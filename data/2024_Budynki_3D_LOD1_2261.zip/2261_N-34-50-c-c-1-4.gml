<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0" xmlns="http://www.opengis.net/citygml/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
			<gml:lowerCorner>471222.99 723520.12 50.11</gml:lowerCorner>
			<gml:upperCorner>471624.55 725849.15 135.59</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E157-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">17.89</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471536.69 723667.22 63.76 471541.5 723662.37 63.76 471543.58 723664.46 63.76 471545.7 723662.29 63.76 471548.04 723659.91 63.76 471550.36 723662.14 63.76 471552.36 723660.15 63.76 471553 723660.77 63.76 471578.46 723634.49 63.76 471577.85 723633.93 63.76 471580.09 723631.54 63.76 471580.73 723632.17 63.76 471585.89 723637.2 63.76 471575.59 723647.88 63.76 471586.87 723658.82 63.76 471588.95 723656.68 63.76 471592.01 723659.64 63.76 471593.5 723658.11 63.76 471599.66 723664.08 63.76 471621.03 723642.02 63.76 471614.47 723635.65 63.76 471618.67 723631.31 63.76 471611.72 723624.56 63.76 471609.88 723626.47 63.76 471602.9 723619.7 63.76 471592.57 723630.3 63.76 471587.44 723625.3 63.76 471595.83 723616.71 63.76 471595.17 723616.09 63.76 471597.27 723613.87 63.76 471592.79 723609.41 63.76 471593.31 723608.89 63.76 471584.61 723600.46 63.76 471580 723605.18 63.76 471578.78 723603.94 63.76 471572.47 723610.4 63.76 471568.19 723606.23 63.76 471561.47 723613.2 63.76 471564.58 723616.21 63.76 471561.22 723619.5 63.76 471552.43 723611.64 63.76 471548.74 723615.63 63.76 471544.1 723611.1 63.76 471536.39 723603.56 63.76 471537.05 723602.89 63.76 471535.73 723601.52 63.76 471525.77 723611.24 63.76 471524.79 723610.24 63.76 471523.66 723611.36 63.76 471521.9 723609.59 63.76 471520.32 723611.16 63.76 471521.23 723612.05 63.76 471517.32 723616.17 63.76 471521.14 723619.89 63.76 471516.79 723624.4 63.76 471517.59 723625.27 63.76 471516.26 723626.64 63.76 471515.38 723625.83 63.76 471511.96 723629.39 63.76 471519.4 723636.58 63.76 471522.38 723633.66 63.76 471528.84 723639.88 63.76 471524.98 723643.74 63.76 471535.83 723654.17 63.76 471529.72 723660.47 63.76 471536.69 723667.22 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471536.69 723667.22 63.76 471529.72 723660.47 63.76 471529.72 723660.47 81.65 471536.69 723667.22 81.65 471536.69 723667.22 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471529.72 723660.47 63.76 471535.83 723654.17 63.76 471535.83 723654.17 81.65 471529.72 723660.47 81.65 471529.72 723660.47 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471535.83 723654.17 63.76 471524.98 723643.74 63.76 471524.98 723643.74 81.65 471535.83 723654.17 81.65 471535.83 723654.17 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471524.98 723643.74 63.76 471528.84 723639.88 63.76 471528.84 723639.88 81.65 471524.98 723643.74 81.65 471524.98 723643.74 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471528.84 723639.88 63.76 471522.38 723633.66 63.76 471522.38 723633.66 81.65 471528.84 723639.88 81.65 471528.84 723639.88 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471522.38 723633.66 63.76 471519.4 723636.58 63.76 471519.4 723636.58 81.65 471522.38 723633.66 81.65 471522.38 723633.66 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471519.4 723636.58 63.76 471511.96 723629.39 63.76 471511.96 723629.39 81.65 471519.4 723636.58 81.65 471519.4 723636.58 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471511.96 723629.39 63.76 471515.38 723625.83 63.76 471515.38 723625.83 81.65 471511.96 723629.39 81.65 471511.96 723629.39 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471515.38 723625.83 63.76 471516.26 723626.64 63.76 471516.26 723626.64 81.65 471515.38 723625.83 81.65 471515.38 723625.83 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471516.26 723626.64 63.76 471517.59 723625.27 63.76 471517.59 723625.27 81.65 471516.26 723626.64 81.65 471516.26 723626.64 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471517.59 723625.27 63.76 471516.79 723624.4 63.76 471516.79 723624.4 81.65 471517.59 723625.27 81.65 471517.59 723625.27 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471516.79 723624.4 63.76 471521.14 723619.89 63.76 471521.14 723619.89 81.65 471516.79 723624.4 81.65 471516.79 723624.4 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471521.14 723619.89 63.76 471517.32 723616.17 63.76 471517.32 723616.17 81.65 471521.14 723619.89 81.65 471521.14 723619.89 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471517.32 723616.17 63.76 471521.23 723612.05 63.76 471521.23 723612.05 81.65 471517.32 723616.17 81.65 471517.32 723616.17 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471521.23 723612.05 63.76 471520.32 723611.16 63.76 471520.32 723611.16 81.65 471521.23 723612.05 81.65 471521.23 723612.05 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471520.32 723611.16 63.76 471521.9 723609.59 63.76 471521.9 723609.59 81.65 471520.32 723611.16 81.65 471520.32 723611.16 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471521.9 723609.59 63.76 471523.66 723611.36 63.76 471523.66 723611.36 81.65 471521.9 723609.59 81.65 471521.9 723609.59 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471523.66 723611.36 63.76 471524.79 723610.24 63.76 471524.79 723610.24 81.65 471523.66 723611.36 81.65 471523.66 723611.36 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471524.79 723610.24 63.76 471525.77 723611.24 63.76 471525.77 723611.24 81.65 471524.79 723610.24 81.65 471524.79 723610.24 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471525.77 723611.24 63.76 471535.73 723601.52 63.76 471535.73 723601.52 81.65 471525.77 723611.24 81.65 471525.77 723611.24 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471535.73 723601.52 63.76 471537.05 723602.89 63.76 471537.05 723602.89 81.65 471535.73 723601.52 81.65 471535.73 723601.52 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471537.05 723602.89 63.76 471536.39 723603.56 63.76 471536.39 723603.56 81.65 471537.05 723602.89 81.65 471537.05 723602.89 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471536.39 723603.56 63.76 471544.1 723611.1 63.76 471544.1 723611.1 81.65 471536.39 723603.56 81.65 471536.39 723603.56 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471544.1 723611.1 63.76 471548.74 723615.63 63.76 471548.74 723615.63 81.65 471544.1 723611.1 81.65 471544.1 723611.1 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471548.74 723615.63 63.76 471552.43 723611.64 63.76 471552.43 723611.64 81.65 471548.74 723615.63 81.65 471548.74 723615.63 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471552.43 723611.64 63.76 471561.22 723619.5 63.76 471561.22 723619.5 81.65 471552.43 723611.64 81.65 471552.43 723611.64 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471561.22 723619.5 63.76 471564.58 723616.21 63.76 471564.58 723616.21 81.65 471561.22 723619.5 81.65 471561.22 723619.5 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.58 723616.21 63.76 471561.47 723613.2 63.76 471561.47 723613.2 81.65 471564.58 723616.21 81.65 471564.58 723616.21 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471561.47 723613.2 63.76 471568.19 723606.23 63.76 471568.19 723606.23 81.65 471561.47 723613.2 81.65 471561.47 723613.2 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471568.19 723606.23 63.76 471572.47 723610.4 63.76 471572.47 723610.4 81.65 471568.19 723606.23 81.65 471568.19 723606.23 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471572.47 723610.4 63.76 471578.78 723603.94 63.76 471578.78 723603.94 81.65 471572.47 723610.4 81.65 471572.47 723610.4 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471578.78 723603.94 63.76 471580 723605.18 63.76 471580 723605.18 81.65 471578.78 723603.94 81.65 471578.78 723603.94 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471580 723605.18 63.76 471584.61 723600.46 63.76 471584.61 723600.46 81.65 471580 723605.18 81.65 471580 723605.18 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471584.61 723600.46 63.76 471593.31 723608.89 63.76 471593.31 723608.89 81.65 471584.61 723600.46 81.65 471584.61 723600.46 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471593.31 723608.89 63.76 471592.79 723609.41 63.76 471592.79 723609.41 81.65 471593.31 723608.89 81.65 471593.31 723608.89 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471592.79 723609.41 63.76 471597.27 723613.87 63.76 471597.27 723613.87 81.65 471592.79 723609.41 81.65 471592.79 723609.41 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471597.27 723613.87 63.76 471595.17 723616.09 63.76 471595.17 723616.09 81.65 471597.27 723613.87 81.65 471597.27 723613.87 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471595.17 723616.09 63.76 471595.83 723616.71 63.76 471595.83 723616.71 81.65 471595.17 723616.09 81.65 471595.17 723616.09 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471595.83 723616.71 63.76 471587.44 723625.3 63.76 471587.44 723625.3 81.65 471595.83 723616.71 81.65 471595.83 723616.71 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471587.44 723625.3 63.76 471592.57 723630.3 63.76 471592.57 723630.3 81.65 471587.44 723625.3 81.65 471587.44 723625.3 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471592.57 723630.3 63.76 471602.9 723619.7 63.76 471602.9 723619.7 81.65 471592.57 723630.3 81.65 471592.57 723630.3 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471602.9 723619.7 63.76 471609.88 723626.47 63.76 471609.88 723626.47 81.65 471602.9 723619.7 81.65 471602.9 723619.7 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471609.88 723626.47 63.76 471611.72 723624.56 63.76 471611.72 723624.56 81.65 471609.88 723626.47 81.65 471609.88 723626.47 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471611.72 723624.56 63.76 471618.67 723631.31 63.76 471618.67 723631.31 81.65 471611.72 723624.56 81.65 471611.72 723624.56 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471618.67 723631.31 63.76 471614.47 723635.65 63.76 471614.47 723635.65 81.65 471618.67 723631.31 81.65 471618.67 723631.31 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471614.47 723635.65 63.76 471621.03 723642.02 63.76 471621.03 723642.02 81.65 471614.47 723635.65 81.65 471614.47 723635.65 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471621.03 723642.02 63.76 471599.66 723664.08 63.76 471599.66 723664.08 81.65 471621.03 723642.02 81.65 471621.03 723642.02 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471599.66 723664.08 63.76 471593.5 723658.11 63.76 471593.5 723658.11 81.65 471599.66 723664.08 81.65 471599.66 723664.08 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471593.5 723658.11 63.76 471592.01 723659.64 63.76 471592.01 723659.64 81.65 471593.5 723658.11 81.65 471593.5 723658.11 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471592.01 723659.64 63.76 471588.95 723656.68 63.76 471588.95 723656.68 81.65 471592.01 723659.64 81.65 471592.01 723659.64 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471588.95 723656.68 63.76 471586.87 723658.82 63.76 471586.87 723658.82 81.65 471588.95 723656.68 81.65 471588.95 723656.68 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471586.87 723658.82 63.76 471575.59 723647.88 63.76 471575.59 723647.88 81.65 471586.87 723658.82 81.65 471586.87 723658.82 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471575.59 723647.88 63.76 471585.89 723637.2 63.76 471585.89 723637.2 81.65 471575.59 723647.88 81.65 471575.59 723647.88 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471585.89 723637.2 63.76 471580.73 723632.17 63.76 471580.73 723632.17 81.65 471585.89 723637.2 81.65 471585.89 723637.2 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471580.73 723632.17 63.76 471580.09 723631.54 63.76 471580.09 723631.54 81.65 471580.73 723632.17 81.65 471580.73 723632.17 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471580.09 723631.54 63.76 471577.85 723633.93 63.76 471577.85 723633.93 81.65 471580.09 723631.54 81.65 471580.09 723631.54 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471577.85 723633.93 63.76 471578.46 723634.49 63.76 471578.46 723634.49 81.65 471577.85 723633.93 81.65 471577.85 723633.93 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471578.46 723634.49 63.76 471553 723660.77 63.76 471553 723660.77 81.65 471578.46 723634.49 81.65 471578.46 723634.49 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471553 723660.77 63.76 471552.36 723660.15 63.76 471552.36 723660.15 81.65 471553 723660.77 81.65 471553 723660.77 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471552.36 723660.15 63.76 471550.36 723662.14 63.76 471550.36 723662.14 81.65 471552.36 723660.15 81.65 471552.36 723660.15 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471550.36 723662.14 63.76 471548.04 723659.91 63.76 471548.04 723659.91 81.65 471550.36 723662.14 81.65 471550.36 723662.14 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471548.04 723659.91 63.76 471545.7 723662.29 63.76 471545.7 723662.29 81.65 471548.04 723659.91 81.65 471548.04 723659.91 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471545.7 723662.29 63.76 471543.58 723664.46 63.76 471543.58 723664.46 81.65 471545.7 723662.29 81.65 471545.7 723662.29 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471543.58 723664.46 63.76 471541.5 723662.37 63.76 471541.5 723662.37 81.65 471543.58 723664.46 81.65 471543.58 723664.46 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471541.5 723662.37 63.76 471536.69 723667.22 63.76 471536.69 723667.22 81.65 471541.5 723662.37 81.65 471541.5 723662.37 63.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E157-FAF6-E053-CA2BA8C0FAE4_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471536.69 723667.22 81.65 471529.72 723660.47 81.65 471535.83 723654.17 81.65 471524.98 723643.74 81.65 471528.84 723639.88 81.65 471522.38 723633.66 81.65 471519.4 723636.58 81.65 471511.96 723629.39 81.65 471515.38 723625.83 81.65 471516.26 723626.64 81.65 471517.59 723625.27 81.65 471516.79 723624.4 81.65 471521.14 723619.89 81.65 471517.32 723616.17 81.65 471521.23 723612.05 81.65 471520.32 723611.16 81.65 471521.9 723609.59 81.65 471523.66 723611.36 81.65 471524.79 723610.24 81.65 471525.77 723611.24 81.65 471535.73 723601.52 81.65 471537.05 723602.89 81.65 471536.39 723603.56 81.65 471544.1 723611.1 81.65 471548.74 723615.63 81.65 471552.43 723611.64 81.65 471561.22 723619.5 81.65 471564.58 723616.21 81.65 471561.47 723613.2 81.65 471568.19 723606.23 81.65 471572.47 723610.4 81.65 471578.78 723603.94 81.65 471580 723605.18 81.65 471584.61 723600.46 81.65 471593.31 723608.89 81.65 471592.79 723609.41 81.65 471597.27 723613.87 81.65 471595.17 723616.09 81.65 471595.83 723616.71 81.65 471587.44 723625.3 81.65 471592.57 723630.3 81.65 471602.9 723619.7 81.65 471609.88 723626.47 81.65 471611.72 723624.56 81.65 471618.67 723631.31 81.65 471614.47 723635.65 81.65 471621.03 723642.02 81.65 471599.66 723664.08 81.65 471593.5 723658.11 81.65 471592.01 723659.64 81.65 471588.95 723656.68 81.65 471586.87 723658.82 81.65 471575.59 723647.88 81.65 471585.89 723637.2 81.65 471580.73 723632.17 81.65 471580.09 723631.54 81.65 471577.85 723633.93 81.65 471578.46 723634.49 81.65 471553 723660.77 81.65 471552.36 723660.15 81.65 471550.36 723662.14 81.65 471548.04 723659.91 81.65 471545.7 723662.29 81.65 471543.58 723664.46 81.65 471541.5 723662.37 81.65 471536.69 723667.22 81.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.58</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471573.04 725836.48 50.11 471589.81 725843.01 50.11 471589.18 725844.8 50.11 471600.67 725849.15 50.11 471603.14 725843.23 50.11 471612.9 725846.97 50.11 471615.44 725840.53 50.11 471594.32 725832.33 50.11 471593.73 725833.85 50.11 471576.56 725827.21 50.11 471573.04 725836.48 50.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471573.04 725836.48 50.11 471576.56 725827.21 50.11 471576.56 725827.21 54.69 471573.04 725836.48 54.69 471573.04 725836.48 50.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471576.56 725827.21 50.11 471593.73 725833.85 50.11 471593.73 725833.85 54.69 471576.56 725827.21 54.69 471576.56 725827.21 50.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471593.73 725833.85 50.11 471594.32 725832.33 50.11 471594.32 725832.33 54.69 471593.73 725833.85 54.69 471593.73 725833.85 50.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471594.32 725832.33 50.11 471615.44 725840.53 50.11 471615.44 725840.53 54.69 471594.32 725832.33 54.69 471594.32 725832.33 50.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471615.44 725840.53 50.11 471612.9 725846.97 50.11 471612.9 725846.97 54.69 471615.44 725840.53 54.69 471615.44 725840.53 50.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471612.9 725846.97 50.11 471603.14 725843.23 50.11 471603.14 725843.23 54.69 471612.9 725846.97 54.69 471612.9 725846.97 50.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471603.14 725843.23 50.11 471600.67 725849.15 50.11 471600.67 725849.15 54.69 471603.14 725843.23 54.69 471603.14 725843.23 50.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471600.67 725849.15 50.11 471589.18 725844.8 50.11 471589.18 725844.8 54.69 471600.67 725849.15 54.69 471600.67 725849.15 50.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471589.18 725844.8 50.11 471589.81 725843.01 50.11 471589.81 725843.01 54.69 471589.18 725844.8 54.69 471589.18 725844.8 50.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471589.81 725843.01 50.11 471573.04 725836.48 50.11 471573.04 725836.48 54.69 471589.81 725843.01 54.69 471589.81 725843.01 50.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA5-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471573.04 725836.48 54.69 471576.56 725827.21 54.69 471593.73 725833.85 54.69 471594.32 725832.33 54.69 471615.44 725840.53 54.69 471612.9 725846.97 54.69 471603.14 725843.23 54.69 471600.67 725849.15 54.69 471589.18 725844.8 54.69 471589.81 725843.01 54.69 471573.04 725836.48 54.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2769-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">35.1</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471445.69 723544.9 85.13 471455.57 723544.8 85.13 471455.53 723541.81 85.13 471455.45 723537.38 85.13 471455.37 723530.46 85.13 471455.3 723526.05 85.13 471450.28 723526.07 85.13 471450.28 723527.26 85.13 471448.8 723527.27 85.13 471448.77 723520.12 85.13 471438.99 723520.16 85.13 471438.86 723523.08 85.13 471438.92 723527.54 85.13 471439.02 723534.54 85.13 471439.09 723538.97 85.13 471444.12 723538.88 85.13 471444.1 723537.7 85.13 471445.6 723537.67 85.13 471445.69 723544.9 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471445.69 723544.9 85.13 471445.6 723537.67 85.13 471445.6 723537.67 120.23 471445.69 723544.9 120.23 471445.69 723544.9 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471445.6 723537.67 85.13 471444.1 723537.7 85.13 471444.1 723537.7 120.23 471445.6 723537.67 120.23 471445.6 723537.67 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471444.1 723537.7 85.13 471444.12 723538.88 85.13 471444.12 723538.88 120.23 471444.1 723537.7 120.23 471444.1 723537.7 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471444.12 723538.88 85.13 471439.09 723538.97 85.13 471439.09 723538.97 120.23 471444.12 723538.88 120.23 471444.12 723538.88 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.09 723538.97 85.13 471439.02 723534.54 85.13 471439.02 723534.54 120.23 471439.09 723538.97 120.23 471439.09 723538.97 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.02 723534.54 85.13 471438.92 723527.54 85.13 471438.92 723527.54 120.23 471439.02 723534.54 120.23 471439.02 723534.54 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.92 723527.54 85.13 471438.86 723523.08 85.13 471438.86 723523.08 120.23 471438.92 723527.54 120.23 471438.92 723527.54 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.86 723523.08 85.13 471438.99 723520.16 85.13 471438.99 723520.16 120.23 471438.86 723523.08 120.23 471438.86 723523.08 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.99 723520.16 85.13 471448.77 723520.12 85.13 471448.77 723520.12 120.23 471438.99 723520.16 120.23 471438.99 723520.16 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471448.77 723520.12 85.13 471448.8 723527.27 85.13 471448.8 723527.27 120.23 471448.77 723520.12 120.23 471448.77 723520.12 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471448.8 723527.27 85.13 471450.28 723527.26 85.13 471450.28 723527.26 120.23 471448.8 723527.27 120.23 471448.8 723527.27 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.28 723527.26 85.13 471450.28 723526.07 85.13 471450.28 723526.07 120.23 471450.28 723527.26 120.23 471450.28 723527.26 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.28 723526.07 85.13 471455.3 723526.05 85.13 471455.3 723526.05 120.23 471450.28 723526.07 120.23 471450.28 723526.07 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.3 723526.05 85.13 471455.37 723530.46 85.13 471455.37 723530.46 120.23 471455.3 723526.05 120.23 471455.3 723526.05 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.37 723530.46 85.13 471455.45 723537.38 85.13 471455.45 723537.38 120.23 471455.37 723530.46 120.23 471455.37 723530.46 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.45 723537.38 85.13 471455.53 723541.81 85.13 471455.53 723541.81 120.23 471455.45 723537.38 120.23 471455.45 723537.38 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.53 723541.81 85.13 471455.57 723544.8 85.13 471455.57 723544.8 120.23 471455.53 723541.81 120.23 471455.53 723541.81 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.57 723544.8 85.13 471445.69 723544.9 85.13 471445.69 723544.9 120.23 471455.57 723544.8 120.23 471455.57 723544.8 85.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2769-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471445.69 723544.9 120.23 471445.6 723537.67 120.23 471444.1 723537.7 120.23 471444.12 723538.88 120.23 471439.09 723538.97 120.23 471439.02 723534.54 120.23 471438.92 723527.54 120.23 471438.86 723523.08 120.23 471438.99 723520.16 120.23 471448.77 723520.12 120.23 471448.8 723527.27 120.23 471450.28 723527.26 120.23 471450.28 723526.07 120.23 471455.3 723526.05 120.23 471455.37 723530.46 120.23 471455.45 723537.38 120.23 471455.53 723541.81 120.23 471455.57 723544.8 120.23 471445.69 723544.9 120.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">16.52</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.55 723980.88 89.82 471563.07 723980.68 89.82 471562.93 723978.19 89.82 471567.12 723977.95 89.82 471567.08 723977.35 89.82 471569.88 723977.19 89.82 471569.92 723977.79 89.82 471573.12 723977.6 89.82 471573.26 723980.1 89.82 471576.68 723979.9 89.82 471576.54 723977.42 89.82 471584.23 723976.97 89.82 471584.27 723977.57 89.82 471588.43 723977.33 89.82 471588.56 723979.82 89.82 471591.8 723979.64 89.82 471591.67 723977.14 89.82 471595.84 723976.91 89.82 471595.81 723976.32 89.82 471598.6 723976.14 89.82 471598.64 723976.74 89.82 471602.76 723976.5 89.82 471602.9 723979 89.82 471606.17 723978.81 89.82 471606.04 723976.32 89.82 471610.21 723976.08 89.82 471610.1 723974.26 89.82 471612.93 723974.1 89.82 471612.96 723974.7 89.82 471617.13 723974.47 89.82 471617.28 723976.97 89.82 471620.51 723976.78 89.82 471620.37 723974.29 89.82 471624.55 723974.06 89.82 471624.02 723964.88 89.82 471621.23 723965.05 89.82 471621.21 723964.44 89.82 471609.62 723965.09 89.82 471609.73 723966.88 89.82 471606.95 723967.04 89.82 471606.93 723966.47 89.82 471595.33 723967.12 89.82 471595.36 723967.69 89.82 471592.57 723967.88 89.82 471592.53 723967.28 89.82 471578.22 723968.12 89.82 471578.19 723967.52 89.82 471566.6 723968.18 89.82 471566.64 723968.76 89.82 471563.8 723968.95 89.82 471563.78 723968.35 89.82 471555.91 723968.8 89.82 471555.94 723969.39 89.82 471551.09 723969.67 89.82 471551.59 723978.23 89.82 471556.39 723977.95 89.82 471556.42 723978.56 89.82 471559.41 723978.38 89.82 471559.55 723980.88 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.55 723980.88 89.82 471559.41 723978.38 89.82 471559.41 723978.38 106.34 471559.55 723980.88 106.34 471559.55 723980.88 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.41 723978.38 89.82 471556.42 723978.56 89.82 471556.42 723978.56 106.34 471559.41 723978.38 106.34 471559.41 723978.38 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471556.42 723978.56 89.82 471556.39 723977.95 89.82 471556.39 723977.95 106.34 471556.42 723978.56 106.34 471556.42 723978.56 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471556.39 723977.95 89.82 471551.59 723978.23 89.82 471551.59 723978.23 106.34 471556.39 723977.95 106.34 471556.39 723977.95 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471551.59 723978.23 89.82 471551.09 723969.67 89.82 471551.09 723969.67 106.34 471551.59 723978.23 106.34 471551.59 723978.23 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471551.09 723969.67 89.82 471555.94 723969.39 89.82 471555.94 723969.39 106.34 471551.09 723969.67 106.34 471551.09 723969.67 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471555.94 723969.39 89.82 471555.91 723968.8 89.82 471555.91 723968.8 106.34 471555.94 723969.39 106.34 471555.94 723969.39 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471555.91 723968.8 89.82 471563.78 723968.35 89.82 471563.78 723968.35 106.34 471555.91 723968.8 106.34 471555.91 723968.8 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471563.78 723968.35 89.82 471563.8 723968.95 89.82 471563.8 723968.95 106.34 471563.78 723968.35 106.34 471563.78 723968.35 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471563.8 723968.95 89.82 471566.64 723968.76 89.82 471566.64 723968.76 106.34 471563.8 723968.95 106.34 471563.8 723968.95 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471566.64 723968.76 89.82 471566.6 723968.18 89.82 471566.6 723968.18 106.34 471566.64 723968.76 106.34 471566.64 723968.76 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471566.6 723968.18 89.82 471578.19 723967.52 89.82 471578.19 723967.52 106.34 471566.6 723968.18 106.34 471566.6 723968.18 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471578.19 723967.52 89.82 471578.22 723968.12 89.82 471578.22 723968.12 106.34 471578.19 723967.52 106.34 471578.19 723967.52 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471578.22 723968.12 89.82 471592.53 723967.28 89.82 471592.53 723967.28 106.34 471578.22 723968.12 106.34 471578.22 723968.12 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471592.53 723967.28 89.82 471592.57 723967.88 89.82 471592.57 723967.88 106.34 471592.53 723967.28 106.34 471592.53 723967.28 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471592.57 723967.88 89.82 471595.36 723967.69 89.82 471595.36 723967.69 106.34 471592.57 723967.88 106.34 471592.57 723967.88 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471595.36 723967.69 89.82 471595.33 723967.12 89.82 471595.33 723967.12 106.34 471595.36 723967.69 106.34 471595.36 723967.69 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471595.33 723967.12 89.82 471606.93 723966.47 89.82 471606.93 723966.47 106.34 471595.33 723967.12 106.34 471595.33 723967.12 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471606.93 723966.47 89.82 471606.95 723967.04 89.82 471606.95 723967.04 106.34 471606.93 723966.47 106.34 471606.93 723966.47 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471606.95 723967.04 89.82 471609.73 723966.88 89.82 471609.73 723966.88 106.34 471606.95 723967.04 106.34 471606.95 723967.04 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471609.73 723966.88 89.82 471609.62 723965.09 89.82 471609.62 723965.09 106.34 471609.73 723966.88 106.34 471609.73 723966.88 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471609.62 723965.09 89.82 471621.21 723964.44 89.82 471621.21 723964.44 106.34 471609.62 723965.09 106.34 471609.62 723965.09 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471621.21 723964.44 89.82 471621.23 723965.05 89.82 471621.23 723965.05 106.34 471621.21 723964.44 106.34 471621.21 723964.44 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471621.23 723965.05 89.82 471624.02 723964.88 89.82 471624.02 723964.88 106.34 471621.23 723965.05 106.34 471621.23 723965.05 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471624.02 723964.88 89.82 471624.55 723974.06 89.82 471624.55 723974.06 106.34 471624.02 723964.88 106.34 471624.02 723964.88 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471624.55 723974.06 89.82 471620.37 723974.29 89.82 471620.37 723974.29 106.34 471624.55 723974.06 106.34 471624.55 723974.06 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471620.37 723974.29 89.82 471620.51 723976.78 89.82 471620.51 723976.78 106.34 471620.37 723974.29 106.34 471620.37 723974.29 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471620.51 723976.78 89.82 471617.28 723976.97 89.82 471617.28 723976.97 106.34 471620.51 723976.78 106.34 471620.51 723976.78 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471617.28 723976.97 89.82 471617.13 723974.47 89.82 471617.13 723974.47 106.34 471617.28 723976.97 106.34 471617.28 723976.97 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471617.13 723974.47 89.82 471612.96 723974.7 89.82 471612.96 723974.7 106.34 471617.13 723974.47 106.34 471617.13 723974.47 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471612.96 723974.7 89.82 471612.93 723974.1 89.82 471612.93 723974.1 106.34 471612.96 723974.7 106.34 471612.96 723974.7 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471612.93 723974.1 89.82 471610.1 723974.26 89.82 471610.1 723974.26 106.34 471612.93 723974.1 106.34 471612.93 723974.1 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471610.1 723974.26 89.82 471610.21 723976.08 89.82 471610.21 723976.08 106.34 471610.1 723974.26 106.34 471610.1 723974.26 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471610.21 723976.08 89.82 471606.04 723976.32 89.82 471606.04 723976.32 106.34 471610.21 723976.08 106.34 471610.21 723976.08 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471606.04 723976.32 89.82 471606.17 723978.81 89.82 471606.17 723978.81 106.34 471606.04 723976.32 106.34 471606.04 723976.32 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471606.17 723978.81 89.82 471602.9 723979 89.82 471602.9 723979 106.34 471606.17 723978.81 106.34 471606.17 723978.81 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471602.9 723979 89.82 471602.76 723976.5 89.82 471602.76 723976.5 106.34 471602.9 723979 106.34 471602.9 723979 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471602.76 723976.5 89.82 471598.64 723976.74 89.82 471598.64 723976.74 106.34 471602.76 723976.5 106.34 471602.76 723976.5 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471598.64 723976.74 89.82 471598.6 723976.14 89.82 471598.6 723976.14 106.34 471598.64 723976.74 106.34 471598.64 723976.74 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471598.6 723976.14 89.82 471595.81 723976.32 89.82 471595.81 723976.32 106.34 471598.6 723976.14 106.34 471598.6 723976.14 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471595.81 723976.32 89.82 471595.84 723976.91 89.82 471595.84 723976.91 106.34 471595.81 723976.32 106.34 471595.81 723976.32 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471595.84 723976.91 89.82 471591.67 723977.14 89.82 471591.67 723977.14 106.34 471595.84 723976.91 106.34 471595.84 723976.91 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471591.67 723977.14 89.82 471591.8 723979.64 89.82 471591.8 723979.64 106.34 471591.67 723977.14 106.34 471591.67 723977.14 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471591.8 723979.64 89.82 471588.56 723979.82 89.82 471588.56 723979.82 106.34 471591.8 723979.64 106.34 471591.8 723979.64 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471588.56 723979.82 89.82 471588.43 723977.33 89.82 471588.43 723977.33 106.34 471588.56 723979.82 106.34 471588.56 723979.82 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471588.43 723977.33 89.82 471584.27 723977.57 89.82 471584.27 723977.57 106.34 471588.43 723977.33 106.34 471588.43 723977.33 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471584.27 723977.57 89.82 471584.23 723976.97 89.82 471584.23 723976.97 106.34 471584.27 723977.57 106.34 471584.27 723977.57 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471584.23 723976.97 89.82 471576.54 723977.42 89.82 471576.54 723977.42 106.34 471584.23 723976.97 106.34 471584.23 723976.97 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471576.54 723977.42 89.82 471576.68 723979.9 89.82 471576.68 723979.9 106.34 471576.54 723977.42 106.34 471576.54 723977.42 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471576.68 723979.9 89.82 471573.26 723980.1 89.82 471573.26 723980.1 106.34 471576.68 723979.9 106.34 471576.68 723979.9 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471573.26 723980.1 89.82 471573.12 723977.6 89.82 471573.12 723977.6 106.34 471573.26 723980.1 106.34 471573.26 723980.1 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471573.12 723977.6 89.82 471569.92 723977.79 89.82 471569.92 723977.79 106.34 471573.12 723977.6 106.34 471573.12 723977.6 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471569.92 723977.79 89.82 471569.88 723977.19 89.82 471569.88 723977.19 106.34 471569.92 723977.79 106.34 471569.92 723977.79 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471569.88 723977.19 89.82 471567.08 723977.35 89.82 471567.08 723977.35 106.34 471569.88 723977.19 106.34 471569.88 723977.19 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471567.08 723977.35 89.82 471567.12 723977.95 89.82 471567.12 723977.95 106.34 471567.08 723977.35 106.34 471567.08 723977.35 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471567.12 723977.95 89.82 471562.93 723978.19 89.82 471562.93 723978.19 106.34 471567.12 723977.95 106.34 471567.12 723977.95 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471562.93 723978.19 89.82 471563.07 723980.68 89.82 471563.07 723980.68 106.34 471562.93 723978.19 106.34 471562.93 723978.19 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471563.07 723980.68 89.82 471559.55 723980.88 89.82 471559.55 723980.88 106.34 471563.07 723980.68 106.34 471563.07 723980.68 89.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B88-FAF6-E053-CA2BA8C0FAE4_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.55 723980.88 106.34 471559.41 723978.38 106.34 471556.42 723978.56 106.34 471556.39 723977.95 106.34 471551.59 723978.23 106.34 471551.09 723969.67 106.34 471555.94 723969.39 106.34 471555.91 723968.8 106.34 471563.78 723968.35 106.34 471563.8 723968.95 106.34 471566.64 723968.76 106.34 471566.6 723968.18 106.34 471578.19 723967.52 106.34 471578.22 723968.12 106.34 471592.53 723967.28 106.34 471592.57 723967.88 106.34 471595.36 723967.69 106.34 471595.33 723967.12 106.34 471606.93 723966.47 106.34 471606.95 723967.04 106.34 471609.73 723966.88 106.34 471609.62 723965.09 106.34 471621.21 723964.44 106.34 471621.23 723965.05 106.34 471624.02 723964.88 106.34 471624.55 723974.06 106.34 471620.37 723974.29 106.34 471620.51 723976.78 106.34 471617.28 723976.97 106.34 471617.13 723974.47 106.34 471612.96 723974.7 106.34 471612.93 723974.1 106.34 471610.1 723974.26 106.34 471610.21 723976.08 106.34 471606.04 723976.32 106.34 471606.17 723978.81 106.34 471602.9 723979 106.34 471602.76 723976.5 106.34 471598.64 723976.74 106.34 471598.6 723976.14 106.34 471595.81 723976.32 106.34 471595.84 723976.91 106.34 471591.67 723977.14 106.34 471591.8 723979.64 106.34 471588.56 723979.82 106.34 471588.43 723977.33 106.34 471584.27 723977.57 106.34 471584.23 723976.97 106.34 471576.54 723977.42 106.34 471576.68 723979.9 106.34 471573.26 723980.1 106.34 471573.12 723977.6 106.34 471569.92 723977.79 106.34 471569.88 723977.19 106.34 471567.08 723977.35 106.34 471567.12 723977.95 106.34 471562.93 723978.19 106.34 471563.07 723980.68 106.34 471559.55 723980.88 106.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">34.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.63 723935.53 98.72 471349.3 723934.24 98.72 471346.82 723915.61 98.72 471341.85 723916.26 98.72 471342.01 723917.42 98.72 471340.43 723917.64 98.72 471339.47 723910.54 98.72 471329.84 723911.79 98.72 471332.32 723930.45 98.72 471337.27 723929.78 98.72 471337.11 723928.59 98.72 471338.67 723928.38 98.72 471339.63 723935.53 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.63 723935.53 98.72 471338.67 723928.38 98.72 471338.67 723928.38 133.51 471339.63 723935.53 133.51 471339.63 723935.53 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.67 723928.38 98.72 471337.11 723928.59 98.72 471337.11 723928.59 133.51 471338.67 723928.38 133.51 471338.67 723928.38 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.11 723928.59 98.72 471337.27 723929.78 98.72 471337.27 723929.78 133.51 471337.11 723928.59 133.51 471337.11 723928.59 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.27 723929.78 98.72 471332.32 723930.45 98.72 471332.32 723930.45 133.51 471337.27 723929.78 133.51 471337.27 723929.78 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471332.32 723930.45 98.72 471329.84 723911.79 98.72 471329.84 723911.79 133.51 471332.32 723930.45 133.51 471332.32 723930.45 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.84 723911.79 98.72 471339.47 723910.54 98.72 471339.47 723910.54 133.51 471329.84 723911.79 133.51 471329.84 723911.79 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.47 723910.54 98.72 471340.43 723917.64 98.72 471340.43 723917.64 133.51 471339.47 723910.54 133.51 471339.47 723910.54 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471340.43 723917.64 98.72 471342.01 723917.42 98.72 471342.01 723917.42 133.51 471340.43 723917.64 133.51 471340.43 723917.64 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.01 723917.42 98.72 471341.85 723916.26 98.72 471341.85 723916.26 133.51 471342.01 723917.42 133.51 471342.01 723917.42 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471341.85 723916.26 98.72 471346.82 723915.61 98.72 471346.82 723915.61 133.51 471341.85 723916.26 133.51 471341.85 723916.26 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471346.82 723915.61 98.72 471349.3 723934.24 98.72 471349.3 723934.24 133.51 471346.82 723915.61 133.51 471346.82 723915.61 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471349.3 723934.24 98.72 471339.63 723935.53 98.72 471339.63 723935.53 133.51 471349.3 723934.24 133.51 471349.3 723934.24 98.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F97-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.63 723935.53 133.51 471338.67 723928.38 133.51 471337.11 723928.59 133.51 471337.27 723929.78 133.51 471332.32 723930.45 133.51 471329.84 723911.79 133.51 471339.47 723910.54 133.51 471340.43 723917.64 133.51 471342.01 723917.42 133.51 471341.85 723916.26 133.51 471346.82 723915.61 133.51 471349.3 723934.24 133.51 471339.63 723935.53 133.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">34.73</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.61 724090.8 100.86 471322.39 724089.55 100.86 471320.03 724070.91 100.86 471315.08 724071.54 100.86 471315.23 724072.74 100.86 471313.73 724072.9 100.86 471312.81 724065.8 100.86 471303.09 724067.07 100.86 471305.37 724085.7 100.86 471310.27 724085.05 100.86 471310.11 724083.86 100.86 471311.7 724083.66 100.86 471312.61 724090.8 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.61 724090.8 100.86 471311.7 724083.66 100.86 471311.7 724083.66 135.59 471312.61 724090.8 135.59 471312.61 724090.8 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.7 724083.66 100.86 471310.11 724083.86 100.86 471310.11 724083.86 135.59 471311.7 724083.66 135.59 471311.7 724083.66 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471310.11 724083.86 100.86 471310.27 724085.05 100.86 471310.27 724085.05 135.59 471310.11 724083.86 135.59 471310.11 724083.86 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471310.27 724085.05 100.86 471305.37 724085.7 100.86 471305.37 724085.7 135.59 471310.27 724085.05 135.59 471310.27 724085.05 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.37 724085.7 100.86 471303.09 724067.07 100.86 471303.09 724067.07 135.59 471305.37 724085.7 135.59 471305.37 724085.7 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471303.09 724067.07 100.86 471312.81 724065.8 100.86 471312.81 724065.8 135.59 471303.09 724067.07 135.59 471303.09 724067.07 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.81 724065.8 100.86 471313.73 724072.9 100.86 471313.73 724072.9 135.59 471312.81 724065.8 135.59 471312.81 724065.8 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471313.73 724072.9 100.86 471315.23 724072.74 100.86 471315.23 724072.74 135.59 471313.73 724072.9 135.59 471313.73 724072.9 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471315.23 724072.74 100.86 471315.08 724071.54 100.86 471315.08 724071.54 135.59 471315.23 724072.74 135.59 471315.23 724072.74 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471315.08 724071.54 100.86 471320.03 724070.91 100.86 471320.03 724070.91 135.59 471315.08 724071.54 135.59 471315.08 724071.54 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471320.03 724070.91 100.86 471322.39 724089.55 100.86 471322.39 724089.55 135.59 471320.03 724070.91 135.59 471320.03 724070.91 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471322.39 724089.55 100.86 471312.61 724090.8 100.86 471312.61 724090.8 135.59 471322.39 724089.55 135.59 471322.39 724089.55 100.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE9-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.61 724090.8 135.59 471311.7 724083.66 135.59 471310.11 724083.86 135.59 471310.27 724085.05 135.59 471305.37 724085.7 135.59 471303.09 724067.07 135.59 471312.81 724065.8 135.59 471313.73 724072.9 135.59 471315.23 724072.74 135.59 471315.08 724071.54 135.59 471320.03 724070.91 135.59 471322.39 724089.55 135.59 471312.61 724090.8 135.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">16.18</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.48 723989.63 99.51 471322.85 723988.28 99.51 471322.61 723986.5 99.51 471336.83 723984.58 99.51 471336.52 723982.2 99.51 471350.77 723980.34 99.51 471349.51 723970.53 99.51 471338.01 723972 99.51 471338.07 723972.59 99.51 471335.07 723972.99 99.51 471335.31 723974.83 99.51 471324.02 723976.34 99.51 471324.09 723976.94 99.51 471321.11 723977.31 99.51 471321.35 723979.12 99.51 471318.56 723979.48 99.51 471318.48 723978.88 99.51 471311.16 723979.8 99.51 471311.23 723980.39 99.51 471306.52 723980.99 99.51 471307.59 723989.54 99.51 471312.41 723989.05 99.51 471312.48 723989.63 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.48 723989.63 99.51 471312.41 723989.05 99.51 471312.41 723989.05 115.69 471312.48 723989.63 115.69 471312.48 723989.63 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.41 723989.05 99.51 471307.59 723989.54 99.51 471307.59 723989.54 115.69 471312.41 723989.05 115.69 471312.41 723989.05 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471307.59 723989.54 99.51 471306.52 723980.99 99.51 471306.52 723980.99 115.69 471307.59 723989.54 115.69 471307.59 723989.54 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471306.52 723980.99 99.51 471311.23 723980.39 99.51 471311.23 723980.39 115.69 471306.52 723980.99 115.69 471306.52 723980.99 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.23 723980.39 99.51 471311.16 723979.8 99.51 471311.16 723979.8 115.69 471311.23 723980.39 115.69 471311.23 723980.39 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.16 723979.8 99.51 471318.48 723978.88 99.51 471318.48 723978.88 115.69 471311.16 723979.8 115.69 471311.16 723979.8 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.48 723978.88 99.51 471318.56 723979.48 99.51 471318.56 723979.48 115.69 471318.48 723978.88 115.69 471318.48 723978.88 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.56 723979.48 99.51 471321.35 723979.12 99.51 471321.35 723979.12 115.69 471318.56 723979.48 115.69 471318.56 723979.48 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471321.35 723979.12 99.51 471321.11 723977.31 99.51 471321.11 723977.31 115.69 471321.35 723979.12 115.69 471321.35 723979.12 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471321.11 723977.31 99.51 471324.09 723976.94 99.51 471324.09 723976.94 115.69 471321.11 723977.31 115.69 471321.11 723977.31 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471324.09 723976.94 99.51 471324.02 723976.34 99.51 471324.02 723976.34 115.69 471324.09 723976.94 115.69 471324.09 723976.94 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471324.02 723976.34 99.51 471335.31 723974.83 99.51 471335.31 723974.83 115.69 471324.02 723976.34 115.69 471324.02 723976.34 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471335.31 723974.83 99.51 471335.07 723972.99 99.51 471335.07 723972.99 115.69 471335.31 723974.83 115.69 471335.31 723974.83 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471335.07 723972.99 99.51 471338.07 723972.59 99.51 471338.07 723972.59 115.69 471335.07 723972.99 115.69 471335.07 723972.99 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.07 723972.59 99.51 471338.01 723972 99.51 471338.01 723972 115.69 471338.07 723972.59 115.69 471338.07 723972.59 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.01 723972 99.51 471349.51 723970.53 99.51 471349.51 723970.53 115.69 471338.01 723972 115.69 471338.01 723972 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471349.51 723970.53 99.51 471350.77 723980.34 99.51 471350.77 723980.34 115.69 471349.51 723970.53 115.69 471349.51 723970.53 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.77 723980.34 99.51 471336.52 723982.2 99.51 471336.52 723982.2 115.69 471350.77 723980.34 115.69 471350.77 723980.34 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471336.52 723982.2 99.51 471336.83 723984.58 99.51 471336.83 723984.58 115.69 471336.52 723982.2 115.69 471336.52 723982.2 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471336.83 723984.58 99.51 471322.61 723986.5 99.51 471322.61 723986.5 115.69 471336.83 723984.58 115.69 471336.83 723984.58 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471322.61 723986.5 99.51 471322.85 723988.28 99.51 471322.85 723988.28 115.69 471322.61 723986.5 115.69 471322.61 723986.5 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471322.85 723988.28 99.51 471312.48 723989.63 99.51 471312.48 723989.63 115.69 471322.85 723988.28 115.69 471322.85 723988.28 99.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2EE8-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.48 723989.63 115.69 471312.41 723989.05 115.69 471307.59 723989.54 115.69 471306.52 723980.99 115.69 471311.23 723980.39 115.69 471311.16 723979.8 115.69 471318.48 723978.88 115.69 471318.56 723979.48 115.69 471321.35 723979.12 115.69 471321.11 723977.31 115.69 471324.09 723976.94 115.69 471324.02 723976.34 115.69 471335.31 723974.83 115.69 471335.07 723972.99 115.69 471338.07 723972.59 115.69 471338.01 723972 115.69 471349.51 723970.53 115.69 471350.77 723980.34 115.69 471336.52 723982.2 115.69 471336.83 723984.58 115.69 471322.61 723986.5 115.69 471322.85 723988.28 115.69 471312.48 723989.63 115.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F1A8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F1A8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">11.69</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.68 723788.19 70.89 471328.78 723783.86 70.89 471327.88 723783.83 70.89 471327.95 723781.48 70.89 471318.63 723780.89 70.89 471318.57 723783.84 70.89 471317.07 723783.8 70.89 471316.97 723787.99 70.89 471328.68 723788.19 70.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.68 723788.19 70.89 471316.97 723787.99 70.89 471316.97 723787.99 82.575 471328.68 723788.19 82.575 471328.68 723788.19 70.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471316.97 723787.99 70.89 471317.07 723783.8 70.89 471317.07 723783.8 82.575 471316.97 723787.99 82.575 471316.97 723787.99 70.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.07 723783.8 70.89 471318.57 723783.84 70.89 471318.57 723783.84 82.575 471317.07 723783.8 82.575 471317.07 723783.8 70.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.57 723783.84 70.89 471318.63 723780.89 70.89 471318.63 723780.89 82.575 471318.57 723783.84 82.575 471318.57 723783.84 70.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.63 723780.89 70.89 471327.95 723781.48 70.89 471327.95 723781.48 82.575 471318.63 723780.89 82.575 471318.63 723780.89 70.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A8-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.95 723781.48 70.89 471327.88 723783.83 70.89 471327.88 723783.83 82.575 471327.95 723781.48 82.575 471327.95 723781.48 70.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A8-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.88 723783.83 70.89 471328.78 723783.86 70.89 471328.78 723783.86 82.575 471327.88 723783.83 82.575 471327.88 723783.83 70.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A8-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.78 723783.86 70.89 471328.68 723788.19 70.89 471328.68 723788.19 82.575 471328.78 723783.86 82.575 471328.78 723783.86 70.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A8-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.68 723788.19 82.575 471316.97 723787.99 82.575 471317.07 723783.8 82.575 471318.57 723783.84 82.575 471318.63 723780.89 82.575 471327.95 723781.48 82.575 471327.88 723783.83 82.575 471328.78 723783.86 82.575 471328.68 723788.19 82.575</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">16.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.95 723930.55 98.25 471394.09 723929.34 98.25 471393.7 723926.37 98.25 471394.32 723926.28 98.25 471390.75 723899.44 98.25 471387.08 723899.89 98.25 471387.24 723901.08 98.25 471385.65 723901.29 98.25 471384.56 723892.97 98.25 471378.26 723893.8 98.25 471378.42 723894.98 98.25 471374.25 723895.53 98.25 471374.65 723898.49 98.25 471374.05 723898.57 98.25 471375.56 723910.02 98.25 471380.52 723909.34 98.25 471380.36 723908.16 98.25 471381.95 723908.01 98.25 471384.95 723930.55 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.95 723930.55 98.25 471381.95 723908.01 98.25 471381.95 723908.01 114.54 471384.95 723930.55 114.54 471384.95 723930.55 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.95 723908.01 98.25 471380.36 723908.16 98.25 471380.36 723908.16 114.54 471381.95 723908.01 114.54 471381.95 723908.01 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.36 723908.16 98.25 471380.52 723909.34 98.25 471380.52 723909.34 114.54 471380.36 723908.16 114.54 471380.36 723908.16 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.52 723909.34 98.25 471375.56 723910.02 98.25 471375.56 723910.02 114.54 471380.52 723909.34 114.54 471380.52 723909.34 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.56 723910.02 98.25 471374.05 723898.57 98.25 471374.05 723898.57 114.54 471375.56 723910.02 114.54 471375.56 723910.02 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471374.05 723898.57 98.25 471374.65 723898.49 98.25 471374.65 723898.49 114.54 471374.05 723898.57 114.54 471374.05 723898.57 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471374.65 723898.49 98.25 471374.25 723895.53 98.25 471374.25 723895.53 114.54 471374.65 723898.49 114.54 471374.65 723898.49 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471374.25 723895.53 98.25 471378.42 723894.98 98.25 471378.42 723894.98 114.54 471374.25 723895.53 114.54 471374.25 723895.53 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471378.42 723894.98 98.25 471378.26 723893.8 98.25 471378.26 723893.8 114.54 471378.42 723894.98 114.54 471378.42 723894.98 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471378.26 723893.8 98.25 471384.56 723892.97 98.25 471384.56 723892.97 114.54 471378.26 723893.8 114.54 471378.26 723893.8 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.56 723892.97 98.25 471385.65 723901.29 98.25 471385.65 723901.29 114.54 471384.56 723892.97 114.54 471384.56 723892.97 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.65 723901.29 98.25 471387.24 723901.08 98.25 471387.24 723901.08 114.54 471385.65 723901.29 114.54 471385.65 723901.29 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.24 723901.08 98.25 471387.08 723899.89 98.25 471387.08 723899.89 114.54 471387.24 723901.08 114.54 471387.24 723901.08 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.08 723899.89 98.25 471390.75 723899.44 98.25 471390.75 723899.44 114.54 471387.08 723899.89 114.54 471387.08 723899.89 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.75 723899.44 98.25 471394.32 723926.28 98.25 471394.32 723926.28 114.54 471390.75 723899.44 114.54 471390.75 723899.44 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471394.32 723926.28 98.25 471393.7 723926.37 98.25 471393.7 723926.37 114.54 471394.32 723926.28 114.54 471394.32 723926.28 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.7 723926.37 98.25 471394.09 723929.34 98.25 471394.09 723929.34 114.54 471393.7 723926.37 114.54 471393.7 723926.37 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471394.09 723929.34 98.25 471384.95 723930.55 98.25 471384.95 723930.55 114.54 471394.09 723929.34 114.54 471394.09 723929.34 98.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F6-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.95 723930.55 114.54 471381.95 723908.01 114.54 471380.36 723908.16 114.54 471380.52 723909.34 114.54 471375.56 723910.02 114.54 471374.05 723898.57 114.54 471374.65 723898.49 114.54 471374.25 723895.53 114.54 471378.42 723894.98 114.54 471378.26 723893.8 114.54 471384.56 723892.97 114.54 471385.65 723901.29 114.54 471387.24 723901.08 114.54 471387.08 723899.89 114.54 471390.75 723899.44 114.54 471394.32 723926.28 114.54 471393.7 723926.37 114.54 471394.09 723929.34 114.54 471384.95 723930.55 114.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">13.42</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471374.59 723888.5 98.52 471383.64 723887.33 98.52 471383.25 723884.35 98.52 471383.85 723884.27 98.52 471380.39 723857.4 98.52 471375.42 723857.94 98.52 471375.55 723859.14 98.52 471373.96 723859.31 98.52 471372.91 723851.1 98.52 471367.96 723851.75 98.52 471368.12 723852.93 98.52 471363.96 723853.48 98.52 471364.34 723856.45 98.52 471363.75 723856.53 98.52 471365.28 723867.87 98.52 471370.22 723867.26 98.52 471370.08 723866.08 98.52 471371.65 723865.88 98.52 471374.59 723888.5 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471374.59 723888.5 98.52 471371.65 723865.88 98.52 471371.65 723865.88 111.94 471374.59 723888.5 111.94 471374.59 723888.5 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.65 723865.88 98.52 471370.08 723866.08 98.52 471370.08 723866.08 111.94 471371.65 723865.88 111.94 471371.65 723865.88 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.08 723866.08 98.52 471370.22 723867.26 98.52 471370.22 723867.26 111.94 471370.08 723866.08 111.94 471370.08 723866.08 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.22 723867.26 98.52 471365.28 723867.87 98.52 471365.28 723867.87 111.94 471370.22 723867.26 111.94 471370.22 723867.26 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471365.28 723867.87 98.52 471363.75 723856.53 98.52 471363.75 723856.53 111.94 471365.28 723867.87 111.94 471365.28 723867.87 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471363.75 723856.53 98.52 471364.34 723856.45 98.52 471364.34 723856.45 111.94 471363.75 723856.53 111.94 471363.75 723856.53 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.34 723856.45 98.52 471363.96 723853.48 98.52 471363.96 723853.48 111.94 471364.34 723856.45 111.94 471364.34 723856.45 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471363.96 723853.48 98.52 471368.12 723852.93 98.52 471368.12 723852.93 111.94 471363.96 723853.48 111.94 471363.96 723853.48 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.12 723852.93 98.52 471367.96 723851.75 98.52 471367.96 723851.75 111.94 471368.12 723852.93 111.94 471368.12 723852.93 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471367.96 723851.75 98.52 471372.91 723851.1 98.52 471372.91 723851.1 111.94 471367.96 723851.75 111.94 471367.96 723851.75 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471372.91 723851.1 98.52 471373.96 723859.31 98.52 471373.96 723859.31 111.94 471372.91 723851.1 111.94 471372.91 723851.1 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.96 723859.31 98.52 471375.55 723859.14 98.52 471375.55 723859.14 111.94 471373.96 723859.31 111.94 471373.96 723859.31 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.55 723859.14 98.52 471375.42 723857.94 98.52 471375.42 723857.94 111.94 471375.55 723859.14 111.94 471375.55 723859.14 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.42 723857.94 98.52 471380.39 723857.4 98.52 471380.39 723857.4 111.94 471375.42 723857.94 111.94 471375.42 723857.94 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.39 723857.4 98.52 471383.85 723884.27 98.52 471383.85 723884.27 111.94 471380.39 723857.4 111.94 471380.39 723857.4 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.85 723884.27 98.52 471383.25 723884.35 98.52 471383.25 723884.35 111.94 471383.85 723884.27 111.94 471383.85 723884.27 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.25 723884.35 98.52 471383.64 723887.33 98.52 471383.64 723887.33 111.94 471383.25 723884.35 111.94 471383.25 723884.35 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.64 723887.33 98.52 471374.59 723888.5 98.52 471374.59 723888.5 111.94 471383.64 723887.33 111.94 471383.64 723887.33 98.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F3-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471374.59 723888.5 111.94 471371.65 723865.88 111.94 471370.08 723866.08 111.94 471370.22 723867.26 111.94 471365.28 723867.87 111.94 471363.75 723856.53 111.94 471364.34 723856.45 111.94 471363.96 723853.48 111.94 471368.12 723852.93 111.94 471367.96 723851.75 111.94 471372.91 723851.1 111.94 471373.96 723859.31 111.94 471375.55 723859.14 111.94 471375.42 723857.94 111.94 471380.39 723857.4 111.94 471383.85 723884.27 111.94 471383.25 723884.35 111.94 471383.64 723887.33 111.94 471374.59 723888.5 111.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">15.92</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.86 723986.59 98.97 471389.81 723985.92 98.97 471388.69 723977.61 98.97 471390.28 723977.4 98.97 471390.43 723978.58 98.97 471395.38 723977.95 98.97 471393.92 723966.47 98.97 471393.32 723966.55 98.97 471392.96 723963.78 98.97 471393.55 723963.71 98.97 471392.46 723955.38 98.97 471394.05 723955.18 98.97 471394.2 723956.37 98.97 471399.16 723955.72 98.97 471397.66 723944.21 98.97 471397.06 723944.3 98.97 471396.68 723941.33 98.97 471392.52 723941.88 98.97 471392.36 723940.68 98.97 471387.42 723941.28 98.97 471388.44 723949.59 98.97 471386.87 723949.81 98.97 471386.7 723948.63 98.97 471381.75 723949.3 98.97 471383.2 723960.76 98.97 471383.8 723960.68 98.97 471384.16 723963.45 98.97 471383.56 723963.53 98.97 471384.64 723971.86 98.97 471383.1 723972.08 98.97 471382.94 723970.9 98.97 471377.96 723971.58 98.97 471379.49 723982.96 98.97 471380.09 723982.91 98.97 471380.42 723985.9 98.97 471384.7 723985.41 98.97 471384.86 723986.59 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.86 723986.59 98.97 471384.7 723985.41 98.97 471384.7 723985.41 114.89 471384.86 723986.59 114.89 471384.86 723986.59 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.7 723985.41 98.97 471380.42 723985.9 98.97 471380.42 723985.9 114.89 471384.7 723985.41 114.89 471384.7 723985.41 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.42 723985.9 98.97 471380.09 723982.91 98.97 471380.09 723982.91 114.89 471380.42 723985.9 114.89 471380.42 723985.9 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.09 723982.91 98.97 471379.49 723982.96 98.97 471379.49 723982.96 114.89 471380.09 723982.91 114.89 471380.09 723982.91 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.49 723982.96 98.97 471377.96 723971.58 98.97 471377.96 723971.58 114.89 471379.49 723982.96 114.89 471379.49 723982.96 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471377.96 723971.58 98.97 471382.94 723970.9 98.97 471382.94 723970.9 114.89 471377.96 723971.58 114.89 471377.96 723971.58 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471382.94 723970.9 98.97 471383.1 723972.08 98.97 471383.1 723972.08 114.89 471382.94 723970.9 114.89 471382.94 723970.9 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.1 723972.08 98.97 471384.64 723971.86 98.97 471384.64 723971.86 114.89 471383.1 723972.08 114.89 471383.1 723972.08 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.64 723971.86 98.97 471383.56 723963.53 98.97 471383.56 723963.53 114.89 471384.64 723971.86 114.89 471384.64 723971.86 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.56 723963.53 98.97 471384.16 723963.45 98.97 471384.16 723963.45 114.89 471383.56 723963.53 114.89 471383.56 723963.53 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.16 723963.45 98.97 471383.8 723960.68 98.97 471383.8 723960.68 114.89 471384.16 723963.45 114.89 471384.16 723963.45 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.8 723960.68 98.97 471383.2 723960.76 98.97 471383.2 723960.76 114.89 471383.8 723960.68 114.89 471383.8 723960.68 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.2 723960.76 98.97 471381.75 723949.3 98.97 471381.75 723949.3 114.89 471383.2 723960.76 114.89 471383.2 723960.76 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.75 723949.3 98.97 471386.7 723948.63 98.97 471386.7 723948.63 114.89 471381.75 723949.3 114.89 471381.75 723949.3 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471386.7 723948.63 98.97 471386.87 723949.81 98.97 471386.87 723949.81 114.89 471386.7 723948.63 114.89 471386.7 723948.63 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471386.87 723949.81 98.97 471388.44 723949.59 98.97 471388.44 723949.59 114.89 471386.87 723949.81 114.89 471386.87 723949.81 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471388.44 723949.59 98.97 471387.42 723941.28 98.97 471387.42 723941.28 114.89 471388.44 723949.59 114.89 471388.44 723949.59 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.42 723941.28 98.97 471392.36 723940.68 98.97 471392.36 723940.68 114.89 471387.42 723941.28 114.89 471387.42 723941.28 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471392.36 723940.68 98.97 471392.52 723941.88 98.97 471392.52 723941.88 114.89 471392.36 723940.68 114.89 471392.36 723940.68 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471392.52 723941.88 98.97 471396.68 723941.33 98.97 471396.68 723941.33 114.89 471392.52 723941.88 114.89 471392.52 723941.88 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.68 723941.33 98.97 471397.06 723944.3 98.97 471397.06 723944.3 114.89 471396.68 723941.33 114.89 471396.68 723941.33 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471397.06 723944.3 98.97 471397.66 723944.21 98.97 471397.66 723944.21 114.89 471397.06 723944.3 114.89 471397.06 723944.3 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471397.66 723944.21 98.97 471399.16 723955.72 98.97 471399.16 723955.72 114.89 471397.66 723944.21 114.89 471397.66 723944.21 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471399.16 723955.72 98.97 471394.2 723956.37 98.97 471394.2 723956.37 114.89 471399.16 723955.72 114.89 471399.16 723955.72 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471394.2 723956.37 98.97 471394.05 723955.18 98.97 471394.05 723955.18 114.89 471394.2 723956.37 114.89 471394.2 723956.37 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471394.05 723955.18 98.97 471392.46 723955.38 98.97 471392.46 723955.38 114.89 471394.05 723955.18 114.89 471394.05 723955.18 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471392.46 723955.38 98.97 471393.55 723963.71 98.97 471393.55 723963.71 114.89 471392.46 723955.38 114.89 471392.46 723955.38 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.55 723963.71 98.97 471392.96 723963.78 98.97 471392.96 723963.78 114.89 471393.55 723963.71 114.89 471393.55 723963.71 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471392.96 723963.78 98.97 471393.32 723966.55 98.97 471393.32 723966.55 114.89 471392.96 723963.78 114.89 471392.96 723963.78 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.32 723966.55 98.97 471393.92 723966.47 98.97 471393.92 723966.47 114.89 471393.32 723966.55 114.89 471393.32 723966.55 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.92 723966.47 98.97 471395.38 723977.95 98.97 471395.38 723977.95 114.89 471393.92 723966.47 114.89 471393.92 723966.47 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471395.38 723977.95 98.97 471390.43 723978.58 98.97 471390.43 723978.58 114.89 471395.38 723977.95 114.89 471395.38 723977.95 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.43 723978.58 98.97 471390.28 723977.4 98.97 471390.28 723977.4 114.89 471390.43 723978.58 114.89 471390.43 723978.58 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.28 723977.4 98.97 471388.69 723977.61 98.97 471388.69 723977.61 114.89 471390.28 723977.4 114.89 471390.28 723977.4 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471388.69 723977.61 98.97 471389.81 723985.92 98.97 471389.81 723985.92 114.89 471388.69 723977.61 114.89 471388.69 723977.61 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471389.81 723985.92 98.97 471384.86 723986.59 98.97 471384.86 723986.59 114.89 471389.81 723985.92 114.89 471389.81 723985.92 98.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-30F4-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.86 723986.59 114.89 471384.7 723985.41 114.89 471380.42 723985.9 114.89 471380.09 723982.91 114.89 471379.49 723982.96 114.89 471377.96 723971.58 114.89 471382.94 723970.9 114.89 471383.1 723972.08 114.89 471384.64 723971.86 114.89 471383.56 723963.53 114.89 471384.16 723963.45 114.89 471383.8 723960.68 114.89 471383.2 723960.76 114.89 471381.75 723949.3 114.89 471386.7 723948.63 114.89 471386.87 723949.81 114.89 471388.44 723949.59 114.89 471387.42 723941.28 114.89 471392.36 723940.68 114.89 471392.52 723941.88 114.89 471396.68 723941.33 114.89 471397.06 723944.3 114.89 471397.66 723944.21 114.89 471399.16 723955.72 114.89 471394.2 723956.37 114.89 471394.05 723955.18 114.89 471392.46 723955.38 114.89 471393.55 723963.71 114.89 471392.96 723963.78 114.89 471393.32 723966.55 114.89 471393.92 723966.47 114.89 471395.38 723977.95 114.89 471390.43 723978.58 114.89 471390.28 723977.4 114.89 471388.69 723977.61 114.89 471389.81 723985.92 114.89 471384.86 723986.59 114.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">26.67</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471334.83 723898.39 98.59 471344.44 723897.1 98.59 471342.04 723878.48 98.59 471337.09 723879.21 98.59 471337.26 723880.39 98.59 471335.68 723880.63 98.59 471334.57 723872.29 98.59 471332.08 723853.54 98.59 471327.13 723854.18 98.59 471327.28 723855.38 98.59 471325.69 723855.58 98.59 471324.7 723848.52 98.59 471315.09 723849.86 98.59 471317.51 723868.39 98.59 471322.46 723867.73 98.59 471322.3 723866.47 98.59 471323.87 723866.27 98.59 471324.85 723873.58 98.59 471327.44 723893.27 98.59 471332.44 723892.66 98.59 471332.29 723891.46 98.59 471333.88 723891.26 98.59 471334.83 723898.39 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471334.83 723898.39 98.59 471333.88 723891.26 98.59 471333.88 723891.26 125.26 471334.83 723898.39 125.26 471334.83 723898.39 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471333.88 723891.26 98.59 471332.29 723891.46 98.59 471332.29 723891.46 125.26 471333.88 723891.26 125.26 471333.88 723891.26 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471332.29 723891.46 98.59 471332.44 723892.66 98.59 471332.44 723892.66 125.26 471332.29 723891.46 125.26 471332.29 723891.46 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471332.44 723892.66 98.59 471327.44 723893.27 98.59 471327.44 723893.27 125.26 471332.44 723892.66 125.26 471332.44 723892.66 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.44 723893.27 98.59 471324.85 723873.58 98.59 471324.85 723873.58 125.26 471327.44 723893.27 125.26 471327.44 723893.27 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471324.85 723873.58 98.59 471323.87 723866.27 98.59 471323.87 723866.27 125.26 471324.85 723873.58 125.26 471324.85 723873.58 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471323.87 723866.27 98.59 471322.3 723866.47 98.59 471322.3 723866.47 125.26 471323.87 723866.27 125.26 471323.87 723866.27 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471322.3 723866.47 98.59 471322.46 723867.73 98.59 471322.46 723867.73 125.26 471322.3 723866.47 125.26 471322.3 723866.47 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471322.46 723867.73 98.59 471317.51 723868.39 98.59 471317.51 723868.39 125.26 471322.46 723867.73 125.26 471322.46 723867.73 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.51 723868.39 98.59 471315.09 723849.86 98.59 471315.09 723849.86 125.26 471317.51 723868.39 125.26 471317.51 723868.39 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471315.09 723849.86 98.59 471324.7 723848.52 98.59 471324.7 723848.52 125.26 471315.09 723849.86 125.26 471315.09 723849.86 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471324.7 723848.52 98.59 471325.69 723855.58 98.59 471325.69 723855.58 125.26 471324.7 723848.52 125.26 471324.7 723848.52 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471325.69 723855.58 98.59 471327.28 723855.38 98.59 471327.28 723855.38 125.26 471325.69 723855.58 125.26 471325.69 723855.58 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.28 723855.38 98.59 471327.13 723854.18 98.59 471327.13 723854.18 125.26 471327.28 723855.38 125.26 471327.28 723855.38 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.13 723854.18 98.59 471332.08 723853.54 98.59 471332.08 723853.54 125.26 471327.13 723854.18 125.26 471327.13 723854.18 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471332.08 723853.54 98.59 471334.57 723872.29 98.59 471334.57 723872.29 125.26 471332.08 723853.54 125.26 471332.08 723853.54 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471334.57 723872.29 98.59 471335.68 723880.63 98.59 471335.68 723880.63 125.26 471334.57 723872.29 125.26 471334.57 723872.29 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471335.68 723880.63 98.59 471337.26 723880.39 98.59 471337.26 723880.39 125.26 471335.68 723880.63 125.26 471335.68 723880.63 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.26 723880.39 98.59 471337.09 723879.21 98.59 471337.09 723879.21 125.26 471337.26 723880.39 125.26 471337.26 723880.39 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.09 723879.21 98.59 471342.04 723878.48 98.59 471342.04 723878.48 125.26 471337.09 723879.21 125.26 471337.09 723879.21 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.04 723878.48 98.59 471344.44 723897.1 98.59 471344.44 723897.1 125.26 471342.04 723878.48 125.26 471342.04 723878.48 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.44 723897.1 98.59 471334.83 723898.39 98.59 471334.83 723898.39 125.26 471344.44 723897.1 125.26 471344.44 723897.1 98.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2F91-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471334.83 723898.39 125.26 471333.88 723891.26 125.26 471332.29 723891.46 125.26 471332.44 723892.66 125.26 471327.44 723893.27 125.26 471324.85 723873.58 125.26 471323.87 723866.27 125.26 471322.3 723866.47 125.26 471322.46 723867.73 125.26 471317.51 723868.39 125.26 471315.09 723849.86 125.26 471324.7 723848.52 125.26 471325.69 723855.58 125.26 471327.28 723855.38 125.26 471327.13 723854.18 125.26 471332.08 723853.54 125.26 471334.57 723872.29 125.26 471335.68 723880.63 125.26 471337.26 723880.39 125.26 471337.09 723879.21 125.26 471342.04 723878.48 125.26 471344.44 723897.1 125.26 471334.83 723898.39 125.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.92 723778.32 60.67 471450.93 723777.88 60.67 471449.98 723777.85 60.67 471450.05 723775.5 60.67 471451 723775.54 60.67 471451.09 723771.74 60.67 471439.41 723771.28 60.67 471439.4 723771.57 60.67 471440.9 723771.61 60.67 471440.81 723774.57 60.67 471439.31 723774.52 60.67 471439.22 723777.88 60.67 471450.92 723778.32 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.92 723778.32 60.67 471439.22 723777.88 60.67 471439.22 723777.88 70.3 471450.92 723778.32 70.3 471450.92 723778.32 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.22 723777.88 60.67 471439.31 723774.52 60.67 471439.31 723774.52 70.3 471439.22 723777.88 70.3 471439.22 723777.88 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.31 723774.52 60.67 471440.81 723774.57 60.67 471440.81 723774.57 70.3 471439.31 723774.52 70.3 471439.31 723774.52 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471440.81 723774.57 60.67 471440.9 723771.61 60.67 471440.9 723771.61 70.3 471440.81 723774.57 70.3 471440.81 723774.57 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471440.9 723771.61 60.67 471439.4 723771.57 60.67 471439.4 723771.57 70.3 471440.9 723771.61 70.3 471440.9 723771.61 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.4 723771.57 60.67 471439.41 723771.28 60.67 471439.41 723771.28 70.3 471439.4 723771.57 70.3 471439.4 723771.57 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.41 723771.28 60.67 471451.09 723771.74 60.67 471451.09 723771.74 70.3 471439.41 723771.28 70.3 471439.41 723771.28 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471451.09 723771.74 60.67 471451 723775.54 60.67 471451 723775.54 70.3 471451.09 723771.74 70.3 471451.09 723771.74 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471451 723775.54 60.67 471450.05 723775.5 60.67 471450.05 723775.5 70.3 471451 723775.54 70.3 471451 723775.54 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.05 723775.5 60.67 471449.98 723777.85 60.67 471449.98 723777.85 70.3 471450.05 723775.5 70.3 471450.05 723775.5 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.98 723777.85 60.67 471450.93 723777.88 60.67 471450.93 723777.88 70.3 471449.98 723777.85 70.3 471449.98 723777.85 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.93 723777.88 60.67 471450.92 723778.32 60.67 471450.92 723778.32 70.3 471450.93 723777.88 70.3 471450.93 723777.88 60.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F27A-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.92 723778.32 70.3 471439.22 723777.88 70.3 471439.31 723774.52 70.3 471440.81 723774.57 70.3 471440.9 723771.61 70.3 471439.4 723771.57 70.3 471439.41 723771.28 70.3 471451.09 723771.74 70.3 471451 723775.54 70.3 471450.05 723775.5 70.3 471449.98 723777.85 70.3 471450.93 723777.88 70.3 471450.92 723778.32 70.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F279-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.4</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.73 723784.91 62.51 471450.74 723784.41 62.51 471449.79 723784.4 62.51 471449.86 723782.1 62.51 471450.81 723782.12 62.51 471450.92 723778.32 62.51 471439.22 723777.88 62.51 471439.2 723778.17 62.51 471440.7 723778.21 62.51 471440.61 723781.17 62.51 471439.11 723781.12 62.51 471439.02 723784.48 62.51 471450.73 723784.91 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.73 723784.91 62.51 471439.02 723784.48 62.51 471439.02 723784.48 71.91 471450.73 723784.91 71.91 471450.73 723784.91 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.02 723784.48 62.51 471439.11 723781.12 62.51 471439.11 723781.12 71.91 471439.02 723784.48 71.91 471439.02 723784.48 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.11 723781.12 62.51 471440.61 723781.17 62.51 471440.61 723781.17 71.91 471439.11 723781.12 71.91 471439.11 723781.12 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471440.61 723781.17 62.51 471440.7 723778.21 62.51 471440.7 723778.21 71.91 471440.61 723781.17 71.91 471440.61 723781.17 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471440.7 723778.21 62.51 471439.2 723778.17 62.51 471439.2 723778.17 71.91 471440.7 723778.21 71.91 471440.7 723778.21 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.2 723778.17 62.51 471439.22 723777.88 62.51 471439.22 723777.88 71.91 471439.2 723778.17 71.91 471439.2 723778.17 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.22 723777.88 62.51 471450.92 723778.32 62.51 471450.92 723778.32 71.91 471439.22 723777.88 71.91 471439.22 723777.88 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.92 723778.32 62.51 471450.81 723782.12 62.51 471450.81 723782.12 71.91 471450.92 723778.32 71.91 471450.92 723778.32 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.81 723782.12 62.51 471449.86 723782.1 62.51 471449.86 723782.1 71.91 471450.81 723782.12 71.91 471450.81 723782.12 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.86 723782.1 62.51 471449.79 723784.4 62.51 471449.79 723784.4 71.91 471449.86 723782.1 71.91 471449.86 723782.1 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.79 723784.4 62.51 471450.74 723784.41 62.51 471450.74 723784.41 71.91 471449.79 723784.4 71.91 471449.79 723784.4 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.74 723784.41 62.51 471450.73 723784.91 62.51 471450.73 723784.91 71.91 471450.74 723784.41 71.91 471450.74 723784.41 62.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F279-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.73 723784.91 71.91 471439.02 723784.48 71.91 471439.11 723781.12 71.91 471440.61 723781.17 71.91 471440.7 723778.21 71.91 471439.2 723778.17 71.91 471439.22 723777.88 71.91 471450.92 723778.32 71.91 471450.81 723782.12 71.91 471449.86 723782.1 71.91 471449.79 723784.4 71.91 471450.74 723784.41 71.91 471450.73 723784.91 71.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F400-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.01</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.97 723790.74 63.96 471423.98 723790.3 63.96 471423.08 723790.28 63.96 471423.12 723787.73 63.96 471424.02 723787.75 63.96 471424.06 723784.13 63.96 471412.3 723783.66 63.96 471412.3 723784.08 63.96 471413.8 723784.1 63.96 471413.76 723787.05 63.96 471412.26 723787.02 63.96 471412.22 723790.25 63.96 471423.97 723790.74 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.97 723790.74 63.96 471412.22 723790.25 63.96 471412.22 723790.25 72.97 471423.97 723790.74 72.97 471423.97 723790.74 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.22 723790.25 63.96 471412.26 723787.02 63.96 471412.26 723787.02 72.97 471412.22 723790.25 72.97 471412.22 723790.25 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.26 723787.02 63.96 471413.76 723787.05 63.96 471413.76 723787.05 72.97 471412.26 723787.02 72.97 471412.26 723787.02 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.76 723787.05 63.96 471413.8 723784.1 63.96 471413.8 723784.1 72.97 471413.76 723787.05 72.97 471413.76 723787.05 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.8 723784.1 63.96 471412.3 723784.08 63.96 471412.3 723784.08 72.97 471413.8 723784.1 72.97 471413.8 723784.1 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.3 723784.08 63.96 471412.3 723783.66 63.96 471412.3 723783.66 72.97 471412.3 723784.08 72.97 471412.3 723784.08 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.3 723783.66 63.96 471424.06 723784.13 63.96 471424.06 723784.13 72.97 471412.3 723783.66 72.97 471412.3 723783.66 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.06 723784.13 63.96 471424.02 723787.75 63.96 471424.02 723787.75 72.97 471424.06 723784.13 72.97 471424.06 723784.13 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.02 723787.75 63.96 471423.12 723787.73 63.96 471423.12 723787.73 72.97 471424.02 723787.75 72.97 471424.02 723787.75 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.12 723787.73 63.96 471423.08 723790.28 63.96 471423.08 723790.28 72.97 471423.12 723787.73 72.97 471423.12 723787.73 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.08 723790.28 63.96 471423.98 723790.3 63.96 471423.98 723790.3 72.97 471423.08 723790.28 72.97 471423.08 723790.28 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.98 723790.3 63.96 471423.97 723790.74 63.96 471423.97 723790.74 72.97 471423.98 723790.3 72.97 471423.98 723790.3 63.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F400-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.97 723790.74 72.97 471412.22 723790.25 72.97 471412.26 723787.02 72.97 471413.76 723787.05 72.97 471413.8 723784.1 72.97 471412.3 723784.08 72.97 471412.3 723783.66 72.97 471424.06 723784.13 72.97 471424.02 723787.75 72.97 471423.12 723787.73 72.97 471423.08 723790.28 72.97 471423.98 723790.3 72.97 471423.97 723790.74 72.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.16 723777.54 61.16 471424.16 723777.17 61.16 471423.27 723777.16 61.16 471423.3 723774.87 61.16 471424.19 723774.87 61.16 471424.26 723770.94 61.16 471412.48 723770.49 61.16 471412.47 723770.93 61.16 471413.97 723770.94 61.16 471413.93 723773.9 61.16 471412.44 723773.88 61.16 471412.39 723777.07 61.16 471424.16 723777.54 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.16 723777.54 61.16 471412.39 723777.07 61.16 471412.39 723777.07 70.10000000000001 471424.16 723777.54 70.10000000000001 471424.16 723777.54 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.39 723777.07 61.16 471412.44 723773.88 61.16 471412.44 723773.88 70.10000000000001 471412.39 723777.07 70.10000000000001 471412.39 723777.07 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.44 723773.88 61.16 471413.93 723773.9 61.16 471413.93 723773.9 70.10000000000001 471412.44 723773.88 70.10000000000001 471412.44 723773.88 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.93 723773.9 61.16 471413.97 723770.94 61.16 471413.97 723770.94 70.10000000000001 471413.93 723773.9 70.10000000000001 471413.93 723773.9 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.97 723770.94 61.16 471412.47 723770.93 61.16 471412.47 723770.93 70.10000000000001 471413.97 723770.94 70.10000000000001 471413.97 723770.94 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.47 723770.93 61.16 471412.48 723770.49 61.16 471412.48 723770.49 70.10000000000001 471412.47 723770.93 70.10000000000001 471412.47 723770.93 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.48 723770.49 61.16 471424.26 723770.94 61.16 471424.26 723770.94 70.10000000000001 471412.48 723770.49 70.10000000000001 471412.48 723770.49 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.26 723770.94 61.16 471424.19 723774.87 61.16 471424.19 723774.87 70.10000000000001 471424.26 723770.94 70.10000000000001 471424.26 723770.94 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.19 723774.87 61.16 471423.3 723774.87 61.16 471423.3 723774.87 70.10000000000001 471424.19 723774.87 70.10000000000001 471424.19 723774.87 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.3 723774.87 61.16 471423.27 723777.16 61.16 471423.27 723777.16 70.10000000000001 471423.3 723774.87 70.10000000000001 471423.3 723774.87 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.27 723777.16 61.16 471424.16 723777.17 61.16 471424.16 723777.17 70.10000000000001 471423.27 723777.16 70.10000000000001 471423.27 723777.16 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.16 723777.17 61.16 471424.16 723777.54 61.16 471424.16 723777.54 70.10000000000001 471424.16 723777.17 70.10000000000001 471424.16 723777.17 61.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA40-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.16 723777.54 70.10000000000001 471412.39 723777.07 70.10000000000001 471412.44 723773.88 70.10000000000001 471413.93 723773.9 70.10000000000001 471413.97 723770.94 70.10000000000001 471412.47 723770.93 70.10000000000001 471412.48 723770.49 70.10000000000001 471424.26 723770.94 70.10000000000001 471424.19 723774.87 70.10000000000001 471423.3 723774.87 70.10000000000001 471423.27 723777.16 70.10000000000001 471424.16 723777.17 70.10000000000001 471424.16 723777.54 70.10000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.09</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.8 723818.4 73.68 471449.81 723818.01 73.68 471448.86 723817.98 73.68 471448.93 723815.33 73.68 471449.88 723815.35 73.68 471450.01 723811.25 73.68 471449.06 723811.22 73.68 471438.26 723810.86 73.68 471438.24 723811.23 73.68 471439.74 723811.27 73.68 471439.66 723814.22 73.68 471438.15 723814.18 73.68 471438.05 723818.04 73.68 471449.8 723818.4 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.8 723818.4 73.68 471438.05 723818.04 73.68 471438.05 723818.04 83.77 471449.8 723818.4 83.77 471449.8 723818.4 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.05 723818.04 73.68 471438.15 723814.18 73.68 471438.15 723814.18 83.77 471438.05 723818.04 83.77 471438.05 723818.04 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.15 723814.18 73.68 471439.66 723814.22 73.68 471439.66 723814.22 83.77 471438.15 723814.18 83.77 471438.15 723814.18 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.66 723814.22 73.68 471439.74 723811.27 73.68 471439.74 723811.27 83.77 471439.66 723814.22 83.77 471439.66 723814.22 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.74 723811.27 73.68 471438.24 723811.23 73.68 471438.24 723811.23 83.77 471439.74 723811.27 83.77 471439.74 723811.27 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.24 723811.23 73.68 471438.26 723810.86 73.68 471438.26 723810.86 83.77 471438.24 723811.23 83.77 471438.24 723811.23 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.26 723810.86 73.68 471449.06 723811.22 73.68 471449.06 723811.22 83.77 471438.26 723810.86 83.77 471438.26 723810.86 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.06 723811.22 73.68 471450.01 723811.25 73.68 471450.01 723811.25 83.77 471449.06 723811.22 83.77 471449.06 723811.22 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.01 723811.25 73.68 471449.88 723815.35 73.68 471449.88 723815.35 83.77 471450.01 723811.25 83.77 471450.01 723811.25 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.88 723815.35 73.68 471448.93 723815.33 73.68 471448.93 723815.33 83.77 471449.88 723815.35 83.77 471449.88 723815.35 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471448.93 723815.33 73.68 471448.86 723817.98 73.68 471448.86 723817.98 83.77 471448.93 723815.33 83.77 471448.93 723815.33 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471448.86 723817.98 73.68 471449.81 723818.01 73.68 471449.81 723818.01 83.77 471448.86 723817.98 83.77 471448.86 723817.98 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.81 723818.01 73.68 471449.8 723818.4 73.68 471449.8 723818.4 83.77 471449.81 723818.01 83.77 471449.81 723818.01 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B8-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.8 723818.4 83.77 471438.05 723818.04 83.77 471438.15 723814.18 83.77 471439.66 723814.22 83.77 471439.74 723811.27 83.77 471438.24 723811.23 83.77 471438.26 723810.86 83.77 471449.06 723811.22 83.77 471450.01 723811.25 83.77 471449.88 723815.35 83.77 471448.93 723815.33 83.77 471448.86 723817.98 83.77 471449.81 723818.01 83.77 471449.8 723818.4 83.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.54 723791.49 64.39 471450.55 723791.29 64.39 471449.6 723791.27 64.39 471449.67 723788.69 64.39 471450.62 723788.72 64.39 471450.73 723784.91 64.39 471439.02 723784.48 64.39 471439.01 723784.8 64.39 471440.52 723784.84 64.39 471440.43 723787.79 64.39 471438.93 723787.74 64.39 471438.82 723791.07 64.39 471450.54 723791.49 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.54 723791.49 64.39 471438.82 723791.07 64.39 471438.82 723791.07 73.68 471450.54 723791.49 73.68 471450.54 723791.49 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.82 723791.07 64.39 471438.93 723787.74 64.39 471438.93 723787.74 73.68 471438.82 723791.07 73.68 471438.82 723791.07 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.93 723787.74 64.39 471440.43 723787.79 64.39 471440.43 723787.79 73.68 471438.93 723787.74 73.68 471438.93 723787.74 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471440.43 723787.79 64.39 471440.52 723784.84 64.39 471440.52 723784.84 73.68 471440.43 723787.79 73.68 471440.43 723787.79 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471440.52 723784.84 64.39 471439.01 723784.8 64.39 471439.01 723784.8 73.68 471440.52 723784.84 73.68 471440.52 723784.84 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.01 723784.8 64.39 471439.02 723784.48 64.39 471439.02 723784.48 73.68 471439.01 723784.8 73.68 471439.01 723784.8 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.02 723784.48 64.39 471450.73 723784.91 64.39 471450.73 723784.91 73.68 471439.02 723784.48 73.68 471439.02 723784.48 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.73 723784.91 64.39 471450.62 723788.72 64.39 471450.62 723788.72 73.68 471450.73 723784.91 73.68 471450.73 723784.91 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.62 723788.72 64.39 471449.67 723788.69 64.39 471449.67 723788.69 73.68 471450.62 723788.72 73.68 471450.62 723788.72 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.67 723788.69 64.39 471449.6 723791.27 64.39 471449.6 723791.27 73.68 471449.67 723788.69 73.68 471449.67 723788.69 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.6 723791.27 64.39 471450.55 723791.29 64.39 471450.55 723791.29 73.68 471449.6 723791.27 73.68 471449.6 723791.27 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.55 723791.29 64.39 471450.54 723791.49 64.39 471450.54 723791.49 73.68 471450.55 723791.29 73.68 471450.55 723791.29 64.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B6-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.54 723791.49 73.68 471438.82 723791.07 73.68 471438.93 723787.74 73.68 471440.43 723787.79 73.68 471440.52 723784.84 73.68 471439.01 723784.8 73.68 471439.02 723784.48 73.68 471450.73 723784.91 73.68 471450.62 723788.72 73.68 471449.67 723788.69 73.68 471449.6 723791.27 73.68 471450.55 723791.29 73.68 471450.54 723791.49 73.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.65</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.06 723811.22 71.64 471449.11 723808.76 71.64 471450.06 723808.79 71.64 471450.17 723804.67 71.64 471449.23 723804.63 71.64 471438.45 723804.26 71.64 471438.44 723804.65 71.64 471439.93 723804.7 71.64 471439.84 723807.65 71.64 471438.35 723807.6 71.64 471438.26 723810.86 71.64 471449.06 723811.22 71.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.06 723811.22 71.64 471438.26 723810.86 71.64 471438.26 723810.86 81.29 471449.06 723811.22 81.29 471449.06 723811.22 71.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.26 723810.86 71.64 471438.35 723807.6 71.64 471438.35 723807.6 81.29 471438.26 723810.86 81.29 471438.26 723810.86 71.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.35 723807.6 71.64 471439.84 723807.65 71.64 471439.84 723807.65 81.29 471438.35 723807.6 81.29 471438.35 723807.6 71.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.84 723807.65 71.64 471439.93 723804.7 71.64 471439.93 723804.7 81.29 471439.84 723807.65 81.29 471439.84 723807.65 71.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.93 723804.7 71.64 471438.44 723804.65 71.64 471438.44 723804.65 81.29 471439.93 723804.7 81.29 471439.93 723804.7 71.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.44 723804.65 71.64 471438.45 723804.26 71.64 471438.45 723804.26 81.29 471438.44 723804.65 81.29 471438.44 723804.65 71.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.45 723804.26 71.64 471449.23 723804.63 71.64 471449.23 723804.63 81.29 471438.45 723804.26 81.29 471438.45 723804.26 71.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.23 723804.63 71.64 471450.17 723804.67 71.64 471450.17 723804.67 81.29 471449.23 723804.63 81.29 471449.23 723804.63 71.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.17 723804.67 71.64 471450.06 723808.79 71.64 471450.06 723808.79 81.29 471450.17 723804.67 81.29 471450.17 723804.67 71.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.06 723808.79 71.64 471449.11 723808.76 71.64 471449.11 723808.76 81.29 471450.06 723808.79 81.29 471450.06 723808.79 71.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.11 723808.76 71.64 471449.06 723811.22 71.64 471449.06 723811.22 81.29 471449.11 723808.76 81.29 471449.11 723808.76 71.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1B7-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.06 723811.22 81.29 471438.26 723810.86 81.29 471438.35 723807.6 81.29 471439.84 723807.65 81.29 471439.93 723804.7 81.29 471438.44 723804.65 81.29 471438.45 723804.26 81.29 471449.23 723804.63 81.29 471450.17 723804.67 81.29 471450.06 723808.79 81.29 471449.11 723808.76 81.29 471449.06 723811.22 81.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.93</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.26 723770.94 60.58 471424.26 723770.58 60.58 471423.36 723770.56 60.58 471423.4 723768.21 60.58 471424.3 723768.23 60.58 471424.36 723763.93 60.58 471414.05 723763.6 60.58 471414 723767.26 60.58 471412.5 723767.25 60.58 471412.48 723770.49 60.58 471424.26 723770.94 60.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.26 723770.94 60.58 471412.48 723770.49 60.58 471412.48 723770.49 68.51 471424.26 723770.94 68.51 471424.26 723770.94 60.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.48 723770.49 60.58 471412.5 723767.25 60.58 471412.5 723767.25 68.51 471412.48 723770.49 68.51 471412.48 723770.49 60.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.5 723767.25 60.58 471414 723767.26 60.58 471414 723767.26 68.51 471412.5 723767.25 68.51 471412.5 723767.25 60.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471414 723767.26 60.58 471414.05 723763.6 60.58 471414.05 723763.6 68.51 471414 723767.26 68.51 471414 723767.26 60.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471414.05 723763.6 60.58 471424.36 723763.93 60.58 471424.36 723763.93 68.51 471414.05 723763.6 68.51 471414.05 723763.6 60.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.36 723763.93 60.58 471424.3 723768.23 60.58 471424.3 723768.23 68.51 471424.36 723763.93 68.51 471424.36 723763.93 60.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.3 723768.23 60.58 471423.4 723768.21 60.58 471423.4 723768.21 68.51 471424.3 723768.23 68.51 471424.3 723768.23 60.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.4 723768.21 60.58 471423.36 723770.56 60.58 471423.36 723770.56 68.51 471423.4 723768.21 68.51 471423.4 723768.21 60.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.36 723770.56 60.58 471424.26 723770.58 60.58 471424.26 723770.58 68.51 471423.36 723770.56 68.51 471423.36 723770.56 60.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.26 723770.58 60.58 471424.26 723770.94 60.58 471424.26 723770.94 68.51 471424.26 723770.58 68.51 471424.26 723770.58 60.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA42-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.26 723770.94 68.51 471412.48 723770.49 68.51 471412.5 723767.25 68.51 471414 723767.26 68.51 471414.05 723763.6 68.51 471424.36 723763.93 68.51 471424.3 723768.23 68.51 471423.4 723768.21 68.51 471423.36 723770.56 68.51 471424.26 723770.58 68.51 471424.26 723770.94 68.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.36</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.88 723797.34 65.58 471423.89 723796.99 65.58 471422.99 723796.99 65.58 471423.02 723794.63 65.58 471423.92 723794.65 65.58 471423.97 723790.74 65.58 471412.22 723790.25 65.58 471412.21 723790.65 65.58 471413.71 723790.67 65.58 471413.67 723793.63 65.58 471412.17 723793.62 65.58 471412.14 723796.84 65.58 471423.88 723797.34 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.88 723797.34 65.58 471412.14 723796.84 65.58 471412.14 723796.84 74.94 471423.88 723797.34 74.94 471423.88 723797.34 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.14 723796.84 65.58 471412.17 723793.62 65.58 471412.17 723793.62 74.94 471412.14 723796.84 74.94 471412.14 723796.84 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.17 723793.62 65.58 471413.67 723793.63 65.58 471413.67 723793.63 74.94 471412.17 723793.62 74.94 471412.17 723793.62 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.67 723793.63 65.58 471413.71 723790.67 65.58 471413.71 723790.67 74.94 471413.67 723793.63 74.94 471413.67 723793.63 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.71 723790.67 65.58 471412.21 723790.65 65.58 471412.21 723790.65 74.94 471413.71 723790.67 74.94 471413.71 723790.67 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.21 723790.65 65.58 471412.22 723790.25 65.58 471412.22 723790.25 74.94 471412.21 723790.65 74.94 471412.21 723790.65 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.22 723790.25 65.58 471423.97 723790.74 65.58 471423.97 723790.74 74.94 471412.22 723790.25 74.94 471412.22 723790.25 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.97 723790.74 65.58 471423.92 723794.65 65.58 471423.92 723794.65 74.94 471423.97 723790.74 74.94 471423.97 723790.74 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.92 723794.65 65.58 471423.02 723794.63 65.58 471423.02 723794.63 74.94 471423.92 723794.65 74.94 471423.92 723794.65 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.02 723794.63 65.58 471422.99 723796.99 65.58 471422.99 723796.99 74.94 471423.02 723794.63 74.94 471423.02 723794.63 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.99 723796.99 65.58 471423.89 723796.99 65.58 471423.89 723796.99 74.94 471422.99 723796.99 74.94 471422.99 723796.99 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.89 723796.99 65.58 471423.88 723797.34 65.58 471423.88 723797.34 74.94 471423.89 723796.99 74.94 471423.89 723796.99 65.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA39-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.88 723797.34 74.94 471412.14 723796.84 74.94 471412.17 723793.62 74.94 471413.67 723793.63 74.94 471413.71 723790.67 74.94 471412.21 723790.65 74.94 471412.22 723790.25 74.94 471423.97 723790.74 74.94 471423.92 723794.65 74.94 471423.02 723794.63 74.94 471422.99 723796.99 74.94 471423.89 723796.99 74.94 471423.88 723797.34 74.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.46</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.79 723803.96 67.11 471423.79 723803.65 67.11 471422.89 723803.63 67.11 471422.93 723801.33 67.11 471423.82 723801.34 67.11 471423.88 723797.34 67.11 471412.14 723796.84 67.11 471412.13 723797.27 67.11 471413.63 723797.28 67.11 471413.59 723800.22 67.11 471412.09 723800.2 67.11 471412.04 723803.43 67.11 471423.79 723803.96 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.79 723803.96 67.11 471412.04 723803.43 67.11 471412.04 723803.43 76.57000000000001 471423.79 723803.96 76.57000000000001 471423.79 723803.96 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.04 723803.43 67.11 471412.09 723800.2 67.11 471412.09 723800.2 76.57000000000001 471412.04 723803.43 76.57000000000001 471412.04 723803.43 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.09 723800.2 67.11 471413.59 723800.22 67.11 471413.59 723800.22 76.57000000000001 471412.09 723800.2 76.57000000000001 471412.09 723800.2 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.59 723800.22 67.11 471413.63 723797.28 67.11 471413.63 723797.28 76.57000000000001 471413.59 723800.22 76.57000000000001 471413.59 723800.22 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.63 723797.28 67.11 471412.13 723797.27 67.11 471412.13 723797.27 76.57000000000001 471413.63 723797.28 76.57000000000001 471413.63 723797.28 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.13 723797.27 67.11 471412.14 723796.84 67.11 471412.14 723796.84 76.57000000000001 471412.13 723797.27 76.57000000000001 471412.13 723797.27 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.14 723796.84 67.11 471423.88 723797.34 67.11 471423.88 723797.34 76.57000000000001 471412.14 723796.84 76.57000000000001 471412.14 723796.84 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.88 723797.34 67.11 471423.82 723801.34 67.11 471423.82 723801.34 76.57000000000001 471423.88 723797.34 76.57000000000001 471423.88 723797.34 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.82 723801.34 67.11 471422.93 723801.33 67.11 471422.93 723801.33 76.57000000000001 471423.82 723801.34 76.57000000000001 471423.82 723801.34 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.93 723801.33 67.11 471422.89 723803.63 67.11 471422.89 723803.63 76.57000000000001 471422.93 723801.33 76.57000000000001 471422.93 723801.33 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.89 723803.63 67.11 471423.79 723803.65 67.11 471423.79 723803.65 76.57000000000001 471422.89 723803.63 76.57000000000001 471422.89 723803.63 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.79 723803.65 67.11 471423.79 723803.96 67.11 471423.79 723803.96 76.57000000000001 471423.79 723803.65 76.57000000000001 471423.79 723803.65 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA38-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.79 723803.96 76.57000000000001 471412.04 723803.43 76.57000000000001 471412.09 723800.2 76.57000000000001 471413.59 723800.22 76.57000000000001 471413.63 723797.28 76.57000000000001 471412.13 723797.27 76.57000000000001 471412.14 723796.84 76.57000000000001 471423.88 723797.34 76.57000000000001 471423.82 723801.34 76.57000000000001 471422.93 723801.33 76.57000000000001 471422.89 723803.63 76.57000000000001 471423.79 723803.65 76.57000000000001 471423.79 723803.96 76.57000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F978-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.91</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.5 723824.17 73.1 471423.51 723823.72 73.1 471422.61 723823.71 73.1 471422.65 723821.16 73.1 471423.55 723821.17 73.1 471423.6 723817.15 73.1 471411.87 723816.6 73.1 471411.87 723817.03 73.1 471413.37 723817.04 73.1 471413.33 723820 73.1 471411.83 723819.98 73.1 471411.77 723823.84 73.1 471423.5 723824.17 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.5 723824.17 73.1 471411.77 723823.84 73.1 471411.77 723823.84 82.01 471423.5 723824.17 82.01 471423.5 723824.17 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.77 723823.84 73.1 471411.83 723819.98 73.1 471411.83 723819.98 82.01 471411.77 723823.84 82.01 471411.77 723823.84 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.83 723819.98 73.1 471413.33 723820 73.1 471413.33 723820 82.01 471411.83 723819.98 82.01 471411.83 723819.98 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.33 723820 73.1 471413.37 723817.04 73.1 471413.37 723817.04 82.01 471413.33 723820 82.01 471413.33 723820 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.37 723817.04 73.1 471411.87 723817.03 73.1 471411.87 723817.03 82.01 471413.37 723817.04 82.01 471413.37 723817.04 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.87 723817.03 73.1 471411.87 723816.6 73.1 471411.87 723816.6 82.01 471411.87 723817.03 82.01 471411.87 723817.03 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.87 723816.6 73.1 471423.6 723817.15 73.1 471423.6 723817.15 82.01 471411.87 723816.6 82.01 471411.87 723816.6 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.6 723817.15 73.1 471423.55 723821.17 73.1 471423.55 723821.17 82.01 471423.6 723817.15 82.01 471423.6 723817.15 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.55 723821.17 73.1 471422.65 723821.16 73.1 471422.65 723821.16 82.01 471423.55 723821.17 82.01 471423.55 723821.17 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.65 723821.16 73.1 471422.61 723823.71 73.1 471422.61 723823.71 82.01 471422.65 723821.16 82.01 471422.65 723821.16 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.61 723823.71 73.1 471423.51 723823.72 73.1 471423.51 723823.72 82.01 471422.61 723823.71 82.01 471422.61 723823.71 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.51 723823.72 73.1 471423.5 723824.17 73.1 471423.5 723824.17 82.01 471423.51 723823.72 82.01 471423.51 723823.72 73.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F978-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.5 723824.17 82.01 471411.77 723823.84 82.01 471411.83 723819.98 82.01 471413.33 723820 82.01 471413.37 723817.04 82.01 471411.87 723817.03 82.01 471411.87 723816.6 82.01 471423.6 723817.15 82.01 471423.55 723821.17 82.01 471422.65 723821.16 82.01 471422.61 723823.71 82.01 471423.51 723823.72 82.01 471423.5 723824.17 82.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F594-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.86 723778.97 61.49 471476.87 723778.68 61.49 471475.92 723778.65 61.49 471475.98 723776.3 61.49 471476.94 723776.33 61.49 471477.03 723772.41 61.49 471465.37 723772.02 61.49 471465.36 723772.34 61.49 471466.86 723772.38 61.49 471466.77 723775.36 61.49 471465.28 723775.31 61.49 471465.16 723778.59 61.49 471476.86 723778.97 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.86 723778.97 61.49 471465.16 723778.59 61.49 471465.16 723778.59 69.92 471476.86 723778.97 69.92 471476.86 723778.97 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.16 723778.59 61.49 471465.28 723775.31 61.49 471465.28 723775.31 69.92 471465.16 723778.59 69.92 471465.16 723778.59 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.28 723775.31 61.49 471466.77 723775.36 61.49 471466.77 723775.36 69.92 471465.28 723775.31 69.92 471465.28 723775.31 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471466.77 723775.36 61.49 471466.86 723772.38 61.49 471466.86 723772.38 69.92 471466.77 723775.36 69.92 471466.77 723775.36 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471466.86 723772.38 61.49 471465.36 723772.34 61.49 471465.36 723772.34 69.92 471466.86 723772.38 69.92 471466.86 723772.38 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.36 723772.34 61.49 471465.37 723772.02 61.49 471465.37 723772.02 69.92 471465.36 723772.34 69.92 471465.36 723772.34 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.37 723772.02 61.49 471477.03 723772.41 61.49 471477.03 723772.41 69.92 471465.37 723772.02 69.92 471465.37 723772.02 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471477.03 723772.41 61.49 471476.94 723776.33 61.49 471476.94 723776.33 69.92 471477.03 723772.41 69.92 471477.03 723772.41 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.94 723776.33 61.49 471475.98 723776.3 61.49 471475.98 723776.3 69.92 471476.94 723776.33 69.92 471476.94 723776.33 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.98 723776.3 61.49 471475.92 723778.65 61.49 471475.92 723778.65 69.92 471475.98 723776.3 69.92 471475.98 723776.3 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.92 723778.65 61.49 471476.87 723778.68 61.49 471476.87 723778.68 69.92 471475.92 723778.65 69.92 471475.92 723778.65 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.87 723778.68 61.49 471476.86 723778.97 61.49 471476.86 723778.97 69.92 471476.87 723778.68 69.92 471476.87 723778.68 61.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F594-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.86 723778.97 69.92 471465.16 723778.59 69.92 471465.28 723775.31 69.92 471466.77 723775.36 69.92 471466.86 723772.38 69.92 471465.36 723772.34 69.92 471465.37 723772.02 69.92 471477.03 723772.41 69.92 471476.94 723776.33 69.92 471475.98 723776.3 69.92 471475.92 723778.65 69.92 471476.87 723778.68 69.92 471476.86 723778.97 69.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F333-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">11.98</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.05 723768.83 61.98 471355.16 723764.92 61.98 471354.26 723764.9 61.98 471354.31 723762.35 61.98 471355.21 723762.37 61.98 471355.22 723761.92 61.98 471352.61 723761.84 61.98 471344.98 723761.61 61.98 471344.9 723764.59 61.98 471343.4 723764.55 61.98 471343.31 723768.14 61.98 471344.81 723768.18 61.98 471344.8 723768.42 61.98 471355.05 723768.83 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.05 723768.83 61.98 471344.8 723768.42 61.98 471344.8 723768.42 73.96000000000001 471355.05 723768.83 73.96000000000001 471355.05 723768.83 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.8 723768.42 61.98 471344.81 723768.18 61.98 471344.81 723768.18 73.96000000000001 471344.8 723768.42 73.96000000000001 471344.8 723768.42 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.81 723768.18 61.98 471343.31 723768.14 61.98 471343.31 723768.14 73.96000000000001 471344.81 723768.18 73.96000000000001 471344.81 723768.18 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471343.31 723768.14 61.98 471343.4 723764.55 61.98 471343.4 723764.55 73.96000000000001 471343.31 723768.14 73.96000000000001 471343.31 723768.14 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471343.4 723764.55 61.98 471344.9 723764.59 61.98 471344.9 723764.59 73.96000000000001 471343.4 723764.55 73.96000000000001 471343.4 723764.55 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.9 723764.59 61.98 471344.98 723761.61 61.98 471344.98 723761.61 73.96000000000001 471344.9 723764.59 73.96000000000001 471344.9 723764.59 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.98 723761.61 61.98 471352.61 723761.84 61.98 471352.61 723761.84 73.96000000000001 471344.98 723761.61 73.96000000000001 471344.98 723761.61 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471352.61 723761.84 61.98 471355.22 723761.92 61.98 471355.22 723761.92 73.96000000000001 471352.61 723761.84 73.96000000000001 471352.61 723761.84 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.22 723761.92 61.98 471355.21 723762.37 61.98 471355.21 723762.37 73.96000000000001 471355.22 723761.92 73.96000000000001 471355.22 723761.92 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.21 723762.37 61.98 471354.31 723762.35 61.98 471354.31 723762.35 73.96000000000001 471355.21 723762.37 73.96000000000001 471355.21 723762.37 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.31 723762.35 61.98 471354.26 723764.9 61.98 471354.26 723764.9 73.96000000000001 471354.31 723762.35 73.96000000000001 471354.31 723762.35 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.26 723764.9 61.98 471355.16 723764.92 61.98 471355.16 723764.92 73.96000000000001 471354.26 723764.9 73.96000000000001 471354.26 723764.9 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.16 723764.92 61.98 471355.05 723768.83 61.98 471355.05 723768.83 73.96000000000001 471355.16 723764.92 73.96000000000001 471355.16 723764.92 61.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F333-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.05 723768.83 73.96000000000001 471344.8 723768.42 73.96000000000001 471344.81 723768.18 73.96000000000001 471343.31 723768.14 73.96000000000001 471343.4 723764.55 73.96000000000001 471344.9 723764.59 73.96000000000001 471344.98 723761.61 73.96000000000001 471352.61 723761.84 73.96000000000001 471355.22 723761.92 73.96000000000001 471355.21 723762.37 73.96000000000001 471354.31 723762.35 73.96000000000001 471354.26 723764.9 73.96000000000001 471355.16 723764.92 73.96000000000001 471355.05 723768.83 73.96000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">16.27</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471306.72 724123.11 100.61 471309.84 724122.72 100.61 471309.67 724121.43 100.61 471312.61 724121.06 100.61 471312.53 724120.44 100.61 471317.36 724119.85 100.61 471316.3 724111.23 100.61 471311.48 724111.8 100.61 471311.41 724111.21 100.61 471304.02 724112.1 100.61 471304.08 724112.76 100.61 471301.35 724113.06 100.61 471301.12 724111.27 100.61 471298.17 724111.66 100.61 471298.1 724111.06 100.61 471286.8 724112.53 100.61 471286.52 724110.76 100.61 471283.59 724111.21 100.61 471283.45 724110.56 100.61 471271.96 724112.06 100.61 471273.19 724121.38 100.61 471276.22 724120.98 100.61 471276.31 724121.52 100.61 471280.57 724120.97 100.61 471280.74 724122.27 100.61 471283.86 724121.86 100.61 471283.69 724120.58 100.61 471287.66 724120.06 100.61 471287.87 724121.83 100.61 471290.69 724121.52 100.61 471290.76 724122.12 100.61 471295.05 724121.61 100.61 471295.2 724122.89 100.61 471298.33 724122.52 100.61 471298.18 724121.23 100.61 471302.15 724120.76 100.61 471302.34 724122.34 100.61 471306.56 724121.82 100.61 471306.72 724123.11 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471306.72 724123.11 100.61 471306.56 724121.82 100.61 471306.56 724121.82 116.88 471306.72 724123.11 116.88 471306.72 724123.11 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471306.56 724121.82 100.61 471302.34 724122.34 100.61 471302.34 724122.34 116.88 471306.56 724121.82 116.88 471306.56 724121.82 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471302.34 724122.34 100.61 471302.15 724120.76 100.61 471302.15 724120.76 116.88 471302.34 724122.34 116.88 471302.34 724122.34 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471302.15 724120.76 100.61 471298.18 724121.23 100.61 471298.18 724121.23 116.88 471302.15 724120.76 116.88 471302.15 724120.76 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471298.18 724121.23 100.61 471298.33 724122.52 100.61 471298.33 724122.52 116.88 471298.18 724121.23 116.88 471298.18 724121.23 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471298.33 724122.52 100.61 471295.2 724122.89 100.61 471295.2 724122.89 116.88 471298.33 724122.52 116.88 471298.33 724122.52 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471295.2 724122.89 100.61 471295.05 724121.61 100.61 471295.05 724121.61 116.88 471295.2 724122.89 116.88 471295.2 724122.89 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471295.05 724121.61 100.61 471290.76 724122.12 100.61 471290.76 724122.12 116.88 471295.05 724121.61 116.88 471295.05 724121.61 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.76 724122.12 100.61 471290.69 724121.52 100.61 471290.69 724121.52 116.88 471290.76 724122.12 116.88 471290.76 724122.12 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.69 724121.52 100.61 471287.87 724121.83 100.61 471287.87 724121.83 116.88 471290.69 724121.52 116.88 471290.69 724121.52 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471287.87 724121.83 100.61 471287.66 724120.06 100.61 471287.66 724120.06 116.88 471287.87 724121.83 116.88 471287.87 724121.83 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471287.66 724120.06 100.61 471283.69 724120.58 100.61 471283.69 724120.58 116.88 471287.66 724120.06 116.88 471287.66 724120.06 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471283.69 724120.58 100.61 471283.86 724121.86 100.61 471283.86 724121.86 116.88 471283.69 724120.58 116.88 471283.69 724120.58 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471283.86 724121.86 100.61 471280.74 724122.27 100.61 471280.74 724122.27 116.88 471283.86 724121.86 116.88 471283.86 724121.86 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471280.74 724122.27 100.61 471280.57 724120.97 100.61 471280.57 724120.97 116.88 471280.74 724122.27 116.88 471280.74 724122.27 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471280.57 724120.97 100.61 471276.31 724121.52 100.61 471276.31 724121.52 116.88 471280.57 724120.97 116.88 471280.57 724120.97 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471276.31 724121.52 100.61 471276.22 724120.98 100.61 471276.22 724120.98 116.88 471276.31 724121.52 116.88 471276.31 724121.52 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471276.22 724120.98 100.61 471273.19 724121.38 100.61 471273.19 724121.38 116.88 471276.22 724120.98 116.88 471276.22 724120.98 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471273.19 724121.38 100.61 471271.96 724112.06 100.61 471271.96 724112.06 116.88 471273.19 724121.38 116.88 471273.19 724121.38 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471271.96 724112.06 100.61 471283.45 724110.56 100.61 471283.45 724110.56 116.88 471271.96 724112.06 116.88 471271.96 724112.06 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471283.45 724110.56 100.61 471283.59 724111.21 100.61 471283.59 724111.21 116.88 471283.45 724110.56 116.88 471283.45 724110.56 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471283.59 724111.21 100.61 471286.52 724110.76 100.61 471286.52 724110.76 116.88 471283.59 724111.21 116.88 471283.59 724111.21 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471286.52 724110.76 100.61 471286.8 724112.53 100.61 471286.8 724112.53 116.88 471286.52 724110.76 116.88 471286.52 724110.76 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471286.8 724112.53 100.61 471298.1 724111.06 100.61 471298.1 724111.06 116.88 471286.8 724112.53 116.88 471286.8 724112.53 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471298.1 724111.06 100.61 471298.17 724111.66 100.61 471298.17 724111.66 116.88 471298.1 724111.06 116.88 471298.1 724111.06 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471298.17 724111.66 100.61 471301.12 724111.27 100.61 471301.12 724111.27 116.88 471298.17 724111.66 116.88 471298.17 724111.66 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471301.12 724111.27 100.61 471301.35 724113.06 100.61 471301.35 724113.06 116.88 471301.12 724111.27 116.88 471301.12 724111.27 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471301.35 724113.06 100.61 471304.08 724112.76 100.61 471304.08 724112.76 116.88 471301.35 724113.06 116.88 471301.35 724113.06 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.08 724112.76 100.61 471304.02 724112.1 100.61 471304.02 724112.1 116.88 471304.08 724112.76 116.88 471304.08 724112.76 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.02 724112.1 100.61 471311.41 724111.21 100.61 471311.41 724111.21 116.88 471304.02 724112.1 116.88 471304.02 724112.1 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.41 724111.21 100.61 471311.48 724111.8 100.61 471311.48 724111.8 116.88 471311.41 724111.21 116.88 471311.41 724111.21 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.48 724111.8 100.61 471316.3 724111.23 100.61 471316.3 724111.23 116.88 471311.48 724111.8 116.88 471311.48 724111.8 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471316.3 724111.23 100.61 471317.36 724119.85 100.61 471317.36 724119.85 116.88 471316.3 724111.23 116.88 471316.3 724111.23 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.36 724119.85 100.61 471312.53 724120.44 100.61 471312.53 724120.44 116.88 471317.36 724119.85 116.88 471317.36 724119.85 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.53 724120.44 100.61 471312.61 724121.06 100.61 471312.61 724121.06 116.88 471312.53 724120.44 116.88 471312.53 724120.44 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.61 724121.06 100.61 471309.67 724121.43 100.61 471309.67 724121.43 116.88 471312.61 724121.06 116.88 471312.61 724121.06 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471309.67 724121.43 100.61 471309.84 724122.72 100.61 471309.84 724122.72 116.88 471309.67 724121.43 116.88 471309.67 724121.43 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471309.84 724122.72 100.61 471306.72 724123.11 100.61 471306.72 724123.11 116.88 471309.84 724122.72 116.88 471309.84 724122.72 100.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3C-FAF6-E053-CA2BA8C0FAE4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471306.72 724123.11 116.88 471306.56 724121.82 116.88 471302.34 724122.34 116.88 471302.15 724120.76 116.88 471298.18 724121.23 116.88 471298.33 724122.52 116.88 471295.2 724122.89 116.88 471295.05 724121.61 116.88 471290.76 724122.12 116.88 471290.69 724121.52 116.88 471287.87 724121.83 116.88 471287.66 724120.06 116.88 471283.69 724120.58 116.88 471283.86 724121.86 116.88 471280.74 724122.27 116.88 471280.57 724120.97 116.88 471276.31 724121.52 116.88 471276.22 724120.98 116.88 471273.19 724121.38 116.88 471271.96 724112.06 116.88 471283.45 724110.56 116.88 471283.59 724111.21 116.88 471286.52 724110.76 116.88 471286.8 724112.53 116.88 471298.1 724111.06 116.88 471298.17 724111.66 116.88 471301.12 724111.27 116.88 471301.35 724113.06 116.88 471304.08 724112.76 116.88 471304.02 724112.1 116.88 471311.41 724111.21 116.88 471311.48 724111.8 116.88 471316.3 724111.23 116.88 471317.36 724119.85 116.88 471312.53 724120.44 116.88 471312.61 724121.06 116.88 471309.67 724121.43 116.88 471309.84 724122.72 116.88 471306.72 724123.11 116.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-3045-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">25.76</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.39 724051.53 100.68 471380.07 724050.24 100.68 471377.64 724031.61 100.68 471372.88 724032.25 100.68 471373.04 724033.44 100.68 471371.45 724033.66 100.68 471370.46 724026.49 100.68 471367.86 724007.91 100.68 471362.91 724008.51 100.68 471363.07 724009.62 100.68 471361.48 724009.84 100.68 471360.53 724002.88 100.68 471350.82 724004.23 100.68 471353.31 724022.74 100.68 471358.23 724022.12 100.68 471358.06 724020.94 100.68 471359.65 724020.72 100.68 471360.6 724027.87 100.68 471363.07 724046.45 100.68 471368.02 724045.8 100.68 471367.86 724044.61 100.68 471369.45 724044.4 100.68 471370.39 724051.53 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.39 724051.53 100.68 471369.45 724044.4 100.68 471369.45 724044.4 126.44 471370.39 724051.53 126.44 471370.39 724051.53 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.45 724044.4 100.68 471367.86 724044.61 100.68 471367.86 724044.61 126.44 471369.45 724044.4 126.44 471369.45 724044.4 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471367.86 724044.61 100.68 471368.02 724045.8 100.68 471368.02 724045.8 126.44 471367.86 724044.61 126.44 471367.86 724044.61 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.02 724045.8 100.68 471363.07 724046.45 100.68 471363.07 724046.45 126.44 471368.02 724045.8 126.44 471368.02 724045.8 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471363.07 724046.45 100.68 471360.6 724027.87 100.68 471360.6 724027.87 126.44 471363.07 724046.45 126.44 471363.07 724046.45 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471360.6 724027.87 100.68 471359.65 724020.72 100.68 471359.65 724020.72 126.44 471360.6 724027.87 126.44 471360.6 724027.87 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471359.65 724020.72 100.68 471358.06 724020.94 100.68 471358.06 724020.94 126.44 471359.65 724020.72 126.44 471359.65 724020.72 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471358.06 724020.94 100.68 471358.23 724022.12 100.68 471358.23 724022.12 126.44 471358.06 724020.94 126.44 471358.06 724020.94 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471358.23 724022.12 100.68 471353.31 724022.74 100.68 471353.31 724022.74 126.44 471358.23 724022.12 126.44 471358.23 724022.12 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.31 724022.74 100.68 471350.82 724004.23 100.68 471350.82 724004.23 126.44 471353.31 724022.74 126.44 471353.31 724022.74 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.82 724004.23 100.68 471360.53 724002.88 100.68 471360.53 724002.88 126.44 471350.82 724004.23 126.44 471350.82 724004.23 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471360.53 724002.88 100.68 471361.48 724009.84 100.68 471361.48 724009.84 126.44 471360.53 724002.88 126.44 471360.53 724002.88 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471361.48 724009.84 100.68 471363.07 724009.62 100.68 471363.07 724009.62 126.44 471361.48 724009.84 126.44 471361.48 724009.84 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471363.07 724009.62 100.68 471362.91 724008.51 100.68 471362.91 724008.51 126.44 471363.07 724009.62 126.44 471363.07 724009.62 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471362.91 724008.51 100.68 471367.86 724007.91 100.68 471367.86 724007.91 126.44 471362.91 724008.51 126.44 471362.91 724008.51 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471367.86 724007.91 100.68 471370.46 724026.49 100.68 471370.46 724026.49 126.44 471367.86 724007.91 126.44 471367.86 724007.91 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.46 724026.49 100.68 471371.45 724033.66 100.68 471371.45 724033.66 126.44 471370.46 724026.49 126.44 471370.46 724026.49 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.45 724033.66 100.68 471373.04 724033.44 100.68 471373.04 724033.44 126.44 471371.45 724033.66 126.44 471371.45 724033.66 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.04 724033.44 100.68 471372.88 724032.25 100.68 471372.88 724032.25 126.44 471373.04 724033.44 126.44 471373.04 724033.44 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471372.88 724032.25 100.68 471377.64 724031.61 100.68 471377.64 724031.61 126.44 471372.88 724032.25 126.44 471372.88 724032.25 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471377.64 724031.61 100.68 471380.07 724050.24 100.68 471380.07 724050.24 126.44 471377.64 724031.61 126.44 471377.64 724031.61 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.07 724050.24 100.68 471370.39 724051.53 100.68 471370.39 724051.53 126.44 471380.07 724050.24 126.44 471380.07 724050.24 100.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3045-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.39 724051.53 126.44 471369.45 724044.4 126.44 471367.86 724044.61 126.44 471368.02 724045.8 126.44 471363.07 724046.45 126.44 471360.6 724027.87 126.44 471359.65 724020.72 126.44 471358.06 724020.94 126.44 471358.23 724022.12 126.44 471353.31 724022.74 126.44 471350.82 724004.23 126.44 471360.53 724002.88 126.44 471361.48 724009.84 126.44 471363.07 724009.62 126.44 471362.91 724008.51 126.44 471367.86 724007.91 126.44 471370.46 724026.49 126.44 471371.45 724033.66 126.44 471373.04 724033.44 126.44 471372.88 724032.25 126.44 471377.64 724031.61 126.44 471380.07 724050.24 126.44 471370.39 724051.53 126.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-BFE1-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-BFE1-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.44</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BFE1-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471487.7 723762.96 59.82 471487.96 723753.63 59.82 471481.4 723753.45 59.82 471481.3 723756.59 59.82 471481.2 723759.57 59.82 471481.12 723762.74 59.82 471487.7 723762.96 59.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BFE1-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471487.7 723762.96 59.82 471481.12 723762.74 59.82 471481.12 723762.74 63.26 471487.7 723762.96 63.26 471487.7 723762.96 59.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BFE1-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471481.12 723762.74 59.82 471481.2 723759.57 59.82 471481.2 723759.57 63.26 471481.12 723762.74 63.26 471481.12 723762.74 59.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BFE1-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471481.2 723759.57 59.82 471481.3 723756.59 59.82 471481.3 723756.59 63.26 471481.2 723759.57 63.26 471481.2 723759.57 59.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BFE1-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471481.3 723756.59 59.82 471481.4 723753.45 59.82 471481.4 723753.45 63.26 471481.3 723756.59 63.26 471481.3 723756.59 59.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BFE1-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471481.4 723753.45 59.82 471487.96 723753.63 59.82 471487.96 723753.63 63.26 471481.4 723753.45 63.26 471481.4 723753.45 59.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BFE1-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471487.96 723753.63 59.82 471487.7 723762.96 59.82 471487.7 723762.96 63.26 471487.96 723753.63 63.26 471487.96 723753.63 59.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BFE1-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471487.7 723762.96 63.26 471481.12 723762.74 63.26 471481.2 723759.57 63.26 471481.3 723756.59 63.26 471481.4 723753.45 63.26 471487.96 723753.63 63.26 471487.7 723762.96 63.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">32.06</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.78 724056.18 100.91 471314.39 724054.87 100.91 471311.85 724036.25 100.91 471306.9 724036.93 100.91 471307.06 724038.12 100.91 471305.48 724038.33 100.91 471304.56 724031.2 100.91 471302.19 724012.56 100.91 471297.22 724013 100.91 471297.4 724014.4 100.91 471295.81 724014.6 100.91 471294.98 724007.4 100.91 471290.2 724007.97 100.91 471290.07 724006.92 100.91 471285.12 724007.57 100.91 471287.68 724027.39 100.91 471292.59 724026.7 100.91 471292.43 724025.51 100.91 471294.03 724025.31 100.91 471294.95 724032.43 100.91 471297.36 724051.11 100.91 471302.41 724050.43 100.91 471302.25 724049.24 100.91 471303.84 724049.04 100.91 471304.78 724056.18 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.78 724056.18 100.91 471303.84 724049.04 100.91 471303.84 724049.04 132.97 471304.78 724056.18 132.97 471304.78 724056.18 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471303.84 724049.04 100.91 471302.25 724049.24 100.91 471302.25 724049.24 132.97 471303.84 724049.04 132.97 471303.84 724049.04 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471302.25 724049.24 100.91 471302.41 724050.43 100.91 471302.41 724050.43 132.97 471302.25 724049.24 132.97 471302.25 724049.24 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471302.41 724050.43 100.91 471297.36 724051.11 100.91 471297.36 724051.11 132.97 471302.41 724050.43 132.97 471302.41 724050.43 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471297.36 724051.11 100.91 471294.95 724032.43 100.91 471294.95 724032.43 132.97 471297.36 724051.11 132.97 471297.36 724051.11 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471294.95 724032.43 100.91 471294.03 724025.31 100.91 471294.03 724025.31 132.97 471294.95 724032.43 132.97 471294.95 724032.43 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471294.03 724025.31 100.91 471292.43 724025.51 100.91 471292.43 724025.51 132.97 471294.03 724025.31 132.97 471294.03 724025.31 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471292.43 724025.51 100.91 471292.59 724026.7 100.91 471292.59 724026.7 132.97 471292.43 724025.51 132.97 471292.43 724025.51 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471292.59 724026.7 100.91 471287.68 724027.39 100.91 471287.68 724027.39 132.97 471292.59 724026.7 132.97 471292.59 724026.7 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471287.68 724027.39 100.91 471285.12 724007.57 100.91 471285.12 724007.57 132.97 471287.68 724027.39 132.97 471287.68 724027.39 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471285.12 724007.57 100.91 471290.07 724006.92 100.91 471290.07 724006.92 132.97 471285.12 724007.57 132.97 471285.12 724007.57 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.07 724006.92 100.91 471290.2 724007.97 100.91 471290.2 724007.97 132.97 471290.07 724006.92 132.97 471290.07 724006.92 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.2 724007.97 100.91 471294.98 724007.4 100.91 471294.98 724007.4 132.97 471290.2 724007.97 132.97 471290.2 724007.97 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471294.98 724007.4 100.91 471295.81 724014.6 100.91 471295.81 724014.6 132.97 471294.98 724007.4 132.97 471294.98 724007.4 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471295.81 724014.6 100.91 471297.4 724014.4 100.91 471297.4 724014.4 132.97 471295.81 724014.6 132.97 471295.81 724014.6 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471297.4 724014.4 100.91 471297.22 724013 100.91 471297.22 724013 132.97 471297.4 724014.4 132.97 471297.4 724014.4 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471297.22 724013 100.91 471302.19 724012.56 100.91 471302.19 724012.56 132.97 471297.22 724013 132.97 471297.22 724013 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471302.19 724012.56 100.91 471304.56 724031.2 100.91 471304.56 724031.2 132.97 471302.19 724012.56 132.97 471302.19 724012.56 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.56 724031.2 100.91 471305.48 724038.33 100.91 471305.48 724038.33 132.97 471304.56 724031.2 132.97 471304.56 724031.2 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.48 724038.33 100.91 471307.06 724038.12 100.91 471307.06 724038.12 132.97 471305.48 724038.33 132.97 471305.48 724038.33 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471307.06 724038.12 100.91 471306.9 724036.93 100.91 471306.9 724036.93 132.97 471307.06 724038.12 132.97 471307.06 724038.12 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471306.9 724036.93 100.91 471311.85 724036.25 100.91 471311.85 724036.25 132.97 471306.9 724036.93 132.97 471306.9 724036.93 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.85 724036.25 100.91 471314.39 724054.87 100.91 471314.39 724054.87 132.97 471311.85 724036.25 132.97 471311.85 724036.25 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.39 724054.87 100.91 471304.78 724056.18 100.91 471304.78 724056.18 132.97 471314.39 724054.87 132.97 471314.39 724054.87 100.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2E3E-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.78 724056.18 132.97 471303.84 724049.04 132.97 471302.25 724049.24 132.97 471302.41 724050.43 132.97 471297.36 724051.11 132.97 471294.95 724032.43 132.97 471294.03 724025.31 132.97 471292.43 724025.51 132.97 471292.59 724026.7 132.97 471287.68 724027.39 132.97 471285.12 724007.57 132.97 471290.07 724006.92 132.97 471290.2 724007.97 132.97 471294.98 724007.4 132.97 471295.81 724014.6 132.97 471297.4 724014.4 132.97 471297.22 724013 132.97 471302.19 724012.56 132.97 471304.56 724031.2 132.97 471305.48 724038.33 132.97 471307.06 724038.12 132.97 471306.9 724036.93 132.97 471311.85 724036.25 132.97 471314.39 724054.87 132.97 471304.78 724056.18 132.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F016-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.11</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.29 723774.29 64.85 471318.79 723774.32 64.85 471328.11 723775.12 64.85 471329.01 723775.15 64.85 471329.11 723770.79 64.85 471328.21 723770.76 64.85 471328.28 723768.39 64.85 471329.15 723768.41 64.85 471329.19 723768.08 64.85 471318.94 723767.77 64.85 471318.87 723770.75 64.85 471317.37 723770.71 64.85 471317.29 723774.29 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.29 723774.29 64.85 471317.37 723770.71 64.85 471317.37 723770.71 76.96000000000001 471317.29 723774.29 76.96000000000001 471317.29 723774.29 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.37 723770.71 64.85 471318.87 723770.75 64.85 471318.87 723770.75 76.96000000000001 471317.37 723770.71 76.96000000000001 471317.37 723770.71 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.87 723770.75 64.85 471318.94 723767.77 64.85 471318.94 723767.77 76.96000000000001 471318.87 723770.75 76.96000000000001 471318.87 723770.75 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.94 723767.77 64.85 471329.19 723768.08 64.85 471329.19 723768.08 76.96000000000001 471318.94 723767.77 76.96000000000001 471318.94 723767.77 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.19 723768.08 64.85 471329.15 723768.41 64.85 471329.15 723768.41 76.96000000000001 471329.19 723768.08 76.96000000000001 471329.19 723768.08 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.15 723768.41 64.85 471328.28 723768.39 64.85 471328.28 723768.39 76.96000000000001 471329.15 723768.41 76.96000000000001 471329.15 723768.41 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.28 723768.39 64.85 471328.21 723770.76 64.85 471328.21 723770.76 76.96000000000001 471328.28 723768.39 76.96000000000001 471328.28 723768.39 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.21 723770.76 64.85 471329.11 723770.79 64.85 471329.11 723770.79 76.96000000000001 471328.21 723770.76 76.96000000000001 471328.21 723770.76 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.11 723770.79 64.85 471329.01 723775.15 64.85 471329.01 723775.15 76.96000000000001 471329.11 723770.79 76.96000000000001 471329.11 723770.79 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.01 723775.15 64.85 471328.11 723775.12 64.85 471328.11 723775.12 76.96000000000001 471329.01 723775.15 76.96000000000001 471329.01 723775.15 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.11 723775.12 64.85 471318.79 723774.32 64.85 471318.79 723774.32 76.96000000000001 471328.11 723775.12 76.96000000000001 471328.11 723775.12 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.79 723774.32 64.85 471317.29 723774.29 64.85 471317.29 723774.29 76.96000000000001 471318.79 723774.32 76.96000000000001 471318.79 723774.32 64.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F016-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.29 723774.29 76.96000000000001 471317.37 723770.71 76.96000000000001 471318.87 723770.75 76.96000000000001 471318.94 723767.77 76.96000000000001 471329.19 723768.08 76.96000000000001 471329.15 723768.41 76.96000000000001 471328.28 723768.39 76.96000000000001 471328.21 723770.76 76.96000000000001 471329.11 723770.79 76.96000000000001 471329.01 723775.15 76.96000000000001 471328.11 723775.12 76.96000000000001 471318.79 723774.32 76.96000000000001 471317.29 723774.29 76.96000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F339-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">11.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.37 723795.59 74.27 471354.48 723791.3 74.27 471353.58 723791.27 74.27 471353.64 723788.97 74.27 471354.54 723789 74.27 471354.55 723788.63 74.27 471344.32 723788.05 74.27 471344.24 723791 74.27 471342.74 723790.96 74.27 471342.64 723795.31 74.27 471354.37 723795.59 74.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.37 723795.59 74.27 471342.64 723795.31 74.27 471342.64 723795.31 86.06 471354.37 723795.59 86.06 471354.37 723795.59 74.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.64 723795.31 74.27 471342.74 723790.96 74.27 471342.74 723790.96 86.06 471342.64 723795.31 86.06 471342.64 723795.31 74.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.74 723790.96 74.27 471344.24 723791 74.27 471344.24 723791 86.06 471342.74 723790.96 86.06 471342.74 723790.96 74.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.24 723791 74.27 471344.32 723788.05 74.27 471344.32 723788.05 86.06 471344.24 723791 86.06 471344.24 723791 74.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.32 723788.05 74.27 471354.55 723788.63 74.27 471354.55 723788.63 86.06 471344.32 723788.05 86.06 471344.32 723788.05 74.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.55 723788.63 74.27 471354.54 723789 74.27 471354.54 723789 86.06 471354.55 723788.63 86.06 471354.55 723788.63 74.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.54 723789 74.27 471353.64 723788.97 74.27 471353.64 723788.97 86.06 471354.54 723789 86.06 471354.54 723789 74.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.64 723788.97 74.27 471353.58 723791.27 74.27 471353.58 723791.27 86.06 471353.64 723788.97 86.06 471353.64 723788.97 74.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.58 723791.27 74.27 471354.48 723791.3 74.27 471354.48 723791.3 86.06 471353.58 723791.27 86.06 471353.58 723791.27 74.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.48 723791.3 74.27 471354.37 723795.59 74.27 471354.37 723795.59 86.06 471354.48 723791.3 86.06 471354.48 723791.3 74.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F339-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.37 723795.59 86.06 471342.64 723795.31 86.06 471342.74 723790.96 86.06 471344.24 723791 86.06 471344.32 723788.05 86.06 471354.55 723788.63 86.06 471354.54 723789 86.06 471353.64 723788.97 86.06 471353.58 723791.27 86.06 471354.48 723791.3 86.06 471354.37 723795.59 86.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F596-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.17</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.35 723798.68 67.36 471476.35 723798.45 67.36 471475.4 723798.43 67.36 471475.47 723796.13 67.36 471476.41 723796.15 67.36 471476.52 723792.11 67.36 471464.77 723791.74 67.36 471464.75 723792.2 67.36 471466.25 723792.25 67.36 471466.17 723795.22 67.36 471464.67 723795.18 67.36 471464.57 723798.33 67.36 471476.35 723798.68 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.35 723798.68 67.36 471464.57 723798.33 67.36 471464.57 723798.33 77.53 471476.35 723798.68 77.53 471476.35 723798.68 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.57 723798.33 67.36 471464.67 723795.18 67.36 471464.67 723795.18 77.53 471464.57 723798.33 77.53 471464.57 723798.33 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.67 723795.18 67.36 471466.17 723795.22 67.36 471466.17 723795.22 77.53 471464.67 723795.18 77.53 471464.67 723795.18 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471466.17 723795.22 67.36 471466.25 723792.25 67.36 471466.25 723792.25 77.53 471466.17 723795.22 77.53 471466.17 723795.22 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471466.25 723792.25 67.36 471464.75 723792.2 67.36 471464.75 723792.2 77.53 471466.25 723792.25 77.53 471466.25 723792.25 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.75 723792.2 67.36 471464.77 723791.74 67.36 471464.77 723791.74 77.53 471464.75 723792.2 77.53 471464.75 723792.2 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.77 723791.74 67.36 471476.52 723792.11 67.36 471476.52 723792.11 77.53 471464.77 723791.74 77.53 471464.77 723791.74 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.52 723792.11 67.36 471476.41 723796.15 67.36 471476.41 723796.15 77.53 471476.52 723792.11 77.53 471476.52 723792.11 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.41 723796.15 67.36 471475.47 723796.13 67.36 471475.47 723796.13 77.53 471476.41 723796.15 77.53 471476.41 723796.15 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.47 723796.13 67.36 471475.4 723798.43 67.36 471475.4 723798.43 77.53 471475.47 723796.13 77.53 471475.47 723796.13 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.4 723798.43 67.36 471476.35 723798.45 67.36 471476.35 723798.45 77.53 471475.4 723798.43 77.53 471475.4 723798.43 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.35 723798.45 67.36 471476.35 723798.68 67.36 471476.35 723798.68 77.53 471476.35 723798.45 77.53 471476.35 723798.45 67.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F596-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.35 723798.68 77.53 471464.57 723798.33 77.53 471464.67 723795.18 77.53 471466.17 723795.22 77.53 471466.25 723792.25 77.53 471464.75 723792.2 77.53 471464.77 723791.74 77.53 471476.52 723792.11 77.53 471476.41 723796.15 77.53 471475.47 723796.13 77.53 471475.4 723798.43 77.53 471476.35 723798.45 77.53 471476.35 723798.68 77.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.15</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.85 723781.51 67.79 471328.95 723777.52 67.79 471328.05 723777.5 67.79 471328.11 723775.12 67.79 471318.79 723774.32 67.79 471318.71 723777.29 67.79 471317.22 723777.25 67.79 471317.13 723780.85 67.79 471318.63 723780.89 67.79 471327.95 723781.48 67.79 471328.85 723781.51 67.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.85 723781.51 67.79 471327.95 723781.48 67.79 471327.95 723781.48 79.94 471328.85 723781.51 79.94 471328.85 723781.51 67.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.95 723781.48 67.79 471318.63 723780.89 67.79 471318.63 723780.89 79.94 471327.95 723781.48 79.94 471327.95 723781.48 67.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.63 723780.89 67.79 471317.13 723780.85 67.79 471317.13 723780.85 79.94 471318.63 723780.89 79.94 471318.63 723780.89 67.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.13 723780.85 67.79 471317.22 723777.25 67.79 471317.22 723777.25 79.94 471317.13 723780.85 79.94 471317.13 723780.85 67.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.22 723777.25 67.79 471318.71 723777.29 67.79 471318.71 723777.29 79.94 471317.22 723777.25 79.94 471317.22 723777.25 67.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.71 723777.29 67.79 471318.79 723774.32 67.79 471318.79 723774.32 79.94 471318.71 723777.29 79.94 471318.71 723777.29 67.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.79 723774.32 67.79 471328.11 723775.12 67.79 471328.11 723775.12 79.94 471318.79 723774.32 79.94 471318.79 723774.32 67.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.11 723775.12 67.79 471328.05 723777.5 67.79 471328.05 723777.5 79.94 471328.11 723775.12 79.94 471328.11 723775.12 67.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.05 723777.5 67.79 471328.95 723777.52 67.79 471328.95 723777.52 79.94 471328.05 723777.5 79.94 471328.05 723777.5 67.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.95 723777.52 67.79 471328.85 723781.51 67.79 471328.85 723781.51 79.94 471328.95 723777.52 79.94 471328.95 723777.52 67.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1A9-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.85 723781.51 79.94 471327.95 723781.48 79.94 471318.63 723780.89 79.94 471317.13 723780.85 79.94 471317.22 723777.25 79.94 471318.71 723777.29 79.94 471318.79 723774.32 79.94 471328.11 723775.12 79.94 471328.05 723777.5 79.94 471328.95 723777.52 79.94 471328.85 723781.51 79.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F597-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.86</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.69 723785.54 62.61 471476.69 723785.27 62.61 471475.75 723785.25 62.61 471475.81 723782.89 62.61 471476.76 723782.92 62.61 471476.86 723778.97 62.61 471465.16 723778.59 62.61 471465.16 723778.95 62.61 471466.66 723779 62.61 471466.57 723781.95 62.61 471465.07 723781.9 62.61 471464.98 723785.17 62.61 471476.69 723785.54 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.69 723785.54 62.61 471464.98 723785.17 62.61 471464.98 723785.17 72.47 471476.69 723785.54 72.47 471476.69 723785.54 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.98 723785.17 62.61 471465.07 723781.9 62.61 471465.07 723781.9 72.47 471464.98 723785.17 72.47 471464.98 723785.17 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.07 723781.9 62.61 471466.57 723781.95 62.61 471466.57 723781.95 72.47 471465.07 723781.9 72.47 471465.07 723781.9 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471466.57 723781.95 62.61 471466.66 723779 62.61 471466.66 723779 72.47 471466.57 723781.95 72.47 471466.57 723781.95 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471466.66 723779 62.61 471465.16 723778.95 62.61 471465.16 723778.95 72.47 471466.66 723779 72.47 471466.66 723779 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.16 723778.95 62.61 471465.16 723778.59 62.61 471465.16 723778.59 72.47 471465.16 723778.95 72.47 471465.16 723778.95 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.16 723778.59 62.61 471476.86 723778.97 62.61 471476.86 723778.97 72.47 471465.16 723778.59 72.47 471465.16 723778.59 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.86 723778.97 62.61 471476.76 723782.92 62.61 471476.76 723782.92 72.47 471476.86 723778.97 72.47 471476.86 723778.97 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.76 723782.92 62.61 471475.81 723782.89 62.61 471475.81 723782.89 72.47 471476.76 723782.92 72.47 471476.76 723782.92 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.81 723782.89 62.61 471475.75 723785.25 62.61 471475.75 723785.25 72.47 471475.81 723782.89 72.47 471475.81 723782.89 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.75 723785.25 62.61 471476.69 723785.27 62.61 471476.69 723785.27 72.47 471475.75 723785.25 72.47 471475.75 723785.25 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.69 723785.27 62.61 471476.69 723785.54 62.61 471476.69 723785.54 72.47 471476.69 723785.27 72.47 471476.69 723785.27 62.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F597-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.69 723785.54 72.47 471464.98 723785.17 72.47 471465.07 723781.9 72.47 471466.57 723781.95 72.47 471466.66 723779 72.47 471465.16 723778.95 72.47 471465.16 723778.59 72.47 471476.86 723778.97 72.47 471476.76 723782.92 72.47 471475.81 723782.89 72.47 471475.75 723785.25 72.47 471476.69 723785.27 72.47 471476.69 723785.54 72.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F598-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.09</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.52 723792.11 64.91 471476.52 723791.91 64.91 471475.58 723791.89 64.91 471475.64 723789.49 64.91 471476.58 723789.51 64.91 471476.69 723785.54 64.91 471464.98 723785.17 64.91 471464.95 723785.58 64.91 471466.45 723785.63 64.91 471466.36 723788.56 64.91 471464.86 723788.51 64.91 471464.77 723791.74 64.91 471476.52 723792.11 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.52 723792.11 64.91 471464.77 723791.74 64.91 471464.77 723791.74 75 471476.52 723792.11 75 471476.52 723792.11 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.77 723791.74 64.91 471464.86 723788.51 64.91 471464.86 723788.51 75 471464.77 723791.74 75 471464.77 723791.74 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.86 723788.51 64.91 471466.36 723788.56 64.91 471466.36 723788.56 75 471464.86 723788.51 75 471464.86 723788.51 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471466.36 723788.56 64.91 471466.45 723785.63 64.91 471466.45 723785.63 75 471466.36 723788.56 75 471466.36 723788.56 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471466.45 723785.63 64.91 471464.95 723785.58 64.91 471464.95 723785.58 75 471466.45 723785.63 75 471466.45 723785.63 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.95 723785.58 64.91 471464.98 723785.17 64.91 471464.98 723785.17 75 471464.95 723785.58 75 471464.95 723785.58 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.98 723785.17 64.91 471476.69 723785.54 64.91 471476.69 723785.54 75 471464.98 723785.17 75 471464.98 723785.17 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.69 723785.54 64.91 471476.58 723789.51 64.91 471476.58 723789.51 75 471476.69 723785.54 75 471476.69 723785.54 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.58 723789.51 64.91 471475.64 723789.49 64.91 471475.64 723789.49 75 471476.58 723789.51 75 471476.58 723789.51 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.64 723789.49 64.91 471475.58 723791.89 64.91 471475.58 723791.89 75 471475.64 723789.49 75 471475.64 723789.49 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.58 723791.89 64.91 471476.52 723791.91 64.91 471476.52 723791.91 75 471475.58 723791.89 75 471475.58 723791.89 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.52 723791.91 64.91 471476.52 723792.11 64.91 471476.52 723792.11 75 471476.52 723791.91 75 471476.52 723791.91 64.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F598-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.52 723792.11 75 471464.77 723791.74 75 471464.86 723788.51 75 471466.36 723788.56 75 471466.45 723785.63 75 471464.95 723785.58 75 471464.98 723785.17 75 471476.69 723785.54 75 471476.58 723789.51 75 471475.64 723789.49 75 471475.58 723791.89 75 471476.52 723791.91 75 471476.52 723792.11 75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.16 723805.63 69.96 471476.18 723805.23 69.96 471475.23 723805.22 69.96 471475.3 723802.57 69.96 471476.25 723802.58 69.96 471476.35 723798.68 69.96 471464.57 723798.33 69.96 471464.56 723798.85 69.96 471466.06 723798.89 69.96 471465.97 723801.84 69.96 471464.47 723801.8 69.96 471464.37 723805.24 69.96 471476.16 723805.63 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.16 723805.63 69.96 471464.37 723805.24 69.96 471464.37 723805.24 79.77 471476.16 723805.63 79.77 471476.16 723805.63 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.37 723805.24 69.96 471464.47 723801.8 69.96 471464.47 723801.8 79.77 471464.37 723805.24 79.77 471464.37 723805.24 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.47 723801.8 69.96 471465.97 723801.84 69.96 471465.97 723801.84 79.77 471464.47 723801.8 79.77 471464.47 723801.8 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.97 723801.84 69.96 471466.06 723798.89 69.96 471466.06 723798.89 79.77 471465.97 723801.84 79.77 471465.97 723801.84 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471466.06 723798.89 69.96 471464.56 723798.85 69.96 471464.56 723798.85 79.77 471466.06 723798.89 79.77 471466.06 723798.89 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.56 723798.85 69.96 471464.57 723798.33 69.96 471464.57 723798.33 79.77 471464.56 723798.85 79.77 471464.56 723798.85 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.57 723798.33 69.96 471476.35 723798.68 69.96 471476.35 723798.68 79.77 471464.57 723798.33 79.77 471464.57 723798.33 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.35 723798.68 69.96 471476.25 723802.58 69.96 471476.25 723802.58 79.77 471476.35 723798.68 79.77 471476.35 723798.68 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.25 723802.58 69.96 471475.3 723802.57 69.96 471475.3 723802.57 79.77 471476.25 723802.58 79.77 471476.25 723802.58 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.3 723802.57 69.96 471475.23 723805.22 69.96 471475.23 723805.22 79.77 471475.3 723802.57 79.77 471475.3 723802.57 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.23 723805.22 69.96 471476.18 723805.23 69.96 471476.18 723805.23 79.77 471475.23 723805.22 79.77 471475.23 723805.22 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.18 723805.23 69.96 471476.16 723805.63 69.96 471476.16 723805.63 79.77 471476.18 723805.23 79.77 471476.18 723805.23 69.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4CF-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.16 723805.63 79.77 471464.37 723805.24 79.77 471464.47 723801.8 79.77 471465.97 723801.84 79.77 471466.06 723798.89 79.77 471464.56 723798.85 79.77 471464.57 723798.33 79.77 471476.35 723798.68 79.77 471476.25 723802.58 79.77 471475.3 723802.57 79.77 471475.23 723805.22 79.77 471476.18 723805.23 79.77 471476.16 723805.63 79.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F658-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.05</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471477.03 723772.41 60.09 471477.04 723772.08 60.09 471476.09 723772.06 60.09 471476.15 723769.71 60.09 471477.1 723769.73 60.09 471477.21 723765.46 60.09 471467.01 723765.15 60.09 471466.98 723768.69 60.09 471465.48 723768.65 60.09 471465.37 723772.02 60.09 471477.03 723772.41 60.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471477.03 723772.41 60.09 471465.37 723772.02 60.09 471465.37 723772.02 68.135 471477.03 723772.41 68.135 471477.03 723772.41 60.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.37 723772.02 60.09 471465.48 723768.65 60.09 471465.48 723768.65 68.135 471465.37 723772.02 68.135 471465.37 723772.02 60.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.48 723768.65 60.09 471466.98 723768.69 60.09 471466.98 723768.69 68.135 471465.48 723768.65 68.135 471465.48 723768.65 60.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471466.98 723768.69 60.09 471467.01 723765.15 60.09 471467.01 723765.15 68.135 471466.98 723768.69 68.135 471466.98 723768.69 60.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471467.01 723765.15 60.09 471477.21 723765.46 60.09 471477.21 723765.46 68.135 471467.01 723765.15 68.135 471467.01 723765.15 60.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471477.21 723765.46 60.09 471477.1 723769.73 60.09 471477.1 723769.73 68.135 471477.21 723765.46 68.135 471477.21 723765.46 60.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471477.1 723769.73 60.09 471476.15 723769.71 60.09 471476.15 723769.71 68.135 471477.1 723769.73 68.135 471477.1 723769.73 60.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.15 723769.71 60.09 471476.09 723772.06 60.09 471476.09 723772.06 68.135 471476.15 723769.71 68.135 471476.15 723769.71 60.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471476.09 723772.06 60.09 471477.04 723772.08 60.09 471477.04 723772.08 68.135 471476.09 723772.06 68.135 471476.09 723772.06 60.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471477.04 723772.08 60.09 471477.03 723772.41 60.09 471477.03 723772.41 68.135 471477.04 723772.08 68.135 471477.04 723772.08 60.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F658-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471477.03 723772.41 68.135 471465.37 723772.02 68.135 471465.48 723768.65 68.135 471466.98 723768.69 68.135 471467.01 723765.15 68.135 471477.21 723765.46 68.135 471477.1 723769.73 68.135 471476.15 723769.71 68.135 471476.09 723772.06 68.135 471477.04 723772.08 68.135 471477.03 723772.41 68.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CE11-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CE11-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.23</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE11-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.18 724068.3 97.03 471351.96 724066.65 97.03 471350.31 724054.26 97.03 471337.57 724055.91 97.03 471339.18 724068.3 97.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE11-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.18 724068.3 97.03 471337.57 724055.91 97.03 471337.57 724055.91 106.26 471339.18 724068.3 106.26 471339.18 724068.3 97.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE11-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.57 724055.91 97.03 471350.31 724054.26 97.03 471350.31 724054.26 106.26 471337.57 724055.91 106.26 471337.57 724055.91 97.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE11-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.31 724054.26 97.03 471351.96 724066.65 97.03 471351.96 724066.65 106.26 471350.31 724054.26 106.26 471350.31 724054.26 97.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE11-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471351.96 724066.65 97.03 471339.18 724068.3 97.03 471339.18 724068.3 106.26 471351.96 724066.65 106.26 471351.96 724066.65 97.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE11-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.18 724068.3 106.26 471337.57 724055.91 106.26 471350.31 724054.26 106.26 471351.96 724066.65 106.26 471339.18 724068.3 106.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">11.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.45 723767.76 61.65 471318.94 723767.77 61.65 471329.19 723768.08 61.65 471329.28 723764.28 61.65 471330.48 723764.31 61.65 471330.54 723761.42 61.65 471329.35 723761.39 61.65 471329.36 723761.04 61.65 471319.11 723760.7 61.65 471319.03 723764.3 61.65 471317.52 723764.25 61.65 471317.45 723767.76 61.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.45 723767.76 61.65 471317.52 723764.25 61.65 471317.52 723764.25 73.08 471317.45 723767.76 73.08 471317.45 723767.76 61.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.52 723764.25 61.65 471319.03 723764.3 61.65 471319.03 723764.3 73.08 471317.52 723764.25 73.08 471317.52 723764.25 61.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471319.03 723764.3 61.65 471319.11 723760.7 61.65 471319.11 723760.7 73.08 471319.03 723764.3 73.08 471319.03 723764.3 61.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471319.11 723760.7 61.65 471329.36 723761.04 61.65 471329.36 723761.04 73.08 471319.11 723760.7 73.08 471319.11 723760.7 61.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.36 723761.04 61.65 471329.35 723761.39 61.65 471329.35 723761.39 73.08 471329.36 723761.04 73.08 471329.36 723761.04 61.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.35 723761.39 61.65 471330.54 723761.42 61.65 471330.54 723761.42 73.08 471329.35 723761.39 73.08 471329.35 723761.39 61.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.54 723761.42 61.65 471330.48 723764.31 61.65 471330.48 723764.31 73.08 471330.54 723761.42 73.08 471330.54 723761.42 61.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.48 723764.31 61.65 471329.28 723764.28 61.65 471329.28 723764.28 73.08 471330.48 723764.31 73.08 471330.48 723764.31 61.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.28 723764.28 61.65 471329.19 723768.08 61.65 471329.19 723768.08 73.08 471329.28 723764.28 73.08 471329.28 723764.28 61.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.19 723768.08 61.65 471318.94 723767.77 61.65 471318.94 723767.77 73.08 471329.19 723768.08 73.08 471329.19 723768.08 61.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.94 723767.77 61.65 471317.45 723767.76 61.65 471317.45 723767.76 73.08 471318.94 723767.77 73.08 471318.94 723767.77 61.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F1AC-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.45 723767.76 73.08 471317.52 723764.25 73.08 471319.03 723764.3 73.08 471319.11 723760.7 73.08 471329.36 723761.04 73.08 471329.35 723761.39 73.08 471330.54 723761.42 73.08 471330.48 723764.31 73.08 471329.28 723764.28 73.08 471329.19 723768.08 73.08 471318.94 723767.77 73.08 471317.45 723767.76 73.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.36</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.88 723775.46 64.93 471354.98 723771.52 64.93 471354.09 723771.49 64.93 471354.15 723769.19 64.93 471355.05 723769.22 64.93 471355.05 723768.83 64.93 471344.8 723768.42 64.93 471344.73 723771.13 64.93 471343.23 723771.09 64.93 471343.14 723774.68 64.93 471344.64 723774.72 64.93 471344.64 723774.97 64.93 471354.88 723775.46 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.88 723775.46 64.93 471344.64 723774.97 64.93 471344.64 723774.97 77.29 471354.88 723775.46 77.29 471354.88 723775.46 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.64 723774.97 64.93 471344.64 723774.72 64.93 471344.64 723774.72 77.29 471344.64 723774.97 77.29 471344.64 723774.97 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.64 723774.72 64.93 471343.14 723774.68 64.93 471343.14 723774.68 77.29 471344.64 723774.72 77.29 471344.64 723774.72 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471343.14 723774.68 64.93 471343.23 723771.09 64.93 471343.23 723771.09 77.29 471343.14 723774.68 77.29 471343.14 723774.68 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471343.23 723771.09 64.93 471344.73 723771.13 64.93 471344.73 723771.13 77.29 471343.23 723771.09 77.29 471343.23 723771.09 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.73 723771.13 64.93 471344.8 723768.42 64.93 471344.8 723768.42 77.29 471344.73 723771.13 77.29 471344.73 723771.13 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.8 723768.42 64.93 471355.05 723768.83 64.93 471355.05 723768.83 77.29 471344.8 723768.42 77.29 471344.8 723768.42 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.05 723768.83 64.93 471355.05 723769.22 64.93 471355.05 723769.22 77.29 471355.05 723768.83 77.29 471355.05 723768.83 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.05 723769.22 64.93 471354.15 723769.19 64.93 471354.15 723769.19 77.29 471355.05 723769.22 77.29 471355.05 723769.22 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.15 723769.19 64.93 471354.09 723771.49 64.93 471354.09 723771.49 77.29 471354.15 723769.19 77.29 471354.15 723769.19 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.09 723771.49 64.93 471354.98 723771.52 64.93 471354.98 723771.52 77.29 471354.09 723771.49 77.29 471354.09 723771.49 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.98 723771.52 64.93 471354.88 723775.46 64.93 471354.88 723775.46 77.29 471354.98 723771.52 77.29 471354.98 723771.52 64.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F6-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.88 723775.46 77.29 471344.64 723774.97 77.29 471344.64 723774.72 77.29 471343.14 723774.68 77.29 471343.23 723771.09 77.29 471344.73 723771.13 77.29 471344.8 723768.42 77.29 471355.05 723768.83 77.29 471355.05 723769.22 77.29 471354.15 723769.19 77.29 471354.09 723771.49 77.29 471354.98 723771.52 77.29 471354.88 723775.46 77.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.05</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.55 723788.63 71.22 471354.65 723784.71 71.22 471353.75 723784.68 71.22 471353.82 723782.38 71.22 471354.71 723782.41 71.22 471354.72 723782.03 71.22 471344.48 723781.51 71.22 471344.41 723784.46 71.22 471342.91 723784.42 71.22 471342.82 723787.96 71.22 471344.32 723788.05 71.22 471354.55 723788.63 71.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.55 723788.63 71.22 471344.32 723788.05 71.22 471344.32 723788.05 83.27 471354.55 723788.63 83.27 471354.55 723788.63 71.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.32 723788.05 71.22 471342.82 723787.96 71.22 471342.82 723787.96 83.27 471344.32 723788.05 83.27 471344.32 723788.05 71.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.82 723787.96 71.22 471342.91 723784.42 71.22 471342.91 723784.42 83.27 471342.82 723787.96 83.27 471342.82 723787.96 71.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.91 723784.42 71.22 471344.41 723784.46 71.22 471344.41 723784.46 83.27 471342.91 723784.42 83.27 471342.91 723784.42 71.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.41 723784.46 71.22 471344.48 723781.51 71.22 471344.48 723781.51 83.27 471344.41 723784.46 83.27 471344.41 723784.46 71.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.48 723781.51 71.22 471354.72 723782.03 71.22 471354.72 723782.03 83.27 471344.48 723781.51 83.27 471344.48 723781.51 71.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.72 723782.03 71.22 471354.71 723782.41 71.22 471354.71 723782.41 83.27 471354.72 723782.03 83.27 471354.72 723782.03 71.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.71 723782.41 71.22 471353.82 723782.38 71.22 471353.82 723782.38 83.27 471354.71 723782.41 83.27 471354.71 723782.41 71.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.82 723782.38 71.22 471353.75 723784.68 71.22 471353.75 723784.68 83.27 471353.82 723782.38 83.27 471353.82 723782.38 71.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.75 723784.68 71.22 471354.65 723784.71 71.22 471354.65 723784.71 83.27 471353.75 723784.68 83.27 471353.75 723784.68 71.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.65 723784.71 71.22 471354.55 723788.63 71.22 471354.55 723788.63 83.27 471354.65 723784.71 83.27 471354.65 723784.71 71.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F5-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.55 723788.63 83.27 471344.32 723788.05 83.27 471342.82 723787.96 83.27 471342.91 723784.42 83.27 471344.41 723784.46 83.27 471344.48 723781.51 83.27 471354.72 723782.03 83.27 471354.71 723782.41 83.27 471353.82 723782.38 83.27 471353.75 723784.68 83.27 471354.65 723784.71 83.27 471354.55 723788.63 83.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.72 723782.03 67.95 471354.81 723778.11 67.95 471353.92 723778.09 67.95 471353.98 723775.78 67.95 471354.88 723775.81 67.95 471354.88 723775.46 67.95 471344.64 723774.97 67.95 471344.57 723777.91 67.95 471343.06 723777.88 67.95 471342.97 723781.44 67.95 471344.48 723781.51 67.95 471354.72 723782.03 67.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.72 723782.03 67.95 471344.48 723781.51 67.95 471344.48 723781.51 80.27 471354.72 723782.03 80.27 471354.72 723782.03 67.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.48 723781.51 67.95 471342.97 723781.44 67.95 471342.97 723781.44 80.27 471344.48 723781.51 80.27 471344.48 723781.51 67.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.97 723781.44 67.95 471343.06 723777.88 67.95 471343.06 723777.88 80.27 471342.97 723781.44 80.27 471342.97 723781.44 67.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471343.06 723777.88 67.95 471344.57 723777.91 67.95 471344.57 723777.91 80.27 471343.06 723777.88 80.27 471343.06 723777.88 67.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.57 723777.91 67.95 471344.64 723774.97 67.95 471344.64 723774.97 80.27 471344.57 723777.91 80.27 471344.57 723777.91 67.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.64 723774.97 67.95 471354.88 723775.46 67.95 471354.88 723775.46 80.27 471344.64 723774.97 80.27 471344.64 723774.97 67.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.88 723775.46 67.95 471354.88 723775.81 67.95 471354.88 723775.81 80.27 471354.88 723775.46 80.27 471354.88 723775.46 67.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.88 723775.81 67.95 471353.98 723775.78 67.95 471353.98 723775.78 80.27 471354.88 723775.81 80.27 471354.88 723775.81 67.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.98 723775.78 67.95 471353.92 723778.09 67.95 471353.92 723778.09 80.27 471353.98 723775.78 80.27 471353.98 723775.78 67.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.92 723778.09 67.95 471354.81 723778.11 67.95 471354.81 723778.11 80.27 471353.92 723778.09 80.27 471353.92 723778.09 67.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.81 723778.11 67.95 471354.72 723782.03 67.95 471354.72 723782.03 80.27 471354.81 723778.11 80.27 471354.81 723778.11 67.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F3F4-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.72 723782.03 80.27 471344.48 723781.51 80.27 471342.97 723781.44 80.27 471343.06 723777.88 80.27 471344.57 723777.91 80.27 471344.64 723774.97 80.27 471354.88 723775.46 80.27 471354.88 723775.81 80.27 471353.98 723775.78 80.27 471353.92 723778.09 80.27 471354.81 723778.11 80.27 471354.72 723782.03 80.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.38</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.71 723782.95 68.11 471380.81 723778.89 68.11 471379.91 723778.87 68.11 471379.98 723776.57 68.11 471380.87 723776.6 68.11 471380.88 723776.38 68.11 471370.57 723776.06 68.11 471370.49 723778.8 68.11 471368.99 723778.76 68.11 471368.89 723782.39 68.11 471370.38 723782.43 68.11 471370.38 723782.64 68.11 471380.71 723782.95 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.71 723782.95 68.11 471370.38 723782.64 68.11 471370.38 723782.64 80.49 471380.71 723782.95 80.49 471380.71 723782.95 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.38 723782.64 68.11 471370.38 723782.43 68.11 471370.38 723782.43 80.49 471370.38 723782.64 80.49 471370.38 723782.64 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.38 723782.43 68.11 471368.89 723782.39 68.11 471368.89 723782.39 80.49 471370.38 723782.43 80.49 471370.38 723782.43 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.89 723782.39 68.11 471368.99 723778.76 68.11 471368.99 723778.76 80.49 471368.89 723782.39 80.49 471368.89 723782.39 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.99 723778.76 68.11 471370.49 723778.8 68.11 471370.49 723778.8 80.49 471368.99 723778.76 80.49 471368.99 723778.76 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.49 723778.8 68.11 471370.57 723776.06 68.11 471370.57 723776.06 80.49 471370.49 723778.8 80.49 471370.49 723778.8 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.57 723776.06 68.11 471380.88 723776.38 68.11 471380.88 723776.38 80.49 471370.57 723776.06 80.49 471370.57 723776.06 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.88 723776.38 68.11 471380.87 723776.6 68.11 471380.87 723776.6 80.49 471380.88 723776.38 80.49 471380.88 723776.38 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.87 723776.6 68.11 471379.98 723776.57 68.11 471379.98 723776.57 80.49 471380.87 723776.6 80.49 471380.87 723776.6 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.98 723776.57 68.11 471379.91 723778.87 68.11 471379.91 723778.87 80.49 471379.98 723776.57 80.49 471379.98 723776.57 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.91 723778.87 68.11 471380.81 723778.89 68.11 471380.81 723778.89 80.49 471379.91 723778.87 80.49 471379.91 723778.87 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.81 723778.89 68.11 471380.71 723782.95 68.11 471380.71 723782.95 80.49 471380.81 723778.89 80.49 471380.81 723778.89 68.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58C-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.71 723782.95 80.49 471370.38 723782.64 80.49 471370.38 723782.43 80.49 471368.89 723782.39 80.49 471368.99 723778.76 80.49 471370.49 723778.8 80.49 471370.57 723776.06 80.49 471380.88 723776.38 80.49 471380.87 723776.6 80.49 471379.98 723776.57 80.49 471379.91 723778.87 80.49 471380.81 723778.89 80.49 471380.71 723782.95 80.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.9</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.55 723789.52 70.71 471380.65 723785.49 70.71 471379.75 723785.47 70.71 471379.81 723783.11 70.71 471380.71 723783.14 70.71 471380.71 723782.95 70.71 471370.38 723782.64 70.71 471370.31 723785.41 70.71 471368.81 723785.37 70.71 471368.7 723789 70.71 471370.2 723789.04 70.71 471370.19 723789.21 70.71 471380.55 723789.52 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.55 723789.52 70.71 471370.19 723789.21 70.71 471370.19 723789.21 83.605 471380.55 723789.52 83.605 471380.55 723789.52 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.19 723789.21 70.71 471370.2 723789.04 70.71 471370.2 723789.04 83.605 471370.19 723789.21 83.605 471370.19 723789.21 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.2 723789.04 70.71 471368.7 723789 70.71 471368.7 723789 83.605 471370.2 723789.04 83.605 471370.2 723789.04 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.7 723789 70.71 471368.81 723785.37 70.71 471368.81 723785.37 83.605 471368.7 723789 83.605 471368.7 723789 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.81 723785.37 70.71 471370.31 723785.41 70.71 471370.31 723785.41 83.605 471368.81 723785.37 83.605 471368.81 723785.37 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.31 723785.41 70.71 471370.38 723782.64 70.71 471370.38 723782.64 83.605 471370.31 723785.41 83.605 471370.31 723785.41 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.38 723782.64 70.71 471380.71 723782.95 70.71 471380.71 723782.95 83.605 471370.38 723782.64 83.605 471370.38 723782.64 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.71 723782.95 70.71 471380.71 723783.14 70.71 471380.71 723783.14 83.605 471380.71 723782.95 83.605 471380.71 723782.95 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.71 723783.14 70.71 471379.81 723783.11 70.71 471379.81 723783.11 83.605 471380.71 723783.14 83.605 471380.71 723783.14 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.81 723783.11 70.71 471379.75 723785.47 70.71 471379.75 723785.47 83.605 471379.81 723783.11 83.605 471379.81 723783.11 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.75 723785.47 70.71 471380.65 723785.49 70.71 471380.65 723785.49 83.605 471379.75 723785.47 83.605 471379.75 723785.47 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.65 723785.49 70.71 471380.55 723789.52 70.71 471380.55 723789.52 83.605 471380.65 723785.49 83.605 471380.65 723785.49 70.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F58B-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.55 723789.52 83.605 471370.19 723789.21 83.605 471370.2 723789.04 83.605 471368.7 723789 83.605 471368.81 723785.37 83.605 471370.31 723785.41 83.605 471370.38 723782.64 83.605 471380.71 723782.95 83.605 471380.71 723783.14 83.605 471379.81 723783.11 83.605 471379.75 723785.47 83.605 471380.65 723785.49 83.605 471380.55 723789.52 83.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4BA6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4BA6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.24</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471531.64 725792.76 58.95 471535.06 725784.13 58.95 471521.17 725778.62 58.95 471517.72 725787.28 58.95 471531.64 725792.76 58.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471531.64 725792.76 58.95 471517.72 725787.28 58.95 471517.72 725787.28 66.19 471531.64 725792.76 66.19 471531.64 725792.76 58.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471517.72 725787.28 58.95 471521.17 725778.62 58.95 471521.17 725778.62 66.19 471517.72 725787.28 66.19 471517.72 725787.28 58.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471521.17 725778.62 58.95 471535.06 725784.13 58.95 471535.06 725784.13 66.19 471521.17 725778.62 66.19 471521.17 725778.62 58.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471535.06 725784.13 58.95 471531.64 725792.76 58.95 471531.64 725792.76 66.19 471535.06 725784.13 66.19 471535.06 725784.13 58.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471531.64 725792.76 66.19 471517.72 725787.28 66.19 471521.17 725778.62 66.19 471535.06 725784.13 66.19 471531.64 725792.76 66.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F587-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.26</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.39 723796.08 74.28 471380.48 723792.14 74.28 471379.58 723792.11 74.28 471379.64 723789.76 74.28 471380.54 723789.79 74.28 471380.55 723789.52 74.28 471370.19 723789.21 74.28 471370.11 723792.01 74.28 471368.62 723791.98 74.28 471368.52 723795.61 74.28 471370.02 723795.63 74.28 471370.01 723795.76 74.28 471380.39 723796.08 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.39 723796.08 74.28 471370.01 723795.76 74.28 471370.01 723795.76 86.54 471380.39 723796.08 86.54 471380.39 723796.08 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.01 723795.76 74.28 471370.02 723795.63 74.28 471370.02 723795.63 86.54 471370.01 723795.76 86.54 471370.01 723795.76 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.02 723795.63 74.28 471368.52 723795.61 74.28 471368.52 723795.61 86.54 471370.02 723795.63 86.54 471370.02 723795.63 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.52 723795.61 74.28 471368.62 723791.98 74.28 471368.62 723791.98 86.54 471368.52 723795.61 86.54 471368.52 723795.61 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.62 723791.98 74.28 471370.11 723792.01 74.28 471370.11 723792.01 86.54 471368.62 723791.98 86.54 471368.62 723791.98 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.11 723792.01 74.28 471370.19 723789.21 74.28 471370.19 723789.21 86.54 471370.11 723792.01 86.54 471370.11 723792.01 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.19 723789.21 74.28 471380.55 723789.52 74.28 471380.55 723789.52 86.54 471370.19 723789.21 86.54 471370.19 723789.21 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.55 723789.52 74.28 471380.54 723789.79 74.28 471380.54 723789.79 86.54 471380.55 723789.52 86.54 471380.55 723789.52 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.54 723789.79 74.28 471379.64 723789.76 74.28 471379.64 723789.76 86.54 471380.54 723789.79 86.54 471380.54 723789.79 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.64 723789.76 74.28 471379.58 723792.11 74.28 471379.58 723792.11 86.54 471379.64 723789.76 86.54 471379.64 723789.76 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.58 723792.11 74.28 471380.48 723792.14 74.28 471380.48 723792.14 86.54 471379.58 723792.11 86.54 471379.58 723792.11 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.48 723792.14 74.28 471380.39 723796.08 74.28 471380.39 723796.08 86.54 471380.48 723792.14 86.54 471380.48 723792.14 74.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F587-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.39 723796.08 86.54 471370.01 723795.76 86.54 471370.02 723795.63 86.54 471368.52 723795.61 86.54 471368.62 723791.98 86.54 471370.11 723792.01 86.54 471370.19 723789.21 86.54 471380.55 723789.52 86.54 471380.54 723789.79 86.54 471379.64 723789.76 86.54 471379.58 723792.11 86.54 471380.48 723792.14 86.54 471380.39 723796.08 86.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.33</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.88 723776.38 65.19 471380.98 723772.3 65.19 471380.08 723772.28 65.19 471380.14 723769.93 65.19 471381.04 723769.95 65.19 471381.04 723769.81 65.19 471370.74 723769.49 65.19 471370.67 723772.19 65.19 471369.17 723772.15 65.19 471369.07 723775.78 65.19 471370.56 723775.83 65.19 471370.57 723776.06 65.19 471380.88 723776.38 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.88 723776.38 65.19 471370.57 723776.06 65.19 471370.57 723776.06 77.52 471380.88 723776.38 77.52 471380.88 723776.38 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.57 723776.06 65.19 471370.56 723775.83 65.19 471370.56 723775.83 77.52 471370.57 723776.06 77.52 471370.57 723776.06 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.56 723775.83 65.19 471369.07 723775.78 65.19 471369.07 723775.78 77.52 471370.56 723775.83 77.52 471370.56 723775.83 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.07 723775.78 65.19 471369.17 723772.15 65.19 471369.17 723772.15 77.52 471369.07 723775.78 77.52 471369.07 723775.78 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.17 723772.15 65.19 471370.67 723772.19 65.19 471370.67 723772.19 77.52 471369.17 723772.15 77.52 471369.17 723772.15 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.67 723772.19 65.19 471370.74 723769.49 65.19 471370.74 723769.49 77.52 471370.67 723772.19 77.52 471370.67 723772.19 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.74 723769.49 65.19 471381.04 723769.81 65.19 471381.04 723769.81 77.52 471370.74 723769.49 77.52 471370.74 723769.49 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.04 723769.81 65.19 471381.04 723769.95 65.19 471381.04 723769.95 77.52 471381.04 723769.81 77.52 471381.04 723769.81 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.04 723769.95 65.19 471380.14 723769.93 65.19 471380.14 723769.93 77.52 471381.04 723769.95 77.52 471381.04 723769.95 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.14 723769.93 65.19 471380.08 723772.28 65.19 471380.08 723772.28 77.52 471380.14 723769.93 77.52 471380.14 723769.93 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.08 723772.28 65.19 471380.98 723772.3 65.19 471380.98 723772.3 77.52 471380.08 723772.28 77.52 471380.08 723772.28 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.98 723772.3 65.19 471380.88 723776.38 65.19 471380.88 723776.38 77.52 471380.98 723772.3 77.52 471380.98 723772.3 65.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F4BB-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.88 723776.38 77.52 471370.57 723776.06 77.52 471370.56 723775.83 77.52 471369.07 723775.78 77.52 471369.17 723772.15 77.52 471370.67 723772.19 77.52 471370.74 723769.49 77.52 471381.04 723769.81 77.52 471381.04 723769.95 77.52 471380.14 723769.93 77.52 471380.08 723772.28 77.52 471380.98 723772.3 77.52 471380.88 723776.38 77.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F277-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.69</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.42 723798.06 66.52 471449.48 723795.64 66.52 471450.43 723795.65 66.52 471450.54 723791.49 66.52 471438.82 723791.07 66.52 471438.82 723791.44 66.52 471440.32 723791.48 66.52 471440.23 723794.46 66.52 471438.73 723794.42 66.52 471438.64 723797.67 66.52 471449.42 723798.06 66.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.42 723798.06 66.52 471438.64 723797.67 66.52 471438.64 723797.67 76.21000000000001 471449.42 723798.06 76.21000000000001 471449.42 723798.06 66.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.64 723797.67 66.52 471438.73 723794.42 66.52 471438.73 723794.42 76.21000000000001 471438.64 723797.67 76.21000000000001 471438.64 723797.67 66.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.73 723794.42 66.52 471440.23 723794.46 66.52 471440.23 723794.46 76.21000000000001 471438.73 723794.42 76.21000000000001 471438.73 723794.42 66.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471440.23 723794.46 66.52 471440.32 723791.48 66.52 471440.32 723791.48 76.21000000000001 471440.23 723794.46 76.21000000000001 471440.23 723794.46 66.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471440.32 723791.48 66.52 471438.82 723791.44 66.52 471438.82 723791.44 76.21000000000001 471440.32 723791.48 76.21000000000001 471440.32 723791.48 66.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.82 723791.44 66.52 471438.82 723791.07 66.52 471438.82 723791.07 76.21000000000001 471438.82 723791.44 76.21000000000001 471438.82 723791.44 66.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.82 723791.07 66.52 471450.54 723791.49 66.52 471450.54 723791.49 76.21000000000001 471438.82 723791.07 76.21000000000001 471438.82 723791.07 66.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.54 723791.49 66.52 471450.43 723795.65 66.52 471450.43 723795.65 76.21000000000001 471450.54 723791.49 76.21000000000001 471450.54 723791.49 66.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.43 723795.65 66.52 471449.48 723795.64 66.52 471449.48 723795.64 76.21000000000001 471450.43 723795.65 76.21000000000001 471450.43 723795.65 66.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.48 723795.64 66.52 471449.42 723798.06 66.52 471449.42 723798.06 76.21000000000001 471449.48 723795.64 76.21000000000001 471449.48 723795.64 66.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F277-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.42 723798.06 76.21000000000001 471438.64 723797.67 76.21000000000001 471438.73 723794.42 76.21000000000001 471440.23 723794.46 76.21000000000001 471440.32 723791.48 76.21000000000001 471438.82 723791.44 76.21000000000001 471438.82 723791.07 76.21000000000001 471450.54 723791.49 76.21000000000001 471450.43 723795.65 76.21000000000001 471449.48 723795.64 76.21000000000001 471449.42 723798.06 76.21000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F278-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.14</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471451.09 723771.74 60.4 471451.12 723771.29 60.4 471450.17 723771.26 60.4 471450.22 723768.86 60.4 471451.18 723768.9 60.4 471451.3 723764.64 60.4 471441.08 723764.27 60.4 471441 723767.94 60.4 471439.51 723767.89 60.4 471439.41 723771.28 60.4 471451.09 723771.74 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471451.09 723771.74 60.4 471439.41 723771.28 60.4 471439.41 723771.28 68.54 471451.09 723771.74 68.54 471451.09 723771.74 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.41 723771.28 60.4 471439.51 723767.89 60.4 471439.51 723767.89 68.54 471439.41 723771.28 68.54 471439.41 723771.28 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.51 723767.89 60.4 471441 723767.94 60.4 471441 723767.94 68.54 471439.51 723767.89 68.54 471439.51 723767.89 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471441 723767.94 60.4 471441.08 723764.27 60.4 471441.08 723764.27 68.54 471441 723767.94 68.54 471441 723767.94 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471441.08 723764.27 60.4 471451.3 723764.64 60.4 471451.3 723764.64 68.54 471441.08 723764.27 68.54 471441.08 723764.27 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471451.3 723764.64 60.4 471451.18 723768.9 60.4 471451.18 723768.9 68.54 471451.3 723764.64 68.54 471451.3 723764.64 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471451.18 723768.9 60.4 471450.22 723768.86 60.4 471450.22 723768.86 68.54 471451.18 723768.9 68.54 471451.18 723768.9 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.22 723768.86 60.4 471450.17 723771.26 60.4 471450.17 723771.26 68.54 471450.22 723768.86 68.54 471450.22 723768.86 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.17 723771.26 60.4 471451.12 723771.29 60.4 471451.12 723771.29 68.54 471450.17 723771.26 68.54 471450.17 723771.26 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471451.12 723771.29 60.4 471451.09 723771.74 60.4 471451.09 723771.74 68.54 471451.12 723771.29 68.54 471451.12 723771.29 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F278-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471451.09 723771.74 68.54 471439.41 723771.28 68.54 471439.51 723767.89 68.54 471441 723767.94 68.54 471441.08 723764.27 68.54 471451.3 723764.64 68.54 471451.18 723768.9 68.54 471450.22 723768.86 68.54 471450.17 723771.26 68.54 471451.12 723771.29 68.54 471451.09 723771.74 68.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6402-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6402-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.05</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6402-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.4 723753.27 59.9 471475.29 723756.41 59.9 471475.19 723759.41 59.9 471475.07 723762.54 59.9 471481.12 723762.74 59.9 471481.2 723759.57 59.9 471481.3 723756.59 59.9 471481.4 723753.45 59.9 471475.4 723753.27 59.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6402-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.4 723753.27 59.9 471481.4 723753.45 59.9 471481.4 723753.45 62.95 471475.4 723753.27 62.95 471475.4 723753.27 59.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6402-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471481.4 723753.45 59.9 471481.3 723756.59 59.9 471481.3 723756.59 62.95 471481.4 723753.45 62.95 471481.4 723753.45 59.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6402-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471481.3 723756.59 59.9 471481.2 723759.57 59.9 471481.2 723759.57 62.95 471481.3 723756.59 62.95 471481.3 723756.59 59.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6402-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471481.2 723759.57 59.9 471481.12 723762.74 59.9 471481.12 723762.74 62.95 471481.2 723759.57 62.95 471481.2 723759.57 59.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6402-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471481.12 723762.74 59.9 471475.07 723762.54 59.9 471475.07 723762.54 62.95 471481.12 723762.74 62.95 471481.12 723762.74 59.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6402-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.07 723762.54 59.9 471475.19 723759.41 59.9 471475.19 723759.41 62.95 471475.07 723762.54 62.95 471475.07 723762.54 59.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6402-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.19 723759.41 59.9 471475.29 723756.41 59.9 471475.29 723756.41 62.95 471475.19 723759.41 62.95 471475.19 723759.41 59.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6402-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.29 723756.41 59.9 471475.4 723753.27 59.9 471475.4 723753.27 62.95 471475.29 723756.41 62.95 471475.29 723756.41 59.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6402-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471475.4 723753.27 62.95 471481.4 723753.45 62.95 471481.3 723756.59 62.95 471481.2 723759.57 62.95 471481.12 723762.74 62.95 471475.07 723762.54 62.95 471475.19 723759.41 62.95 471475.29 723756.41 62.95 471475.4 723753.27 62.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6400-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6400-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.74</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6400-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.87 723755.78 60.31 471455.96 723752.67 60.31 471449.67 723752.5 60.31 471449.55 723755.63 60.31 471449.43 723758.62 60.31 471449.31 723761.75 60.31 471455.69 723761.87 60.31 471455.78 723758.77 60.31 471455.87 723755.78 60.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6400-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.87 723755.78 60.31 471455.78 723758.77 60.31 471455.78 723758.77 63.050000000000004 471455.87 723755.78 63.050000000000004 471455.87 723755.78 60.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6400-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.78 723758.77 60.31 471455.69 723761.87 60.31 471455.69 723761.87 63.050000000000004 471455.78 723758.77 63.050000000000004 471455.78 723758.77 60.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6400-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.69 723761.87 60.31 471449.31 723761.75 60.31 471449.31 723761.75 63.050000000000004 471455.69 723761.87 63.050000000000004 471455.69 723761.87 60.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6400-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.31 723761.75 60.31 471449.43 723758.62 60.31 471449.43 723758.62 63.050000000000004 471449.31 723761.75 63.050000000000004 471449.31 723761.75 60.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6400-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.43 723758.62 60.31 471449.55 723755.63 60.31 471449.55 723755.63 63.050000000000004 471449.43 723758.62 63.050000000000004 471449.43 723758.62 60.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6400-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.55 723755.63 60.31 471449.67 723752.5 60.31 471449.67 723752.5 63.050000000000004 471449.55 723755.63 63.050000000000004 471449.55 723755.63 60.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6400-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.67 723752.5 60.31 471455.96 723752.67 60.31 471455.96 723752.67 63.050000000000004 471449.67 723752.5 63.050000000000004 471449.67 723752.5 60.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6400-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.96 723752.67 60.31 471455.87 723755.78 60.31 471455.87 723755.78 63.050000000000004 471455.96 723752.67 63.050000000000004 471455.96 723752.67 60.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6400-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.87 723755.78 63.050000000000004 471455.78 723758.77 63.050000000000004 471455.69 723761.87 63.050000000000004 471449.31 723761.75 63.050000000000004 471449.43 723758.62 63.050000000000004 471449.55 723755.63 63.050000000000004 471449.67 723752.5 63.050000000000004 471455.96 723752.67 63.050000000000004 471455.87 723755.78 63.050000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6401-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6401-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.72</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6401-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.98 723756.03 60.02 471466.02 723752.93 60.02 471459.71 723752.74 60.02 471459.63 723755.89 60.02 471459.56 723758.94 60.02 471459.47 723762.07 60.02 471465.89 723762.22 60.02 471465.94 723759.07 60.02 471465.98 723756.03 60.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6401-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.98 723756.03 60.02 471465.94 723759.07 60.02 471465.94 723759.07 62.74 471465.98 723756.03 62.74 471465.98 723756.03 60.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6401-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.94 723759.07 60.02 471465.89 723762.22 60.02 471465.89 723762.22 62.74 471465.94 723759.07 62.74 471465.94 723759.07 60.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6401-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.89 723762.22 60.02 471459.47 723762.07 60.02 471459.47 723762.07 62.74 471465.89 723762.22 62.74 471465.89 723762.22 60.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6401-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471459.47 723762.07 60.02 471459.56 723758.94 60.02 471459.56 723758.94 62.74 471459.47 723762.07 62.74 471459.47 723762.07 60.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6401-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471459.56 723758.94 60.02 471459.63 723755.89 60.02 471459.63 723755.89 62.74 471459.56 723758.94 62.74 471459.56 723758.94 60.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6401-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471459.63 723755.89 60.02 471459.71 723752.74 60.02 471459.71 723752.74 62.74 471459.63 723755.89 62.74 471459.63 723755.89 60.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6401-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471459.71 723752.74 60.02 471466.02 723752.93 60.02 471466.02 723752.93 62.74 471459.71 723752.74 62.74 471459.71 723752.74 60.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6401-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471466.02 723752.93 60.02 471465.98 723756.03 60.02 471465.98 723756.03 62.74 471466.02 723752.93 62.74 471466.02 723752.93 60.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6401-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471465.98 723756.03 62.74 471465.94 723759.07 62.74 471465.89 723762.22 62.74 471459.47 723762.07 62.74 471459.56 723758.94 62.74 471459.63 723755.89 62.74 471459.71 723752.74 62.74 471466.02 723752.93 62.74 471465.98 723756.03 62.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">11.2</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471505.86 725708.03 71 471519.64 725715 71 471518.27 725717.77 71 471526.59 725722.02 71 471537.72 725700.04 71 471541.18 725701.82 71 471542.98 725698.35 71 471531.26 725692.42 71 471524.21 725706.06 71 471510.31 725699.05 71 471505.86 725708.03 71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471505.86 725708.03 71 471510.31 725699.05 71 471510.31 725699.05 82.2 471505.86 725708.03 82.2 471505.86 725708.03 71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471510.31 725699.05 71 471524.21 725706.06 71 471524.21 725706.06 82.2 471510.31 725699.05 82.2 471510.31 725699.05 71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471524.21 725706.06 71 471531.26 725692.42 71 471531.26 725692.42 82.2 471524.21 725706.06 82.2 471524.21 725706.06 71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471531.26 725692.42 71 471542.98 725698.35 71 471542.98 725698.35 82.2 471531.26 725692.42 82.2 471531.26 725692.42 71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471542.98 725698.35 71 471541.18 725701.82 71 471541.18 725701.82 82.2 471542.98 725698.35 82.2 471542.98 725698.35 71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471541.18 725701.82 71 471537.72 725700.04 71 471537.72 725700.04 82.2 471541.18 725701.82 82.2 471541.18 725701.82 71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471537.72 725700.04 71 471526.59 725722.02 71 471526.59 725722.02 82.2 471537.72 725700.04 82.2 471537.72 725700.04 71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471526.59 725722.02 71 471518.27 725717.77 71 471518.27 725717.77 82.2 471526.59 725722.02 82.2 471526.59 725722.02 71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471518.27 725717.77 71 471519.64 725715 71 471519.64 725715 82.2 471518.27 725717.77 82.2 471518.27 725717.77 71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471519.64 725715 71 471505.86 725708.03 71 471505.86 725708.03 82.2 471519.64 725715 82.2 471519.64 725715 71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4BA4-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471505.86 725708.03 82.2 471510.31 725699.05 82.2 471524.21 725706.06 82.2 471531.26 725692.42 82.2 471542.98 725698.35 82.2 471541.18 725701.82 82.2 471537.72 725700.04 82.2 471526.59 725722.02 82.2 471518.27 725717.77 82.2 471519.64 725715 82.2 471505.86 725708.03 82.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-633F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-633F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.08</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-633F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.28 723748.16 61.61 471305.16 723751.22 61.61 471305.05 723754.23 61.61 471311.56 723754.39 61.61 471311.67 723751.39 61.61 471311.77 723748.32 61.61 471305.28 723748.16 61.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-633F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.28 723748.16 61.61 471311.77 723748.32 61.61 471311.77 723748.32 64.69 471305.28 723748.16 64.69 471305.28 723748.16 61.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-633F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.77 723748.32 61.61 471311.67 723751.39 61.61 471311.67 723751.39 64.69 471311.77 723748.32 64.69 471311.77 723748.32 61.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-633F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.67 723751.39 61.61 471311.56 723754.39 61.61 471311.56 723754.39 64.69 471311.67 723751.39 64.69 471311.67 723751.39 61.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-633F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.56 723754.39 61.61 471305.05 723754.23 61.61 471305.05 723754.23 64.69 471311.56 723754.39 64.69 471311.56 723754.39 61.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-633F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.05 723754.23 61.61 471305.16 723751.22 61.61 471305.16 723751.22 64.69 471305.05 723754.23 64.69 471305.05 723754.23 61.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-633F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.16 723751.22 61.61 471305.28 723748.16 61.61 471305.28 723748.16 64.69 471305.16 723751.22 64.69 471305.16 723751.22 61.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-633F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.28 723748.16 64.69 471311.77 723748.32 64.69 471311.67 723751.39 64.69 471311.56 723754.39 64.69 471305.05 723754.23 64.69 471305.16 723751.22 64.69 471305.28 723748.16 64.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-63FF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-63FF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63FF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471441.47 723755.49 60.4 471441.53 723752.38 60.4 471435.03 723752.17 60.4 471434.97 723755.27 60.4 471434.92 723758.31 60.4 471434.85 723761.4 60.4 471441.38 723761.68 60.4 471441.43 723758.59 60.4 471441.47 723755.49 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63FF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471441.47 723755.49 60.4 471441.43 723758.59 60.4 471441.43 723758.59 63.21 471441.47 723755.49 63.21 471441.47 723755.49 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63FF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471441.43 723758.59 60.4 471441.38 723761.68 60.4 471441.38 723761.68 63.21 471441.43 723758.59 63.21 471441.43 723758.59 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63FF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471441.38 723761.68 60.4 471434.85 723761.4 60.4 471434.85 723761.4 63.21 471441.38 723761.68 63.21 471441.38 723761.68 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63FF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471434.85 723761.4 60.4 471434.92 723758.31 60.4 471434.92 723758.31 63.21 471434.85 723761.4 63.21 471434.85 723761.4 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63FF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471434.92 723758.31 60.4 471434.97 723755.27 60.4 471434.97 723755.27 63.21 471434.92 723758.31 63.21 471434.92 723758.31 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63FF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471434.97 723755.27 60.4 471435.03 723752.17 60.4 471435.03 723752.17 63.21 471434.97 723755.27 63.21 471434.97 723755.27 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63FF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471435.03 723752.17 60.4 471441.53 723752.38 60.4 471441.53 723752.38 63.21 471435.03 723752.17 63.21 471435.03 723752.17 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63FF-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471441.53 723752.38 60.4 471441.47 723755.49 60.4 471441.47 723755.49 63.21 471441.53 723752.38 63.21 471441.53 723752.38 60.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63FF-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471441.47 723755.49 63.21 471441.43 723758.59 63.21 471441.38 723761.68 63.21 471434.85 723761.4 63.21 471434.92 723758.31 63.21 471434.97 723755.27 63.21 471435.03 723752.17 63.21 471441.53 723752.38 63.21 471441.47 723755.49 63.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6346-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6346-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.74</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6346-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.5 723749.39 61.45 471353.34 723752.6 61.45 471353.21 723755.72 61.45 471360.14 723755.81 61.45 471360.24 723752.72 61.45 471360.33 723749.58 61.45 471353.5 723749.39 61.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6346-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.5 723749.39 61.45 471360.33 723749.58 61.45 471360.33 723749.58 64.19 471353.5 723749.39 64.19 471353.5 723749.39 61.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6346-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471360.33 723749.58 61.45 471360.24 723752.72 61.45 471360.24 723752.72 64.19 471360.33 723749.58 64.19 471360.33 723749.58 61.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6346-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471360.24 723752.72 61.45 471360.14 723755.81 61.45 471360.14 723755.81 64.19 471360.24 723752.72 64.19 471360.24 723752.72 61.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6346-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471360.14 723755.81 61.45 471353.21 723755.72 61.45 471353.21 723755.72 64.19 471360.14 723755.81 64.19 471360.14 723755.81 61.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6346-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.21 723755.72 61.45 471353.34 723752.6 61.45 471353.34 723752.6 64.19 471353.21 723755.72 64.19 471353.21 723755.72 61.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6346-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.34 723752.6 61.45 471353.5 723749.39 61.45 471353.5 723749.39 64.19 471353.34 723752.6 64.19 471353.34 723752.6 61.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6346-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.5 723749.39 64.19 471360.33 723749.58 64.19 471360.24 723752.72 64.19 471360.14 723755.81 64.19 471353.21 723755.72 64.19 471353.34 723752.6 64.19 471353.5 723749.39 64.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6345-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.05 723759.02 61.58 471352.8 723759.04 61.58 471352.61 723761.84 61.58 471355.22 723761.92 61.58 471355.21 723762.37 61.58 471356.66 723762.34 61.58 471358.91 723761.12 61.58 471360.04 723758.92 61.58 471360.14 723755.81 61.58 471353.21 723755.72 61.58 471353.05 723759.02 61.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.05 723759.02 61.58 471353.21 723755.72 61.58 471353.21 723755.72 64.42 471353.05 723759.02 64.42 471353.05 723759.02 61.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.21 723755.72 61.58 471360.14 723755.81 61.58 471360.14 723755.81 64.42 471353.21 723755.72 64.42 471353.21 723755.72 61.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471360.14 723755.81 61.58 471360.04 723758.92 61.58 471360.04 723758.92 64.42 471360.14 723755.81 64.42 471360.14 723755.81 61.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471360.04 723758.92 61.58 471358.91 723761.12 61.58 471358.91 723761.12 64.42 471360.04 723758.92 64.42 471360.04 723758.92 61.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471358.91 723761.12 61.58 471356.66 723762.34 61.58 471356.66 723762.34 64.42 471358.91 723761.12 64.42 471358.91 723761.12 61.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471356.66 723762.34 61.58 471355.21 723762.37 61.58 471355.21 723762.37 64.42 471356.66 723762.34 64.42 471356.66 723762.34 61.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.21 723762.37 61.58 471355.22 723761.92 61.58 471355.22 723761.92 64.42 471355.21 723762.37 64.42 471355.21 723762.37 61.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.22 723761.92 61.58 471352.61 723761.84 61.58 471352.61 723761.84 64.42 471355.22 723761.92 64.42 471355.22 723761.92 61.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471352.61 723761.84 61.58 471352.8 723759.04 61.58 471352.8 723759.04 64.42 471352.61 723761.84 64.42 471352.61 723761.84 61.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471352.8 723759.04 61.58 471353.05 723759.02 61.58 471353.05 723759.02 64.42 471352.8 723759.04 64.42 471352.8 723759.04 61.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6345-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.05 723759.02 64.42 471353.21 723755.72 64.42 471360.14 723755.81 64.42 471360.04 723758.92 64.42 471358.91 723761.12 64.42 471356.66 723762.34 64.42 471355.21 723762.37 64.42 471355.22 723761.92 64.42 471352.61 723761.84 64.42 471352.8 723759.04 64.42 471353.05 723759.02 64.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6343-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6343-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.72</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6343-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.51 723755.21 61.69 471338.38 723758.31 61.69 471337.27 723758.34 61.69 471335.53 723760.24 61.69 471335.55 723761.21 61.69 471344.97 723761.6 61.69 471345.25 723758.74 61.69 471345.65 723758.76 61.69 471345.78 723755.52 61.69 471338.51 723755.21 61.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6343-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.51 723755.21 61.69 471345.78 723755.52 61.69 471345.78 723755.52 64.41 471338.51 723755.21 64.41 471338.51 723755.21 61.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6343-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.78 723755.52 61.69 471345.65 723758.76 61.69 471345.65 723758.76 64.41 471345.78 723755.52 64.41 471345.78 723755.52 61.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6343-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.65 723758.76 61.69 471345.25 723758.74 61.69 471345.25 723758.74 64.41 471345.65 723758.76 64.41 471345.65 723758.76 61.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6343-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.25 723758.74 61.69 471344.97 723761.6 61.69 471344.97 723761.6 64.41 471345.25 723758.74 64.41 471345.25 723758.74 61.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6343-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.97 723761.6 61.69 471335.55 723761.21 61.69 471335.55 723761.21 64.41 471344.97 723761.6 64.41 471344.97 723761.6 61.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6343-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471335.55 723761.21 61.69 471335.53 723760.24 61.69 471335.53 723760.24 64.41 471335.55 723761.21 64.41 471335.55 723761.21 61.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6343-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471335.53 723760.24 61.69 471337.27 723758.34 61.69 471337.27 723758.34 64.41 471335.53 723760.24 64.41 471335.53 723760.24 61.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6343-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.27 723758.34 61.69 471338.38 723758.31 61.69 471338.38 723758.31 64.41 471337.27 723758.34 64.41 471337.27 723758.34 61.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6343-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.38 723758.31 61.69 471338.51 723755.21 61.69 471338.51 723755.21 64.41 471338.38 723758.31 64.41 471338.38 723758.31 61.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6343-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.51 723755.21 64.41 471345.78 723755.52 64.41 471345.65 723758.76 64.41 471345.25 723758.74 64.41 471344.97 723761.6 64.41 471335.55 723761.21 64.41 471335.53 723760.24 64.41 471337.27 723758.34 64.41 471338.38 723758.31 64.41 471338.51 723755.21 64.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6344-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6344-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.61</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6344-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.74 723749.09 61.55 471338.62 723752.18 61.55 471338.51 723755.21 61.55 471345.78 723755.52 61.55 471345.9 723752.4 61.55 471346.02 723749.17 61.55 471338.74 723749.09 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6344-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.74 723749.09 61.55 471346.02 723749.17 61.55 471346.02 723749.17 64.16 471338.74 723749.09 64.16 471338.74 723749.09 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6344-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471346.02 723749.17 61.55 471345.9 723752.4 61.55 471345.9 723752.4 64.16 471346.02 723749.17 64.16 471346.02 723749.17 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6344-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.9 723752.4 61.55 471345.78 723755.52 61.55 471345.78 723755.52 64.16 471345.9 723752.4 64.16 471345.9 723752.4 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6344-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.78 723755.52 61.55 471338.51 723755.21 61.55 471338.51 723755.21 64.16 471345.78 723755.52 64.16 471345.78 723755.52 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6344-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.51 723755.21 61.55 471338.62 723752.18 61.55 471338.62 723752.18 64.16 471338.51 723755.21 64.16 471338.51 723755.21 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6344-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.62 723752.18 61.55 471338.74 723749.09 61.55 471338.74 723749.09 64.16 471338.62 723752.18 64.16 471338.62 723752.18 61.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6344-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.74 723749.09 64.16 471346.02 723749.17 64.16 471345.9 723752.4 64.16 471345.78 723755.52 64.16 471338.51 723755.21 64.16 471338.62 723752.18 64.16 471338.74 723749.09 64.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6342-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6342-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.83</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6342-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.74 723748.66 61.59 471327.6 723751.7 61.59 471327.45 723754.65 61.59 471327.3 723757.86 61.59 471334.18 723758.03 61.59 471334.33 723754.88 61.59 471334.46 723751.89 61.59 471334.61 723748.9 61.59 471327.74 723748.66 61.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6342-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.74 723748.66 61.59 471334.61 723748.9 61.59 471334.61 723748.9 64.42 471327.74 723748.66 64.42 471327.74 723748.66 61.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6342-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471334.61 723748.9 61.59 471334.46 723751.89 61.59 471334.46 723751.89 64.42 471334.61 723748.9 64.42 471334.61 723748.9 61.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6342-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471334.46 723751.89 61.59 471334.33 723754.88 61.59 471334.33 723754.88 64.42 471334.46 723751.89 64.42 471334.46 723751.89 61.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6342-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471334.33 723754.88 61.59 471334.18 723758.03 61.59 471334.18 723758.03 64.42 471334.33 723754.88 64.42 471334.33 723754.88 61.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6342-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471334.18 723758.03 61.59 471327.3 723757.86 61.59 471327.3 723757.86 64.42 471334.18 723758.03 64.42 471334.18 723758.03 61.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6342-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.3 723757.86 61.59 471327.45 723754.65 61.59 471327.45 723754.65 64.42 471327.3 723757.86 64.42 471327.3 723757.86 61.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6342-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.45 723754.65 61.59 471327.6 723751.7 61.59 471327.6 723751.7 64.42 471327.45 723754.65 64.42 471327.45 723754.65 61.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6342-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.6 723751.7 61.59 471327.74 723748.66 61.59 471327.74 723748.66 64.42 471327.6 723751.7 64.42 471327.6 723751.7 61.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6342-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.74 723748.66 64.42 471334.61 723748.9 64.42 471334.46 723751.89 64.42 471334.33 723754.88 64.42 471334.18 723758.03 64.42 471327.3 723757.86 64.42 471327.45 723754.65 64.42 471327.6 723751.7 64.42 471327.74 723748.66 64.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6341-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6341-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.12</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6341-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.77 723748.32 61.6 471311.67 723751.39 61.6 471311.56 723754.39 61.6 471318.08 723754.56 61.6 471318.18 723751.56 61.6 471318.28 723748.47 61.6 471311.77 723748.32 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6341-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.77 723748.32 61.6 471318.28 723748.47 61.6 471318.28 723748.47 64.72 471311.77 723748.32 64.72 471311.77 723748.32 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6341-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.28 723748.47 61.6 471318.18 723751.56 61.6 471318.18 723751.56 64.72 471318.28 723748.47 64.72 471318.28 723748.47 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6341-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.18 723751.56 61.6 471318.08 723754.56 61.6 471318.08 723754.56 64.72 471318.18 723751.56 64.72 471318.18 723751.56 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6341-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.08 723754.56 61.6 471311.56 723754.39 61.6 471311.56 723754.39 64.72 471318.08 723754.56 64.72 471318.08 723754.56 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6341-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.56 723754.39 61.6 471311.67 723751.39 61.6 471311.67 723751.39 64.72 471311.56 723754.39 64.72 471311.56 723754.39 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6341-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.67 723751.39 61.6 471311.77 723748.32 61.6 471311.77 723748.32 64.72 471311.67 723751.39 64.72 471311.67 723751.39 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6341-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.77 723748.32 64.72 471318.28 723748.47 64.72 471318.18 723751.56 64.72 471318.08 723754.56 64.72 471311.56 723754.39 64.72 471311.67 723751.39 64.72 471311.77 723748.32 64.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.82</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.32 723553.02 79.13 471353.13 723553.62 79.13 471353.31 723553.69 79.13 471351.07 723559.32 79.13 471354.16 723560.52 79.13 471357.05 723561.65 79.13 471359.84 723562.73 79.13 471362.76 723563.86 79.13 471365.58 723564.95 79.13 471368.39 723566.02 79.13 471371.33 723567.16 79.13 471374.26 723568.28 79.13 471377.02 723569.31 79.13 471379.8 723570.35 79.13 471382.57 723571.39 79.13 471385.03 723565.2 79.13 471382.16 723564.12 79.13 471379.34 723563.05 79.13 471376.53 723561.99 79.13 471373.61 723560.89 79.13 471370.74 723559.89 79.13 471367.92 723558.73 79.13 471365.1 723557.66 79.13 471362.28 723556.59 79.13 471359.49 723555.47 79.13 471356.62 723554.32 79.13 471353.32 723553.02 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.32 723553.02 79.13 471356.62 723554.32 79.13 471356.62 723554.32 81.95 471353.32 723553.02 81.95 471353.32 723553.02 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471356.62 723554.32 79.13 471359.49 723555.47 79.13 471359.49 723555.47 81.95 471356.62 723554.32 81.95 471356.62 723554.32 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471359.49 723555.47 79.13 471362.28 723556.59 79.13 471362.28 723556.59 81.95 471359.49 723555.47 81.95 471359.49 723555.47 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471362.28 723556.59 79.13 471365.1 723557.66 79.13 471365.1 723557.66 81.95 471362.28 723556.59 81.95 471362.28 723556.59 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471365.1 723557.66 79.13 471367.92 723558.73 79.13 471367.92 723558.73 81.95 471365.1 723557.66 81.95 471365.1 723557.66 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471367.92 723558.73 79.13 471370.74 723559.89 79.13 471370.74 723559.89 81.95 471367.92 723558.73 81.95 471367.92 723558.73 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.74 723559.89 79.13 471373.61 723560.89 79.13 471373.61 723560.89 81.95 471370.74 723559.89 81.95 471370.74 723559.89 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.61 723560.89 79.13 471376.53 723561.99 79.13 471376.53 723561.99 81.95 471373.61 723560.89 81.95 471373.61 723560.89 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471376.53 723561.99 79.13 471379.34 723563.05 79.13 471379.34 723563.05 81.95 471376.53 723561.99 81.95 471376.53 723561.99 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.34 723563.05 79.13 471382.16 723564.12 79.13 471382.16 723564.12 81.95 471379.34 723563.05 81.95 471379.34 723563.05 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471382.16 723564.12 79.13 471385.03 723565.2 79.13 471385.03 723565.2 81.95 471382.16 723564.12 81.95 471382.16 723564.12 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.03 723565.2 79.13 471382.57 723571.39 79.13 471382.57 723571.39 81.95 471385.03 723565.2 81.95 471385.03 723565.2 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471382.57 723571.39 79.13 471379.8 723570.35 79.13 471379.8 723570.35 81.95 471382.57 723571.39 81.95 471382.57 723571.39 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.8 723570.35 79.13 471377.02 723569.31 79.13 471377.02 723569.31 81.95 471379.8 723570.35 81.95 471379.8 723570.35 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471377.02 723569.31 79.13 471374.26 723568.28 79.13 471374.26 723568.28 81.95 471377.02 723569.31 81.95 471377.02 723569.31 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471374.26 723568.28 79.13 471371.33 723567.16 79.13 471371.33 723567.16 81.95 471374.26 723568.28 81.95 471374.26 723568.28 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.33 723567.16 79.13 471368.39 723566.02 79.13 471368.39 723566.02 81.95 471371.33 723567.16 81.95 471371.33 723567.16 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.39 723566.02 79.13 471365.58 723564.95 79.13 471365.58 723564.95 81.95 471368.39 723566.02 81.95 471368.39 723566.02 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471365.58 723564.95 79.13 471362.76 723563.86 79.13 471362.76 723563.86 81.95 471365.58 723564.95 81.95 471365.58 723564.95 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471362.76 723563.86 79.13 471359.84 723562.73 79.13 471359.84 723562.73 81.95 471362.76 723563.86 81.95 471362.76 723563.86 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471359.84 723562.73 79.13 471357.05 723561.65 79.13 471357.05 723561.65 81.95 471359.84 723562.73 81.95 471359.84 723562.73 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471357.05 723561.65 79.13 471354.16 723560.52 79.13 471354.16 723560.52 81.95 471357.05 723561.65 81.95 471357.05 723561.65 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.16 723560.52 79.13 471351.07 723559.32 79.13 471351.07 723559.32 81.95 471354.16 723560.52 81.95 471354.16 723560.52 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471351.07 723559.32 79.13 471353.31 723553.69 79.13 471353.31 723553.69 81.95 471351.07 723559.32 81.95 471351.07 723559.32 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.31 723553.69 79.13 471353.13 723553.62 79.13 471353.13 723553.62 81.95 471353.31 723553.69 81.95 471353.31 723553.69 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.13 723553.62 79.13 471353.32 723553.02 79.13 471353.32 723553.02 81.95 471353.13 723553.62 81.95 471353.13 723553.62 79.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EC-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.32 723553.02 81.95 471356.62 723554.32 81.95 471359.49 723555.47 81.95 471362.28 723556.59 81.95 471365.1 723557.66 81.95 471367.92 723558.73 81.95 471370.74 723559.89 81.95 471373.61 723560.89 81.95 471376.53 723561.99 81.95 471379.34 723563.05 81.95 471382.16 723564.12 81.95 471385.03 723565.2 81.95 471382.57 723571.39 81.95 471379.8 723570.35 81.95 471377.02 723569.31 81.95 471374.26 723568.28 81.95 471371.33 723567.16 81.95 471368.39 723566.02 81.95 471365.58 723564.95 81.95 471362.76 723563.86 81.95 471359.84 723562.73 81.95 471357.05 723561.65 81.95 471354.16 723560.52 81.95 471351.07 723559.32 81.95 471353.31 723553.69 81.95 471353.13 723553.62 81.95 471353.32 723553.02 81.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.78</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.78 723530.26 79.27 471327.68 723535.91 79.27 471330.83 723537.06 79.27 471333.81 723538.15 79.27 471336.64 723539.2 79.27 471339.44 723540.22 79.27 471342.23 723541.24 79.27 471345.07 723542.29 79.27 471347.87 723543.32 79.27 471350.82 723544.4 79.27 471353.63 723545.44 79.27 471356.45 723546.47 79.27 471359.26 723547.51 79.27 471362.15 723548.56 79.27 471365.05 723549.62 79.27 471367.87 723550.66 79.27 471370.65 723551.69 79.27 471373.47 723552.72 79.27 471376.35 723553.78 79.27 471379.31 723554.87 79.27 471382.13 723555.9 79.27 471384.93 723556.93 79.27 471387.76 723557.97 79.27 471390.62 723559.02 79.27 471393.52 723560.09 79.27 471396.32 723561.11 79.27 471399.15 723562.14 79.27 471402.18 723563.26 79.27 471404.31 723557.29 79.27 471401.26 723556.18 79.27 471398.45 723555.15 79.27 471395.62 723554.11 79.27 471392.72 723553.05 79.27 471389.85 723552 79.27 471387.02 723550.96 79.27 471384.2 723549.92 79.27 471381.4 723548.9 79.27 471378.42 723547.81 79.27 471375.53 723546.75 79.27 471372.72 723545.72 79.27 471369.92 723544.69 79.27 471367.1 723543.65 79.27 471364.19 723542.59 79.27 471361.29 723541.53 79.27 471358.46 723540.48 79.27 471355.66 723539.45 79.27 471352.82 723538.42 79.27 471349.88 723537.34 79.27 471346.98 723536.28 79.27 471344.22 723535.27 79.27 471341.41 723534.24 79.27 471338.63 723533.22 79.27 471335.77 723532.17 79.27 471332.93 723531.27 79.27 471329.78 723530.26 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.78 723530.26 79.27 471332.93 723531.27 79.27 471332.93 723531.27 82.05 471329.78 723530.26 82.05 471329.78 723530.26 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471332.93 723531.27 79.27 471335.77 723532.17 79.27 471335.77 723532.17 82.05 471332.93 723531.27 82.05 471332.93 723531.27 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471335.77 723532.17 79.27 471338.63 723533.22 79.27 471338.63 723533.22 82.05 471335.77 723532.17 82.05 471335.77 723532.17 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.63 723533.22 79.27 471341.41 723534.24 79.27 471341.41 723534.24 82.05 471338.63 723533.22 82.05 471338.63 723533.22 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471341.41 723534.24 79.27 471344.22 723535.27 79.27 471344.22 723535.27 82.05 471341.41 723534.24 82.05 471341.41 723534.24 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.22 723535.27 79.27 471346.98 723536.28 79.27 471346.98 723536.28 82.05 471344.22 723535.27 82.05 471344.22 723535.27 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471346.98 723536.28 79.27 471349.88 723537.34 79.27 471349.88 723537.34 82.05 471346.98 723536.28 82.05 471346.98 723536.28 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471349.88 723537.34 79.27 471352.82 723538.42 79.27 471352.82 723538.42 82.05 471349.88 723537.34 82.05 471349.88 723537.34 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471352.82 723538.42 79.27 471355.66 723539.45 79.27 471355.66 723539.45 82.05 471352.82 723538.42 82.05 471352.82 723538.42 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.66 723539.45 79.27 471358.46 723540.48 79.27 471358.46 723540.48 82.05 471355.66 723539.45 82.05 471355.66 723539.45 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471358.46 723540.48 79.27 471361.29 723541.53 79.27 471361.29 723541.53 82.05 471358.46 723540.48 82.05 471358.46 723540.48 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471361.29 723541.53 79.27 471364.19 723542.59 79.27 471364.19 723542.59 82.05 471361.29 723541.53 82.05 471361.29 723541.53 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.19 723542.59 79.27 471367.1 723543.65 79.27 471367.1 723543.65 82.05 471364.19 723542.59 82.05 471364.19 723542.59 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471367.1 723543.65 79.27 471369.92 723544.69 79.27 471369.92 723544.69 82.05 471367.1 723543.65 82.05 471367.1 723543.65 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.92 723544.69 79.27 471372.72 723545.72 79.27 471372.72 723545.72 82.05 471369.92 723544.69 82.05 471369.92 723544.69 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471372.72 723545.72 79.27 471375.53 723546.75 79.27 471375.53 723546.75 82.05 471372.72 723545.72 82.05 471372.72 723545.72 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.53 723546.75 79.27 471378.42 723547.81 79.27 471378.42 723547.81 82.05 471375.53 723546.75 82.05 471375.53 723546.75 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471378.42 723547.81 79.27 471381.4 723548.9 79.27 471381.4 723548.9 82.05 471378.42 723547.81 82.05 471378.42 723547.81 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.4 723548.9 79.27 471384.2 723549.92 79.27 471384.2 723549.92 82.05 471381.4 723548.9 82.05 471381.4 723548.9 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.2 723549.92 79.27 471387.02 723550.96 79.27 471387.02 723550.96 82.05 471384.2 723549.92 82.05 471384.2 723549.92 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.02 723550.96 79.27 471389.85 723552 79.27 471389.85 723552 82.05 471387.02 723550.96 82.05 471387.02 723550.96 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471389.85 723552 79.27 471392.72 723553.05 79.27 471392.72 723553.05 82.05 471389.85 723552 82.05 471389.85 723552 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471392.72 723553.05 79.27 471395.62 723554.11 79.27 471395.62 723554.11 82.05 471392.72 723553.05 82.05 471392.72 723553.05 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471395.62 723554.11 79.27 471398.45 723555.15 79.27 471398.45 723555.15 82.05 471395.62 723554.11 82.05 471395.62 723554.11 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471398.45 723555.15 79.27 471401.26 723556.18 79.27 471401.26 723556.18 82.05 471398.45 723555.15 82.05 471398.45 723555.15 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471401.26 723556.18 79.27 471404.31 723557.29 79.27 471404.31 723557.29 82.05 471401.26 723556.18 82.05 471401.26 723556.18 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471404.31 723557.29 79.27 471402.18 723563.26 79.27 471402.18 723563.26 82.05 471404.31 723557.29 82.05 471404.31 723557.29 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471402.18 723563.26 79.27 471399.15 723562.14 79.27 471399.15 723562.14 82.05 471402.18 723563.26 82.05 471402.18 723563.26 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471399.15 723562.14 79.27 471396.32 723561.11 79.27 471396.32 723561.11 82.05 471399.15 723562.14 82.05 471399.15 723562.14 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.32 723561.11 79.27 471393.52 723560.09 79.27 471393.52 723560.09 82.05 471396.32 723561.11 82.05 471396.32 723561.11 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.52 723560.09 79.27 471390.62 723559.02 79.27 471390.62 723559.02 82.05 471393.52 723560.09 82.05 471393.52 723560.09 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.62 723559.02 79.27 471387.76 723557.97 79.27 471387.76 723557.97 82.05 471390.62 723559.02 82.05 471390.62 723559.02 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.76 723557.97 79.27 471384.93 723556.93 79.27 471384.93 723556.93 82.05 471387.76 723557.97 82.05 471387.76 723557.97 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.93 723556.93 79.27 471382.13 723555.9 79.27 471382.13 723555.9 82.05 471384.93 723556.93 82.05 471384.93 723556.93 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471382.13 723555.9 79.27 471379.31 723554.87 79.27 471379.31 723554.87 82.05 471382.13 723555.9 82.05 471382.13 723555.9 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.31 723554.87 79.27 471376.35 723553.78 79.27 471376.35 723553.78 82.05 471379.31 723554.87 82.05 471379.31 723554.87 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471376.35 723553.78 79.27 471373.47 723552.72 79.27 471373.47 723552.72 82.05 471376.35 723553.78 82.05 471376.35 723553.78 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.47 723552.72 79.27 471370.65 723551.69 79.27 471370.65 723551.69 82.05 471373.47 723552.72 82.05 471373.47 723552.72 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.65 723551.69 79.27 471367.87 723550.66 79.27 471367.87 723550.66 82.05 471370.65 723551.69 82.05 471370.65 723551.69 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471367.87 723550.66 79.27 471365.05 723549.62 79.27 471365.05 723549.62 82.05 471367.87 723550.66 82.05 471367.87 723550.66 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471365.05 723549.62 79.27 471362.15 723548.56 79.27 471362.15 723548.56 82.05 471365.05 723549.62 82.05 471365.05 723549.62 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471362.15 723548.56 79.27 471359.26 723547.51 79.27 471359.26 723547.51 82.05 471362.15 723548.56 82.05 471362.15 723548.56 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471359.26 723547.51 79.27 471356.45 723546.47 79.27 471356.45 723546.47 82.05 471359.26 723547.51 82.05 471359.26 723547.51 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471356.45 723546.47 79.27 471353.63 723545.44 79.27 471353.63 723545.44 82.05 471356.45 723546.47 82.05 471356.45 723546.47 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.63 723545.44 79.27 471350.82 723544.4 79.27 471350.82 723544.4 82.05 471353.63 723545.44 82.05 471353.63 723545.44 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.82 723544.4 79.27 471347.87 723543.32 79.27 471347.87 723543.32 82.05 471350.82 723544.4 82.05 471350.82 723544.4 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.87 723543.32 79.27 471345.07 723542.29 79.27 471345.07 723542.29 82.05 471347.87 723543.32 82.05 471347.87 723543.32 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.07 723542.29 79.27 471342.23 723541.24 79.27 471342.23 723541.24 82.05 471345.07 723542.29 82.05 471345.07 723542.29 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.23 723541.24 79.27 471339.44 723540.22 79.27 471339.44 723540.22 82.05 471342.23 723541.24 82.05 471342.23 723541.24 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.44 723540.22 79.27 471336.64 723539.2 79.27 471336.64 723539.2 82.05 471339.44 723540.22 82.05 471339.44 723540.22 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471336.64 723539.2 79.27 471333.81 723538.15 79.27 471333.81 723538.15 82.05 471336.64 723539.2 82.05 471336.64 723539.2 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471333.81 723538.15 79.27 471330.83 723537.06 79.27 471330.83 723537.06 82.05 471333.81 723538.15 82.05 471333.81 723538.15 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.83 723537.06 79.27 471327.68 723535.91 79.27 471327.68 723535.91 82.05 471330.83 723537.06 82.05 471330.83 723537.06 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.68 723535.91 79.27 471329.78 723530.26 79.27 471329.78 723530.26 82.05 471327.68 723535.91 82.05 471327.68 723535.91 79.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EE-FAF6-E053-CA2BA8C0FAE4_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.78 723530.26 82.05 471332.93 723531.27 82.05 471335.77 723532.17 82.05 471338.63 723533.22 82.05 471341.41 723534.24 82.05 471344.22 723535.27 82.05 471346.98 723536.28 82.05 471349.88 723537.34 82.05 471352.82 723538.42 82.05 471355.66 723539.45 82.05 471358.46 723540.48 82.05 471361.29 723541.53 82.05 471364.19 723542.59 82.05 471367.1 723543.65 82.05 471369.92 723544.69 82.05 471372.72 723545.72 82.05 471375.53 723546.75 82.05 471378.42 723547.81 82.05 471381.4 723548.9 82.05 471384.2 723549.92 82.05 471387.02 723550.96 82.05 471389.85 723552 82.05 471392.72 723553.05 82.05 471395.62 723554.11 82.05 471398.45 723555.15 82.05 471401.26 723556.18 82.05 471404.31 723557.29 82.05 471402.18 723563.26 82.05 471399.15 723562.14 82.05 471396.32 723561.11 82.05 471393.52 723560.09 82.05 471390.62 723559.02 82.05 471387.76 723557.97 82.05 471384.93 723556.93 82.05 471382.13 723555.9 82.05 471379.31 723554.87 82.05 471376.35 723553.78 82.05 471373.47 723552.72 82.05 471370.65 723551.69 82.05 471367.87 723550.66 82.05 471365.05 723549.62 82.05 471362.15 723548.56 82.05 471359.26 723547.51 82.05 471356.45 723546.47 82.05 471353.63 723545.44 82.05 471350.82 723544.4 82.05 471347.87 723543.32 82.05 471345.07 723542.29 82.05 471342.23 723541.24 82.05 471339.44 723540.22 82.05 471336.64 723539.2 82.05 471333.81 723538.15 82.05 471330.83 723537.06 82.05 471327.68 723535.91 82.05 471329.78 723530.26 82.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6347-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6347-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.04</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6347-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.28 723752.98 61.43 471371.41 723749.89 61.43 471364.37 723749.72 61.43 471364.25 723752.81 61.43 471364.14 723755.83 61.43 471371.16 723756.05 61.43 471371.28 723752.98 61.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6347-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.28 723752.98 61.43 471371.16 723756.05 61.43 471371.16 723756.05 64.47 471371.28 723752.98 64.47 471371.28 723752.98 61.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6347-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.16 723756.05 61.43 471364.14 723755.83 61.43 471364.14 723755.83 64.47 471371.16 723756.05 64.47 471371.16 723756.05 61.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6347-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.14 723755.83 61.43 471364.25 723752.81 61.43 471364.25 723752.81 64.47 471364.14 723755.83 64.47 471364.14 723755.83 61.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6347-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.25 723752.81 61.43 471364.37 723749.72 61.43 471364.37 723749.72 64.47 471364.25 723752.81 64.47 471364.25 723752.81 61.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6347-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.37 723749.72 61.43 471371.41 723749.89 61.43 471371.41 723749.89 64.47 471364.37 723749.72 64.47 471364.37 723749.72 61.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6347-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.41 723749.89 61.43 471371.28 723752.98 61.43 471371.28 723752.98 64.47 471371.41 723749.89 64.47 471371.41 723749.89 61.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6347-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.28 723752.98 64.47 471371.16 723756.05 64.47 471364.14 723755.83 64.47 471364.25 723752.81 64.47 471364.37 723749.72 64.47 471371.41 723749.89 64.47 471371.28 723752.98 64.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.86</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471325.32 723542.12 79 471323.29 723547.18 79 471325.96 723548.35 79 471325.22 723549.79 79 471328.16 723551.03 79 471330.98 723552.21 79 471333.87 723553.33 79 471336.7 723554.43 79 471339.5 723555.52 79 471342.33 723556.61 79 471345.13 723557.71 79 471347.91 723558.79 79 471350.8 723559.93 79 471351.07 723559.32 79 471353.31 723553.69 79 471353.13 723553.62 79 471350.51 723552.63 79 471347.7 723551.57 79 471344.84 723550.49 79 471342.09 723549.44 79 471339.27 723548.37 79 471336.42 723547.29 79 471333.56 723546.2 79 471330.63 723545.1 79 471327.96 723544.08 79 471328.28 723543.34 79 471325.32 723542.12 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471325.32 723542.12 79 471328.28 723543.34 79 471328.28 723543.34 81.86 471325.32 723542.12 81.86 471325.32 723542.12 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.28 723543.34 79 471327.96 723544.08 79 471327.96 723544.08 81.86 471328.28 723543.34 81.86 471328.28 723543.34 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.96 723544.08 79 471330.63 723545.1 79 471330.63 723545.1 81.86 471327.96 723544.08 81.86 471327.96 723544.08 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.63 723545.1 79 471333.56 723546.2 79 471333.56 723546.2 81.86 471330.63 723545.1 81.86 471330.63 723545.1 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471333.56 723546.2 79 471336.42 723547.29 79 471336.42 723547.29 81.86 471333.56 723546.2 81.86 471333.56 723546.2 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471336.42 723547.29 79 471339.27 723548.37 79 471339.27 723548.37 81.86 471336.42 723547.29 81.86 471336.42 723547.29 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.27 723548.37 79 471342.09 723549.44 79 471342.09 723549.44 81.86 471339.27 723548.37 81.86 471339.27 723548.37 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.09 723549.44 79 471344.84 723550.49 79 471344.84 723550.49 81.86 471342.09 723549.44 81.86 471342.09 723549.44 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.84 723550.49 79 471347.7 723551.57 79 471347.7 723551.57 81.86 471344.84 723550.49 81.86 471344.84 723550.49 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.7 723551.57 79 471350.51 723552.63 79 471350.51 723552.63 81.86 471347.7 723551.57 81.86 471347.7 723551.57 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.51 723552.63 79 471353.13 723553.62 79 471353.13 723553.62 81.86 471350.51 723552.63 81.86 471350.51 723552.63 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.13 723553.62 79 471353.31 723553.69 79 471353.31 723553.69 81.86 471353.13 723553.62 81.86 471353.13 723553.62 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.31 723553.69 79 471351.07 723559.32 79 471351.07 723559.32 81.86 471353.31 723553.69 81.86 471353.31 723553.69 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471351.07 723559.32 79 471350.8 723559.93 79 471350.8 723559.93 81.86 471351.07 723559.32 81.86 471351.07 723559.32 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.8 723559.93 79 471347.91 723558.79 79 471347.91 723558.79 81.86 471350.8 723559.93 81.86 471350.8 723559.93 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.91 723558.79 79 471345.13 723557.71 79 471345.13 723557.71 81.86 471347.91 723558.79 81.86 471347.91 723558.79 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.13 723557.71 79 471342.33 723556.61 79 471342.33 723556.61 81.86 471345.13 723557.71 81.86 471345.13 723557.71 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.33 723556.61 79 471339.5 723555.52 79 471339.5 723555.52 81.86 471342.33 723556.61 81.86 471342.33 723556.61 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.5 723555.52 79 471336.7 723554.43 79 471336.7 723554.43 81.86 471339.5 723555.52 81.86 471339.5 723555.52 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471336.7 723554.43 79 471333.87 723553.33 79 471333.87 723553.33 81.86 471336.7 723554.43 81.86 471336.7 723554.43 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471333.87 723553.33 79 471330.98 723552.21 79 471330.98 723552.21 81.86 471333.87 723553.33 81.86 471333.87 723553.33 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.98 723552.21 79 471328.16 723551.03 79 471328.16 723551.03 81.86 471330.98 723552.21 81.86 471330.98 723552.21 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.16 723551.03 79 471325.22 723549.79 79 471325.22 723549.79 81.86 471328.16 723551.03 81.86 471328.16 723551.03 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471325.22 723549.79 79 471325.96 723548.35 79 471325.96 723548.35 81.86 471325.22 723549.79 81.86 471325.22 723549.79 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471325.96 723548.35 79 471323.29 723547.18 79 471323.29 723547.18 81.86 471325.96 723548.35 81.86 471325.96 723548.35 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471323.29 723547.18 79 471325.32 723542.12 79 471325.32 723542.12 81.86 471323.29 723547.18 81.86 471323.29 723547.18 79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68ED-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471325.32 723542.12 81.86 471328.28 723543.34 81.86 471327.96 723544.08 81.86 471330.63 723545.1 81.86 471333.56 723546.2 81.86 471336.42 723547.29 81.86 471339.27 723548.37 81.86 471342.09 723549.44 81.86 471344.84 723550.49 81.86 471347.7 723551.57 81.86 471350.51 723552.63 81.86 471353.13 723553.62 81.86 471353.31 723553.69 81.86 471351.07 723559.32 81.86 471350.8 723559.93 81.86 471347.91 723558.79 81.86 471345.13 723557.71 81.86 471342.33 723556.61 81.86 471339.5 723555.52 81.86 471336.7 723554.43 81.86 471333.87 723553.33 81.86 471330.98 723552.21 81.86 471328.16 723551.03 81.86 471325.22 723549.79 81.86 471325.96 723548.35 81.86 471323.29 723547.18 81.86 471325.32 723542.12 81.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.24</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.1 723570.63 79.49 471393.93 723576.62 79.49 471396.78 723577.66 79.49 471399.55 723578.67 79.49 471402.36 723579.71 79.49 471405.3 723580.78 79.49 471408.17 723581.84 79.49 471408.45 723581.94 79.49 471410.99 723582.87 79.49 471411.43 723583.03 79.49 471413.81 723583.89 79.49 471414.25 723584.06 79.49 471416.63 723584.93 79.49 471417.05 723585.09 79.49 471419.4 723585.94 79.49 471419.88 723586.12 79.49 471422.27 723586.99 79.49 471422.69 723587.16 79.49 471425.66 723588.24 79.49 471427.79 723582.09 79.49 471424.42 723580.87 79.49 471421.55 723579.83 79.49 471418.78 723578.83 79.49 471415.96 723577.81 79.49 471413.12 723576.78 79.49 471410.31 723575.77 79.49 471407.44 723574.73 79.49 471404.61 723573.7 79.49 471401.79 723572.69 79.49 471398.93 723571.65 79.49 471396.1 723570.63 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.1 723570.63 79.49 471398.93 723571.65 79.49 471398.93 723571.65 82.73 471396.1 723570.63 82.73 471396.1 723570.63 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471398.93 723571.65 79.49 471401.79 723572.69 79.49 471401.79 723572.69 82.73 471398.93 723571.65 82.73 471398.93 723571.65 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471401.79 723572.69 79.49 471404.61 723573.7 79.49 471404.61 723573.7 82.73 471401.79 723572.69 82.73 471401.79 723572.69 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471404.61 723573.7 79.49 471407.44 723574.73 79.49 471407.44 723574.73 82.73 471404.61 723573.7 82.73 471404.61 723573.7 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471407.44 723574.73 79.49 471410.31 723575.77 79.49 471410.31 723575.77 82.73 471407.44 723574.73 82.73 471407.44 723574.73 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471410.31 723575.77 79.49 471413.12 723576.78 79.49 471413.12 723576.78 82.73 471410.31 723575.77 82.73 471410.31 723575.77 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.12 723576.78 79.49 471415.96 723577.81 79.49 471415.96 723577.81 82.73 471413.12 723576.78 82.73 471413.12 723576.78 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471415.96 723577.81 79.49 471418.78 723578.83 79.49 471418.78 723578.83 82.73 471415.96 723577.81 82.73 471415.96 723577.81 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471418.78 723578.83 79.49 471421.55 723579.83 79.49 471421.55 723579.83 82.73 471418.78 723578.83 82.73 471418.78 723578.83 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471421.55 723579.83 79.49 471424.42 723580.87 79.49 471424.42 723580.87 82.73 471421.55 723579.83 82.73 471421.55 723579.83 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.42 723580.87 79.49 471427.79 723582.09 79.49 471427.79 723582.09 82.73 471424.42 723580.87 82.73 471424.42 723580.87 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471427.79 723582.09 79.49 471425.66 723588.24 79.49 471425.66 723588.24 82.73 471427.79 723582.09 82.73 471427.79 723582.09 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471425.66 723588.24 79.49 471422.69 723587.16 79.49 471422.69 723587.16 82.73 471425.66 723588.24 82.73 471425.66 723588.24 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.69 723587.16 79.49 471422.27 723586.99 79.49 471422.27 723586.99 82.73 471422.69 723587.16 82.73 471422.69 723587.16 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.27 723586.99 79.49 471419.88 723586.12 79.49 471419.88 723586.12 82.73 471422.27 723586.99 82.73 471422.27 723586.99 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471419.88 723586.12 79.49 471419.4 723585.94 79.49 471419.4 723585.94 82.73 471419.88 723586.12 82.73 471419.88 723586.12 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471419.4 723585.94 79.49 471417.05 723585.09 79.49 471417.05 723585.09 82.73 471419.4 723585.94 82.73 471419.4 723585.94 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471417.05 723585.09 79.49 471416.63 723584.93 79.49 471416.63 723584.93 82.73 471417.05 723585.09 82.73 471417.05 723585.09 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471416.63 723584.93 79.49 471414.25 723584.06 79.49 471414.25 723584.06 82.73 471416.63 723584.93 82.73 471416.63 723584.93 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471414.25 723584.06 79.49 471413.81 723583.89 79.49 471413.81 723583.89 82.73 471414.25 723584.06 82.73 471414.25 723584.06 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.81 723583.89 79.49 471411.43 723583.03 79.49 471411.43 723583.03 82.73 471413.81 723583.89 82.73 471413.81 723583.89 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.43 723583.03 79.49 471410.99 723582.87 79.49 471410.99 723582.87 82.73 471411.43 723583.03 82.73 471411.43 723583.03 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471410.99 723582.87 79.49 471408.45 723581.94 79.49 471408.45 723581.94 82.73 471410.99 723582.87 82.73 471410.99 723582.87 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471408.45 723581.94 79.49 471408.17 723581.84 79.49 471408.17 723581.84 82.73 471408.45 723581.94 82.73 471408.45 723581.94 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471408.17 723581.84 79.49 471405.3 723580.78 79.49 471405.3 723580.78 82.73 471408.17 723581.84 82.73 471408.17 723581.84 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471405.3 723580.78 79.49 471402.36 723579.71 79.49 471402.36 723579.71 82.73 471405.3 723580.78 82.73 471405.3 723580.78 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471402.36 723579.71 79.49 471399.55 723578.67 79.49 471399.55 723578.67 82.73 471402.36 723579.71 82.73 471402.36 723579.71 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471399.55 723578.67 79.49 471396.78 723577.66 79.49 471396.78 723577.66 82.73 471399.55 723578.67 82.73 471399.55 723578.67 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.78 723577.66 79.49 471393.93 723576.62 79.49 471393.93 723576.62 82.73 471396.78 723577.66 82.73 471396.78 723577.66 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.93 723576.62 79.49 471396.1 723570.63 79.49 471396.1 723570.63 82.73 471393.93 723576.62 82.73 471393.93 723576.62 79.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EA-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.1 723570.63 82.73 471398.93 723571.65 82.73 471401.79 723572.69 82.73 471404.61 723573.7 82.73 471407.44 723574.73 82.73 471410.31 723575.77 82.73 471413.12 723576.78 82.73 471415.96 723577.81 82.73 471418.78 723578.83 82.73 471421.55 723579.83 82.73 471424.42 723580.87 82.73 471427.79 723582.09 82.73 471425.66 723588.24 82.73 471422.69 723587.16 82.73 471422.27 723586.99 82.73 471419.88 723586.12 82.73 471419.4 723585.94 82.73 471417.05 723585.09 82.73 471416.63 723584.93 82.73 471414.25 723584.06 82.73 471413.81 723583.89 82.73 471411.43 723583.03 82.73 471410.99 723582.87 82.73 471408.45 723581.94 82.73 471408.17 723581.84 82.73 471405.3 723580.78 82.73 471402.36 723579.71 82.73 471399.55 723578.67 82.73 471396.78 723577.66 82.73 471393.93 723576.62 82.73 471396.1 723570.63 82.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.03 723565.2 79.39 471382.57 723571.39 79.39 471382.25 723572.24 79.39 471385.11 723573.35 79.39 471387.93 723574.43 79.39 471390.76 723575.52 79.39 471393.71 723576.66 79.39 471393.76 723576.55 79.39 471393.93 723576.62 79.39 471396.1 723570.63 79.39 471395.99 723570.58 79.39 471396.34 723569.49 79.39 471393.33 723568.34 79.39 471390.53 723567.28 79.39 471387.76 723566.23 79.39 471385.03 723565.2 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.03 723565.2 79.39 471387.76 723566.23 79.39 471387.76 723566.23 82.2 471385.03 723565.2 82.2 471385.03 723565.2 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.76 723566.23 79.39 471390.53 723567.28 79.39 471390.53 723567.28 82.2 471387.76 723566.23 82.2 471387.76 723566.23 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.53 723567.28 79.39 471393.33 723568.34 79.39 471393.33 723568.34 82.2 471390.53 723567.28 82.2 471390.53 723567.28 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.33 723568.34 79.39 471396.34 723569.49 79.39 471396.34 723569.49 82.2 471393.33 723568.34 82.2 471393.33 723568.34 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.34 723569.49 79.39 471395.99 723570.58 79.39 471395.99 723570.58 82.2 471396.34 723569.49 82.2 471396.34 723569.49 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471395.99 723570.58 79.39 471396.1 723570.63 79.39 471396.1 723570.63 82.2 471395.99 723570.58 82.2 471395.99 723570.58 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.1 723570.63 79.39 471393.93 723576.62 79.39 471393.93 723576.62 82.2 471396.1 723570.63 82.2 471396.1 723570.63 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.93 723576.62 79.39 471393.76 723576.55 79.39 471393.76 723576.55 82.2 471393.93 723576.62 82.2 471393.93 723576.62 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.76 723576.55 79.39 471393.71 723576.66 79.39 471393.71 723576.66 82.2 471393.76 723576.55 82.2 471393.76 723576.55 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.71 723576.66 79.39 471390.76 723575.52 79.39 471390.76 723575.52 82.2 471393.71 723576.66 82.2 471393.71 723576.66 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.76 723575.52 79.39 471387.93 723574.43 79.39 471387.93 723574.43 82.2 471390.76 723575.52 82.2 471390.76 723575.52 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.93 723574.43 79.39 471385.11 723573.35 79.39 471385.11 723573.35 82.2 471387.93 723574.43 82.2 471387.93 723574.43 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.11 723573.35 79.39 471382.25 723572.24 79.39 471382.25 723572.24 82.2 471385.11 723573.35 82.2 471385.11 723573.35 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471382.25 723572.24 79.39 471382.57 723571.39 79.39 471382.57 723571.39 82.2 471382.25 723572.24 82.2 471382.25 723572.24 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471382.57 723571.39 79.39 471385.03 723565.2 79.39 471385.03 723565.2 82.2 471382.57 723571.39 82.2 471382.57 723571.39 79.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68EB-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.03 723565.2 82.2 471387.76 723566.23 82.2 471390.53 723567.28 82.2 471393.33 723568.34 82.2 471396.34 723569.49 82.2 471395.99 723570.58 82.2 471396.1 723570.63 82.2 471393.93 723576.62 82.2 471393.76 723576.55 82.2 471393.71 723576.66 82.2 471390.76 723575.52 82.2 471387.93 723574.43 82.2 471385.11 723573.35 82.2 471382.25 723572.24 82.2 471382.57 723571.39 82.2 471385.03 723565.2 82.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-634A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-634A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.68</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471404.26 723754.27 60.92 471404.3 723751.17 60.92 471396.85 723750.9 60.92 471396.8 723754 60.92 471396.74 723757.05 60.92 471396.69 723760.16 60.92 471404.16 723760.45 60.92 471404.22 723757.35 60.92 471404.26 723754.27 60.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471404.26 723754.27 60.92 471404.22 723757.35 60.92 471404.22 723757.35 63.6 471404.26 723754.27 63.6 471404.26 723754.27 60.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471404.22 723757.35 60.92 471404.16 723760.45 60.92 471404.16 723760.45 63.6 471404.22 723757.35 63.6 471404.22 723757.35 60.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471404.16 723760.45 60.92 471396.69 723760.16 60.92 471396.69 723760.16 63.6 471404.16 723760.45 63.6 471404.16 723760.45 60.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.69 723760.16 60.92 471396.74 723757.05 60.92 471396.74 723757.05 63.6 471396.69 723760.16 63.6 471396.69 723760.16 60.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.74 723757.05 60.92 471396.8 723754 60.92 471396.8 723754 63.6 471396.74 723757.05 63.6 471396.74 723757.05 60.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.8 723754 60.92 471396.85 723750.9 60.92 471396.85 723750.9 63.6 471396.8 723754 63.6 471396.8 723754 60.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.85 723750.9 60.92 471404.3 723751.17 60.92 471404.3 723751.17 63.6 471396.85 723750.9 63.6 471396.85 723750.9 60.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471404.3 723751.17 60.92 471404.26 723754.27 60.92 471404.26 723754.27 63.6 471404.3 723751.17 63.6 471404.3 723751.17 60.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471404.26 723754.27 63.6 471404.22 723757.35 63.6 471404.16 723760.45 63.6 471396.69 723760.16 63.6 471396.74 723757.05 63.6 471396.8 723754 63.6 471396.85 723750.9 63.6 471404.3 723751.17 63.6 471404.26 723754.27 63.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-634B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-634B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.65</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.68 723755.03 60.56 471429.76 723751.88 60.56 471423.04 723751.7 60.56 471422.96 723754.84 60.56 471422.88 723757.89 60.56 471422.8 723761.04 60.56 471429.53 723761.21 60.56 471429.61 723758.04 60.56 471429.68 723755.03 60.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.68 723755.03 60.56 471429.61 723758.04 60.56 471429.61 723758.04 63.21 471429.68 723755.03 63.21 471429.68 723755.03 60.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.61 723758.04 60.56 471429.53 723761.21 60.56 471429.53 723761.21 63.21 471429.61 723758.04 63.21 471429.61 723758.04 60.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.53 723761.21 60.56 471422.8 723761.04 60.56 471422.8 723761.04 63.21 471429.53 723761.21 63.21 471429.53 723761.21 60.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.8 723761.04 60.56 471422.88 723757.89 60.56 471422.88 723757.89 63.21 471422.8 723761.04 63.21 471422.8 723761.04 60.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.88 723757.89 60.56 471422.96 723754.84 60.56 471422.96 723754.84 63.21 471422.88 723757.89 63.21 471422.88 723757.89 60.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.96 723754.84 60.56 471423.04 723751.7 60.56 471423.04 723751.7 63.21 471422.96 723754.84 63.21 471422.96 723754.84 60.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634B-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.04 723751.7 60.56 471429.76 723751.88 60.56 471429.76 723751.88 63.21 471423.04 723751.7 63.21 471423.04 723751.7 60.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634B-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.76 723751.88 60.56 471429.68 723755.03 60.56 471429.68 723755.03 63.21 471429.76 723751.88 63.21 471429.76 723751.88 60.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-634B-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.68 723755.03 63.21 471429.61 723758.04 63.21 471429.53 723761.21 63.21 471422.8 723761.04 63.21 471422.88 723757.89 63.21 471422.96 723754.84 63.21 471423.04 723751.7 63.21 471429.76 723751.88 63.21 471429.68 723755.03 63.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6349-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6349-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.9</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6349-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.67 723753.7 61.22 471387.72 723750.58 61.22 471380.83 723750.35 61.22 471380.77 723753.47 61.22 471380.71 723756.57 61.22 471380.66 723759.69 61.22 471387.57 723759.95 61.22 471387.62 723756.79 61.22 471387.67 723753.7 61.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6349-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.67 723753.7 61.22 471387.62 723756.79 61.22 471387.62 723756.79 64.12 471387.67 723753.7 64.12 471387.67 723753.7 61.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6349-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.62 723756.79 61.22 471387.57 723759.95 61.22 471387.57 723759.95 64.12 471387.62 723756.79 64.12 471387.62 723756.79 61.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6349-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.57 723759.95 61.22 471380.66 723759.69 61.22 471380.66 723759.69 64.12 471387.57 723759.95 64.12 471387.57 723759.95 61.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6349-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.66 723759.69 61.22 471380.71 723756.57 61.22 471380.71 723756.57 64.12 471380.66 723759.69 64.12 471380.66 723759.69 61.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6349-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.71 723756.57 61.22 471380.77 723753.47 61.22 471380.77 723753.47 64.12 471380.71 723756.57 64.12 471380.71 723756.57 61.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6349-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.77 723753.47 61.22 471380.83 723750.35 61.22 471380.83 723750.35 64.12 471380.77 723753.47 64.12 471380.77 723753.47 61.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6349-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.83 723750.35 61.22 471387.72 723750.58 61.22 471387.72 723750.58 64.12 471380.83 723750.35 64.12 471380.83 723750.35 61.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6349-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.72 723750.58 61.22 471387.67 723753.7 61.22 471387.67 723753.7 64.12 471387.72 723750.58 64.12 471387.72 723750.58 61.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6349-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.67 723753.7 64.12 471387.62 723756.79 64.12 471387.57 723759.95 64.12 471380.66 723759.69 64.12 471380.71 723756.57 64.12 471380.77 723753.47 64.12 471380.83 723750.35 64.12 471387.72 723750.58 64.12 471387.67 723753.7 64.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6348-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6348-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.93</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6348-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.66 723759.14 61.52 471370.87 723759.14 61.52 471371.05 723758.88 61.52 471371.16 723756.05 61.52 471364.14 723755.83 61.52 471364.01 723758.93 61.52 471364.87 723758.95 61.52 471364.77 723762.11 61.52 471370.57 723762.31 61.52 471370.66 723759.14 61.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6348-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.66 723759.14 61.52 471370.57 723762.31 61.52 471370.57 723762.31 64.45 471370.66 723759.14 64.45 471370.66 723759.14 61.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6348-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.57 723762.31 61.52 471364.77 723762.11 61.52 471364.77 723762.11 64.45 471370.57 723762.31 64.45 471370.57 723762.31 61.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6348-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.77 723762.11 61.52 471364.87 723758.95 61.52 471364.87 723758.95 64.45 471364.77 723762.11 64.45 471364.77 723762.11 61.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6348-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.87 723758.95 61.52 471364.01 723758.93 61.52 471364.01 723758.93 64.45 471364.87 723758.95 64.45 471364.87 723758.95 61.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6348-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.01 723758.93 61.52 471364.14 723755.83 61.52 471364.14 723755.83 64.45 471364.01 723758.93 64.45 471364.01 723758.93 61.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6348-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.14 723755.83 61.52 471371.16 723756.05 61.52 471371.16 723756.05 64.45 471364.14 723755.83 64.45 471364.14 723755.83 61.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6348-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.16 723756.05 61.52 471371.05 723758.88 61.52 471371.05 723758.88 64.45 471371.16 723756.05 64.45 471371.16 723756.05 61.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6348-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.05 723758.88 61.52 471370.87 723759.14 61.52 471370.87 723759.14 64.45 471371.05 723758.88 64.45 471371.05 723758.88 61.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6348-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.87 723759.14 61.52 471370.66 723759.14 61.52 471370.66 723759.14 64.45 471370.87 723759.14 64.45 471370.87 723759.14 61.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6348-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.66 723759.14 64.45 471370.57 723762.31 64.45 471364.77 723762.11 64.45 471364.87 723758.95 64.45 471364.01 723758.93 64.45 471364.14 723755.83 64.45 471371.16 723756.05 64.45 471371.05 723758.88 64.45 471370.87 723759.14 64.45 471370.66 723759.14 64.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6E09-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6E09-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.96</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6E09-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.05 723754.23 61.6 471304.93 723757.29 61.6 471304.83 723760.2 61.6 471311.35 723760.43 61.6 471317.87 723760.64 61.6 471317.97 723757.65 61.6 471318.08 723754.56 61.6 471311.56 723754.39 61.6 471305.05 723754.23 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6E09-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.05 723754.23 61.6 471311.56 723754.39 61.6 471311.56 723754.39 64.56 471305.05 723754.23 64.56 471305.05 723754.23 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6E09-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.56 723754.39 61.6 471318.08 723754.56 61.6 471318.08 723754.56 64.56 471311.56 723754.39 64.56 471311.56 723754.39 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6E09-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.08 723754.56 61.6 471317.97 723757.65 61.6 471317.97 723757.65 64.56 471318.08 723754.56 64.56 471318.08 723754.56 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6E09-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.97 723757.65 61.6 471317.87 723760.64 61.6 471317.87 723760.64 64.56 471317.97 723757.65 64.56 471317.97 723757.65 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6E09-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.87 723760.64 61.6 471311.35 723760.43 61.6 471311.35 723760.43 64.56 471317.87 723760.64 64.56 471317.87 723760.64 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6E09-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.35 723760.43 61.6 471304.83 723760.2 61.6 471304.83 723760.2 64.56 471311.35 723760.43 64.56 471311.35 723760.43 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6E09-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.83 723760.2 61.6 471304.93 723757.29 61.6 471304.93 723757.29 64.56 471304.83 723760.2 64.56 471304.83 723760.2 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6E09-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.93 723757.29 61.6 471305.05 723754.23 61.6 471305.05 723754.23 64.56 471304.93 723757.29 64.56 471304.93 723757.29 61.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6E09-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.05 723754.23 64.56 471311.56 723754.39 64.56 471318.08 723754.56 64.56 471317.97 723757.65 64.56 471317.87 723760.64 64.56 471311.35 723760.43 64.56 471304.83 723760.2 64.56 471304.93 723757.29 64.56 471305.05 723754.23 64.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">11.41</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.04 723769.81 63 471381.15 723765.82 63 471380.24 723765.79 63 471380.31 723763.25 63 471381.21 723763.27 63 471381.21 723762.82 63 471370.94 723762.5 63 471370.87 723765.51 63 471369.37 723765.47 63 471369.26 723769.17 63 471370.76 723769.22 63 471370.74 723769.49 63 471381.04 723769.81 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.04 723769.81 63 471370.74 723769.49 63 471370.74 723769.49 74.41 471381.04 723769.81 74.41 471381.04 723769.81 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.74 723769.49 63 471370.76 723769.22 63 471370.76 723769.22 74.41 471370.74 723769.49 74.41 471370.74 723769.49 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.76 723769.22 63 471369.26 723769.17 63 471369.26 723769.17 74.41 471370.76 723769.22 74.41 471370.76 723769.22 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.26 723769.17 63 471369.37 723765.47 63 471369.37 723765.47 74.41 471369.26 723769.17 74.41 471369.26 723769.17 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.37 723765.47 63 471370.87 723765.51 63 471370.87 723765.51 74.41 471369.37 723765.47 74.41 471369.37 723765.47 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.87 723765.51 63 471370.94 723762.5 63 471370.94 723762.5 74.41 471370.87 723765.51 74.41 471370.87 723765.51 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.94 723762.5 63 471381.21 723762.82 63 471381.21 723762.82 74.41 471370.94 723762.5 74.41 471370.94 723762.5 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.21 723762.82 63 471381.21 723763.27 63 471381.21 723763.27 74.41 471381.21 723762.82 74.41 471381.21 723762.82 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.21 723763.27 63 471380.31 723763.25 63 471380.31 723763.25 74.41 471381.21 723763.27 74.41 471381.21 723763.27 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.31 723763.25 63 471380.24 723765.79 63 471380.24 723765.79 74.41 471380.31 723763.25 74.41 471380.31 723763.25 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.24 723765.79 63 471381.15 723765.82 63 471381.15 723765.82 74.41 471380.24 723765.79 74.41 471380.24 723765.79 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.15 723765.82 63 471381.04 723769.81 63 471381.04 723769.81 74.41 471381.15 723765.82 74.41 471381.15 723765.82 63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F64C-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.04 723769.81 74.41 471370.74 723769.49 74.41 471370.76 723769.22 74.41 471369.26 723769.17 74.41 471369.37 723765.47 74.41 471370.87 723765.51 74.41 471370.94 723762.5 74.41 471381.21 723762.82 74.41 471381.21 723763.27 74.41 471380.31 723763.25 74.41 471380.24 723765.79 74.41 471381.15 723765.82 74.41 471381.04 723769.81 74.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F977-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.6 723817.15 71.41 471423.61 723816.93 71.41 471422.71 723816.91 71.41 471422.75 723814.57 71.41 471423.65 723814.58 71.41 471423.7 723810.54 71.41 471411.96 723810 71.41 471411.95 723810.4 71.41 471413.45 723810.43 71.41 471413.41 723813.39 71.41 471411.92 723813.37 71.41 471411.87 723816.6 71.41 471423.6 723817.15 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.6 723817.15 71.41 471411.87 723816.6 71.41 471411.87 723816.6 80.22 471423.6 723817.15 80.22 471423.6 723817.15 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.87 723816.6 71.41 471411.92 723813.37 71.41 471411.92 723813.37 80.22 471411.87 723816.6 80.22 471411.87 723816.6 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.92 723813.37 71.41 471413.41 723813.39 71.41 471413.41 723813.39 80.22 471411.92 723813.37 80.22 471411.92 723813.37 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.41 723813.39 71.41 471413.45 723810.43 71.41 471413.45 723810.43 80.22 471413.41 723813.39 80.22 471413.41 723813.39 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.45 723810.43 71.41 471411.95 723810.4 71.41 471411.95 723810.4 80.22 471413.45 723810.43 80.22 471413.45 723810.43 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.95 723810.4 71.41 471411.96 723810 71.41 471411.96 723810 80.22 471411.95 723810.4 80.22 471411.95 723810.4 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.96 723810 71.41 471423.7 723810.54 71.41 471423.7 723810.54 80.22 471411.96 723810 80.22 471411.96 723810 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.7 723810.54 71.41 471423.65 723814.58 71.41 471423.65 723814.58 80.22 471423.7 723810.54 80.22 471423.7 723810.54 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.65 723814.58 71.41 471422.75 723814.57 71.41 471422.75 723814.57 80.22 471423.65 723814.58 80.22 471423.65 723814.58 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.75 723814.57 71.41 471422.71 723816.91 71.41 471422.71 723816.91 80.22 471422.75 723814.57 80.22 471422.75 723814.57 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.71 723816.91 71.41 471423.61 723816.93 71.41 471423.61 723816.93 80.22 471422.71 723816.91 80.22 471422.71 723816.91 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.61 723816.93 71.41 471423.6 723817.15 71.41 471423.6 723817.15 80.22 471423.61 723816.93 80.22 471423.61 723816.93 71.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F977-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.6 723817.15 80.22 471411.87 723816.6 80.22 471411.92 723813.37 80.22 471413.41 723813.39 80.22 471413.45 723810.43 80.22 471411.95 723810.4 80.22 471411.96 723810 80.22 471423.7 723810.54 80.22 471423.65 723814.58 80.22 471422.75 723814.57 80.22 471422.71 723816.91 80.22 471423.61 723816.93 80.22 471423.6 723817.15 80.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F976-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.28</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.7 723810.54 69.09 471423.7 723810.33 69.09 471422.81 723810.32 69.09 471422.83 723807.93 69.09 471423.73 723807.94 69.09 471423.79 723803.96 69.09 471412.04 723803.43 69.09 471412.04 723803.8 69.09 471413.54 723803.82 69.09 471413.49 723806.77 69.09 471412 723806.75 69.09 471411.96 723810 69.09 471423.7 723810.54 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.7 723810.54 69.09 471411.96 723810 69.09 471411.96 723810 78.37 471423.7 723810.54 78.37 471423.7 723810.54 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.96 723810 69.09 471412 723806.75 69.09 471412 723806.75 78.37 471411.96 723810 78.37 471411.96 723810 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412 723806.75 69.09 471413.49 723806.77 69.09 471413.49 723806.77 78.37 471412 723806.75 78.37 471412 723806.75 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.49 723806.77 69.09 471413.54 723803.82 69.09 471413.54 723803.82 78.37 471413.49 723806.77 78.37 471413.49 723806.77 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.54 723803.82 69.09 471412.04 723803.8 69.09 471412.04 723803.8 78.37 471413.54 723803.82 78.37 471413.54 723803.82 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.04 723803.8 69.09 471412.04 723803.43 69.09 471412.04 723803.43 78.37 471412.04 723803.8 78.37 471412.04 723803.8 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.04 723803.43 69.09 471423.79 723803.96 69.09 471423.79 723803.96 78.37 471412.04 723803.43 78.37 471412.04 723803.43 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.79 723803.96 69.09 471423.73 723807.94 69.09 471423.73 723807.94 78.37 471423.79 723803.96 78.37 471423.79 723803.96 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.73 723807.94 69.09 471422.83 723807.93 69.09 471422.83 723807.93 78.37 471423.73 723807.94 78.37 471423.73 723807.94 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.83 723807.93 69.09 471422.81 723810.32 69.09 471422.81 723810.32 78.37 471422.83 723807.93 78.37 471422.83 723807.93 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.81 723810.32 69.09 471423.7 723810.33 69.09 471423.7 723810.33 78.37 471422.81 723810.32 78.37 471422.81 723810.32 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.7 723810.33 69.09 471423.7 723810.54 69.09 471423.7 723810.54 78.37 471423.7 723810.33 78.37 471423.7 723810.33 69.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F976-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.7 723810.54 78.37 471411.96 723810 78.37 471412 723806.75 78.37 471413.49 723806.77 78.37 471413.54 723803.82 78.37 471412.04 723803.8 78.37 471412.04 723803.43 78.37 471423.79 723803.96 78.37 471423.73 723807.94 78.37 471422.83 723807.93 78.37 471422.81 723810.32 78.37 471423.7 723810.33 78.37 471423.7 723810.54 78.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F275-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.23 723804.63 68.78 471449.3 723802.23 68.78 471450.25 723802.25 68.78 471450.36 723798.08 68.78 471449.42 723798.06 68.78 471438.64 723797.67 68.78 471438.62 723798.07 68.78 471440.12 723798.11 68.78 471440.04 723801.06 68.78 471438.54 723801.01 68.78 471438.45 723804.26 68.78 471449.23 723804.63 68.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.23 723804.63 68.78 471438.45 723804.26 68.78 471438.45 723804.26 78.72 471449.23 723804.63 78.72 471449.23 723804.63 68.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.45 723804.26 68.78 471438.54 723801.01 68.78 471438.54 723801.01 78.72 471438.45 723804.26 78.72 471438.45 723804.26 68.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.54 723801.01 68.78 471440.04 723801.06 68.78 471440.04 723801.06 78.72 471438.54 723801.01 78.72 471438.54 723801.01 68.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471440.04 723801.06 68.78 471440.12 723798.11 68.78 471440.12 723798.11 78.72 471440.04 723801.06 78.72 471440.04 723801.06 68.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471440.12 723798.11 68.78 471438.62 723798.07 68.78 471438.62 723798.07 78.72 471440.12 723798.11 78.72 471440.12 723798.11 68.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.62 723798.07 68.78 471438.64 723797.67 68.78 471438.64 723797.67 78.72 471438.62 723798.07 78.72 471438.62 723798.07 68.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.64 723797.67 68.78 471449.42 723798.06 68.78 471449.42 723798.06 78.72 471438.64 723797.67 78.72 471438.64 723797.67 68.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.42 723798.06 68.78 471450.36 723798.08 68.78 471450.36 723798.08 78.72 471449.42 723798.06 78.72 471449.42 723798.06 68.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.36 723798.08 68.78 471450.25 723802.25 68.78 471450.25 723802.25 78.72 471450.36 723798.08 78.72 471450.36 723798.08 68.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.25 723802.25 68.78 471449.3 723802.23 68.78 471449.3 723802.23 78.72 471450.25 723802.25 78.72 471450.25 723802.25 68.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.3 723802.23 68.78 471449.23 723804.63 68.78 471449.23 723804.63 78.72 471449.3 723802.23 78.72 471449.3 723802.23 68.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F275-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.23 723804.63 78.72 471438.45 723804.26 78.72 471438.54 723801.01 78.72 471440.04 723801.06 78.72 471440.12 723798.11 78.72 471438.62 723798.07 78.72 471438.64 723797.67 78.72 471449.42 723798.06 78.72 471450.36 723798.08 78.72 471450.25 723802.25 78.72 471449.3 723802.23 78.72 471449.23 723804.63 78.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.14</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.06 723784.13 62.12 471424.08 723783.82 62.12 471423.18 723783.81 62.12 471423.21 723781.41 62.12 471424.11 723781.42 62.12 471424.16 723777.54 62.12 471412.39 723777.07 62.12 471412.4 723777.52 62.12 471413.89 723777.54 62.12 471413.85 723780.5 62.12 471412.35 723780.48 62.12 471412.3 723783.66 62.12 471424.06 723784.13 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.06 723784.13 62.12 471412.3 723783.66 62.12 471412.3 723783.66 71.26 471424.06 723784.13 71.26 471424.06 723784.13 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.3 723783.66 62.12 471412.35 723780.48 62.12 471412.35 723780.48 71.26 471412.3 723783.66 71.26 471412.3 723783.66 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.35 723780.48 62.12 471413.85 723780.5 62.12 471413.85 723780.5 71.26 471412.35 723780.48 71.26 471412.35 723780.48 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.85 723780.5 62.12 471413.89 723777.54 62.12 471413.89 723777.54 71.26 471413.85 723780.5 71.26 471413.85 723780.5 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.89 723777.54 62.12 471412.4 723777.52 62.12 471412.4 723777.52 71.26 471413.89 723777.54 71.26 471413.89 723777.54 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.4 723777.52 62.12 471412.39 723777.07 62.12 471412.39 723777.07 71.26 471412.4 723777.52 71.26 471412.4 723777.52 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.39 723777.07 62.12 471424.16 723777.54 62.12 471424.16 723777.54 71.26 471412.39 723777.07 71.26 471412.39 723777.07 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.16 723777.54 62.12 471424.11 723781.42 62.12 471424.11 723781.42 71.26 471424.16 723777.54 71.26 471424.16 723777.54 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.11 723781.42 62.12 471423.21 723781.41 62.12 471423.21 723781.41 71.26 471424.11 723781.42 71.26 471424.11 723781.42 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.21 723781.41 62.12 471423.18 723783.81 62.12 471423.18 723783.81 71.26 471423.21 723781.41 71.26 471423.21 723781.41 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.18 723783.81 62.12 471424.08 723783.82 62.12 471424.08 723783.82 71.26 471423.18 723783.81 71.26 471423.18 723783.81 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.08 723783.82 62.12 471424.06 723784.13 62.12 471424.06 723784.13 71.26 471424.08 723783.82 71.26 471424.08 723783.82 62.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FA3F-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.06 723784.13 71.26 471412.3 723783.66 71.26 471412.35 723780.48 71.26 471413.85 723780.5 71.26 471413.89 723777.54 71.26 471412.4 723777.52 71.26 471412.39 723777.07 71.26 471424.16 723777.54 71.26 471424.11 723781.42 71.26 471423.21 723781.41 71.26 471423.18 723783.81 71.26 471424.08 723783.82 71.26 471424.06 723784.13 71.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471408.45 723581.94 78.77 471406.2 723588.44 78.77 471409.16 723589.53 78.77 471411.98 723590.56 78.77 471414.8 723591.58 78.77 471417.62 723592.61 78.77 471420.18 723593.55 78.77 471420.42 723593.64 78.77 471423.41 723594.72 78.77 471424.99 723590.17 78.77 471425.66 723588.24 78.77 471422.69 723587.16 78.77 471422.27 723586.99 78.77 471419.88 723586.12 78.77 471419.4 723585.94 78.77 471417.05 723585.09 78.77 471416.63 723584.93 78.77 471414.25 723584.06 78.77 471413.81 723583.89 78.77 471411.43 723583.03 78.77 471410.99 723582.87 78.77 471408.45 723581.94 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471408.45 723581.94 78.77 471410.99 723582.87 78.77 471410.99 723582.87 81.76 471408.45 723581.94 81.76 471408.45 723581.94 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471410.99 723582.87 78.77 471411.43 723583.03 78.77 471411.43 723583.03 81.76 471410.99 723582.87 81.76 471410.99 723582.87 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.43 723583.03 78.77 471413.81 723583.89 78.77 471413.81 723583.89 81.76 471411.43 723583.03 81.76 471411.43 723583.03 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471413.81 723583.89 78.77 471414.25 723584.06 78.77 471414.25 723584.06 81.76 471413.81 723583.89 81.76 471413.81 723583.89 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471414.25 723584.06 78.77 471416.63 723584.93 78.77 471416.63 723584.93 81.76 471414.25 723584.06 81.76 471414.25 723584.06 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471416.63 723584.93 78.77 471417.05 723585.09 78.77 471417.05 723585.09 81.76 471416.63 723584.93 81.76 471416.63 723584.93 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471417.05 723585.09 78.77 471419.4 723585.94 78.77 471419.4 723585.94 81.76 471417.05 723585.09 81.76 471417.05 723585.09 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471419.4 723585.94 78.77 471419.88 723586.12 78.77 471419.88 723586.12 81.76 471419.4 723585.94 81.76 471419.4 723585.94 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471419.88 723586.12 78.77 471422.27 723586.99 78.77 471422.27 723586.99 81.76 471419.88 723586.12 81.76 471419.88 723586.12 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.27 723586.99 78.77 471422.69 723587.16 78.77 471422.69 723587.16 81.76 471422.27 723586.99 81.76 471422.27 723586.99 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.69 723587.16 78.77 471425.66 723588.24 78.77 471425.66 723588.24 81.76 471422.69 723587.16 81.76 471422.69 723587.16 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471425.66 723588.24 78.77 471424.99 723590.17 78.77 471424.99 723590.17 81.76 471425.66 723588.24 81.76 471425.66 723588.24 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.99 723590.17 78.77 471423.41 723594.72 78.77 471423.41 723594.72 81.76 471424.99 723590.17 81.76 471424.99 723590.17 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.41 723594.72 78.77 471420.42 723593.64 78.77 471420.42 723593.64 81.76 471423.41 723594.72 81.76 471423.41 723594.72 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471420.42 723593.64 78.77 471420.18 723593.55 78.77 471420.18 723593.55 81.76 471420.42 723593.64 81.76 471420.42 723593.64 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471420.18 723593.55 78.77 471417.62 723592.61 78.77 471417.62 723592.61 81.76 471420.18 723593.55 81.76 471420.18 723593.55 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471417.62 723592.61 78.77 471414.8 723591.58 78.77 471414.8 723591.58 81.76 471417.62 723592.61 81.76 471417.62 723592.61 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471414.8 723591.58 78.77 471411.98 723590.56 78.77 471411.98 723590.56 81.76 471414.8 723591.58 81.76 471414.8 723591.58 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.98 723590.56 78.77 471409.16 723589.53 78.77 471409.16 723589.53 81.76 471411.98 723590.56 81.76 471411.98 723590.56 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471409.16 723589.53 78.77 471406.2 723588.44 78.77 471406.2 723588.44 81.76 471409.16 723589.53 81.76 471409.16 723589.53 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471406.2 723588.44 78.77 471408.45 723581.94 78.77 471408.45 723581.94 81.76 471406.2 723588.44 81.76 471406.2 723588.44 78.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DE0-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471408.45 723581.94 81.76 471410.99 723582.87 81.76 471411.43 723583.03 81.76 471413.81 723583.89 81.76 471414.25 723584.06 81.76 471416.63 723584.93 81.76 471417.05 723585.09 81.76 471419.4 723585.94 81.76 471419.88 723586.12 81.76 471422.27 723586.99 81.76 471422.69 723587.16 81.76 471425.66 723588.24 81.76 471424.99 723590.17 81.76 471423.41 723594.72 81.76 471420.42 723593.64 81.76 471420.18 723593.55 81.76 471417.62 723592.61 81.76 471414.8 723591.58 81.76 471411.98 723590.56 81.76 471409.16 723589.53 81.76 471406.2 723588.44 81.76 471408.45 723581.94 81.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">16.22</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471232.16 724139.32 100.78 471235.28 724138.89 100.78 471235.1 724137.6 100.78 471239.22 724137.03 100.78 471239.02 724135.33 100.78 471242.98 724134.82 100.78 471243.16 724136.11 100.78 471246.28 724135.69 100.78 471246.11 724134.4 100.78 471250.34 724133.84 100.78 471250.25 724133.25 100.78 471253.12 724132.84 100.78 471252.9 724131.09 100.78 471256.87 724130.54 100.78 471257.05 724131.83 100.78 471260.16 724131.42 100.78 471259.98 724130.12 100.78 471264.15 724129.55 100.78 471264.06 724128.96 100.78 471267.1 724128.54 100.78 471265.87 724119.29 100.78 471254.38 724120.78 100.78 471254.46 724121.38 100.78 471251.5 724121.77 100.78 471251.72 724123.46 100.78 471240.43 724125 100.78 471240.5 724125.6 100.78 471237.49 724126.08 100.78 471237.84 724127.91 100.78 471235.07 724128.29 100.78 471234.99 724127.71 100.78 471227.66 724128.71 100.78 471227.75 724129.31 100.78 471222.99 724129.96 100.78 471224.18 724138.5 100.78 471228.93 724137.86 100.78 471229.01 724138.44 100.78 471231.99 724138.02 100.78 471232.16 724139.32 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471232.16 724139.32 100.78 471231.99 724138.02 100.78 471231.99 724138.02 117 471232.16 724139.32 117 471232.16 724139.32 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471231.99 724138.02 100.78 471229.01 724138.44 100.78 471229.01 724138.44 117 471231.99 724138.02 117 471231.99 724138.02 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471229.01 724138.44 100.78 471228.93 724137.86 100.78 471228.93 724137.86 117 471229.01 724138.44 117 471229.01 724138.44 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471228.93 724137.86 100.78 471224.18 724138.5 100.78 471224.18 724138.5 117 471228.93 724137.86 117 471228.93 724137.86 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471224.18 724138.5 100.78 471222.99 724129.96 100.78 471222.99 724129.96 117 471224.18 724138.5 117 471224.18 724138.5 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471222.99 724129.96 100.78 471227.75 724129.31 100.78 471227.75 724129.31 117 471222.99 724129.96 117 471222.99 724129.96 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471227.75 724129.31 100.78 471227.66 724128.71 100.78 471227.66 724128.71 117 471227.75 724129.31 117 471227.75 724129.31 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471227.66 724128.71 100.78 471234.99 724127.71 100.78 471234.99 724127.71 117 471227.66 724128.71 117 471227.66 724128.71 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471234.99 724127.71 100.78 471235.07 724128.29 100.78 471235.07 724128.29 117 471234.99 724127.71 117 471234.99 724127.71 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471235.07 724128.29 100.78 471237.84 724127.91 100.78 471237.84 724127.91 117 471235.07 724128.29 117 471235.07 724128.29 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471237.84 724127.91 100.78 471237.49 724126.08 100.78 471237.49 724126.08 117 471237.84 724127.91 117 471237.84 724127.91 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471237.49 724126.08 100.78 471240.5 724125.6 100.78 471240.5 724125.6 117 471237.49 724126.08 117 471237.49 724126.08 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471240.5 724125.6 100.78 471240.43 724125 100.78 471240.43 724125 117 471240.5 724125.6 117 471240.5 724125.6 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471240.43 724125 100.78 471251.72 724123.46 100.78 471251.72 724123.46 117 471240.43 724125 117 471240.43 724125 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471251.72 724123.46 100.78 471251.5 724121.77 100.78 471251.5 724121.77 117 471251.72 724123.46 117 471251.72 724123.46 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471251.5 724121.77 100.78 471254.46 724121.38 100.78 471254.46 724121.38 117 471251.5 724121.77 117 471251.5 724121.77 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471254.46 724121.38 100.78 471254.38 724120.78 100.78 471254.38 724120.78 117 471254.46 724121.38 117 471254.46 724121.38 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471254.38 724120.78 100.78 471265.87 724119.29 100.78 471265.87 724119.29 117 471254.38 724120.78 117 471254.38 724120.78 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471265.87 724119.29 100.78 471267.1 724128.54 100.78 471267.1 724128.54 117 471265.87 724119.29 117 471265.87 724119.29 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471267.1 724128.54 100.78 471264.06 724128.96 100.78 471264.06 724128.96 117 471267.1 724128.54 117 471267.1 724128.54 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471264.06 724128.96 100.78 471264.15 724129.55 100.78 471264.15 724129.55 117 471264.06 724128.96 117 471264.06 724128.96 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471264.15 724129.55 100.78 471259.98 724130.12 100.78 471259.98 724130.12 117 471264.15 724129.55 117 471264.15 724129.55 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471259.98 724130.12 100.78 471260.16 724131.42 100.78 471260.16 724131.42 117 471259.98 724130.12 117 471259.98 724130.12 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471260.16 724131.42 100.78 471257.05 724131.83 100.78 471257.05 724131.83 117 471260.16 724131.42 117 471260.16 724131.42 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471257.05 724131.83 100.78 471256.87 724130.54 100.78 471256.87 724130.54 117 471257.05 724131.83 117 471257.05 724131.83 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471256.87 724130.54 100.78 471252.9 724131.09 100.78 471252.9 724131.09 117 471256.87 724130.54 117 471256.87 724130.54 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471252.9 724131.09 100.78 471253.12 724132.84 100.78 471253.12 724132.84 117 471252.9 724131.09 117 471252.9 724131.09 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471253.12 724132.84 100.78 471250.25 724133.25 100.78 471250.25 724133.25 117 471253.12 724132.84 117 471253.12 724132.84 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471250.25 724133.25 100.78 471250.34 724133.84 100.78 471250.34 724133.84 117 471250.25 724133.25 117 471250.25 724133.25 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471250.34 724133.84 100.78 471246.11 724134.4 100.78 471246.11 724134.4 117 471250.34 724133.84 117 471250.34 724133.84 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471246.11 724134.4 100.78 471246.28 724135.69 100.78 471246.28 724135.69 117 471246.11 724134.4 117 471246.11 724134.4 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471246.28 724135.69 100.78 471243.16 724136.11 100.78 471243.16 724136.11 117 471246.28 724135.69 117 471246.28 724135.69 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471243.16 724136.11 100.78 471242.98 724134.82 100.78 471242.98 724134.82 117 471243.16 724136.11 117 471243.16 724136.11 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471242.98 724134.82 100.78 471239.02 724135.33 100.78 471239.02 724135.33 117 471242.98 724134.82 117 471242.98 724134.82 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471239.02 724135.33 100.78 471239.22 724137.03 100.78 471239.22 724137.03 117 471239.02 724135.33 117 471239.02 724135.33 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471239.22 724137.03 100.78 471235.1 724137.6 100.78 471235.1 724137.6 117 471239.22 724137.03 117 471239.22 724137.03 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471235.1 724137.6 100.78 471235.28 724138.89 100.78 471235.28 724138.89 117 471235.1 724137.6 117 471235.1 724137.6 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471235.28 724138.89 100.78 471232.16 724139.32 100.78 471232.16 724139.32 117 471235.28 724138.89 117 471235.28 724138.89 100.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CD2-FAF6-E053-CA2BA8C0FAE4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471232.16 724139.32 117 471231.99 724138.02 117 471229.01 724138.44 117 471228.93 724137.86 117 471224.18 724138.5 117 471222.99 724129.96 117 471227.75 724129.31 117 471227.66 724128.71 117 471234.99 724127.71 117 471235.07 724128.29 117 471237.84 724127.91 117 471237.49 724126.08 117 471240.5 724125.6 117 471240.43 724125 117 471251.72 724123.46 117 471251.5 724121.77 117 471254.46 724121.38 117 471254.38 724120.78 117 471265.87 724119.29 117 471267.1 724128.54 117 471264.06 724128.96 117 471264.15 724129.55 117 471259.98 724130.12 117 471260.16 724131.42 117 471257.05 724131.83 117 471256.87 724130.54 117 471252.9 724131.09 117 471253.12 724132.84 117 471250.25 724133.25 117 471250.34 724133.84 117 471246.11 724134.4 117 471246.28 724135.69 117 471243.16 724136.11 117 471242.98 724134.82 117 471239.02 724135.33 117 471239.22 724137.03 117 471235.1 724137.6 117 471235.28 724138.89 117 471232.16 724139.32 117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-32b71c5b-7e57-466a-a57a-a33352c7d1fd">
			<gen:stringAttribute name="buildingId">
				<gen:value>32b71c5b-7e57-466a-a57a-a33352c7d1fd</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.4</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32b71c5b-7e57-466a-a57a-a33352c7d1fd_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471569.59 725504.47 55.68 471568.12 725509 55.68 471594.84 725518.76 55.68 471596.46 725514.38 55.68 471569.59 725504.47 55.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32b71c5b-7e57-466a-a57a-a33352c7d1fd_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471569.59 725504.47 55.68 471596.46 725514.38 55.68 471596.46 725514.38 59.08 471569.59 725504.47 59.08 471569.59 725504.47 55.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32b71c5b-7e57-466a-a57a-a33352c7d1fd_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471596.46 725514.38 55.68 471594.84 725518.76 55.68 471594.84 725518.76 59.08 471596.46 725514.38 59.08 471596.46 725514.38 55.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32b71c5b-7e57-466a-a57a-a33352c7d1fd_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471594.84 725518.76 55.68 471568.12 725509 55.68 471568.12 725509 59.08 471594.84 725518.76 59.08 471594.84 725518.76 55.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32b71c5b-7e57-466a-a57a-a33352c7d1fd_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471568.12 725509 55.68 471569.59 725504.47 55.68 471569.59 725504.47 59.08 471568.12 725509 59.08 471568.12 725509 55.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32b71c5b-7e57-466a-a57a-a33352c7d1fd_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471569.59 725504.47 59.08 471596.46 725514.38 59.08 471594.84 725518.76 59.08 471568.12 725509 59.08 471569.59 725504.47 59.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2971-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">32.67</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471490.15 723578.41 75.13 471501.08 723578.06 75.13 471500.45 723558.21 75.13 471494.32 723558.41 75.13 471494.36 723559.62 75.13 471492.72 723559.67 75.13 471492.49 723552.49 75.13 471483.94 723552.78 75.13 471484.54 723571.44 75.13 471488.27 723571.32 75.13 471488.23 723570.14 75.13 471489.88 723570.09 75.13 471490.15 723578.41 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471490.15 723578.41 75.13 471489.88 723570.09 75.13 471489.88 723570.09 107.8 471490.15 723578.41 107.8 471490.15 723578.41 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471489.88 723570.09 75.13 471488.23 723570.14 75.13 471488.23 723570.14 107.8 471489.88 723570.09 107.8 471489.88 723570.09 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471488.23 723570.14 75.13 471488.27 723571.32 75.13 471488.27 723571.32 107.8 471488.23 723570.14 107.8 471488.23 723570.14 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471488.27 723571.32 75.13 471484.54 723571.44 75.13 471484.54 723571.44 107.8 471488.27 723571.32 107.8 471488.27 723571.32 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471484.54 723571.44 75.13 471483.94 723552.78 75.13 471483.94 723552.78 107.8 471484.54 723571.44 107.8 471484.54 723571.44 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471483.94 723552.78 75.13 471492.49 723552.49 75.13 471492.49 723552.49 107.8 471483.94 723552.78 107.8 471483.94 723552.78 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471492.49 723552.49 75.13 471492.72 723559.67 75.13 471492.72 723559.67 107.8 471492.49 723552.49 107.8 471492.49 723552.49 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471492.72 723559.67 75.13 471494.36 723559.62 75.13 471494.36 723559.62 107.8 471492.72 723559.67 107.8 471492.72 723559.67 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471494.36 723559.62 75.13 471494.32 723558.41 75.13 471494.32 723558.41 107.8 471494.36 723559.62 107.8 471494.36 723559.62 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471494.32 723558.41 75.13 471500.45 723558.21 75.13 471500.45 723558.21 107.8 471494.32 723558.41 107.8 471494.32 723558.41 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471500.45 723558.21 75.13 471501.08 723578.06 75.13 471501.08 723578.06 107.8 471500.45 723558.21 107.8 471500.45 723558.21 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471501.08 723578.06 75.13 471490.15 723578.41 75.13 471490.15 723578.41 107.8 471501.08 723578.06 107.8 471501.08 723578.06 75.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2971-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471490.15 723578.41 107.8 471489.88 723570.09 107.8 471488.23 723570.14 107.8 471488.27 723571.32 107.8 471484.54 723571.44 107.8 471483.94 723552.78 107.8 471492.49 723552.49 107.8 471492.72 723559.67 107.8 471494.36 723559.62 107.8 471494.32 723558.41 107.8 471500.45 723558.21 107.8 471501.08 723578.06 107.8 471490.15 723578.41 107.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F589-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.9</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.2 723802.97 76.15 471380.31 723798.73 76.15 471379.41 723798.7 76.15 471379.47 723796.4 76.15 471380.37 723796.43 76.15 471380.39 723796.08 76.15 471370.01 723795.76 76.15 471369.93 723798.6 76.15 471368.43 723798.56 76.15 471368.32 723802.37 76.15 471380.2 723802.97 76.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.2 723802.97 76.15 471368.32 723802.37 76.15 471368.32 723802.37 89.05 471380.2 723802.97 89.05 471380.2 723802.97 76.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.32 723802.37 76.15 471368.43 723798.56 76.15 471368.43 723798.56 89.05 471368.32 723802.37 89.05 471368.32 723802.37 76.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.43 723798.56 76.15 471369.93 723798.6 76.15 471369.93 723798.6 89.05 471368.43 723798.56 89.05 471368.43 723798.56 76.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.93 723798.6 76.15 471370.01 723795.76 76.15 471370.01 723795.76 89.05 471369.93 723798.6 89.05 471369.93 723798.6 76.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.01 723795.76 76.15 471380.39 723796.08 76.15 471380.39 723796.08 89.05 471370.01 723795.76 89.05 471370.01 723795.76 76.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.39 723796.08 76.15 471380.37 723796.43 76.15 471380.37 723796.43 89.05 471380.39 723796.08 89.05 471380.39 723796.08 76.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.37 723796.43 76.15 471379.47 723796.4 76.15 471379.47 723796.4 89.05 471380.37 723796.43 89.05 471380.37 723796.43 76.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.47 723796.4 76.15 471379.41 723798.7 76.15 471379.41 723798.7 89.05 471379.47 723796.4 89.05 471379.47 723796.4 76.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.41 723798.7 76.15 471380.31 723798.73 76.15 471380.31 723798.73 89.05 471379.41 723798.7 89.05 471379.41 723798.7 76.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.31 723798.73 76.15 471380.2 723802.97 76.15 471380.2 723802.97 89.05 471380.31 723798.73 89.05 471380.31 723798.73 76.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F589-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.2 723802.97 89.05 471368.32 723802.37 89.05 471368.43 723798.56 89.05 471369.93 723798.6 89.05 471370.01 723795.76 89.05 471380.39 723796.08 89.05 471380.37 723796.43 89.05 471379.47 723796.4 89.05 471379.41 723798.7 89.05 471380.31 723798.73 89.05 471380.2 723802.97 89.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6FEE-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6FEE-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.2</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FEE-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.16 725835.55 51.92 471566.58 725838.37 51.92 471569.89 725829.65 51.92 471556.64 725824.62 51.92 471553.33 725833.33 51.92 471552.23 725836.48 51.92 471558.07 725838.75 51.92 471559.16 725835.55 51.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FEE-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.16 725835.55 51.92 471558.07 725838.75 51.92 471558.07 725838.75 56.120000000000005 471559.16 725835.55 56.120000000000005 471559.16 725835.55 51.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FEE-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471558.07 725838.75 51.92 471552.23 725836.48 51.92 471552.23 725836.48 56.120000000000005 471558.07 725838.75 56.120000000000005 471558.07 725838.75 51.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FEE-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471552.23 725836.48 51.92 471553.33 725833.33 51.92 471553.33 725833.33 56.120000000000005 471552.23 725836.48 56.120000000000005 471552.23 725836.48 51.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FEE-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471553.33 725833.33 51.92 471556.64 725824.62 51.92 471556.64 725824.62 56.120000000000005 471553.33 725833.33 56.120000000000005 471553.33 725833.33 51.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FEE-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471556.64 725824.62 51.92 471569.89 725829.65 51.92 471569.89 725829.65 56.120000000000005 471556.64 725824.62 56.120000000000005 471556.64 725824.62 51.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FEE-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471569.89 725829.65 51.92 471566.58 725838.37 51.92 471566.58 725838.37 56.120000000000005 471569.89 725829.65 56.120000000000005 471569.89 725829.65 51.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FEE-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471566.58 725838.37 51.92 471559.16 725835.55 51.92 471559.16 725835.55 56.120000000000005 471566.58 725838.37 56.120000000000005 471566.58 725838.37 51.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FEE-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.16 725835.55 56.120000000000005 471558.07 725838.75 56.120000000000005 471552.23 725836.48 56.120000000000005 471553.33 725833.33 56.120000000000005 471556.64 725824.62 56.120000000000005 471569.89 725829.65 56.120000000000005 471566.58 725838.37 56.120000000000005 471559.16 725835.55 56.120000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
</CityModel>
<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0" xmlns="http://www.opengis.net/citygml/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
			<gml:lowerCorner>489885.38 719537.74 0.59</gml:lowerCorner>
			<gml:upperCorner>491879.83 720141.93 17.75</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-753A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-753A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.04</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-753A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491871.72 719612.79 1.74 491873.67 719618.88 1.74 491872.84 719619.21 1.74 491873.3 719620.59 1.74 491874.13 719620.28 1.74 491879.83 719618.41 1.74 491877.38 719610.94 1.74 491871.72 719612.79 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-753A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491871.72 719612.79 1.74 491877.38 719610.94 1.74 491877.38 719610.94 7.78 491871.72 719612.79 7.78 491871.72 719612.79 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-753A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491877.38 719610.94 1.74 491879.83 719618.41 1.74 491879.83 719618.41 7.78 491877.38 719610.94 7.78 491877.38 719610.94 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-753A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491879.83 719618.41 1.74 491874.13 719620.28 1.74 491874.13 719620.28 7.78 491879.83 719618.41 7.78 491879.83 719618.41 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-753A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491874.13 719620.28 1.74 491873.3 719620.59 1.74 491873.3 719620.59 7.78 491874.13 719620.28 7.78 491874.13 719620.28 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-753A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491873.3 719620.59 1.74 491872.84 719619.21 1.74 491872.84 719619.21 7.78 491873.3 719620.59 7.78 491873.3 719620.59 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-753A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491872.84 719619.21 1.74 491873.67 719618.88 1.74 491873.67 719618.88 7.78 491872.84 719619.21 7.78 491872.84 719619.21 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-753A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491873.67 719618.88 1.74 491871.72 719612.79 1.74 491871.72 719612.79 7.78 491873.67 719618.88 7.78 491873.67 719618.88 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-753A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491871.72 719612.79 7.78 491877.38 719610.94 7.78 491879.83 719618.41 7.78 491874.13 719620.28 7.78 491873.3 719620.59 7.78 491872.84 719619.21 7.78 491873.67 719618.88 7.78 491871.72 719612.79 7.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E29A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E29A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.27</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491456.07 719721.14 1.57 491459.12 719738.04 1.57 491466.15 719736.73 1.57 491463.04 719719.89 1.57 491456.07 719721.14 1.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491456.07 719721.14 1.57 491463.04 719719.89 1.57 491463.04 719719.89 6.84 491456.07 719721.14 6.84 491456.07 719721.14 1.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491463.04 719719.89 1.57 491466.15 719736.73 1.57 491466.15 719736.73 6.84 491463.04 719719.89 6.84 491463.04 719719.89 1.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491466.15 719736.73 1.57 491459.12 719738.04 1.57 491459.12 719738.04 6.84 491466.15 719736.73 6.84 491466.15 719736.73 1.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491459.12 719738.04 1.57 491456.07 719721.14 1.57 491456.07 719721.14 6.84 491459.12 719738.04 6.84 491459.12 719738.04 1.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491456.07 719721.14 6.84 491463.04 719719.89 6.84 491466.15 719736.73 6.84 491459.12 719738.04 6.84 491456.07 719721.14 6.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E1E4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E1E4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1E4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491186.69 719625.64 1.34 491187.13 719631.72 1.34 491199.08 719630.56 1.34 491198.57 719624.55 1.34 491186.69 719625.64 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1E4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491186.69 719625.64 1.34 491198.57 719624.55 1.34 491198.57 719624.55 7.63 491186.69 719625.64 7.63 491186.69 719625.64 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1E4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491198.57 719624.55 1.34 491199.08 719630.56 1.34 491199.08 719630.56 7.63 491198.57 719624.55 7.63 491198.57 719624.55 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1E4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491199.08 719630.56 1.34 491187.13 719631.72 1.34 491187.13 719631.72 7.63 491199.08 719630.56 7.63 491199.08 719630.56 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1E4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491187.13 719631.72 1.34 491186.69 719625.64 1.34 491186.69 719625.64 7.63 491187.13 719631.72 7.63 491187.13 719631.72 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1E4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491186.69 719625.64 7.63 491198.57 719624.55 7.63 491199.08 719630.56 7.63 491187.13 719631.72 7.63 491186.69 719625.64 7.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C975-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C975-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C975-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490981.91 719644.64 0.88 490983.91 719681.46 0.88 491004.11 719680.36 0.88 491003.98 719677.23 0.88 490999.86 719677.4 0.88 490998.1 719643.81 0.88 490981.91 719644.64 0.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C975-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490981.91 719644.64 0.88 490998.1 719643.81 0.88 490998.1 719643.81 5.41 490981.91 719644.64 5.41 490981.91 719644.64 0.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C975-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490998.1 719643.81 0.88 490999.86 719677.4 0.88 490999.86 719677.4 5.41 490998.1 719643.81 5.41 490998.1 719643.81 0.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C975-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490999.86 719677.4 0.88 491003.98 719677.23 0.88 491003.98 719677.23 5.41 490999.86 719677.4 5.41 490999.86 719677.4 0.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C975-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491003.98 719677.23 0.88 491004.11 719680.36 0.88 491004.11 719680.36 5.41 491003.98 719677.23 5.41 491003.98 719677.23 0.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C975-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491004.11 719680.36 0.88 490983.91 719681.46 0.88 490983.91 719681.46 5.41 491004.11 719680.36 5.41 491004.11 719680.36 0.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C975-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490983.91 719681.46 0.88 490981.91 719644.64 0.88 490981.91 719644.64 5.41 490983.91 719681.46 5.41 490983.91 719681.46 0.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C975-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490981.91 719644.64 5.41 490998.1 719643.81 5.41 490999.86 719677.4 5.41 491003.98 719677.23 5.41 491004.11 719680.36 5.41 490983.91 719681.46 5.41 490981.91 719644.64 5.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D78A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D78A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.46</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D78A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491841.26 719909.86 5.2 491845.41 719916.78 5.2 491849.01 719914.63 5.2 491859.98 719932.87 5.2 491871.18 719926.1 5.2 491855.98 719900.98 5.2 491841.26 719909.86 5.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D78A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491841.26 719909.86 5.2 491855.98 719900.98 5.2 491855.98 719900.98 17.66 491841.26 719909.86 17.66 491841.26 719909.86 5.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D78A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491855.98 719900.98 5.2 491871.18 719926.1 5.2 491871.18 719926.1 17.66 491855.98 719900.98 17.66 491855.98 719900.98 5.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D78A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491871.18 719926.1 5.2 491859.98 719932.87 5.2 491859.98 719932.87 17.66 491871.18 719926.1 17.66 491871.18 719926.1 5.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D78A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491859.98 719932.87 5.2 491849.01 719914.63 5.2 491849.01 719914.63 17.66 491859.98 719932.87 17.66 491859.98 719932.87 5.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D78A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491849.01 719914.63 5.2 491845.41 719916.78 5.2 491845.41 719916.78 17.66 491849.01 719914.63 17.66 491849.01 719914.63 5.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D78A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491845.41 719916.78 5.2 491841.26 719909.86 5.2 491841.26 719909.86 17.66 491845.41 719916.78 17.66 491845.41 719916.78 5.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D78A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491841.26 719909.86 17.66 491855.98 719900.98 17.66 491871.18 719926.1 17.66 491859.98 719932.87 17.66 491849.01 719914.63 17.66 491845.41 719916.78 17.66 491841.26 719909.86 17.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6F74-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6F74-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F74-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491661.33 719633.86 1.42 491657.2 719635.22 1.42 491658.12 719637.98 1.42 491656.11 719638.66 1.42 491658.12 719645.24 1.42 491666.31 719642.59 1.42 491664.28 719636.04 1.42 491662.25 719636.69 1.42 491661.33 719633.86 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F74-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491661.33 719633.86 1.42 491662.25 719636.69 1.42 491662.25 719636.69 5.95 491661.33 719633.86 5.95 491661.33 719633.86 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F74-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491662.25 719636.69 1.42 491664.28 719636.04 1.42 491664.28 719636.04 5.95 491662.25 719636.69 5.95 491662.25 719636.69 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F74-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491664.28 719636.04 1.42 491666.31 719642.59 1.42 491666.31 719642.59 5.95 491664.28 719636.04 5.95 491664.28 719636.04 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F74-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491666.31 719642.59 1.42 491658.12 719645.24 1.42 491658.12 719645.24 5.95 491666.31 719642.59 5.95 491666.31 719642.59 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F74-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491658.12 719645.24 1.42 491656.11 719638.66 1.42 491656.11 719638.66 5.95 491658.12 719645.24 5.95 491658.12 719645.24 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F74-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491656.11 719638.66 1.42 491658.12 719637.98 1.42 491658.12 719637.98 5.95 491656.11 719638.66 5.95 491656.11 719638.66 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F74-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491658.12 719637.98 1.42 491657.2 719635.22 1.42 491657.2 719635.22 5.95 491658.12 719637.98 5.95 491658.12 719637.98 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F74-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491657.2 719635.22 1.42 491661.33 719633.86 1.42 491661.33 719633.86 5.95 491657.2 719635.22 5.95 491657.2 719635.22 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F74-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491661.33 719633.86 5.95 491662.25 719636.69 5.95 491664.28 719636.04 5.95 491666.31 719642.59 5.95 491658.12 719645.24 5.95 491656.11 719638.66 5.95 491658.12 719637.98 5.95 491657.2 719635.22 5.95 491661.33 719633.86 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01F8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01F8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.04</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490735.6 719783.13 2.11 490748.41 719782.47 2.11 490747.95 719772.24 2.11 490735.1 719772.9 2.11 490735.6 719783.13 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490735.6 719783.13 2.11 490735.1 719772.9 2.11 490735.1 719772.9 8.15 490735.6 719783.13 8.15 490735.6 719783.13 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490735.1 719772.9 2.11 490747.95 719772.24 2.11 490747.95 719772.24 8.15 490735.1 719772.9 8.15 490735.1 719772.9 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490747.95 719772.24 2.11 490748.41 719782.47 2.11 490748.41 719782.47 8.15 490747.95 719772.24 8.15 490747.95 719772.24 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490748.41 719782.47 2.11 490735.6 719783.13 2.11 490735.6 719783.13 8.15 490748.41 719782.47 8.15 490748.41 719782.47 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490735.6 719783.13 8.15 490735.1 719772.9 8.15 490747.95 719772.24 8.15 490748.41 719782.47 8.15 490735.6 719783.13 8.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.62</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490768.45 719782.84 1.89 490768.5 719784.39 1.89 490769.45 719785.23 1.89 490769.6 719788.66 1.89 490778.62 719788.21 1.89 490778.59 719787.66 1.89 490782.71 719787.51 1.89 490782.34 719779.57 1.89 490778.24 719779.76 1.89 490778.21 719779.21 1.89 490769.21 719779.64 1.89 490769.3 719781.88 1.89 490768.45 719782.84 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490768.45 719782.84 1.89 490769.3 719781.88 1.89 490769.3 719781.88 8.51 490768.45 719782.84 8.51 490768.45 719782.84 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490769.3 719781.88 1.89 490769.21 719779.64 1.89 490769.21 719779.64 8.51 490769.3 719781.88 8.51 490769.3 719781.88 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490769.21 719779.64 1.89 490778.21 719779.21 1.89 490778.21 719779.21 8.51 490769.21 719779.64 8.51 490769.21 719779.64 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490778.21 719779.21 1.89 490778.24 719779.76 1.89 490778.24 719779.76 8.51 490778.21 719779.21 8.51 490778.21 719779.21 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490778.24 719779.76 1.89 490782.34 719779.57 1.89 490782.34 719779.57 8.51 490778.24 719779.76 8.51 490778.24 719779.76 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490782.34 719779.57 1.89 490782.71 719787.51 1.89 490782.71 719787.51 8.51 490782.34 719779.57 8.51 490782.34 719779.57 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490782.71 719787.51 1.89 490778.59 719787.66 1.89 490778.59 719787.66 8.51 490782.71 719787.51 8.51 490782.71 719787.51 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490778.59 719787.66 1.89 490778.62 719788.21 1.89 490778.62 719788.21 8.51 490778.59 719787.66 8.51 490778.59 719787.66 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490778.62 719788.21 1.89 490769.6 719788.66 1.89 490769.6 719788.66 8.51 490778.62 719788.21 8.51 490778.62 719788.21 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490769.6 719788.66 1.89 490769.45 719785.23 1.89 490769.45 719785.23 8.51 490769.6 719788.66 8.51 490769.6 719788.66 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490769.45 719785.23 1.89 490768.5 719784.39 1.89 490768.5 719784.39 8.51 490769.45 719785.23 8.51 490769.45 719785.23 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490768.5 719784.39 1.89 490768.45 719782.84 1.89 490768.45 719782.84 8.51 490768.5 719784.39 8.51 490768.5 719784.39 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F7-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490768.45 719782.84 8.51 490769.3 719781.88 8.51 490769.21 719779.64 8.51 490778.21 719779.21 8.51 490778.24 719779.76 8.51 490782.34 719779.57 8.51 490782.71 719787.51 8.51 490778.59 719787.66 8.51 490778.62 719788.21 8.51 490769.6 719788.66 8.51 490769.45 719785.23 8.51 490768.5 719784.39 8.51 490768.45 719782.84 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491594.25 719632.21 0.91 491593.01 719633.38 0.91 491593.75 719635.74 0.91 491595.53 719636.14 0.91 491596.18 719638.17 0.91 491610.36 719633.58 0.91 491607.99 719626.17 0.91 491604.33 719627.33 0.91 491604.14 719626.79 0.91 491593.6 719630.15 0.91 491594.25 719632.21 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491594.25 719632.21 0.91 491593.6 719630.15 0.91 491593.6 719630.15 7.54 491594.25 719632.21 7.54 491594.25 719632.21 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491593.6 719630.15 0.91 491604.14 719626.79 0.91 491604.14 719626.79 7.54 491593.6 719630.15 7.54 491593.6 719630.15 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491604.14 719626.79 0.91 491604.33 719627.33 0.91 491604.33 719627.33 7.54 491604.14 719626.79 7.54 491604.14 719626.79 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491604.33 719627.33 0.91 491607.99 719626.17 0.91 491607.99 719626.17 7.54 491604.33 719627.33 7.54 491604.33 719627.33 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491607.99 719626.17 0.91 491610.36 719633.58 0.91 491610.36 719633.58 7.54 491607.99 719626.17 7.54 491607.99 719626.17 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491610.36 719633.58 0.91 491596.18 719638.17 0.91 491596.18 719638.17 7.54 491610.36 719633.58 7.54 491610.36 719633.58 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491596.18 719638.17 0.91 491595.53 719636.14 0.91 491595.53 719636.14 7.54 491596.18 719638.17 7.54 491596.18 719638.17 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491595.53 719636.14 0.91 491593.75 719635.74 0.91 491593.75 719635.74 7.54 491595.53 719636.14 7.54 491595.53 719636.14 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491593.75 719635.74 0.91 491593.01 719633.38 0.91 491593.01 719633.38 7.54 491593.75 719635.74 7.54 491593.75 719635.74 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491593.01 719633.38 0.91 491594.25 719632.21 0.91 491594.25 719632.21 7.54 491593.01 719633.38 7.54 491593.01 719633.38 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C5-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491594.25 719632.21 7.54 491593.6 719630.15 7.54 491604.14 719626.79 7.54 491604.33 719627.33 7.54 491607.99 719626.17 7.54 491610.36 719633.58 7.54 491596.18 719638.17 7.54 491595.53 719636.14 7.54 491593.75 719635.74 7.54 491593.01 719633.38 7.54 491594.25 719632.21 7.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.02</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491584.91 719686.93 1.03 491589.65 719685.45 1.03 491589.97 719686.39 1.03 491594.69 719684.8 1.03 491594.35 719683.86 1.03 491599.1 719682.37 1.03 491597.54 719677.63 1.03 491592.83 719679.18 1.03 491593.09 719679.95 1.03 491588.35 719681.66 1.03 491588.04 719680.7 1.03 491583.39 719682.19 1.03 491583.7 719683.12 1.03 491579.01 719684.65 1.03 491580.49 719689.35 1.03 491585.21 719687.87 1.03 491584.91 719686.93 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491584.91 719686.93 1.03 491585.21 719687.87 1.03 491585.21 719687.87 6.05 491584.91 719686.93 6.05 491584.91 719686.93 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491585.21 719687.87 1.03 491580.49 719689.35 1.03 491580.49 719689.35 6.05 491585.21 719687.87 6.05 491585.21 719687.87 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491580.49 719689.35 1.03 491579.01 719684.65 1.03 491579.01 719684.65 6.05 491580.49 719689.35 6.05 491580.49 719689.35 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491579.01 719684.65 1.03 491583.7 719683.12 1.03 491583.7 719683.12 6.05 491579.01 719684.65 6.05 491579.01 719684.65 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491583.7 719683.12 1.03 491583.39 719682.19 1.03 491583.39 719682.19 6.05 491583.7 719683.12 6.05 491583.7 719683.12 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491583.39 719682.19 1.03 491588.04 719680.7 1.03 491588.04 719680.7 6.05 491583.39 719682.19 6.05 491583.39 719682.19 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491588.04 719680.7 1.03 491588.35 719681.66 1.03 491588.35 719681.66 6.05 491588.04 719680.7 6.05 491588.04 719680.7 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491588.35 719681.66 1.03 491593.09 719679.95 1.03 491593.09 719679.95 6.05 491588.35 719681.66 6.05 491588.35 719681.66 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491593.09 719679.95 1.03 491592.83 719679.18 1.03 491592.83 719679.18 6.05 491593.09 719679.95 6.05 491593.09 719679.95 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491592.83 719679.18 1.03 491597.54 719677.63 1.03 491597.54 719677.63 6.05 491592.83 719679.18 6.05 491592.83 719679.18 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491597.54 719677.63 1.03 491599.1 719682.37 1.03 491599.1 719682.37 6.05 491597.54 719677.63 6.05 491597.54 719677.63 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491599.1 719682.37 1.03 491594.35 719683.86 1.03 491594.35 719683.86 6.05 491599.1 719682.37 6.05 491599.1 719682.37 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491594.35 719683.86 1.03 491594.69 719684.8 1.03 491594.69 719684.8 6.05 491594.35 719683.86 6.05 491594.35 719683.86 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491594.69 719684.8 1.03 491589.97 719686.39 1.03 491589.97 719686.39 6.05 491594.69 719684.8 6.05 491594.69 719684.8 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491589.97 719686.39 1.03 491589.65 719685.45 1.03 491589.65 719685.45 6.05 491589.97 719686.39 6.05 491589.97 719686.39 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491589.65 719685.45 1.03 491584.91 719686.93 1.03 491584.91 719686.93 6.05 491589.65 719685.45 6.05 491589.65 719685.45 1.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F72-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491584.91 719686.93 6.05 491585.21 719687.87 6.05 491580.49 719689.35 6.05 491579.01 719684.65 6.05 491583.7 719683.12 6.05 491583.39 719682.19 6.05 491588.04 719680.7 6.05 491588.35 719681.66 6.05 491593.09 719679.95 6.05 491592.83 719679.18 6.05 491597.54 719677.63 6.05 491599.1 719682.37 6.05 491594.35 719683.86 6.05 491594.69 719684.8 6.05 491589.97 719686.39 6.05 491589.65 719685.45 6.05 491584.91 719686.93 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6F71-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6F71-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.86</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F71-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491604.61 719667.44 1.14 491605.99 719672.41 1.14 491610.88 719671.08 1.14 491609.55 719666.1 1.14 491604.61 719667.44 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F71-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491604.61 719667.44 1.14 491609.55 719666.1 1.14 491609.55 719666.1 6 491604.61 719667.44 6 491604.61 719667.44 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F71-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491609.55 719666.1 1.14 491610.88 719671.08 1.14 491610.88 719671.08 6 491609.55 719666.1 6 491609.55 719666.1 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F71-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491610.88 719671.08 1.14 491605.99 719672.41 1.14 491605.99 719672.41 6 491610.88 719671.08 6 491610.88 719671.08 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F71-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491605.99 719672.41 1.14 491604.61 719667.44 1.14 491604.61 719667.44 6 491605.99 719672.41 6 491605.99 719672.41 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F71-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491604.61 719667.44 6 491609.55 719666.1 6 491610.88 719671.08 6 491605.99 719672.41 6 491604.61 719667.44 6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6F70-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6F70-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.3</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F70-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490859.93 719781.76 1.8 490860.31 719793.25 1.8 490867.14 719793 1.8 490866.76 719781.52 1.8 490859.93 719781.76 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F70-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490859.93 719781.76 1.8 490866.76 719781.52 1.8 490866.76 719781.52 8.1 490859.93 719781.76 8.1 490859.93 719781.76 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F70-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490866.76 719781.52 1.8 490867.14 719793 1.8 490867.14 719793 8.1 490866.76 719781.52 8.1 490866.76 719781.52 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F70-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490867.14 719793 1.8 490860.31 719793.25 1.8 490860.31 719793.25 8.1 490867.14 719793 8.1 490867.14 719793 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F70-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490860.31 719793.25 1.8 490859.93 719781.76 1.8 490859.93 719781.76 8.1 490860.31 719793.25 8.1 490860.31 719793.25 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F70-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490859.93 719781.76 8.1 490866.76 719781.52 8.1 490867.14 719793 8.1 490860.31 719793.25 8.1 490859.93 719781.76 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.75</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490801.16 719741.1 1.47 490793.35 719741.37 1.47 490793.57 719746.47 1.47 490792.52 719746.54 1.47 490792.67 719749.95 1.47 490793.67 719749.9 1.47 490793.79 719752.84 1.47 490801.5 719752.57 1.47 490801.47 719751.74 1.47 490807.76 719751.5 1.47 490807.49 719743.09 1.47 490801.23 719743.27 1.47 490801.16 719741.1 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490801.16 719741.1 1.47 490801.23 719743.27 1.47 490801.23 719743.27 8.22 490801.16 719741.1 8.22 490801.16 719741.1 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490801.23 719743.27 1.47 490807.49 719743.09 1.47 490807.49 719743.09 8.22 490801.23 719743.27 8.22 490801.23 719743.27 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490807.49 719743.09 1.47 490807.76 719751.5 1.47 490807.76 719751.5 8.22 490807.49 719743.09 8.22 490807.49 719743.09 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490807.76 719751.5 1.47 490801.47 719751.74 1.47 490801.47 719751.74 8.22 490807.76 719751.5 8.22 490807.76 719751.5 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490801.47 719751.74 1.47 490801.5 719752.57 1.47 490801.5 719752.57 8.22 490801.47 719751.74 8.22 490801.47 719751.74 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490801.5 719752.57 1.47 490793.79 719752.84 1.47 490793.79 719752.84 8.22 490801.5 719752.57 8.22 490801.5 719752.57 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490793.79 719752.84 1.47 490793.67 719749.9 1.47 490793.67 719749.9 8.22 490793.79 719752.84 8.22 490793.79 719752.84 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490793.67 719749.9 1.47 490792.67 719749.95 1.47 490792.67 719749.95 8.22 490793.67 719749.9 8.22 490793.67 719749.9 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490792.67 719749.95 1.47 490792.52 719746.54 1.47 490792.52 719746.54 8.22 490792.67 719749.95 8.22 490792.67 719749.95 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490792.52 719746.54 1.47 490793.57 719746.47 1.47 490793.57 719746.47 8.22 490792.52 719746.54 8.22 490792.52 719746.54 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490793.57 719746.47 1.47 490793.35 719741.37 1.47 490793.35 719741.37 8.22 490793.57 719746.47 8.22 490793.57 719746.47 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490793.35 719741.37 1.47 490801.16 719741.1 1.47 490801.16 719741.1 8.22 490793.35 719741.37 8.22 490793.35 719741.37 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB8-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490801.16 719741.1 8.22 490801.23 719743.27 8.22 490807.49 719743.09 8.22 490807.76 719751.5 8.22 490801.47 719751.74 8.22 490801.5 719752.57 8.22 490793.79 719752.84 8.22 490793.67 719749.9 8.22 490792.67 719749.95 8.22 490792.52 719746.54 8.22 490793.57 719746.47 8.22 490793.35 719741.37 8.22 490801.16 719741.1 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-012C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.67</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489975.83 719822.89 1.3 489975.01 719829.15 1.3 489983.94 719830.32 1.3 489983.49 719833.57 1.3 489990.21 719834.47 1.3 489990.24 719834.17 1.3 489993.82 719834.66 1.3 489995.05 719825.76 1.3 489991.48 719825.26 1.3 489991.52 719824.96 1.3 489985.27 719824.14 1.3 489985.54 719822.15 1.3 489980.52 719821.5 1.3 489980.25 719823.47 1.3 489975.83 719822.89 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489975.83 719822.89 1.3 489980.25 719823.47 1.3 489980.25 719823.47 7.97 489975.83 719822.89 7.97 489975.83 719822.89 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489980.25 719823.47 1.3 489980.52 719821.5 1.3 489980.52 719821.5 7.97 489980.25 719823.47 7.97 489980.25 719823.47 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489980.52 719821.5 1.3 489985.54 719822.15 1.3 489985.54 719822.15 7.97 489980.52 719821.5 7.97 489980.52 719821.5 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489985.54 719822.15 1.3 489985.27 719824.14 1.3 489985.27 719824.14 7.97 489985.54 719822.15 7.97 489985.54 719822.15 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489985.27 719824.14 1.3 489991.52 719824.96 1.3 489991.52 719824.96 7.97 489985.27 719824.14 7.97 489985.27 719824.14 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489991.52 719824.96 1.3 489991.48 719825.26 1.3 489991.48 719825.26 7.97 489991.52 719824.96 7.97 489991.52 719824.96 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489991.48 719825.26 1.3 489995.05 719825.76 1.3 489995.05 719825.76 7.97 489991.48 719825.26 7.97 489991.48 719825.26 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489995.05 719825.76 1.3 489993.82 719834.66 1.3 489993.82 719834.66 7.97 489995.05 719825.76 7.97 489995.05 719825.76 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489993.82 719834.66 1.3 489990.24 719834.17 1.3 489990.24 719834.17 7.97 489993.82 719834.66 7.97 489993.82 719834.66 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489990.24 719834.17 1.3 489990.21 719834.47 1.3 489990.21 719834.47 7.97 489990.24 719834.17 7.97 489990.24 719834.17 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489990.21 719834.47 1.3 489983.49 719833.57 1.3 489983.49 719833.57 7.97 489990.21 719834.47 7.97 489990.21 719834.47 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489983.49 719833.57 1.3 489983.94 719830.32 1.3 489983.94 719830.32 7.97 489983.49 719833.57 7.97 489983.49 719833.57 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489983.94 719830.32 1.3 489975.01 719829.15 1.3 489975.01 719829.15 7.97 489983.94 719830.32 7.97 489983.94 719830.32 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489975.01 719829.15 1.3 489975.83 719822.89 1.3 489975.83 719822.89 7.97 489975.01 719829.15 7.97 489975.01 719829.15 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012C-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489975.83 719822.89 7.97 489980.25 719823.47 7.97 489980.52 719821.5 7.97 489985.54 719822.15 7.97 489985.27 719824.14 7.97 489991.52 719824.96 7.97 489991.48 719825.26 7.97 489995.05 719825.76 7.97 489993.82 719834.66 7.97 489990.24 719834.17 7.97 489990.21 719834.47 7.97 489983.49 719833.57 7.97 489983.94 719830.32 7.97 489975.01 719829.15 7.97 489975.83 719822.89 7.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-012A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.3</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489887.21 719862.09 0.74 489890.13 719861.78 0.74 489890.31 719863.2 0.74 489889.28 719863.35 0.74 489889.91 719867.99 0.74 489900.98 719866.41 0.74 489900.52 719863.1 0.74 489903.94 719862.63 0.74 489902.62 719853.63 0.74 489901.93 719853.72 0.74 489900.97 719847.64 0.74 489885.38 719849.95 0.74 489887.21 719862.09 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489887.21 719862.09 0.74 489885.38 719849.95 0.74 489885.38 719849.95 9.040000000000001 489887.21 719862.09 9.040000000000001 489887.21 719862.09 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489885.38 719849.95 0.74 489900.97 719847.64 0.74 489900.97 719847.64 9.040000000000001 489885.38 719849.95 9.040000000000001 489885.38 719849.95 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489900.97 719847.64 0.74 489901.93 719853.72 0.74 489901.93 719853.72 9.040000000000001 489900.97 719847.64 9.040000000000001 489900.97 719847.64 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489901.93 719853.72 0.74 489902.62 719853.63 0.74 489902.62 719853.63 9.040000000000001 489901.93 719853.72 9.040000000000001 489901.93 719853.72 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489902.62 719853.63 0.74 489903.94 719862.63 0.74 489903.94 719862.63 9.040000000000001 489902.62 719853.63 9.040000000000001 489902.62 719853.63 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489903.94 719862.63 0.74 489900.52 719863.1 0.74 489900.52 719863.1 9.040000000000001 489903.94 719862.63 9.040000000000001 489903.94 719862.63 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489900.52 719863.1 0.74 489900.98 719866.41 0.74 489900.98 719866.41 9.040000000000001 489900.52 719863.1 9.040000000000001 489900.52 719863.1 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489900.98 719866.41 0.74 489889.91 719867.99 0.74 489889.91 719867.99 9.040000000000001 489900.98 719866.41 9.040000000000001 489900.98 719866.41 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489889.91 719867.99 0.74 489889.28 719863.35 0.74 489889.28 719863.35 9.040000000000001 489889.91 719867.99 9.040000000000001 489889.91 719867.99 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489889.28 719863.35 0.74 489890.31 719863.2 0.74 489890.31 719863.2 9.040000000000001 489889.28 719863.35 9.040000000000001 489889.28 719863.35 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489890.31 719863.2 0.74 489890.13 719861.78 0.74 489890.13 719861.78 9.040000000000001 489890.31 719863.2 9.040000000000001 489890.31 719863.2 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489890.13 719861.78 0.74 489887.21 719862.09 0.74 489887.21 719862.09 9.040000000000001 489890.13 719861.78 9.040000000000001 489890.13 719861.78 0.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012A-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489887.21 719862.09 9.040000000000001 489885.38 719849.95 9.040000000000001 489900.97 719847.64 9.040000000000001 489901.93 719853.72 9.040000000000001 489902.62 719853.63 9.040000000000001 489903.94 719862.63 9.040000000000001 489900.52 719863.1 9.040000000000001 489900.98 719866.41 9.040000000000001 489889.91 719867.99 9.040000000000001 489889.28 719863.35 9.040000000000001 489890.31 719863.2 9.040000000000001 489890.13 719861.78 9.040000000000001 489887.21 719862.09 9.040000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6EBA-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6EBA-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EBA-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490819.02 719783.16 1.8 490819.4 719794.67 1.8 490826.16 719794.43 1.8 490825.8 719782.9 1.8 490819.02 719783.16 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EBA-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490819.02 719783.16 1.8 490825.8 719782.9 1.8 490825.8 719782.9 8.09 490819.02 719783.16 8.09 490819.02 719783.16 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EBA-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490825.8 719782.9 1.8 490826.16 719794.43 1.8 490826.16 719794.43 8.09 490825.8 719782.9 8.09 490825.8 719782.9 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EBA-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490826.16 719794.43 1.8 490819.4 719794.67 1.8 490819.4 719794.67 8.09 490826.16 719794.43 8.09 490826.16 719794.43 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EBA-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490819.4 719794.67 1.8 490819.02 719783.16 1.8 490819.02 719783.16 8.09 490819.4 719794.67 8.09 490819.4 719794.67 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EBA-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490819.02 719783.16 8.09 490825.8 719782.9 8.09 490826.16 719794.43 8.09 490819.4 719794.67 8.09 490819.02 719783.16 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6EB9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6EB9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490812.17 719783.4 1.8 490812.54 719794.86 1.8 490819.4 719794.67 1.8 490819.02 719783.16 1.8 490812.17 719783.4 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490812.17 719783.4 1.8 490819.02 719783.16 1.8 490819.02 719783.16 8.09 490812.17 719783.4 8.09 490812.17 719783.4 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490819.02 719783.16 1.8 490819.4 719794.67 1.8 490819.4 719794.67 8.09 490819.02 719783.16 8.09 490819.02 719783.16 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490819.4 719794.67 1.8 490812.54 719794.86 1.8 490812.54 719794.86 8.09 490819.4 719794.67 8.09 490819.4 719794.67 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490812.54 719794.86 1.8 490812.17 719783.4 1.8 490812.17 719783.4 8.09 490812.54 719794.86 8.09 490812.54 719794.86 1.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490812.17 719783.4 8.09 490819.02 719783.16 8.09 490819.4 719794.67 8.09 490812.54 719794.86 8.09 490812.17 719783.4 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6F73-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6F73-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.22</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F73-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491594.41 719607.15 0.77 491596.81 719614.89 0.77 491602.69 719613.05 0.77 491600.28 719605.31 0.77 491598.14 719605.98 0.77 491598.02 719605.59 0.77 491597.64 719605.71 0.77 491597.77 719606.1 0.77 491594.41 719607.15 0.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F73-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491594.41 719607.15 0.77 491597.77 719606.1 0.77 491597.77 719606.1 3.99 491594.41 719607.15 3.99 491594.41 719607.15 0.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F73-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491597.77 719606.1 0.77 491597.64 719605.71 0.77 491597.64 719605.71 3.99 491597.77 719606.1 3.99 491597.77 719606.1 0.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F73-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491597.64 719605.71 0.77 491598.02 719605.59 0.77 491598.02 719605.59 3.99 491597.64 719605.71 3.99 491597.64 719605.71 0.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F73-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491598.02 719605.59 0.77 491598.14 719605.98 0.77 491598.14 719605.98 3.99 491598.02 719605.59 3.99 491598.02 719605.59 0.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F73-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491598.14 719605.98 0.77 491600.28 719605.31 0.77 491600.28 719605.31 3.99 491598.14 719605.98 3.99 491598.14 719605.98 0.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F73-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491600.28 719605.31 0.77 491602.69 719613.05 0.77 491602.69 719613.05 3.99 491600.28 719605.31 3.99 491600.28 719605.31 0.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F73-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491602.69 719613.05 0.77 491596.81 719614.89 0.77 491596.81 719614.89 3.99 491602.69 719613.05 3.99 491602.69 719613.05 0.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F73-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491596.81 719614.89 0.77 491594.41 719607.15 0.77 491594.41 719607.15 3.99 491596.81 719614.89 3.99 491596.81 719614.89 0.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F73-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491594.41 719607.15 3.99 491597.77 719606.1 3.99 491597.64 719605.71 3.99 491598.02 719605.59 3.99 491598.14 719605.98 3.99 491600.28 719605.31 3.99 491602.69 719613.05 3.99 491596.81 719614.89 3.99 491594.41 719607.15 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CC5D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CC5D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.73</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC5D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490364.11 719807.66 1.26 490365.1 719817.56 1.26 490371.59 719816.94 1.26 490370.62 719807.07 1.26 490364.11 719807.66 1.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC5D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490364.11 719807.66 1.26 490370.62 719807.07 1.26 490370.62 719807.07 6.99 490364.11 719807.66 6.99 490364.11 719807.66 1.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC5D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490370.62 719807.07 1.26 490371.59 719816.94 1.26 490371.59 719816.94 6.99 490370.62 719807.07 6.99 490370.62 719807.07 1.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC5D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490371.59 719816.94 1.26 490365.1 719817.56 1.26 490365.1 719817.56 6.99 490371.59 719816.94 6.99 490371.59 719816.94 1.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC5D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490365.1 719817.56 1.26 490364.11 719807.66 1.26 490364.11 719807.66 6.99 490365.1 719817.56 6.99 490365.1 719817.56 1.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC5D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490364.11 719807.66 6.99 490370.62 719807.07 6.99 490371.59 719816.94 6.99 490365.1 719817.56 6.99 490364.11 719807.66 6.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E2A0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E2A0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.09</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E2A0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491714.37 720105.72 6.1 491716.59 720111.69 6.1 491729.97 720106.75 6.1 491727.72 720100.68 6.1 491714.37 720105.72 6.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E2A0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491714.37 720105.72 6.1 491727.72 720100.68 6.1 491727.72 720100.68 10.19 491714.37 720105.72 10.19 491714.37 720105.72 6.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E2A0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491727.72 720100.68 6.1 491729.97 720106.75 6.1 491729.97 720106.75 10.19 491727.72 720100.68 10.19 491727.72 720100.68 6.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E2A0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491729.97 720106.75 6.1 491716.59 720111.69 6.1 491716.59 720111.69 10.19 491729.97 720106.75 10.19 491729.97 720106.75 6.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E2A0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491716.59 720111.69 6.1 491714.37 720105.72 6.1 491714.37 720105.72 10.19 491716.59 720111.69 10.19 491716.59 720111.69 6.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E2A0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491714.37 720105.72 10.19 491727.72 720100.68 10.19 491729.97 720106.75 10.19 491716.59 720111.69 10.19 491714.37 720105.72 10.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E2A1-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E2A1-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E2A1-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491717.23 720004.23 4.15 491731.96 720004.35 4.15 491732.01 719998.21 4.15 491717.26 719998.08 4.15 491717.23 720004.23 4.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E2A1-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491717.23 720004.23 4.15 491717.26 719998.08 4.15 491717.26 719998.08 9.14 491717.23 720004.23 9.14 491717.23 720004.23 4.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E2A1-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491717.26 719998.08 4.15 491732.01 719998.21 4.15 491732.01 719998.21 9.14 491717.26 719998.08 9.14 491717.26 719998.08 4.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E2A1-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491732.01 719998.21 4.15 491731.96 720004.35 4.15 491731.96 720004.35 9.14 491732.01 719998.21 9.14 491732.01 719998.21 4.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E2A1-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491731.96 720004.35 4.15 491717.23 720004.23 4.15 491717.23 720004.23 9.14 491731.96 720004.35 9.14 491731.96 720004.35 4.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E2A1-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491717.23 720004.23 9.14 491717.26 719998.08 9.14 491732.01 719998.21 9.14 491731.96 720004.35 9.14 491717.23 720004.23 9.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E29F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E29F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.89</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491727.72 720100.68 6.34 491729.97 720106.75 6.34 491734.16 720118.13 6.34 491740.04 720115.97 6.34 491733.61 720098.52 6.34 491727.72 720100.68 6.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491727.72 720100.68 6.34 491733.61 720098.52 6.34 491733.61 720098.52 10.23 491727.72 720100.68 10.23 491727.72 720100.68 6.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491733.61 720098.52 6.34 491740.04 720115.97 6.34 491740.04 720115.97 10.23 491733.61 720098.52 10.23 491733.61 720098.52 6.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491740.04 720115.97 6.34 491734.16 720118.13 6.34 491734.16 720118.13 10.23 491740.04 720115.97 10.23 491740.04 720115.97 6.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491734.16 720118.13 6.34 491729.97 720106.75 6.34 491729.97 720106.75 10.23 491734.16 720118.13 10.23 491734.16 720118.13 6.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491729.97 720106.75 6.34 491727.72 720100.68 6.34 491727.72 720100.68 10.23 491729.97 720106.75 10.23 491729.97 720106.75 6.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491727.72 720100.68 10.23 491733.61 720098.52 10.23 491740.04 720115.97 10.23 491734.16 720118.13 10.23 491729.97 720106.75 10.23 491727.72 720100.68 10.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E29E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E29E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.33</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491616.3 719717.21 1.82 491617.31 719722.21 1.82 491624.24 719720.91 1.82 491623.26 719715.9 1.82 491616.3 719717.21 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491616.3 719717.21 1.82 491623.26 719715.9 1.82 491623.26 719715.9 6.1450000000000005 491616.3 719717.21 6.1450000000000005 491616.3 719717.21 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491623.26 719715.9 1.82 491624.24 719720.91 1.82 491624.24 719720.91 6.1450000000000005 491623.26 719715.9 6.1450000000000005 491623.26 719715.9 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491624.24 719720.91 1.82 491617.31 719722.21 1.82 491617.31 719722.21 6.1450000000000005 491624.24 719720.91 6.1450000000000005 491624.24 719720.91 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491617.31 719722.21 1.82 491616.3 719717.21 1.82 491616.3 719717.21 6.1450000000000005 491617.31 719722.21 6.1450000000000005 491617.31 719722.21 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491616.3 719717.21 6.1450000000000005 491623.26 719715.9 6.1450000000000005 491624.24 719720.91 6.1450000000000005 491617.31 719722.21 6.1450000000000005 491616.3 719717.21 6.1450000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E126-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E126-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E126-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491036.13 719672.34 1.14 491036.55 719678.66 1.14 491045.92 719678.18 1.14 491045.49 719671.82 1.14 491036.13 719672.34 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E126-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491036.13 719672.34 1.14 491045.49 719671.82 1.14 491045.49 719671.82 5.95 491036.13 719672.34 5.95 491036.13 719672.34 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E126-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491045.49 719671.82 1.14 491045.92 719678.18 1.14 491045.92 719678.18 5.95 491045.49 719671.82 5.95 491045.49 719671.82 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E126-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491045.92 719678.18 1.14 491036.55 719678.66 1.14 491036.55 719678.66 5.95 491045.92 719678.18 5.95 491045.92 719678.18 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E126-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491036.55 719678.66 1.14 491036.13 719672.34 1.14 491036.13 719672.34 5.95 491036.55 719678.66 5.95 491036.55 719678.66 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E126-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491036.13 719672.34 5.95 491045.49 719671.82 5.95 491045.92 719678.18 5.95 491036.55 719678.66 5.95 491036.13 719672.34 5.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.97</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490378.92 719791.57 1.15 490380.08 719803.77 1.15 490380.33 719806.43 1.15 490384.62 719806 1.15 490384.35 719803.33 1.15 490384.29 719802.71 1.15 490385.78 719802.62 1.15 490385.85 719803.25 1.15 490389.12 719802.9 1.15 490387.89 719790.66 1.15 490378.92 719791.57 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490378.92 719791.57 1.15 490387.89 719790.66 1.15 490387.89 719790.66 8.120000000000001 490378.92 719791.57 8.120000000000001 490378.92 719791.57 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490387.89 719790.66 1.15 490389.12 719802.9 1.15 490389.12 719802.9 8.120000000000001 490387.89 719790.66 8.120000000000001 490387.89 719790.66 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490389.12 719802.9 1.15 490385.85 719803.25 1.15 490385.85 719803.25 8.120000000000001 490389.12 719802.9 8.120000000000001 490389.12 719802.9 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490385.85 719803.25 1.15 490385.78 719802.62 1.15 490385.78 719802.62 8.120000000000001 490385.85 719803.25 8.120000000000001 490385.85 719803.25 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490385.78 719802.62 1.15 490384.29 719802.71 1.15 490384.29 719802.71 8.120000000000001 490385.78 719802.62 8.120000000000001 490385.78 719802.62 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490384.29 719802.71 1.15 490384.35 719803.33 1.15 490384.35 719803.33 8.120000000000001 490384.29 719802.71 8.120000000000001 490384.29 719802.71 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490384.35 719803.33 1.15 490384.62 719806 1.15 490384.62 719806 8.120000000000001 490384.35 719803.33 8.120000000000001 490384.35 719803.33 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490384.62 719806 1.15 490380.33 719806.43 1.15 490380.33 719806.43 8.120000000000001 490384.62 719806 8.120000000000001 490384.62 719806 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490380.33 719806.43 1.15 490380.08 719803.77 1.15 490380.08 719803.77 8.120000000000001 490380.33 719806.43 8.120000000000001 490380.33 719806.43 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490380.08 719803.77 1.15 490378.92 719791.57 1.15 490378.92 719791.57 8.120000000000001 490380.08 719803.77 8.120000000000001 490380.08 719803.77 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA1-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490378.92 719791.57 8.120000000000001 490387.89 719790.66 8.120000000000001 490389.12 719802.9 8.120000000000001 490385.85 719803.25 8.120000000000001 490385.78 719802.62 8.120000000000001 490384.29 719802.71 8.120000000000001 490384.35 719803.33 8.120000000000001 490384.62 719806 8.120000000000001 490380.33 719806.43 8.120000000000001 490380.08 719803.77 8.120000000000001 490378.92 719791.57 8.120000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0131-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.77</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490457.34 719785.14 0.9 490458.4 719794.94 0.9 490459.97 719794.78 0.9 490460.63 719800.7 0.9 490468.76 719799.85 0.9 490468.12 719793.92 0.9 490467.86 719791.68 0.9 490470.57 719791.39 0.9 490469.73 719783.8 0.9 490466.75 719784.14 0.9 490466.61 719782.92 0.9 490462.64 719783.37 0.9 490462.75 719784.56 0.9 490457.34 719785.14 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490457.34 719785.14 0.9 490462.75 719784.56 0.9 490462.75 719784.56 6.67 490457.34 719785.14 6.67 490457.34 719785.14 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490462.75 719784.56 0.9 490462.64 719783.37 0.9 490462.64 719783.37 6.67 490462.75 719784.56 6.67 490462.75 719784.56 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490462.64 719783.37 0.9 490466.61 719782.92 0.9 490466.61 719782.92 6.67 490462.64 719783.37 6.67 490462.64 719783.37 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490466.61 719782.92 0.9 490466.75 719784.14 0.9 490466.75 719784.14 6.67 490466.61 719782.92 6.67 490466.61 719782.92 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490466.75 719784.14 0.9 490469.73 719783.8 0.9 490469.73 719783.8 6.67 490466.75 719784.14 6.67 490466.75 719784.14 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490469.73 719783.8 0.9 490470.57 719791.39 0.9 490470.57 719791.39 6.67 490469.73 719783.8 6.67 490469.73 719783.8 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490470.57 719791.39 0.9 490467.86 719791.68 0.9 490467.86 719791.68 6.67 490470.57 719791.39 6.67 490470.57 719791.39 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490467.86 719791.68 0.9 490468.12 719793.92 0.9 490468.12 719793.92 6.67 490467.86 719791.68 6.67 490467.86 719791.68 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490468.12 719793.92 0.9 490468.76 719799.85 0.9 490468.76 719799.85 6.67 490468.12 719793.92 6.67 490468.12 719793.92 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490468.76 719799.85 0.9 490460.63 719800.7 0.9 490460.63 719800.7 6.67 490468.76 719799.85 6.67 490468.76 719799.85 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490460.63 719800.7 0.9 490459.97 719794.78 0.9 490459.97 719794.78 6.67 490460.63 719800.7 6.67 490460.63 719800.7 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490459.97 719794.78 0.9 490458.4 719794.94 0.9 490458.4 719794.94 6.67 490459.97 719794.78 6.67 490459.97 719794.78 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490458.4 719794.94 0.9 490457.34 719785.14 0.9 490457.34 719785.14 6.67 490458.4 719794.94 6.67 490458.4 719794.94 0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0131-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490457.34 719785.14 6.67 490462.75 719784.56 6.67 490462.64 719783.37 6.67 490466.61 719782.92 6.67 490466.75 719784.14 6.67 490469.73 719783.8 6.67 490470.57 719791.39 6.67 490467.86 719791.68 6.67 490468.12 719793.92 6.67 490468.76 719799.85 6.67 490460.63 719800.7 6.67 490459.97 719794.78 6.67 490458.4 719794.94 6.67 490457.34 719785.14 6.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6F6F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6F6F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.22</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490853.14 719782 1.84 490853.48 719793.47 1.84 490860.31 719793.25 1.84 490859.93 719781.76 1.84 490853.14 719782 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490853.14 719782 1.84 490859.93 719781.76 1.84 490859.93 719781.76 8.06 490853.14 719782 8.06 490853.14 719782 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490859.93 719781.76 1.84 490860.31 719793.25 1.84 490860.31 719793.25 8.06 490859.93 719781.76 8.06 490859.93 719781.76 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490860.31 719793.25 1.84 490853.48 719793.47 1.84 490853.48 719793.47 8.06 490860.31 719793.25 8.06 490860.31 719793.25 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490853.48 719793.47 1.84 490853.14 719782 1.84 490853.14 719782 8.06 490853.48 719793.47 8.06 490853.48 719793.47 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490853.14 719782 8.06 490859.93 719781.76 8.06 490860.31 719793.25 8.06 490853.48 719793.47 8.06 490853.14 719782 8.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6F6E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6F6E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.33</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490846.31 719782.22 1.77 490846.68 719793.72 1.77 490853.48 719793.47 1.77 490853.14 719782 1.77 490846.31 719782.22 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490846.31 719782.22 1.77 490853.14 719782 1.77 490853.14 719782 8.1 490846.31 719782.22 8.1 490846.31 719782.22 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490853.14 719782 1.77 490853.48 719793.47 1.77 490853.48 719793.47 8.1 490853.14 719782 8.1 490853.14 719782 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490853.48 719793.47 1.77 490846.68 719793.72 1.77 490846.68 719793.72 8.1 490853.48 719793.47 8.1 490853.48 719793.47 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490846.68 719793.72 1.77 490846.31 719782.22 1.77 490846.31 719782.22 8.1 490846.68 719793.72 8.1 490846.68 719793.72 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490846.31 719782.22 8.1 490853.14 719782 8.1 490853.48 719793.47 8.1 490846.68 719793.72 8.1 490846.31 719782.22 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6F6D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6F6D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490839.52 719782.46 1.83 490839.86 719793.95 1.83 490846.68 719793.72 1.83 490846.31 719782.22 1.83 490839.52 719782.46 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490839.52 719782.46 1.83 490846.31 719782.22 1.83 490846.31 719782.22 8.15 490839.52 719782.46 8.15 490839.52 719782.46 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490846.31 719782.22 1.83 490846.68 719793.72 1.83 490846.68 719793.72 8.15 490846.31 719782.22 8.15 490846.31 719782.22 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490846.68 719793.72 1.83 490839.86 719793.95 1.83 490839.86 719793.95 8.15 490846.68 719793.72 8.15 490846.68 719793.72 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490839.86 719793.95 1.83 490839.52 719782.46 1.83 490839.52 719782.46 8.15 490839.86 719793.95 8.15 490839.86 719793.95 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490839.52 719782.46 8.15 490846.31 719782.22 8.15 490846.68 719793.72 8.15 490839.86 719793.95 8.15 490839.52 719782.46 8.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6F6C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6F6C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.4</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490832.61 719782.69 1.84 490833.01 719794.19 1.84 490839.86 719793.95 1.84 490839.52 719782.46 1.84 490832.61 719782.69 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490832.61 719782.69 1.84 490839.52 719782.46 1.84 490839.52 719782.46 8.24 490832.61 719782.69 8.24 490832.61 719782.69 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490839.52 719782.46 1.84 490839.86 719793.95 1.84 490839.86 719793.95 8.24 490839.52 719782.46 8.24 490839.52 719782.46 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490839.86 719793.95 1.84 490833.01 719794.19 1.84 490833.01 719794.19 8.24 490839.86 719793.95 8.24 490839.86 719793.95 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490833.01 719794.19 1.84 490832.61 719782.69 1.84 490832.61 719782.69 8.24 490833.01 719794.19 8.24 490833.01 719794.19 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F6C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490832.61 719782.69 8.24 490839.52 719782.46 8.24 490839.86 719793.95 8.24 490833.01 719794.19 8.24 490832.61 719782.69 8.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6EBB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6EBB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.28</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EBB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490825.8 719782.9 1.82 490826.16 719794.43 1.82 490833.01 719794.19 1.82 490832.61 719782.69 1.82 490825.8 719782.9 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EBB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490825.8 719782.9 1.82 490832.61 719782.69 1.82 490832.61 719782.69 8.1 490825.8 719782.9 8.1 490825.8 719782.9 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EBB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490832.61 719782.69 1.82 490833.01 719794.19 1.82 490833.01 719794.19 8.1 490832.61 719782.69 8.1 490832.61 719782.69 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EBB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490833.01 719794.19 1.82 490826.16 719794.43 1.82 490826.16 719794.43 8.1 490833.01 719794.19 8.1 490833.01 719794.19 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EBB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490826.16 719794.43 1.82 490825.8 719782.9 1.82 490825.8 719782.9 8.1 490826.16 719794.43 8.1 490826.16 719794.43 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EBB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490825.8 719782.9 8.1 490832.61 719782.69 8.1 490833.01 719794.19 8.1 490826.16 719794.43 8.1 490825.8 719782.9 8.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CE09-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CE09-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.01</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE09-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491838.69 719574.78 1.84 491841.2 719580.81 1.84 491847.97 719578.31 1.84 491848.74 719579.98 1.84 491852.94 719578.45 1.84 491852.26 719576.78 1.84 491854.28 719575.99 1.84 491851.71 719569.95 1.84 491838.69 719574.78 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE09-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491838.69 719574.78 1.84 491851.71 719569.95 1.84 491851.71 719569.95 4.8500000000000005 491838.69 719574.78 4.8500000000000005 491838.69 719574.78 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE09-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491851.71 719569.95 1.84 491854.28 719575.99 1.84 491854.28 719575.99 4.8500000000000005 491851.71 719569.95 4.8500000000000005 491851.71 719569.95 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE09-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491854.28 719575.99 1.84 491852.26 719576.78 1.84 491852.26 719576.78 4.8500000000000005 491854.28 719575.99 4.8500000000000005 491854.28 719575.99 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE09-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491852.26 719576.78 1.84 491852.94 719578.45 1.84 491852.94 719578.45 4.8500000000000005 491852.26 719576.78 4.8500000000000005 491852.26 719576.78 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE09-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491852.94 719578.45 1.84 491848.74 719579.98 1.84 491848.74 719579.98 4.8500000000000005 491852.94 719578.45 4.8500000000000005 491852.94 719578.45 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE09-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491848.74 719579.98 1.84 491847.97 719578.31 1.84 491847.97 719578.31 4.8500000000000005 491848.74 719579.98 4.8500000000000005 491848.74 719579.98 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE09-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491847.97 719578.31 1.84 491841.2 719580.81 1.84 491841.2 719580.81 4.8500000000000005 491847.97 719578.31 4.8500000000000005 491847.97 719578.31 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE09-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491841.2 719580.81 1.84 491838.69 719574.78 1.84 491838.69 719574.78 4.8500000000000005 491841.2 719580.81 4.8500000000000005 491841.2 719580.81 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE09-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491838.69 719574.78 4.8500000000000005 491851.71 719569.95 4.8500000000000005 491854.28 719575.99 4.8500000000000005 491852.26 719576.78 4.8500000000000005 491852.94 719578.45 4.8500000000000005 491848.74 719579.98 4.8500000000000005 491847.97 719578.31 4.8500000000000005 491841.2 719580.81 4.8500000000000005 491838.69 719574.78 4.8500000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CE07-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CE07-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE07-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491813.88 719550.71 1.47 491816.46 719557.7 1.47 491818.9 719564.35 1.47 491824.88 719562.08 1.47 491822.42 719555.51 1.47 491823.85 719554.98 1.47 491821.18 719548.02 1.47 491819.63 719548.61 1.47 491813.88 719550.71 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE07-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491813.88 719550.71 1.47 491819.63 719548.61 1.47 491819.63 719548.61 6.79 491813.88 719550.71 6.79 491813.88 719550.71 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE07-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491819.63 719548.61 1.47 491821.18 719548.02 1.47 491821.18 719548.02 6.79 491819.63 719548.61 6.79 491819.63 719548.61 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE07-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491821.18 719548.02 1.47 491823.85 719554.98 1.47 491823.85 719554.98 6.79 491821.18 719548.02 6.79 491821.18 719548.02 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE07-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491823.85 719554.98 1.47 491822.42 719555.51 1.47 491822.42 719555.51 6.79 491823.85 719554.98 6.79 491823.85 719554.98 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE07-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491822.42 719555.51 1.47 491824.88 719562.08 1.47 491824.88 719562.08 6.79 491822.42 719555.51 6.79 491822.42 719555.51 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE07-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491824.88 719562.08 1.47 491818.9 719564.35 1.47 491818.9 719564.35 6.79 491824.88 719562.08 6.79 491824.88 719562.08 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE07-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491818.9 719564.35 1.47 491816.46 719557.7 1.47 491816.46 719557.7 6.79 491818.9 719564.35 6.79 491818.9 719564.35 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE07-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491816.46 719557.7 1.47 491813.88 719550.71 1.47 491813.88 719550.71 6.79 491816.46 719557.7 6.79 491816.46 719557.7 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE07-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491813.88 719550.71 6.79 491819.63 719548.61 6.79 491821.18 719548.02 6.79 491823.85 719554.98 6.79 491822.42 719555.51 6.79 491824.88 719562.08 6.79 491818.9 719564.35 6.79 491816.46 719557.7 6.79 491813.88 719550.71 6.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02CA-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02CA-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.41</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CA-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491854.34 719541.37 2.04 491858.37 719551.7 2.04 491858.63 719551.6 2.04 491858.56 719551.39 2.04 491869.83 719547.26 2.04 491866.11 719537.74 2.04 491854.96 719541.92 2.04 491854.71 719541.25 2.04 491854.34 719541.37 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CA-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491854.34 719541.37 2.04 491854.71 719541.25 2.04 491854.71 719541.25 7.45 491854.34 719541.37 7.45 491854.34 719541.37 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CA-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491854.71 719541.25 2.04 491854.96 719541.92 2.04 491854.96 719541.92 7.45 491854.71 719541.25 7.45 491854.71 719541.25 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CA-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491854.96 719541.92 2.04 491866.11 719537.74 2.04 491866.11 719537.74 7.45 491854.96 719541.92 7.45 491854.96 719541.92 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CA-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491866.11 719537.74 2.04 491869.83 719547.26 2.04 491869.83 719547.26 7.45 491866.11 719537.74 7.45 491866.11 719537.74 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CA-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491869.83 719547.26 2.04 491858.56 719551.39 2.04 491858.56 719551.39 7.45 491869.83 719547.26 7.45 491869.83 719547.26 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CA-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491858.56 719551.39 2.04 491858.63 719551.6 2.04 491858.63 719551.6 7.45 491858.56 719551.39 7.45 491858.56 719551.39 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CA-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491858.63 719551.6 2.04 491858.37 719551.7 2.04 491858.37 719551.7 7.45 491858.63 719551.6 7.45 491858.63 719551.6 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CA-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491858.37 719551.7 2.04 491854.34 719541.37 2.04 491854.34 719541.37 7.45 491858.37 719551.7 7.45 491858.37 719551.7 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CA-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491854.34 719541.37 7.45 491854.71 719541.25 7.45 491854.96 719541.92 7.45 491866.11 719537.74 7.45 491869.83 719547.26 7.45 491858.56 719551.39 7.45 491858.63 719551.6 7.45 491858.37 719551.7 7.45 491854.34 719541.37 7.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.85</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491241.82 719716.67 1.23 491242.37 719723.08 1.23 491242.12 719723.11 1.23 491242.58 719728.61 1.23 491242.83 719728.6 1.23 491243.53 719735.63 1.23 491255.49 719734.53 1.23 491253.86 719715.64 1.23 491247.73 719716.16 1.23 491241.82 719716.67 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491241.82 719716.67 1.23 491247.73 719716.16 1.23 491247.73 719716.16 10.08 491241.82 719716.67 10.08 491241.82 719716.67 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491247.73 719716.16 1.23 491253.86 719715.64 1.23 491253.86 719715.64 10.08 491247.73 719716.16 10.08 491247.73 719716.16 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491253.86 719715.64 1.23 491255.49 719734.53 1.23 491255.49 719734.53 10.08 491253.86 719715.64 10.08 491253.86 719715.64 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491255.49 719734.53 1.23 491243.53 719735.63 1.23 491243.53 719735.63 10.08 491255.49 719734.53 10.08 491255.49 719734.53 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491243.53 719735.63 1.23 491242.83 719728.6 1.23 491242.83 719728.6 10.08 491243.53 719735.63 10.08 491243.53 719735.63 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491242.83 719728.6 1.23 491242.58 719728.61 1.23 491242.58 719728.61 10.08 491242.83 719728.6 10.08 491242.83 719728.6 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491242.58 719728.61 1.23 491242.12 719723.11 1.23 491242.12 719723.11 10.08 491242.58 719728.61 10.08 491242.58 719728.61 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491242.12 719723.11 1.23 491242.37 719723.08 1.23 491242.37 719723.08 10.08 491242.12 719723.11 10.08 491242.12 719723.11 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491242.37 719723.08 1.23 491241.82 719716.67 1.23 491241.82 719716.67 10.08 491242.37 719723.08 10.08 491242.37 719723.08 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-72A7-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491241.82 719716.67 10.08 491247.73 719716.16 10.08 491253.86 719715.64 10.08 491255.49 719734.53 10.08 491243.53 719735.63 10.08 491242.83 719728.6 10.08 491242.58 719728.61 10.08 491242.12 719723.11 10.08 491242.37 719723.08 10.08 491241.82 719716.67 10.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.39</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491678.07 719681.26 1.59 491679.41 719685.04 1.59 491679.09 719685.66 1.59 491679.77 719687.48 1.59 491680.37 719687.77 1.59 491681.71 719691.57 1.59 491685.87 719690.13 1.59 491688.22 719691.35 1.59 491690.08 719696.62 1.59 491696.29 719694.42 1.59 491693.61 719686.79 1.59 491692.68 719687.12 1.59 491688.02 719673.9 1.59 491680.87 719676.44 1.59 491682.11 719679.85 1.59 491678.07 719681.26 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491678.07 719681.26 1.59 491682.11 719679.85 1.59 491682.11 719679.85 5.98 491678.07 719681.26 5.98 491678.07 719681.26 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491682.11 719679.85 1.59 491680.87 719676.44 1.59 491680.87 719676.44 5.98 491682.11 719679.85 5.98 491682.11 719679.85 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491680.87 719676.44 1.59 491688.02 719673.9 1.59 491688.02 719673.9 5.98 491680.87 719676.44 5.98 491680.87 719676.44 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491688.02 719673.9 1.59 491692.68 719687.12 1.59 491692.68 719687.12 5.98 491688.02 719673.9 5.98 491688.02 719673.9 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491692.68 719687.12 1.59 491693.61 719686.79 1.59 491693.61 719686.79 5.98 491692.68 719687.12 5.98 491692.68 719687.12 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491693.61 719686.79 1.59 491696.29 719694.42 1.59 491696.29 719694.42 5.98 491693.61 719686.79 5.98 491693.61 719686.79 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491696.29 719694.42 1.59 491690.08 719696.62 1.59 491690.08 719696.62 5.98 491696.29 719694.42 5.98 491696.29 719694.42 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491690.08 719696.62 1.59 491688.22 719691.35 1.59 491688.22 719691.35 5.98 491690.08 719696.62 5.98 491690.08 719696.62 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491688.22 719691.35 1.59 491685.87 719690.13 1.59 491685.87 719690.13 5.98 491688.22 719691.35 5.98 491688.22 719691.35 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491685.87 719690.13 1.59 491681.71 719691.57 1.59 491681.71 719691.57 5.98 491685.87 719690.13 5.98 491685.87 719690.13 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491681.71 719691.57 1.59 491680.37 719687.77 1.59 491680.37 719687.77 5.98 491681.71 719691.57 5.98 491681.71 719691.57 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491680.37 719687.77 1.59 491679.77 719687.48 1.59 491679.77 719687.48 5.98 491680.37 719687.77 5.98 491680.37 719687.77 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491679.77 719687.48 1.59 491679.09 719685.66 1.59 491679.09 719685.66 5.98 491679.77 719687.48 5.98 491679.77 719687.48 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491679.09 719685.66 1.59 491679.41 719685.04 1.59 491679.41 719685.04 5.98 491679.09 719685.66 5.98 491679.09 719685.66 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491679.41 719685.04 1.59 491678.07 719681.26 1.59 491678.07 719681.26 5.98 491679.41 719685.04 5.98 491679.41 719685.04 1.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C8-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491678.07 719681.26 5.98 491682.11 719679.85 5.98 491680.87 719676.44 5.98 491688.02 719673.9 5.98 491692.68 719687.12 5.98 491693.61 719686.79 5.98 491696.29 719694.42 5.98 491690.08 719696.62 5.98 491688.22 719691.35 5.98 491685.87 719690.13 5.98 491681.71 719691.57 5.98 491680.37 719687.77 5.98 491679.77 719687.48 5.98 491679.09 719685.66 5.98 491679.41 719685.04 5.98 491678.07 719681.26 5.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.16</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491691.16 720078.87 6.17 491692.22 720082.97 6.17 491693.36 720082.66 6.17 491696.1 720093.31 6.17 491694.93 720093.6 6.17 491696.06 720097.88 6.17 491708.12 720094.86 6.17 491707.61 720092.89 6.17 491715.9 720090.63 6.17 491714.49 720084.56 6.17 491711.76 720085.19 6.17 491711.1 720082.34 6.17 491713.83 720081.71 6.17 491712.44 720075.82 6.17 491703.77 720077.73 6.17 491703.26 720075.77 6.17 491691.16 720078.87 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491691.16 720078.87 6.17 491703.26 720075.77 6.17 491703.26 720075.77 10.325000000000001 491691.16 720078.87 10.325000000000001 491691.16 720078.87 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491703.26 720075.77 6.17 491703.77 720077.73 6.17 491703.77 720077.73 10.325000000000001 491703.26 720075.77 10.325000000000001 491703.26 720075.77 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491703.77 720077.73 6.17 491712.44 720075.82 6.17 491712.44 720075.82 10.325000000000001 491703.77 720077.73 10.325000000000001 491703.77 720077.73 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491712.44 720075.82 6.17 491713.83 720081.71 6.17 491713.83 720081.71 10.325000000000001 491712.44 720075.82 10.325000000000001 491712.44 720075.82 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491713.83 720081.71 6.17 491711.1 720082.34 6.17 491711.1 720082.34 10.325000000000001 491713.83 720081.71 10.325000000000001 491713.83 720081.71 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491711.1 720082.34 6.17 491711.76 720085.19 6.17 491711.76 720085.19 10.325000000000001 491711.1 720082.34 10.325000000000001 491711.1 720082.34 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491711.76 720085.19 6.17 491714.49 720084.56 6.17 491714.49 720084.56 10.325000000000001 491711.76 720085.19 10.325000000000001 491711.76 720085.19 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491714.49 720084.56 6.17 491715.9 720090.63 6.17 491715.9 720090.63 10.325000000000001 491714.49 720084.56 10.325000000000001 491714.49 720084.56 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491715.9 720090.63 6.17 491707.61 720092.89 6.17 491707.61 720092.89 10.325000000000001 491715.9 720090.63 10.325000000000001 491715.9 720090.63 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491707.61 720092.89 6.17 491708.12 720094.86 6.17 491708.12 720094.86 10.325000000000001 491707.61 720092.89 10.325000000000001 491707.61 720092.89 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491708.12 720094.86 6.17 491696.06 720097.88 6.17 491696.06 720097.88 10.325000000000001 491708.12 720094.86 10.325000000000001 491708.12 720094.86 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491696.06 720097.88 6.17 491694.93 720093.6 6.17 491694.93 720093.6 10.325000000000001 491696.06 720097.88 10.325000000000001 491696.06 720097.88 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491694.93 720093.6 6.17 491696.1 720093.31 6.17 491696.1 720093.31 10.325000000000001 491694.93 720093.6 10.325000000000001 491694.93 720093.6 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491696.1 720093.31 6.17 491693.36 720082.66 6.17 491693.36 720082.66 10.325000000000001 491696.1 720093.31 10.325000000000001 491696.1 720093.31 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491693.36 720082.66 6.17 491692.22 720082.97 6.17 491692.22 720082.97 10.325000000000001 491693.36 720082.66 10.325000000000001 491693.36 720082.66 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491692.22 720082.97 6.17 491691.16 720078.87 6.17 491691.16 720078.87 10.325000000000001 491692.22 720082.97 10.325000000000001 491692.22 720082.97 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C9-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491691.16 720078.87 10.325000000000001 491703.26 720075.77 10.325000000000001 491703.77 720077.73 10.325000000000001 491712.44 720075.82 10.325000000000001 491713.83 720081.71 10.325000000000001 491711.1 720082.34 10.325000000000001 491711.76 720085.19 10.325000000000001 491714.49 720084.56 10.325000000000001 491715.9 720090.63 10.325000000000001 491707.61 720092.89 10.325000000000001 491708.12 720094.86 10.325000000000001 491696.06 720097.88 10.325000000000001 491694.93 720093.6 10.325000000000001 491696.1 720093.31 10.325000000000001 491693.36 720082.66 10.325000000000001 491692.22 720082.97 10.325000000000001 491691.16 720078.87 10.325000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.05</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490732.16 719753.17 1.5 490732.73 719763.71 1.5 490747.43 719763.01 1.5 490747.07 719756.33 1.5 490744.69 719756.46 1.5 490744.47 719753.09 1.5 490745.44 719753.03 1.5 490745.4 719752.49 1.5 490745.12 719748.04 1.5 490733.51 719748.64 1.5 490733.65 719753.07 1.5 490732.16 719753.17 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490732.16 719753.17 1.5 490733.65 719753.07 1.5 490733.65 719753.07 9.55 490732.16 719753.17 9.55 490732.16 719753.17 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490733.65 719753.07 1.5 490733.51 719748.64 1.5 490733.51 719748.64 9.55 490733.65 719753.07 9.55 490733.65 719753.07 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490733.51 719748.64 1.5 490745.12 719748.04 1.5 490745.12 719748.04 9.55 490733.51 719748.64 9.55 490733.51 719748.64 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490745.12 719748.04 1.5 490745.4 719752.49 1.5 490745.4 719752.49 9.55 490745.12 719748.04 9.55 490745.12 719748.04 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490745.4 719752.49 1.5 490745.44 719753.03 1.5 490745.44 719753.03 9.55 490745.4 719752.49 9.55 490745.4 719752.49 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490745.44 719753.03 1.5 490744.47 719753.09 1.5 490744.47 719753.09 9.55 490745.44 719753.03 9.55 490745.44 719753.03 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490744.47 719753.09 1.5 490744.69 719756.46 1.5 490744.69 719756.46 9.55 490744.47 719753.09 9.55 490744.47 719753.09 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490744.69 719756.46 1.5 490747.07 719756.33 1.5 490747.07 719756.33 9.55 490744.69 719756.46 9.55 490744.69 719756.46 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490747.07 719756.33 1.5 490747.43 719763.01 1.5 490747.43 719763.01 9.55 490747.07 719756.33 9.55 490747.07 719756.33 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490747.43 719763.01 1.5 490732.73 719763.71 1.5 490732.73 719763.71 9.55 490747.43 719763.01 9.55 490747.43 719763.01 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490732.73 719763.71 1.5 490732.16 719753.17 1.5 490732.16 719753.17 9.55 490732.73 719763.71 9.55 490732.73 719763.71 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F6-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490732.16 719753.17 9.55 490733.65 719753.07 9.55 490733.51 719748.64 9.55 490745.12 719748.04 9.55 490745.4 719752.49 9.55 490745.44 719753.03 9.55 490744.47 719753.09 9.55 490744.69 719756.46 9.55 490747.07 719756.33 9.55 490747.43 719763.01 9.55 490732.73 719763.71 9.55 490732.16 719753.17 9.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01F5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01F5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.22</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490656.33 719713.83 0.86 490648.58 719714.38 0.86 490649.35 719724.79 0.86 490649.8 719724.77 0.86 490650.32 719732.41 0.86 490657.2 719731.97 0.86 490656.64 719724.3 0.86 490657.07 719724.26 0.86 490656.33 719713.83 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490656.33 719713.83 0.86 490657.07 719724.26 0.86 490657.07 719724.26 7.08 490656.33 719713.83 7.08 490656.33 719713.83 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490657.07 719724.26 0.86 490656.64 719724.3 0.86 490656.64 719724.3 7.08 490657.07 719724.26 7.08 490657.07 719724.26 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490656.64 719724.3 0.86 490657.2 719731.97 0.86 490657.2 719731.97 7.08 490656.64 719724.3 7.08 490656.64 719724.3 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490657.2 719731.97 0.86 490650.32 719732.41 0.86 490650.32 719732.41 7.08 490657.2 719731.97 7.08 490657.2 719731.97 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490650.32 719732.41 0.86 490649.8 719724.77 0.86 490649.8 719724.77 7.08 490650.32 719732.41 7.08 490650.32 719732.41 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490649.8 719724.77 0.86 490649.35 719724.79 0.86 490649.35 719724.79 7.08 490649.8 719724.77 7.08 490649.8 719724.77 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490649.35 719724.79 0.86 490648.58 719714.38 0.86 490648.58 719714.38 7.08 490649.35 719724.79 7.08 490649.35 719724.79 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490648.58 719714.38 0.86 490656.33 719713.83 0.86 490656.33 719713.83 7.08 490648.58 719714.38 7.08 490648.58 719714.38 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490656.33 719713.83 7.08 490657.07 719724.26 7.08 490656.64 719724.3 7.08 490657.2 719731.97 7.08 490650.32 719732.41 7.08 490649.8 719724.77 7.08 490649.35 719724.79 7.08 490648.58 719714.38 7.08 490656.33 719713.83 7.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.88</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490740.73 719727.49 1.12 490739.19 719727.52 1.12 490738.17 719728.55 1.12 490735.11 719728.71 1.12 490735.6 719737.08 1.12 490736.65 719737.02 1.12 490736.84 719740.47 1.12 490746.19 719740.04 1.12 490746.05 719735.93 1.12 490745.2 719735.99 1.12 490744.82 719728.24 1.12 490741.74 719728.4 1.12 490740.73 719727.49 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490740.73 719727.49 1.12 490741.74 719728.4 1.12 490741.74 719728.4 8 490740.73 719727.49 8 490740.73 719727.49 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490741.74 719728.4 1.12 490744.82 719728.24 1.12 490744.82 719728.24 8 490741.74 719728.4 8 490741.74 719728.4 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490744.82 719728.24 1.12 490745.2 719735.99 1.12 490745.2 719735.99 8 490744.82 719728.24 8 490744.82 719728.24 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490745.2 719735.99 1.12 490746.05 719735.93 1.12 490746.05 719735.93 8 490745.2 719735.99 8 490745.2 719735.99 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490746.05 719735.93 1.12 490746.19 719740.04 1.12 490746.19 719740.04 8 490746.05 719735.93 8 490746.05 719735.93 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490746.19 719740.04 1.12 490736.84 719740.47 1.12 490736.84 719740.47 8 490746.19 719740.04 8 490746.19 719740.04 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490736.84 719740.47 1.12 490736.65 719737.02 1.12 490736.65 719737.02 8 490736.84 719740.47 8 490736.84 719740.47 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490736.65 719737.02 1.12 490735.6 719737.08 1.12 490735.6 719737.08 8 490736.65 719737.02 8 490736.65 719737.02 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490735.6 719737.08 1.12 490735.11 719728.71 1.12 490735.11 719728.71 8 490735.6 719737.08 8 490735.6 719737.08 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490735.11 719728.71 1.12 490738.17 719728.55 1.12 490738.17 719728.55 8 490735.11 719728.71 8 490735.11 719728.71 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490738.17 719728.55 1.12 490739.19 719727.52 1.12 490739.19 719727.52 8 490738.17 719728.55 8 490738.17 719728.55 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490739.19 719727.52 1.12 490740.73 719727.49 1.12 490740.73 719727.49 8 490739.19 719727.52 8 490739.19 719727.52 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F3-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490740.73 719727.49 8 490741.74 719728.4 8 490744.82 719728.24 8 490745.2 719735.99 8 490746.05 719735.93 8 490746.19 719740.04 8 490736.84 719740.47 8 490736.65 719737.02 8 490735.6 719737.08 8 490735.11 719728.71 8 490738.17 719728.55 8 490739.19 719727.52 8 490740.73 719727.49 8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.97</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491476.78 719724.32 1.46 491477.65 719731.33 1.46 491481.06 719730.9 1.46 491481.4 719733.39 1.46 491485.53 719732.87 1.46 491485.64 719733.48 1.46 491488.34 719733.1 1.46 491488.13 719731.64 1.46 491490.65 719731.31 1.46 491490.43 719729.32 1.46 491491.58 719729.15 1.46 491490.8 719722.75 1.46 491489.45 719722.88 1.46 491487.21 719723.18 1.46 491487.05 719721.77 1.46 491486.88 719720.51 1.46 491486.71 719720.53 1.46 491480.54 719721.29 1.46 491480.82 719723.8 1.46 491476.78 719724.32 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491476.78 719724.32 1.46 491480.82 719723.8 1.46 491480.82 719723.8 10.43 491476.78 719724.32 10.43 491476.78 719724.32 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491480.82 719723.8 1.46 491480.54 719721.29 1.46 491480.54 719721.29 10.43 491480.82 719723.8 10.43 491480.82 719723.8 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491480.54 719721.29 1.46 491486.71 719720.53 1.46 491486.71 719720.53 10.43 491480.54 719721.29 10.43 491480.54 719721.29 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491486.71 719720.53 1.46 491486.88 719720.51 1.46 491486.88 719720.51 10.43 491486.71 719720.53 10.43 491486.71 719720.53 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491486.88 719720.51 1.46 491487.05 719721.77 1.46 491487.05 719721.77 10.43 491486.88 719720.51 10.43 491486.88 719720.51 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491487.05 719721.77 1.46 491487.21 719723.18 1.46 491487.21 719723.18 10.43 491487.05 719721.77 10.43 491487.05 719721.77 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491487.21 719723.18 1.46 491489.45 719722.88 1.46 491489.45 719722.88 10.43 491487.21 719723.18 10.43 491487.21 719723.18 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491489.45 719722.88 1.46 491490.8 719722.75 1.46 491490.8 719722.75 10.43 491489.45 719722.88 10.43 491489.45 719722.88 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491490.8 719722.75 1.46 491491.58 719729.15 1.46 491491.58 719729.15 10.43 491490.8 719722.75 10.43 491490.8 719722.75 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491491.58 719729.15 1.46 491490.43 719729.32 1.46 491490.43 719729.32 10.43 491491.58 719729.15 10.43 491491.58 719729.15 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491490.43 719729.32 1.46 491490.65 719731.31 1.46 491490.65 719731.31 10.43 491490.43 719729.32 10.43 491490.43 719729.32 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491490.65 719731.31 1.46 491488.13 719731.64 1.46 491488.13 719731.64 10.43 491490.65 719731.31 10.43 491490.65 719731.31 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491488.13 719731.64 1.46 491488.34 719733.1 1.46 491488.34 719733.1 10.43 491488.13 719731.64 10.43 491488.13 719731.64 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491488.34 719733.1 1.46 491485.64 719733.48 1.46 491485.64 719733.48 10.43 491488.34 719733.1 10.43 491488.34 719733.1 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491485.64 719733.48 1.46 491485.53 719732.87 1.46 491485.53 719732.87 10.43 491485.64 719733.48 10.43 491485.64 719733.48 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491485.53 719732.87 1.46 491481.4 719733.39 1.46 491481.4 719733.39 10.43 491485.53 719732.87 10.43 491485.53 719732.87 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491481.4 719733.39 1.46 491481.06 719730.9 1.46 491481.06 719730.9 10.43 491481.4 719733.39 10.43 491481.4 719733.39 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491481.06 719730.9 1.46 491477.65 719731.33 1.46 491477.65 719731.33 10.43 491481.06 719730.9 10.43 491481.06 719730.9 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491477.65 719731.33 1.46 491476.78 719724.32 1.46 491476.78 719724.32 10.43 491477.65 719731.33 10.43 491477.65 719731.33 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C0-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491476.78 719724.32 10.43 491480.82 719723.8 10.43 491480.54 719721.29 10.43 491486.71 719720.53 10.43 491486.88 719720.51 10.43 491487.05 719721.77 10.43 491487.21 719723.18 10.43 491489.45 719722.88 10.43 491490.8 719722.75 10.43 491491.58 719729.15 10.43 491490.43 719729.32 10.43 491490.65 719731.31 10.43 491488.13 719731.64 10.43 491488.34 719733.1 10.43 491485.64 719733.48 10.43 491485.53 719732.87 10.43 491481.4 719733.39 10.43 491481.06 719730.9 10.43 491477.65 719731.33 10.43 491476.78 719724.32 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-540D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-540D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.62</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-540D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491840.94 719951.78 6.37 491852.37 719947.36 6.37 491849.65 719940.4 6.37 491838.3 719944.86 6.37 491840.94 719951.78 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-540D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491840.94 719951.78 6.37 491838.3 719944.86 6.37 491838.3 719944.86 9.99 491840.94 719951.78 9.99 491840.94 719951.78 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-540D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491838.3 719944.86 6.37 491849.65 719940.4 6.37 491849.65 719940.4 9.99 491838.3 719944.86 9.99 491838.3 719944.86 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-540D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491849.65 719940.4 6.37 491852.37 719947.36 6.37 491852.37 719947.36 9.99 491849.65 719940.4 9.99 491849.65 719940.4 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-540D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491852.37 719947.36 6.37 491840.94 719951.78 6.37 491840.94 719951.78 9.99 491852.37 719947.36 9.99 491852.37 719947.36 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-540D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491840.94 719951.78 9.99 491838.3 719944.86 9.99 491849.65 719940.4 9.99 491852.37 719947.36 9.99 491840.94 719951.78 9.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5686-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5686-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.54</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5686-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491811.21 719543.39 1.53 491813.88 719550.71 1.53 491819.63 719548.61 1.53 491816.86 719541.15 1.53 491811.21 719543.39 1.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5686-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491811.21 719543.39 1.53 491816.86 719541.15 1.53 491816.86 719541.15 6.07 491811.21 719543.39 6.07 491811.21 719543.39 1.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5686-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491816.86 719541.15 1.53 491819.63 719548.61 1.53 491819.63 719548.61 6.07 491816.86 719541.15 6.07 491816.86 719541.15 1.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5686-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491819.63 719548.61 1.53 491813.88 719550.71 1.53 491813.88 719550.71 6.07 491819.63 719548.61 6.07 491819.63 719548.61 1.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5686-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491813.88 719550.71 1.53 491811.21 719543.39 1.53 491811.21 719543.39 6.07 491813.88 719550.71 6.07 491813.88 719550.71 1.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5686-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491811.21 719543.39 6.07 491816.86 719541.15 6.07 491819.63 719548.61 6.07 491813.88 719550.71 6.07 491811.21 719543.39 6.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6588-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6588-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.04</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6588-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489913.83 719853.51 1.3 489929.07 719854.02 1.3 489932.03 719854.12 1.3 489932.26 719847.67 1.3 489932.45 719842.5 1.3 489929.44 719842.38 1.3 489922.34 719842.09 1.3 489922.27 719844.21 1.3 489914.12 719843.91 1.3 489913.83 719853.51 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6588-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489913.83 719853.51 1.3 489914.12 719843.91 1.3 489914.12 719843.91 6.34 489913.83 719853.51 6.34 489913.83 719853.51 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6588-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489914.12 719843.91 1.3 489922.27 719844.21 1.3 489922.27 719844.21 6.34 489914.12 719843.91 6.34 489914.12 719843.91 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6588-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489922.27 719844.21 1.3 489922.34 719842.09 1.3 489922.34 719842.09 6.34 489922.27 719844.21 6.34 489922.27 719844.21 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6588-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489922.34 719842.09 1.3 489929.44 719842.38 1.3 489929.44 719842.38 6.34 489922.34 719842.09 6.34 489922.34 719842.09 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6588-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489929.44 719842.38 1.3 489932.45 719842.5 1.3 489932.45 719842.5 6.34 489929.44 719842.38 6.34 489929.44 719842.38 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6588-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489932.45 719842.5 1.3 489932.26 719847.67 1.3 489932.26 719847.67 6.34 489932.45 719842.5 6.34 489932.45 719842.5 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6588-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489932.26 719847.67 1.3 489932.03 719854.12 1.3 489932.03 719854.12 6.34 489932.26 719847.67 6.34 489932.26 719847.67 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6588-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489932.03 719854.12 1.3 489929.07 719854.02 1.3 489929.07 719854.02 6.34 489932.03 719854.12 6.34 489932.03 719854.12 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6588-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489929.07 719854.02 1.3 489913.83 719853.51 1.3 489913.83 719853.51 6.34 489929.07 719854.02 6.34 489929.07 719854.02 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6588-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489913.83 719853.51 6.34 489914.12 719843.91 6.34 489922.27 719844.21 6.34 489922.34 719842.09 6.34 489929.44 719842.38 6.34 489932.45 719842.5 6.34 489932.26 719847.67 6.34 489932.03 719854.12 6.34 489929.07 719854.02 6.34 489913.83 719853.51 6.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.49</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491300.96 719779.92 1.76 491301.65 719785.49 1.76 491314.6 719783.88 1.76 491313.95 719778.6 1.76 491310.77 719778.98 1.76 491310.47 719776.59 1.76 491309.81 719771.54 1.76 491302.14 719772.53 1.76 491302.8 719777.58 1.76 491303.05 719779.66 1.76 491300.96 719779.92 1.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491300.96 719779.92 1.76 491303.05 719779.66 1.76 491303.05 719779.66 8.25 491300.96 719779.92 8.25 491300.96 719779.92 1.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491303.05 719779.66 1.76 491302.8 719777.58 1.76 491302.8 719777.58 8.25 491303.05 719779.66 8.25 491303.05 719779.66 1.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491302.8 719777.58 1.76 491302.14 719772.53 1.76 491302.14 719772.53 8.25 491302.8 719777.58 8.25 491302.8 719777.58 1.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491302.14 719772.53 1.76 491309.81 719771.54 1.76 491309.81 719771.54 8.25 491302.14 719772.53 8.25 491302.14 719772.53 1.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491309.81 719771.54 1.76 491310.47 719776.59 1.76 491310.47 719776.59 8.25 491309.81 719771.54 8.25 491309.81 719771.54 1.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491310.47 719776.59 1.76 491310.77 719778.98 1.76 491310.77 719778.98 8.25 491310.47 719776.59 8.25 491310.47 719776.59 1.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491310.77 719778.98 1.76 491313.95 719778.6 1.76 491313.95 719778.6 8.25 491310.77 719778.98 8.25 491310.77 719778.98 1.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491313.95 719778.6 1.76 491314.6 719783.88 1.76 491314.6 719783.88 8.25 491313.95 719778.6 8.25 491313.95 719778.6 1.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491314.6 719783.88 1.76 491301.65 719785.49 1.76 491301.65 719785.49 8.25 491314.6 719783.88 8.25 491314.6 719783.88 1.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491301.65 719785.49 1.76 491300.96 719779.92 1.76 491300.96 719779.92 8.25 491301.65 719785.49 8.25 491301.65 719785.49 1.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FF-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491300.96 719779.92 8.25 491303.05 719779.66 8.25 491302.8 719777.58 8.25 491302.14 719772.53 8.25 491309.81 719771.54 8.25 491310.47 719776.59 8.25 491310.77 719778.98 8.25 491313.95 719778.6 8.25 491314.6 719783.88 8.25 491301.65 719785.49 8.25 491300.96 719779.92 8.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D75F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D75F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.31</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491762.27 720008.11 5.57 491768.36 720011.94 5.57 491771.67 720006.81 5.57 491765.58 720002.98 5.57 491762.27 720008.11 5.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491762.27 720008.11 5.57 491765.58 720002.98 5.57 491765.58 720002.98 8.88 491762.27 720008.11 8.88 491762.27 720008.11 5.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491765.58 720002.98 5.57 491771.67 720006.81 5.57 491771.67 720006.81 8.88 491765.58 720002.98 8.88 491765.58 720002.98 5.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491771.67 720006.81 5.57 491768.36 720011.94 5.57 491768.36 720011.94 8.88 491771.67 720006.81 8.88 491771.67 720006.81 5.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491768.36 720011.94 5.57 491762.27 720008.11 5.57 491762.27 720008.11 8.88 491768.36 720011.94 8.88 491768.36 720011.94 5.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491762.27 720008.11 8.88 491765.58 720002.98 8.88 491771.67 720006.81 8.88 491768.36 720011.94 8.88 491762.27 720008.11 8.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CE02-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CE02-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE02-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491278.72 719747.41 1.7 491279.73 719755.31 1.7 491291.64 719753.79 1.7 491290.61 719745.88 1.7 491278.72 719747.41 1.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE02-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491278.72 719747.41 1.7 491290.61 719745.88 1.7 491290.61 719745.88 5.64 491278.72 719747.41 5.64 491278.72 719747.41 1.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE02-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491290.61 719745.88 1.7 491291.64 719753.79 1.7 491291.64 719753.79 5.64 491290.61 719745.88 5.64 491290.61 719745.88 1.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE02-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491291.64 719753.79 1.7 491279.73 719755.31 1.7 491279.73 719755.31 5.64 491291.64 719753.79 5.64 491291.64 719753.79 1.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE02-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491279.73 719755.31 1.7 491278.72 719747.41 1.7 491278.72 719747.41 5.64 491279.73 719755.31 5.64 491279.73 719755.31 1.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE02-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491278.72 719747.41 5.64 491290.61 719745.88 5.64 491291.64 719753.79 5.64 491279.73 719755.31 5.64 491278.72 719747.41 5.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-76605509-3d10-41f4-8743-08d79d8beb16">
			<gen:stringAttribute name="buildingId">
				<gen:value>76605509-3d10-41f4-8743-08d79d8beb16</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.83</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-76605509-3d10-41f4-8743-08d79d8beb16_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491562.2 719663.36 1.16 491549.88 719666.91 1.16 491552.68 719676.71 1.16 491565.02 719673.19 1.16 491562.2 719663.36 1.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-76605509-3d10-41f4-8743-08d79d8beb16_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491562.2 719663.36 1.16 491565.02 719673.19 1.16 491565.02 719673.19 7.99 491562.2 719663.36 7.99 491562.2 719663.36 1.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-76605509-3d10-41f4-8743-08d79d8beb16_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491565.02 719673.19 1.16 491552.68 719676.71 1.16 491552.68 719676.71 7.99 491565.02 719673.19 7.99 491565.02 719673.19 1.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-76605509-3d10-41f4-8743-08d79d8beb16_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491552.68 719676.71 1.16 491549.88 719666.91 1.16 491549.88 719666.91 7.99 491552.68 719676.71 7.99 491552.68 719676.71 1.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-76605509-3d10-41f4-8743-08d79d8beb16_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491549.88 719666.91 1.16 491562.2 719663.36 1.16 491562.2 719663.36 7.99 491549.88 719666.91 7.99 491549.88 719666.91 1.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-76605509-3d10-41f4-8743-08d79d8beb16_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491562.2 719663.36 7.99 491565.02 719673.19 7.99 491552.68 719676.71 7.99 491549.88 719666.91 7.99 491562.2 719663.36 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-7a80c55a-77ed-45a7-9a0b-433b0693a1a8">
			<gen:stringAttribute name="buildingId">
				<gen:value>7a80c55a-77ed-45a7-9a0b-433b0693a1a8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.08</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7a80c55a-77ed-45a7-9a0b-433b0693a1a8_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490903.4 719737.25 1.6 490895.68 719737.53 1.6 490895.84 719741.41 1.6 490896.77 719741.39 1.6 490897.12 719749.47 1.6 490904.3 719749.22 1.6 490904 719740.57 1.6 490903.56 719740.58 1.6 490903.4 719737.25 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7a80c55a-77ed-45a7-9a0b-433b0693a1a8_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490903.4 719737.25 1.6 490903.56 719740.58 1.6 490903.56 719740.58 7.68 490903.4 719737.25 7.68 490903.4 719737.25 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7a80c55a-77ed-45a7-9a0b-433b0693a1a8_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490903.56 719740.58 1.6 490904 719740.57 1.6 490904 719740.57 7.68 490903.56 719740.58 7.68 490903.56 719740.58 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7a80c55a-77ed-45a7-9a0b-433b0693a1a8_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490904 719740.57 1.6 490904.3 719749.22 1.6 490904.3 719749.22 7.68 490904 719740.57 7.68 490904 719740.57 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7a80c55a-77ed-45a7-9a0b-433b0693a1a8_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490904.3 719749.22 1.6 490897.12 719749.47 1.6 490897.12 719749.47 7.68 490904.3 719749.22 7.68 490904.3 719749.22 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7a80c55a-77ed-45a7-9a0b-433b0693a1a8_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490897.12 719749.47 1.6 490896.77 719741.39 1.6 490896.77 719741.39 7.68 490897.12 719749.47 7.68 490897.12 719749.47 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7a80c55a-77ed-45a7-9a0b-433b0693a1a8_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490896.77 719741.39 1.6 490895.84 719741.41 1.6 490895.84 719741.41 7.68 490896.77 719741.39 7.68 490896.77 719741.39 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7a80c55a-77ed-45a7-9a0b-433b0693a1a8_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490895.84 719741.41 1.6 490895.68 719737.53 1.6 490895.68 719737.53 7.68 490895.84 719741.41 7.68 490895.84 719741.41 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7a80c55a-77ed-45a7-9a0b-433b0693a1a8_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490895.68 719737.53 1.6 490903.4 719737.25 1.6 490903.4 719737.25 7.68 490895.68 719737.53 7.68 490895.68 719737.53 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7a80c55a-77ed-45a7-9a0b-433b0693a1a8_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490903.4 719737.25 7.68 490903.56 719740.58 7.68 490904 719740.57 7.68 490904.3 719749.22 7.68 490897.12 719749.47 7.68 490896.77 719741.39 7.68 490895.84 719741.41 7.68 490895.68 719737.53 7.68 490903.4 719737.25 7.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-5cdc86b0-538b-4be9-9650-f2048246ae90">
			<gen:stringAttribute name="buildingId">
				<gen:value>5cdc86b0-538b-4be9-9650-f2048246ae90</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.75</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cdc86b0-538b-4be9-9650-f2048246ae90_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490648.77 719759.11 1.23 490649.59 719771.14 1.23 490658.48 719770.53 1.23 490657.66 719758.5 1.23 490648.77 719759.11 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cdc86b0-538b-4be9-9650-f2048246ae90_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490648.77 719759.11 1.23 490657.66 719758.5 1.23 490657.66 719758.5 6.98 490648.77 719759.11 6.98 490648.77 719759.11 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cdc86b0-538b-4be9-9650-f2048246ae90_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490657.66 719758.5 1.23 490658.48 719770.53 1.23 490658.48 719770.53 6.98 490657.66 719758.5 6.98 490657.66 719758.5 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cdc86b0-538b-4be9-9650-f2048246ae90_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490658.48 719770.53 1.23 490649.59 719771.14 1.23 490649.59 719771.14 6.98 490658.48 719770.53 6.98 490658.48 719770.53 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cdc86b0-538b-4be9-9650-f2048246ae90_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490649.59 719771.14 1.23 490648.77 719759.11 1.23 490648.77 719759.11 6.98 490649.59 719771.14 6.98 490649.59 719771.14 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cdc86b0-538b-4be9-9650-f2048246ae90_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490648.77 719759.11 6.98 490657.66 719758.5 6.98 490658.48 719770.53 6.98 490649.59 719771.14 6.98 490648.77 719759.11 6.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-31a73561-d713-4881-bc32-472266e6e8d1">
			<gen:stringAttribute name="buildingId">
				<gen:value>31a73561-d713-4881-bc32-472266e6e8d1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.9</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31a73561-d713-4881-bc32-472266e6e8d1_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491568.14 719695.63 1.45 491557.06 719698.79 1.45 491559.35 719706.9 1.45 491570.44 719703.77 1.45 491568.14 719695.63 1.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31a73561-d713-4881-bc32-472266e6e8d1_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491568.14 719695.63 1.45 491570.44 719703.77 1.45 491570.44 719703.77 7.3500000000000005 491568.14 719695.63 7.3500000000000005 491568.14 719695.63 1.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31a73561-d713-4881-bc32-472266e6e8d1_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491570.44 719703.77 1.45 491559.35 719706.9 1.45 491559.35 719706.9 7.3500000000000005 491570.44 719703.77 7.3500000000000005 491570.44 719703.77 1.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31a73561-d713-4881-bc32-472266e6e8d1_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491559.35 719706.9 1.45 491557.06 719698.79 1.45 491557.06 719698.79 7.3500000000000005 491559.35 719706.9 7.3500000000000005 491559.35 719706.9 1.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31a73561-d713-4881-bc32-472266e6e8d1_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491557.06 719698.79 1.45 491568.14 719695.63 1.45 491568.14 719695.63 7.3500000000000005 491557.06 719698.79 7.3500000000000005 491557.06 719698.79 1.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31a73561-d713-4881-bc32-472266e6e8d1_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491568.14 719695.63 7.3500000000000005 491570.44 719703.77 7.3500000000000005 491559.35 719706.9 7.3500000000000005 491557.06 719698.79 7.3500000000000005 491568.14 719695.63 7.3500000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-40269c48-c23a-4613-a2b2-c60997b39fbf">
			<gen:stringAttribute name="buildingId">
				<gen:value>40269c48-c23a-4613-a2b2-c60997b39fbf</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.76</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40269c48-c23a-4613-a2b2-c60997b39fbf_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491475.98 719718.06 0.8 491476.78 719724.32 0.8 491480.82 719723.8 0.8 491480.54 719721.29 0.8 491486.71 719720.53 0.8 491486.01 719714.78 0.8 491477.71 719715.83 0.8 491475.98 719718.06 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40269c48-c23a-4613-a2b2-c60997b39fbf_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491475.98 719718.06 0.8 491477.71 719715.83 0.8 491477.71 719715.83 3.5599999999999996 491475.98 719718.06 3.5599999999999996 491475.98 719718.06 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40269c48-c23a-4613-a2b2-c60997b39fbf_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491477.71 719715.83 0.8 491486.01 719714.78 0.8 491486.01 719714.78 3.5599999999999996 491477.71 719715.83 3.5599999999999996 491477.71 719715.83 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40269c48-c23a-4613-a2b2-c60997b39fbf_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491486.01 719714.78 0.8 491486.71 719720.53 0.8 491486.71 719720.53 3.5599999999999996 491486.01 719714.78 3.5599999999999996 491486.01 719714.78 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40269c48-c23a-4613-a2b2-c60997b39fbf_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491486.71 719720.53 0.8 491480.54 719721.29 0.8 491480.54 719721.29 3.5599999999999996 491486.71 719720.53 3.5599999999999996 491486.71 719720.53 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40269c48-c23a-4613-a2b2-c60997b39fbf_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491480.54 719721.29 0.8 491480.82 719723.8 0.8 491480.82 719723.8 3.5599999999999996 491480.54 719721.29 3.5599999999999996 491480.54 719721.29 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40269c48-c23a-4613-a2b2-c60997b39fbf_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491480.82 719723.8 0.8 491476.78 719724.32 0.8 491476.78 719724.32 3.5599999999999996 491480.82 719723.8 3.5599999999999996 491480.82 719723.8 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40269c48-c23a-4613-a2b2-c60997b39fbf_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491476.78 719724.32 0.8 491475.98 719718.06 0.8 491475.98 719718.06 3.5599999999999996 491476.78 719724.32 3.5599999999999996 491476.78 719724.32 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40269c48-c23a-4613-a2b2-c60997b39fbf_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491475.98 719718.06 3.5599999999999996 491477.71 719715.83 3.5599999999999996 491486.01 719714.78 3.5599999999999996 491486.71 719720.53 3.5599999999999996 491480.54 719721.29 3.5599999999999996 491480.82 719723.8 3.5599999999999996 491476.78 719724.32 3.5599999999999996 491475.98 719718.06 3.5599999999999996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-361cc14f-4d2d-464d-9fb5-601c6f280d09">
			<gen:stringAttribute name="buildingId">
				<gen:value>361cc14f-4d2d-464d-9fb5-601c6f280d09</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.87</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-361cc14f-4d2d-464d-9fb5-601c6f280d09_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490059.97 719831.99 1.19 490060.14 719843.26 1.19 490066.97 719843.16 1.19 490066.96 719842.3 1.19 490066.77 719832.39 1.19 490066.76 719831.87 1.19 490059.97 719831.99 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-361cc14f-4d2d-464d-9fb5-601c6f280d09_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490059.97 719831.99 1.19 490066.76 719831.87 1.19 490066.76 719831.87 11.06 490059.97 719831.99 11.06 490059.97 719831.99 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-361cc14f-4d2d-464d-9fb5-601c6f280d09_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490066.76 719831.87 1.19 490066.77 719832.39 1.19 490066.77 719832.39 11.06 490066.76 719831.87 11.06 490066.76 719831.87 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-361cc14f-4d2d-464d-9fb5-601c6f280d09_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490066.77 719832.39 1.19 490066.96 719842.3 1.19 490066.96 719842.3 11.06 490066.77 719832.39 11.06 490066.77 719832.39 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-361cc14f-4d2d-464d-9fb5-601c6f280d09_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490066.96 719842.3 1.19 490066.97 719843.16 1.19 490066.97 719843.16 11.06 490066.96 719842.3 11.06 490066.96 719842.3 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-361cc14f-4d2d-464d-9fb5-601c6f280d09_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490066.97 719843.16 1.19 490060.14 719843.26 1.19 490060.14 719843.26 11.06 490066.97 719843.16 11.06 490066.97 719843.16 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-361cc14f-4d2d-464d-9fb5-601c6f280d09_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490060.14 719843.26 1.19 490059.97 719831.99 1.19 490059.97 719831.99 11.06 490060.14 719843.26 11.06 490060.14 719843.26 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-361cc14f-4d2d-464d-9fb5-601c6f280d09_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490059.97 719831.99 11.06 490066.76 719831.87 11.06 490066.77 719832.39 11.06 490066.96 719842.3 11.06 490066.97 719843.16 11.06 490060.14 719843.26 11.06 490059.97 719831.99 11.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-b4c1ba33-20a1-435c-9c29-16352e33cfa4">
			<gen:stringAttribute name="buildingId">
				<gen:value>b4c1ba33-20a1-435c-9c29-16352e33cfa4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b4c1ba33-20a1-435c-9c29-16352e33cfa4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491516.84 719692.58 1.28 491519.65 719702.45 1.28 491531.99 719698.94 1.28 491529.19 719689.07 1.28 491516.84 719692.58 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b4c1ba33-20a1-435c-9c29-16352e33cfa4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491516.84 719692.58 1.28 491529.19 719689.07 1.28 491529.19 719689.07 7.88 491516.84 719692.58 7.88 491516.84 719692.58 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b4c1ba33-20a1-435c-9c29-16352e33cfa4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491529.19 719689.07 1.28 491531.99 719698.94 1.28 491531.99 719698.94 7.88 491529.19 719689.07 7.88 491529.19 719689.07 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b4c1ba33-20a1-435c-9c29-16352e33cfa4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491531.99 719698.94 1.28 491519.65 719702.45 1.28 491519.65 719702.45 7.88 491531.99 719698.94 7.88 491531.99 719698.94 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b4c1ba33-20a1-435c-9c29-16352e33cfa4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491519.65 719702.45 1.28 491516.84 719692.58 1.28 491516.84 719692.58 7.88 491519.65 719702.45 7.88 491519.65 719702.45 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b4c1ba33-20a1-435c-9c29-16352e33cfa4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491516.84 719692.58 7.88 491529.19 719689.07 7.88 491531.99 719698.94 7.88 491519.65 719702.45 7.88 491516.84 719692.58 7.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee">
			<gen:stringAttribute name="buildingId">
				<gen:value>32538e0f-887e-461d-87d7-c035cc8863ee</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.16</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490841.92 719696.05 0.59 490842.2 719705.64 0.59 490856.18 719705.17 0.59 490856.07 719701.57 0.59 490856.97 719701.54 0.59 490856.69 719692.63 0.59 490850.2 719692.86 0.59 490850.31 719696.8 0.59 490846.96 719696.81 0.59 490846.91 719695.81 0.59 490841.92 719696.05 0.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490841.92 719696.05 0.59 490846.91 719695.81 0.59 490846.91 719695.81 6.75 490841.92 719696.05 6.75 490841.92 719696.05 0.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490846.91 719695.81 0.59 490846.96 719696.81 0.59 490846.96 719696.81 6.75 490846.91 719695.81 6.75 490846.91 719695.81 0.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490846.96 719696.81 0.59 490850.31 719696.8 0.59 490850.31 719696.8 6.75 490846.96 719696.81 6.75 490846.96 719696.81 0.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490850.31 719696.8 0.59 490850.2 719692.86 0.59 490850.2 719692.86 6.75 490850.31 719696.8 6.75 490850.31 719696.8 0.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490850.2 719692.86 0.59 490856.69 719692.63 0.59 490856.69 719692.63 6.75 490850.2 719692.86 6.75 490850.2 719692.86 0.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490856.69 719692.63 0.59 490856.97 719701.54 0.59 490856.97 719701.54 6.75 490856.69 719692.63 6.75 490856.69 719692.63 0.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490856.97 719701.54 0.59 490856.07 719701.57 0.59 490856.07 719701.57 6.75 490856.97 719701.54 6.75 490856.97 719701.54 0.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490856.07 719701.57 0.59 490856.18 719705.17 0.59 490856.18 719705.17 6.75 490856.07 719701.57 6.75 490856.07 719701.57 0.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490856.18 719705.17 0.59 490842.2 719705.64 0.59 490842.2 719705.64 6.75 490856.18 719705.17 6.75 490856.18 719705.17 0.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490842.2 719705.64 0.59 490841.92 719696.05 0.59 490841.92 719696.05 6.75 490842.2 719705.64 6.75 490842.2 719705.64 0.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-32538e0f-887e-461d-87d7-c035cc8863ee_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490841.92 719696.05 6.75 490846.91 719695.81 6.75 490846.96 719696.81 6.75 490850.31 719696.8 6.75 490850.2 719692.86 6.75 490856.69 719692.63 6.75 490856.97 719701.54 6.75 490856.07 719701.57 6.75 490856.18 719705.17 6.75 490842.2 719705.64 6.75 490841.92 719696.05 6.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-dc6a89f1-62d0-4038-89c1-c2e2a5aa76cd">
			<gen:stringAttribute name="buildingId">
				<gen:value>dc6a89f1-62d0-4038-89c1-c2e2a5aa76cd</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.05</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-dc6a89f1-62d0-4038-89c1-c2e2a5aa76cd_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491249.68 719663.89 1.48 491251.4 719674.97 1.48 491257.77 719673.98 1.48 491256.8 719667.71 1.48 491267.02 719666.14 1.48 491265.61 719657.14 1.48 491250.69 719659.44 1.48 491251.34 719663.64 1.48 491249.68 719663.89 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-dc6a89f1-62d0-4038-89c1-c2e2a5aa76cd_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491249.68 719663.89 1.48 491251.34 719663.64 1.48 491251.34 719663.64 6.530000000000001 491249.68 719663.89 6.530000000000001 491249.68 719663.89 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-dc6a89f1-62d0-4038-89c1-c2e2a5aa76cd_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491251.34 719663.64 1.48 491250.69 719659.44 1.48 491250.69 719659.44 6.530000000000001 491251.34 719663.64 6.530000000000001 491251.34 719663.64 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-dc6a89f1-62d0-4038-89c1-c2e2a5aa76cd_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491250.69 719659.44 1.48 491265.61 719657.14 1.48 491265.61 719657.14 6.530000000000001 491250.69 719659.44 6.530000000000001 491250.69 719659.44 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-dc6a89f1-62d0-4038-89c1-c2e2a5aa76cd_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491265.61 719657.14 1.48 491267.02 719666.14 1.48 491267.02 719666.14 6.530000000000001 491265.61 719657.14 6.530000000000001 491265.61 719657.14 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-dc6a89f1-62d0-4038-89c1-c2e2a5aa76cd_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491267.02 719666.14 1.48 491256.8 719667.71 1.48 491256.8 719667.71 6.530000000000001 491267.02 719666.14 6.530000000000001 491267.02 719666.14 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-dc6a89f1-62d0-4038-89c1-c2e2a5aa76cd_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491256.8 719667.71 1.48 491257.77 719673.98 1.48 491257.77 719673.98 6.530000000000001 491256.8 719667.71 6.530000000000001 491256.8 719667.71 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-dc6a89f1-62d0-4038-89c1-c2e2a5aa76cd_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491257.77 719673.98 1.48 491251.4 719674.97 1.48 491251.4 719674.97 6.530000000000001 491257.77 719673.98 6.530000000000001 491257.77 719673.98 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-dc6a89f1-62d0-4038-89c1-c2e2a5aa76cd_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491251.4 719674.97 1.48 491249.68 719663.89 1.48 491249.68 719663.89 6.530000000000001 491251.4 719674.97 6.530000000000001 491251.4 719674.97 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-dc6a89f1-62d0-4038-89c1-c2e2a5aa76cd_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491249.68 719663.89 6.530000000000001 491251.34 719663.64 6.530000000000001 491250.69 719659.44 6.530000000000001 491265.61 719657.14 6.530000000000001 491267.02 719666.14 6.530000000000001 491256.8 719667.71 6.530000000000001 491257.77 719673.98 6.530000000000001 491251.4 719674.97 6.530000000000001 491249.68 719663.89 6.530000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7C61-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7C61-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7C61-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491383.12 719765.22 1.47 491384.21 719771.6 1.47 491388.81 719770.87 1.47 491387.77 719764.48 1.47 491383.12 719765.22 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7C61-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491383.12 719765.22 1.47 491387.77 719764.48 1.47 491387.77 719764.48 6.76 491383.12 719765.22 6.76 491383.12 719765.22 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7C61-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491387.77 719764.48 1.47 491388.81 719770.87 1.47 491388.81 719770.87 6.76 491387.77 719764.48 6.76 491387.77 719764.48 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7C61-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491388.81 719770.87 1.47 491384.21 719771.6 1.47 491384.21 719771.6 6.76 491388.81 719770.87 6.76 491388.81 719770.87 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7C61-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491384.21 719771.6 1.47 491383.12 719765.22 1.47 491383.12 719765.22 6.76 491384.21 719771.6 6.76 491384.21 719771.6 1.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7C61-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491383.12 719765.22 6.76 491387.77 719764.48 6.76 491388.81 719770.87 6.76 491384.21 719771.6 6.76 491383.12 719765.22 6.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-bf68d254-565b-4810-af4d-9a746fb1b780">
			<gen:stringAttribute name="buildingId">
				<gen:value>bf68d254-565b-4810-af4d-9a746fb1b780</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.52</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bf68d254-565b-4810-af4d-9a746fb1b780_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490731.2 719704.12 0.86 490731.92 719717.77 0.86 490742.96 719717.21 0.86 490742.26 719703.56 0.86 490731.2 719704.12 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bf68d254-565b-4810-af4d-9a746fb1b780_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490731.2 719704.12 0.86 490742.26 719703.56 0.86 490742.26 719703.56 7.38 490731.2 719704.12 7.38 490731.2 719704.12 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bf68d254-565b-4810-af4d-9a746fb1b780_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490742.26 719703.56 0.86 490742.96 719717.21 0.86 490742.96 719717.21 7.38 490742.26 719703.56 7.38 490742.26 719703.56 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bf68d254-565b-4810-af4d-9a746fb1b780_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490742.96 719717.21 0.86 490731.92 719717.77 0.86 490731.92 719717.77 7.38 490742.96 719717.21 7.38 490742.96 719717.21 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bf68d254-565b-4810-af4d-9a746fb1b780_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490731.92 719717.77 0.86 490731.2 719704.12 0.86 490731.2 719704.12 7.38 490731.92 719717.77 7.38 490731.92 719717.77 0.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bf68d254-565b-4810-af4d-9a746fb1b780_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490731.2 719704.12 7.38 490742.26 719703.56 7.38 490742.96 719717.21 7.38 490731.92 719717.77 7.38 490731.2 719704.12 7.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e">
			<gen:stringAttribute name="buildingId">
				<gen:value>8d9a122c-f5e9-4d57-ba04-903ab8732d7e</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.82</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491584.57 719730.28 1.87 491576.49 719731.72 1.87 491574.78 719732.04 1.87 491574.54 719730.65 1.87 491567.04 719732 1.87 491567.51 719734.62 1.87 491566.35 719734.85 1.87 491567.06 719738.75 1.87 491568.23 719738.5 1.87 491568.73 719741.21 1.87 491574.82 719740.11 1.87 491574.58 719738.72 1.87 491577.69 719738.17 1.87 491585.77 719736.72 1.87 491584.57 719730.28 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491584.57 719730.28 1.87 491585.77 719736.72 1.87 491585.77 719736.72 8.69 491584.57 719730.28 8.69 491584.57 719730.28 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491585.77 719736.72 1.87 491577.69 719738.17 1.87 491577.69 719738.17 8.69 491585.77 719736.72 8.69 491585.77 719736.72 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491577.69 719738.17 1.87 491574.58 719738.72 1.87 491574.58 719738.72 8.69 491577.69 719738.17 8.69 491577.69 719738.17 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491574.58 719738.72 1.87 491574.82 719740.11 1.87 491574.82 719740.11 8.69 491574.58 719738.72 8.69 491574.58 719738.72 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491574.82 719740.11 1.87 491568.73 719741.21 1.87 491568.73 719741.21 8.69 491574.82 719740.11 8.69 491574.82 719740.11 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491568.73 719741.21 1.87 491568.23 719738.5 1.87 491568.23 719738.5 8.69 491568.73 719741.21 8.69 491568.73 719741.21 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491568.23 719738.5 1.87 491567.06 719738.75 1.87 491567.06 719738.75 8.69 491568.23 719738.5 8.69 491568.23 719738.5 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491567.06 719738.75 1.87 491566.35 719734.85 1.87 491566.35 719734.85 8.69 491567.06 719738.75 8.69 491567.06 719738.75 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491566.35 719734.85 1.87 491567.51 719734.62 1.87 491567.51 719734.62 8.69 491566.35 719734.85 8.69 491566.35 719734.85 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491567.51 719734.62 1.87 491567.04 719732 1.87 491567.04 719732 8.69 491567.51 719734.62 8.69 491567.51 719734.62 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491567.04 719732 1.87 491574.54 719730.65 1.87 491574.54 719730.65 8.69 491567.04 719732 8.69 491567.04 719732 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491574.54 719730.65 1.87 491574.78 719732.04 1.87 491574.78 719732.04 8.69 491574.54 719730.65 8.69 491574.54 719730.65 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491574.78 719732.04 1.87 491576.49 719731.72 1.87 491576.49 719731.72 8.69 491574.78 719732.04 8.69 491574.78 719732.04 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491576.49 719731.72 1.87 491584.57 719730.28 1.87 491584.57 719730.28 8.69 491576.49 719731.72 8.69 491576.49 719731.72 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-8d9a122c-f5e9-4d57-ba04-903ab8732d7e_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491584.57 719730.28 8.69 491585.77 719736.72 8.69 491577.69 719738.17 8.69 491574.58 719738.72 8.69 491574.82 719740.11 8.69 491568.73 719741.21 8.69 491568.23 719738.5 8.69 491567.06 719738.75 8.69 491566.35 719734.85 8.69 491567.51 719734.62 8.69 491567.04 719732 8.69 491574.54 719730.65 8.69 491574.78 719732.04 8.69 491576.49 719731.72 8.69 491584.57 719730.28 8.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011">
			<gen:stringAttribute name="buildingId">
				<gen:value>c530b8b8-4c9b-4310-bf02-723c7105a011</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.41</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490032.01 719829.68 1.32 490032.24 719846.14 1.32 490038.83 719846.04 1.32 490038.82 719845.54 1.32 490044.83 719845.46 1.32 490044.83 719844.97 1.32 490050.79 719844.89 1.32 490050.8 719844.38 1.32 490056.78 719844.32 1.32 490056.61 719831.1 1.32 490050.62 719831.19 1.32 490050.61 719830.72 1.32 490044.63 719830.8 1.32 490044.61 719830.29 1.32 490038.61 719830.41 1.32 490038.61 719829.9 1.32 490032.6 719829.97 1.32 490032.61 719829.67 1.32 490032.01 719829.68 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490032.01 719829.68 1.32 490032.61 719829.67 1.32 490032.61 719829.67 11.73 490032.01 719829.68 11.73 490032.01 719829.68 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490032.61 719829.67 1.32 490032.6 719829.97 1.32 490032.6 719829.97 11.73 490032.61 719829.67 11.73 490032.61 719829.67 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490032.6 719829.97 1.32 490038.61 719829.9 1.32 490038.61 719829.9 11.73 490032.6 719829.97 11.73 490032.6 719829.97 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490038.61 719829.9 1.32 490038.61 719830.41 1.32 490038.61 719830.41 11.73 490038.61 719829.9 11.73 490038.61 719829.9 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490038.61 719830.41 1.32 490044.61 719830.29 1.32 490044.61 719830.29 11.73 490038.61 719830.41 11.73 490038.61 719830.41 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490044.61 719830.29 1.32 490044.63 719830.8 1.32 490044.63 719830.8 11.73 490044.61 719830.29 11.73 490044.61 719830.29 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490044.63 719830.8 1.32 490050.61 719830.72 1.32 490050.61 719830.72 11.73 490044.63 719830.8 11.73 490044.63 719830.8 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490050.61 719830.72 1.32 490050.62 719831.19 1.32 490050.62 719831.19 11.73 490050.61 719830.72 11.73 490050.61 719830.72 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490050.62 719831.19 1.32 490056.61 719831.1 1.32 490056.61 719831.1 11.73 490050.62 719831.19 11.73 490050.62 719831.19 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490056.61 719831.1 1.32 490056.78 719844.32 1.32 490056.78 719844.32 11.73 490056.61 719831.1 11.73 490056.61 719831.1 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490056.78 719844.32 1.32 490050.8 719844.38 1.32 490050.8 719844.38 11.73 490056.78 719844.32 11.73 490056.78 719844.32 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490050.8 719844.38 1.32 490050.79 719844.89 1.32 490050.79 719844.89 11.73 490050.8 719844.38 11.73 490050.8 719844.38 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490050.79 719844.89 1.32 490044.83 719844.97 1.32 490044.83 719844.97 11.73 490050.79 719844.89 11.73 490050.79 719844.89 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490044.83 719844.97 1.32 490044.83 719845.46 1.32 490044.83 719845.46 11.73 490044.83 719844.97 11.73 490044.83 719844.97 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490044.83 719845.46 1.32 490038.82 719845.54 1.32 490038.82 719845.54 11.73 490044.83 719845.46 11.73 490044.83 719845.46 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490038.82 719845.54 1.32 490038.83 719846.04 1.32 490038.83 719846.04 11.73 490038.82 719845.54 11.73 490038.82 719845.54 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490038.83 719846.04 1.32 490032.24 719846.14 1.32 490032.24 719846.14 11.73 490038.83 719846.04 11.73 490038.83 719846.04 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490032.24 719846.14 1.32 490032.01 719829.68 1.32 490032.01 719829.68 11.73 490032.24 719846.14 11.73 490032.24 719846.14 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c530b8b8-4c9b-4310-bf02-723c7105a011_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490032.01 719829.68 11.73 490032.61 719829.67 11.73 490032.6 719829.97 11.73 490038.61 719829.9 11.73 490038.61 719830.41 11.73 490044.61 719830.29 11.73 490044.63 719830.8 11.73 490050.61 719830.72 11.73 490050.62 719831.19 11.73 490056.61 719831.1 11.73 490056.78 719844.32 11.73 490050.8 719844.38 11.73 490050.79 719844.89 11.73 490044.83 719844.97 11.73 490044.83 719845.46 11.73 490038.82 719845.54 11.73 490038.83 719846.04 11.73 490032.24 719846.14 11.73 490032.01 719829.68 11.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-3b9ac236-bf9f-4c1d-be9c-bf6986dd3e54">
			<gen:stringAttribute name="buildingId">
				<gen:value>3b9ac236-bf9f-4c1d-be9c-bf6986dd3e54</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3b9ac236-bf9f-4c1d-be9c-bf6986dd3e54_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490688.7 719717.33 0.98 490689.39 719730.96 0.98 490700.45 719730.39 0.98 490700.36 719725.53 0.98 490701.7 719725.42 0.98 490701.17 719718.21 0.98 490699.86 719718.29 0.98 490699.76 719716.78 0.98 490688.7 719717.33 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3b9ac236-bf9f-4c1d-be9c-bf6986dd3e54_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490688.7 719717.33 0.98 490699.76 719716.78 0.98 490699.76 719716.78 7.58 490688.7 719717.33 7.58 490688.7 719717.33 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3b9ac236-bf9f-4c1d-be9c-bf6986dd3e54_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490699.76 719716.78 0.98 490699.86 719718.29 0.98 490699.86 719718.29 7.58 490699.76 719716.78 7.58 490699.76 719716.78 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3b9ac236-bf9f-4c1d-be9c-bf6986dd3e54_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490699.86 719718.29 0.98 490701.17 719718.21 0.98 490701.17 719718.21 7.58 490699.86 719718.29 7.58 490699.86 719718.29 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3b9ac236-bf9f-4c1d-be9c-bf6986dd3e54_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490701.17 719718.21 0.98 490701.7 719725.42 0.98 490701.7 719725.42 7.58 490701.17 719718.21 7.58 490701.17 719718.21 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3b9ac236-bf9f-4c1d-be9c-bf6986dd3e54_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490701.7 719725.42 0.98 490700.36 719725.53 0.98 490700.36 719725.53 7.58 490701.7 719725.42 7.58 490701.7 719725.42 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3b9ac236-bf9f-4c1d-be9c-bf6986dd3e54_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490700.36 719725.53 0.98 490700.45 719730.39 0.98 490700.45 719730.39 7.58 490700.36 719725.53 7.58 490700.36 719725.53 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3b9ac236-bf9f-4c1d-be9c-bf6986dd3e54_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490700.45 719730.39 0.98 490689.39 719730.96 0.98 490689.39 719730.96 7.58 490700.45 719730.39 7.58 490700.45 719730.39 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3b9ac236-bf9f-4c1d-be9c-bf6986dd3e54_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490689.39 719730.96 0.98 490688.7 719717.33 0.98 490688.7 719717.33 7.58 490689.39 719730.96 7.58 490689.39 719730.96 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3b9ac236-bf9f-4c1d-be9c-bf6986dd3e54_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490688.7 719717.33 7.58 490699.76 719716.78 7.58 490699.86 719718.29 7.58 490701.17 719718.21 7.58 490701.7 719725.42 7.58 490700.36 719725.53 7.58 490700.45 719730.39 7.58 490689.39 719730.96 7.58 490688.7 719717.33 7.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-0034357b-77be-4437-92f1-f955cc418699">
			<gen:stringAttribute name="buildingId">
				<gen:value>0034357b-77be-4437-92f1-f955cc418699</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0034357b-77be-4437-92f1-f955cc418699_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490764.64 719710.22 0.87 490764.86 719714.41 0.87 490774.73 719713.89 0.87 490774.11 719701.65 0.87 490765.55 719702.08 0.87 490765.97 719710.12 0.87 490764.64 719710.22 0.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0034357b-77be-4437-92f1-f955cc418699_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490764.64 719710.22 0.87 490765.97 719710.12 0.87 490765.97 719710.12 7.3 490764.64 719710.22 7.3 490764.64 719710.22 0.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0034357b-77be-4437-92f1-f955cc418699_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490765.97 719710.12 0.87 490765.55 719702.08 0.87 490765.55 719702.08 7.3 490765.97 719710.12 7.3 490765.97 719710.12 0.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0034357b-77be-4437-92f1-f955cc418699_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490765.55 719702.08 0.87 490774.11 719701.65 0.87 490774.11 719701.65 7.3 490765.55 719702.08 7.3 490765.55 719702.08 0.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0034357b-77be-4437-92f1-f955cc418699_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490774.11 719701.65 0.87 490774.73 719713.89 0.87 490774.73 719713.89 7.3 490774.11 719701.65 7.3 490774.11 719701.65 0.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0034357b-77be-4437-92f1-f955cc418699_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490774.73 719713.89 0.87 490764.86 719714.41 0.87 490764.86 719714.41 7.3 490774.73 719713.89 7.3 490774.73 719713.89 0.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0034357b-77be-4437-92f1-f955cc418699_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490764.86 719714.41 0.87 490764.64 719710.22 0.87 490764.64 719710.22 7.3 490764.86 719714.41 7.3 490764.86 719714.41 0.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0034357b-77be-4437-92f1-f955cc418699_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490764.64 719710.22 7.3 490765.97 719710.12 7.3 490765.55 719702.08 7.3 490774.11 719701.65 7.3 490774.73 719713.89 7.3 490764.86 719714.41 7.3 490764.64 719710.22 7.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1">
			<gen:stringAttribute name="buildingId">
				<gen:value>f2c12d55-c96a-4160-8375-f77a47cdbbc1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.88</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490789.92 719659.9 0.69 490789.63 719665.36 0.69 490788.21 719665.3 0.69 490788.01 719669.01 0.69 490789.4 719669.08 0.69 490789.2 719672.02 0.69 490793.82 719672.28 0.69 490793.75 719673.68 0.69 490797.69 719673.86 0.69 490797.84 719671.51 0.69 490804.3 719671.88 0.69 490804.79 719663.15 0.69 490798.33 719662.8 0.69 490798.47 719660.32 0.69 490789.92 719659.9 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490789.92 719659.9 0.69 490798.47 719660.32 0.69 490798.47 719660.32 7.57 490789.92 719659.9 7.57 490789.92 719659.9 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490798.47 719660.32 0.69 490798.33 719662.8 0.69 490798.33 719662.8 7.57 490798.47 719660.32 7.57 490798.47 719660.32 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490798.33 719662.8 0.69 490804.79 719663.15 0.69 490804.79 719663.15 7.57 490798.33 719662.8 7.57 490798.33 719662.8 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490804.79 719663.15 0.69 490804.3 719671.88 0.69 490804.3 719671.88 7.57 490804.79 719663.15 7.57 490804.79 719663.15 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490804.3 719671.88 0.69 490797.84 719671.51 0.69 490797.84 719671.51 7.57 490804.3 719671.88 7.57 490804.3 719671.88 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490797.84 719671.51 0.69 490797.69 719673.86 0.69 490797.69 719673.86 7.57 490797.84 719671.51 7.57 490797.84 719671.51 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490797.69 719673.86 0.69 490793.75 719673.68 0.69 490793.75 719673.68 7.57 490797.69 719673.86 7.57 490797.69 719673.86 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490793.75 719673.68 0.69 490793.82 719672.28 0.69 490793.82 719672.28 7.57 490793.75 719673.68 7.57 490793.75 719673.68 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490793.82 719672.28 0.69 490789.2 719672.02 0.69 490789.2 719672.02 7.57 490793.82 719672.28 7.57 490793.82 719672.28 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490789.2 719672.02 0.69 490789.4 719669.08 0.69 490789.4 719669.08 7.57 490789.2 719672.02 7.57 490789.2 719672.02 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490789.4 719669.08 0.69 490788.01 719669.01 0.69 490788.01 719669.01 7.57 490789.4 719669.08 7.57 490789.4 719669.08 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490788.01 719669.01 0.69 490788.21 719665.3 0.69 490788.21 719665.3 7.57 490788.01 719669.01 7.57 490788.01 719669.01 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490788.21 719665.3 0.69 490789.63 719665.36 0.69 490789.63 719665.36 7.57 490788.21 719665.3 7.57 490788.21 719665.3 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490789.63 719665.36 0.69 490789.92 719659.9 0.69 490789.92 719659.9 7.57 490789.63 719665.36 7.57 490789.63 719665.36 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f2c12d55-c96a-4160-8375-f77a47cdbbc1_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490789.92 719659.9 7.57 490798.47 719660.32 7.57 490798.33 719662.8 7.57 490804.79 719663.15 7.57 490804.3 719671.88 7.57 490797.84 719671.51 7.57 490797.69 719673.86 7.57 490793.75 719673.68 7.57 490793.82 719672.28 7.57 490789.2 719672.02 7.57 490789.4 719669.08 7.57 490788.01 719669.01 7.57 490788.21 719665.3 7.57 490789.63 719665.36 7.57 490789.92 719659.9 7.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-4b4aa0dc-84b4-4b14-bb6a-d7871d50004c">
			<gen:stringAttribute name="buildingId">
				<gen:value>4b4aa0dc-84b4-4b14-bb6a-d7871d50004c</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.01</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b4aa0dc-84b4-4b14-bb6a-d7871d50004c_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491654.71 719690.83 1.5 491655.99 719695.14 1.5 491659.54 719706.1 1.5 491664.13 719704.69 1.5 491666.13 719711.1 1.5 491672.52 719709.06 1.5 491665.67 719687.39 1.5 491654.71 719690.83 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b4aa0dc-84b4-4b14-bb6a-d7871d50004c_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491654.71 719690.83 1.5 491665.67 719687.39 1.5 491665.67 719687.39 6.51 491654.71 719690.83 6.51 491654.71 719690.83 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b4aa0dc-84b4-4b14-bb6a-d7871d50004c_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491665.67 719687.39 1.5 491672.52 719709.06 1.5 491672.52 719709.06 6.51 491665.67 719687.39 6.51 491665.67 719687.39 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b4aa0dc-84b4-4b14-bb6a-d7871d50004c_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491672.52 719709.06 1.5 491666.13 719711.1 1.5 491666.13 719711.1 6.51 491672.52 719709.06 6.51 491672.52 719709.06 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b4aa0dc-84b4-4b14-bb6a-d7871d50004c_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491666.13 719711.1 1.5 491664.13 719704.69 1.5 491664.13 719704.69 6.51 491666.13 719711.1 6.51 491666.13 719711.1 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b4aa0dc-84b4-4b14-bb6a-d7871d50004c_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491664.13 719704.69 1.5 491659.54 719706.1 1.5 491659.54 719706.1 6.51 491664.13 719704.69 6.51 491664.13 719704.69 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b4aa0dc-84b4-4b14-bb6a-d7871d50004c_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491659.54 719706.1 1.5 491655.99 719695.14 1.5 491655.99 719695.14 6.51 491659.54 719706.1 6.51 491659.54 719706.1 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b4aa0dc-84b4-4b14-bb6a-d7871d50004c_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491655.99 719695.14 1.5 491654.71 719690.83 1.5 491654.71 719690.83 6.51 491655.99 719695.14 6.51 491655.99 719695.14 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b4aa0dc-84b4-4b14-bb6a-d7871d50004c_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491654.71 719690.83 6.51 491665.67 719687.39 6.51 491672.52 719709.06 6.51 491666.13 719711.1 6.51 491664.13 719704.69 6.51 491659.54 719706.1 6.51 491655.99 719695.14 6.51 491654.71 719690.83 6.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5B38-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5B38-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.69</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5B38-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491725.71 720095.3 6.44 491727.72 720100.68 6.44 491733.61 720098.52 6.44 491731.58 720093.13 6.44 491725.71 720095.3 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5B38-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491725.71 720095.3 6.44 491731.58 720093.13 6.44 491731.58 720093.13 10.13 491725.71 720095.3 10.13 491725.71 720095.3 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5B38-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491731.58 720093.13 6.44 491733.61 720098.52 6.44 491733.61 720098.52 10.13 491731.58 720093.13 10.13 491731.58 720093.13 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5B38-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491733.61 720098.52 6.44 491727.72 720100.68 6.44 491727.72 720100.68 10.13 491733.61 720098.52 10.13 491733.61 720098.52 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5B38-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491727.72 720100.68 6.44 491725.71 720095.3 6.44 491725.71 720095.3 10.13 491727.72 720100.68 10.13 491727.72 720100.68 6.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5B38-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491725.71 720095.3 10.13 491731.58 720093.13 10.13 491733.61 720098.52 10.13 491727.72 720100.68 10.13 491725.71 720095.3 10.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D789-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D789-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.45</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D789-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491760.08 719883.07 11.3 491770.39 719883.82 11.3 491771.62 719868.88 11.3 491761.36 719868.08 11.3 491760.08 719883.07 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D789-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491760.08 719883.07 11.3 491761.36 719868.08 11.3 491761.36 719868.08 17.75 491760.08 719883.07 17.75 491760.08 719883.07 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D789-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491761.36 719868.08 11.3 491771.62 719868.88 11.3 491771.62 719868.88 17.75 491761.36 719868.08 17.75 491761.36 719868.08 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D789-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491771.62 719868.88 11.3 491770.39 719883.82 11.3 491770.39 719883.82 17.75 491771.62 719868.88 17.75 491771.62 719868.88 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D789-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491770.39 719883.82 11.3 491760.08 719883.07 11.3 491760.08 719883.07 17.75 491770.39 719883.82 17.75 491770.39 719883.82 11.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D789-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491760.08 719883.07 17.75 491761.36 719868.08 17.75 491771.62 719868.88 17.75 491770.39 719883.82 17.75 491760.08 719883.07 17.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D788-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491736.6 719884.92 10.74 491742.06 719885.38 10.74 491741.97 719886.58 10.74 491745.27 719886.88 10.74 491745.12 719889.46 10.74 491751.14 719889.99 10.74 491751.34 719887.4 10.74 491754.7 719887.65 10.74 491755.39 719879.19 10.74 491742.72 719878.1 10.74 491742.58 719879.29 10.74 491737.1 719878.87 10.74 491736.6 719884.92 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491736.6 719884.92 10.74 491737.1 719878.87 10.74 491737.1 719878.87 17.55 491736.6 719884.92 17.55 491736.6 719884.92 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491737.1 719878.87 10.74 491742.58 719879.29 10.74 491742.58 719879.29 17.55 491737.1 719878.87 17.55 491737.1 719878.87 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491742.58 719879.29 10.74 491742.72 719878.1 10.74 491742.72 719878.1 17.55 491742.58 719879.29 17.55 491742.58 719879.29 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491742.72 719878.1 10.74 491755.39 719879.19 10.74 491755.39 719879.19 17.55 491742.72 719878.1 17.55 491742.72 719878.1 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491755.39 719879.19 10.74 491754.7 719887.65 10.74 491754.7 719887.65 17.55 491755.39 719879.19 17.55 491755.39 719879.19 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491754.7 719887.65 10.74 491751.34 719887.4 10.74 491751.34 719887.4 17.55 491754.7 719887.65 17.55 491754.7 719887.65 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491751.34 719887.4 10.74 491751.14 719889.99 10.74 491751.14 719889.99 17.55 491751.34 719887.4 17.55 491751.34 719887.4 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491751.14 719889.99 10.74 491745.12 719889.46 10.74 491745.12 719889.46 17.55 491751.14 719889.99 17.55 491751.14 719889.99 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491745.12 719889.46 10.74 491745.27 719886.88 10.74 491745.27 719886.88 17.55 491745.12 719889.46 17.55 491745.12 719889.46 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491745.27 719886.88 10.74 491741.97 719886.58 10.74 491741.97 719886.58 17.55 491745.27 719886.88 17.55 491745.27 719886.88 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491741.97 719886.58 10.74 491742.06 719885.38 10.74 491742.06 719885.38 17.55 491741.97 719886.58 17.55 491741.97 719886.58 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491742.06 719885.38 10.74 491736.6 719884.92 10.74 491736.6 719884.92 17.55 491742.06 719885.38 17.55 491742.06 719885.38 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D788-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491736.6 719884.92 17.55 491737.1 719878.87 17.55 491742.58 719879.29 17.55 491742.72 719878.1 17.55 491755.39 719879.19 17.55 491754.7 719887.65 17.55 491751.34 719887.4 17.55 491751.14 719889.99 17.55 491745.12 719889.46 17.55 491745.27 719886.88 17.55 491741.97 719886.58 17.55 491742.06 719885.38 17.55 491736.6 719884.92 17.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D787-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D787-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.78</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D787-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491660.22 719869.9 10.9 491662.13 719877.23 10.9 491673.76 719874.31 10.9 491674.62 719877.45 10.9 491692.62 719872.8 10.9 491691.78 719869.7 10.9 491703.35 719866.65 10.9 491701.38 719859.35 10.9 491660.22 719869.9 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D787-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491660.22 719869.9 10.9 491701.38 719859.35 10.9 491701.38 719859.35 17.68 491660.22 719869.9 17.68 491660.22 719869.9 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D787-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491701.38 719859.35 10.9 491703.35 719866.65 10.9 491703.35 719866.65 17.68 491701.38 719859.35 17.68 491701.38 719859.35 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D787-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491703.35 719866.65 10.9 491691.78 719869.7 10.9 491691.78 719869.7 17.68 491703.35 719866.65 17.68 491703.35 719866.65 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D787-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491691.78 719869.7 10.9 491692.62 719872.8 10.9 491692.62 719872.8 17.68 491691.78 719869.7 17.68 491691.78 719869.7 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D787-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491692.62 719872.8 10.9 491674.62 719877.45 10.9 491674.62 719877.45 17.68 491692.62 719872.8 17.68 491692.62 719872.8 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D787-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491674.62 719877.45 10.9 491673.76 719874.31 10.9 491673.76 719874.31 17.68 491674.62 719877.45 17.68 491674.62 719877.45 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D787-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491673.76 719874.31 10.9 491662.13 719877.23 10.9 491662.13 719877.23 17.68 491673.76 719874.31 17.68 491673.76 719874.31 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D787-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491662.13 719877.23 10.9 491660.22 719869.9 10.9 491660.22 719869.9 17.68 491662.13 719877.23 17.68 491662.13 719877.23 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D787-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491660.22 719869.9 17.68 491701.38 719859.35 17.68 491703.35 719866.65 17.68 491691.78 719869.7 17.68 491692.62 719872.8 17.68 491674.62 719877.45 17.68 491673.76 719874.31 17.68 491662.13 719877.23 17.68 491660.22 719869.9 17.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CC65-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CC65-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.49</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC65-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490736.37 719687.92 0.91 490736.82 719694.58 0.91 490743.91 719694.24 0.91 490743.54 719687.55 0.91 490736.37 719687.92 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC65-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490736.37 719687.92 0.91 490743.54 719687.55 0.91 490743.54 719687.55 6.4 490736.37 719687.92 6.4 490736.37 719687.92 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC65-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490743.54 719687.55 0.91 490743.91 719694.24 0.91 490743.91 719694.24 6.4 490743.54 719687.55 6.4 490743.54 719687.55 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC65-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490743.91 719694.24 0.91 490736.82 719694.58 0.91 490736.82 719694.58 6.4 490743.91 719694.24 6.4 490743.91 719694.24 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC65-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490736.82 719694.58 0.91 490736.37 719687.92 0.91 490736.37 719687.92 6.4 490736.82 719694.58 6.4 490736.82 719694.58 0.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC65-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490736.37 719687.92 6.4 490743.54 719687.55 6.4 490743.91 719694.24 6.4 490736.82 719694.58 6.4 490736.37 719687.92 6.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CDFF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CDFF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CDFF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491260.65 719745.19 2.02 491266.17 719744.67 2.02 491265.09 719733.47 2.02 491259.62 719733.99 2.02 491260.65 719745.19 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CDFF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491260.65 719745.19 2.02 491259.62 719733.99 2.02 491259.62 719733.99 6.549999999999999 491260.65 719745.19 6.549999999999999 491260.65 719745.19 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CDFF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491259.62 719733.99 2.02 491265.09 719733.47 2.02 491265.09 719733.47 6.549999999999999 491259.62 719733.99 6.549999999999999 491259.62 719733.99 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CDFF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491265.09 719733.47 2.02 491266.17 719744.67 2.02 491266.17 719744.67 6.549999999999999 491265.09 719733.47 6.549999999999999 491265.09 719733.47 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CDFF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491266.17 719744.67 2.02 491260.65 719745.19 2.02 491260.65 719745.19 6.549999999999999 491266.17 719744.67 6.549999999999999 491266.17 719744.67 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CDFF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491260.65 719745.19 6.549999999999999 491259.62 719733.99 6.549999999999999 491265.09 719733.47 6.549999999999999 491266.17 719744.67 6.549999999999999 491260.65 719745.19 6.549999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-f32df644-d3d2-40d8-afdb-3ea0001ca8c7">
			<gen:stringAttribute name="buildingId">
				<gen:value>f32df644-d3d2-40d8-afdb-3ea0001ca8c7</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.07</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f32df644-d3d2-40d8-afdb-3ea0001ca8c7_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.19 719832.78 1.19 490073.37 719841.33 1.19 490079.8 719841.25 1.19 490079.79 719840.38 1.19 490079.64 719833.19 1.19 490079.62 719832.69 1.19 490073.19 719832.78 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f32df644-d3d2-40d8-afdb-3ea0001ca8c7_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.19 719832.78 1.19 490079.62 719832.69 1.19 490079.62 719832.69 11.26 490073.19 719832.78 11.26 490073.19 719832.78 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f32df644-d3d2-40d8-afdb-3ea0001ca8c7_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490079.62 719832.69 1.19 490079.64 719833.19 1.19 490079.64 719833.19 11.26 490079.62 719832.69 11.26 490079.62 719832.69 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f32df644-d3d2-40d8-afdb-3ea0001ca8c7_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490079.64 719833.19 1.19 490079.79 719840.38 1.19 490079.79 719840.38 11.26 490079.64 719833.19 11.26 490079.64 719833.19 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f32df644-d3d2-40d8-afdb-3ea0001ca8c7_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490079.79 719840.38 1.19 490079.8 719841.25 1.19 490079.8 719841.25 11.26 490079.79 719840.38 11.26 490079.79 719840.38 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f32df644-d3d2-40d8-afdb-3ea0001ca8c7_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490079.8 719841.25 1.19 490073.37 719841.33 1.19 490073.37 719841.33 11.26 490079.8 719841.25 11.26 490079.8 719841.25 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f32df644-d3d2-40d8-afdb-3ea0001ca8c7_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.37 719841.33 1.19 490073.19 719832.78 1.19 490073.19 719832.78 11.26 490073.37 719841.33 11.26 490073.37 719841.33 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f32df644-d3d2-40d8-afdb-3ea0001ca8c7_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.19 719832.78 11.26 490079.62 719832.69 11.26 490079.64 719833.19 11.26 490079.79 719840.38 11.26 490079.8 719841.25 11.26 490073.37 719841.33 11.26 490073.19 719832.78 11.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-34bae511-df85-48b6-8e45-adb0f6243a2a">
			<gen:stringAttribute name="buildingId">
				<gen:value>34bae511-df85-48b6-8e45-adb0f6243a2a</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.06</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34bae511-df85-48b6-8e45-adb0f6243a2a_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490066.77 719832.39 1.19 490066.96 719842.3 1.19 490073.36 719842.2 1.19 490073.37 719841.33 1.19 490073.19 719832.78 1.19 490073.18 719832.28 1.19 490066.77 719832.39 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34bae511-df85-48b6-8e45-adb0f6243a2a_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490066.77 719832.39 1.19 490073.18 719832.28 1.19 490073.18 719832.28 11.25 490066.77 719832.39 11.25 490066.77 719832.39 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34bae511-df85-48b6-8e45-adb0f6243a2a_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.18 719832.28 1.19 490073.19 719832.78 1.19 490073.19 719832.78 11.25 490073.18 719832.28 11.25 490073.18 719832.28 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34bae511-df85-48b6-8e45-adb0f6243a2a_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.19 719832.78 1.19 490073.37 719841.33 1.19 490073.37 719841.33 11.25 490073.19 719832.78 11.25 490073.19 719832.78 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34bae511-df85-48b6-8e45-adb0f6243a2a_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.37 719841.33 1.19 490073.36 719842.2 1.19 490073.36 719842.2 11.25 490073.37 719841.33 11.25 490073.37 719841.33 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34bae511-df85-48b6-8e45-adb0f6243a2a_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.36 719842.2 1.19 490066.96 719842.3 1.19 490066.96 719842.3 11.25 490073.36 719842.2 11.25 490073.36 719842.2 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34bae511-df85-48b6-8e45-adb0f6243a2a_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490066.96 719842.3 1.19 490066.77 719832.39 1.19 490066.77 719832.39 11.25 490066.96 719842.3 11.25 490066.96 719842.3 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34bae511-df85-48b6-8e45-adb0f6243a2a_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490066.77 719832.39 11.25 490073.18 719832.28 11.25 490073.19 719832.78 11.25 490073.37 719841.33 11.25 490073.36 719842.2 11.25 490066.96 719842.3 11.25 490066.77 719832.39 11.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-3c34e942-6bfd-4160-ac6a-2d3121bbdf78">
			<gen:stringAttribute name="buildingId">
				<gen:value>3c34e942-6bfd-4160-ac6a-2d3121bbdf78</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.34</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3c34e942-6bfd-4160-ac6a-2d3121bbdf78_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491596.17 719693.75 1.4 491597.68 719699.35 1.4 491603.28 719697.84 1.4 491601.77 719692.24 1.4 491596.17 719693.75 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3c34e942-6bfd-4160-ac6a-2d3121bbdf78_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491596.17 719693.75 1.4 491601.77 719692.24 1.4 491601.77 719692.24 6.74 491596.17 719693.75 6.74 491596.17 719693.75 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3c34e942-6bfd-4160-ac6a-2d3121bbdf78_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491601.77 719692.24 1.4 491603.28 719697.84 1.4 491603.28 719697.84 6.74 491601.77 719692.24 6.74 491601.77 719692.24 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3c34e942-6bfd-4160-ac6a-2d3121bbdf78_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491603.28 719697.84 1.4 491597.68 719699.35 1.4 491597.68 719699.35 6.74 491603.28 719697.84 6.74 491603.28 719697.84 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3c34e942-6bfd-4160-ac6a-2d3121bbdf78_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491597.68 719699.35 1.4 491596.17 719693.75 1.4 491596.17 719693.75 6.74 491597.68 719699.35 6.74 491597.68 719699.35 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3c34e942-6bfd-4160-ac6a-2d3121bbdf78_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491596.17 719693.75 6.74 491601.77 719692.24 6.74 491603.28 719697.84 6.74 491597.68 719699.35 6.74 491596.17 719693.75 6.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-15477e14-d58a-449b-95f8-d2cc04d56c64">
			<gen:stringAttribute name="buildingId">
				<gen:value>15477e14-d58a-449b-95f8-d2cc04d56c64</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-15477e14-d58a-449b-95f8-d2cc04d56c64_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491598.25 719701.47 1.44 491599.76 719707.06 1.44 491605.36 719705.55 1.44 491603.85 719699.96 1.44 491598.25 719701.47 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-15477e14-d58a-449b-95f8-d2cc04d56c64_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491598.25 719701.47 1.44 491603.85 719699.96 1.44 491603.85 719699.96 6.91 491598.25 719701.47 6.91 491598.25 719701.47 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-15477e14-d58a-449b-95f8-d2cc04d56c64_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491603.85 719699.96 1.44 491605.36 719705.55 1.44 491605.36 719705.55 6.91 491603.85 719699.96 6.91 491603.85 719699.96 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-15477e14-d58a-449b-95f8-d2cc04d56c64_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491605.36 719705.55 1.44 491599.76 719707.06 1.44 491599.76 719707.06 6.91 491605.36 719705.55 6.91 491605.36 719705.55 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-15477e14-d58a-449b-95f8-d2cc04d56c64_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491599.76 719707.06 1.44 491598.25 719701.47 1.44 491598.25 719701.47 6.91 491599.76 719707.06 6.91 491599.76 719707.06 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-15477e14-d58a-449b-95f8-d2cc04d56c64_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491598.25 719701.47 6.91 491603.85 719699.96 6.91 491605.36 719705.55 6.91 491599.76 719707.06 6.91 491598.25 719701.47 6.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c">
			<gen:stringAttribute name="buildingId">
				<gen:value>d216ac8a-5f58-468c-9899-0c66fbd1b09c</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.4</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491348.06 719697.66 1.35 491346.63 719688.92 1.35 491345.27 719689.14 1.35 491345.04 719687.74 1.35 491336.4 719689.13 1.35 491336.62 719690.36 1.35 491332.1 719690.99 1.35 491332.47 719693.4 1.35 491330.43 719693.71 1.35 491331.44 719700.26 1.35 491348.06 719697.66 1.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491348.06 719697.66 1.35 491331.44 719700.26 1.35 491331.44 719700.26 7.744999999999999 491348.06 719697.66 7.744999999999999 491348.06 719697.66 1.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491331.44 719700.26 1.35 491330.43 719693.71 1.35 491330.43 719693.71 7.744999999999999 491331.44 719700.26 7.744999999999999 491331.44 719700.26 1.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491330.43 719693.71 1.35 491332.47 719693.4 1.35 491332.47 719693.4 7.744999999999999 491330.43 719693.71 7.744999999999999 491330.43 719693.71 1.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491332.47 719693.4 1.35 491332.1 719690.99 1.35 491332.1 719690.99 7.744999999999999 491332.47 719693.4 7.744999999999999 491332.47 719693.4 1.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491332.1 719690.99 1.35 491336.62 719690.36 1.35 491336.62 719690.36 7.744999999999999 491332.1 719690.99 7.744999999999999 491332.1 719690.99 1.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491336.62 719690.36 1.35 491336.4 719689.13 1.35 491336.4 719689.13 7.744999999999999 491336.62 719690.36 7.744999999999999 491336.62 719690.36 1.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491336.4 719689.13 1.35 491345.04 719687.74 1.35 491345.04 719687.74 7.744999999999999 491336.4 719689.13 7.744999999999999 491336.4 719689.13 1.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491345.04 719687.74 1.35 491345.27 719689.14 1.35 491345.27 719689.14 7.744999999999999 491345.04 719687.74 7.744999999999999 491345.04 719687.74 1.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491345.27 719689.14 1.35 491346.63 719688.92 1.35 491346.63 719688.92 7.744999999999999 491345.27 719689.14 7.744999999999999 491345.27 719689.14 1.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491346.63 719688.92 1.35 491348.06 719697.66 1.35 491348.06 719697.66 7.744999999999999 491346.63 719688.92 7.744999999999999 491346.63 719688.92 1.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d216ac8a-5f58-468c-9899-0c66fbd1b09c_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491348.06 719697.66 7.744999999999999 491331.44 719700.26 7.744999999999999 491330.43 719693.71 7.744999999999999 491332.47 719693.4 7.744999999999999 491332.1 719690.99 7.744999999999999 491336.62 719690.36 7.744999999999999 491336.4 719689.13 7.744999999999999 491345.04 719687.74 7.744999999999999 491345.27 719689.14 7.744999999999999 491346.63 719688.92 7.744999999999999 491348.06 719697.66 7.744999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-da696132-a225-4bec-9cfc-366bb6c7ddb2">
			<gen:stringAttribute name="buildingId">
				<gen:value>da696132-a225-4bec-9cfc-366bb6c7ddb2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-da696132-a225-4bec-9cfc-366bb6c7ddb2_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491600.33 719709.18 1.46 491601.84 719714.78 1.46 491607.43 719713.27 1.46 491605.93 719707.67 1.46 491600.33 719709.18 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-da696132-a225-4bec-9cfc-366bb6c7ddb2_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491600.33 719709.18 1.46 491605.93 719707.67 1.46 491605.93 719707.67 6.890000000000001 491600.33 719709.18 6.890000000000001 491600.33 719709.18 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-da696132-a225-4bec-9cfc-366bb6c7ddb2_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491605.93 719707.67 1.46 491607.43 719713.27 1.46 491607.43 719713.27 6.890000000000001 491605.93 719707.67 6.890000000000001 491605.93 719707.67 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-da696132-a225-4bec-9cfc-366bb6c7ddb2_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491607.43 719713.27 1.46 491601.84 719714.78 1.46 491601.84 719714.78 6.890000000000001 491607.43 719713.27 6.890000000000001 491607.43 719713.27 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-da696132-a225-4bec-9cfc-366bb6c7ddb2_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491601.84 719714.78 1.46 491600.33 719709.18 1.46 491600.33 719709.18 6.890000000000001 491601.84 719714.78 6.890000000000001 491601.84 719714.78 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-da696132-a225-4bec-9cfc-366bb6c7ddb2_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491600.33 719709.18 6.890000000000001 491605.93 719707.67 6.890000000000001 491607.43 719713.27 6.890000000000001 491601.84 719714.78 6.890000000000001 491600.33 719709.18 6.890000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-561acd68-5ed1-4abb-adf1-f0adcd3f6e4c">
			<gen:stringAttribute name="buildingId">
				<gen:value>561acd68-5ed1-4abb-adf1-f0adcd3f6e4c</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.06</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-561acd68-5ed1-4abb-adf1-f0adcd3f6e4c_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490079.64 719833.19 1.19 490079.79 719840.38 1.19 490086.2 719840.29 1.19 490086.2 719839.41 1.19 490092.63 719839.32 1.19 490092.61 719838.46 1.19 490092.52 719833.52 1.19 490086.08 719833.61 1.19 490086.08 719833.09 1.19 490079.64 719833.19 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-561acd68-5ed1-4abb-adf1-f0adcd3f6e4c_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490079.64 719833.19 1.19 490086.08 719833.09 1.19 490086.08 719833.09 11.25 490079.64 719833.19 11.25 490079.64 719833.19 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-561acd68-5ed1-4abb-adf1-f0adcd3f6e4c_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490086.08 719833.09 1.19 490086.08 719833.61 1.19 490086.08 719833.61 11.25 490086.08 719833.09 11.25 490086.08 719833.09 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-561acd68-5ed1-4abb-adf1-f0adcd3f6e4c_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490086.08 719833.61 1.19 490092.52 719833.52 1.19 490092.52 719833.52 11.25 490086.08 719833.61 11.25 490086.08 719833.61 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-561acd68-5ed1-4abb-adf1-f0adcd3f6e4c_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490092.52 719833.52 1.19 490092.61 719838.46 1.19 490092.61 719838.46 11.25 490092.52 719833.52 11.25 490092.52 719833.52 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-561acd68-5ed1-4abb-adf1-f0adcd3f6e4c_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490092.61 719838.46 1.19 490092.63 719839.32 1.19 490092.63 719839.32 11.25 490092.61 719838.46 11.25 490092.61 719838.46 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-561acd68-5ed1-4abb-adf1-f0adcd3f6e4c_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490092.63 719839.32 1.19 490086.2 719839.41 1.19 490086.2 719839.41 11.25 490092.63 719839.32 11.25 490092.63 719839.32 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-561acd68-5ed1-4abb-adf1-f0adcd3f6e4c_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490086.2 719839.41 1.19 490086.2 719840.29 1.19 490086.2 719840.29 11.25 490086.2 719839.41 11.25 490086.2 719839.41 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-561acd68-5ed1-4abb-adf1-f0adcd3f6e4c_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490086.2 719840.29 1.19 490079.79 719840.38 1.19 490079.79 719840.38 11.25 490086.2 719840.29 11.25 490086.2 719840.29 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-561acd68-5ed1-4abb-adf1-f0adcd3f6e4c_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490079.79 719840.38 1.19 490079.64 719833.19 1.19 490079.64 719833.19 11.25 490079.79 719840.38 11.25 490079.79 719840.38 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-561acd68-5ed1-4abb-adf1-f0adcd3f6e4c_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490079.64 719833.19 11.25 490086.08 719833.09 11.25 490086.08 719833.61 11.25 490092.52 719833.52 11.25 490092.61 719838.46 11.25 490092.63 719839.32 11.25 490086.2 719839.41 11.25 490086.2 719840.29 11.25 490079.79 719840.38 11.25 490079.64 719833.19 11.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-660c75f2-c609-4f6a-a8ef-c35535667c14">
			<gen:stringAttribute name="buildingId">
				<gen:value>660c75f2-c609-4f6a-a8ef-c35535667c14</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.49</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-660c75f2-c609-4f6a-a8ef-c35535667c14_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491359.64 719717.56 1.32 491358.42 719709.55 1.32 491343.49 719711.61 1.32 491344.71 719719.66 1.32 491359.64 719717.56 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-660c75f2-c609-4f6a-a8ef-c35535667c14_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491359.64 719717.56 1.32 491344.71 719719.66 1.32 491344.71 719719.66 6.8100000000000005 491359.64 719717.56 6.8100000000000005 491359.64 719717.56 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-660c75f2-c609-4f6a-a8ef-c35535667c14_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491344.71 719719.66 1.32 491343.49 719711.61 1.32 491343.49 719711.61 6.8100000000000005 491344.71 719719.66 6.8100000000000005 491344.71 719719.66 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-660c75f2-c609-4f6a-a8ef-c35535667c14_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491343.49 719711.61 1.32 491358.42 719709.55 1.32 491358.42 719709.55 6.8100000000000005 491343.49 719711.61 6.8100000000000005 491343.49 719711.61 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-660c75f2-c609-4f6a-a8ef-c35535667c14_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491358.42 719709.55 1.32 491359.64 719717.56 1.32 491359.64 719717.56 6.8100000000000005 491358.42 719709.55 6.8100000000000005 491358.42 719709.55 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-660c75f2-c609-4f6a-a8ef-c35535667c14_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491359.64 719717.56 6.8100000000000005 491344.71 719719.66 6.8100000000000005 491343.49 719711.61 6.8100000000000005 491358.42 719709.55 6.8100000000000005 491359.64 719717.56 6.8100000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-4f08e7f8-a1c5-4cf5-8b5c-90dfd4bb9134">
			<gen:stringAttribute name="buildingId">
				<gen:value>4f08e7f8-a1c5-4cf5-8b5c-90dfd4bb9134</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.92</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4f08e7f8-a1c5-4cf5-8b5c-90dfd4bb9134_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491387.58 719726.72 1.66 491388.16 719730.15 1.66 491395.94 719728.96 1.66 491394.88 719722.37 1.66 491393.57 719722.57 1.66 491392.41 719715.23 1.66 491385.13 719716.38 1.66 491386.77 719726.82 1.66 491387.58 719726.72 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4f08e7f8-a1c5-4cf5-8b5c-90dfd4bb9134_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491387.58 719726.72 1.66 491386.77 719726.82 1.66 491386.77 719726.82 8.58 491387.58 719726.72 8.58 491387.58 719726.72 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4f08e7f8-a1c5-4cf5-8b5c-90dfd4bb9134_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491386.77 719726.82 1.66 491385.13 719716.38 1.66 491385.13 719716.38 8.58 491386.77 719726.82 8.58 491386.77 719726.82 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4f08e7f8-a1c5-4cf5-8b5c-90dfd4bb9134_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491385.13 719716.38 1.66 491392.41 719715.23 1.66 491392.41 719715.23 8.58 491385.13 719716.38 8.58 491385.13 719716.38 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4f08e7f8-a1c5-4cf5-8b5c-90dfd4bb9134_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491392.41 719715.23 1.66 491393.57 719722.57 1.66 491393.57 719722.57 8.58 491392.41 719715.23 8.58 491392.41 719715.23 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4f08e7f8-a1c5-4cf5-8b5c-90dfd4bb9134_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491393.57 719722.57 1.66 491394.88 719722.37 1.66 491394.88 719722.37 8.58 491393.57 719722.57 8.58 491393.57 719722.57 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4f08e7f8-a1c5-4cf5-8b5c-90dfd4bb9134_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491394.88 719722.37 1.66 491395.94 719728.96 1.66 491395.94 719728.96 8.58 491394.88 719722.37 8.58 491394.88 719722.37 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4f08e7f8-a1c5-4cf5-8b5c-90dfd4bb9134_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491395.94 719728.96 1.66 491388.16 719730.15 1.66 491388.16 719730.15 8.58 491395.94 719728.96 8.58 491395.94 719728.96 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4f08e7f8-a1c5-4cf5-8b5c-90dfd4bb9134_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491388.16 719730.15 1.66 491387.58 719726.72 1.66 491387.58 719726.72 8.58 491388.16 719730.15 8.58 491388.16 719730.15 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4f08e7f8-a1c5-4cf5-8b5c-90dfd4bb9134_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491387.58 719726.72 8.58 491386.77 719726.82 8.58 491385.13 719716.38 8.58 491392.41 719715.23 8.58 491393.57 719722.57 8.58 491394.88 719722.37 8.58 491395.94 719728.96 8.58 491388.16 719730.15 8.58 491387.58 719726.72 8.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-fa18d646-bef2-4018-8847-5ad23107cb7d">
			<gen:stringAttribute name="buildingId">
				<gen:value>fa18d646-bef2-4018-8847-5ad23107cb7d</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.25</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fa18d646-bef2-4018-8847-5ad23107cb7d_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490842.92 719659.76 0.64 490843.47 719671.84 0.64 490862.41 719670.98 0.64 490861.86 719658.89 0.64 490842.92 719659.76 0.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fa18d646-bef2-4018-8847-5ad23107cb7d_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490842.92 719659.76 0.64 490861.86 719658.89 0.64 490861.86 719658.89 6.890000000000001 490842.92 719659.76 6.890000000000001 490842.92 719659.76 0.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fa18d646-bef2-4018-8847-5ad23107cb7d_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490861.86 719658.89 0.64 490862.41 719670.98 0.64 490862.41 719670.98 6.890000000000001 490861.86 719658.89 6.890000000000001 490861.86 719658.89 0.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fa18d646-bef2-4018-8847-5ad23107cb7d_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490862.41 719670.98 0.64 490843.47 719671.84 0.64 490843.47 719671.84 6.890000000000001 490862.41 719670.98 6.890000000000001 490862.41 719670.98 0.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fa18d646-bef2-4018-8847-5ad23107cb7d_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490843.47 719671.84 0.64 490842.92 719659.76 0.64 490842.92 719659.76 6.890000000000001 490843.47 719671.84 6.890000000000001 490843.47 719671.84 0.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fa18d646-bef2-4018-8847-5ad23107cb7d_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490842.92 719659.76 6.890000000000001 490861.86 719658.89 6.890000000000001 490862.41 719670.98 6.890000000000001 490843.47 719671.84 6.890000000000001 490842.92 719659.76 6.890000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-60f78cf2-4b6b-42bd-9a01-6e890bf3b0cc">
			<gen:stringAttribute name="buildingId">
				<gen:value>60f78cf2-4b6b-42bd-9a01-6e890bf3b0cc</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.76</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-60f78cf2-4b6b-42bd-9a01-6e890bf3b0cc_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490632.63 719674.35 0.69 490633.41 719687.24 0.69 490650.73 719686.2 0.69 490649.96 719673.31 0.69 490632.63 719674.35 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-60f78cf2-4b6b-42bd-9a01-6e890bf3b0cc_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490632.63 719674.35 0.69 490649.96 719673.31 0.69 490649.96 719673.31 5.449999999999999 490632.63 719674.35 5.449999999999999 490632.63 719674.35 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-60f78cf2-4b6b-42bd-9a01-6e890bf3b0cc_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490649.96 719673.31 0.69 490650.73 719686.2 0.69 490650.73 719686.2 5.449999999999999 490649.96 719673.31 5.449999999999999 490649.96 719673.31 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-60f78cf2-4b6b-42bd-9a01-6e890bf3b0cc_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490650.73 719686.2 0.69 490633.41 719687.24 0.69 490633.41 719687.24 5.449999999999999 490650.73 719686.2 5.449999999999999 490650.73 719686.2 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-60f78cf2-4b6b-42bd-9a01-6e890bf3b0cc_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490633.41 719687.24 0.69 490632.63 719674.35 0.69 490632.63 719674.35 5.449999999999999 490633.41 719687.24 5.449999999999999 490633.41 719687.24 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-60f78cf2-4b6b-42bd-9a01-6e890bf3b0cc_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490632.63 719674.35 5.449999999999999 490649.96 719673.31 5.449999999999999 490650.73 719686.2 5.449999999999999 490633.41 719687.24 5.449999999999999 490632.63 719674.35 5.449999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14">
			<gen:stringAttribute name="buildingId">
				<gen:value>4105ec17-2d8b-4448-9060-e23fdf84ed14</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490004.29 719845.55 1.15 490010.27 719845.49 1.15 490010.29 719847.12 1.15 490016.94 719846.99 1.15 490016.93 719846.49 1.15 490022.92 719846.36 1.15 490022.91 719845.87 1.15 490028.31 719845.83 1.15 490028.31 719846.18 1.15 490028.88 719846.18 1.15 490028.67 719829.47 1.15 490028.08 719829.48 1.15 490028.08 719829.78 1.15 490022.71 719829.87 1.15 490022.69 719829.34 1.15 490016.7 719829.49 1.15 490016.7 719828.96 1.15 490010.12 719829.04 1.15 490010.16 719831.54 1.15 490004.14 719831.61 1.15 490004.2 719835.92 1.15 490002.65 719835.94 1.15 490002.7 719840.85 1.15 490004.21 719840.82 1.15 490004.29 719845.55 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490004.29 719845.55 1.15 490004.21 719840.82 1.15 490004.21 719840.82 11.58 490004.29 719845.55 11.58 490004.29 719845.55 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490004.21 719840.82 1.15 490002.7 719840.85 1.15 490002.7 719840.85 11.58 490004.21 719840.82 11.58 490004.21 719840.82 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490002.7 719840.85 1.15 490002.65 719835.94 1.15 490002.65 719835.94 11.58 490002.7 719840.85 11.58 490002.7 719840.85 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490002.65 719835.94 1.15 490004.2 719835.92 1.15 490004.2 719835.92 11.58 490002.65 719835.94 11.58 490002.65 719835.94 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490004.2 719835.92 1.15 490004.14 719831.61 1.15 490004.14 719831.61 11.58 490004.2 719835.92 11.58 490004.2 719835.92 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490004.14 719831.61 1.15 490010.16 719831.54 1.15 490010.16 719831.54 11.58 490004.14 719831.61 11.58 490004.14 719831.61 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490010.16 719831.54 1.15 490010.12 719829.04 1.15 490010.12 719829.04 11.58 490010.16 719831.54 11.58 490010.16 719831.54 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490010.12 719829.04 1.15 490016.7 719828.96 1.15 490016.7 719828.96 11.58 490010.12 719829.04 11.58 490010.12 719829.04 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490016.7 719828.96 1.15 490016.7 719829.49 1.15 490016.7 719829.49 11.58 490016.7 719828.96 11.58 490016.7 719828.96 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490016.7 719829.49 1.15 490022.69 719829.34 1.15 490022.69 719829.34 11.58 490016.7 719829.49 11.58 490016.7 719829.49 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490022.69 719829.34 1.15 490022.71 719829.87 1.15 490022.71 719829.87 11.58 490022.69 719829.34 11.58 490022.69 719829.34 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490022.71 719829.87 1.15 490028.08 719829.78 1.15 490028.08 719829.78 11.58 490022.71 719829.87 11.58 490022.71 719829.87 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490028.08 719829.78 1.15 490028.08 719829.48 1.15 490028.08 719829.48 11.58 490028.08 719829.78 11.58 490028.08 719829.78 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490028.08 719829.48 1.15 490028.67 719829.47 1.15 490028.67 719829.47 11.58 490028.08 719829.48 11.58 490028.08 719829.48 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490028.67 719829.47 1.15 490028.88 719846.18 1.15 490028.88 719846.18 11.58 490028.67 719829.47 11.58 490028.67 719829.47 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490028.88 719846.18 1.15 490028.31 719846.18 1.15 490028.31 719846.18 11.58 490028.88 719846.18 11.58 490028.88 719846.18 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490028.31 719846.18 1.15 490028.31 719845.83 1.15 490028.31 719845.83 11.58 490028.31 719846.18 11.58 490028.31 719846.18 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490028.31 719845.83 1.15 490022.91 719845.87 1.15 490022.91 719845.87 11.58 490028.31 719845.83 11.58 490028.31 719845.83 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490022.91 719845.87 1.15 490022.92 719846.36 1.15 490022.92 719846.36 11.58 490022.91 719845.87 11.58 490022.91 719845.87 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490022.92 719846.36 1.15 490016.93 719846.49 1.15 490016.93 719846.49 11.58 490022.92 719846.36 11.58 490022.92 719846.36 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490016.93 719846.49 1.15 490016.94 719846.99 1.15 490016.94 719846.99 11.58 490016.93 719846.49 11.58 490016.93 719846.49 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490016.94 719846.99 1.15 490010.29 719847.12 1.15 490010.29 719847.12 11.58 490016.94 719846.99 11.58 490016.94 719846.99 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490010.29 719847.12 1.15 490010.27 719845.49 1.15 490010.27 719845.49 11.58 490010.29 719847.12 11.58 490010.29 719847.12 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490010.27 719845.49 1.15 490004.29 719845.55 1.15 490004.29 719845.55 11.58 490010.27 719845.49 11.58 490010.27 719845.49 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4105ec17-2d8b-4448-9060-e23fdf84ed14_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490004.29 719845.55 11.58 490004.21 719840.82 11.58 490002.7 719840.85 11.58 490002.65 719835.94 11.58 490004.2 719835.92 11.58 490004.14 719831.61 11.58 490010.16 719831.54 11.58 490010.12 719829.04 11.58 490016.7 719828.96 11.58 490016.7 719829.49 11.58 490022.69 719829.34 11.58 490022.71 719829.87 11.58 490028.08 719829.78 11.58 490028.08 719829.48 11.58 490028.67 719829.47 11.58 490028.88 719846.18 11.58 490028.31 719846.18 11.58 490028.31 719845.83 11.58 490022.91 719845.87 11.58 490022.92 719846.36 11.58 490016.93 719846.49 11.58 490016.94 719846.99 11.58 490010.29 719847.12 11.58 490010.27 719845.49 11.58 490004.29 719845.55 11.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-fba9ba6e-4e73-4c06-b6f4-d51f6b5324d9">
			<gen:stringAttribute name="buildingId">
				<gen:value>fba9ba6e-4e73-4c06-b6f4-d51f6b5324d9</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fba9ba6e-4e73-4c06-b6f4-d51f6b5324d9_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490669.07 719753.27 1.16 490669.27 719761.66 1.16 490679.59 719761.42 1.16 490679.4 719753.03 1.16 490669.07 719753.27 1.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fba9ba6e-4e73-4c06-b6f4-d51f6b5324d9_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490669.07 719753.27 1.16 490679.4 719753.03 1.16 490679.4 719753.03 6.965 490669.07 719753.27 6.965 490669.07 719753.27 1.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fba9ba6e-4e73-4c06-b6f4-d51f6b5324d9_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490679.4 719753.03 1.16 490679.59 719761.42 1.16 490679.59 719761.42 6.965 490679.4 719753.03 6.965 490679.4 719753.03 1.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fba9ba6e-4e73-4c06-b6f4-d51f6b5324d9_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490679.59 719761.42 1.16 490669.27 719761.66 1.16 490669.27 719761.66 6.965 490679.59 719761.42 6.965 490679.59 719761.42 1.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fba9ba6e-4e73-4c06-b6f4-d51f6b5324d9_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490669.27 719761.66 1.16 490669.07 719753.27 1.16 490669.07 719753.27 6.965 490669.27 719761.66 6.965 490669.27 719761.66 1.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fba9ba6e-4e73-4c06-b6f4-d51f6b5324d9_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490669.07 719753.27 6.965 490679.4 719753.03 6.965 490679.59 719761.42 6.965 490669.27 719761.66 6.965 490669.07 719753.27 6.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6EB7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6EB7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.52</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489956.35 719828.51 1.44 489957.18 719828.54 1.44 489957.21 719828.3 1.44 489962.23 719828.58 1.44 489962.37 719826.11 1.44 489963.97 719826.21 1.44 489964.33 719820.08 1.44 489956.86 719819.65 1.44 489956.35 719828.51 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489956.35 719828.51 1.44 489956.86 719819.65 1.44 489956.86 719819.65 7.959999999999999 489956.35 719828.51 7.959999999999999 489956.35 719828.51 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489956.86 719819.65 1.44 489964.33 719820.08 1.44 489964.33 719820.08 7.959999999999999 489956.86 719819.65 7.959999999999999 489956.86 719819.65 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489964.33 719820.08 1.44 489963.97 719826.21 1.44 489963.97 719826.21 7.959999999999999 489964.33 719820.08 7.959999999999999 489964.33 719820.08 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489963.97 719826.21 1.44 489962.37 719826.11 1.44 489962.37 719826.11 7.959999999999999 489963.97 719826.21 7.959999999999999 489963.97 719826.21 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489962.37 719826.11 1.44 489962.23 719828.58 1.44 489962.23 719828.58 7.959999999999999 489962.37 719826.11 7.959999999999999 489962.37 719826.11 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489962.23 719828.58 1.44 489957.21 719828.3 1.44 489957.21 719828.3 7.959999999999999 489962.23 719828.58 7.959999999999999 489962.23 719828.58 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489957.21 719828.3 1.44 489957.18 719828.54 1.44 489957.18 719828.54 7.959999999999999 489957.21 719828.3 7.959999999999999 489957.21 719828.3 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489957.18 719828.54 1.44 489956.35 719828.51 1.44 489956.35 719828.51 7.959999999999999 489957.18 719828.54 7.959999999999999 489957.18 719828.54 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6EB7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489956.35 719828.51 7.959999999999999 489956.86 719819.65 7.959999999999999 489964.33 719820.08 7.959999999999999 489963.97 719826.21 7.959999999999999 489962.37 719826.11 7.959999999999999 489962.23 719828.58 7.959999999999999 489957.21 719828.3 7.959999999999999 489957.18 719828.54 7.959999999999999 489956.35 719828.51 7.959999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD34-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD34-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.17</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD34-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490878.34 719744.29 1.21 490878.62 719751.98 1.21 490884.78 719751.71 1.21 490884.5 719744.09 1.21 490878.34 719744.29 1.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD34-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490878.34 719744.29 1.21 490884.5 719744.09 1.21 490884.5 719744.09 6.38 490878.34 719744.29 6.38 490878.34 719744.29 1.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD34-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490884.5 719744.09 1.21 490884.78 719751.71 1.21 490884.78 719751.71 6.38 490884.5 719744.09 6.38 490884.5 719744.09 1.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD34-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490884.78 719751.71 1.21 490878.62 719751.98 1.21 490878.62 719751.98 6.38 490884.78 719751.71 6.38 490884.78 719751.71 1.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD34-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490878.62 719751.98 1.21 490878.34 719744.29 1.21 490878.34 719744.29 6.38 490878.62 719751.98 6.38 490878.62 719751.98 1.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD34-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490878.34 719744.29 6.38 490884.5 719744.09 6.38 490884.78 719751.71 6.38 490878.62 719751.98 6.38 490878.34 719744.29 6.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E071-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E071-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.17</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E071-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490935.36 719771.36 1.42 490941.99 719771.17 1.42 490941.8 719764.21 1.42 490935.16 719764.39 1.42 490935.36 719771.36 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E071-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490935.36 719771.36 1.42 490935.16 719764.39 1.42 490935.16 719764.39 4.59 490935.36 719771.36 4.59 490935.36 719771.36 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E071-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490935.16 719764.39 1.42 490941.8 719764.21 1.42 490941.8 719764.21 4.59 490935.16 719764.39 4.59 490935.16 719764.39 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E071-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490941.8 719764.21 1.42 490941.99 719771.17 1.42 490941.99 719771.17 4.59 490941.8 719764.21 4.59 490941.8 719764.21 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E071-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490941.99 719771.17 1.42 490935.36 719771.36 1.42 490935.36 719771.36 4.59 490941.99 719771.17 4.59 490941.99 719771.17 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E071-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490935.36 719771.36 4.59 490935.16 719764.39 4.59 490941.8 719764.21 4.59 490941.99 719771.17 4.59 490935.36 719771.36 4.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E070-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E070-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.22</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E070-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490929.49 719785.23 1.41 490936.37 719784.99 1.41 490936.15 719778.2 1.41 490929.26 719778.44 1.41 490929.49 719785.23 1.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E070-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490929.49 719785.23 1.41 490929.26 719778.44 1.41 490929.26 719778.44 4.63 490929.49 719785.23 4.63 490929.49 719785.23 1.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E070-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490929.26 719778.44 1.41 490936.15 719778.2 1.41 490936.15 719778.2 4.63 490929.26 719778.44 4.63 490929.26 719778.44 1.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E070-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490936.15 719778.2 1.41 490936.37 719784.99 1.41 490936.37 719784.99 4.63 490936.15 719778.2 4.63 490936.15 719778.2 1.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E070-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490936.37 719784.99 1.41 490929.49 719785.23 1.41 490929.49 719785.23 4.63 490936.37 719784.99 4.63 490936.37 719784.99 1.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E070-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490929.49 719785.23 4.63 490929.26 719778.44 4.63 490936.15 719778.2 4.63 490936.37 719784.99 4.63 490929.49 719785.23 4.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E06F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E06F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.61</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490925.83 719801.31 1.51 490932.46 719801.24 1.51 490932.37 719794.02 1.51 490925.74 719794.11 1.51 490925.83 719801.31 1.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490925.83 719801.31 1.51 490925.74 719794.11 1.51 490925.74 719794.11 5.115 490925.83 719801.31 5.115 490925.83 719801.31 1.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490925.74 719794.11 1.51 490932.37 719794.02 1.51 490932.37 719794.02 5.115 490925.74 719794.11 5.115 490925.74 719794.11 1.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490932.37 719794.02 1.51 490932.46 719801.24 1.51 490932.46 719801.24 5.115 490932.37 719794.02 5.115 490932.37 719794.02 1.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490932.46 719801.24 1.51 490925.83 719801.31 1.51 490925.83 719801.31 5.115 490932.46 719801.24 5.115 490932.46 719801.24 1.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490925.83 719801.31 5.115 490925.74 719794.11 5.115 490932.37 719794.02 5.115 490932.46 719801.24 5.115 490925.83 719801.31 5.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E06E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E06E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.03</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490925.82 719770.62 1.4 490932.67 719770.58 1.4 490932.63 719763.47 1.4 490925.77 719763.52 1.4 490925.82 719770.62 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490925.82 719770.62 1.4 490925.77 719763.52 1.4 490925.77 719763.52 4.43 490925.82 719770.62 4.43 490925.82 719770.62 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490925.77 719763.52 1.4 490932.63 719763.47 1.4 490932.63 719763.47 4.43 490925.77 719763.52 4.43 490925.77 719763.52 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490932.63 719763.47 1.4 490932.67 719770.58 1.4 490932.67 719770.58 4.43 490932.63 719763.47 4.43 490932.63 719763.47 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490932.67 719770.58 1.4 490925.82 719770.62 1.4 490925.82 719770.62 4.43 490932.67 719770.58 4.43 490932.67 719770.58 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490925.82 719770.62 4.43 490925.77 719763.52 4.43 490932.63 719763.47 4.43 490932.67 719770.58 4.43 490925.82 719770.62 4.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E06A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E06A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490923.87 719756.88 1.3 490930.77 719756.69 1.3 490930.49 719748.7 1.3 490923.55 719748.94 1.3 490923.87 719756.88 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490923.87 719756.88 1.3 490923.55 719748.94 1.3 490923.55 719748.94 4.925 490923.87 719756.88 4.925 490923.87 719756.88 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490923.55 719748.94 1.3 490930.49 719748.7 1.3 490930.49 719748.7 4.925 490923.55 719748.94 4.925 490923.55 719748.94 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490930.49 719748.7 1.3 490930.77 719756.69 1.3 490930.77 719756.69 4.925 490930.49 719748.7 4.925 490930.49 719748.7 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490930.77 719756.69 1.3 490923.87 719756.88 1.3 490923.87 719756.88 4.925 490930.77 719756.69 4.925 490930.77 719756.69 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E06A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490923.87 719756.88 4.925 490923.55 719748.94 4.925 490930.49 719748.7 4.925 490930.77 719756.69 4.925 490923.87 719756.88 4.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E069-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E069-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.31</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E069-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490931.75 719756.05 1.32 490938.34 719755.91 1.32 490938.18 719748.76 1.32 490931.59 719748.91 1.32 490931.75 719756.05 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E069-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490931.75 719756.05 1.32 490931.59 719748.91 1.32 490931.59 719748.91 4.625 490931.75 719756.05 4.625 490931.75 719756.05 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E069-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490931.59 719748.91 1.32 490938.18 719748.76 1.32 490938.18 719748.76 4.625 490931.59 719748.91 4.625 490931.59 719748.91 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E069-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490938.18 719748.76 1.32 490938.34 719755.91 1.32 490938.34 719755.91 4.625 490938.18 719748.76 4.625 490938.18 719748.76 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E069-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490938.34 719755.91 1.32 490931.75 719756.05 1.32 490931.75 719756.05 4.625 490938.34 719755.91 4.625 490938.34 719755.91 1.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E069-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490931.75 719756.05 4.625 490931.59 719748.91 4.625 490938.18 719748.76 4.625 490938.34 719755.91 4.625 490931.75 719756.05 4.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D75E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D75E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.73</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491784.33 720057.24 6.21 491785.7 720049.49 6.21 491776.29 720047.82 6.21 491774.91 720055.58 6.21 491784.33 720057.24 6.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491784.33 720057.24 6.21 491774.91 720055.58 6.21 491774.91 720055.58 9.94 491784.33 720057.24 9.94 491784.33 720057.24 6.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491774.91 720055.58 6.21 491776.29 720047.82 6.21 491776.29 720047.82 9.94 491774.91 720055.58 9.94 491774.91 720055.58 6.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491776.29 720047.82 6.21 491785.7 720049.49 6.21 491785.7 720049.49 9.94 491776.29 720047.82 9.94 491776.29 720047.82 6.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491785.7 720049.49 6.21 491784.33 720057.24 6.21 491784.33 720057.24 9.94 491785.7 720049.49 9.94 491785.7 720049.49 6.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491784.33 720057.24 9.94 491774.91 720055.58 9.94 491776.29 720047.82 9.94 491785.7 720049.49 9.94 491784.33 720057.24 9.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E29D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E29D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.69</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491602.9 719731.53 1.58 491603.86 719736.74 1.58 491610.82 719735.46 1.58 491609.86 719730.25 1.58 491602.9 719731.53 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491602.9 719731.53 1.58 491609.86 719730.25 1.58 491609.86 719730.25 5.2700000000000005 491602.9 719731.53 5.2700000000000005 491602.9 719731.53 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491609.86 719730.25 1.58 491610.82 719735.46 1.58 491610.82 719735.46 5.2700000000000005 491609.86 719730.25 5.2700000000000005 491609.86 719730.25 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491610.82 719735.46 1.58 491603.86 719736.74 1.58 491603.86 719736.74 5.2700000000000005 491610.82 719735.46 5.2700000000000005 491610.82 719735.46 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491603.86 719736.74 1.58 491602.9 719731.53 1.58 491602.9 719731.53 5.2700000000000005 491603.86 719736.74 5.2700000000000005 491603.86 719736.74 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491602.9 719731.53 5.2700000000000005 491609.86 719730.25 5.2700000000000005 491610.82 719735.46 5.2700000000000005 491603.86 719736.74 5.2700000000000005 491602.9 719731.53 5.2700000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E29C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E29C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.73</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491613.62 719729.27 1.54 491614.58 719734.69 1.54 491621.71 719733.44 1.54 491620.75 719728.02 1.54 491613.62 719729.27 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491613.62 719729.27 1.54 491620.75 719728.02 1.54 491620.75 719728.02 5.2700000000000005 491613.62 719729.27 5.2700000000000005 491613.62 719729.27 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491620.75 719728.02 1.54 491621.71 719733.44 1.54 491621.71 719733.44 5.2700000000000005 491620.75 719728.02 5.2700000000000005 491620.75 719728.02 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491621.71 719733.44 1.54 491614.58 719734.69 1.54 491614.58 719734.69 5.2700000000000005 491621.71 719733.44 5.2700000000000005 491621.71 719733.44 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491614.58 719734.69 1.54 491613.62 719729.27 1.54 491613.62 719729.27 5.2700000000000005 491614.58 719734.69 5.2700000000000005 491614.58 719734.69 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491613.62 719729.27 5.2700000000000005 491620.75 719728.02 5.2700000000000005 491621.71 719733.44 5.2700000000000005 491614.58 719734.69 5.2700000000000005 491613.62 719729.27 5.2700000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E29B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E29B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.73</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491592.55 719733.7 1.56 491593.72 719738.76 1.56 491600.48 719737.41 1.56 491599.31 719732.35 1.56 491592.55 719733.7 1.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491592.55 719733.7 1.56 491599.31 719732.35 1.56 491599.31 719732.35 5.29 491592.55 719733.7 5.29 491592.55 719733.7 1.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491599.31 719732.35 1.56 491600.48 719737.41 1.56 491600.48 719737.41 5.29 491599.31 719732.35 5.29 491599.31 719732.35 1.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491600.48 719737.41 1.56 491593.72 719738.76 1.56 491593.72 719738.76 5.29 491600.48 719737.41 5.29 491600.48 719737.41 1.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491593.72 719738.76 1.56 491592.55 719733.7 1.56 491592.55 719733.7 5.29 491593.72 719738.76 5.29 491593.72 719738.76 1.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E29B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491592.55 719733.7 5.29 491599.31 719732.35 5.29 491600.48 719737.41 5.29 491593.72 719738.76 5.29 491592.55 719733.7 5.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E299-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E299-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E299-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491609.3 720141.93 4.94 491609.66 720137 4.94 491599.33 720136.25 4.94 491598.96 720141.34 4.94 491601.45 720141.48 4.94 491606.61 720141.74 4.94 491609.3 720141.93 4.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E299-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491609.3 720141.93 4.94 491606.61 720141.74 4.94 491606.61 720141.74 8.73 491609.3 720141.93 8.73 491609.3 720141.93 4.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E299-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491606.61 720141.74 4.94 491601.45 720141.48 4.94 491601.45 720141.48 8.73 491606.61 720141.74 8.73 491606.61 720141.74 4.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E299-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491601.45 720141.48 4.94 491598.96 720141.34 4.94 491598.96 720141.34 8.73 491601.45 720141.48 8.73 491601.45 720141.48 4.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E299-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491598.96 720141.34 4.94 491599.33 720136.25 4.94 491599.33 720136.25 8.73 491598.96 720141.34 8.73 491598.96 720141.34 4.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E299-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491599.33 720136.25 4.94 491609.66 720137 4.94 491609.66 720137 8.73 491599.33 720136.25 8.73 491599.33 720136.25 4.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E299-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491609.66 720137 4.94 491609.3 720141.93 4.94 491609.3 720141.93 8.73 491609.66 720137 8.73 491609.66 720137 4.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E299-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491609.3 720141.93 8.73 491606.61 720141.74 8.73 491601.45 720141.48 8.73 491598.96 720141.34 8.73 491599.33 720136.25 8.73 491609.66 720137 8.73 491609.3 720141.93 8.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E298-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E298-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.67</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E298-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491769.09 720064.4 6.05 491770.65 720057.19 6.05 491763.29 720055.6 6.05 491761.73 720062.81 6.05 491769.09 720064.4 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E298-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491769.09 720064.4 6.05 491761.73 720062.81 6.05 491761.73 720062.81 9.72 491769.09 720064.4 9.72 491769.09 720064.4 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E298-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491761.73 720062.81 6.05 491763.29 720055.6 6.05 491763.29 720055.6 9.72 491761.73 720062.81 9.72 491761.73 720062.81 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E298-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491763.29 720055.6 6.05 491770.65 720057.19 6.05 491770.65 720057.19 9.72 491763.29 720055.6 9.72 491763.29 720055.6 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E298-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491770.65 720057.19 6.05 491769.09 720064.4 6.05 491769.09 720064.4 9.72 491770.65 720057.19 9.72 491770.65 720057.19 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E298-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491769.09 720064.4 9.72 491761.73 720062.81 9.72 491763.29 720055.6 9.72 491770.65 720057.19 9.72 491769.09 720064.4 9.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D75D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D75D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.62</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491760.58 720076.52 6.03 491762.22 720069.53 6.03 491755.38 720067.93 6.03 491753.73 720074.91 6.03 491760.58 720076.52 6.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491760.58 720076.52 6.03 491753.73 720074.91 6.03 491753.73 720074.91 9.65 491760.58 720076.52 9.65 491760.58 720076.52 6.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491753.73 720074.91 6.03 491755.38 720067.93 6.03 491755.38 720067.93 9.65 491753.73 720074.91 9.65 491753.73 720074.91 6.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491755.38 720067.93 6.03 491762.22 720069.53 6.03 491762.22 720069.53 9.65 491755.38 720067.93 9.65 491755.38 720067.93 6.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491762.22 720069.53 6.03 491760.58 720076.52 6.03 491760.58 720076.52 9.65 491762.22 720069.53 9.65 491762.22 720069.53 6.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D75D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491760.58 720076.52 9.65 491753.73 720074.91 9.65 491755.38 720067.93 9.65 491762.22 720069.53 9.65 491760.58 720076.52 9.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E1E1-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E1E1-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1E1-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491180.68 719658.4 1.2 491200.25 719656.65 1.2 491199.78 719651.42 1.2 491180.22 719653.17 1.2 491180.68 719658.4 1.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1E1-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491180.68 719658.4 1.2 491180.22 719653.17 1.2 491180.22 719653.17 7.665 491180.68 719658.4 7.665 491180.68 719658.4 1.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1E1-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491180.22 719653.17 1.2 491199.78 719651.42 1.2 491199.78 719651.42 7.665 491180.22 719653.17 7.665 491180.22 719653.17 1.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1E1-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491199.78 719651.42 1.2 491200.25 719656.65 1.2 491200.25 719656.65 7.665 491199.78 719651.42 7.665 491199.78 719651.42 1.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1E1-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491200.25 719656.65 1.2 491180.68 719658.4 1.2 491180.68 719658.4 7.665 491200.25 719656.65 7.665 491200.25 719656.65 1.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1E1-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491180.68 719658.4 7.665 491180.22 719653.17 7.665 491199.78 719651.42 7.665 491200.25 719656.65 7.665 491180.68 719658.4 7.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E1DD-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E1DD-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.14</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1DD-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491200.68 719647.73 1.38 491206.01 719647.31 1.38 491205.65 719642.59 1.38 491200.31 719643 1.38 491200.68 719647.73 1.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1DD-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491200.68 719647.73 1.38 491200.31 719643 1.38 491200.31 719643 7.5200000000000005 491200.68 719647.73 7.5200000000000005 491200.68 719647.73 1.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1DD-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491200.31 719643 1.38 491205.65 719642.59 1.38 491205.65 719642.59 7.5200000000000005 491200.31 719643 7.5200000000000005 491200.31 719643 1.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1DD-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491205.65 719642.59 1.38 491206.01 719647.31 1.38 491206.01 719647.31 7.5200000000000005 491205.65 719642.59 7.5200000000000005 491205.65 719642.59 1.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1DD-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491206.01 719647.31 1.38 491200.68 719647.73 1.38 491200.68 719647.73 7.5200000000000005 491206.01 719647.31 7.5200000000000005 491206.01 719647.31 1.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1DD-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491200.68 719647.73 7.5200000000000005 491200.31 719643 7.5200000000000005 491205.65 719642.59 7.5200000000000005 491206.01 719647.31 7.5200000000000005 491200.68 719647.73 7.5200000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E12A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E12A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.96</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E12A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491147.94 719634.42 1.24 491153.42 719633.89 1.24 491153 719629.59 1.24 491147.52 719630.12 1.24 491147.94 719634.42 1.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E12A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491147.94 719634.42 1.24 491147.52 719630.12 1.24 491147.52 719630.12 7.195 491147.94 719634.42 7.195 491147.94 719634.42 1.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E12A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491147.52 719630.12 1.24 491153 719629.59 1.24 491153 719629.59 7.195 491147.52 719630.12 7.195 491147.52 719630.12 1.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E12A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491153 719629.59 1.24 491153.42 719633.89 1.24 491153.42 719633.89 7.195 491153 719629.59 7.195 491153 719629.59 1.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E12A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491153.42 719633.89 1.24 491147.94 719634.42 1.24 491147.94 719634.42 7.195 491153.42 719633.89 7.195 491153.42 719633.89 1.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E12A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491147.94 719634.42 7.195 491147.52 719630.12 7.195 491153 719629.59 7.195 491153.42 719633.89 7.195 491147.94 719634.42 7.195</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E296-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E296-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E296-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491255.97 719630.56 0.69 491257.16 719624.17 0.69 491251.49 719623.11 0.69 491250.3 719629.51 0.69 491255.97 719630.56 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E296-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491255.97 719630.56 0.69 491250.3 719629.51 0.69 491250.3 719629.51 5.289999999999999 491255.97 719630.56 5.289999999999999 491255.97 719630.56 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E296-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491250.3 719629.51 0.69 491251.49 719623.11 0.69 491251.49 719623.11 5.289999999999999 491250.3 719629.51 5.289999999999999 491250.3 719629.51 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E296-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491251.49 719623.11 0.69 491257.16 719624.17 0.69 491257.16 719624.17 5.289999999999999 491251.49 719623.11 5.289999999999999 491251.49 719623.11 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E296-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491257.16 719624.17 0.69 491255.97 719630.56 0.69 491255.97 719630.56 5.289999999999999 491257.16 719624.17 5.289999999999999 491257.16 719624.17 0.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E296-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491255.97 719630.56 5.289999999999999 491250.3 719629.51 5.289999999999999 491251.49 719623.11 5.289999999999999 491257.16 719624.17 5.289999999999999 491255.97 719630.56 5.289999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E1DA-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E1DA-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.75</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1DA-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491151.33 719669.95 1.08 491156.81 719669.65 1.08 491156.57 719665.33 1.08 491151.09 719665.62 1.08 491151.33 719669.95 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1DA-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491151.33 719669.95 1.08 491151.09 719665.62 1.08 491151.09 719665.62 3.83 491151.33 719669.95 3.83 491151.33 719669.95 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1DA-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491151.09 719665.62 1.08 491156.57 719665.33 1.08 491156.57 719665.33 3.83 491151.09 719665.62 3.83 491151.09 719665.62 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1DA-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491156.57 719665.33 1.08 491156.81 719669.65 1.08 491156.81 719669.65 3.83 491156.57 719665.33 3.83 491156.57 719665.33 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1DA-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491156.81 719669.65 1.08 491151.33 719669.95 1.08 491151.33 719669.95 3.83 491156.81 719669.65 3.83 491156.81 719669.65 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E1DA-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491151.33 719669.95 3.83 491151.09 719665.62 3.83 491156.57 719665.33 3.83 491156.81 719669.65 3.83 491151.33 719669.95 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E122-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E122-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.89</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E122-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491164.96 719632.95 1.23 491170.45 719632.42 1.23 491170.03 719628.13 1.23 491164.54 719628.67 1.23 491164.96 719632.95 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E122-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491164.96 719632.95 1.23 491164.54 719628.67 1.23 491164.54 719628.67 8.115 491164.96 719632.95 8.115 491164.96 719632.95 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E122-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491164.54 719628.67 1.23 491170.03 719628.13 1.23 491170.03 719628.13 8.115 491164.54 719628.67 8.115 491164.54 719628.67 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E122-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491170.03 719628.13 1.23 491170.45 719632.42 1.23 491170.45 719632.42 8.115 491170.03 719628.13 8.115 491170.03 719628.13 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E122-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491170.45 719632.42 1.23 491164.96 719632.95 1.23 491164.96 719632.95 8.115 491170.45 719632.42 8.115 491170.45 719632.42 1.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E122-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491164.96 719632.95 8.115 491164.54 719628.67 8.115 491170.03 719628.13 8.115 491170.45 719632.42 8.115 491164.96 719632.95 8.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E11F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E11F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.68</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E11F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490970.86 719740.05 1.19 490970.86 719733.18 1.19 490964.54 719733.16 1.19 490964.52 719740.04 1.19 490970.86 719740.05 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E11F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490970.86 719740.05 1.19 490964.52 719740.04 1.19 490964.52 719740.04 4.87 490970.86 719740.05 4.87 490970.86 719740.05 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E11F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490964.52 719740.04 1.19 490964.54 719733.16 1.19 490964.54 719733.16 4.87 490964.52 719740.04 4.87 490964.52 719740.04 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E11F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490964.54 719733.16 1.19 490970.86 719733.18 1.19 490970.86 719733.18 4.87 490964.54 719733.16 4.87 490964.54 719733.16 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E11F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490970.86 719733.18 1.19 490970.86 719740.05 1.19 490970.86 719740.05 4.87 490970.86 719733.18 4.87 490970.86 719733.18 1.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E11F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490970.86 719740.05 4.87 490964.52 719740.04 4.87 490964.54 719733.16 4.87 490970.86 719733.18 4.87 490970.86 719740.05 4.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E11E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E11E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.74</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E11E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490965.59 719770.65 1.37 490972.29 719770.5 1.37 490972.13 719763.41 1.37 490965.43 719763.57 1.37 490965.59 719770.65 1.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E11E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490965.59 719770.65 1.37 490965.43 719763.57 1.37 490965.43 719763.57 5.11 490965.59 719770.65 5.11 490965.59 719770.65 1.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E11E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490965.43 719763.57 1.37 490972.13 719763.41 1.37 490972.13 719763.41 5.11 490965.43 719763.57 5.11 490965.43 719763.57 1.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E11E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490972.13 719763.41 1.37 490972.29 719770.5 1.37 490972.29 719770.5 5.11 490972.13 719763.41 5.11 490972.13 719763.41 1.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E11E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490972.29 719770.5 1.37 490965.59 719770.65 1.37 490965.59 719770.65 5.11 490972.29 719770.5 5.11 490972.29 719770.5 1.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E11E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490965.59 719770.65 5.11 490965.43 719763.57 5.11 490972.13 719763.41 5.11 490972.29 719770.5 5.11 490965.59 719770.65 5.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DEEC-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DEEC-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.03</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DEEC-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490974.24 719754.54 1.08 490974.31 719747.44 1.08 490967.98 719747.37 1.08 490967.9 719754.47 1.08 490974.24 719754.54 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DEEC-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490974.24 719754.54 1.08 490967.9 719754.47 1.08 490967.9 719754.47 5.11 490974.24 719754.54 5.11 490974.24 719754.54 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DEEC-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490967.9 719754.47 1.08 490967.98 719747.37 1.08 490967.98 719747.37 5.11 490967.9 719754.47 5.11 490967.9 719754.47 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DEEC-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490967.98 719747.37 1.08 490974.31 719747.44 1.08 490974.31 719747.44 5.11 490967.98 719747.37 5.11 490967.98 719747.37 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DEEC-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490974.31 719747.44 1.08 490974.24 719754.54 1.08 490974.24 719754.54 5.11 490974.31 719747.44 5.11 490974.31 719747.44 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DEEC-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490974.24 719754.54 5.11 490967.9 719754.47 5.11 490967.98 719747.37 5.11 490974.31 719747.44 5.11 490974.24 719754.54 5.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
</CityModel>
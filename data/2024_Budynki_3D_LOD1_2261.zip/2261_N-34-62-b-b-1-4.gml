<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0" xmlns="http://www.opengis.net/citygml/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
			<gml:lowerCorner>494432.85 715068.58 2.1</gml:lowerCorner>
			<gml:upperCorner>495364.25 716493.72 14.63</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7294-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.87</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494675.11 716474.95 3.67 494677.4 716481.47 3.67 494675.27 716482.26 3.67 494676.02 716484.34 3.67 494678.19 716483.56 3.67 494680.13 716489.24 3.67 494681.31 716492.72 3.67 494687.12 716490.68 3.67 494685.93 716487.19 3.67 494688.87 716486.15 3.67 494683.72 716471.87 3.67 494675.11 716474.95 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494675.11 716474.95 3.67 494683.72 716471.87 3.67 494683.72 716471.87 8.540000000000001 494675.11 716474.95 8.540000000000001 494675.11 716474.95 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494683.72 716471.87 3.67 494688.87 716486.15 3.67 494688.87 716486.15 8.540000000000001 494683.72 716471.87 8.540000000000001 494683.72 716471.87 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494688.87 716486.15 3.67 494685.93 716487.19 3.67 494685.93 716487.19 8.540000000000001 494688.87 716486.15 8.540000000000001 494688.87 716486.15 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494685.93 716487.19 3.67 494687.12 716490.68 3.67 494687.12 716490.68 8.540000000000001 494685.93 716487.19 8.540000000000001 494685.93 716487.19 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494687.12 716490.68 3.67 494681.31 716492.72 3.67 494681.31 716492.72 8.540000000000001 494687.12 716490.68 8.540000000000001 494687.12 716490.68 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494681.31 716492.72 3.67 494680.13 716489.24 3.67 494680.13 716489.24 8.540000000000001 494681.31 716492.72 8.540000000000001 494681.31 716492.72 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494680.13 716489.24 3.67 494678.19 716483.56 3.67 494678.19 716483.56 8.540000000000001 494680.13 716489.24 8.540000000000001 494680.13 716489.24 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494678.19 716483.56 3.67 494676.02 716484.34 3.67 494676.02 716484.34 8.540000000000001 494678.19 716483.56 8.540000000000001 494678.19 716483.56 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494676.02 716484.34 3.67 494675.27 716482.26 3.67 494675.27 716482.26 8.540000000000001 494676.02 716484.34 8.540000000000001 494676.02 716484.34 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494675.27 716482.26 3.67 494677.4 716481.47 3.67 494677.4 716481.47 8.540000000000001 494675.27 716482.26 8.540000000000001 494675.27 716482.26 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494677.4 716481.47 3.67 494675.11 716474.95 3.67 494675.11 716474.95 8.540000000000001 494677.4 716481.47 8.540000000000001 494677.4 716481.47 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7294-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494675.11 716474.95 8.540000000000001 494683.72 716471.87 8.540000000000001 494688.87 716486.15 8.540000000000001 494685.93 716487.19 8.540000000000001 494687.12 716490.68 8.540000000000001 494681.31 716492.72 8.540000000000001 494680.13 716489.24 8.540000000000001 494678.19 716483.56 8.540000000000001 494676.02 716484.34 8.540000000000001 494675.27 716482.26 8.540000000000001 494677.4 716481.47 8.540000000000001 494675.11 716474.95 8.540000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-020C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.07</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494644.19 716487.37 3.69 494645.7 716490.81 3.69 494647.8 716489.83 3.69 494649.57 716493.72 3.69 494657.71 716490.03 3.69 494656.3 716486.75 3.69 494658.32 716485.79 3.69 494657.17 716483.19 3.69 494655.06 716484.11 3.69 494650.48 716486.11 3.69 494649.86 716484.69 3.69 494644.19 716487.37 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494644.19 716487.37 3.69 494649.86 716484.69 3.69 494649.86 716484.69 7.76 494644.19 716487.37 7.76 494644.19 716487.37 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494649.86 716484.69 3.69 494650.48 716486.11 3.69 494650.48 716486.11 7.76 494649.86 716484.69 7.76 494649.86 716484.69 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494650.48 716486.11 3.69 494655.06 716484.11 3.69 494655.06 716484.11 7.76 494650.48 716486.11 7.76 494650.48 716486.11 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494655.06 716484.11 3.69 494657.17 716483.19 3.69 494657.17 716483.19 7.76 494655.06 716484.11 7.76 494655.06 716484.11 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494657.17 716483.19 3.69 494658.32 716485.79 3.69 494658.32 716485.79 7.76 494657.17 716483.19 7.76 494657.17 716483.19 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494658.32 716485.79 3.69 494656.3 716486.75 3.69 494656.3 716486.75 7.76 494658.32 716485.79 7.76 494658.32 716485.79 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494656.3 716486.75 3.69 494657.71 716490.03 3.69 494657.71 716490.03 7.76 494656.3 716486.75 7.76 494656.3 716486.75 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494657.71 716490.03 3.69 494649.57 716493.72 3.69 494649.57 716493.72 7.76 494657.71 716490.03 7.76 494657.71 716490.03 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494649.57 716493.72 3.69 494647.8 716489.83 3.69 494647.8 716489.83 7.76 494649.57 716493.72 7.76 494649.57 716493.72 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494647.8 716489.83 3.69 494645.7 716490.81 3.69 494645.7 716490.81 7.76 494647.8 716489.83 7.76 494647.8 716489.83 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494645.7 716490.81 3.69 494644.19 716487.37 3.69 494644.19 716487.37 7.76 494645.7 716490.81 7.76 494645.7 716490.81 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020C-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494644.19 716487.37 7.76 494649.86 716484.69 7.76 494650.48 716486.11 7.76 494655.06 716484.11 7.76 494657.17 716483.19 7.76 494658.32 716485.79 7.76 494656.3 716486.75 7.76 494657.71 716490.03 7.76 494649.57 716493.72 7.76 494647.8 716489.83 7.76 494645.7 716490.81 7.76 494644.19 716487.37 7.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0471-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.75</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494891.2 715775.01 3.96 494895.44 715770.1 3.96 494896.67 715771.14 3.96 494902.41 715764.43 3.96 494898.99 715761.42 3.96 494898.85 715760.2 3.96 494897.54 715759.08 3.96 494896.3 715759.2 3.96 494893.94 715757.17 3.96 494888.15 715763.9 3.96 494889.23 715764.82 3.96 494885.04 715769.68 3.96 494891.2 715775.01 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494891.2 715775.01 3.96 494885.04 715769.68 3.96 494885.04 715769.68 10.71 494891.2 715775.01 10.71 494891.2 715775.01 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494885.04 715769.68 3.96 494889.23 715764.82 3.96 494889.23 715764.82 10.71 494885.04 715769.68 10.71 494885.04 715769.68 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494889.23 715764.82 3.96 494888.15 715763.9 3.96 494888.15 715763.9 10.71 494889.23 715764.82 10.71 494889.23 715764.82 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494888.15 715763.9 3.96 494893.94 715757.17 3.96 494893.94 715757.17 10.71 494888.15 715763.9 10.71 494888.15 715763.9 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494893.94 715757.17 3.96 494896.3 715759.2 3.96 494896.3 715759.2 10.71 494893.94 715757.17 10.71 494893.94 715757.17 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494896.3 715759.2 3.96 494897.54 715759.08 3.96 494897.54 715759.08 10.71 494896.3 715759.2 10.71 494896.3 715759.2 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494897.54 715759.08 3.96 494898.85 715760.2 3.96 494898.85 715760.2 10.71 494897.54 715759.08 10.71 494897.54 715759.08 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494898.85 715760.2 3.96 494898.99 715761.42 3.96 494898.99 715761.42 10.71 494898.85 715760.2 10.71 494898.85 715760.2 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494898.99 715761.42 3.96 494902.41 715764.43 3.96 494902.41 715764.43 10.71 494898.99 715761.42 10.71 494898.99 715761.42 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494902.41 715764.43 3.96 494896.67 715771.14 3.96 494896.67 715771.14 10.71 494902.41 715764.43 10.71 494902.41 715764.43 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494896.67 715771.14 3.96 494895.44 715770.1 3.96 494895.44 715770.1 10.71 494896.67 715771.14 10.71 494896.67 715771.14 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494895.44 715770.1 3.96 494891.2 715775.01 3.96 494891.2 715775.01 10.71 494895.44 715770.1 10.71 494895.44 715770.1 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0471-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494891.2 715775.01 10.71 494885.04 715769.68 10.71 494889.23 715764.82 10.71 494888.15 715763.9 10.71 494893.94 715757.17 10.71 494896.3 715759.2 10.71 494897.54 715759.08 10.71 494898.85 715760.2 10.71 494898.99 715761.42 10.71 494902.41 715764.43 10.71 494896.67 715771.14 10.71 494895.44 715770.1 10.71 494891.2 715775.01 10.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-046F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494909.44 715372.86 4.51 494919.28 715375.44 4.51 494919.89 715373.08 4.51 494920.15 715372.05 4.51 494920.25 715371.66 4.51 494922.07 715372.1 4.51 494923 715368.81 4.51 494921.1 715368.36 4.51 494922.3 715363.57 4.51 494912.49 715360.96 4.51 494910.74 715367.8 4.51 494910.48 715368.84 4.51 494909.97 715370.82 4.51 494909.7 715371.85 4.51 494909.44 715372.86 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494909.44 715372.86 4.51 494909.7 715371.85 4.51 494909.7 715371.85 9.98 494909.44 715372.86 9.98 494909.44 715372.86 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494909.7 715371.85 4.51 494909.97 715370.82 4.51 494909.97 715370.82 9.98 494909.7 715371.85 9.98 494909.7 715371.85 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494909.97 715370.82 4.51 494910.48 715368.84 4.51 494910.48 715368.84 9.98 494909.97 715370.82 9.98 494909.97 715370.82 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494910.48 715368.84 4.51 494910.74 715367.8 4.51 494910.74 715367.8 9.98 494910.48 715368.84 9.98 494910.48 715368.84 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494910.74 715367.8 4.51 494912.49 715360.96 4.51 494912.49 715360.96 9.98 494910.74 715367.8 9.98 494910.74 715367.8 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494912.49 715360.96 4.51 494922.3 715363.57 4.51 494922.3 715363.57 9.98 494912.49 715360.96 9.98 494912.49 715360.96 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494922.3 715363.57 4.51 494921.1 715368.36 4.51 494921.1 715368.36 9.98 494922.3 715363.57 9.98 494922.3 715363.57 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494921.1 715368.36 4.51 494923 715368.81 4.51 494923 715368.81 9.98 494921.1 715368.36 9.98 494921.1 715368.36 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494923 715368.81 4.51 494922.07 715372.1 4.51 494922.07 715372.1 9.98 494923 715368.81 9.98 494923 715368.81 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494922.07 715372.1 4.51 494920.25 715371.66 4.51 494920.25 715371.66 9.98 494922.07 715372.1 9.98 494922.07 715372.1 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494920.25 715371.66 4.51 494920.15 715372.05 4.51 494920.15 715372.05 9.98 494920.25 715371.66 9.98 494920.25 715371.66 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494920.15 715372.05 4.51 494919.89 715373.08 4.51 494919.89 715373.08 9.98 494920.15 715372.05 9.98 494920.15 715372.05 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494919.89 715373.08 4.51 494919.28 715375.44 4.51 494919.28 715375.44 9.98 494919.89 715373.08 9.98 494919.89 715373.08 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494919.28 715375.44 4.51 494909.44 715372.86 4.51 494909.44 715372.86 9.98 494919.28 715375.44 9.98 494919.28 715375.44 4.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046F-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494909.44 715372.86 9.98 494909.7 715371.85 9.98 494909.97 715370.82 9.98 494910.48 715368.84 9.98 494910.74 715367.8 9.98 494912.49 715360.96 9.98 494922.3 715363.57 9.98 494921.1 715368.36 9.98 494923 715368.81 9.98 494922.07 715372.1 9.98 494920.25 715371.66 9.98 494920.15 715372.05 9.98 494919.89 715373.08 9.98 494919.28 715375.44 9.98 494909.44 715372.86 9.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-046D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.19</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494859.73 716272.62 3.71 494860.92 716275.41 3.71 494861.56 716275.15 3.71 494865 716283.45 3.71 494866.02 716285.77 3.71 494871.31 716283.51 3.71 494870.38 716281.18 3.71 494871.67 716280.66 3.71 494868.21 716272.31 3.71 494864.28 716273.96 3.71 494863.42 716271.92 3.71 494862.48 716271.42 3.71 494859.73 716272.62 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494859.73 716272.62 3.71 494862.48 716271.42 3.71 494862.48 716271.42 7.9 494859.73 716272.62 7.9 494859.73 716272.62 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494862.48 716271.42 3.71 494863.42 716271.92 3.71 494863.42 716271.92 7.9 494862.48 716271.42 7.9 494862.48 716271.42 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494863.42 716271.92 3.71 494864.28 716273.96 3.71 494864.28 716273.96 7.9 494863.42 716271.92 7.9 494863.42 716271.92 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494864.28 716273.96 3.71 494868.21 716272.31 3.71 494868.21 716272.31 7.9 494864.28 716273.96 7.9 494864.28 716273.96 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494868.21 716272.31 3.71 494871.67 716280.66 3.71 494871.67 716280.66 7.9 494868.21 716272.31 7.9 494868.21 716272.31 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494871.67 716280.66 3.71 494870.38 716281.18 3.71 494870.38 716281.18 7.9 494871.67 716280.66 7.9 494871.67 716280.66 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494870.38 716281.18 3.71 494871.31 716283.51 3.71 494871.31 716283.51 7.9 494870.38 716281.18 7.9 494870.38 716281.18 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494871.31 716283.51 3.71 494866.02 716285.77 3.71 494866.02 716285.77 7.9 494871.31 716283.51 7.9 494871.31 716283.51 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494866.02 716285.77 3.71 494865 716283.45 3.71 494865 716283.45 7.9 494866.02 716285.77 7.9 494866.02 716285.77 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494865 716283.45 3.71 494861.56 716275.15 3.71 494861.56 716275.15 7.9 494865 716283.45 7.9 494865 716283.45 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494861.56 716275.15 3.71 494860.92 716275.41 3.71 494860.92 716275.41 7.9 494861.56 716275.15 7.9 494861.56 716275.15 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494860.92 716275.41 3.71 494859.73 716272.62 3.71 494859.73 716272.62 7.9 494860.92 716275.41 7.9 494860.92 716275.41 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046D-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494859.73 716272.62 7.9 494862.48 716271.42 7.9 494863.42 716271.92 7.9 494864.28 716273.96 7.9 494868.21 716272.31 7.9 494871.67 716280.66 7.9 494870.38 716281.18 7.9 494871.31 716283.51 7.9 494866.02 716285.77 7.9 494865 716283.45 7.9 494861.56 716275.15 7.9 494860.92 716275.41 7.9 494859.73 716272.62 7.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.08</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495013.93 715977.61 3.4 495018.39 715981.45 3.4 495017.98 715981.92 3.4 495022.14 715985.36 3.4 495024.78 715981.99 3.4 495026.89 715983.83 3.4 495033.63 715976.18 3.4 495022.91 715967.12 3.4 495016.36 715974.72 3.4 495016.16 715974.95 3.4 495015.95 715974.77 3.4 495015.74 715975.03 3.4 495015.95 715975.21 3.4 495013.93 715977.61 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495013.93 715977.61 3.4 495015.95 715975.21 3.4 495015.95 715975.21 9.48 495013.93 715977.61 9.48 495013.93 715977.61 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495015.95 715975.21 3.4 495015.74 715975.03 3.4 495015.74 715975.03 9.48 495015.95 715975.21 9.48 495015.95 715975.21 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495015.74 715975.03 3.4 495015.95 715974.77 3.4 495015.95 715974.77 9.48 495015.74 715975.03 9.48 495015.74 715975.03 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495015.95 715974.77 3.4 495016.16 715974.95 3.4 495016.16 715974.95 9.48 495015.95 715974.77 9.48 495015.95 715974.77 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495016.16 715974.95 3.4 495016.36 715974.72 3.4 495016.36 715974.72 9.48 495016.16 715974.95 9.48 495016.16 715974.95 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495016.36 715974.72 3.4 495022.91 715967.12 3.4 495022.91 715967.12 9.48 495016.36 715974.72 9.48 495016.36 715974.72 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495022.91 715967.12 3.4 495033.63 715976.18 3.4 495033.63 715976.18 9.48 495022.91 715967.12 9.48 495022.91 715967.12 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495033.63 715976.18 3.4 495026.89 715983.83 3.4 495026.89 715983.83 9.48 495033.63 715976.18 9.48 495033.63 715976.18 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495026.89 715983.83 3.4 495024.78 715981.99 3.4 495024.78 715981.99 9.48 495026.89 715983.83 9.48 495026.89 715983.83 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495024.78 715981.99 3.4 495022.14 715985.36 3.4 495022.14 715985.36 9.48 495024.78 715981.99 9.48 495024.78 715981.99 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495022.14 715985.36 3.4 495017.98 715981.92 3.4 495017.98 715981.92 9.48 495022.14 715985.36 9.48 495022.14 715985.36 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495017.98 715981.92 3.4 495018.39 715981.45 3.4 495018.39 715981.45 9.48 495017.98 715981.92 9.48 495017.98 715981.92 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495018.39 715981.45 3.4 495013.93 715977.61 3.4 495013.93 715977.61 9.48 495018.39 715981.45 9.48 495018.39 715981.45 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DB5-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495013.93 715977.61 9.48 495015.95 715975.21 9.48 495015.74 715975.03 9.48 495015.95 715974.77 9.48 495016.16 715974.95 9.48 495016.36 715974.72 9.48 495022.91 715967.12 9.48 495033.63 715976.18 9.48 495026.89 715983.83 9.48 495024.78 715981.99 9.48 495022.14 715985.36 9.48 495017.98 715981.92 9.48 495018.39 715981.45 9.48 495013.93 715977.61 9.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.52</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494996.28 715924.74 3.51 495000 715919.14 3.51 494997.16 715917.3 3.51 494997.38 715916.96 3.51 494990.29 715912.21 3.51 494989.86 715912.85 3.51 494989.65 715912.7 3.51 494988.29 715912.95 3.51 494987.26 715914.47 3.51 494987.55 715915.81 3.51 494987.77 715915.95 3.51 494986.13 715918.4 3.51 494993.21 715923.18 3.51 494993.46 715922.81 3.51 494996.28 715924.74 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494996.28 715924.74 3.51 494993.46 715922.81 3.51 494993.46 715922.81 10.03 494996.28 715924.74 10.03 494996.28 715924.74 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494993.46 715922.81 3.51 494993.21 715923.18 3.51 494993.21 715923.18 10.03 494993.46 715922.81 10.03 494993.46 715922.81 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494993.21 715923.18 3.51 494986.13 715918.4 3.51 494986.13 715918.4 10.03 494993.21 715923.18 10.03 494993.21 715923.18 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494986.13 715918.4 3.51 494987.77 715915.95 3.51 494987.77 715915.95 10.03 494986.13 715918.4 10.03 494986.13 715918.4 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494987.77 715915.95 3.51 494987.55 715915.81 3.51 494987.55 715915.81 10.03 494987.77 715915.95 10.03 494987.77 715915.95 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494987.55 715915.81 3.51 494987.26 715914.47 3.51 494987.26 715914.47 10.03 494987.55 715915.81 10.03 494987.55 715915.81 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494987.26 715914.47 3.51 494988.29 715912.95 3.51 494988.29 715912.95 10.03 494987.26 715914.47 10.03 494987.26 715914.47 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494988.29 715912.95 3.51 494989.65 715912.7 3.51 494989.65 715912.7 10.03 494988.29 715912.95 10.03 494988.29 715912.95 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494989.65 715912.7 3.51 494989.86 715912.85 3.51 494989.86 715912.85 10.03 494989.65 715912.7 10.03 494989.65 715912.7 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494989.86 715912.85 3.51 494990.29 715912.21 3.51 494990.29 715912.21 10.03 494989.86 715912.85 10.03 494989.86 715912.85 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494990.29 715912.21 3.51 494997.38 715916.96 3.51 494997.38 715916.96 10.03 494990.29 715912.21 10.03 494990.29 715912.21 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494997.38 715916.96 3.51 494997.16 715917.3 3.51 494997.16 715917.3 10.03 494997.38 715916.96 10.03 494997.38 715916.96 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494997.16 715917.3 3.51 495000 715919.14 3.51 495000 715919.14 10.03 494997.16 715917.3 10.03 494997.16 715917.3 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495000 715919.14 3.51 494996.28 715924.74 3.51 494996.28 715924.74 10.03 495000 715919.14 10.03 495000 715919.14 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E7C-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494996.28 715924.74 10.03 494993.46 715922.81 10.03 494993.21 715923.18 10.03 494986.13 715918.4 10.03 494987.77 715915.95 10.03 494987.55 715915.81 10.03 494987.26 715914.47 10.03 494988.29 715912.95 10.03 494989.65 715912.7 10.03 494989.86 715912.85 10.03 494990.29 715912.21 10.03 494997.38 715916.96 10.03 494997.16 715917.3 10.03 495000 715919.14 10.03 494996.28 715924.74 10.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0206-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0206-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.88</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0206-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494628.9 716448.01 3.64 494637.31 716444.31 3.64 494632.82 716434.56 3.64 494624.55 716438.3 3.64 494628.9 716448.01 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0206-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494628.9 716448.01 3.64 494624.55 716438.3 3.64 494624.55 716438.3 8.52 494628.9 716448.01 8.52 494628.9 716448.01 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0206-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494624.55 716438.3 3.64 494632.82 716434.56 3.64 494632.82 716434.56 8.52 494624.55 716438.3 8.52 494624.55 716438.3 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0206-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494632.82 716434.56 3.64 494637.31 716444.31 3.64 494637.31 716444.31 8.52 494632.82 716434.56 8.52 494632.82 716434.56 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0206-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494637.31 716444.31 3.64 494628.9 716448.01 3.64 494628.9 716448.01 8.52 494637.31 716444.31 8.52 494637.31 716444.31 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0206-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494628.9 716448.01 8.52 494624.55 716438.3 8.52 494632.82 716434.56 8.52 494637.31 716444.31 8.52 494628.9 716448.01 8.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0204-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0204-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.73</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0204-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494624.55 716438.3 3.77 494632.82 716434.56 3.77 494628.48 716424.86 3.77 494620.18 716428.59 3.77 494624.55 716438.3 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0204-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494624.55 716438.3 3.77 494620.18 716428.59 3.77 494620.18 716428.59 8.5 494624.55 716438.3 8.5 494624.55 716438.3 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0204-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494620.18 716428.59 3.77 494628.48 716424.86 3.77 494628.48 716424.86 8.5 494620.18 716428.59 8.5 494620.18 716428.59 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0204-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494628.48 716424.86 3.77 494632.82 716434.56 3.77 494632.82 716434.56 8.5 494628.48 716424.86 8.5 494628.48 716424.86 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0204-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494632.82 716434.56 3.77 494624.55 716438.3 3.77 494624.55 716438.3 8.5 494632.82 716434.56 8.5 494632.82 716434.56 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0204-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494624.55 716438.3 8.5 494620.18 716428.59 8.5 494628.48 716424.86 8.5 494632.82 716434.56 8.5 494624.55 716438.3 8.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0202-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.44</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494601.85 716409.24 4.04 494605.21 716416.65 4.04 494611.2 716413.84 4.04 494612.92 716417.56 4.04 494615.64 716417.6 4.04 494623.72 716413.96 4.04 494622.35 716410.99 4.04 494625.36 716409.61 4.04 494623.51 716405.47 4.04 494620.57 716406.8 4.04 494618.26 716401.66 4.04 494610.29 716405.34 4.04 494601.85 716409.24 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494601.85 716409.24 4.04 494610.29 716405.34 4.04 494610.29 716405.34 9.48 494601.85 716409.24 9.48 494601.85 716409.24 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494610.29 716405.34 4.04 494618.26 716401.66 4.04 494618.26 716401.66 9.48 494610.29 716405.34 9.48 494610.29 716405.34 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494618.26 716401.66 4.04 494620.57 716406.8 4.04 494620.57 716406.8 9.48 494618.26 716401.66 9.48 494618.26 716401.66 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494620.57 716406.8 4.04 494623.51 716405.47 4.04 494623.51 716405.47 9.48 494620.57 716406.8 9.48 494620.57 716406.8 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494623.51 716405.47 4.04 494625.36 716409.61 4.04 494625.36 716409.61 9.48 494623.51 716405.47 9.48 494623.51 716405.47 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494625.36 716409.61 4.04 494622.35 716410.99 4.04 494622.35 716410.99 9.48 494625.36 716409.61 9.48 494625.36 716409.61 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494622.35 716410.99 4.04 494623.72 716413.96 4.04 494623.72 716413.96 9.48 494622.35 716410.99 9.48 494622.35 716410.99 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494623.72 716413.96 4.04 494615.64 716417.6 4.04 494615.64 716417.6 9.48 494623.72 716413.96 9.48 494623.72 716413.96 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494615.64 716417.6 4.04 494612.92 716417.56 4.04 494612.92 716417.56 9.48 494615.64 716417.6 9.48 494615.64 716417.6 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494612.92 716417.56 4.04 494611.2 716413.84 4.04 494611.2 716413.84 9.48 494612.92 716417.56 9.48 494612.92 716417.56 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494611.2 716413.84 4.04 494605.21 716416.65 4.04 494605.21 716416.65 9.48 494611.2 716413.84 9.48 494611.2 716413.84 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494605.21 716416.65 4.04 494601.85 716409.24 4.04 494601.85 716409.24 9.48 494605.21 716416.65 9.48 494605.21 716416.65 4.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0202-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494601.85 716409.24 9.48 494610.29 716405.34 9.48 494618.26 716401.66 9.48 494620.57 716406.8 9.48 494623.51 716405.47 9.48 494625.36 716409.61 9.48 494622.35 716410.99 9.48 494623.72 716413.96 9.48 494615.64 716417.6 9.48 494612.92 716417.56 9.48 494611.2 716413.84 9.48 494605.21 716416.65 9.48 494601.85 716409.24 9.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7032-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7032-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.21</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7032-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494866.66 716287.86 3.75 494866.73 716288.02 3.75 494868.63 716292.67 3.75 494869.11 716293.92 3.75 494878.75 716289.88 3.75 494876.28 716283.78 3.75 494866.66 716287.86 3.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7032-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494866.66 716287.86 3.75 494876.28 716283.78 3.75 494876.28 716283.78 8.96 494866.66 716287.86 8.96 494866.66 716287.86 3.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7032-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494876.28 716283.78 3.75 494878.75 716289.88 3.75 494878.75 716289.88 8.96 494876.28 716283.78 8.96 494876.28 716283.78 3.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7032-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494878.75 716289.88 3.75 494869.11 716293.92 3.75 494869.11 716293.92 8.96 494878.75 716289.88 8.96 494878.75 716289.88 3.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7032-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494869.11 716293.92 3.75 494868.63 716292.67 3.75 494868.63 716292.67 8.96 494869.11 716293.92 8.96 494869.11 716293.92 3.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7032-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494868.63 716292.67 3.75 494866.73 716288.02 3.75 494866.73 716288.02 8.96 494868.63 716292.67 8.96 494868.63 716292.67 3.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7032-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494866.73 716288.02 3.75 494866.66 716287.86 3.75 494866.66 716287.86 8.96 494866.73 716288.02 8.96 494866.73 716288.02 3.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7032-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494866.66 716287.86 8.96 494876.28 716283.78 8.96 494878.75 716289.88 8.96 494869.11 716293.92 8.96 494868.63 716292.67 8.96 494866.73 716288.02 8.96 494866.66 716287.86 8.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-03A4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-03A4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.39</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494821.46 715793.54 3.46 494819.04 715796.66 3.46 494813.25 715804.08 3.46 494823.4 715811.99 3.46 494829.19 715804.56 3.46 494825.16 715801.43 3.46 494827.58 715798.32 3.46 494821.46 715793.54 3.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494821.46 715793.54 3.46 494827.58 715798.32 3.46 494827.58 715798.32 8.85 494821.46 715793.54 8.85 494821.46 715793.54 3.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494827.58 715798.32 3.46 494825.16 715801.43 3.46 494825.16 715801.43 8.85 494827.58 715798.32 8.85 494827.58 715798.32 3.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494825.16 715801.43 3.46 494829.19 715804.56 3.46 494829.19 715804.56 8.85 494825.16 715801.43 8.85 494825.16 715801.43 3.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494829.19 715804.56 3.46 494823.4 715811.99 3.46 494823.4 715811.99 8.85 494829.19 715804.56 8.85 494829.19 715804.56 3.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494823.4 715811.99 3.46 494813.25 715804.08 3.46 494813.25 715804.08 8.85 494823.4 715811.99 8.85 494823.4 715811.99 3.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494813.25 715804.08 3.46 494819.04 715796.66 3.46 494819.04 715796.66 8.85 494813.25 715804.08 8.85 494813.25 715804.08 3.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494819.04 715796.66 3.46 494821.46 715793.54 3.46 494821.46 715793.54 8.85 494819.04 715796.66 8.85 494819.04 715796.66 3.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A4-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494821.46 715793.54 8.85 494827.58 715798.32 8.85 494825.16 715801.43 8.85 494829.19 715804.56 8.85 494823.4 715811.99 8.85 494813.25 715804.08 8.85 494819.04 715796.66 8.85 494821.46 715793.54 8.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-03A3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-03A3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.07</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494788.16 715811.57 3.14 494799.5 715820.18 3.14 494804.83 715813.23 3.14 494804.69 715813.12 3.14 494806.71 715810.72 3.14 494802.07 715807.03 3.14 494795.42 715802.05 3.14 494793.47 715804.64 3.14 494788.16 715811.57 3.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494788.16 715811.57 3.14 494793.47 715804.64 3.14 494793.47 715804.64 8.21 494788.16 715811.57 8.21 494788.16 715811.57 3.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494793.47 715804.64 3.14 494795.42 715802.05 3.14 494795.42 715802.05 8.21 494793.47 715804.64 8.21 494793.47 715804.64 3.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494795.42 715802.05 3.14 494802.07 715807.03 3.14 494802.07 715807.03 8.21 494795.42 715802.05 8.21 494795.42 715802.05 3.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494802.07 715807.03 3.14 494806.71 715810.72 3.14 494806.71 715810.72 8.21 494802.07 715807.03 8.21 494802.07 715807.03 3.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494806.71 715810.72 3.14 494804.69 715813.12 3.14 494804.69 715813.12 8.21 494806.71 715810.72 8.21 494806.71 715810.72 3.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A3-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494804.69 715813.12 3.14 494804.83 715813.23 3.14 494804.83 715813.23 8.21 494804.69 715813.12 8.21 494804.69 715813.12 3.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A3-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494804.83 715813.23 3.14 494799.5 715820.18 3.14 494799.5 715820.18 8.21 494804.83 715813.23 8.21 494804.83 715813.23 3.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A3-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494799.5 715820.18 3.14 494788.16 715811.57 3.14 494788.16 715811.57 8.21 494799.5 715820.18 8.21 494799.5 715820.18 3.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A3-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494788.16 715811.57 8.21 494793.47 715804.64 8.21 494795.42 715802.05 8.21 494802.07 715807.03 8.21 494806.71 715810.72 8.21 494804.69 715813.12 8.21 494804.83 715813.23 8.21 494799.5 715820.18 8.21 494788.16 715811.57 8.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-03A2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-03A2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.41</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494799.99 715717.02 4.62 494808.19 715721.47 4.62 494811.2 715716.02 4.62 494808.55 715714.55 4.62 494810.64 715710.72 4.62 494804.03 715707.16 4.62 494801.68 715711.61 4.62 494802.58 715712.1 4.62 494799.99 715717.02 4.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494799.99 715717.02 4.62 494802.58 715712.1 4.62 494802.58 715712.1 10.03 494799.99 715717.02 10.03 494799.99 715717.02 4.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494802.58 715712.1 4.62 494801.68 715711.61 4.62 494801.68 715711.61 10.03 494802.58 715712.1 10.03 494802.58 715712.1 4.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494801.68 715711.61 4.62 494804.03 715707.16 4.62 494804.03 715707.16 10.03 494801.68 715711.61 10.03 494801.68 715711.61 4.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494804.03 715707.16 4.62 494810.64 715710.72 4.62 494810.64 715710.72 10.03 494804.03 715707.16 10.03 494804.03 715707.16 4.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494810.64 715710.72 4.62 494808.55 715714.55 4.62 494808.55 715714.55 10.03 494810.64 715710.72 10.03 494810.64 715710.72 4.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A2-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494808.55 715714.55 4.62 494811.2 715716.02 4.62 494811.2 715716.02 10.03 494808.55 715714.55 10.03 494808.55 715714.55 4.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A2-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494811.2 715716.02 4.62 494808.19 715721.47 4.62 494808.19 715721.47 10.03 494811.2 715716.02 10.03 494811.2 715716.02 4.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A2-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494808.19 715721.47 4.62 494799.99 715717.02 4.62 494799.99 715717.02 10.03 494808.19 715721.47 10.03 494808.19 715721.47 4.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-03A2-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494799.99 715717.02 10.03 494802.58 715712.1 10.03 494801.68 715711.61 10.03 494804.03 715707.16 10.03 494810.64 715710.72 10.03 494808.55 715714.55 10.03 494811.2 715716.02 10.03 494808.19 715721.47 10.03 494799.99 715717.02 10.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C702-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C702-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C702-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495028.7 716164.62 3.44 495033.77 716176.81 3.44 495046.21 716171.63 3.44 495041.15 716159.44 3.44 495028.7 716164.62 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C702-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495028.7 716164.62 3.44 495041.15 716159.44 3.44 495041.15 716159.44 8.040000000000001 495028.7 716164.62 8.040000000000001 495028.7 716164.62 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C702-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495041.15 716159.44 3.44 495046.21 716171.63 3.44 495046.21 716171.63 8.040000000000001 495041.15 716159.44 8.040000000000001 495041.15 716159.44 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C702-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495046.21 716171.63 3.44 495033.77 716176.81 3.44 495033.77 716176.81 8.040000000000001 495046.21 716171.63 8.040000000000001 495046.21 716171.63 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C702-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495033.77 716176.81 3.44 495028.7 716164.62 3.44 495028.7 716164.62 8.040000000000001 495033.77 716176.81 8.040000000000001 495033.77 716176.81 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C702-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495028.7 716164.62 8.040000000000001 495041.15 716159.44 8.040000000000001 495046.21 716171.63 8.040000000000001 495033.77 716176.81 8.040000000000001 495028.7 716164.62 8.040000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02CF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02CF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.51</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494677.36 716364.95 3.28 494687.96 716361.13 3.28 494686.47 716356.97 3.28 494683.68 716349.16 3.28 494685.58 716348.5 3.28 494684.23 716344.67 3.28 494671.67 716349.2 3.28 494675.86 716360.82 3.28 494677.36 716364.95 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494677.36 716364.95 3.28 494675.86 716360.82 3.28 494675.86 716360.82 6.79 494677.36 716364.95 6.79 494677.36 716364.95 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494675.86 716360.82 3.28 494671.67 716349.2 3.28 494671.67 716349.2 6.79 494675.86 716360.82 6.79 494675.86 716360.82 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494671.67 716349.2 3.28 494684.23 716344.67 3.28 494684.23 716344.67 6.79 494671.67 716349.2 6.79 494671.67 716349.2 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494684.23 716344.67 3.28 494685.58 716348.5 3.28 494685.58 716348.5 6.79 494684.23 716344.67 6.79 494684.23 716344.67 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494685.58 716348.5 3.28 494683.68 716349.16 3.28 494683.68 716349.16 6.79 494685.58 716348.5 6.79 494685.58 716348.5 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494683.68 716349.16 3.28 494686.47 716356.97 3.28 494686.47 716356.97 6.79 494683.68 716349.16 6.79 494683.68 716349.16 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494686.47 716356.97 3.28 494687.96 716361.13 3.28 494687.96 716361.13 6.79 494686.47 716356.97 6.79 494686.47 716356.97 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CF-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494687.96 716361.13 3.28 494677.36 716364.95 3.28 494677.36 716364.95 6.79 494687.96 716361.13 6.79 494687.96 716361.13 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CF-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494677.36 716364.95 6.79 494675.86 716360.82 6.79 494671.67 716349.2 6.79 494684.23 716344.67 6.79 494685.58 716348.5 6.79 494683.68 716349.16 6.79 494686.47 716356.97 6.79 494687.96 716361.13 6.79 494677.36 716364.95 6.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D64B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D64B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.88</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D64B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495309.51 716456.04 3.73 495316.08 716470.57 3.73 495333.51 716462.84 3.73 495326.88 716448.39 3.73 495309.51 716456.04 3.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D64B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495309.51 716456.04 3.73 495326.88 716448.39 3.73 495326.88 716448.39 9.61 495309.51 716456.04 9.61 495309.51 716456.04 3.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D64B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495326.88 716448.39 3.73 495333.51 716462.84 3.73 495333.51 716462.84 9.61 495326.88 716448.39 9.61 495326.88 716448.39 3.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D64B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495333.51 716462.84 3.73 495316.08 716470.57 3.73 495316.08 716470.57 9.61 495333.51 716462.84 9.61 495333.51 716462.84 3.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D64B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495316.08 716470.57 3.73 495309.51 716456.04 3.73 495309.51 716456.04 9.61 495316.08 716470.57 9.61 495316.08 716470.57 3.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D64B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495309.51 716456.04 9.61 495326.88 716448.39 9.61 495333.51 716462.84 9.61 495316.08 716470.57 9.61 495309.51 716456.04 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7033-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7033-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.11</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7033-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494999.68 715909.01 3.2 495007.94 715914.52 3.2 495011.73 715908.82 3.2 495003.47 715903.32 3.2 494999.68 715909.01 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7033-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494999.68 715909.01 3.2 495003.47 715903.32 3.2 495003.47 715903.32 7.3100000000000005 494999.68 715909.01 7.3100000000000005 494999.68 715909.01 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7033-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495003.47 715903.32 3.2 495011.73 715908.82 3.2 495011.73 715908.82 7.3100000000000005 495003.47 715903.32 7.3100000000000005 495003.47 715903.32 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7033-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495011.73 715908.82 3.2 495007.94 715914.52 3.2 495007.94 715914.52 7.3100000000000005 495011.73 715908.82 7.3100000000000005 495011.73 715908.82 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7033-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495007.94 715914.52 3.2 494999.68 715909.01 3.2 494999.68 715909.01 7.3100000000000005 495007.94 715914.52 7.3100000000000005 495007.94 715914.52 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7033-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494999.68 715909.01 7.3100000000000005 495003.47 715903.32 7.3100000000000005 495011.73 715908.82 7.3100000000000005 495007.94 715914.52 7.3100000000000005 494999.68 715909.01 7.3100000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D57A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D57A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.76</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494969.85 715339.61 4.26 494967.7 715353.87 4.26 494968.26 715353.95 4.26 494968.23 715354.2 4.26 494968.64 715354.26 4.26 494968.67 715354.01 4.26 494976.34 715355.16 4.26 494978.44 715340.88 4.26 494969.85 715339.61 4.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494969.85 715339.61 4.26 494978.44 715340.88 4.26 494978.44 715340.88 7.0200000000000005 494969.85 715339.61 7.0200000000000005 494969.85 715339.61 4.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494978.44 715340.88 4.26 494976.34 715355.16 4.26 494976.34 715355.16 7.0200000000000005 494978.44 715340.88 7.0200000000000005 494978.44 715340.88 4.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494976.34 715355.16 4.26 494968.67 715354.01 4.26 494968.67 715354.01 7.0200000000000005 494976.34 715355.16 7.0200000000000005 494976.34 715355.16 4.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494968.67 715354.01 4.26 494968.64 715354.26 4.26 494968.64 715354.26 7.0200000000000005 494968.67 715354.01 7.0200000000000005 494968.67 715354.01 4.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494968.64 715354.26 4.26 494968.23 715354.2 4.26 494968.23 715354.2 7.0200000000000005 494968.64 715354.26 7.0200000000000005 494968.64 715354.26 4.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494968.23 715354.2 4.26 494968.26 715353.95 4.26 494968.26 715353.95 7.0200000000000005 494968.23 715354.2 7.0200000000000005 494968.23 715354.2 4.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494968.26 715353.95 4.26 494967.7 715353.87 4.26 494967.7 715353.87 7.0200000000000005 494968.26 715353.95 7.0200000000000005 494968.26 715353.95 4.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494967.7 715353.87 4.26 494969.85 715339.61 4.26 494969.85 715339.61 7.0200000000000005 494967.7 715353.87 7.0200000000000005 494967.7 715353.87 4.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494969.85 715339.61 7.0200000000000005 494978.44 715340.88 7.0200000000000005 494976.34 715355.16 7.0200000000000005 494968.67 715354.01 7.0200000000000005 494968.64 715354.26 7.0200000000000005 494968.23 715354.2 7.0200000000000005 494968.26 715353.95 7.0200000000000005 494967.7 715353.87 7.0200000000000005 494969.85 715339.61 7.0200000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D57C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D57C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.61</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495177.32 716242.28 2.85 495180.53 716249.51 2.85 495186.35 716246.87 2.85 495183.24 716239.66 2.85 495177.32 716242.28 2.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495177.32 716242.28 2.85 495183.24 716239.66 2.85 495183.24 716239.66 7.459999999999999 495177.32 716242.28 7.459999999999999 495177.32 716242.28 2.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495183.24 716239.66 2.85 495186.35 716246.87 2.85 495186.35 716246.87 7.459999999999999 495183.24 716239.66 7.459999999999999 495183.24 716239.66 2.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495186.35 716246.87 2.85 495180.53 716249.51 2.85 495180.53 716249.51 7.459999999999999 495186.35 716246.87 7.459999999999999 495186.35 716246.87 2.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495180.53 716249.51 2.85 495177.32 716242.28 2.85 495177.32 716242.28 7.459999999999999 495180.53 716249.51 7.459999999999999 495180.53 716249.51 2.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495177.32 716242.28 7.459999999999999 495183.24 716239.66 7.459999999999999 495186.35 716246.87 7.459999999999999 495180.53 716249.51 7.459999999999999 495177.32 716242.28 7.459999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D572-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D572-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.8</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D572-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494920.37 715394.22 4.38 494918.23 715400.08 4.38 494929.63 715404.43 4.38 494931.88 715398.58 4.38 494920.37 715394.22 4.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D572-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494920.37 715394.22 4.38 494931.88 715398.58 4.38 494931.88 715398.58 7.18 494920.37 715394.22 7.18 494920.37 715394.22 4.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D572-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494931.88 715398.58 4.38 494929.63 715404.43 4.38 494929.63 715404.43 7.18 494931.88 715398.58 7.18 494931.88 715398.58 4.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D572-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494929.63 715404.43 4.38 494918.23 715400.08 4.38 494918.23 715400.08 7.18 494929.63 715404.43 7.18 494929.63 715404.43 4.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D572-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494918.23 715400.08 4.38 494920.37 715394.22 4.38 494920.37 715394.22 7.18 494918.23 715400.08 7.18 494918.23 715400.08 4.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D572-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494920.37 715394.22 7.18 494931.88 715398.58 7.18 494929.63 715404.43 7.18 494918.23 715400.08 7.18 494920.37 715394.22 7.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D575-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D575-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.02</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D575-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494919.3 716273.22 3.79 494921.53 716278.38 3.79 494929.82 716275.07 3.79 494928.86 716272.86 3.79 494930.83 716272.04 3.79 494929.52 716269.04 3.79 494927.54 716269.92 3.79 494919.3 716273.22 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D575-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494919.3 716273.22 3.79 494927.54 716269.92 3.79 494927.54 716269.92 7.8100000000000005 494919.3 716273.22 7.8100000000000005 494919.3 716273.22 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D575-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494927.54 716269.92 3.79 494929.52 716269.04 3.79 494929.52 716269.04 7.8100000000000005 494927.54 716269.92 7.8100000000000005 494927.54 716269.92 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D575-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494929.52 716269.04 3.79 494930.83 716272.04 3.79 494930.83 716272.04 7.8100000000000005 494929.52 716269.04 7.8100000000000005 494929.52 716269.04 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D575-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494930.83 716272.04 3.79 494928.86 716272.86 3.79 494928.86 716272.86 7.8100000000000005 494930.83 716272.04 7.8100000000000005 494930.83 716272.04 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D575-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494928.86 716272.86 3.79 494929.82 716275.07 3.79 494929.82 716275.07 7.8100000000000005 494928.86 716272.86 7.8100000000000005 494928.86 716272.86 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D575-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494929.82 716275.07 3.79 494921.53 716278.38 3.79 494921.53 716278.38 7.8100000000000005 494929.82 716275.07 7.8100000000000005 494929.82 716275.07 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D575-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494921.53 716278.38 3.79 494919.3 716273.22 3.79 494919.3 716273.22 7.8100000000000005 494921.53 716278.38 7.8100000000000005 494921.53 716278.38 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D575-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494919.3 716273.22 7.8100000000000005 494927.54 716269.92 7.8100000000000005 494929.52 716269.04 7.8100000000000005 494930.83 716272.04 7.8100000000000005 494928.86 716272.86 7.8100000000000005 494929.82 716275.07 7.8100000000000005 494921.53 716278.38 7.8100000000000005 494919.3 716273.22 7.8100000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.42</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495234.32 716366.24 3.71 495238.58 716377.04 3.71 495238.42 716377.11 3.71 495243.78 716390.71 3.71 495243.91 716390.67 3.71 495248.79 716402.51 3.71 495258.14 716398.69 3.71 495253.48 716387.13 3.71 495253.67 716387.06 3.71 495248.14 716373.18 3.71 495247.96 716373.25 3.71 495243.7 716362.48 3.71 495234.32 716366.24 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495234.32 716366.24 3.71 495243.7 716362.48 3.71 495243.7 716362.48 8.13 495234.32 716366.24 8.13 495234.32 716366.24 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495243.7 716362.48 3.71 495247.96 716373.25 3.71 495247.96 716373.25 8.13 495243.7 716362.48 8.13 495243.7 716362.48 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495247.96 716373.25 3.71 495248.14 716373.18 3.71 495248.14 716373.18 8.13 495247.96 716373.25 8.13 495247.96 716373.25 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495248.14 716373.18 3.71 495253.67 716387.06 3.71 495253.67 716387.06 8.13 495248.14 716373.18 8.13 495248.14 716373.18 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495253.67 716387.06 3.71 495253.48 716387.13 3.71 495253.48 716387.13 8.13 495253.67 716387.06 8.13 495253.67 716387.06 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495253.48 716387.13 3.71 495258.14 716398.69 3.71 495258.14 716398.69 8.13 495253.48 716387.13 8.13 495253.48 716387.13 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495258.14 716398.69 3.71 495248.79 716402.51 3.71 495248.79 716402.51 8.13 495258.14 716398.69 8.13 495258.14 716398.69 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495248.79 716402.51 3.71 495243.91 716390.67 3.71 495243.91 716390.67 8.13 495248.79 716402.51 8.13 495248.79 716402.51 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495243.91 716390.67 3.71 495243.78 716390.71 3.71 495243.78 716390.71 8.13 495243.91 716390.67 8.13 495243.91 716390.67 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495243.78 716390.71 3.71 495238.42 716377.11 3.71 495238.42 716377.11 8.13 495243.78 716390.71 8.13 495243.78 716390.71 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495238.42 716377.11 3.71 495238.58 716377.04 3.71 495238.58 716377.04 8.13 495238.42 716377.11 8.13 495238.42 716377.11 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495238.58 716377.04 3.71 495234.32 716366.24 3.71 495234.32 716366.24 8.13 495238.58 716377.04 8.13 495238.58 716377.04 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3E18-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495234.32 716366.24 8.13 495243.7 716362.48 8.13 495247.96 716373.25 8.13 495248.14 716373.18 8.13 495253.67 716387.06 8.13 495253.48 716387.13 8.13 495258.14 716398.69 8.13 495248.79 716402.51 8.13 495243.91 716390.67 8.13 495243.78 716390.71 8.13 495238.42 716377.11 8.13 495238.58 716377.04 8.13 495234.32 716366.24 8.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D57B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D57B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.36</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495050.86 715940.51 2.7 495060.37 715946.2 2.7 495072.13 715926.31 2.7 495062.67 715920.57 2.7 495050.86 715940.51 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495050.86 715940.51 2.7 495062.67 715920.57 2.7 495062.67 715920.57 9.06 495050.86 715940.51 9.06 495050.86 715940.51 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495062.67 715920.57 2.7 495072.13 715926.31 2.7 495072.13 715926.31 9.06 495062.67 715920.57 9.06 495062.67 715920.57 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495072.13 715926.31 2.7 495060.37 715946.2 2.7 495060.37 715946.2 9.06 495072.13 715926.31 9.06 495072.13 715926.31 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495060.37 715946.2 2.7 495050.86 715940.51 2.7 495050.86 715940.51 9.06 495060.37 715946.2 9.06 495060.37 715946.2 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D57B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495050.86 715940.51 9.06 495062.67 715920.57 9.06 495072.13 715926.31 9.06 495060.37 715946.2 9.06 495050.86 715940.51 9.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.42</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494691.19 716357.61 2.7 494691.51 716358.72 2.7 494691.24 716358.79 2.7 494691.34 716359.12 2.7 494691.61 716359.06 2.7 494693.61 716365.69 2.7 494699.95 716363.61 2.7 494700.37 716365.32 2.7 494707.87 716362.73 2.7 494707.39 716361.04 2.7 494705.13 716353.42 2.7 494697.57 716355.75 2.7 494691.19 716357.61 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494691.19 716357.61 2.7 494697.57 716355.75 2.7 494697.57 716355.75 6.12 494691.19 716357.61 6.12 494691.19 716357.61 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494697.57 716355.75 2.7 494705.13 716353.42 2.7 494705.13 716353.42 6.12 494697.57 716355.75 6.12 494697.57 716355.75 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494705.13 716353.42 2.7 494707.39 716361.04 2.7 494707.39 716361.04 6.12 494705.13 716353.42 6.12 494705.13 716353.42 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494707.39 716361.04 2.7 494707.87 716362.73 2.7 494707.87 716362.73 6.12 494707.39 716361.04 6.12 494707.39 716361.04 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494707.87 716362.73 2.7 494700.37 716365.32 2.7 494700.37 716365.32 6.12 494707.87 716362.73 6.12 494707.87 716362.73 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494700.37 716365.32 2.7 494699.95 716363.61 2.7 494699.95 716363.61 6.12 494700.37 716365.32 6.12 494700.37 716365.32 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494699.95 716363.61 2.7 494693.61 716365.69 2.7 494693.61 716365.69 6.12 494699.95 716363.61 6.12 494699.95 716363.61 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494693.61 716365.69 2.7 494691.61 716359.06 2.7 494691.61 716359.06 6.12 494693.61 716365.69 6.12 494693.61 716365.69 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494691.61 716359.06 2.7 494691.34 716359.12 2.7 494691.34 716359.12 6.12 494691.61 716359.06 6.12 494691.61 716359.06 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494691.34 716359.12 2.7 494691.24 716358.79 2.7 494691.24 716358.79 6.12 494691.34 716359.12 6.12 494691.34 716359.12 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494691.24 716358.79 2.7 494691.51 716358.72 2.7 494691.51 716358.72 6.12 494691.24 716358.79 6.12 494691.24 716358.79 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494691.51 716358.72 2.7 494691.19 716357.61 2.7 494691.19 716357.61 6.12 494691.51 716358.72 6.12 494691.51 716358.72 2.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CD-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494691.19 716357.61 6.12 494697.57 716355.75 6.12 494705.13 716353.42 6.12 494707.39 716361.04 6.12 494707.87 716362.73 6.12 494700.37 716365.32 6.12 494699.95 716363.61 6.12 494693.61 716365.69 6.12 494691.61 716359.06 6.12 494691.34 716359.12 6.12 494691.24 716358.79 6.12 494691.51 716358.72 6.12 494691.19 716357.61 6.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-013C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-013C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.66</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-013C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494634.41 716377.17 4.31 494641.08 716374.65 4.31 494641.8 716376.57 4.31 494645.14 716375.26 4.31 494644.45 716373.4 4.31 494650.34 716371.19 4.31 494646.99 716362.34 4.31 494631.07 716368.34 4.31 494634.41 716377.17 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-013C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494634.41 716377.17 4.31 494631.07 716368.34 4.31 494631.07 716368.34 9.97 494634.41 716377.17 9.97 494634.41 716377.17 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-013C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494631.07 716368.34 4.31 494646.99 716362.34 4.31 494646.99 716362.34 9.97 494631.07 716368.34 9.97 494631.07 716368.34 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-013C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494646.99 716362.34 4.31 494650.34 716371.19 4.31 494650.34 716371.19 9.97 494646.99 716362.34 9.97 494646.99 716362.34 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-013C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494650.34 716371.19 4.31 494644.45 716373.4 4.31 494644.45 716373.4 9.97 494650.34 716371.19 9.97 494650.34 716371.19 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-013C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494644.45 716373.4 4.31 494645.14 716375.26 4.31 494645.14 716375.26 9.97 494644.45 716373.4 9.97 494644.45 716373.4 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-013C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494645.14 716375.26 4.31 494641.8 716376.57 4.31 494641.8 716376.57 9.97 494645.14 716375.26 9.97 494645.14 716375.26 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-013C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494641.8 716376.57 4.31 494641.08 716374.65 4.31 494641.08 716374.65 9.97 494641.8 716376.57 9.97 494641.8 716376.57 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-013C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494641.08 716374.65 4.31 494634.41 716377.17 4.31 494634.41 716377.17 9.97 494641.08 716374.65 9.97 494641.08 716374.65 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-013C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494634.41 716377.17 9.97 494631.07 716368.34 9.97 494646.99 716362.34 9.97 494650.34 716371.19 9.97 494644.45 716373.4 9.97 494645.14 716375.26 9.97 494641.8 716376.57 9.97 494641.08 716374.65 9.97 494634.41 716377.17 9.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D644-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.01</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495229.29 716354.04 3.86 495230.26 716356.45 3.86 495232.26 716361.39 3.86 495237.26 716359.37 3.86 495236.31 716357.03 3.86 495237.28 716356.63 3.86 495237.51 716356.11 3.86 495236.81 716354.39 3.86 495237.36 716353.41 3.86 495236.11 716350.29 3.86 495235.24 716349.81 3.86 495233.1 716350.67 3.86 495232.93 716350.25 3.86 495231.97 716349.83 3.86 495230.49 716350.44 3.86 495230.15 716351.37 3.86 495230.96 716353.37 3.86 495229.29 716354.04 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495229.29 716354.04 3.86 495230.96 716353.37 3.86 495230.96 716353.37 10.870000000000001 495229.29 716354.04 10.870000000000001 495229.29 716354.04 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495230.96 716353.37 3.86 495230.15 716351.37 3.86 495230.15 716351.37 10.870000000000001 495230.96 716353.37 10.870000000000001 495230.96 716353.37 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495230.15 716351.37 3.86 495230.49 716350.44 3.86 495230.49 716350.44 10.870000000000001 495230.15 716351.37 10.870000000000001 495230.15 716351.37 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495230.49 716350.44 3.86 495231.97 716349.83 3.86 495231.97 716349.83 10.870000000000001 495230.49 716350.44 10.870000000000001 495230.49 716350.44 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495231.97 716349.83 3.86 495232.93 716350.25 3.86 495232.93 716350.25 10.870000000000001 495231.97 716349.83 10.870000000000001 495231.97 716349.83 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495232.93 716350.25 3.86 495233.1 716350.67 3.86 495233.1 716350.67 10.870000000000001 495232.93 716350.25 10.870000000000001 495232.93 716350.25 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495233.1 716350.67 3.86 495235.24 716349.81 3.86 495235.24 716349.81 10.870000000000001 495233.1 716350.67 10.870000000000001 495233.1 716350.67 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495235.24 716349.81 3.86 495236.11 716350.29 3.86 495236.11 716350.29 10.870000000000001 495235.24 716349.81 10.870000000000001 495235.24 716349.81 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495236.11 716350.29 3.86 495237.36 716353.41 3.86 495237.36 716353.41 10.870000000000001 495236.11 716350.29 10.870000000000001 495236.11 716350.29 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495237.36 716353.41 3.86 495236.81 716354.39 3.86 495236.81 716354.39 10.870000000000001 495237.36 716353.41 10.870000000000001 495237.36 716353.41 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495236.81 716354.39 3.86 495237.51 716356.11 3.86 495237.51 716356.11 10.870000000000001 495236.81 716354.39 10.870000000000001 495236.81 716354.39 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495237.51 716356.11 3.86 495237.28 716356.63 3.86 495237.28 716356.63 10.870000000000001 495237.51 716356.11 10.870000000000001 495237.51 716356.11 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495237.28 716356.63 3.86 495236.31 716357.03 3.86 495236.31 716357.03 10.870000000000001 495237.28 716356.63 10.870000000000001 495237.28 716356.63 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495236.31 716357.03 3.86 495237.26 716359.37 3.86 495237.26 716359.37 10.870000000000001 495236.31 716357.03 10.870000000000001 495236.31 716357.03 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495237.26 716359.37 3.86 495232.26 716361.39 3.86 495232.26 716361.39 10.870000000000001 495237.26 716359.37 10.870000000000001 495237.26 716359.37 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495232.26 716361.39 3.86 495230.26 716356.45 3.86 495230.26 716356.45 10.870000000000001 495232.26 716361.39 10.870000000000001 495232.26 716361.39 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495230.26 716356.45 3.86 495229.29 716354.04 3.86 495229.29 716354.04 10.870000000000001 495230.26 716356.45 10.870000000000001 495230.26 716356.45 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D644-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495229.29 716354.04 10.870000000000001 495230.96 716353.37 10.870000000000001 495230.15 716351.37 10.870000000000001 495230.49 716350.44 10.870000000000001 495231.97 716349.83 10.870000000000001 495232.93 716350.25 10.870000000000001 495233.1 716350.67 10.870000000000001 495235.24 716349.81 10.870000000000001 495236.11 716350.29 10.870000000000001 495237.36 716353.41 10.870000000000001 495236.81 716354.39 10.870000000000001 495237.51 716356.11 10.870000000000001 495237.28 716356.63 10.870000000000001 495236.31 716357.03 10.870000000000001 495237.26 716359.37 10.870000000000001 495232.26 716361.39 10.870000000000001 495230.26 716356.45 10.870000000000001 495229.29 716354.04 10.870000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5CEB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5CEB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5CEB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494784.59 716315.56 3.93 494785.5 716317.82 3.93 494786.38 716320.01 3.93 494786.88 716319.82 3.93 494795.05 716316.53 3.93 494793.18 716312.11 3.93 494784.59 716315.56 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5CEB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494784.59 716315.56 3.93 494793.18 716312.11 3.93 494793.18 716312.11 7.5600000000000005 494784.59 716315.56 7.5600000000000005 494784.59 716315.56 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5CEB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494793.18 716312.11 3.93 494795.05 716316.53 3.93 494795.05 716316.53 7.5600000000000005 494793.18 716312.11 7.5600000000000005 494793.18 716312.11 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5CEB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494795.05 716316.53 3.93 494786.88 716319.82 3.93 494786.88 716319.82 7.5600000000000005 494795.05 716316.53 7.5600000000000005 494795.05 716316.53 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5CEB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494786.88 716319.82 3.93 494786.38 716320.01 3.93 494786.38 716320.01 7.5600000000000005 494786.88 716319.82 7.5600000000000005 494786.88 716319.82 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5CEB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494786.38 716320.01 3.93 494785.5 716317.82 3.93 494785.5 716317.82 7.5600000000000005 494786.38 716320.01 7.5600000000000005 494786.38 716320.01 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5CEB-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494785.5 716317.82 3.93 494784.59 716315.56 3.93 494784.59 716315.56 7.5600000000000005 494785.5 716317.82 7.5600000000000005 494785.5 716317.82 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5CEB-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494784.59 716315.56 7.5600000000000005 494793.18 716312.11 7.5600000000000005 494795.05 716316.53 7.5600000000000005 494786.88 716319.82 7.5600000000000005 494786.38 716320.01 7.5600000000000005 494785.5 716317.82 7.5600000000000005 494784.59 716315.56 7.5600000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-046A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-046A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494855.07 716277.92 3.87 494858.49 716286.16 3.87 494865 716283.45 3.87 494861.56 716275.15 3.87 494860.92 716275.41 3.87 494859.73 716272.62 3.87 494856.98 716273.81 3.87 494856.7 716274.84 3.87 494857.6 716276.85 3.87 494855.07 716277.92 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494855.07 716277.92 3.87 494857.6 716276.85 3.87 494857.6 716276.85 8.335 494855.07 716277.92 8.335 494855.07 716277.92 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494857.6 716276.85 3.87 494856.7 716274.84 3.87 494856.7 716274.84 8.335 494857.6 716276.85 8.335 494857.6 716276.85 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494856.7 716274.84 3.87 494856.98 716273.81 3.87 494856.98 716273.81 8.335 494856.7 716274.84 8.335 494856.7 716274.84 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494856.98 716273.81 3.87 494859.73 716272.62 3.87 494859.73 716272.62 8.335 494856.98 716273.81 8.335 494856.98 716273.81 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494859.73 716272.62 3.87 494860.92 716275.41 3.87 494860.92 716275.41 8.335 494859.73 716272.62 8.335 494859.73 716272.62 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494860.92 716275.41 3.87 494861.56 716275.15 3.87 494861.56 716275.15 8.335 494860.92 716275.41 8.335 494860.92 716275.41 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494861.56 716275.15 3.87 494865 716283.45 3.87 494865 716283.45 8.335 494861.56 716275.15 8.335 494861.56 716275.15 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494865 716283.45 3.87 494858.49 716286.16 3.87 494858.49 716286.16 8.335 494865 716283.45 8.335 494865 716283.45 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494858.49 716286.16 3.87 494855.07 716277.92 3.87 494855.07 716277.92 8.335 494858.49 716286.16 8.335 494858.49 716286.16 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-046A-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494855.07 716277.92 8.335 494857.6 716276.85 8.335 494856.7 716274.84 8.335 494856.98 716273.81 8.335 494859.73 716272.62 8.335 494860.92 716275.41 8.335 494861.56 716275.15 8.335 494865 716283.45 8.335 494858.49 716286.16 8.335 494855.07 716277.92 8.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0469-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0469-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.76</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0469-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494856.85 715609.48 5.23 494864.54 715612.14 5.23 494868.89 715599.57 5.23 494861.2 715596.91 5.23 494856.85 715609.48 5.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0469-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494856.85 715609.48 5.23 494861.2 715596.91 5.23 494861.2 715596.91 10.99 494856.85 715609.48 10.99 494856.85 715609.48 5.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0469-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494861.2 715596.91 5.23 494868.89 715599.57 5.23 494868.89 715599.57 10.99 494861.2 715596.91 10.99 494861.2 715596.91 5.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0469-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494868.89 715599.57 5.23 494864.54 715612.14 5.23 494864.54 715612.14 10.99 494868.89 715599.57 10.99 494868.89 715599.57 5.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0469-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494864.54 715612.14 5.23 494856.85 715609.48 5.23 494856.85 715609.48 10.99 494864.54 715612.14 10.99 494864.54 715612.14 5.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0469-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494856.85 715609.48 10.99 494861.2 715596.91 10.99 494868.89 715599.57 10.99 494864.54 715612.14 10.99 494856.85 715609.48 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.91</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494649.74 716378.72 3.96 494650.74 716381.47 3.96 494654.57 716391.93 3.96 494661.68 716389.47 3.96 494660.13 716385.12 3.96 494659.16 716382.4 3.96 494657.88 716378.81 3.96 494655.13 716379.8 3.96 494654.21 716377.17 3.96 494649.74 716378.72 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494649.74 716378.72 3.96 494654.21 716377.17 3.96 494654.21 716377.17 9.870000000000001 494649.74 716378.72 9.870000000000001 494649.74 716378.72 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494654.21 716377.17 3.96 494655.13 716379.8 3.96 494655.13 716379.8 9.870000000000001 494654.21 716377.17 9.870000000000001 494654.21 716377.17 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494655.13 716379.8 3.96 494657.88 716378.81 3.96 494657.88 716378.81 9.870000000000001 494655.13 716379.8 9.870000000000001 494655.13 716379.8 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494657.88 716378.81 3.96 494659.16 716382.4 3.96 494659.16 716382.4 9.870000000000001 494657.88 716378.81 9.870000000000001 494657.88 716378.81 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494659.16 716382.4 3.96 494660.13 716385.12 3.96 494660.13 716385.12 9.870000000000001 494659.16 716382.4 9.870000000000001 494659.16 716382.4 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494660.13 716385.12 3.96 494661.68 716389.47 3.96 494661.68 716389.47 9.870000000000001 494660.13 716385.12 9.870000000000001 494660.13 716385.12 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494661.68 716389.47 3.96 494654.57 716391.93 3.96 494654.57 716391.93 9.870000000000001 494661.68 716389.47 9.870000000000001 494661.68 716389.47 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494654.57 716391.93 3.96 494650.74 716381.47 3.96 494650.74 716381.47 9.870000000000001 494654.57 716391.93 9.870000000000001 494654.57 716391.93 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494650.74 716381.47 3.96 494649.74 716378.72 3.96 494649.74 716378.72 9.870000000000001 494650.74 716381.47 9.870000000000001 494650.74 716381.47 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02CD-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494649.74 716378.72 9.870000000000001 494654.21 716377.17 9.870000000000001 494655.13 716379.8 9.870000000000001 494657.88 716378.81 9.870000000000001 494659.16 716382.4 9.870000000000001 494660.13 716385.12 9.870000000000001 494661.68 716389.47 9.870000000000001 494654.57 716391.93 9.870000000000001 494650.74 716381.47 9.870000000000001 494649.74 716378.72 9.870000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D648-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D648-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.14</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D648-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495248.48 716402.69 3.56 495253.13 716414.21 3.56 495267.51 716408.35 3.56 495262.7 716396.79 3.56 495258.14 716398.69 3.56 495248.79 716402.51 3.56 495248.48 716402.69 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D648-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495248.48 716402.69 3.56 495248.79 716402.51 3.56 495248.79 716402.51 8.700000000000001 495248.48 716402.69 8.700000000000001 495248.48 716402.69 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D648-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495248.79 716402.51 3.56 495258.14 716398.69 3.56 495258.14 716398.69 8.700000000000001 495248.79 716402.51 8.700000000000001 495248.79 716402.51 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D648-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495258.14 716398.69 3.56 495262.7 716396.79 3.56 495262.7 716396.79 8.700000000000001 495258.14 716398.69 8.700000000000001 495258.14 716398.69 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D648-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495262.7 716396.79 3.56 495267.51 716408.35 3.56 495267.51 716408.35 8.700000000000001 495262.7 716396.79 8.700000000000001 495262.7 716396.79 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D648-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495267.51 716408.35 3.56 495253.13 716414.21 3.56 495253.13 716414.21 8.700000000000001 495267.51 716408.35 8.700000000000001 495267.51 716408.35 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D648-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495253.13 716414.21 3.56 495248.48 716402.69 3.56 495248.48 716402.69 8.700000000000001 495253.13 716414.21 8.700000000000001 495253.13 716414.21 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D648-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495248.48 716402.69 8.700000000000001 495248.79 716402.51 8.700000000000001 495258.14 716398.69 8.700000000000001 495262.7 716396.79 8.700000000000001 495267.51 716408.35 8.700000000000001 495253.13 716414.21 8.700000000000001 495248.48 716402.69 8.700000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-645B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.74</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494820.51 716293.04 2.95 494822.98 716299.53 2.95 494824.98 716298.75 2.95 494826.15 716301.83 2.95 494833.22 716299.19 2.95 494832.04 716296.06 2.95 494829.54 716289.56 2.95 494827.7 716284.78 2.95 494822.96 716286.58 2.95 494823.2 716287.23 2.95 494818.93 716288.9 2.95 494820.51 716293.04 2.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494820.51 716293.04 2.95 494818.93 716288.9 2.95 494818.93 716288.9 7.69 494820.51 716293.04 7.69 494820.51 716293.04 2.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494818.93 716288.9 2.95 494823.2 716287.23 2.95 494823.2 716287.23 7.69 494818.93 716288.9 7.69 494818.93 716288.9 2.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494823.2 716287.23 2.95 494822.96 716286.58 2.95 494822.96 716286.58 7.69 494823.2 716287.23 7.69 494823.2 716287.23 2.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494822.96 716286.58 2.95 494827.7 716284.78 2.95 494827.7 716284.78 7.69 494822.96 716286.58 7.69 494822.96 716286.58 2.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494827.7 716284.78 2.95 494829.54 716289.56 2.95 494829.54 716289.56 7.69 494827.7 716284.78 7.69 494827.7 716284.78 2.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494829.54 716289.56 2.95 494832.04 716296.06 2.95 494832.04 716296.06 7.69 494829.54 716289.56 7.69 494829.54 716289.56 2.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494832.04 716296.06 2.95 494833.22 716299.19 2.95 494833.22 716299.19 7.69 494832.04 716296.06 7.69 494832.04 716296.06 2.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494833.22 716299.19 2.95 494826.15 716301.83 2.95 494826.15 716301.83 7.69 494833.22 716299.19 7.69 494833.22 716299.19 2.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494826.15 716301.83 2.95 494824.98 716298.75 2.95 494824.98 716298.75 7.69 494826.15 716301.83 7.69 494826.15 716301.83 2.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494824.98 716298.75 2.95 494822.98 716299.53 2.95 494822.98 716299.53 7.69 494824.98 716298.75 7.69 494824.98 716298.75 2.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494822.98 716299.53 2.95 494820.51 716293.04 2.95 494820.51 716293.04 7.69 494822.98 716299.53 7.69 494822.98 716299.53 2.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645B-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494820.51 716293.04 7.69 494818.93 716288.9 7.69 494823.2 716287.23 7.69 494822.96 716286.58 7.69 494827.7 716284.78 7.69 494829.54 716289.56 7.69 494832.04 716296.06 7.69 494833.22 716299.19 7.69 494826.15 716301.83 7.69 494824.98 716298.75 7.69 494822.98 716299.53 7.69 494820.51 716293.04 7.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0076-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494447.58 716423.69 2.1 494451.92 716429.95 2.1 494452.35 716429.66 2.1 494453.91 716431.96 2.1 494460.12 716427.73 2.1 494458.63 716425.44 2.1 494462.8 716422.63 2.1 494458.47 716416.38 2.1 494455.66 716418.21 2.1 494454.34 716416.33 2.1 494449.97 716419.24 2.1 494451.22 716421.17 2.1 494447.58 716423.69 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494447.58 716423.69 2.1 494451.22 716421.17 2.1 494451.22 716421.17 7.1 494447.58 716423.69 7.1 494447.58 716423.69 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494451.22 716421.17 2.1 494449.97 716419.24 2.1 494449.97 716419.24 7.1 494451.22 716421.17 7.1 494451.22 716421.17 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494449.97 716419.24 2.1 494454.34 716416.33 2.1 494454.34 716416.33 7.1 494449.97 716419.24 7.1 494449.97 716419.24 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494454.34 716416.33 2.1 494455.66 716418.21 2.1 494455.66 716418.21 7.1 494454.34 716416.33 7.1 494454.34 716416.33 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494455.66 716418.21 2.1 494458.47 716416.38 2.1 494458.47 716416.38 7.1 494455.66 716418.21 7.1 494455.66 716418.21 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494458.47 716416.38 2.1 494462.8 716422.63 2.1 494462.8 716422.63 7.1 494458.47 716416.38 7.1 494458.47 716416.38 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494462.8 716422.63 2.1 494458.63 716425.44 2.1 494458.63 716425.44 7.1 494462.8 716422.63 7.1 494462.8 716422.63 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494458.63 716425.44 2.1 494460.12 716427.73 2.1 494460.12 716427.73 7.1 494458.63 716425.44 7.1 494458.63 716425.44 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494460.12 716427.73 2.1 494453.91 716431.96 2.1 494453.91 716431.96 7.1 494460.12 716427.73 7.1 494460.12 716427.73 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494453.91 716431.96 2.1 494452.35 716429.66 2.1 494452.35 716429.66 7.1 494453.91 716431.96 7.1 494453.91 716431.96 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494452.35 716429.66 2.1 494451.92 716429.95 2.1 494451.92 716429.95 7.1 494452.35 716429.66 7.1 494452.35 716429.66 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494451.92 716429.95 2.1 494447.58 716423.69 2.1 494447.58 716423.69 7.1 494451.92 716429.95 7.1 494451.92 716429.95 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0076-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494447.58 716423.69 7.1 494451.22 716421.17 7.1 494449.97 716419.24 7.1 494454.34 716416.33 7.1 494455.66 716418.21 7.1 494458.47 716416.38 7.1 494462.8 716422.63 7.1 494458.63 716425.44 7.1 494460.12 716427.73 7.1 494453.91 716431.96 7.1 494452.35 716429.66 7.1 494451.92 716429.95 7.1 494447.58 716423.69 7.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CAD8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CAD8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.13</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CAD8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494654.56 716351.97 3.69 494658.15 716361.08 3.69 494667.35 716357.61 3.69 494663.76 716348.53 3.69 494654.56 716351.97 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CAD8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494654.56 716351.97 3.69 494663.76 716348.53 3.69 494663.76 716348.53 7.82 494654.56 716351.97 7.82 494654.56 716351.97 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CAD8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494663.76 716348.53 3.69 494667.35 716357.61 3.69 494667.35 716357.61 7.82 494663.76 716348.53 7.82 494663.76 716348.53 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CAD8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494667.35 716357.61 3.69 494658.15 716361.08 3.69 494658.15 716361.08 7.82 494667.35 716357.61 7.82 494667.35 716357.61 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CAD8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494658.15 716361.08 3.69 494654.56 716351.97 3.69 494654.56 716351.97 7.82 494658.15 716361.08 7.82 494658.15 716361.08 3.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CAD8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494654.56 716351.97 7.82 494663.76 716348.53 7.82 494667.35 716357.61 7.82 494658.15 716361.08 7.82 494654.56 716351.97 7.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-75B6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-75B6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.23</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75B6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494443.47 716439.65 2.37 494446.13 716442.66 2.37 494451.39 716438.09 2.37 494448.75 716435.08 2.37 494443.47 716439.65 2.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75B6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494443.47 716439.65 2.37 494448.75 716435.08 2.37 494448.75 716435.08 5.6000000000000005 494443.47 716439.65 5.6000000000000005 494443.47 716439.65 2.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75B6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494448.75 716435.08 2.37 494451.39 716438.09 2.37 494451.39 716438.09 5.6000000000000005 494448.75 716435.08 5.6000000000000005 494448.75 716435.08 2.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75B6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494451.39 716438.09 2.37 494446.13 716442.66 2.37 494446.13 716442.66 5.6000000000000005 494451.39 716438.09 5.6000000000000005 494451.39 716438.09 2.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75B6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494446.13 716442.66 2.37 494443.47 716439.65 2.37 494443.47 716439.65 5.6000000000000005 494446.13 716442.66 5.6000000000000005 494446.13 716442.66 2.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75B6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494443.47 716439.65 5.6000000000000005 494448.75 716435.08 5.6000000000000005 494451.39 716438.09 5.6000000000000005 494446.13 716442.66 5.6000000000000005 494443.47 716439.65 5.6000000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-053D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.03</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495026.51 715984.27 3.4 495026.69 715984.42 3.4 495027.07 715983.98 3.4 495036.91 715992.55 3.4 495043.43 715984.86 3.4 495040.82 715982.83 3.4 495042.77 715980.44 3.4 495035.33 715974.16 3.4 495033.63 715976.18 3.4 495026.89 715983.83 3.4 495026.51 715984.27 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495026.51 715984.27 3.4 495026.89 715983.83 3.4 495026.89 715983.83 9.43 495026.51 715984.27 9.43 495026.51 715984.27 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495026.89 715983.83 3.4 495033.63 715976.18 3.4 495033.63 715976.18 9.43 495026.89 715983.83 9.43 495026.89 715983.83 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495033.63 715976.18 3.4 495035.33 715974.16 3.4 495035.33 715974.16 9.43 495033.63 715976.18 9.43 495033.63 715976.18 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495035.33 715974.16 3.4 495042.77 715980.44 3.4 495042.77 715980.44 9.43 495035.33 715974.16 9.43 495035.33 715974.16 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495042.77 715980.44 3.4 495040.82 715982.83 3.4 495040.82 715982.83 9.43 495042.77 715980.44 9.43 495042.77 715980.44 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495040.82 715982.83 3.4 495043.43 715984.86 3.4 495043.43 715984.86 9.43 495040.82 715982.83 9.43 495040.82 715982.83 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495043.43 715984.86 3.4 495036.91 715992.55 3.4 495036.91 715992.55 9.43 495043.43 715984.86 9.43 495043.43 715984.86 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495036.91 715992.55 3.4 495027.07 715983.98 3.4 495027.07 715983.98 9.43 495036.91 715992.55 9.43 495036.91 715992.55 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495027.07 715983.98 3.4 495026.69 715984.42 3.4 495026.69 715984.42 9.43 495027.07 715983.98 9.43 495027.07 715983.98 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495026.69 715984.42 3.4 495026.51 715984.27 3.4 495026.51 715984.27 9.43 495026.69 715984.42 9.43 495026.69 715984.42 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053D-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495026.51 715984.27 9.43 495026.89 715983.83 9.43 495033.63 715976.18 9.43 495035.33 715974.16 9.43 495042.77 715980.44 9.43 495040.82 715982.83 9.43 495043.43 715984.86 9.43 495036.91 715992.55 9.43 495027.07 715983.98 9.43 495026.69 715984.42 9.43 495026.51 715984.27 9.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-053A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494969.45 715104.94 4.73 494960.52 715105.16 4.73 494960.86 715111.15 4.73 494958.85 715111.26 4.73 494958.94 715114.28 4.73 494960.98 715114.14 4.73 494960.98 715114.68 4.73 494960.31 715114.73 4.73 494960.32 715114.99 4.73 494960.86 715114.98 4.73 494969.72 715114.76 4.73 494970.35 715114.77 4.73 494970.33 715114.5 4.73 494969.81 715114.49 4.73 494969.45 715104.94 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494969.45 715104.94 4.73 494969.81 715114.49 4.73 494969.81 715114.49 10.28 494969.45 715104.94 10.28 494969.45 715104.94 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494969.81 715114.49 4.73 494970.33 715114.5 4.73 494970.33 715114.5 10.28 494969.81 715114.49 10.28 494969.81 715114.49 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494970.33 715114.5 4.73 494970.35 715114.77 4.73 494970.35 715114.77 10.28 494970.33 715114.5 10.28 494970.33 715114.5 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494970.35 715114.77 4.73 494969.72 715114.76 4.73 494969.72 715114.76 10.28 494970.35 715114.77 10.28 494970.35 715114.77 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494969.72 715114.76 4.73 494960.86 715114.98 4.73 494960.86 715114.98 10.28 494969.72 715114.76 10.28 494969.72 715114.76 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494960.86 715114.98 4.73 494960.32 715114.99 4.73 494960.32 715114.99 10.28 494960.86 715114.98 10.28 494960.86 715114.98 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494960.32 715114.99 4.73 494960.31 715114.73 4.73 494960.31 715114.73 10.28 494960.32 715114.99 10.28 494960.32 715114.99 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494960.31 715114.73 4.73 494960.98 715114.68 4.73 494960.98 715114.68 10.28 494960.31 715114.73 10.28 494960.31 715114.73 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494960.98 715114.68 4.73 494960.98 715114.14 4.73 494960.98 715114.14 10.28 494960.98 715114.68 10.28 494960.98 715114.68 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494960.98 715114.14 4.73 494958.94 715114.28 4.73 494958.94 715114.28 10.28 494960.98 715114.14 10.28 494960.98 715114.14 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494958.94 715114.28 4.73 494958.85 715111.26 4.73 494958.85 715111.26 10.28 494958.94 715114.28 10.28 494958.94 715114.28 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494958.85 715111.26 4.73 494960.86 715111.15 4.73 494960.86 715111.15 10.28 494958.85 715111.26 10.28 494958.85 715111.26 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494960.86 715111.15 4.73 494960.52 715105.16 4.73 494960.52 715105.16 10.28 494960.86 715111.15 10.28 494960.86 715111.15 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494960.52 715105.16 4.73 494969.45 715104.94 4.73 494969.45 715104.94 10.28 494960.52 715105.16 10.28 494960.52 715105.16 4.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-053A-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494969.45 715104.94 10.28 494969.81 715114.49 10.28 494970.33 715114.5 10.28 494970.35 715114.77 10.28 494969.72 715114.76 10.28 494960.86 715114.98 10.28 494960.32 715114.99 10.28 494960.31 715114.73 10.28 494960.98 715114.68 10.28 494960.98 715114.14 10.28 494958.94 715114.28 10.28 494958.85 715111.26 10.28 494960.86 715111.15 10.28 494960.52 715105.16 10.28 494969.45 715104.94 10.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0537-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.93</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494927.76 715899.17 3.4 494941.94 715912.24 3.4 494947.21 715906.41 3.4 494947.56 715906.68 3.4 494950 715904.04 3.4 494945.93 715900.24 3.4 494945.64 715900.56 3.4 494942.22 715897.57 3.4 494942.13 715897.65 3.4 494938.73 715894.51 3.4 494938.83 715894.41 3.4 494935.07 715890.96 3.4 494932.95 715893.25 3.4 494933.11 715893.38 3.4 494927.76 715899.17 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494927.76 715899.17 3.4 494933.11 715893.38 3.4 494933.11 715893.38 7.33 494927.76 715899.17 7.33 494927.76 715899.17 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494933.11 715893.38 3.4 494932.95 715893.25 3.4 494932.95 715893.25 7.33 494933.11 715893.38 7.33 494933.11 715893.38 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494932.95 715893.25 3.4 494935.07 715890.96 3.4 494935.07 715890.96 7.33 494932.95 715893.25 7.33 494932.95 715893.25 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494935.07 715890.96 3.4 494938.83 715894.41 3.4 494938.83 715894.41 7.33 494935.07 715890.96 7.33 494935.07 715890.96 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494938.83 715894.41 3.4 494938.73 715894.51 3.4 494938.73 715894.51 7.33 494938.83 715894.41 7.33 494938.83 715894.41 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494938.73 715894.51 3.4 494942.13 715897.65 3.4 494942.13 715897.65 7.33 494938.73 715894.51 7.33 494938.73 715894.51 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494942.13 715897.65 3.4 494942.22 715897.57 3.4 494942.22 715897.57 7.33 494942.13 715897.65 7.33 494942.13 715897.65 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494942.22 715897.57 3.4 494945.64 715900.56 3.4 494945.64 715900.56 7.33 494942.22 715897.57 7.33 494942.22 715897.57 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494945.64 715900.56 3.4 494945.93 715900.24 3.4 494945.93 715900.24 7.33 494945.64 715900.56 7.33 494945.64 715900.56 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494945.93 715900.24 3.4 494950 715904.04 3.4 494950 715904.04 7.33 494945.93 715900.24 7.33 494945.93 715900.24 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494950 715904.04 3.4 494947.56 715906.68 3.4 494947.56 715906.68 7.33 494950 715904.04 7.33 494950 715904.04 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494947.56 715906.68 3.4 494947.21 715906.41 3.4 494947.21 715906.41 7.33 494947.56 715906.68 7.33 494947.56 715906.68 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494947.21 715906.41 3.4 494941.94 715912.24 3.4 494941.94 715912.24 7.33 494947.21 715906.41 7.33 494947.21 715906.41 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494941.94 715912.24 3.4 494927.76 715899.17 3.4 494927.76 715899.17 7.33 494941.94 715912.24 7.33 494941.94 715912.24 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0537-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494927.76 715899.17 7.33 494933.11 715893.38 7.33 494932.95 715893.25 7.33 494935.07 715890.96 7.33 494938.83 715894.41 7.33 494938.73 715894.51 7.33 494942.13 715897.65 7.33 494942.22 715897.57 7.33 494945.64 715900.56 7.33 494945.93 715900.24 7.33 494950 715904.04 7.33 494947.56 715906.68 7.33 494947.21 715906.41 7.33 494941.94 715912.24 7.33 494927.76 715899.17 7.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0538-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494937.84 715339.95 3.81 494939.94 715340.46 3.81 494939.01 715345.21 3.81 494939.25 715345.25 3.81 494939.35 715344.8 3.81 494947.5 715346.28 3.81 494947.41 715346.7 3.81 494947.72 715346.77 3.81 494948.11 715344.73 3.81 494951.18 715345.25 3.81 494952.11 715340.21 3.81 494948.97 715339.63 3.81 494950.08 715333.24 3.81 494941.46 715331.7 3.81 494940.49 715337.19 3.81 494938.45 715336.75 3.81 494937.84 715339.95 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494937.84 715339.95 3.81 494938.45 715336.75 3.81 494938.45 715336.75 8.36 494937.84 715339.95 8.36 494937.84 715339.95 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494938.45 715336.75 3.81 494940.49 715337.19 3.81 494940.49 715337.19 8.36 494938.45 715336.75 8.36 494938.45 715336.75 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494940.49 715337.19 3.81 494941.46 715331.7 3.81 494941.46 715331.7 8.36 494940.49 715337.19 8.36 494940.49 715337.19 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494941.46 715331.7 3.81 494950.08 715333.24 3.81 494950.08 715333.24 8.36 494941.46 715331.7 8.36 494941.46 715331.7 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494950.08 715333.24 3.81 494948.97 715339.63 3.81 494948.97 715339.63 8.36 494950.08 715333.24 8.36 494950.08 715333.24 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494948.97 715339.63 3.81 494952.11 715340.21 3.81 494952.11 715340.21 8.36 494948.97 715339.63 8.36 494948.97 715339.63 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494952.11 715340.21 3.81 494951.18 715345.25 3.81 494951.18 715345.25 8.36 494952.11 715340.21 8.36 494952.11 715340.21 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494951.18 715345.25 3.81 494948.11 715344.73 3.81 494948.11 715344.73 8.36 494951.18 715345.25 8.36 494951.18 715345.25 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494948.11 715344.73 3.81 494947.72 715346.77 3.81 494947.72 715346.77 8.36 494948.11 715344.73 8.36 494948.11 715344.73 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494947.72 715346.77 3.81 494947.41 715346.7 3.81 494947.41 715346.7 8.36 494947.72 715346.77 8.36 494947.72 715346.77 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494947.41 715346.7 3.81 494947.5 715346.28 3.81 494947.5 715346.28 8.36 494947.41 715346.7 8.36 494947.41 715346.7 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494947.5 715346.28 3.81 494939.35 715344.8 3.81 494939.35 715344.8 8.36 494947.5 715346.28 8.36 494947.5 715346.28 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494939.35 715344.8 3.81 494939.25 715345.25 3.81 494939.25 715345.25 8.36 494939.35 715344.8 8.36 494939.35 715344.8 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494939.25 715345.25 3.81 494939.01 715345.21 3.81 494939.01 715345.21 8.36 494939.25 715345.25 8.36 494939.25 715345.25 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494939.01 715345.21 3.81 494939.94 715340.46 3.81 494939.94 715340.46 8.36 494939.01 715345.21 8.36 494939.01 715345.21 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494939.94 715340.46 3.81 494937.84 715339.95 3.81 494937.84 715339.95 8.36 494939.94 715340.46 8.36 494939.94 715340.46 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0538-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494937.84 715339.95 8.36 494938.45 715336.75 8.36 494940.49 715337.19 8.36 494941.46 715331.7 8.36 494950.08 715333.24 8.36 494948.97 715339.63 8.36 494952.11 715340.21 8.36 494951.18 715345.25 8.36 494948.11 715344.73 8.36 494947.72 715346.77 8.36 494947.41 715346.7 8.36 494947.5 715346.28 8.36 494939.35 715344.8 8.36 494939.25 715345.25 8.36 494939.01 715345.21 8.36 494939.94 715340.46 8.36 494937.84 715339.95 8.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-039F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.7</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494778.78 716301.27 3.92 494782.4 716310.18 3.92 494784.15 716314.16 3.92 494787.12 716312.95 3.92 494786.59 716311.66 3.92 494791.81 716309.49 3.92 494790.76 716306.84 3.92 494786.28 716295.53 3.92 494781.74 716297.3 3.92 494782.77 716299.67 3.92 494778.78 716301.27 3.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494778.78 716301.27 3.92 494782.77 716299.67 3.92 494782.77 716299.67 7.62 494778.78 716301.27 7.62 494778.78 716301.27 3.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494782.77 716299.67 3.92 494781.74 716297.3 3.92 494781.74 716297.3 7.62 494782.77 716299.67 7.62 494782.77 716299.67 3.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494781.74 716297.3 3.92 494786.28 716295.53 3.92 494786.28 716295.53 7.62 494781.74 716297.3 7.62 494781.74 716297.3 3.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494786.28 716295.53 3.92 494790.76 716306.84 3.92 494790.76 716306.84 7.62 494786.28 716295.53 7.62 494786.28 716295.53 3.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494790.76 716306.84 3.92 494791.81 716309.49 3.92 494791.81 716309.49 7.62 494790.76 716306.84 7.62 494790.76 716306.84 3.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494791.81 716309.49 3.92 494786.59 716311.66 3.92 494786.59 716311.66 7.62 494791.81 716309.49 7.62 494791.81 716309.49 3.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494786.59 716311.66 3.92 494787.12 716312.95 3.92 494787.12 716312.95 7.62 494786.59 716311.66 7.62 494786.59 716311.66 3.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494787.12 716312.95 3.92 494784.15 716314.16 3.92 494784.15 716314.16 7.62 494787.12 716312.95 7.62 494787.12 716312.95 3.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494784.15 716314.16 3.92 494782.4 716310.18 3.92 494782.4 716310.18 7.62 494784.15 716314.16 7.62 494784.15 716314.16 3.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494782.4 716310.18 3.92 494778.78 716301.27 3.92 494778.78 716301.27 7.62 494782.4 716310.18 7.62 494782.4 716310.18 3.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-039F-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494778.78 716301.27 7.62 494782.77 716299.67 7.62 494781.74 716297.3 7.62 494786.28 716295.53 7.62 494790.76 716306.84 7.62 494791.81 716309.49 7.62 494786.59 716311.66 7.62 494787.12 716312.95 7.62 494784.15 716314.16 7.62 494782.4 716310.18 7.62 494778.78 716301.27 7.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D2F8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D2F8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.03</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2F8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494432.85 716433.44 2.17 494437.78 716438.73 2.17 494442.11 716434.69 2.17 494437.15 716429.36 2.17 494432.85 716433.44 2.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2F8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494432.85 716433.44 2.17 494437.15 716429.36 2.17 494437.15 716429.36 5.2 494432.85 716433.44 5.2 494432.85 716433.44 2.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2F8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494437.15 716429.36 2.17 494442.11 716434.69 2.17 494442.11 716434.69 5.2 494437.15 716429.36 5.2 494437.15 716429.36 2.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2F8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494442.11 716434.69 2.17 494437.78 716438.73 2.17 494437.78 716438.73 5.2 494442.11 716434.69 5.2 494442.11 716434.69 2.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2F8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494437.78 716438.73 2.17 494432.85 716433.44 2.17 494432.85 716433.44 5.2 494437.78 716438.73 5.2 494437.78 716438.73 2.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2F8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494432.85 716433.44 5.2 494437.15 716429.36 5.2 494442.11 716434.69 5.2 494437.78 716438.73 5.2 494432.85 716433.44 5.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D4A5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D4A5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.33</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494877.64 715780.91 4.05 494882.59 715785.11 4.05 494882.76 715784.9 4.05 494884.3 715786.21 4.05 494885.89 715784.37 4.05 494884.34 715783.05 4.05 494887.91 715778.78 4.05 494882.97 715774.59 4.05 494877.64 715780.91 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494877.64 715780.91 4.05 494882.97 715774.59 4.05 494882.97 715774.59 9.38 494877.64 715780.91 9.38 494877.64 715780.91 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494882.97 715774.59 4.05 494887.91 715778.78 4.05 494887.91 715778.78 9.38 494882.97 715774.59 9.38 494882.97 715774.59 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494887.91 715778.78 4.05 494884.34 715783.05 4.05 494884.34 715783.05 9.38 494887.91 715778.78 9.38 494887.91 715778.78 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494884.34 715783.05 4.05 494885.89 715784.37 4.05 494885.89 715784.37 9.38 494884.34 715783.05 9.38 494884.34 715783.05 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494885.89 715784.37 4.05 494884.3 715786.21 4.05 494884.3 715786.21 9.38 494885.89 715784.37 9.38 494885.89 715784.37 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494884.3 715786.21 4.05 494882.76 715784.9 4.05 494882.76 715784.9 9.38 494884.3 715786.21 9.38 494884.3 715786.21 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494882.76 715784.9 4.05 494882.59 715785.11 4.05 494882.59 715785.11 9.38 494882.76 715784.9 9.38 494882.76 715784.9 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494882.59 715785.11 4.05 494877.64 715780.91 4.05 494877.64 715780.91 9.38 494882.59 715785.11 9.38 494882.59 715785.11 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494877.64 715780.91 9.38 494882.97 715774.59 9.38 494887.91 715778.78 9.38 494884.34 715783.05 9.38 494885.89 715784.37 9.38 494884.3 715786.21 9.38 494882.76 715784.9 9.38 494882.59 715785.11 9.38 494877.64 715780.91 9.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D3D0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D3D0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3D0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494784.46 715823.24 3.16 494792.49 715829.32 3.16 494795.22 715825.72 3.16 494787.22 715819.62 3.16 494784.46 715823.24 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3D0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494784.46 715823.24 3.16 494787.22 715819.62 3.16 494787.22 715819.62 7.1000000000000005 494784.46 715823.24 7.1000000000000005 494784.46 715823.24 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3D0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494787.22 715819.62 3.16 494795.22 715825.72 3.16 494795.22 715825.72 7.1000000000000005 494787.22 715819.62 7.1000000000000005 494787.22 715819.62 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3D0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494795.22 715825.72 3.16 494792.49 715829.32 3.16 494792.49 715829.32 7.1000000000000005 494795.22 715825.72 7.1000000000000005 494795.22 715825.72 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3D0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494792.49 715829.32 3.16 494784.46 715823.24 3.16 494784.46 715823.24 7.1000000000000005 494792.49 715829.32 7.1000000000000005 494792.49 715829.32 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3D0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494784.46 715823.24 7.1000000000000005 494787.22 715819.62 7.1000000000000005 494795.22 715825.72 7.1000000000000005 494792.49 715829.32 7.1000000000000005 494784.46 715823.24 7.1000000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D3CF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D3CF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.13</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494795.82 716317.71 3.64 494798.7 716324.39 3.64 494804.58 716321.84 3.64 494801.7 716315.17 3.64 494795.82 716317.71 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494795.82 716317.71 3.64 494801.7 716315.17 3.64 494801.7 716315.17 6.7700000000000005 494795.82 716317.71 6.7700000000000005 494795.82 716317.71 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494801.7 716315.17 3.64 494804.58 716321.84 3.64 494804.58 716321.84 6.7700000000000005 494801.7 716315.17 6.7700000000000005 494801.7 716315.17 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494804.58 716321.84 3.64 494798.7 716324.39 3.64 494798.7 716324.39 6.7700000000000005 494804.58 716321.84 6.7700000000000005 494804.58 716321.84 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494798.7 716324.39 3.64 494795.82 716317.71 3.64 494795.82 716317.71 6.7700000000000005 494798.7 716324.39 6.7700000000000005 494798.7 716324.39 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3CF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494795.82 716317.71 6.7700000000000005 494801.7 716315.17 6.7700000000000005 494804.58 716321.84 6.7700000000000005 494798.7 716324.39 6.7700000000000005 494795.82 716317.71 6.7700000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D4A2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D4A2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.14</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494853.49 716295.98 3.68 494856.63 716303.07 3.68 494861.23 716301.04 3.68 494858.12 716293.92 3.68 494853.49 716295.98 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494853.49 716295.98 3.68 494858.12 716293.92 3.68 494858.12 716293.92 7.82 494853.49 716295.98 7.82 494853.49 716295.98 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494858.12 716293.92 3.68 494861.23 716301.04 3.68 494861.23 716301.04 7.82 494858.12 716293.92 7.82 494858.12 716293.92 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494861.23 716301.04 3.68 494856.63 716303.07 3.68 494856.63 716303.07 7.82 494861.23 716301.04 7.82 494861.23 716301.04 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494856.63 716303.07 3.68 494853.49 716295.98 3.68 494853.49 716295.98 7.82 494856.63 716303.07 7.82 494856.63 716303.07 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494853.49 716295.98 7.82 494858.12 716293.92 7.82 494861.23 716301.04 7.82 494856.63 716303.07 7.82 494853.49 716295.98 7.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D49F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D49F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.92</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D49F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494864.41 715743.53 3.55 494869.09 715747.57 3.55 494870.59 715745.79 3.55 494875.15 715749.69 3.55 494883.87 715739.57 3.55 494879.02 715735.34 3.55 494878.01 715736.46 3.55 494873.76 715732.77 3.55 494864.41 715743.53 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D49F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494864.41 715743.53 3.55 494873.76 715732.77 3.55 494873.76 715732.77 8.47 494864.41 715743.53 8.47 494864.41 715743.53 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D49F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494873.76 715732.77 3.55 494878.01 715736.46 3.55 494878.01 715736.46 8.47 494873.76 715732.77 8.47 494873.76 715732.77 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D49F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494878.01 715736.46 3.55 494879.02 715735.34 3.55 494879.02 715735.34 8.47 494878.01 715736.46 8.47 494878.01 715736.46 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D49F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494879.02 715735.34 3.55 494883.87 715739.57 3.55 494883.87 715739.57 8.47 494879.02 715735.34 8.47 494879.02 715735.34 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D49F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494883.87 715739.57 3.55 494875.15 715749.69 3.55 494875.15 715749.69 8.47 494883.87 715739.57 8.47 494883.87 715739.57 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D49F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494875.15 715749.69 3.55 494870.59 715745.79 3.55 494870.59 715745.79 8.47 494875.15 715749.69 8.47 494875.15 715749.69 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D49F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494870.59 715745.79 3.55 494869.09 715747.57 3.55 494869.09 715747.57 8.47 494870.59 715745.79 8.47 494870.59 715745.79 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D49F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494869.09 715747.57 3.55 494864.41 715743.53 3.55 494864.41 715743.53 8.47 494869.09 715747.57 8.47 494869.09 715747.57 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D49F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494864.41 715743.53 8.47 494873.76 715732.77 8.47 494878.01 715736.46 8.47 494879.02 715735.34 8.47 494883.87 715739.57 8.47 494875.15 715749.69 8.47 494870.59 715745.79 8.47 494869.09 715747.57 8.47 494864.41 715743.53 8.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-554b98e7-00d4-4d5a-aa15-2eda1e47c663">
			<gen:stringAttribute name="buildingId">
				<gen:value>554b98e7-00d4-4d5a-aa15-2eda1e47c663</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.51</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-554b98e7-00d4-4d5a-aa15-2eda1e47c663_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494861.14 715779.19 3.96 494857.67 715783.13 3.96 494863.08 715787.9 3.96 494864.07 715786.78 3.96 494865.91 715788.45 3.96 494868.37 715785.65 3.96 494866.52 715784 3.96 494861.14 715779.19 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-554b98e7-00d4-4d5a-aa15-2eda1e47c663_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494861.14 715779.19 3.96 494866.52 715784 3.96 494866.52 715784 9.465 494861.14 715779.19 9.465 494861.14 715779.19 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-554b98e7-00d4-4d5a-aa15-2eda1e47c663_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494866.52 715784 3.96 494868.37 715785.65 3.96 494868.37 715785.65 9.465 494866.52 715784 9.465 494866.52 715784 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-554b98e7-00d4-4d5a-aa15-2eda1e47c663_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494868.37 715785.65 3.96 494865.91 715788.45 3.96 494865.91 715788.45 9.465 494868.37 715785.65 9.465 494868.37 715785.65 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-554b98e7-00d4-4d5a-aa15-2eda1e47c663_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494865.91 715788.45 3.96 494864.07 715786.78 3.96 494864.07 715786.78 9.465 494865.91 715788.45 9.465 494865.91 715788.45 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-554b98e7-00d4-4d5a-aa15-2eda1e47c663_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494864.07 715786.78 3.96 494863.08 715787.9 3.96 494863.08 715787.9 9.465 494864.07 715786.78 9.465 494864.07 715786.78 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-554b98e7-00d4-4d5a-aa15-2eda1e47c663_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494863.08 715787.9 3.96 494857.67 715783.13 3.96 494857.67 715783.13 9.465 494863.08 715787.9 9.465 494863.08 715787.9 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-554b98e7-00d4-4d5a-aa15-2eda1e47c663_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494857.67 715783.13 3.96 494861.14 715779.19 3.96 494861.14 715779.19 9.465 494857.67 715783.13 9.465 494857.67 715783.13 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-554b98e7-00d4-4d5a-aa15-2eda1e47c663_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494861.14 715779.19 9.465 494866.52 715784 9.465 494868.37 715785.65 9.465 494865.91 715788.45 9.465 494864.07 715786.78 9.465 494863.08 715787.9 9.465 494857.67 715783.13 9.465 494861.14 715779.19 9.465</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-ca62e54a-8a07-4f52-9a3d-ad048fe11f1b">
			<gen:stringAttribute name="buildingId">
				<gen:value>ca62e54a-8a07-4f52-9a3d-ad048fe11f1b</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ca62e54a-8a07-4f52-9a3d-ad048fe11f1b_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494963.97 715319.46 4.02 494963.81 715321.43 4.02 494963.49 715325.59 4.02 494972 715326.19 4.02 494972.46 715320.11 4.02 494963.97 715319.46 4.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ca62e54a-8a07-4f52-9a3d-ad048fe11f1b_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494963.97 715319.46 4.02 494972.46 715320.11 4.02 494972.46 715320.11 6.86 494963.97 715319.46 6.86 494963.97 715319.46 4.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ca62e54a-8a07-4f52-9a3d-ad048fe11f1b_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494972.46 715320.11 4.02 494972 715326.19 4.02 494972 715326.19 6.86 494972.46 715320.11 6.86 494972.46 715320.11 4.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ca62e54a-8a07-4f52-9a3d-ad048fe11f1b_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494972 715326.19 4.02 494963.49 715325.59 4.02 494963.49 715325.59 6.86 494972 715326.19 6.86 494972 715326.19 4.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ca62e54a-8a07-4f52-9a3d-ad048fe11f1b_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494963.49 715325.59 4.02 494963.81 715321.43 4.02 494963.81 715321.43 6.86 494963.49 715325.59 6.86 494963.49 715325.59 4.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ca62e54a-8a07-4f52-9a3d-ad048fe11f1b_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494963.81 715321.43 4.02 494963.97 715319.46 4.02 494963.97 715319.46 6.86 494963.81 715321.43 6.86 494963.81 715321.43 4.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ca62e54a-8a07-4f52-9a3d-ad048fe11f1b_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494963.97 715319.46 6.86 494972.46 715320.11 6.86 494972 715326.19 6.86 494963.49 715325.59 6.86 494963.81 715321.43 6.86 494963.97 715319.46 6.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-de20ed86-cca5-4317-9856-7dbaf2050175">
			<gen:stringAttribute name="buildingId">
				<gen:value>de20ed86-cca5-4317-9856-7dbaf2050175</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.57</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de20ed86-cca5-4317-9856-7dbaf2050175_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494918.93 715418.53 4.49 494915.75 715428.61 4.49 494920.01 715429.94 4.49 494923.25 715419.84 4.49 494918.93 715418.53 4.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de20ed86-cca5-4317-9856-7dbaf2050175_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494918.93 715418.53 4.49 494923.25 715419.84 4.49 494923.25 715419.84 7.0600000000000005 494918.93 715418.53 7.0600000000000005 494918.93 715418.53 4.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de20ed86-cca5-4317-9856-7dbaf2050175_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494923.25 715419.84 4.49 494920.01 715429.94 4.49 494920.01 715429.94 7.0600000000000005 494923.25 715419.84 7.0600000000000005 494923.25 715419.84 4.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de20ed86-cca5-4317-9856-7dbaf2050175_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494920.01 715429.94 4.49 494915.75 715428.61 4.49 494915.75 715428.61 7.0600000000000005 494920.01 715429.94 7.0600000000000005 494920.01 715429.94 4.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de20ed86-cca5-4317-9856-7dbaf2050175_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494915.75 715428.61 4.49 494918.93 715418.53 4.49 494918.93 715418.53 7.0600000000000005 494915.75 715428.61 7.0600000000000005 494915.75 715428.61 4.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de20ed86-cca5-4317-9856-7dbaf2050175_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494918.93 715418.53 7.0600000000000005 494923.25 715419.84 7.0600000000000005 494920.01 715429.94 7.0600000000000005 494915.75 715428.61 7.0600000000000005 494918.93 715418.53 7.0600000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-de681cc0-51ec-4c00-af67-a0abc1b69233">
			<gen:stringAttribute name="buildingId">
				<gen:value>de681cc0-51ec-4c00-af67-a0abc1b69233</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de681cc0-51ec-4c00-af67-a0abc1b69233_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494841.08 715765.34 4.03 494839.5 715767.29 4.03 494840.51 715768.14 4.03 494835.92 715773.76 4.03 494839.91 715777.09 4.03 494844.48 715771.46 4.03 494845.46 715772.28 4.03 494847 715770.43 4.03 494841.08 715765.34 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de681cc0-51ec-4c00-af67-a0abc1b69233_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494841.08 715765.34 4.03 494847 715770.43 4.03 494847 715770.43 8.82 494841.08 715765.34 8.82 494841.08 715765.34 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de681cc0-51ec-4c00-af67-a0abc1b69233_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494847 715770.43 4.03 494845.46 715772.28 4.03 494845.46 715772.28 8.82 494847 715770.43 8.82 494847 715770.43 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de681cc0-51ec-4c00-af67-a0abc1b69233_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494845.46 715772.28 4.03 494844.48 715771.46 4.03 494844.48 715771.46 8.82 494845.46 715772.28 8.82 494845.46 715772.28 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de681cc0-51ec-4c00-af67-a0abc1b69233_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494844.48 715771.46 4.03 494839.91 715777.09 4.03 494839.91 715777.09 8.82 494844.48 715771.46 8.82 494844.48 715771.46 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de681cc0-51ec-4c00-af67-a0abc1b69233_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494839.91 715777.09 4.03 494835.92 715773.76 4.03 494835.92 715773.76 8.82 494839.91 715777.09 8.82 494839.91 715777.09 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de681cc0-51ec-4c00-af67-a0abc1b69233_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494835.92 715773.76 4.03 494840.51 715768.14 4.03 494840.51 715768.14 8.82 494835.92 715773.76 8.82 494835.92 715773.76 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de681cc0-51ec-4c00-af67-a0abc1b69233_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494840.51 715768.14 4.03 494839.5 715767.29 4.03 494839.5 715767.29 8.82 494840.51 715768.14 8.82 494840.51 715768.14 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de681cc0-51ec-4c00-af67-a0abc1b69233_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494839.5 715767.29 4.03 494841.08 715765.34 4.03 494841.08 715765.34 8.82 494839.5 715767.29 8.82 494839.5 715767.29 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-de681cc0-51ec-4c00-af67-a0abc1b69233_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494841.08 715765.34 8.82 494847 715770.43 8.82 494845.46 715772.28 8.82 494844.48 715771.46 8.82 494839.91 715777.09 8.82 494835.92 715773.76 8.82 494840.51 715768.14 8.82 494839.5 715767.29 8.82 494841.08 715765.34 8.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-0828d8fd-f2e9-4dda-973f-e75f310eccee">
			<gen:stringAttribute name="buildingId">
				<gen:value>0828d8fd-f2e9-4dda-973f-e75f310eccee</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.15</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0828d8fd-f2e9-4dda-973f-e75f310eccee_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494781.58 715879.53 4.33 494781.46 715880.48 4.33 494778.9 715880.1 4.33 494776.99 715892.85 4.33 494785.77 715894.18 4.33 494787.7 715881.42 4.33 494785.19 715881.05 4.33 494785.33 715880.13 4.33 494781.58 715879.53 4.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0828d8fd-f2e9-4dda-973f-e75f310eccee_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494781.58 715879.53 4.33 494785.33 715880.13 4.33 494785.33 715880.13 9.48 494781.58 715879.53 9.48 494781.58 715879.53 4.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0828d8fd-f2e9-4dda-973f-e75f310eccee_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494785.33 715880.13 4.33 494785.19 715881.05 4.33 494785.19 715881.05 9.48 494785.33 715880.13 9.48 494785.33 715880.13 4.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0828d8fd-f2e9-4dda-973f-e75f310eccee_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494785.19 715881.05 4.33 494787.7 715881.42 4.33 494787.7 715881.42 9.48 494785.19 715881.05 9.48 494785.19 715881.05 4.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0828d8fd-f2e9-4dda-973f-e75f310eccee_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494787.7 715881.42 4.33 494785.77 715894.18 4.33 494785.77 715894.18 9.48 494787.7 715881.42 9.48 494787.7 715881.42 4.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0828d8fd-f2e9-4dda-973f-e75f310eccee_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494785.77 715894.18 4.33 494776.99 715892.85 4.33 494776.99 715892.85 9.48 494785.77 715894.18 9.48 494785.77 715894.18 4.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0828d8fd-f2e9-4dda-973f-e75f310eccee_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494776.99 715892.85 4.33 494778.9 715880.1 4.33 494778.9 715880.1 9.48 494776.99 715892.85 9.48 494776.99 715892.85 4.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0828d8fd-f2e9-4dda-973f-e75f310eccee_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494778.9 715880.1 4.33 494781.46 715880.48 4.33 494781.46 715880.48 9.48 494778.9 715880.1 9.48 494778.9 715880.1 4.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0828d8fd-f2e9-4dda-973f-e75f310eccee_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494781.46 715880.48 4.33 494781.58 715879.53 4.33 494781.58 715879.53 9.48 494781.46 715880.48 9.48 494781.46 715880.48 4.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0828d8fd-f2e9-4dda-973f-e75f310eccee_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494781.58 715879.53 9.48 494785.33 715880.13 9.48 494785.19 715881.05 9.48 494787.7 715881.42 9.48 494785.77 715894.18 9.48 494776.99 715892.85 9.48 494778.9 715880.1 9.48 494781.46 715880.48 9.48 494781.58 715879.53 9.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-60b6e4d4-64b6-4535-b0ef-7783d54265cb">
			<gen:stringAttribute name="buildingId">
				<gen:value>60b6e4d4-64b6-4535-b0ef-7783d54265cb</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-60b6e4d4-64b6-4535-b0ef-7783d54265cb_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494968.87 715075.52 4.79 494977.07 715079.46 4.79 494980.39 715072.44 4.79 494972.17 715068.58 4.79 494968.87 715075.52 4.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-60b6e4d4-64b6-4535-b0ef-7783d54265cb_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494968.87 715075.52 4.79 494972.17 715068.58 4.79 494972.17 715068.58 10.625 494968.87 715075.52 10.625 494968.87 715075.52 4.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-60b6e4d4-64b6-4535-b0ef-7783d54265cb_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494972.17 715068.58 4.79 494980.39 715072.44 4.79 494980.39 715072.44 10.625 494972.17 715068.58 10.625 494972.17 715068.58 4.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-60b6e4d4-64b6-4535-b0ef-7783d54265cb_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494980.39 715072.44 4.79 494977.07 715079.46 4.79 494977.07 715079.46 10.625 494980.39 715072.44 10.625 494980.39 715072.44 4.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-60b6e4d4-64b6-4535-b0ef-7783d54265cb_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494977.07 715079.46 4.79 494968.87 715075.52 4.79 494968.87 715075.52 10.625 494977.07 715079.46 10.625 494977.07 715079.46 4.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-60b6e4d4-64b6-4535-b0ef-7783d54265cb_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494968.87 715075.52 10.625 494972.17 715068.58 10.625 494980.39 715072.44 10.625 494977.07 715079.46 10.625 494968.87 715075.52 10.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-92d5b3e2-9a04-4a39-a183-7fe6aa523f3d">
			<gen:stringAttribute name="buildingId">
				<gen:value>92d5b3e2-9a04-4a39-a183-7fe6aa523f3d</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.1</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-92d5b3e2-9a04-4a39-a183-7fe6aa523f3d_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494787.79 715866.37 4.46 494788.27 715863.4 4.46 494781.54 715862.35 4.46 494781.11 715865.34 4.46 494780.27 715871.25 4.46 494786.91 715872.24 4.46 494787.79 715866.37 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-92d5b3e2-9a04-4a39-a183-7fe6aa523f3d_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494787.79 715866.37 4.46 494786.91 715872.24 4.46 494786.91 715872.24 8.56 494787.79 715866.37 8.56 494787.79 715866.37 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-92d5b3e2-9a04-4a39-a183-7fe6aa523f3d_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494786.91 715872.24 4.46 494780.27 715871.25 4.46 494780.27 715871.25 8.56 494786.91 715872.24 8.56 494786.91 715872.24 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-92d5b3e2-9a04-4a39-a183-7fe6aa523f3d_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494780.27 715871.25 4.46 494781.11 715865.34 4.46 494781.11 715865.34 8.56 494780.27 715871.25 8.56 494780.27 715871.25 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-92d5b3e2-9a04-4a39-a183-7fe6aa523f3d_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494781.11 715865.34 4.46 494781.54 715862.35 4.46 494781.54 715862.35 8.56 494781.11 715865.34 8.56 494781.11 715865.34 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-92d5b3e2-9a04-4a39-a183-7fe6aa523f3d_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494781.54 715862.35 4.46 494788.27 715863.4 4.46 494788.27 715863.4 8.56 494781.54 715862.35 8.56 494781.54 715862.35 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-92d5b3e2-9a04-4a39-a183-7fe6aa523f3d_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494788.27 715863.4 4.46 494787.79 715866.37 4.46 494787.79 715866.37 8.56 494788.27 715863.4 8.56 494788.27 715863.4 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-92d5b3e2-9a04-4a39-a183-7fe6aa523f3d_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494787.79 715866.37 8.56 494786.91 715872.24 8.56 494780.27 715871.25 8.56 494781.11 715865.34 8.56 494781.54 715862.35 8.56 494788.27 715863.4 8.56 494787.79 715866.37 8.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-729A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-729A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-729A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494907.68 715379.61 4.32 494917.44 715382.24 4.32 494920.2 715383.06 4.32 494922.17 715376.08 4.32 494919.28 715375.44 4.32 494909.44 715372.86 4.32 494909.21 715372.81 4.32 494909.15 715373.05 4.32 494909.41 715373.14 4.32 494907.68 715379.61 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-729A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494907.68 715379.61 4.32 494909.41 715373.14 4.32 494909.41 715373.14 9.31 494907.68 715379.61 9.31 494907.68 715379.61 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-729A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494909.41 715373.14 4.32 494909.15 715373.05 4.32 494909.15 715373.05 9.31 494909.41 715373.14 9.31 494909.41 715373.14 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-729A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494909.15 715373.05 4.32 494909.21 715372.81 4.32 494909.21 715372.81 9.31 494909.15 715373.05 9.31 494909.15 715373.05 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-729A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494909.21 715372.81 4.32 494909.44 715372.86 4.32 494909.44 715372.86 9.31 494909.21 715372.81 9.31 494909.21 715372.81 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-729A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494909.44 715372.86 4.32 494919.28 715375.44 4.32 494919.28 715375.44 9.31 494909.44 715372.86 9.31 494909.44 715372.86 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-729A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494919.28 715375.44 4.32 494922.17 715376.08 4.32 494922.17 715376.08 9.31 494919.28 715375.44 9.31 494919.28 715375.44 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-729A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494922.17 715376.08 4.32 494920.2 715383.06 4.32 494920.2 715383.06 9.31 494922.17 715376.08 9.31 494922.17 715376.08 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-729A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494920.2 715383.06 4.32 494917.44 715382.24 4.32 494917.44 715382.24 9.31 494920.2 715383.06 9.31 494920.2 715383.06 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-729A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494917.44 715382.24 4.32 494907.68 715379.61 4.32 494907.68 715379.61 9.31 494917.44 715382.24 9.31 494917.44 715382.24 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-729A-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494907.68 715379.61 9.31 494909.41 715373.14 9.31 494909.15 715373.05 9.31 494909.21 715372.81 9.31 494909.44 715372.86 9.31 494919.28 715375.44 9.31 494922.17 715376.08 9.31 494920.2 715383.06 9.31 494917.44 715382.24 9.31 494907.68 715379.61 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-f3d9f420-376c-4791-81fc-baad4ffdb9ba">
			<gen:stringAttribute name="buildingId">
				<gen:value>f3d9f420-376c-4791-81fc-baad4ffdb9ba</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.96</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f3d9f420-376c-4791-81fc-baad4ffdb9ba_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495252.98 716414.28 3.64 495262.11 716436.73 3.64 495276.66 716430.63 3.64 495267.67 716408.29 3.64 495267.51 716408.35 3.64 495253.13 716414.21 3.64 495252.98 716414.28 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f3d9f420-376c-4791-81fc-baad4ffdb9ba_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495252.98 716414.28 3.64 495253.13 716414.21 3.64 495253.13 716414.21 8.6 495252.98 716414.28 8.6 495252.98 716414.28 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f3d9f420-376c-4791-81fc-baad4ffdb9ba_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495253.13 716414.21 3.64 495267.51 716408.35 3.64 495267.51 716408.35 8.6 495253.13 716414.21 8.6 495253.13 716414.21 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f3d9f420-376c-4791-81fc-baad4ffdb9ba_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495267.51 716408.35 3.64 495267.67 716408.29 3.64 495267.67 716408.29 8.6 495267.51 716408.35 8.6 495267.51 716408.35 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f3d9f420-376c-4791-81fc-baad4ffdb9ba_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495267.67 716408.29 3.64 495276.66 716430.63 3.64 495276.66 716430.63 8.6 495267.67 716408.29 8.6 495267.67 716408.29 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f3d9f420-376c-4791-81fc-baad4ffdb9ba_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495276.66 716430.63 3.64 495262.11 716436.73 3.64 495262.11 716436.73 8.6 495276.66 716430.63 8.6 495276.66 716430.63 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f3d9f420-376c-4791-81fc-baad4ffdb9ba_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495262.11 716436.73 3.64 495252.98 716414.28 3.64 495252.98 716414.28 8.6 495262.11 716436.73 8.6 495262.11 716436.73 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f3d9f420-376c-4791-81fc-baad4ffdb9ba_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495252.98 716414.28 8.6 495253.13 716414.21 8.6 495267.51 716408.35 8.6 495267.67 716408.29 8.6 495276.66 716430.63 8.6 495262.11 716436.73 8.6 495252.98 716414.28 8.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7296-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.68</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494907.35 716258.85 3.68 494909.5 716264 3.68 494912.32 716262.82 3.68 494913.29 716265.14 3.68 494912.17 716265.67 3.68 494915.13 716272.68 3.68 494922.51 716269.51 3.68 494920.5 716264.86 3.68 494919.64 716262.86 3.68 494920.35 716262.56 3.68 494921.47 716265.32 3.68 494924.27 716264.1 3.68 494923.89 716263.21 3.68 494923.09 716261.38 3.68 494924.28 716260.86 3.68 494930.62 716258.19 3.68 494926.3 716248.01 3.68 494909.28 716255.3 3.68 494910.16 716257.64 3.68 494907.35 716258.85 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494907.35 716258.85 3.68 494910.16 716257.64 3.68 494910.16 716257.64 10.36 494907.35 716258.85 10.36 494907.35 716258.85 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494910.16 716257.64 3.68 494909.28 716255.3 3.68 494909.28 716255.3 10.36 494910.16 716257.64 10.36 494910.16 716257.64 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494909.28 716255.3 3.68 494926.3 716248.01 3.68 494926.3 716248.01 10.36 494909.28 716255.3 10.36 494909.28 716255.3 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494926.3 716248.01 3.68 494930.62 716258.19 3.68 494930.62 716258.19 10.36 494926.3 716248.01 10.36 494926.3 716248.01 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494930.62 716258.19 3.68 494924.28 716260.86 3.68 494924.28 716260.86 10.36 494930.62 716258.19 10.36 494930.62 716258.19 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494924.28 716260.86 3.68 494923.09 716261.38 3.68 494923.09 716261.38 10.36 494924.28 716260.86 10.36 494924.28 716260.86 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494923.09 716261.38 3.68 494923.89 716263.21 3.68 494923.89 716263.21 10.36 494923.09 716261.38 10.36 494923.09 716261.38 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494923.89 716263.21 3.68 494924.27 716264.1 3.68 494924.27 716264.1 10.36 494923.89 716263.21 10.36 494923.89 716263.21 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494924.27 716264.1 3.68 494921.47 716265.32 3.68 494921.47 716265.32 10.36 494924.27 716264.1 10.36 494924.27 716264.1 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494921.47 716265.32 3.68 494920.35 716262.56 3.68 494920.35 716262.56 10.36 494921.47 716265.32 10.36 494921.47 716265.32 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494920.35 716262.56 3.68 494919.64 716262.86 3.68 494919.64 716262.86 10.36 494920.35 716262.56 10.36 494920.35 716262.56 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494919.64 716262.86 3.68 494920.5 716264.86 3.68 494920.5 716264.86 10.36 494919.64 716262.86 10.36 494919.64 716262.86 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494920.5 716264.86 3.68 494922.51 716269.51 3.68 494922.51 716269.51 10.36 494920.5 716264.86 10.36 494920.5 716264.86 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494922.51 716269.51 3.68 494915.13 716272.68 3.68 494915.13 716272.68 10.36 494922.51 716269.51 10.36 494922.51 716269.51 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494915.13 716272.68 3.68 494912.17 716265.67 3.68 494912.17 716265.67 10.36 494915.13 716272.68 10.36 494915.13 716272.68 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494912.17 716265.67 3.68 494913.29 716265.14 3.68 494913.29 716265.14 10.36 494912.17 716265.67 10.36 494912.17 716265.67 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494913.29 716265.14 3.68 494912.32 716262.82 3.68 494912.32 716262.82 10.36 494913.29 716265.14 10.36 494913.29 716265.14 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494912.32 716262.82 3.68 494909.5 716264 3.68 494909.5 716264 10.36 494912.32 716262.82 10.36 494912.32 716262.82 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494909.5 716264 3.68 494907.35 716258.85 3.68 494907.35 716258.85 10.36 494909.5 716264 10.36 494909.5 716264 3.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7296-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494907.35 716258.85 10.36 494910.16 716257.64 10.36 494909.28 716255.3 10.36 494926.3 716248.01 10.36 494930.62 716258.19 10.36 494924.28 716260.86 10.36 494923.09 716261.38 10.36 494923.89 716263.21 10.36 494924.27 716264.1 10.36 494921.47 716265.32 10.36 494920.35 716262.56 10.36 494919.64 716262.86 10.36 494920.5 716264.86 10.36 494922.51 716269.51 10.36 494915.13 716272.68 10.36 494912.17 716265.67 10.36 494913.29 716265.14 10.36 494912.32 716262.82 10.36 494909.5 716264 10.36 494907.35 716258.85 10.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D222-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D222-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D222-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494844.02 715805.33 2.98 494841 715809.43 2.98 494847.92 715814.52 2.98 494850.92 715810.4 2.98 494844.14 715805.38 2.98 494844.02 715805.33 2.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D222-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494844.02 715805.33 2.98 494844.14 715805.38 2.98 494844.14 715805.38 7.530000000000001 494844.02 715805.33 7.530000000000001 494844.02 715805.33 2.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D222-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494844.14 715805.38 2.98 494850.92 715810.4 2.98 494850.92 715810.4 7.530000000000001 494844.14 715805.38 7.530000000000001 494844.14 715805.38 2.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D222-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494850.92 715810.4 2.98 494847.92 715814.52 2.98 494847.92 715814.52 7.530000000000001 494850.92 715810.4 7.530000000000001 494850.92 715810.4 2.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D222-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494847.92 715814.52 2.98 494841 715809.43 2.98 494841 715809.43 7.530000000000001 494847.92 715814.52 7.530000000000001 494847.92 715814.52 2.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D222-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494841 715809.43 2.98 494844.02 715805.33 2.98 494844.02 715805.33 7.530000000000001 494841 715809.43 7.530000000000001 494841 715809.43 2.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D222-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494844.02 715805.33 7.530000000000001 494844.14 715805.38 7.530000000000001 494850.92 715810.4 7.530000000000001 494847.92 715814.52 7.530000000000001 494841 715809.43 7.530000000000001 494844.02 715805.33 7.530000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6019-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6019-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6019-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494889.88 715429.2 4.92 494897.58 715432.88 4.92 494901.05 715423.74 4.92 494893.29 715419.94 4.92 494889.88 715429.2 4.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6019-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494889.88 715429.2 4.92 494893.29 715419.94 4.92 494893.29 715419.94 10.76 494889.88 715429.2 10.76 494889.88 715429.2 4.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6019-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494893.29 715419.94 4.92 494901.05 715423.74 4.92 494901.05 715423.74 10.76 494893.29 715419.94 10.76 494893.29 715419.94 4.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6019-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494901.05 715423.74 4.92 494897.58 715432.88 4.92 494897.58 715432.88 10.76 494901.05 715423.74 10.76 494901.05 715423.74 4.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6019-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494897.58 715432.88 4.92 494889.88 715429.2 4.92 494889.88 715429.2 10.76 494897.58 715432.88 10.76 494897.58 715432.88 4.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6019-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494889.88 715429.2 10.76 494893.29 715419.94 10.76 494901.05 715423.74 10.76 494897.58 715432.88 10.76 494889.88 715429.2 10.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0474-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0474-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.61</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0474-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494893.29 715419.94 4.89 494901.05 715423.74 4.89 494907.75 715410.27 4.89 494900.12 715406.44 4.89 494897.31 715412.02 4.89 494895.83 715411.29 4.89 494894.58 715413.8 4.89 494896.05 715414.48 4.89 494893.29 715419.94 4.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0474-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494893.29 715419.94 4.89 494896.05 715414.48 4.89 494896.05 715414.48 10.5 494893.29 715419.94 10.5 494893.29 715419.94 4.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0474-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494896.05 715414.48 4.89 494894.58 715413.8 4.89 494894.58 715413.8 10.5 494896.05 715414.48 10.5 494896.05 715414.48 4.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0474-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494894.58 715413.8 4.89 494895.83 715411.29 4.89 494895.83 715411.29 10.5 494894.58 715413.8 10.5 494894.58 715413.8 4.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0474-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494895.83 715411.29 4.89 494897.31 715412.02 4.89 494897.31 715412.02 10.5 494895.83 715411.29 10.5 494895.83 715411.29 4.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0474-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494897.31 715412.02 4.89 494900.12 715406.44 4.89 494900.12 715406.44 10.5 494897.31 715412.02 10.5 494897.31 715412.02 4.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0474-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494900.12 715406.44 4.89 494907.75 715410.27 4.89 494907.75 715410.27 10.5 494900.12 715406.44 10.5 494900.12 715406.44 4.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0474-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494907.75 715410.27 4.89 494901.05 715423.74 4.89 494901.05 715423.74 10.5 494907.75 715410.27 10.5 494907.75 715410.27 4.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0474-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494901.05 715423.74 4.89 494893.29 715419.94 4.89 494893.29 715419.94 10.5 494901.05 715423.74 10.5 494901.05 715423.74 4.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0474-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494893.29 715419.94 10.5 494896.05 715414.48 10.5 494894.58 715413.8 10.5 494895.83 715411.29 10.5 494897.31 715412.02 10.5 494900.12 715406.44 10.5 494907.75 715410.27 10.5 494901.05 715423.74 10.5 494893.29 715419.94 10.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0473-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.12</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494896.43 715708.29 3.81 494900.44 715711.8 3.81 494899.34 715713.18 3.81 494903.12 715716.47 3.81 494904.86 715714.45 3.81 494906.54 715715.82 3.81 494903.35 715719.48 3.81 494906.51 715722.24 3.81 494914.88 715712.54 3.81 494912.17 715710.21 3.81 494914.11 715707.98 3.81 494909.7 715704.12 3.81 494910.16 715703.55 3.81 494907.45 715701.18 3.81 494904.96 715703.99 3.81 494902.28 715701.64 3.81 494896.43 715708.29 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494896.43 715708.29 3.81 494902.28 715701.64 3.81 494902.28 715701.64 7.9300000000000015 494896.43 715708.29 7.9300000000000015 494896.43 715708.29 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494902.28 715701.64 3.81 494904.96 715703.99 3.81 494904.96 715703.99 7.9300000000000015 494902.28 715701.64 7.9300000000000015 494902.28 715701.64 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494904.96 715703.99 3.81 494907.45 715701.18 3.81 494907.45 715701.18 7.9300000000000015 494904.96 715703.99 7.9300000000000015 494904.96 715703.99 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494907.45 715701.18 3.81 494910.16 715703.55 3.81 494910.16 715703.55 7.9300000000000015 494907.45 715701.18 7.9300000000000015 494907.45 715701.18 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494910.16 715703.55 3.81 494909.7 715704.12 3.81 494909.7 715704.12 7.9300000000000015 494910.16 715703.55 7.9300000000000015 494910.16 715703.55 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494909.7 715704.12 3.81 494914.11 715707.98 3.81 494914.11 715707.98 7.9300000000000015 494909.7 715704.12 7.9300000000000015 494909.7 715704.12 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494914.11 715707.98 3.81 494912.17 715710.21 3.81 494912.17 715710.21 7.9300000000000015 494914.11 715707.98 7.9300000000000015 494914.11 715707.98 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494912.17 715710.21 3.81 494914.88 715712.54 3.81 494914.88 715712.54 7.9300000000000015 494912.17 715710.21 7.9300000000000015 494912.17 715710.21 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494914.88 715712.54 3.81 494906.51 715722.24 3.81 494906.51 715722.24 7.9300000000000015 494914.88 715712.54 7.9300000000000015 494914.88 715712.54 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494906.51 715722.24 3.81 494903.35 715719.48 3.81 494903.35 715719.48 7.9300000000000015 494906.51 715722.24 7.9300000000000015 494906.51 715722.24 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494903.35 715719.48 3.81 494906.54 715715.82 3.81 494906.54 715715.82 7.9300000000000015 494903.35 715719.48 7.9300000000000015 494903.35 715719.48 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494906.54 715715.82 3.81 494904.86 715714.45 3.81 494904.86 715714.45 7.9300000000000015 494906.54 715715.82 7.9300000000000015 494906.54 715715.82 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494904.86 715714.45 3.81 494903.12 715716.47 3.81 494903.12 715716.47 7.9300000000000015 494904.86 715714.45 7.9300000000000015 494904.86 715714.45 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494903.12 715716.47 3.81 494899.34 715713.18 3.81 494899.34 715713.18 7.9300000000000015 494903.12 715716.47 7.9300000000000015 494903.12 715716.47 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494899.34 715713.18 3.81 494900.44 715711.8 3.81 494900.44 715711.8 7.9300000000000015 494899.34 715713.18 7.9300000000000015 494899.34 715713.18 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494900.44 715711.8 3.81 494896.43 715708.29 3.81 494896.43 715708.29 7.9300000000000015 494900.44 715711.8 7.9300000000000015 494900.44 715711.8 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0473-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494896.43 715708.29 7.9300000000000015 494902.28 715701.64 7.9300000000000015 494904.96 715703.99 7.9300000000000015 494907.45 715701.18 7.9300000000000015 494910.16 715703.55 7.9300000000000015 494909.7 715704.12 7.9300000000000015 494914.11 715707.98 7.9300000000000015 494912.17 715710.21 7.9300000000000015 494914.88 715712.54 7.9300000000000015 494906.51 715722.24 7.9300000000000015 494903.35 715719.48 7.9300000000000015 494906.54 715715.82 7.9300000000000015 494904.86 715714.45 7.9300000000000015 494903.12 715716.47 7.9300000000000015 494899.34 715713.18 7.9300000000000015 494900.44 715711.8 7.9300000000000015 494896.43 715708.29 7.9300000000000015</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-3F88-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-3F88-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.54</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F88-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495293.79 716407.62 3.47 495298.89 716418.99 3.47 495294.56 716420.94 3.47 495303.37 716440.84 3.47 495364.25 716413.51 3.47 495355.49 716393.82 3.47 495316.28 716411.17 3.47 495311.29 716399.8 3.47 495293.79 716407.62 3.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F88-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495293.79 716407.62 3.47 495311.29 716399.8 3.47 495311.29 716399.8 12.01 495293.79 716407.62 12.01 495293.79 716407.62 3.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F88-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495311.29 716399.8 3.47 495316.28 716411.17 3.47 495316.28 716411.17 12.01 495311.29 716399.8 12.01 495311.29 716399.8 3.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F88-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495316.28 716411.17 3.47 495355.49 716393.82 3.47 495355.49 716393.82 12.01 495316.28 716411.17 12.01 495316.28 716411.17 3.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F88-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495355.49 716393.82 3.47 495364.25 716413.51 3.47 495364.25 716413.51 12.01 495355.49 716393.82 12.01 495355.49 716393.82 3.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F88-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495364.25 716413.51 3.47 495303.37 716440.84 3.47 495303.37 716440.84 12.01 495364.25 716413.51 12.01 495364.25 716413.51 3.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F88-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495303.37 716440.84 3.47 495294.56 716420.94 3.47 495294.56 716420.94 12.01 495303.37 716440.84 12.01 495303.37 716440.84 3.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F88-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495294.56 716420.94 3.47 495298.89 716418.99 3.47 495298.89 716418.99 12.01 495294.56 716420.94 12.01 495294.56 716420.94 3.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F88-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495298.89 716418.99 3.47 495293.79 716407.62 3.47 495293.79 716407.62 12.01 495298.89 716418.99 12.01 495298.89 716418.99 3.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F88-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495293.79 716407.62 12.01 495311.29 716399.8 12.01 495316.28 716411.17 12.01 495355.49 716393.82 12.01 495364.25 716413.51 12.01 495303.37 716440.84 12.01 495294.56 716420.94 12.01 495298.89 716418.99 12.01 495293.79 716407.62 12.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0209-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.58</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494632.46 716384.46 3.93 494637.93 716398.18 3.93 494639.44 716401.52 3.93 494648.27 716397.9 3.93 494646.9 716394.55 3.93 494643.57 716385.97 3.93 494645.77 716385.17 3.93 494644.25 716381.31 3.93 494642.06 716382.11 3.93 494641.58 716380.87 3.93 494640.98 716379.05 3.93 494634.58 716381.6 3.93 494635.23 716383.37 3.93 494632.46 716384.46 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494632.46 716384.46 3.93 494635.23 716383.37 3.93 494635.23 716383.37 9.505 494632.46 716384.46 9.505 494632.46 716384.46 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494635.23 716383.37 3.93 494634.58 716381.6 3.93 494634.58 716381.6 9.505 494635.23 716383.37 9.505 494635.23 716383.37 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494634.58 716381.6 3.93 494640.98 716379.05 3.93 494640.98 716379.05 9.505 494634.58 716381.6 9.505 494634.58 716381.6 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494640.98 716379.05 3.93 494641.58 716380.87 3.93 494641.58 716380.87 9.505 494640.98 716379.05 9.505 494640.98 716379.05 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494641.58 716380.87 3.93 494642.06 716382.11 3.93 494642.06 716382.11 9.505 494641.58 716380.87 9.505 494641.58 716380.87 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494642.06 716382.11 3.93 494644.25 716381.31 3.93 494644.25 716381.31 9.505 494642.06 716382.11 9.505 494642.06 716382.11 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494644.25 716381.31 3.93 494645.77 716385.17 3.93 494645.77 716385.17 9.505 494644.25 716381.31 9.505 494644.25 716381.31 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494645.77 716385.17 3.93 494643.57 716385.97 3.93 494643.57 716385.97 9.505 494645.77 716385.17 9.505 494645.77 716385.17 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494643.57 716385.97 3.93 494646.9 716394.55 3.93 494646.9 716394.55 9.505 494643.57 716385.97 9.505 494643.57 716385.97 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494646.9 716394.55 3.93 494648.27 716397.9 3.93 494648.27 716397.9 9.505 494646.9 716394.55 9.505 494646.9 716394.55 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494648.27 716397.9 3.93 494639.44 716401.52 3.93 494639.44 716401.52 9.505 494648.27 716397.9 9.505 494648.27 716397.9 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494639.44 716401.52 3.93 494637.93 716398.18 3.93 494637.93 716398.18 9.505 494639.44 716401.52 9.505 494639.44 716401.52 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494637.93 716398.18 3.93 494632.46 716384.46 3.93 494632.46 716384.46 9.505 494637.93 716398.18 9.505 494637.93 716398.18 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0209-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494632.46 716384.46 9.505 494635.23 716383.37 9.505 494634.58 716381.6 9.505 494640.98 716379.05 9.505 494641.58 716380.87 9.505 494642.06 716382.11 9.505 494644.25 716381.31 9.505 494645.77 716385.17 9.505 494643.57 716385.97 9.505 494646.9 716394.55 9.505 494648.27 716397.9 9.505 494639.44 716401.52 9.505 494637.93 716398.18 9.505 494632.46 716384.46 9.505</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0207-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.86</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494648.04 716418.94 3.48 494649.37 716422.29 3.48 494650.59 716425.73 3.48 494653.56 716424.61 3.48 494655.5 716429.61 3.48 494652.62 716430.68 3.48 494653.9 716434.01 3.48 494656.76 716432.95 3.48 494658.53 716437.83 3.48 494667.07 716434.63 3.48 494661.34 716419.19 3.48 494662.82 716418.64 3.48 494662.07 716416.73 3.48 494660.66 716417.23 3.48 494658.22 716410.78 3.48 494649.57 716413.99 3.48 494650.96 716417.82 3.48 494648.04 716418.94 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494648.04 716418.94 3.48 494650.96 716417.82 3.48 494650.96 716417.82 8.335 494648.04 716418.94 8.335 494648.04 716418.94 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494650.96 716417.82 3.48 494649.57 716413.99 3.48 494649.57 716413.99 8.335 494650.96 716417.82 8.335 494650.96 716417.82 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494649.57 716413.99 3.48 494658.22 716410.78 3.48 494658.22 716410.78 8.335 494649.57 716413.99 8.335 494649.57 716413.99 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494658.22 716410.78 3.48 494660.66 716417.23 3.48 494660.66 716417.23 8.335 494658.22 716410.78 8.335 494658.22 716410.78 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494660.66 716417.23 3.48 494662.07 716416.73 3.48 494662.07 716416.73 8.335 494660.66 716417.23 8.335 494660.66 716417.23 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494662.07 716416.73 3.48 494662.82 716418.64 3.48 494662.82 716418.64 8.335 494662.07 716416.73 8.335 494662.07 716416.73 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494662.82 716418.64 3.48 494661.34 716419.19 3.48 494661.34 716419.19 8.335 494662.82 716418.64 8.335 494662.82 716418.64 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494661.34 716419.19 3.48 494667.07 716434.63 3.48 494667.07 716434.63 8.335 494661.34 716419.19 8.335 494661.34 716419.19 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494667.07 716434.63 3.48 494658.53 716437.83 3.48 494658.53 716437.83 8.335 494667.07 716434.63 8.335 494667.07 716434.63 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494658.53 716437.83 3.48 494656.76 716432.95 3.48 494656.76 716432.95 8.335 494658.53 716437.83 8.335 494658.53 716437.83 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494656.76 716432.95 3.48 494653.9 716434.01 3.48 494653.9 716434.01 8.335 494656.76 716432.95 8.335 494656.76 716432.95 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494653.9 716434.01 3.48 494652.62 716430.68 3.48 494652.62 716430.68 8.335 494653.9 716434.01 8.335 494653.9 716434.01 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494652.62 716430.68 3.48 494655.5 716429.61 3.48 494655.5 716429.61 8.335 494652.62 716430.68 8.335 494652.62 716430.68 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494655.5 716429.61 3.48 494653.56 716424.61 3.48 494653.56 716424.61 8.335 494655.5 716429.61 8.335 494655.5 716429.61 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494653.56 716424.61 3.48 494650.59 716425.73 3.48 494650.59 716425.73 8.335 494653.56 716424.61 8.335 494653.56 716424.61 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494650.59 716425.73 3.48 494649.37 716422.29 3.48 494649.37 716422.29 8.335 494650.59 716425.73 8.335 494650.59 716425.73 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494649.37 716422.29 3.48 494648.04 716418.94 3.48 494648.04 716418.94 8.335 494649.37 716422.29 8.335 494649.37 716422.29 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0207-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494648.04 716418.94 8.335 494650.96 716417.82 8.335 494649.57 716413.99 8.335 494658.22 716410.78 8.335 494660.66 716417.23 8.335 494662.07 716416.73 8.335 494662.82 716418.64 8.335 494661.34 716419.19 8.335 494667.07 716434.63 8.335 494658.53 716437.83 8.335 494656.76 716432.95 8.335 494653.9 716434.01 8.335 494652.62 716430.68 8.335 494655.5 716429.61 8.335 494653.56 716424.61 8.335 494650.59 716425.73 8.335 494649.37 716422.29 8.335 494648.04 716418.94 8.335</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-020A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.38</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494639.69 716482.77 3.59 494642.21 716488.29 3.59 494644.19 716487.37 3.59 494649.86 716484.69 3.59 494650.48 716486.11 3.59 494655.06 716484.11 3.59 494657.17 716483.19 3.59 494655.91 716480.53 3.59 494653.85 716481.52 3.59 494651.84 716477.27 3.59 494639.69 716482.77 3.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494639.69 716482.77 3.59 494651.84 716477.27 3.59 494651.84 716477.27 7.965 494639.69 716482.77 7.965 494639.69 716482.77 3.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494651.84 716477.27 3.59 494653.85 716481.52 3.59 494653.85 716481.52 7.965 494651.84 716477.27 7.965 494651.84 716477.27 3.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494653.85 716481.52 3.59 494655.91 716480.53 3.59 494655.91 716480.53 7.965 494653.85 716481.52 7.965 494653.85 716481.52 3.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494655.91 716480.53 3.59 494657.17 716483.19 3.59 494657.17 716483.19 7.965 494655.91 716480.53 7.965 494655.91 716480.53 3.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494657.17 716483.19 3.59 494655.06 716484.11 3.59 494655.06 716484.11 7.965 494657.17 716483.19 7.965 494657.17 716483.19 3.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494655.06 716484.11 3.59 494650.48 716486.11 3.59 494650.48 716486.11 7.965 494655.06 716484.11 7.965 494655.06 716484.11 3.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494650.48 716486.11 3.59 494649.86 716484.69 3.59 494649.86 716484.69 7.965 494650.48 716486.11 7.965 494650.48 716486.11 3.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494649.86 716484.69 3.59 494644.19 716487.37 3.59 494644.19 716487.37 7.965 494649.86 716484.69 7.965 494649.86 716484.69 3.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494644.19 716487.37 3.59 494642.21 716488.29 3.59 494642.21 716488.29 7.965 494644.19 716487.37 7.965 494644.19 716487.37 3.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494642.21 716488.29 3.59 494639.69 716482.77 3.59 494639.69 716482.77 7.965 494642.21 716488.29 7.965 494642.21 716488.29 3.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-020A-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494639.69 716482.77 7.965 494651.84 716477.27 7.965 494653.85 716481.52 7.965 494655.91 716480.53 7.965 494657.17 716483.19 7.965 494655.06 716484.11 7.965 494650.48 716486.11 7.965 494649.86 716484.69 7.965 494644.19 716487.37 7.965 494642.21 716488.29 7.965 494639.69 716482.77 7.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494786.28 716295.53 3.83 494790.76 716306.84 3.83 494791.81 716309.49 3.83 494792.07 716310.16 3.83 494798.19 716307.7 3.83 494798.83 716305.85 3.83 494798.02 716303.93 3.83 494799.31 716303.4 3.83 494795.64 716294.51 3.83 494791.34 716296.26 3.83 494790.39 716293.87 3.83 494786.28 716295.53 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494786.28 716295.53 3.83 494790.39 716293.87 3.83 494790.39 716293.87 7.640000000000001 494786.28 716295.53 7.640000000000001 494786.28 716295.53 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494790.39 716293.87 3.83 494791.34 716296.26 3.83 494791.34 716296.26 7.640000000000001 494790.39 716293.87 7.640000000000001 494790.39 716293.87 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494791.34 716296.26 3.83 494795.64 716294.51 3.83 494795.64 716294.51 7.640000000000001 494791.34 716296.26 7.640000000000001 494791.34 716296.26 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494795.64 716294.51 3.83 494799.31 716303.4 3.83 494799.31 716303.4 7.640000000000001 494795.64 716294.51 7.640000000000001 494795.64 716294.51 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494799.31 716303.4 3.83 494798.02 716303.93 3.83 494798.02 716303.93 7.640000000000001 494799.31 716303.4 7.640000000000001 494799.31 716303.4 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494798.02 716303.93 3.83 494798.83 716305.85 3.83 494798.83 716305.85 7.640000000000001 494798.02 716303.93 7.640000000000001 494798.02 716303.93 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494798.83 716305.85 3.83 494798.19 716307.7 3.83 494798.19 716307.7 7.640000000000001 494798.83 716305.85 7.640000000000001 494798.83 716305.85 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494798.19 716307.7 3.83 494792.07 716310.16 3.83 494792.07 716310.16 7.640000000000001 494798.19 716307.7 7.640000000000001 494798.19 716307.7 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494792.07 716310.16 3.83 494791.81 716309.49 3.83 494791.81 716309.49 7.640000000000001 494792.07 716310.16 7.640000000000001 494792.07 716310.16 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494791.81 716309.49 3.83 494790.76 716306.84 3.83 494790.76 716306.84 7.640000000000001 494791.81 716309.49 7.640000000000001 494791.81 716309.49 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494790.76 716306.84 3.83 494786.28 716295.53 3.83 494786.28 716295.53 7.640000000000001 494790.76 716306.84 7.640000000000001 494790.76 716306.84 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02D2-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494786.28 716295.53 7.640000000000001 494790.39 716293.87 7.640000000000001 494791.34 716296.26 7.640000000000001 494795.64 716294.51 7.640000000000001 494799.31 716303.4 7.640000000000001 494798.02 716303.93 7.640000000000001 494798.83 716305.85 7.640000000000001 494798.19 716307.7 7.640000000000001 494792.07 716310.16 7.640000000000001 494791.81 716309.49 7.640000000000001 494790.76 716306.84 7.640000000000001 494786.28 716295.53 7.640000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D579-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D579-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.51</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D579-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494960.86 715114.98 4.47 494961.48 715130.4 4.47 494970.17 715130.13 4.47 494969.72 715114.76 4.47 494960.86 715114.98 4.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D579-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494960.86 715114.98 4.47 494969.72 715114.76 4.47 494969.72 715114.76 9.98 494960.86 715114.98 9.98 494960.86 715114.98 4.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D579-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494969.72 715114.76 4.47 494970.17 715130.13 4.47 494970.17 715130.13 9.98 494969.72 715114.76 9.98 494969.72 715114.76 4.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D579-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494970.17 715130.13 4.47 494961.48 715130.4 4.47 494961.48 715130.4 9.98 494970.17 715130.13 9.98 494970.17 715130.13 4.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D579-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494961.48 715130.4 4.47 494960.86 715114.98 4.47 494960.86 715114.98 9.98 494961.48 715130.4 9.98 494961.48 715130.4 4.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D579-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494960.86 715114.98 9.98 494969.72 715114.76 9.98 494970.17 715130.13 9.98 494961.48 715130.4 9.98 494960.86 715114.98 9.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D578-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D578-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.34</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D578-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494942.92 715888.48 3.94 494952.27 715896.85 3.94 494954.92 715893.84 3.94 494945.55 715885.43 3.94 494942.92 715888.48 3.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D578-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494942.92 715888.48 3.94 494945.55 715885.43 3.94 494945.55 715885.43 6.28 494942.92 715888.48 6.28 494942.92 715888.48 3.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D578-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494945.55 715885.43 3.94 494954.92 715893.84 3.94 494954.92 715893.84 6.28 494945.55 715885.43 6.28 494945.55 715885.43 3.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D578-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494954.92 715893.84 3.94 494952.27 715896.85 3.94 494952.27 715896.85 6.28 494954.92 715893.84 6.28 494954.92 715893.84 3.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D578-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494952.27 715896.85 3.94 494942.92 715888.48 3.94 494942.92 715888.48 6.28 494952.27 715896.85 6.28 494952.27 715896.85 3.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D578-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494942.92 715888.48 6.28 494945.55 715885.43 6.28 494954.92 715893.84 6.28 494952.27 715896.85 6.28 494942.92 715888.48 6.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc">
			<gen:stringAttribute name="buildingId">
				<gen:value>f7c2382d-df01-4b66-aa0a-e2267f9050cc</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.04</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494943.13 716283.41 3.48 494947.04 716293.29 3.48 494954.42 716290.37 3.48 494956.57 716295.89 3.48 494962.5 716293.55 3.48 494959.44 716285.8 3.48 494956.68 716286.91 3.48 494954.71 716281.93 3.48 494951.85 716283.02 3.48 494950.82 716280.38 3.48 494943.13 716283.41 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494943.13 716283.41 3.48 494950.82 716280.38 3.48 494950.82 716280.38 8.52 494943.13 716283.41 8.52 494943.13 716283.41 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494950.82 716280.38 3.48 494951.85 716283.02 3.48 494951.85 716283.02 8.52 494950.82 716280.38 8.52 494950.82 716280.38 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494951.85 716283.02 3.48 494954.71 716281.93 3.48 494954.71 716281.93 8.52 494951.85 716283.02 8.52 494951.85 716283.02 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494954.71 716281.93 3.48 494956.68 716286.91 3.48 494956.68 716286.91 8.52 494954.71 716281.93 8.52 494954.71 716281.93 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494956.68 716286.91 3.48 494959.44 716285.8 3.48 494959.44 716285.8 8.52 494956.68 716286.91 8.52 494956.68 716286.91 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494959.44 716285.8 3.48 494962.5 716293.55 3.48 494962.5 716293.55 8.52 494959.44 716285.8 8.52 494959.44 716285.8 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494962.5 716293.55 3.48 494956.57 716295.89 3.48 494956.57 716295.89 8.52 494962.5 716293.55 8.52 494962.5 716293.55 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494956.57 716295.89 3.48 494954.42 716290.37 3.48 494954.42 716290.37 8.52 494956.57 716295.89 8.52 494956.57 716295.89 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494954.42 716290.37 3.48 494947.04 716293.29 3.48 494947.04 716293.29 8.52 494954.42 716290.37 8.52 494954.42 716290.37 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494947.04 716293.29 3.48 494943.13 716283.41 3.48 494943.13 716283.41 8.52 494947.04 716293.29 8.52 494947.04 716293.29 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7c2382d-df01-4b66-aa0a-e2267f9050cc_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494943.13 716283.41 8.52 494950.82 716280.38 8.52 494951.85 716283.02 8.52 494954.71 716281.93 8.52 494956.68 716286.91 8.52 494959.44 716285.8 8.52 494962.5 716293.55 8.52 494956.57 716295.89 8.52 494954.42 716290.37 8.52 494947.04 716293.29 8.52 494943.13 716283.41 8.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.96</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494999.77 716187.45 3.67 495004.3 716198.29 3.67 495009.37 716196.22 3.67 495009.41 716196.33 3.67 495015.22 716193.95 3.67 495015.76 716195.21 3.67 495017.7 716194.41 3.67 495017.19 716193.16 3.67 495026.1 716189.5 3.67 495025.94 716189.09 3.67 495030.99 716187.02 3.67 495027.83 716179.34 3.67 495026.23 716179.98 3.67 495025.11 716177.41 3.67 495021.71 716178.8 3.67 495021.53 716178.38 3.67 495004.83 716185.2 3.67 495004.87 716185.32 3.67 494999.77 716187.45 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494999.77 716187.45 3.67 495004.87 716185.32 3.67 495004.87 716185.32 14.63 494999.77 716187.45 14.63 494999.77 716187.45 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495004.87 716185.32 3.67 495004.83 716185.2 3.67 495004.83 716185.2 14.63 495004.87 716185.32 14.63 495004.87 716185.32 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495004.83 716185.2 3.67 495021.53 716178.38 3.67 495021.53 716178.38 14.63 495004.83 716185.2 14.63 495004.83 716185.2 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495021.53 716178.38 3.67 495021.71 716178.8 3.67 495021.71 716178.8 14.63 495021.53 716178.38 14.63 495021.53 716178.38 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495021.71 716178.8 3.67 495025.11 716177.41 3.67 495025.11 716177.41 14.63 495021.71 716178.8 14.63 495021.71 716178.8 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495025.11 716177.41 3.67 495026.23 716179.98 3.67 495026.23 716179.98 14.63 495025.11 716177.41 14.63 495025.11 716177.41 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495026.23 716179.98 3.67 495027.83 716179.34 3.67 495027.83 716179.34 14.63 495026.23 716179.98 14.63 495026.23 716179.98 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495027.83 716179.34 3.67 495030.99 716187.02 3.67 495030.99 716187.02 14.63 495027.83 716179.34 14.63 495027.83 716179.34 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495030.99 716187.02 3.67 495025.94 716189.09 3.67 495025.94 716189.09 14.63 495030.99 716187.02 14.63 495030.99 716187.02 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495025.94 716189.09 3.67 495026.1 716189.5 3.67 495026.1 716189.5 14.63 495025.94 716189.09 14.63 495025.94 716189.09 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495026.1 716189.5 3.67 495017.19 716193.16 3.67 495017.19 716193.16 14.63 495026.1 716189.5 14.63 495026.1 716189.5 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495017.19 716193.16 3.67 495017.7 716194.41 3.67 495017.7 716194.41 14.63 495017.19 716193.16 14.63 495017.19 716193.16 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495017.7 716194.41 3.67 495015.76 716195.21 3.67 495015.76 716195.21 14.63 495017.7 716194.41 14.63 495017.7 716194.41 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495015.76 716195.21 3.67 495015.22 716193.95 3.67 495015.22 716193.95 14.63 495015.76 716195.21 14.63 495015.76 716195.21 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495015.22 716193.95 3.67 495009.41 716196.33 3.67 495009.41 716196.33 14.63 495015.22 716193.95 14.63 495015.22 716193.95 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495009.41 716196.33 3.67 495009.37 716196.22 3.67 495009.37 716196.22 14.63 495009.41 716196.33 14.63 495009.41 716196.33 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495009.37 716196.22 3.67 495004.3 716198.29 3.67 495004.3 716198.29 14.63 495009.37 716196.22 14.63 495009.37 716196.22 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>495004.3 716198.29 3.67 494999.77 716187.45 3.67 494999.77 716187.45 14.63 495004.3 716198.29 14.63 495004.3 716198.29 3.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27E5-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494999.77 716187.45 14.63 495004.87 716185.32 14.63 495004.83 716185.2 14.63 495021.53 716178.38 14.63 495021.71 716178.8 14.63 495025.11 716177.41 14.63 495026.23 716179.98 14.63 495027.83 716179.34 14.63 495030.99 716187.02 14.63 495025.94 716189.09 14.63 495026.1 716189.5 14.63 495017.19 716193.16 14.63 495017.7 716194.41 14.63 495015.76 716195.21 14.63 495015.22 716193.95 14.63 495009.41 716196.33 14.63 495009.37 716196.22 14.63 495004.3 716198.29 14.63 494999.77 716187.45 14.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C977-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C977-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.15</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C977-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494786.07 716189.59 3.51 494789.03 716196.92 3.51 494793.69 716194.98 3.51 494794.49 716196.86 3.51 494800.04 716194.56 3.51 494799.28 716192.67 3.51 494803.91 716190.82 3.51 494800.89 716183.53 3.51 494786.07 716189.59 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C977-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494786.07 716189.59 3.51 494800.89 716183.53 3.51 494800.89 716183.53 9.66 494786.07 716189.59 9.66 494786.07 716189.59 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C977-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494800.89 716183.53 3.51 494803.91 716190.82 3.51 494803.91 716190.82 9.66 494800.89 716183.53 9.66 494800.89 716183.53 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C977-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494803.91 716190.82 3.51 494799.28 716192.67 3.51 494799.28 716192.67 9.66 494803.91 716190.82 9.66 494803.91 716190.82 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C977-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494799.28 716192.67 3.51 494800.04 716194.56 3.51 494800.04 716194.56 9.66 494799.28 716192.67 9.66 494799.28 716192.67 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C977-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494800.04 716194.56 3.51 494794.49 716196.86 3.51 494794.49 716196.86 9.66 494800.04 716194.56 9.66 494800.04 716194.56 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C977-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494794.49 716196.86 3.51 494793.69 716194.98 3.51 494793.69 716194.98 9.66 494794.49 716196.86 9.66 494794.49 716196.86 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C977-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494793.69 716194.98 3.51 494789.03 716196.92 3.51 494789.03 716196.92 9.66 494793.69 716194.98 9.66 494793.69 716194.98 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C977-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494789.03 716196.92 3.51 494786.07 716189.59 3.51 494786.07 716189.59 9.66 494789.03 716196.92 9.66 494789.03 716196.92 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C977-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494786.07 716189.59 9.66 494800.89 716183.53 9.66 494803.91 716190.82 9.66 494799.28 716192.67 9.66 494800.04 716194.56 9.66 494794.49 716196.86 9.66 494793.69 716194.98 9.66 494789.03 716196.92 9.66 494786.07 716189.59 9.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-a535afe3-79c8-4b9c-9936-07b7b3c2c007">
			<gen:stringAttribute name="buildingId">
				<gen:value>a535afe3-79c8-4b9c-9936-07b7b3c2c007</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.96</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a535afe3-79c8-4b9c-9936-07b7b3c2c007_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494899.28 716137.8 3.4 494907.05 716156.89 3.4 494915.85 716153.31 3.4 494908.08 716134.22 3.4 494899.28 716137.8 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a535afe3-79c8-4b9c-9936-07b7b3c2c007_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494899.28 716137.8 3.4 494908.08 716134.22 3.4 494908.08 716134.22 8.36 494899.28 716137.8 8.36 494899.28 716137.8 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a535afe3-79c8-4b9c-9936-07b7b3c2c007_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494908.08 716134.22 3.4 494915.85 716153.31 3.4 494915.85 716153.31 8.36 494908.08 716134.22 8.36 494908.08 716134.22 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a535afe3-79c8-4b9c-9936-07b7b3c2c007_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494915.85 716153.31 3.4 494907.05 716156.89 3.4 494907.05 716156.89 8.36 494915.85 716153.31 8.36 494915.85 716153.31 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a535afe3-79c8-4b9c-9936-07b7b3c2c007_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494907.05 716156.89 3.4 494899.28 716137.8 3.4 494899.28 716137.8 8.36 494907.05 716156.89 8.36 494907.05 716156.89 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a535afe3-79c8-4b9c-9936-07b7b3c2c007_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494899.28 716137.8 8.36 494908.08 716134.22 8.36 494915.85 716153.31 8.36 494907.05 716156.89 8.36 494899.28 716137.8 8.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-762c5af1-9818-4bc0-804d-765021340a77">
			<gen:stringAttribute name="buildingId">
				<gen:value>762c5af1-9818-4bc0-804d-765021340a77</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.38</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-762c5af1-9818-4bc0-804d-765021340a77_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494836.53 716165.42 3.28 494840.95 716176.13 3.28 494866.89 716165.41 3.28 494866.1 716163.51 3.28 494883.99 716156.12 3.28 494879.68 716145.67 3.28 494860.58 716153.56 3.28 494861.26 716155.21 3.28 494836.53 716165.42 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-762c5af1-9818-4bc0-804d-765021340a77_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494836.53 716165.42 3.28 494861.26 716155.21 3.28 494861.26 716155.21 9.66 494836.53 716165.42 9.66 494836.53 716165.42 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-762c5af1-9818-4bc0-804d-765021340a77_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494861.26 716155.21 3.28 494860.58 716153.56 3.28 494860.58 716153.56 9.66 494861.26 716155.21 9.66 494861.26 716155.21 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-762c5af1-9818-4bc0-804d-765021340a77_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494860.58 716153.56 3.28 494879.68 716145.67 3.28 494879.68 716145.67 9.66 494860.58 716153.56 9.66 494860.58 716153.56 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-762c5af1-9818-4bc0-804d-765021340a77_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494879.68 716145.67 3.28 494883.99 716156.12 3.28 494883.99 716156.12 9.66 494879.68 716145.67 9.66 494879.68 716145.67 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-762c5af1-9818-4bc0-804d-765021340a77_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494883.99 716156.12 3.28 494866.1 716163.51 3.28 494866.1 716163.51 9.66 494883.99 716156.12 9.66 494883.99 716156.12 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-762c5af1-9818-4bc0-804d-765021340a77_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494866.1 716163.51 3.28 494866.89 716165.41 3.28 494866.89 716165.41 9.66 494866.1 716163.51 9.66 494866.1 716163.51 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-762c5af1-9818-4bc0-804d-765021340a77_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494866.89 716165.41 3.28 494840.95 716176.13 3.28 494840.95 716176.13 9.66 494866.89 716165.41 9.66 494866.89 716165.41 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-762c5af1-9818-4bc0-804d-765021340a77_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494840.95 716176.13 3.28 494836.53 716165.42 3.28 494836.53 716165.42 9.66 494840.95 716176.13 9.66 494840.95 716176.13 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-762c5af1-9818-4bc0-804d-765021340a77_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494836.53 716165.42 9.66 494861.26 716155.21 9.66 494860.58 716153.56 9.66 494879.68 716145.67 9.66 494883.99 716156.12 9.66 494866.1 716163.51 9.66 494866.89 716165.41 9.66 494840.95 716176.13 9.66 494836.53 716165.42 9.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-4b5689bc-bf41-4324-b847-d753edd9258b">
			<gen:stringAttribute name="buildingId">
				<gen:value>4b5689bc-bf41-4324-b847-d753edd9258b</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b5689bc-bf41-4324-b847-d753edd9258b_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494865.59 715686.47 4.11 494871.55 715691.8 4.11 494881.16 715680.54 4.11 494875.22 715675.46 4.11 494865.59 715686.47 4.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b5689bc-bf41-4324-b847-d753edd9258b_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494865.59 715686.47 4.11 494875.22 715675.46 4.11 494875.22 715675.46 10.05 494865.59 715686.47 10.05 494865.59 715686.47 4.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b5689bc-bf41-4324-b847-d753edd9258b_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494875.22 715675.46 4.11 494881.16 715680.54 4.11 494881.16 715680.54 10.05 494875.22 715675.46 10.05 494875.22 715675.46 4.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b5689bc-bf41-4324-b847-d753edd9258b_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494881.16 715680.54 4.11 494871.55 715691.8 4.11 494871.55 715691.8 10.05 494881.16 715680.54 10.05 494881.16 715680.54 4.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b5689bc-bf41-4324-b847-d753edd9258b_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494871.55 715691.8 4.11 494865.59 715686.47 4.11 494865.59 715686.47 10.05 494871.55 715691.8 10.05 494871.55 715691.8 4.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4b5689bc-bf41-4324-b847-d753edd9258b_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494865.59 715686.47 10.05 494875.22 715675.46 10.05 494881.16 715680.54 10.05 494871.55 715691.8 10.05 494865.59 715686.47 10.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-3736ade2-79fc-41cf-9d71-b0357d18450e">
			<gen:stringAttribute name="buildingId">
				<gen:value>3736ade2-79fc-41cf-9d71-b0357d18450e</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3736ade2-79fc-41cf-9d71-b0357d18450e_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494929.15 716125.96 3.33 494934.85 716139.62 3.33 494941.4 716136.89 3.33 494935.7 716123.22 3.33 494929.15 716125.96 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3736ade2-79fc-41cf-9d71-b0357d18450e_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494929.15 716125.96 3.33 494935.7 716123.22 3.33 494935.7 716123.22 7.86 494929.15 716125.96 7.86 494929.15 716125.96 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3736ade2-79fc-41cf-9d71-b0357d18450e_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494935.7 716123.22 3.33 494941.4 716136.89 3.33 494941.4 716136.89 7.86 494935.7 716123.22 7.86 494935.7 716123.22 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3736ade2-79fc-41cf-9d71-b0357d18450e_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494941.4 716136.89 3.33 494934.85 716139.62 3.33 494934.85 716139.62 7.86 494941.4 716136.89 7.86 494941.4 716136.89 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3736ade2-79fc-41cf-9d71-b0357d18450e_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494934.85 716139.62 3.33 494929.15 716125.96 3.33 494929.15 716125.96 7.86 494934.85 716139.62 7.86 494934.85 716139.62 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3736ade2-79fc-41cf-9d71-b0357d18450e_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494929.15 716125.96 7.86 494935.7 716123.22 7.86 494941.4 716136.89 7.86 494934.85 716139.62 7.86 494929.15 716125.96 7.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D4A8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D4A8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494884.22 715588.77 3.86 494884.22 715594.23 3.86 494892.08 715594.23 3.86 494892.08 715588.77 3.86 494884.22 715588.77 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494884.22 715588.77 3.86 494892.08 715588.77 3.86 494892.08 715588.77 6.8500000000000005 494884.22 715588.77 6.8500000000000005 494884.22 715588.77 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494892.08 715588.77 3.86 494892.08 715594.23 3.86 494892.08 715594.23 6.8500000000000005 494892.08 715588.77 6.8500000000000005 494892.08 715588.77 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494892.08 715594.23 3.86 494884.22 715594.23 3.86 494884.22 715594.23 6.8500000000000005 494892.08 715594.23 6.8500000000000005 494892.08 715594.23 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494884.22 715594.23 3.86 494884.22 715588.77 3.86 494884.22 715588.77 6.8500000000000005 494884.22 715594.23 6.8500000000000005 494884.22 715594.23 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494884.22 715588.77 6.8500000000000005 494892.08 715588.77 6.8500000000000005 494892.08 715594.23 6.8500000000000005 494884.22 715594.23 6.8500000000000005 494884.22 715588.77 6.8500000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D4A0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D4A0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494854.24 715643.27 4.1 494861.32 715644.96 4.1 494862.79 715638.84 4.1 494855.71 715637.15 4.1 494854.24 715643.27 4.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494854.24 715643.27 4.1 494855.71 715637.15 4.1 494855.71 715637.15 6.625 494854.24 715643.27 6.625 494854.24 715643.27 4.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494855.71 715637.15 4.1 494862.79 715638.84 4.1 494862.79 715638.84 6.625 494855.71 715637.15 6.625 494855.71 715637.15 4.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494862.79 715638.84 4.1 494861.32 715644.96 4.1 494861.32 715644.96 6.625 494862.79 715638.84 6.625 494862.79 715638.84 4.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494861.32 715644.96 4.1 494854.24 715643.27 4.1 494854.24 715643.27 6.625 494861.32 715644.96 6.625 494861.32 715644.96 4.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D4A0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494854.24 715643.27 6.625 494855.71 715637.15 6.625 494862.79 715638.84 6.625 494861.32 715644.96 6.625 494854.24 715643.27 6.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5F45-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5F45-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.09</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F45-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494825.55 715746.81 4.13 494828.25 715743.75 4.13 494819.48 715735.98 4.13 494816.77 715739.05 4.13 494825.55 715746.81 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F45-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494825.55 715746.81 4.13 494816.77 715739.05 4.13 494816.77 715739.05 7.22 494825.55 715746.81 7.22 494825.55 715746.81 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F45-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494816.77 715739.05 4.13 494819.48 715735.98 4.13 494819.48 715735.98 7.22 494816.77 715739.05 7.22 494816.77 715739.05 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F45-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494819.48 715735.98 4.13 494828.25 715743.75 4.13 494828.25 715743.75 7.22 494819.48 715735.98 7.22 494819.48 715735.98 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F45-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494828.25 715743.75 4.13 494825.55 715746.81 4.13 494825.55 715746.81 7.22 494828.25 715743.75 7.22 494828.25 715743.75 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F45-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>494825.55 715746.81 7.22 494816.77 715739.05 7.22 494819.48 715735.98 7.22 494828.25 715743.75 7.22 494825.55 715746.81 7.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
</CityModel>
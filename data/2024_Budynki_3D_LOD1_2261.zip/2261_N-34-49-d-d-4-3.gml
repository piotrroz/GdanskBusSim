<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0" xmlns="http://www.opengis.net/citygml/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
			<gml:lowerCorner>465132.34 719611.51 120.79</gml:lowerCorner>
			<gml:upperCorner>465483.56 721225.62 157.96</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.58</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465474.71 721044.39 135.72 465483.56 721040.58 135.72 465479.21 721030.31 135.72 465478.89 721030.48 135.72 465477.32 721026.92 135.72 465469.52 721030.37 135.72 465471.11 721033.96 135.72 465469.26 721034.78 135.72 465471.16 721039.02 135.72 465473.05 721038.3 135.72 465473.97 721040.58 135.72 465473.22 721040.91 135.72 465474.71 721044.39 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465474.71 721044.39 135.72 465473.22 721040.91 135.72 465473.22 721040.91 143.3 465474.71 721044.39 143.3 465474.71 721044.39 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465473.22 721040.91 135.72 465473.97 721040.58 135.72 465473.97 721040.58 143.3 465473.22 721040.91 143.3 465473.22 721040.91 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465473.97 721040.58 135.72 465473.05 721038.3 135.72 465473.05 721038.3 143.3 465473.97 721040.58 143.3 465473.97 721040.58 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465473.05 721038.3 135.72 465471.16 721039.02 135.72 465471.16 721039.02 143.3 465473.05 721038.3 143.3 465473.05 721038.3 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465471.16 721039.02 135.72 465469.26 721034.78 135.72 465469.26 721034.78 143.3 465471.16 721039.02 143.3 465471.16 721039.02 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465469.26 721034.78 135.72 465471.11 721033.96 135.72 465471.11 721033.96 143.3 465469.26 721034.78 143.3 465469.26 721034.78 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465471.11 721033.96 135.72 465469.52 721030.37 135.72 465469.52 721030.37 143.3 465471.11 721033.96 143.3 465471.11 721033.96 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465469.52 721030.37 135.72 465477.32 721026.92 135.72 465477.32 721026.92 143.3 465469.52 721030.37 143.3 465469.52 721030.37 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465477.32 721026.92 135.72 465478.89 721030.48 135.72 465478.89 721030.48 143.3 465477.32 721026.92 143.3 465477.32 721026.92 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465478.89 721030.48 135.72 465479.21 721030.31 135.72 465479.21 721030.31 143.3 465478.89 721030.48 143.3 465478.89 721030.48 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465479.21 721030.31 135.72 465483.56 721040.58 135.72 465483.56 721040.58 143.3 465479.21 721030.31 143.3 465479.21 721030.31 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465483.56 721040.58 135.72 465474.71 721044.39 135.72 465474.71 721044.39 143.3 465483.56 721040.58 143.3 465483.56 721040.58 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED87-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465474.71 721044.39 143.3 465473.22 721040.91 143.3 465473.97 721040.58 143.3 465473.05 721038.3 143.3 465471.16 721039.02 143.3 465469.26 721034.78 143.3 465471.11 721033.96 143.3 465469.52 721030.37 143.3 465477.32 721026.92 143.3 465478.89 721030.48 143.3 465479.21 721030.31 143.3 465483.56 721040.58 143.3 465474.71 721044.39 143.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E553-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.77</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465301.98 720899.71 136.42 465308.16 720909.53 136.42 465313.83 720906.1 136.42 465313.18 720905.03 136.42 465323.49 720898.79 136.42 465316.84 720888.1 136.42 465306.18 720894.64 136.42 465307.48 720896.71 136.42 465306.3 720897.46 136.42 465306.08 720897.12 136.42 465301.98 720899.71 136.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465301.98 720899.71 136.42 465306.08 720897.12 136.42 465306.08 720897.12 143.19 465301.98 720899.71 143.19 465301.98 720899.71 136.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465306.08 720897.12 136.42 465306.3 720897.46 136.42 465306.3 720897.46 143.19 465306.08 720897.12 143.19 465306.08 720897.12 136.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465306.3 720897.46 136.42 465307.48 720896.71 136.42 465307.48 720896.71 143.19 465306.3 720897.46 143.19 465306.3 720897.46 136.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465307.48 720896.71 136.42 465306.18 720894.64 136.42 465306.18 720894.64 143.19 465307.48 720896.71 143.19 465307.48 720896.71 136.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465306.18 720894.64 136.42 465316.84 720888.1 136.42 465316.84 720888.1 143.19 465306.18 720894.64 143.19 465306.18 720894.64 136.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465316.84 720888.1 136.42 465323.49 720898.79 136.42 465323.49 720898.79 143.19 465316.84 720888.1 143.19 465316.84 720888.1 136.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465323.49 720898.79 136.42 465313.18 720905.03 136.42 465313.18 720905.03 143.19 465323.49 720898.79 143.19 465323.49 720898.79 136.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465313.18 720905.03 136.42 465313.83 720906.1 136.42 465313.83 720906.1 143.19 465313.18 720905.03 143.19 465313.18 720905.03 136.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465313.83 720906.1 136.42 465308.16 720909.53 136.42 465308.16 720909.53 143.19 465313.83 720906.1 143.19 465313.83 720906.1 136.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465308.16 720909.53 136.42 465301.98 720899.71 136.42 465301.98 720899.71 143.19 465308.16 720909.53 143.19 465308.16 720909.53 136.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E553-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465301.98 720899.71 143.19 465306.08 720897.12 143.19 465306.3 720897.46 143.19 465307.48 720896.71 143.19 465306.18 720894.64 143.19 465316.84 720888.1 143.19 465323.49 720898.79 143.19 465313.18 720905.03 143.19 465313.83 720906.1 143.19 465308.16 720909.53 143.19 465301.98 720899.71 143.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-EEC7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-EEC7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EEC7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465424.68 720648.14 149.53 465433.63 720646.41 149.53 465433.85 720647.57 149.53 465437.49 720646.87 149.53 465435.74 720637.82 149.53 465432.52 720638.39 149.53 465432.19 720636.84 149.53 465422.86 720638.67 149.53 465424.68 720648.14 149.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EEC7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465424.68 720648.14 149.53 465422.86 720638.67 149.53 465422.86 720638.67 157.96 465424.68 720648.14 157.96 465424.68 720648.14 149.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EEC7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465422.86 720638.67 149.53 465432.19 720636.84 149.53 465432.19 720636.84 157.96 465422.86 720638.67 157.96 465422.86 720638.67 149.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EEC7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465432.19 720636.84 149.53 465432.52 720638.39 149.53 465432.52 720638.39 157.96 465432.19 720636.84 157.96 465432.19 720636.84 149.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EEC7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465432.52 720638.39 149.53 465435.74 720637.82 149.53 465435.74 720637.82 157.96 465432.52 720638.39 157.96 465432.52 720638.39 149.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EEC7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465435.74 720637.82 149.53 465437.49 720646.87 149.53 465437.49 720646.87 157.96 465435.74 720637.82 157.96 465435.74 720637.82 149.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EEC7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465437.49 720646.87 149.53 465433.85 720647.57 149.53 465433.85 720647.57 157.96 465437.49 720646.87 157.96 465437.49 720646.87 149.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EEC7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465433.85 720647.57 149.53 465433.63 720646.41 149.53 465433.63 720646.41 157.96 465433.85 720647.57 157.96 465433.85 720647.57 149.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EEC7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465433.63 720646.41 149.53 465424.68 720648.14 149.53 465424.68 720648.14 157.96 465433.63 720646.41 157.96 465433.63 720646.41 149.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EEC7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465424.68 720648.14 157.96 465422.86 720638.67 157.96 465432.19 720636.84 157.96 465432.52 720638.39 157.96 465435.74 720637.82 157.96 465437.49 720646.87 157.96 465433.85 720647.57 157.96 465433.63 720646.41 157.96 465424.68 720648.14 157.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.56</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465459.14 721198.92 135.15 465465.97 721195.3 135.15 465462.56 721188.85 135.15 465464.79 721187.68 135.15 465461.25 721181.06 135.15 465462.93 721180.16 135.15 465462.6 721179.52 135.15 465463.82 721178.84 135.15 465464.57 721176.2 135.15 465463.06 721173.36 135.15 465460.48 721172.49 135.15 465459.23 721173.19 135.15 465458.86 721172.56 135.15 465457.18 721173.43 135.15 465451.94 721163.64 135.15 465440.73 721169.62 135.15 465453.54 721193.62 135.15 465455.7 721192.48 135.15 465459.14 721198.92 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465459.14 721198.92 135.15 465455.7 721192.48 135.15 465455.7 721192.48 143.71 465459.14 721198.92 143.71 465459.14 721198.92 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465455.7 721192.48 135.15 465453.54 721193.62 135.15 465453.54 721193.62 143.71 465455.7 721192.48 143.71 465455.7 721192.48 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465453.54 721193.62 135.15 465440.73 721169.62 135.15 465440.73 721169.62 143.71 465453.54 721193.62 143.71 465453.54 721193.62 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465440.73 721169.62 135.15 465451.94 721163.64 135.15 465451.94 721163.64 143.71 465440.73 721169.62 143.71 465440.73 721169.62 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465451.94 721163.64 135.15 465457.18 721173.43 135.15 465457.18 721173.43 143.71 465451.94 721163.64 143.71 465451.94 721163.64 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465457.18 721173.43 135.15 465458.86 721172.56 135.15 465458.86 721172.56 143.71 465457.18 721173.43 143.71 465457.18 721173.43 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465458.86 721172.56 135.15 465459.23 721173.19 135.15 465459.23 721173.19 143.71 465458.86 721172.56 143.71 465458.86 721172.56 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465459.23 721173.19 135.15 465460.48 721172.49 135.15 465460.48 721172.49 143.71 465459.23 721173.19 143.71 465459.23 721173.19 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465460.48 721172.49 135.15 465463.06 721173.36 135.15 465463.06 721173.36 143.71 465460.48 721172.49 143.71 465460.48 721172.49 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465463.06 721173.36 135.15 465464.57 721176.2 135.15 465464.57 721176.2 143.71 465463.06 721173.36 143.71 465463.06 721173.36 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465464.57 721176.2 135.15 465463.82 721178.84 135.15 465463.82 721178.84 143.71 465464.57 721176.2 143.71 465464.57 721176.2 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465463.82 721178.84 135.15 465462.6 721179.52 135.15 465462.6 721179.52 143.71 465463.82 721178.84 143.71 465463.82 721178.84 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465462.6 721179.52 135.15 465462.93 721180.16 135.15 465462.93 721180.16 143.71 465462.6 721179.52 143.71 465462.6 721179.52 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465462.93 721180.16 135.15 465461.25 721181.06 135.15 465461.25 721181.06 143.71 465462.93 721180.16 143.71 465462.93 721180.16 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465461.25 721181.06 135.15 465464.79 721187.68 135.15 465464.79 721187.68 143.71 465461.25 721181.06 143.71 465461.25 721181.06 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465464.79 721187.68 135.15 465462.56 721188.85 135.15 465462.56 721188.85 143.71 465464.79 721187.68 143.71 465464.79 721187.68 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465462.56 721188.85 135.15 465465.97 721195.3 135.15 465465.97 721195.3 143.71 465462.56 721188.85 143.71 465462.56 721188.85 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465465.97 721195.3 135.15 465459.14 721198.92 135.15 465459.14 721198.92 143.71 465465.97 721195.3 143.71 465465.97 721195.3 135.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB3A-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465459.14 721198.92 143.71 465455.7 721192.48 143.71 465453.54 721193.62 143.71 465440.73 721169.62 143.71 465451.94 721163.64 143.71 465457.18 721173.43 143.71 465458.86 721172.56 143.71 465459.23 721173.19 143.71 465460.48 721172.49 143.71 465463.06 721173.36 143.71 465464.57 721176.2 143.71 465463.82 721178.84 143.71 465462.6 721179.52 143.71 465462.93 721180.16 143.71 465461.25 721181.06 143.71 465464.79 721187.68 143.71 465462.56 721188.85 143.71 465465.97 721195.3 143.71 465459.14 721198.92 143.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-710B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.14</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465371.64 720970.75 136.01 465388.28 720962.64 136.01 465386.44 720958.9 136.01 465384.58 720959.8 136.01 465380.74 720952.03 136.01 465375.31 720954.69 136.01 465374.68 720953.38 136.01 465367.44 720956.92 136.01 465370.26 720962.49 136.01 465368.1 720963.54 136.01 465371.64 720970.75 136.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465371.64 720970.75 136.01 465368.1 720963.54 136.01 465368.1 720963.54 142.15 465371.64 720970.75 142.15 465371.64 720970.75 136.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465368.1 720963.54 136.01 465370.26 720962.49 136.01 465370.26 720962.49 142.15 465368.1 720963.54 142.15 465368.1 720963.54 136.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465370.26 720962.49 136.01 465367.44 720956.92 136.01 465367.44 720956.92 142.15 465370.26 720962.49 142.15 465370.26 720962.49 136.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465367.44 720956.92 136.01 465374.68 720953.38 136.01 465374.68 720953.38 142.15 465367.44 720956.92 142.15 465367.44 720956.92 136.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465374.68 720953.38 136.01 465375.31 720954.69 136.01 465375.31 720954.69 142.15 465374.68 720953.38 142.15 465374.68 720953.38 136.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465375.31 720954.69 136.01 465380.74 720952.03 136.01 465380.74 720952.03 142.15 465375.31 720954.69 142.15 465375.31 720954.69 136.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465380.74 720952.03 136.01 465384.58 720959.8 136.01 465384.58 720959.8 142.15 465380.74 720952.03 142.15 465380.74 720952.03 136.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465384.58 720959.8 136.01 465386.44 720958.9 136.01 465386.44 720958.9 142.15 465384.58 720959.8 142.15 465384.58 720959.8 136.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465386.44 720958.9 136.01 465388.28 720962.64 136.01 465388.28 720962.64 142.15 465386.44 720958.9 142.15 465386.44 720958.9 136.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465388.28 720962.64 136.01 465371.64 720970.75 136.01 465371.64 720970.75 142.15 465388.28 720962.64 142.15 465388.28 720962.64 136.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710B-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465371.64 720970.75 142.15 465368.1 720963.54 142.15 465370.26 720962.49 142.15 465367.44 720956.92 142.15 465374.68 720953.38 142.15 465375.31 720954.69 142.15 465380.74 720952.03 142.15 465384.58 720959.8 142.15 465386.44 720958.9 142.15 465388.28 720962.64 142.15 465371.64 720970.75 142.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-710A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.72</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465226.31 721014.76 139.48 465240.61 721007.62 139.48 465240.51 721007.43 139.48 465244.83 721005.27 139.48 465244.93 721005.45 139.48 465245.37 721005.24 139.48 465244.33 721003.32 139.48 465245.11 721002.94 139.48 465245 721002.71 139.48 465244.28 721003.07 139.48 465243.3 721001.11 139.48 465244.02 721000.75 139.48 465243.9 721000.53 139.48 465243.11 721000.91 139.48 465242.09 720998.91 139.48 465232.93 721003.4 139.48 465232.24 721002.06 139.48 465228.98 721003.66 139.48 465227.69 721001 139.48 465228.8 721000.44 139.48 465226.03 720994.88 139.48 465219.68 720998.04 139.48 465223.83 721006.33 139.48 465223.54 721006.51 139.48 465223.66 721006.72 139.48 465223.97 721006.57 139.48 465224.74 721008.14 139.48 465223.39 721008.8 139.48 465226.31 721014.76 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465226.31 721014.76 139.48 465223.39 721008.8 139.48 465223.39 721008.8 146.20000000000002 465226.31 721014.76 146.20000000000002 465226.31 721014.76 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465223.39 721008.8 139.48 465224.74 721008.14 139.48 465224.74 721008.14 146.20000000000002 465223.39 721008.8 146.20000000000002 465223.39 721008.8 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465224.74 721008.14 139.48 465223.97 721006.57 139.48 465223.97 721006.57 146.20000000000002 465224.74 721008.14 146.20000000000002 465224.74 721008.14 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465223.97 721006.57 139.48 465223.66 721006.72 139.48 465223.66 721006.72 146.20000000000002 465223.97 721006.57 146.20000000000002 465223.97 721006.57 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465223.66 721006.72 139.48 465223.54 721006.51 139.48 465223.54 721006.51 146.20000000000002 465223.66 721006.72 146.20000000000002 465223.66 721006.72 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465223.54 721006.51 139.48 465223.83 721006.33 139.48 465223.83 721006.33 146.20000000000002 465223.54 721006.51 146.20000000000002 465223.54 721006.51 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465223.83 721006.33 139.48 465219.68 720998.04 139.48 465219.68 720998.04 146.20000000000002 465223.83 721006.33 146.20000000000002 465223.83 721006.33 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465219.68 720998.04 139.48 465226.03 720994.88 139.48 465226.03 720994.88 146.20000000000002 465219.68 720998.04 146.20000000000002 465219.68 720998.04 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465226.03 720994.88 139.48 465228.8 721000.44 139.48 465228.8 721000.44 146.20000000000002 465226.03 720994.88 146.20000000000002 465226.03 720994.88 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465228.8 721000.44 139.48 465227.69 721001 139.48 465227.69 721001 146.20000000000002 465228.8 721000.44 146.20000000000002 465228.8 721000.44 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465227.69 721001 139.48 465228.98 721003.66 139.48 465228.98 721003.66 146.20000000000002 465227.69 721001 146.20000000000002 465227.69 721001 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465228.98 721003.66 139.48 465232.24 721002.06 139.48 465232.24 721002.06 146.20000000000002 465228.98 721003.66 146.20000000000002 465228.98 721003.66 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465232.24 721002.06 139.48 465232.93 721003.4 139.48 465232.93 721003.4 146.20000000000002 465232.24 721002.06 146.20000000000002 465232.24 721002.06 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465232.93 721003.4 139.48 465242.09 720998.91 139.48 465242.09 720998.91 146.20000000000002 465232.93 721003.4 146.20000000000002 465232.93 721003.4 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465242.09 720998.91 139.48 465243.11 721000.91 139.48 465243.11 721000.91 146.20000000000002 465242.09 720998.91 146.20000000000002 465242.09 720998.91 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465243.11 721000.91 139.48 465243.9 721000.53 139.48 465243.9 721000.53 146.20000000000002 465243.11 721000.91 146.20000000000002 465243.11 721000.91 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465243.9 721000.53 139.48 465244.02 721000.75 139.48 465244.02 721000.75 146.20000000000002 465243.9 721000.53 146.20000000000002 465243.9 721000.53 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465244.02 721000.75 139.48 465243.3 721001.11 139.48 465243.3 721001.11 146.20000000000002 465244.02 721000.75 146.20000000000002 465244.02 721000.75 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465243.3 721001.11 139.48 465244.28 721003.07 139.48 465244.28 721003.07 146.20000000000002 465243.3 721001.11 146.20000000000002 465243.3 721001.11 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465244.28 721003.07 139.48 465245 721002.71 139.48 465245 721002.71 146.20000000000002 465244.28 721003.07 146.20000000000002 465244.28 721003.07 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465245 721002.71 139.48 465245.11 721002.94 139.48 465245.11 721002.94 146.20000000000002 465245 721002.71 146.20000000000002 465245 721002.71 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465245.11 721002.94 139.48 465244.33 721003.32 139.48 465244.33 721003.32 146.20000000000002 465245.11 721002.94 146.20000000000002 465245.11 721002.94 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465244.33 721003.32 139.48 465245.37 721005.24 139.48 465245.37 721005.24 146.20000000000002 465244.33 721003.32 146.20000000000002 465244.33 721003.32 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465245.37 721005.24 139.48 465244.93 721005.45 139.48 465244.93 721005.45 146.20000000000002 465245.37 721005.24 146.20000000000002 465245.37 721005.24 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465244.93 721005.45 139.48 465244.83 721005.27 139.48 465244.83 721005.27 146.20000000000002 465244.93 721005.45 146.20000000000002 465244.93 721005.45 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465244.83 721005.27 139.48 465240.51 721007.43 139.48 465240.51 721007.43 146.20000000000002 465244.83 721005.27 146.20000000000002 465244.83 721005.27 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465240.51 721007.43 139.48 465240.61 721007.62 139.48 465240.61 721007.62 146.20000000000002 465240.51 721007.43 146.20000000000002 465240.51 721007.43 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465240.61 721007.62 139.48 465226.31 721014.76 139.48 465226.31 721014.76 146.20000000000002 465240.61 721007.62 146.20000000000002 465240.61 721007.62 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-710A-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465226.31 721014.76 146.20000000000002 465223.39 721008.8 146.20000000000002 465224.74 721008.14 146.20000000000002 465223.97 721006.57 146.20000000000002 465223.66 721006.72 146.20000000000002 465223.54 721006.51 146.20000000000002 465223.83 721006.33 146.20000000000002 465219.68 720998.04 146.20000000000002 465226.03 720994.88 146.20000000000002 465228.8 721000.44 146.20000000000002 465227.69 721001 146.20000000000002 465228.98 721003.66 146.20000000000002 465232.24 721002.06 146.20000000000002 465232.93 721003.4 146.20000000000002 465242.09 720998.91 146.20000000000002 465243.11 721000.91 146.20000000000002 465243.9 721000.53 146.20000000000002 465244.02 721000.75 146.20000000000002 465243.3 721001.11 146.20000000000002 465244.28 721003.07 146.20000000000002 465245 721002.71 146.20000000000002 465245.11 721002.94 146.20000000000002 465244.33 721003.32 146.20000000000002 465245.37 721005.24 146.20000000000002 465244.93 721005.45 146.20000000000002 465244.83 721005.27 146.20000000000002 465240.51 721007.43 146.20000000000002 465240.61 721007.62 146.20000000000002 465226.31 721014.76 146.20000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.76</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465428.35 721129.79 134.42 465420.72 721133.79 134.42 465426.09 721144.06 134.42 465429 721149.61 134.42 465438.28 721144.69 134.42 465435.19 721138.88 134.42 465436.19 721138.32 134.42 465434.41 721134.96 134.42 465431.7 721136.34 134.42 465430.03 721133.07 134.42 465428.35 721129.79 134.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465428.35 721129.79 134.42 465430.03 721133.07 134.42 465430.03 721133.07 143.18 465428.35 721129.79 143.18 465428.35 721129.79 134.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465430.03 721133.07 134.42 465431.7 721136.34 134.42 465431.7 721136.34 143.18 465430.03 721133.07 143.18 465430.03 721133.07 134.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465431.7 721136.34 134.42 465434.41 721134.96 134.42 465434.41 721134.96 143.18 465431.7 721136.34 143.18 465431.7 721136.34 134.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465434.41 721134.96 134.42 465436.19 721138.32 134.42 465436.19 721138.32 143.18 465434.41 721134.96 143.18 465434.41 721134.96 134.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465436.19 721138.32 134.42 465435.19 721138.88 134.42 465435.19 721138.88 143.18 465436.19 721138.32 143.18 465436.19 721138.32 134.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465435.19 721138.88 134.42 465438.28 721144.69 134.42 465438.28 721144.69 143.18 465435.19 721138.88 143.18 465435.19 721138.88 134.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465438.28 721144.69 134.42 465429 721149.61 134.42 465429 721149.61 143.18 465438.28 721144.69 143.18 465438.28 721144.69 134.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465429 721149.61 134.42 465426.09 721144.06 134.42 465426.09 721144.06 143.18 465429 721149.61 143.18 465429 721149.61 134.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465426.09 721144.06 134.42 465420.72 721133.79 134.42 465420.72 721133.79 143.18 465426.09 721144.06 143.18 465426.09 721144.06 134.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465420.72 721133.79 134.42 465428.35 721129.79 134.42 465428.35 721129.79 143.18 465420.72 721133.79 143.18 465420.72 721133.79 134.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E9FB-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465428.35 721129.79 143.18 465430.03 721133.07 143.18 465431.7 721136.34 143.18 465434.41 721134.96 143.18 465436.19 721138.32 143.18 465435.19 721138.88 143.18 465438.28 721144.69 143.18 465429 721149.61 143.18 465426.09 721144.06 143.18 465420.72 721133.79 143.18 465428.35 721129.79 143.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C57B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C57B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.13</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C57B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465331.42 720901.89 136.82 465337 720898.3 136.82 465330.34 720887.93 136.82 465324.74 720891.49 136.82 465331.42 720901.89 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C57B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465331.42 720901.89 136.82 465324.74 720891.49 136.82 465324.74 720891.49 139.95000000000002 465331.42 720901.89 139.95000000000002 465331.42 720901.89 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C57B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465324.74 720891.49 136.82 465330.34 720887.93 136.82 465330.34 720887.93 139.95000000000002 465324.74 720891.49 139.95000000000002 465324.74 720891.49 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C57B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465330.34 720887.93 136.82 465337 720898.3 136.82 465337 720898.3 139.95000000000002 465330.34 720887.93 139.95000000000002 465330.34 720887.93 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C57B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465337 720898.3 136.82 465331.42 720901.89 136.82 465331.42 720901.89 139.95000000000002 465337 720898.3 139.95000000000002 465337 720898.3 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C57B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465331.42 720901.89 139.95000000000002 465324.74 720891.49 139.95000000000002 465330.34 720887.93 139.95000000000002 465337 720898.3 139.95000000000002 465331.42 720901.89 139.95000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C640-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465310.05 720861.06 137.04 465317.73 720871.18 137.04 465319.26 720873.21 137.04 465324.46 720869.1 137.04 465323.46 720867.76 137.04 465324.55 720866.81 137.04 465325.2 720865.91 137.04 465325.84 720864.94 137.04 465326.14 720863.91 137.04 465326.14 720862.74 137.04 465325.82 720861.69 137.04 465325.27 720860.67 137.04 465327.25 720859.02 137.04 465321.64 720851.92 137.04 465310.05 720861.06 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465310.05 720861.06 137.04 465321.64 720851.92 137.04 465321.64 720851.92 141.36 465310.05 720861.06 141.36 465310.05 720861.06 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465321.64 720851.92 137.04 465327.25 720859.02 137.04 465327.25 720859.02 141.36 465321.64 720851.92 141.36 465321.64 720851.92 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465327.25 720859.02 137.04 465325.27 720860.67 137.04 465325.27 720860.67 141.36 465327.25 720859.02 141.36 465327.25 720859.02 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465325.27 720860.67 137.04 465325.82 720861.69 137.04 465325.82 720861.69 141.36 465325.27 720860.67 141.36 465325.27 720860.67 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465325.82 720861.69 137.04 465326.14 720862.74 137.04 465326.14 720862.74 141.36 465325.82 720861.69 141.36 465325.82 720861.69 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465326.14 720862.74 137.04 465326.14 720863.91 137.04 465326.14 720863.91 141.36 465326.14 720862.74 141.36 465326.14 720862.74 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465326.14 720863.91 137.04 465325.84 720864.94 137.04 465325.84 720864.94 141.36 465326.14 720863.91 141.36 465326.14 720863.91 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465325.84 720864.94 137.04 465325.2 720865.91 137.04 465325.2 720865.91 141.36 465325.84 720864.94 141.36 465325.84 720864.94 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465325.2 720865.91 137.04 465324.55 720866.81 137.04 465324.55 720866.81 141.36 465325.2 720865.91 141.36 465325.2 720865.91 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465324.55 720866.81 137.04 465323.46 720867.76 137.04 465323.46 720867.76 141.36 465324.55 720866.81 141.36 465324.55 720866.81 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465323.46 720867.76 137.04 465324.46 720869.1 137.04 465324.46 720869.1 141.36 465323.46 720867.76 141.36 465323.46 720867.76 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465324.46 720869.1 137.04 465319.26 720873.21 137.04 465319.26 720873.21 141.36 465324.46 720869.1 141.36 465324.46 720869.1 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465319.26 720873.21 137.04 465317.73 720871.18 137.04 465317.73 720871.18 141.36 465319.26 720873.21 141.36 465319.26 720873.21 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465317.73 720871.18 137.04 465310.05 720861.06 137.04 465310.05 720861.06 141.36 465317.73 720871.18 141.36 465317.73 720871.18 137.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C640-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465310.05 720861.06 141.36 465321.64 720851.92 141.36 465327.25 720859.02 141.36 465325.27 720860.67 141.36 465325.82 720861.69 141.36 465326.14 720862.74 141.36 465326.14 720863.91 141.36 465325.84 720864.94 141.36 465325.2 720865.91 141.36 465324.55 720866.81 141.36 465323.46 720867.76 141.36 465324.46 720869.1 141.36 465319.26 720873.21 141.36 465317.73 720871.18 141.36 465310.05 720861.06 141.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E7FC-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E7FC-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.01</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E7FC-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465439.72 720188.65 136.82 465450.51 720184.38 136.82 465447.87 720177.8 136.82 465443.77 720179.42 136.82 465443.37 720178.45 136.82 465438.99 720180.19 136.82 465441.06 720185.44 136.82 465438.8 720186.35 136.82 465439.72 720188.65 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E7FC-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465439.72 720188.65 136.82 465438.8 720186.35 136.82 465438.8 720186.35 143.83 465439.72 720188.65 143.83 465439.72 720188.65 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E7FC-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465438.8 720186.35 136.82 465441.06 720185.44 136.82 465441.06 720185.44 143.83 465438.8 720186.35 143.83 465438.8 720186.35 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E7FC-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465441.06 720185.44 136.82 465438.99 720180.19 136.82 465438.99 720180.19 143.83 465441.06 720185.44 143.83 465441.06 720185.44 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E7FC-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465438.99 720180.19 136.82 465443.37 720178.45 136.82 465443.37 720178.45 143.83 465438.99 720180.19 143.83 465438.99 720180.19 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E7FC-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465443.37 720178.45 136.82 465443.77 720179.42 136.82 465443.77 720179.42 143.83 465443.37 720178.45 143.83 465443.37 720178.45 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E7FC-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465443.77 720179.42 136.82 465447.87 720177.8 136.82 465447.87 720177.8 143.83 465443.77 720179.42 143.83 465443.77 720179.42 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E7FC-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465447.87 720177.8 136.82 465450.51 720184.38 136.82 465450.51 720184.38 143.83 465447.87 720177.8 143.83 465447.87 720177.8 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E7FC-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465450.51 720184.38 136.82 465439.72 720188.65 136.82 465439.72 720188.65 143.83 465450.51 720184.38 143.83 465450.51 720184.38 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E7FC-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465439.72 720188.65 143.83 465438.8 720186.35 143.83 465441.06 720185.44 143.83 465438.99 720180.19 143.83 465443.37 720178.45 143.83 465443.77 720179.42 143.83 465447.87 720177.8 143.83 465450.51 720184.38 143.83 465439.72 720188.65 143.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C43A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C43A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.78</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C43A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465331.61 721225.62 138.1 465340.03 721221.15 138.1 465337.03 721215.51 138.1 465336.86 721215.6 138.1 465336.57 721215.08 138.1 465328.36 721219.51 138.1 465331.61 721225.62 138.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C43A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465331.61 721225.62 138.1 465328.36 721219.51 138.1 465328.36 721219.51 142.88 465331.61 721225.62 142.88 465331.61 721225.62 138.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C43A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465328.36 721219.51 138.1 465336.57 721215.08 138.1 465336.57 721215.08 142.88 465328.36 721219.51 142.88 465328.36 721219.51 138.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C43A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465336.57 721215.08 138.1 465336.86 721215.6 138.1 465336.86 721215.6 142.88 465336.57 721215.08 142.88 465336.57 721215.08 138.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C43A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465336.86 721215.6 138.1 465337.03 721215.51 138.1 465337.03 721215.51 142.88 465336.86 721215.6 142.88 465336.86 721215.6 138.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C43A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465337.03 721215.51 138.1 465340.03 721221.15 138.1 465340.03 721221.15 142.88 465337.03 721215.51 142.88 465337.03 721215.51 138.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C43A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465340.03 721221.15 138.1 465331.61 721225.62 138.1 465331.61 721225.62 142.88 465340.03 721221.15 142.88 465340.03 721221.15 138.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C43A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465331.61 721225.62 142.88 465328.36 721219.51 142.88 465336.57 721215.08 142.88 465336.86 721215.6 142.88 465337.03 721215.51 142.88 465340.03 721221.15 142.88 465331.61 721225.62 142.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6172-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.66</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.03 720801.35 140.65 465424.84 720793.67 140.65 465421.71 720790.88 140.65 465423.14 720789.21 140.65 465415.37 720782.51 140.65 465413.92 720784.21 140.65 465410.74 720781.45 140.65 465403.99 720789.25 140.65 465407.1 720792 140.65 465405.73 720793.44 140.65 465413.39 720800.24 140.65 465414.89 720798.56 140.65 465418.03 720801.35 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.03 720801.35 140.65 465414.89 720798.56 140.65 465414.89 720798.56 151.31 465418.03 720801.35 151.31 465418.03 720801.35 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465414.89 720798.56 140.65 465413.39 720800.24 140.65 465413.39 720800.24 151.31 465414.89 720798.56 151.31 465414.89 720798.56 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465413.39 720800.24 140.65 465405.73 720793.44 140.65 465405.73 720793.44 151.31 465413.39 720800.24 151.31 465413.39 720800.24 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465405.73 720793.44 140.65 465407.1 720792 140.65 465407.1 720792 151.31 465405.73 720793.44 151.31 465405.73 720793.44 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465407.1 720792 140.65 465403.99 720789.25 140.65 465403.99 720789.25 151.31 465407.1 720792 151.31 465407.1 720792 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465403.99 720789.25 140.65 465410.74 720781.45 140.65 465410.74 720781.45 151.31 465403.99 720789.25 151.31 465403.99 720789.25 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465410.74 720781.45 140.65 465413.92 720784.21 140.65 465413.92 720784.21 151.31 465410.74 720781.45 151.31 465410.74 720781.45 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465413.92 720784.21 140.65 465415.37 720782.51 140.65 465415.37 720782.51 151.31 465413.92 720784.21 151.31 465413.92 720784.21 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465415.37 720782.51 140.65 465423.14 720789.21 140.65 465423.14 720789.21 151.31 465415.37 720782.51 151.31 465415.37 720782.51 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465423.14 720789.21 140.65 465421.71 720790.88 140.65 465421.71 720790.88 151.31 465423.14 720789.21 151.31 465423.14 720789.21 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465421.71 720790.88 140.65 465424.84 720793.67 140.65 465424.84 720793.67 151.31 465421.71 720790.88 151.31 465421.71 720790.88 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465424.84 720793.67 140.65 465418.03 720801.35 140.65 465418.03 720801.35 151.31 465424.84 720793.67 151.31 465424.84 720793.67 140.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6172-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.03 720801.35 151.31 465414.89 720798.56 151.31 465413.39 720800.24 151.31 465405.73 720793.44 151.31 465407.1 720792 151.31 465403.99 720789.25 151.31 465410.74 720781.45 151.31 465413.92 720784.21 151.31 465415.37 720782.51 151.31 465423.14 720789.21 151.31 465421.71 720790.88 151.31 465424.84 720793.67 151.31 465418.03 720801.35 151.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7110-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7110-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.91</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7110-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465406.68 720699.9 144.99 465412.11 720702.53 144.99 465414.67 720697.07 144.99 465409.21 720694.51 144.99 465406.68 720699.9 144.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7110-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465406.68 720699.9 144.99 465409.21 720694.51 144.99 465409.21 720694.51 149.9 465406.68 720699.9 149.9 465406.68 720699.9 144.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7110-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465409.21 720694.51 144.99 465414.67 720697.07 144.99 465414.67 720697.07 149.9 465409.21 720694.51 149.9 465409.21 720694.51 144.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7110-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465414.67 720697.07 144.99 465412.11 720702.53 144.99 465412.11 720702.53 149.9 465414.67 720697.07 149.9 465414.67 720697.07 144.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7110-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465412.11 720702.53 144.99 465406.68 720699.9 144.99 465406.68 720699.9 149.9 465412.11 720702.53 149.9 465412.11 720702.53 144.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7110-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465406.68 720699.9 149.9 465409.21 720694.51 149.9 465414.67 720697.07 149.9 465412.11 720702.53 149.9 465406.68 720699.9 149.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.22</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465395.04 721224.62 137.38 465401.56 721221.88 137.38 465400.01 721218.22 137.38 465402.4 721217.23 137.38 465400.81 721213.5 137.38 465402.09 721212.92 137.38 465402.61 721212.62 137.38 465403.05 721211.95 137.38 465403.47 721210.87 137.38 465403.46 721209.91 137.38 465403.21 721209.25 137.38 465402.77 721208.56 137.38 465401.99 721207.97 137.38 465401.43 721207.77 137.38 465400.61 721207.59 137.38 465399.7 721207.77 137.38 465398.48 721208.12 137.38 465396.91 721204.4 137.38 465394.65 721205.3 137.38 465392.83 721201.06 137.38 465386.31 721203.79 137.38 465395.04 721224.62 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465395.04 721224.62 137.38 465386.31 721203.79 137.38 465386.31 721203.79 144.6 465395.04 721224.62 144.6 465395.04 721224.62 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465386.31 721203.79 137.38 465392.83 721201.06 137.38 465392.83 721201.06 144.6 465386.31 721203.79 144.6 465386.31 721203.79 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465392.83 721201.06 137.38 465394.65 721205.3 137.38 465394.65 721205.3 144.6 465392.83 721201.06 144.6 465392.83 721201.06 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465394.65 721205.3 137.38 465396.91 721204.4 137.38 465396.91 721204.4 144.6 465394.65 721205.3 144.6 465394.65 721205.3 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465396.91 721204.4 137.38 465398.48 721208.12 137.38 465398.48 721208.12 144.6 465396.91 721204.4 144.6 465396.91 721204.4 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465398.48 721208.12 137.38 465399.7 721207.77 137.38 465399.7 721207.77 144.6 465398.48 721208.12 144.6 465398.48 721208.12 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465399.7 721207.77 137.38 465400.61 721207.59 137.38 465400.61 721207.59 144.6 465399.7 721207.77 144.6 465399.7 721207.77 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465400.61 721207.59 137.38 465401.43 721207.77 137.38 465401.43 721207.77 144.6 465400.61 721207.59 144.6 465400.61 721207.59 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465401.43 721207.77 137.38 465401.99 721207.97 137.38 465401.99 721207.97 144.6 465401.43 721207.77 144.6 465401.43 721207.77 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465401.99 721207.97 137.38 465402.77 721208.56 137.38 465402.77 721208.56 144.6 465401.99 721207.97 144.6 465401.99 721207.97 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465402.77 721208.56 137.38 465403.21 721209.25 137.38 465403.21 721209.25 144.6 465402.77 721208.56 144.6 465402.77 721208.56 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465403.21 721209.25 137.38 465403.46 721209.91 137.38 465403.46 721209.91 144.6 465403.21 721209.25 144.6 465403.21 721209.25 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465403.46 721209.91 137.38 465403.47 721210.87 137.38 465403.47 721210.87 144.6 465403.46 721209.91 144.6 465403.46 721209.91 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465403.47 721210.87 137.38 465403.05 721211.95 137.38 465403.05 721211.95 144.6 465403.47 721210.87 144.6 465403.47 721210.87 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465403.05 721211.95 137.38 465402.61 721212.62 137.38 465402.61 721212.62 144.6 465403.05 721211.95 144.6 465403.05 721211.95 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465402.61 721212.62 137.38 465402.09 721212.92 137.38 465402.09 721212.92 144.6 465402.61 721212.62 144.6 465402.61 721212.62 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465402.09 721212.92 137.38 465400.81 721213.5 137.38 465400.81 721213.5 144.6 465402.09 721212.92 144.6 465402.09 721212.92 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465400.81 721213.5 137.38 465402.4 721217.23 137.38 465402.4 721217.23 144.6 465400.81 721213.5 144.6 465400.81 721213.5 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465402.4 721217.23 137.38 465400.01 721218.22 137.38 465400.01 721218.22 144.6 465402.4 721217.23 144.6 465402.4 721217.23 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465400.01 721218.22 137.38 465401.56 721221.88 137.38 465401.56 721221.88 144.6 465400.01 721218.22 144.6 465400.01 721218.22 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465401.56 721221.88 137.38 465395.04 721224.62 137.38 465395.04 721224.62 144.6 465401.56 721221.88 144.6 465401.56 721221.88 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E6DF-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465395.04 721224.62 144.6 465386.31 721203.79 144.6 465392.83 721201.06 144.6 465394.65 721205.3 144.6 465396.91 721204.4 144.6 465398.48 721208.12 144.6 465399.7 721207.77 144.6 465400.61 721207.59 144.6 465401.43 721207.77 144.6 465401.99 721207.97 144.6 465402.77 721208.56 144.6 465403.21 721209.25 144.6 465403.46 721209.91 144.6 465403.47 721210.87 144.6 465403.05 721211.95 144.6 465402.61 721212.62 144.6 465402.09 721212.92 144.6 465400.81 721213.5 144.6 465402.4 721217.23 144.6 465400.01 721218.22 144.6 465401.56 721221.88 144.6 465395.04 721224.62 144.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7109-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.33</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465236.86 721031.55 139.57 465239.59 721037.06 139.57 465238.49 721037.6 139.57 465239.63 721039.92 139.57 465245.83 721036.82 139.57 465245.3 721035.73 139.57 465253.35 721031.79 139.57 465261.42 721027.83 139.57 465261.97 721028.9 139.57 465268.22 721025.86 139.57 465267.06 721023.57 139.57 465265.95 721024.12 139.57 465263.22 721018.61 139.57 465258.63 721020.85 139.57 465258.16 721019.89 139.57 465257.61 721020.15 139.57 465257.92 721020.75 139.57 465249.87 721024.7 139.57 465241.82 721028.67 139.57 465241.53 721028.05 139.57 465240.95 721028.33 139.57 465241.43 721029.3 139.57 465236.86 721031.55 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465236.86 721031.55 139.57 465241.43 721029.3 139.57 465241.43 721029.3 145.9 465236.86 721031.55 145.9 465236.86 721031.55 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465241.43 721029.3 139.57 465240.95 721028.33 139.57 465240.95 721028.33 145.9 465241.43 721029.3 145.9 465241.43 721029.3 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465240.95 721028.33 139.57 465241.53 721028.05 139.57 465241.53 721028.05 145.9 465240.95 721028.33 145.9 465240.95 721028.33 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465241.53 721028.05 139.57 465241.82 721028.67 139.57 465241.82 721028.67 145.9 465241.53 721028.05 145.9 465241.53 721028.05 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465241.82 721028.67 139.57 465249.87 721024.7 139.57 465249.87 721024.7 145.9 465241.82 721028.67 145.9 465241.82 721028.67 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465249.87 721024.7 139.57 465257.92 721020.75 139.57 465257.92 721020.75 145.9 465249.87 721024.7 145.9 465249.87 721024.7 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465257.92 721020.75 139.57 465257.61 721020.15 139.57 465257.61 721020.15 145.9 465257.92 721020.75 145.9 465257.92 721020.75 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465257.61 721020.15 139.57 465258.16 721019.89 139.57 465258.16 721019.89 145.9 465257.61 721020.15 145.9 465257.61 721020.15 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465258.16 721019.89 139.57 465258.63 721020.85 139.57 465258.63 721020.85 145.9 465258.16 721019.89 145.9 465258.16 721019.89 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465258.63 721020.85 139.57 465263.22 721018.61 139.57 465263.22 721018.61 145.9 465258.63 721020.85 145.9 465258.63 721020.85 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465263.22 721018.61 139.57 465265.95 721024.12 139.57 465265.95 721024.12 145.9 465263.22 721018.61 145.9 465263.22 721018.61 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465265.95 721024.12 139.57 465267.06 721023.57 139.57 465267.06 721023.57 145.9 465265.95 721024.12 145.9 465265.95 721024.12 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465267.06 721023.57 139.57 465268.22 721025.86 139.57 465268.22 721025.86 145.9 465267.06 721023.57 145.9 465267.06 721023.57 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465268.22 721025.86 139.57 465261.97 721028.9 139.57 465261.97 721028.9 145.9 465268.22 721025.86 145.9 465268.22 721025.86 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465261.97 721028.9 139.57 465261.42 721027.83 139.57 465261.42 721027.83 145.9 465261.97 721028.9 145.9 465261.97 721028.9 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465261.42 721027.83 139.57 465253.35 721031.79 139.57 465253.35 721031.79 145.9 465261.42 721027.83 145.9 465261.42 721027.83 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465253.35 721031.79 139.57 465245.3 721035.73 139.57 465245.3 721035.73 145.9 465253.35 721031.79 145.9 465253.35 721031.79 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465245.3 721035.73 139.57 465245.83 721036.82 139.57 465245.83 721036.82 145.9 465245.3 721035.73 145.9 465245.3 721035.73 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465245.83 721036.82 139.57 465239.63 721039.92 139.57 465239.63 721039.92 145.9 465245.83 721036.82 145.9 465245.83 721036.82 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465239.63 721039.92 139.57 465238.49 721037.6 139.57 465238.49 721037.6 145.9 465239.63 721039.92 145.9 465239.63 721039.92 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465238.49 721037.6 139.57 465239.59 721037.06 139.57 465239.59 721037.06 145.9 465238.49 721037.6 145.9 465238.49 721037.6 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465239.59 721037.06 139.57 465236.86 721031.55 139.57 465236.86 721031.55 145.9 465239.59 721037.06 145.9 465239.59 721037.06 139.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7109-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465236.86 721031.55 145.9 465241.43 721029.3 145.9 465240.95 721028.33 145.9 465241.53 721028.05 145.9 465241.82 721028.67 145.9 465249.87 721024.7 145.9 465257.92 721020.75 145.9 465257.61 721020.15 145.9 465258.16 721019.89 145.9 465258.63 721020.85 145.9 465263.22 721018.61 145.9 465265.95 721024.12 145.9 465267.06 721023.57 145.9 465268.22 721025.86 145.9 465261.97 721028.9 145.9 465261.42 721027.83 145.9 465253.35 721031.79 145.9 465245.3 721035.73 145.9 465245.83 721036.82 145.9 465239.63 721039.92 145.9 465238.49 721037.6 145.9 465239.59 721037.06 145.9 465236.86 721031.55 145.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C372-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C372-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.98</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C372-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465457.08 721118.49 134.38 465473.26 721109.68 134.38 465465.19 721094.49 134.38 465448.95 721103.21 134.38 465457.08 721118.49 134.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C372-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465457.08 721118.49 134.38 465448.95 721103.21 134.38 465448.95 721103.21 140.36 465457.08 721118.49 140.36 465457.08 721118.49 134.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C372-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465448.95 721103.21 134.38 465465.19 721094.49 134.38 465465.19 721094.49 140.36 465448.95 721103.21 140.36 465448.95 721103.21 134.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C372-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465465.19 721094.49 134.38 465473.26 721109.68 134.38 465473.26 721109.68 140.36 465465.19 721094.49 140.36 465465.19 721094.49 134.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C372-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465473.26 721109.68 134.38 465457.08 721118.49 134.38 465457.08 721118.49 140.36 465473.26 721109.68 140.36 465473.26 721109.68 134.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C372-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465457.08 721118.49 140.36 465448.95 721103.21 140.36 465465.19 721094.49 140.36 465473.26 721109.68 140.36 465457.08 721118.49 140.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5445-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5445-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.51</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5445-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465431.15 720723.35 145.03 465437.49 720711.7 145.03 465425.91 720705.33 145.03 465419.53 720717.01 145.03 465422.12 720718.42 145.03 465428.53 720721.94 145.03 465431.15 720723.35 145.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5445-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465431.15 720723.35 145.03 465428.53 720721.94 145.03 465428.53 720721.94 151.54 465431.15 720723.35 151.54 465431.15 720723.35 145.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5445-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465428.53 720721.94 145.03 465422.12 720718.42 145.03 465422.12 720718.42 151.54 465428.53 720721.94 151.54 465428.53 720721.94 145.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5445-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465422.12 720718.42 145.03 465419.53 720717.01 145.03 465419.53 720717.01 151.54 465422.12 720718.42 151.54 465422.12 720718.42 145.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5445-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465419.53 720717.01 145.03 465425.91 720705.33 145.03 465425.91 720705.33 151.54 465419.53 720717.01 151.54 465419.53 720717.01 145.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5445-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465425.91 720705.33 145.03 465437.49 720711.7 145.03 465437.49 720711.7 151.54 465425.91 720705.33 151.54 465425.91 720705.33 145.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5445-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465437.49 720711.7 145.03 465431.15 720723.35 145.03 465431.15 720723.35 151.54 465437.49 720711.7 151.54 465437.49 720711.7 145.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5445-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465431.15 720723.35 151.54 465428.53 720721.94 151.54 465422.12 720718.42 151.54 465419.53 720717.01 151.54 465425.91 720705.33 151.54 465437.49 720711.7 151.54 465431.15 720723.35 151.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-56B1-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-56B1-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.31</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56B1-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465444.37 720199.06 137.67 465446.02 720203.66 137.67 465461.65 720197.51 137.67 465459.84 720192.97 137.67 465444.37 720199.06 137.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56B1-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465444.37 720199.06 137.67 465459.84 720192.97 137.67 465459.84 720192.97 142.98 465444.37 720199.06 142.98 465444.37 720199.06 137.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56B1-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465459.84 720192.97 137.67 465461.65 720197.51 137.67 465461.65 720197.51 142.98 465459.84 720192.97 142.98 465459.84 720192.97 137.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56B1-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465461.65 720197.51 137.67 465446.02 720203.66 137.67 465446.02 720203.66 142.98 465461.65 720197.51 142.98 465461.65 720197.51 137.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56B1-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465446.02 720203.66 137.67 465444.37 720199.06 137.67 465444.37 720199.06 142.98 465446.02 720203.66 142.98 465446.02 720203.66 137.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56B1-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465444.37 720199.06 142.98 465459.84 720192.97 142.98 465461.65 720197.51 142.98 465446.02 720203.66 142.98 465444.37 720199.06 142.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5444-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.2</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465457.7 720754.83 145.33 465459.33 720755.3 145.33 465459.86 720756.36 145.33 465461.33 720756.76 145.33 465462.44 720756.2 145.33 465463.22 720756.41 145.33 465463.49 720755.45 145.33 465466.37 720756.28 145.33 465466.1 720757.24 145.33 465471.69 720758.84 145.33 465476.35 720742.53 145.33 465469.4 720740.57 145.33 465468.07 720745.16 145.33 465465.92 720744.55 145.33 465465.55 720745.97 145.33 465461.25 720744.75 145.33 465461.63 720743.46 145.33 465460.96 720743.31 145.33 465459.51 720748.64 145.33 465458.4 720749.09 145.33 465457.99 720750.64 145.33 465458.6 720751.65 145.33 465457.7 720754.83 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465457.7 720754.83 145.33 465458.6 720751.65 145.33 465458.6 720751.65 152.53 465457.7 720754.83 152.53 465457.7 720754.83 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465458.6 720751.65 145.33 465457.99 720750.64 145.33 465457.99 720750.64 152.53 465458.6 720751.65 152.53 465458.6 720751.65 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465457.99 720750.64 145.33 465458.4 720749.09 145.33 465458.4 720749.09 152.53 465457.99 720750.64 152.53 465457.99 720750.64 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465458.4 720749.09 145.33 465459.51 720748.64 145.33 465459.51 720748.64 152.53 465458.4 720749.09 152.53 465458.4 720749.09 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465459.51 720748.64 145.33 465460.96 720743.31 145.33 465460.96 720743.31 152.53 465459.51 720748.64 152.53 465459.51 720748.64 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465460.96 720743.31 145.33 465461.63 720743.46 145.33 465461.63 720743.46 152.53 465460.96 720743.31 152.53 465460.96 720743.31 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465461.63 720743.46 145.33 465461.25 720744.75 145.33 465461.25 720744.75 152.53 465461.63 720743.46 152.53 465461.63 720743.46 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465461.25 720744.75 145.33 465465.55 720745.97 145.33 465465.55 720745.97 152.53 465461.25 720744.75 152.53 465461.25 720744.75 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465465.55 720745.97 145.33 465465.92 720744.55 145.33 465465.92 720744.55 152.53 465465.55 720745.97 152.53 465465.55 720745.97 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465465.92 720744.55 145.33 465468.07 720745.16 145.33 465468.07 720745.16 152.53 465465.92 720744.55 152.53 465465.92 720744.55 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465468.07 720745.16 145.33 465469.4 720740.57 145.33 465469.4 720740.57 152.53 465468.07 720745.16 152.53 465468.07 720745.16 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465469.4 720740.57 145.33 465476.35 720742.53 145.33 465476.35 720742.53 152.53 465469.4 720740.57 152.53 465469.4 720740.57 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465476.35 720742.53 145.33 465471.69 720758.84 145.33 465471.69 720758.84 152.53 465476.35 720742.53 152.53 465476.35 720742.53 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465471.69 720758.84 145.33 465466.1 720757.24 145.33 465466.1 720757.24 152.53 465471.69 720758.84 152.53 465471.69 720758.84 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465466.1 720757.24 145.33 465466.37 720756.28 145.33 465466.37 720756.28 152.53 465466.1 720757.24 152.53 465466.1 720757.24 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465466.37 720756.28 145.33 465463.49 720755.45 145.33 465463.49 720755.45 152.53 465466.37 720756.28 152.53 465466.37 720756.28 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465463.49 720755.45 145.33 465463.22 720756.41 145.33 465463.22 720756.41 152.53 465463.49 720755.45 152.53 465463.49 720755.45 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465463.22 720756.41 145.33 465462.44 720756.2 145.33 465462.44 720756.2 152.53 465463.22 720756.41 152.53 465463.22 720756.41 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465462.44 720756.2 145.33 465461.33 720756.76 145.33 465461.33 720756.76 152.53 465462.44 720756.2 152.53 465462.44 720756.2 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465461.33 720756.76 145.33 465459.86 720756.36 145.33 465459.86 720756.36 152.53 465461.33 720756.76 152.53 465461.33 720756.76 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465459.86 720756.36 145.33 465459.33 720755.3 145.33 465459.33 720755.3 152.53 465459.86 720756.36 152.53 465459.86 720756.36 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465459.33 720755.3 145.33 465457.7 720754.83 145.33 465457.7 720754.83 152.53 465459.33 720755.3 152.53 465459.33 720755.3 145.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5444-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465457.7 720754.83 152.53 465458.6 720751.65 152.53 465457.99 720750.64 152.53 465458.4 720749.09 152.53 465459.51 720748.64 152.53 465460.96 720743.31 152.53 465461.63 720743.46 152.53 465461.25 720744.75 152.53 465465.55 720745.97 152.53 465465.92 720744.55 152.53 465468.07 720745.16 152.53 465469.4 720740.57 152.53 465476.35 720742.53 152.53 465471.69 720758.84 152.53 465466.1 720757.24 152.53 465466.37 720756.28 152.53 465463.49 720755.45 152.53 465463.22 720756.41 152.53 465462.44 720756.2 152.53 465461.33 720756.76 152.53 465459.86 720756.36 152.53 465459.33 720755.3 152.53 465457.7 720754.83 152.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a">
			<gen:stringAttribute name="buildingId">
				<gen:value>14e34154-50b8-4173-a277-d3edd5fef46a</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.35</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465305.69 721052.87 138.09 465300.62 721055.39 138.09 465297.76 721049.51 138.09 465292.47 721052.06 138.09 465294.8 721056.86 138.09 465293.69 721057.39 138.09 465298.82 721067.66 138.09 465308.48 721062.93 138.09 465306.69 721059.17 138.09 465307.12 721058.97 138.09 465307.92 721060.62 138.09 465314.51 721057.33 138.09 465309.81 721047.59 138.09 465304.44 721050.19 138.09 465305.69 721052.87 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465305.69 721052.87 138.09 465304.44 721050.19 138.09 465304.44 721050.19 146.44 465305.69 721052.87 146.44 465305.69 721052.87 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465304.44 721050.19 138.09 465309.81 721047.59 138.09 465309.81 721047.59 146.44 465304.44 721050.19 146.44 465304.44 721050.19 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465309.81 721047.59 138.09 465314.51 721057.33 138.09 465314.51 721057.33 146.44 465309.81 721047.59 146.44 465309.81 721047.59 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465314.51 721057.33 138.09 465307.92 721060.62 138.09 465307.92 721060.62 146.44 465314.51 721057.33 146.44 465314.51 721057.33 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465307.92 721060.62 138.09 465307.12 721058.97 138.09 465307.12 721058.97 146.44 465307.92 721060.62 146.44 465307.92 721060.62 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465307.12 721058.97 138.09 465306.69 721059.17 138.09 465306.69 721059.17 146.44 465307.12 721058.97 146.44 465307.12 721058.97 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465306.69 721059.17 138.09 465308.48 721062.93 138.09 465308.48 721062.93 146.44 465306.69 721059.17 146.44 465306.69 721059.17 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465308.48 721062.93 138.09 465298.82 721067.66 138.09 465298.82 721067.66 146.44 465308.48 721062.93 146.44 465308.48 721062.93 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465298.82 721067.66 138.09 465293.69 721057.39 138.09 465293.69 721057.39 146.44 465298.82 721067.66 146.44 465298.82 721067.66 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465293.69 721057.39 138.09 465294.8 721056.86 138.09 465294.8 721056.86 146.44 465293.69 721057.39 146.44 465293.69 721057.39 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465294.8 721056.86 138.09 465292.47 721052.06 138.09 465292.47 721052.06 146.44 465294.8 721056.86 146.44 465294.8 721056.86 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465292.47 721052.06 138.09 465297.76 721049.51 138.09 465297.76 721049.51 146.44 465292.47 721052.06 146.44 465292.47 721052.06 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465297.76 721049.51 138.09 465300.62 721055.39 138.09 465300.62 721055.39 146.44 465297.76 721049.51 146.44 465297.76 721049.51 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465300.62 721055.39 138.09 465305.69 721052.87 138.09 465305.69 721052.87 146.44 465300.62 721055.39 146.44 465300.62 721055.39 138.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-14e34154-50b8-4173-a277-d3edd5fef46a_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465305.69 721052.87 146.44 465304.44 721050.19 146.44 465309.81 721047.59 146.44 465314.51 721057.33 146.44 465307.92 721060.62 146.44 465307.12 721058.97 146.44 465306.69 721059.17 146.44 465308.48 721062.93 146.44 465298.82 721067.66 146.44 465293.69 721057.39 146.44 465294.8 721056.86 146.44 465292.47 721052.06 146.44 465297.76 721049.51 146.44 465300.62 721055.39 146.44 465305.69 721052.87 146.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408">
			<gen:stringAttribute name="buildingId">
				<gen:value>64a7e197-f7c9-4d90-a09c-d4bc608af408</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.14</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465292.34 721038.36 138.04 465292.95 721038.08 138.04 465290.85 721033.53 138.04 465283.09 721037.29 138.04 465288.26 721047.91 138.04 465288.91 721047.58 138.04 465291.5 721052.88 138.04 465291.85 721052.71 138.04 465289.83 721048.67 138.04 465295.96 721045.88 138.04 465292.34 721038.36 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465292.34 721038.36 138.04 465295.96 721045.88 138.04 465295.96 721045.88 142.18 465292.34 721038.36 142.18 465292.34 721038.36 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465295.96 721045.88 138.04 465289.83 721048.67 138.04 465289.83 721048.67 142.18 465295.96 721045.88 142.18 465295.96 721045.88 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465289.83 721048.67 138.04 465291.85 721052.71 138.04 465291.85 721052.71 142.18 465289.83 721048.67 142.18 465289.83 721048.67 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465291.85 721052.71 138.04 465291.5 721052.88 138.04 465291.5 721052.88 142.18 465291.85 721052.71 142.18 465291.85 721052.71 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465291.5 721052.88 138.04 465288.91 721047.58 138.04 465288.91 721047.58 142.18 465291.5 721052.88 142.18 465291.5 721052.88 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465288.91 721047.58 138.04 465288.26 721047.91 138.04 465288.26 721047.91 142.18 465288.91 721047.58 142.18 465288.91 721047.58 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465288.26 721047.91 138.04 465283.09 721037.29 138.04 465283.09 721037.29 142.18 465288.26 721047.91 142.18 465288.26 721047.91 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465283.09 721037.29 138.04 465290.85 721033.53 138.04 465290.85 721033.53 142.18 465283.09 721037.29 142.18 465283.09 721037.29 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465290.85 721033.53 138.04 465292.95 721038.08 138.04 465292.95 721038.08 142.18 465290.85 721033.53 142.18 465290.85 721033.53 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465292.95 721038.08 138.04 465292.34 721038.36 138.04 465292.34 721038.36 142.18 465292.95 721038.08 142.18 465292.95 721038.08 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64a7e197-f7c9-4d90-a09c-d4bc608af408_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465292.34 721038.36 142.18 465295.96 721045.88 142.18 465289.83 721048.67 142.18 465291.85 721052.71 142.18 465291.5 721052.88 142.18 465288.91 721047.58 142.18 465288.26 721047.91 142.18 465283.09 721037.29 142.18 465290.85 721033.53 142.18 465292.95 721038.08 142.18 465292.34 721038.36 142.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5">
			<gen:stringAttribute name="buildingId">
				<gen:value>A712F5C3-F46D-4303-A717-36CE6D145AA5</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.54</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465142.3 721022.52 143.87 465142.63 721023.14 143.87 465146.1 721021.41 143.87 465145.84 721020.77 143.87 465151.96 721017.77 143.87 465150.12 721014.04 143.87 465152.76 721012.75 143.87 465148.27 721003.49 143.87 465134.87 721010.08 143.87 465137.13 721014.67 143.87 465132.34 721017.04 143.87 465136.45 721025.4 143.87 465142.3 721022.52 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465142.3 721022.52 143.87 465136.45 721025.4 143.87 465136.45 721025.4 151.41 465142.3 721022.52 151.41 465142.3 721022.52 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465136.45 721025.4 143.87 465132.34 721017.04 143.87 465132.34 721017.04 151.41 465136.45 721025.4 151.41 465136.45 721025.4 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465132.34 721017.04 143.87 465137.13 721014.67 143.87 465137.13 721014.67 151.41 465132.34 721017.04 151.41 465132.34 721017.04 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465137.13 721014.67 143.87 465134.87 721010.08 143.87 465134.87 721010.08 151.41 465137.13 721014.67 151.41 465137.13 721014.67 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465134.87 721010.08 143.87 465148.27 721003.49 143.87 465148.27 721003.49 151.41 465134.87 721010.08 151.41 465134.87 721010.08 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465148.27 721003.49 143.87 465152.76 721012.75 143.87 465152.76 721012.75 151.41 465148.27 721003.49 151.41 465148.27 721003.49 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465152.76 721012.75 143.87 465150.12 721014.04 143.87 465150.12 721014.04 151.41 465152.76 721012.75 151.41 465152.76 721012.75 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465150.12 721014.04 143.87 465151.96 721017.77 143.87 465151.96 721017.77 151.41 465150.12 721014.04 151.41 465150.12 721014.04 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465151.96 721017.77 143.87 465145.84 721020.77 143.87 465145.84 721020.77 151.41 465151.96 721017.77 151.41 465151.96 721017.77 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465145.84 721020.77 143.87 465146.1 721021.41 143.87 465146.1 721021.41 151.41 465145.84 721020.77 151.41 465145.84 721020.77 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465146.1 721021.41 143.87 465142.63 721023.14 143.87 465142.63 721023.14 151.41 465146.1 721021.41 151.41 465146.1 721021.41 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465142.63 721023.14 143.87 465142.3 721022.52 143.87 465142.3 721022.52 151.41 465142.63 721023.14 151.41 465142.63 721023.14 143.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-A712F5C3-F46D-4303-A717-36CE6D145AA5_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465142.3 721022.52 151.41 465136.45 721025.4 151.41 465132.34 721017.04 151.41 465137.13 721014.67 151.41 465134.87 721010.08 151.41 465148.27 721003.49 151.41 465152.76 721012.75 151.41 465150.12 721014.04 151.41 465151.96 721017.77 151.41 465145.84 721020.77 151.41 465146.1 721021.41 151.41 465142.63 721023.14 151.41 465142.3 721022.52 151.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.45</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465336.86 721215.6 138.04 465337.03 721215.51 138.04 465341.94 721212.83 138.04 465347.96 721209.56 138.04 465346.13 721206.12 138.04 465347.82 721205.18 138.04 465347.87 721203.17 138.04 465347.35 721201.64 138.04 465346.3 721200.36 138.04 465344.64 721199.31 138.04 465342.95 721200.22 138.04 465341.02 721196.78 138.04 465336.66 721199.11 138.04 465335.63 721197.19 138.04 465334.27 721196.32 138.04 465332.22 721197.38 138.04 465332.14 721199 138.04 465333.22 721200.97 138.04 465329.91 721202.76 138.04 465336.57 721215.08 138.04 465336.86 721215.6 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465336.86 721215.6 138.04 465336.57 721215.08 138.04 465336.57 721215.08 145.49 465336.86 721215.6 145.49 465336.86 721215.6 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465336.57 721215.08 138.04 465329.91 721202.76 138.04 465329.91 721202.76 145.49 465336.57 721215.08 145.49 465336.57 721215.08 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465329.91 721202.76 138.04 465333.22 721200.97 138.04 465333.22 721200.97 145.49 465329.91 721202.76 145.49 465329.91 721202.76 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465333.22 721200.97 138.04 465332.14 721199 138.04 465332.14 721199 145.49 465333.22 721200.97 145.49 465333.22 721200.97 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465332.14 721199 138.04 465332.22 721197.38 138.04 465332.22 721197.38 145.49 465332.14 721199 145.49 465332.14 721199 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465332.22 721197.38 138.04 465334.27 721196.32 138.04 465334.27 721196.32 145.49 465332.22 721197.38 145.49 465332.22 721197.38 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465334.27 721196.32 138.04 465335.63 721197.19 138.04 465335.63 721197.19 145.49 465334.27 721196.32 145.49 465334.27 721196.32 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465335.63 721197.19 138.04 465336.66 721199.11 138.04 465336.66 721199.11 145.49 465335.63 721197.19 145.49 465335.63 721197.19 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465336.66 721199.11 138.04 465341.02 721196.78 138.04 465341.02 721196.78 145.49 465336.66 721199.11 145.49 465336.66 721199.11 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465341.02 721196.78 138.04 465342.95 721200.22 138.04 465342.95 721200.22 145.49 465341.02 721196.78 145.49 465341.02 721196.78 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465342.95 721200.22 138.04 465344.64 721199.31 138.04 465344.64 721199.31 145.49 465342.95 721200.22 145.49 465342.95 721200.22 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465344.64 721199.31 138.04 465346.3 721200.36 138.04 465346.3 721200.36 145.49 465344.64 721199.31 145.49 465344.64 721199.31 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465346.3 721200.36 138.04 465347.35 721201.64 138.04 465347.35 721201.64 145.49 465346.3 721200.36 145.49 465346.3 721200.36 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465347.35 721201.64 138.04 465347.87 721203.17 138.04 465347.87 721203.17 145.49 465347.35 721201.64 145.49 465347.35 721201.64 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465347.87 721203.17 138.04 465347.82 721205.18 138.04 465347.82 721205.18 145.49 465347.87 721203.17 145.49 465347.87 721203.17 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465347.82 721205.18 138.04 465346.13 721206.12 138.04 465346.13 721206.12 145.49 465347.82 721205.18 145.49 465347.82 721205.18 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465346.13 721206.12 138.04 465347.96 721209.56 138.04 465347.96 721209.56 145.49 465346.13 721206.12 145.49 465346.13 721206.12 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465347.96 721209.56 138.04 465341.94 721212.83 138.04 465341.94 721212.83 145.49 465347.96 721209.56 145.49 465347.96 721209.56 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465341.94 721212.83 138.04 465337.03 721215.51 138.04 465337.03 721215.51 145.49 465341.94 721212.83 145.49 465341.94 721212.83 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465337.03 721215.51 138.04 465336.86 721215.6 138.04 465336.86 721215.6 145.49 465337.03 721215.51 145.49 465337.03 721215.51 138.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED2E-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465336.86 721215.6 145.49 465336.57 721215.08 145.49 465329.91 721202.76 145.49 465333.22 721200.97 145.49 465332.14 721199 145.49 465332.22 721197.38 145.49 465334.27 721196.32 145.49 465335.63 721197.19 145.49 465336.66 721199.11 145.49 465341.02 721196.78 145.49 465342.95 721200.22 145.49 465344.64 721199.31 145.49 465346.3 721200.36 145.49 465347.35 721201.64 145.49 465347.87 721203.17 145.49 465347.82 721205.18 145.49 465346.13 721206.12 145.49 465347.96 721209.56 145.49 465341.94 721212.83 145.49 465337.03 721215.51 145.49 465336.86 721215.6 145.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-ba37dcf3-7843-4880-8797-8c40bd4eace2">
			<gen:stringAttribute name="buildingId">
				<gen:value>ba37dcf3-7843-4880-8797-8c40bd4eace2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.69</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ba37dcf3-7843-4880-8797-8c40bd4eace2_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465255.03 720920.29 135.72 465236.19 720934.99 135.72 465254.88 720964.67 135.72 465275.01 720952.07 135.72 465256.75 720923.02 135.72 465255.03 720920.29 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ba37dcf3-7843-4880-8797-8c40bd4eace2_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465255.03 720920.29 135.72 465256.75 720923.02 135.72 465256.75 720923.02 140.41 465255.03 720920.29 140.41 465255.03 720920.29 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ba37dcf3-7843-4880-8797-8c40bd4eace2_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465256.75 720923.02 135.72 465275.01 720952.07 135.72 465275.01 720952.07 140.41 465256.75 720923.02 140.41 465256.75 720923.02 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ba37dcf3-7843-4880-8797-8c40bd4eace2_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465275.01 720952.07 135.72 465254.88 720964.67 135.72 465254.88 720964.67 140.41 465275.01 720952.07 140.41 465275.01 720952.07 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ba37dcf3-7843-4880-8797-8c40bd4eace2_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465254.88 720964.67 135.72 465236.19 720934.99 135.72 465236.19 720934.99 140.41 465254.88 720964.67 140.41 465254.88 720964.67 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ba37dcf3-7843-4880-8797-8c40bd4eace2_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465236.19 720934.99 135.72 465255.03 720920.29 135.72 465255.03 720920.29 140.41 465236.19 720934.99 140.41 465236.19 720934.99 135.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ba37dcf3-7843-4880-8797-8c40bd4eace2_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465255.03 720920.29 140.41 465256.75 720923.02 140.41 465275.01 720952.07 140.41 465254.88 720964.67 140.41 465236.19 720934.99 140.41 465255.03 720920.29 140.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b">
			<gen:stringAttribute name="buildingId">
				<gen:value>a090d462-522d-4603-9696-2b5ba957347b</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.12</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465287.37 721135.02 138.61 465291.73 721143.15 138.61 465291.2 721143.43 138.61 465291.34 721143.71 138.61 465291.89 721143.41 138.61 465292.76 721145.03 138.61 465291.47 721145.71 138.61 465294.71 721151.71 138.61 465309.54 721143.7 138.61 465309.36 721143.35 138.61 465313.71 721141.02 138.61 465313.92 721141.37 138.61 465314.29 721141.17 138.61 465314.14 721140.86 138.61 465313.08 721138.98 138.61 465313.5 721138.75 138.61 465313.42 721138.62 138.61 465313.01 721138.85 138.61 465312 721137.01 138.61 465312.44 721136.78 138.61 465312.34 721136.59 138.61 465311.89 721136.8 138.61 465310.74 721134.74 138.61 465301.14 721139.83 138.61 465300.5 721138.66 138.61 465297.93 721140.02 138.61 465293.56 721131.7 138.61 465287.37 721135.02 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465287.37 721135.02 138.61 465293.56 721131.7 138.61 465293.56 721131.7 147.73 465287.37 721135.02 147.73 465287.37 721135.02 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465293.56 721131.7 138.61 465297.93 721140.02 138.61 465297.93 721140.02 147.73 465293.56 721131.7 147.73 465293.56 721131.7 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465297.93 721140.02 138.61 465300.5 721138.66 138.61 465300.5 721138.66 147.73 465297.93 721140.02 147.73 465297.93 721140.02 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465300.5 721138.66 138.61 465301.14 721139.83 138.61 465301.14 721139.83 147.73 465300.5 721138.66 147.73 465300.5 721138.66 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465301.14 721139.83 138.61 465310.74 721134.74 138.61 465310.74 721134.74 147.73 465301.14 721139.83 147.73 465301.14 721139.83 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465310.74 721134.74 138.61 465311.89 721136.8 138.61 465311.89 721136.8 147.73 465310.74 721134.74 147.73 465310.74 721134.74 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465311.89 721136.8 138.61 465312.34 721136.59 138.61 465312.34 721136.59 147.73 465311.89 721136.8 147.73 465311.89 721136.8 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465312.34 721136.59 138.61 465312.44 721136.78 138.61 465312.44 721136.78 147.73 465312.34 721136.59 147.73 465312.34 721136.59 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465312.44 721136.78 138.61 465312 721137.01 138.61 465312 721137.01 147.73 465312.44 721136.78 147.73 465312.44 721136.78 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465312 721137.01 138.61 465313.01 721138.85 138.61 465313.01 721138.85 147.73 465312 721137.01 147.73 465312 721137.01 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465313.01 721138.85 138.61 465313.42 721138.62 138.61 465313.42 721138.62 147.73 465313.01 721138.85 147.73 465313.01 721138.85 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465313.42 721138.62 138.61 465313.5 721138.75 138.61 465313.5 721138.75 147.73 465313.42 721138.62 147.73 465313.42 721138.62 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465313.5 721138.75 138.61 465313.08 721138.98 138.61 465313.08 721138.98 147.73 465313.5 721138.75 147.73 465313.5 721138.75 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465313.08 721138.98 138.61 465314.14 721140.86 138.61 465314.14 721140.86 147.73 465313.08 721138.98 147.73 465313.08 721138.98 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465314.14 721140.86 138.61 465314.29 721141.17 138.61 465314.29 721141.17 147.73 465314.14 721140.86 147.73 465314.14 721140.86 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465314.29 721141.17 138.61 465313.92 721141.37 138.61 465313.92 721141.37 147.73 465314.29 721141.17 147.73 465314.29 721141.17 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465313.92 721141.37 138.61 465313.71 721141.02 138.61 465313.71 721141.02 147.73 465313.92 721141.37 147.73 465313.92 721141.37 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465313.71 721141.02 138.61 465309.36 721143.35 138.61 465309.36 721143.35 147.73 465313.71 721141.02 147.73 465313.71 721141.02 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465309.36 721143.35 138.61 465309.54 721143.7 138.61 465309.54 721143.7 147.73 465309.36 721143.35 147.73 465309.36 721143.35 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465309.54 721143.7 138.61 465294.71 721151.71 138.61 465294.71 721151.71 147.73 465309.54 721143.7 147.73 465309.54 721143.7 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465294.71 721151.71 138.61 465291.47 721145.71 138.61 465291.47 721145.71 147.73 465294.71 721151.71 147.73 465294.71 721151.71 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465291.47 721145.71 138.61 465292.76 721145.03 138.61 465292.76 721145.03 147.73 465291.47 721145.71 147.73 465291.47 721145.71 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465292.76 721145.03 138.61 465291.89 721143.41 138.61 465291.89 721143.41 147.73 465292.76 721145.03 147.73 465292.76 721145.03 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465291.89 721143.41 138.61 465291.34 721143.71 138.61 465291.34 721143.71 147.73 465291.89 721143.41 147.73 465291.89 721143.41 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465291.34 721143.71 138.61 465291.2 721143.43 138.61 465291.2 721143.43 147.73 465291.34 721143.71 147.73 465291.34 721143.71 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465291.2 721143.43 138.61 465291.73 721143.15 138.61 465291.73 721143.15 147.73 465291.2 721143.43 147.73 465291.2 721143.43 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465291.73 721143.15 138.61 465287.37 721135.02 138.61 465287.37 721135.02 147.73 465291.73 721143.15 147.73 465291.73 721143.15 138.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a090d462-522d-4603-9696-2b5ba957347b_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465287.37 721135.02 147.73 465293.56 721131.7 147.73 465297.93 721140.02 147.73 465300.5 721138.66 147.73 465301.14 721139.83 147.73 465310.74 721134.74 147.73 465311.89 721136.8 147.73 465312.34 721136.59 147.73 465312.44 721136.78 147.73 465312 721137.01 147.73 465313.01 721138.85 147.73 465313.42 721138.62 147.73 465313.5 721138.75 147.73 465313.08 721138.98 147.73 465314.14 721140.86 147.73 465314.29 721141.17 147.73 465313.92 721141.37 147.73 465313.71 721141.02 147.73 465309.36 721143.35 147.73 465309.54 721143.7 147.73 465294.71 721151.71 147.73 465291.47 721145.71 147.73 465292.76 721145.03 147.73 465291.89 721143.41 147.73 465291.34 721143.71 147.73 465291.2 721143.43 147.73 465291.73 721143.15 147.73 465287.37 721135.02 147.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-ECC1-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-ECC1-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ECC1-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465456.23 720647.56 150.24 465466.82 720644.92 150.24 465463.24 720630.65 150.24 465457.06 720632.21 150.24 465458.01 720636.25 150.24 465453.67 720637.28 150.24 465456.23 720647.56 150.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ECC1-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465456.23 720647.56 150.24 465453.67 720637.28 150.24 465453.67 720637.28 155.84 465456.23 720647.56 155.84 465456.23 720647.56 150.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ECC1-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465453.67 720637.28 150.24 465458.01 720636.25 150.24 465458.01 720636.25 155.84 465453.67 720637.28 155.84 465453.67 720637.28 150.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ECC1-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465458.01 720636.25 150.24 465457.06 720632.21 150.24 465457.06 720632.21 155.84 465458.01 720636.25 155.84 465458.01 720636.25 150.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ECC1-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465457.06 720632.21 150.24 465463.24 720630.65 150.24 465463.24 720630.65 155.84 465457.06 720632.21 155.84 465457.06 720632.21 150.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ECC1-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465463.24 720630.65 150.24 465466.82 720644.92 150.24 465466.82 720644.92 155.84 465463.24 720630.65 155.84 465463.24 720630.65 150.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ECC1-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465466.82 720644.92 150.24 465456.23 720647.56 150.24 465456.23 720647.56 155.84 465466.82 720644.92 155.84 465466.82 720644.92 150.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ECC1-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465456.23 720647.56 155.84 465453.67 720637.28 155.84 465458.01 720636.25 155.84 465457.06 720632.21 155.84 465463.24 720630.65 155.84 465466.82 720644.92 155.84 465456.23 720647.56 155.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-3F7F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-3F7F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465263.42 720897.71 136.21 465271.06 720907.61 136.21 465317.73 720871.18 136.21 465310.05 720861.06 136.21 465263.42 720897.71 136.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465263.42 720897.71 136.21 465310.05 720861.06 136.21 465310.05 720861.06 140.64000000000001 465263.42 720897.71 140.64000000000001 465263.42 720897.71 136.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465310.05 720861.06 136.21 465317.73 720871.18 136.21 465317.73 720871.18 140.64000000000001 465310.05 720861.06 140.64000000000001 465310.05 720861.06 136.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465317.73 720871.18 136.21 465271.06 720907.61 136.21 465271.06 720907.61 140.64000000000001 465317.73 720871.18 140.64000000000001 465317.73 720871.18 136.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465271.06 720907.61 136.21 465263.42 720897.71 136.21 465263.42 720897.71 140.64000000000001 465271.06 720907.61 140.64000000000001 465271.06 720907.61 136.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465263.42 720897.71 140.64000000000001 465310.05 720861.06 140.64000000000001 465317.73 720871.18 140.64000000000001 465271.06 720907.61 140.64000000000001 465263.42 720897.71 140.64000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-3F7E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-3F7E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.41</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465228.73 720924.83 136.13 465236.19 720934.99 136.13 465255.03 720920.29 136.13 465271.06 720907.61 136.13 465263.42 720897.71 136.13 465228.73 720924.83 136.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465228.73 720924.83 136.13 465263.42 720897.71 136.13 465263.42 720897.71 140.54 465228.73 720924.83 140.54 465228.73 720924.83 136.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465263.42 720897.71 136.13 465271.06 720907.61 136.13 465271.06 720907.61 140.54 465263.42 720897.71 140.54 465263.42 720897.71 136.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465271.06 720907.61 136.13 465255.03 720920.29 136.13 465255.03 720920.29 140.54 465271.06 720907.61 140.54 465271.06 720907.61 136.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465255.03 720920.29 136.13 465236.19 720934.99 136.13 465236.19 720934.99 140.54 465255.03 720920.29 140.54 465255.03 720920.29 136.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465236.19 720934.99 136.13 465228.73 720924.83 136.13 465228.73 720924.83 140.54 465236.19 720934.99 140.54 465236.19 720934.99 136.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3F7E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465228.73 720924.83 140.54 465263.42 720897.71 140.54 465271.06 720907.61 140.54 465255.03 720920.29 140.54 465236.19 720934.99 140.54 465228.73 720924.83 140.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.08</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465329.34 720947.17 136.67 465347.21 720938.26 136.67 465342.31 720928.52 136.67 465340.54 720929.38 136.67 465335.69 720919.58 136.67 465324.3 720925.21 136.67 465329.17 720935.07 136.67 465324.87 720937.21 136.67 465320.34 720928.12 136.67 465314.01 720931.28 136.67 465319.95 720943.19 136.67 465321.57 720942.39 136.67 465321.98 720943.22 136.67 465323.8 720942.33 136.67 465323.38 720941.48 136.67 465325.89 720940.24 136.67 465329.34 720947.17 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465329.34 720947.17 136.67 465325.89 720940.24 136.67 465325.89 720940.24 141.75 465329.34 720947.17 141.75 465329.34 720947.17 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465325.89 720940.24 136.67 465323.38 720941.48 136.67 465323.38 720941.48 141.75 465325.89 720940.24 141.75 465325.89 720940.24 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465323.38 720941.48 136.67 465323.8 720942.33 136.67 465323.8 720942.33 141.75 465323.38 720941.48 141.75 465323.38 720941.48 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465323.8 720942.33 136.67 465321.98 720943.22 136.67 465321.98 720943.22 141.75 465323.8 720942.33 141.75 465323.8 720942.33 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465321.98 720943.22 136.67 465321.57 720942.39 136.67 465321.57 720942.39 141.75 465321.98 720943.22 141.75 465321.98 720943.22 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465321.57 720942.39 136.67 465319.95 720943.19 136.67 465319.95 720943.19 141.75 465321.57 720942.39 141.75 465321.57 720942.39 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465319.95 720943.19 136.67 465314.01 720931.28 136.67 465314.01 720931.28 141.75 465319.95 720943.19 141.75 465319.95 720943.19 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465314.01 720931.28 136.67 465320.34 720928.12 136.67 465320.34 720928.12 141.75 465314.01 720931.28 141.75 465314.01 720931.28 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465320.34 720928.12 136.67 465324.87 720937.21 136.67 465324.87 720937.21 141.75 465320.34 720928.12 141.75 465320.34 720928.12 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465324.87 720937.21 136.67 465329.17 720935.07 136.67 465329.17 720935.07 141.75 465324.87 720937.21 141.75 465324.87 720937.21 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465329.17 720935.07 136.67 465324.3 720925.21 136.67 465324.3 720925.21 141.75 465329.17 720935.07 141.75 465329.17 720935.07 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465324.3 720925.21 136.67 465335.69 720919.58 136.67 465335.69 720919.58 141.75 465324.3 720925.21 141.75 465324.3 720925.21 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465335.69 720919.58 136.67 465340.54 720929.38 136.67 465340.54 720929.38 141.75 465335.69 720919.58 141.75 465335.69 720919.58 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465340.54 720929.38 136.67 465342.31 720928.52 136.67 465342.31 720928.52 141.75 465340.54 720929.38 141.75 465340.54 720929.38 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465342.31 720928.52 136.67 465347.21 720938.26 136.67 465347.21 720938.26 141.75 465342.31 720928.52 141.75 465342.31 720928.52 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465347.21 720938.26 136.67 465329.34 720947.17 136.67 465329.34 720947.17 141.75 465347.21 720938.26 141.75 465347.21 720938.26 136.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2B35-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465329.34 720947.17 141.75 465325.89 720940.24 141.75 465323.38 720941.48 141.75 465323.8 720942.33 141.75 465321.98 720943.22 141.75 465321.57 720942.39 141.75 465319.95 720943.19 141.75 465314.01 720931.28 141.75 465320.34 720928.12 141.75 465324.87 720937.21 141.75 465329.17 720935.07 141.75 465324.3 720925.21 141.75 465335.69 720919.58 141.75 465340.54 720929.38 141.75 465342.31 720928.52 141.75 465347.21 720938.26 141.75 465329.34 720947.17 141.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E60C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E60C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.97</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E60C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465460.79 721004.14 136.27 465456.32 720993.94 136.27 465444.37 720999.17 136.27 465448.84 721009.37 136.27 465460.79 721004.14 136.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E60C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465460.79 721004.14 136.27 465448.84 721009.37 136.27 465448.84 721009.37 142.24 465460.79 721004.14 142.24 465460.79 721004.14 136.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E60C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465448.84 721009.37 136.27 465444.37 720999.17 136.27 465444.37 720999.17 142.24 465448.84 721009.37 142.24 465448.84 721009.37 136.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E60C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465444.37 720999.17 136.27 465456.32 720993.94 136.27 465456.32 720993.94 142.24 465444.37 720999.17 142.24 465444.37 720999.17 136.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E60C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465456.32 720993.94 136.27 465460.79 721004.14 136.27 465460.79 721004.14 142.24 465456.32 720993.94 142.24 465456.32 720993.94 136.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E60C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465460.79 721004.14 142.24 465448.84 721009.37 142.24 465444.37 720999.17 142.24 465456.32 720993.94 142.24 465460.79 721004.14 142.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C787-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C787-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.64</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C787-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465469.76 720599.02 149.73 465468.72 720594.02 149.73 465460.54 720595.74 149.73 465461.59 720600.74 149.73 465469.76 720599.02 149.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C787-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465469.76 720599.02 149.73 465461.59 720600.74 149.73 465461.59 720600.74 152.37 465469.76 720599.02 152.37 465469.76 720599.02 149.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C787-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465461.59 720600.74 149.73 465460.54 720595.74 149.73 465460.54 720595.74 152.37 465461.59 720600.74 152.37 465461.59 720600.74 149.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C787-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465460.54 720595.74 149.73 465468.72 720594.02 149.73 465468.72 720594.02 152.37 465460.54 720595.74 152.37 465460.54 720595.74 149.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C787-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465468.72 720594.02 149.73 465469.76 720599.02 149.73 465469.76 720599.02 152.37 465468.72 720594.02 152.37 465468.72 720594.02 149.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C787-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465469.76 720599.02 152.37 465461.59 720600.74 152.37 465460.54 720595.74 152.37 465468.72 720594.02 152.37 465469.76 720599.02 152.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-c234acbc-1dc6-4453-95b6-1cbddcc3d6ab">
			<gen:stringAttribute name="buildingId">
				<gen:value>c234acbc-1dc6-4453-95b6-1cbddcc3d6ab</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.35</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c234acbc-1dc6-4453-95b6-1cbddcc3d6ab_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465452.24 719616.05 120.79 465458.27 719617.03 120.79 465458.89 719613.22 120.79 465448.3 719611.51 120.79 465447.5 719616.27 120.79 465452.07 719617.03 120.79 465452.24 719616.05 120.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c234acbc-1dc6-4453-95b6-1cbddcc3d6ab_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465452.24 719616.05 120.79 465452.07 719617.03 120.79 465452.07 719617.03 124.14 465452.24 719616.05 124.14 465452.24 719616.05 120.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c234acbc-1dc6-4453-95b6-1cbddcc3d6ab_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465452.07 719617.03 120.79 465447.5 719616.27 120.79 465447.5 719616.27 124.14 465452.07 719617.03 124.14 465452.07 719617.03 120.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c234acbc-1dc6-4453-95b6-1cbddcc3d6ab_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465447.5 719616.27 120.79 465448.3 719611.51 120.79 465448.3 719611.51 124.14 465447.5 719616.27 124.14 465447.5 719616.27 120.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c234acbc-1dc6-4453-95b6-1cbddcc3d6ab_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465448.3 719611.51 120.79 465458.89 719613.22 120.79 465458.89 719613.22 124.14 465448.3 719611.51 124.14 465448.3 719611.51 120.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c234acbc-1dc6-4453-95b6-1cbddcc3d6ab_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465458.89 719613.22 120.79 465458.27 719617.03 120.79 465458.27 719617.03 124.14 465458.89 719613.22 124.14 465458.89 719613.22 120.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c234acbc-1dc6-4453-95b6-1cbddcc3d6ab_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465458.27 719617.03 120.79 465452.24 719616.05 120.79 465452.24 719616.05 124.14 465458.27 719617.03 124.14 465458.27 719617.03 120.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c234acbc-1dc6-4453-95b6-1cbddcc3d6ab_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465452.24 719616.05 124.14 465452.07 719617.03 124.14 465447.5 719616.27 124.14 465448.3 719611.51 124.14 465458.89 719613.22 124.14 465458.27 719617.03 124.14 465452.24 719616.05 124.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-777C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-777C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-777C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465428.44 720790.82 144.03 465440.85 720776.08 144.03 465432.59 720769.13 144.03 465420.18 720783.86 144.03 465428.44 720790.82 144.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-777C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465428.44 720790.82 144.03 465420.18 720783.86 144.03 465420.18 720783.86 149.66 465428.44 720790.82 149.66 465428.44 720790.82 144.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-777C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465420.18 720783.86 144.03 465432.59 720769.13 144.03 465432.59 720769.13 149.66 465420.18 720783.86 149.66 465420.18 720783.86 144.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-777C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465432.59 720769.13 144.03 465440.85 720776.08 144.03 465440.85 720776.08 149.66 465432.59 720769.13 149.66 465432.59 720769.13 144.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-777C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465440.85 720776.08 144.03 465428.44 720790.82 144.03 465428.44 720790.82 149.66 465440.85 720776.08 149.66 465440.85 720776.08 144.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-777C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465428.44 720790.82 149.66 465420.18 720783.86 149.66 465432.59 720769.13 149.66 465440.85 720776.08 149.66 465428.44 720790.82 149.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
</CityModel>
<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0" xmlns="http://www.opengis.net/citygml/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
			<gml:lowerCorner>470004.34 728153.91 22.19</gml:lowerCorner>
			<gml:upperCorner>471634.87 728834.38 77.07000000000001</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D86E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D86E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">18.93</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D86E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471599.91 728496.95 22.19 471603.03 728506.69 22.19 471613 728538.35 22.19 471619.78 728560.32 22.19 471634.87 728555.77 22.19 471614.83 728492.24 22.19 471599.91 728496.95 22.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D86E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471599.91 728496.95 22.19 471614.83 728492.24 22.19 471614.83 728492.24 41.12 471599.91 728496.95 41.12 471599.91 728496.95 22.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D86E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471614.83 728492.24 22.19 471634.87 728555.77 22.19 471634.87 728555.77 41.12 471614.83 728492.24 41.12 471614.83 728492.24 22.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D86E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471634.87 728555.77 22.19 471619.78 728560.32 22.19 471619.78 728560.32 41.12 471634.87 728555.77 41.12 471634.87 728555.77 22.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D86E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471619.78 728560.32 22.19 471613 728538.35 22.19 471613 728538.35 41.12 471619.78 728560.32 41.12 471619.78 728560.32 22.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D86E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471613 728538.35 22.19 471603.03 728506.69 22.19 471603.03 728506.69 41.12 471613 728538.35 41.12 471613 728538.35 22.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D86E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471603.03 728506.69 22.19 471599.91 728496.95 22.19 471599.91 728496.95 41.12 471603.03 728506.69 41.12 471603.03 728506.69 22.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D86E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471599.91 728496.95 41.12 471614.83 728492.24 41.12 471634.87 728555.77 41.12 471619.78 728560.32 41.12 471613 728538.35 41.12 471603.03 728506.69 41.12 471599.91 728496.95 41.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-787A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.82</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471251.69 728161.31 37.19 471254.55 728170.6 37.19 471263.8 728167.74 37.19 471261.08 728158.94 37.19 471262.63 728158.45 37.19 471261.21 728153.91 37.19 471254.21 728155.97 37.19 471255.3 728159.69 37.19 471251.97 728160.72 37.19 471252.1 728161.17 37.19 471251.69 728161.31 37.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471251.69 728161.31 37.19 471252.1 728161.17 37.19 471252.1 728161.17 45.01 471251.69 728161.31 45.01 471251.69 728161.31 37.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471252.1 728161.17 37.19 471251.97 728160.72 37.19 471251.97 728160.72 45.01 471252.1 728161.17 45.01 471252.1 728161.17 37.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471251.97 728160.72 37.19 471255.3 728159.69 37.19 471255.3 728159.69 45.01 471251.97 728160.72 45.01 471251.97 728160.72 37.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471255.3 728159.69 37.19 471254.21 728155.97 37.19 471254.21 728155.97 45.01 471255.3 728159.69 45.01 471255.3 728159.69 37.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471254.21 728155.97 37.19 471261.21 728153.91 37.19 471261.21 728153.91 45.01 471254.21 728155.97 45.01 471254.21 728155.97 37.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471261.21 728153.91 37.19 471262.63 728158.45 37.19 471262.63 728158.45 45.01 471261.21 728153.91 45.01 471261.21 728153.91 37.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471262.63 728158.45 37.19 471261.08 728158.94 37.19 471261.08 728158.94 45.01 471262.63 728158.45 45.01 471262.63 728158.45 37.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471261.08 728158.94 37.19 471263.8 728167.74 37.19 471263.8 728167.74 45.01 471261.08 728158.94 45.01 471261.08 728158.94 37.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471263.8 728167.74 37.19 471254.55 728170.6 37.19 471254.55 728170.6 45.01 471263.8 728167.74 45.01 471263.8 728167.74 37.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471254.55 728170.6 37.19 471251.69 728161.31 37.19 471251.69 728161.31 45.01 471254.55 728170.6 45.01 471254.55 728170.6 37.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-787A-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471251.69 728161.31 45.01 471252.1 728161.17 45.01 471251.97 728160.72 45.01 471255.3 728159.69 45.01 471254.21 728155.97 45.01 471261.21 728153.91 45.01 471262.63 728158.45 45.01 471261.08 728158.94 45.01 471263.8 728167.74 45.01 471254.55 728170.6 45.01 471251.69 728161.31 45.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-d998881a-4633-49fc-a447-31162aaab683">
			<gen:stringAttribute name="buildingId">
				<gen:value>d998881a-4633-49fc-a447-31162aaab683</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">16.01</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d998881a-4633-49fc-a447-31162aaab683_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471542.67 728608.03 26.21 471538.72 728620.4 26.21 471547.83 728655.27 26.21 471621.35 728637.07 26.21 471615.58 728618.55 26.21 471604.6 728621.97 26.21 471600.42 728608.55 26.21 471582.12 728614.25 26.21 471576.86 728597.38 26.21 471542.67 728608.03 26.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d998881a-4633-49fc-a447-31162aaab683_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471542.67 728608.03 26.21 471576.86 728597.38 26.21 471576.86 728597.38 42.22 471542.67 728608.03 42.22 471542.67 728608.03 26.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d998881a-4633-49fc-a447-31162aaab683_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471576.86 728597.38 26.21 471582.12 728614.25 26.21 471582.12 728614.25 42.22 471576.86 728597.38 42.22 471576.86 728597.38 26.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d998881a-4633-49fc-a447-31162aaab683_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471582.12 728614.25 26.21 471600.42 728608.55 26.21 471600.42 728608.55 42.22 471582.12 728614.25 42.22 471582.12 728614.25 26.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d998881a-4633-49fc-a447-31162aaab683_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471600.42 728608.55 26.21 471604.6 728621.97 26.21 471604.6 728621.97 42.22 471600.42 728608.55 42.22 471600.42 728608.55 26.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d998881a-4633-49fc-a447-31162aaab683_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471604.6 728621.97 26.21 471615.58 728618.55 26.21 471615.58 728618.55 42.22 471604.6 728621.97 42.22 471604.6 728621.97 26.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d998881a-4633-49fc-a447-31162aaab683_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471615.58 728618.55 26.21 471621.35 728637.07 26.21 471621.35 728637.07 42.22 471615.58 728618.55 42.22 471615.58 728618.55 26.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d998881a-4633-49fc-a447-31162aaab683_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471621.35 728637.07 26.21 471547.83 728655.27 26.21 471547.83 728655.27 42.22 471621.35 728637.07 42.22 471621.35 728637.07 26.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d998881a-4633-49fc-a447-31162aaab683_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471547.83 728655.27 26.21 471538.72 728620.4 26.21 471538.72 728620.4 42.22 471547.83 728655.27 42.22 471547.83 728655.27 26.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d998881a-4633-49fc-a447-31162aaab683_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471538.72 728620.4 26.21 471542.67 728608.03 26.21 471542.67 728608.03 42.22 471538.72 728620.4 42.22 471538.72 728620.4 26.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d998881a-4633-49fc-a447-31162aaab683_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471542.67 728608.03 42.22 471576.86 728597.38 42.22 471582.12 728614.25 42.22 471600.42 728608.55 42.22 471604.6 728621.97 42.22 471615.58 728618.55 42.22 471621.35 728637.07 42.22 471547.83 728655.27 42.22 471538.72 728620.4 42.22 471542.67 728608.03 42.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2A7B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2A7B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471611.29 728759.76 24.51 471613.77 728764.16 24.51 471622.63 728758.77 24.51 471619.96 728754.63 24.51 471612.19 728759.23 24.51 471611.29 728759.76 24.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471611.29 728759.76 24.51 471612.19 728759.23 24.51 471612.19 728759.23 29.830000000000002 471611.29 728759.76 29.830000000000002 471611.29 728759.76 24.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471612.19 728759.23 24.51 471619.96 728754.63 24.51 471619.96 728754.63 29.830000000000002 471612.19 728759.23 29.830000000000002 471612.19 728759.23 24.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471619.96 728754.63 24.51 471622.63 728758.77 24.51 471622.63 728758.77 29.830000000000002 471619.96 728754.63 29.830000000000002 471619.96 728754.63 24.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471622.63 728758.77 24.51 471613.77 728764.16 24.51 471613.77 728764.16 29.830000000000002 471622.63 728758.77 29.830000000000002 471622.63 728758.77 24.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471613.77 728764.16 24.51 471611.29 728759.76 24.51 471611.29 728759.76 29.830000000000002 471613.77 728764.16 29.830000000000002 471613.77 728764.16 24.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471611.29 728759.76 29.830000000000002 471612.19 728759.23 29.830000000000002 471619.96 728754.63 29.830000000000002 471622.63 728758.77 29.830000000000002 471613.77 728764.16 29.830000000000002 471611.29 728759.76 29.830000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D873-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D873-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.64</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D873-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471523.3 728373.61 26.47 471531.16 728398.54 26.47 471530.04 728398.89 26.47 471534.83 728413.92 26.47 471542.02 728411.7 26.47 471541.58 728410.23 26.47 471569.49 728401.49 26.47 471557.23 728362.96 26.47 471523.3 728373.61 26.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D873-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471523.3 728373.61 26.47 471557.23 728362.96 26.47 471557.23 728362.96 36.11 471523.3 728373.61 36.11 471523.3 728373.61 26.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D873-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471557.23 728362.96 26.47 471569.49 728401.49 26.47 471569.49 728401.49 36.11 471557.23 728362.96 36.11 471557.23 728362.96 26.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D873-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471569.49 728401.49 26.47 471541.58 728410.23 26.47 471541.58 728410.23 36.11 471569.49 728401.49 36.11 471569.49 728401.49 26.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D873-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471541.58 728410.23 26.47 471542.02 728411.7 26.47 471542.02 728411.7 36.11 471541.58 728410.23 36.11 471541.58 728410.23 26.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D873-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471542.02 728411.7 26.47 471534.83 728413.92 26.47 471534.83 728413.92 36.11 471542.02 728411.7 36.11 471542.02 728411.7 26.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D873-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471534.83 728413.92 26.47 471530.04 728398.89 26.47 471530.04 728398.89 36.11 471534.83 728413.92 36.11 471534.83 728413.92 26.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D873-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471530.04 728398.89 26.47 471531.16 728398.54 26.47 471531.16 728398.54 36.11 471530.04 728398.89 36.11 471530.04 728398.89 26.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D873-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471531.16 728398.54 26.47 471523.3 728373.61 26.47 471523.3 728373.61 36.11 471531.16 728398.54 36.11 471531.16 728398.54 26.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D873-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471523.3 728373.61 36.11 471557.23 728362.96 36.11 471569.49 728401.49 36.11 471541.58 728410.23 36.11 471542.02 728411.7 36.11 471534.83 728413.92 36.11 471530.04 728398.89 36.11 471531.16 728398.54 36.11 471523.3 728373.61 36.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D872-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">17.36</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471471.64 728388.31 27.71 471472.22 728390.13 27.71 471472.38 728390.08 27.71 471493.39 728456.29 27.71 471527.6 728445.41 27.71 471510.01 728390.06 27.71 471510.22 728389.99 27.71 471509.46 728387.57 27.71 471508.63 728384.96 27.71 471506.22 728377.35 27.71 471504.57 728377.85 27.71 471504.6 728377.95 27.71 471473.29 728387.9 27.71 471473.26 728387.8 27.71 471471.64 728388.31 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471471.64 728388.31 27.71 471473.26 728387.8 27.71 471473.26 728387.8 45.07 471471.64 728388.31 45.07 471471.64 728388.31 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471473.26 728387.8 27.71 471473.29 728387.9 27.71 471473.29 728387.9 45.07 471473.26 728387.8 45.07 471473.26 728387.8 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471473.29 728387.9 27.71 471504.6 728377.95 27.71 471504.6 728377.95 45.07 471473.29 728387.9 45.07 471473.29 728387.9 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471504.6 728377.95 27.71 471504.57 728377.85 27.71 471504.57 728377.85 45.07 471504.6 728377.95 45.07 471504.6 728377.95 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471504.57 728377.85 27.71 471506.22 728377.35 27.71 471506.22 728377.35 45.07 471504.57 728377.85 45.07 471504.57 728377.85 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471506.22 728377.35 27.71 471508.63 728384.96 27.71 471508.63 728384.96 45.07 471506.22 728377.35 45.07 471506.22 728377.35 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471508.63 728384.96 27.71 471509.46 728387.57 27.71 471509.46 728387.57 45.07 471508.63 728384.96 45.07 471508.63 728384.96 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471509.46 728387.57 27.71 471510.22 728389.99 27.71 471510.22 728389.99 45.07 471509.46 728387.57 45.07 471509.46 728387.57 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471510.22 728389.99 27.71 471510.01 728390.06 27.71 471510.01 728390.06 45.07 471510.22 728389.99 45.07 471510.22 728389.99 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471510.01 728390.06 27.71 471527.6 728445.41 27.71 471527.6 728445.41 45.07 471510.01 728390.06 45.07 471510.01 728390.06 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471527.6 728445.41 27.71 471493.39 728456.29 27.71 471493.39 728456.29 45.07 471527.6 728445.41 45.07 471527.6 728445.41 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471493.39 728456.29 27.71 471472.38 728390.08 27.71 471472.38 728390.08 45.07 471493.39 728456.29 45.07 471493.39 728456.29 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471472.38 728390.08 27.71 471472.22 728390.13 27.71 471472.22 728390.13 45.07 471472.38 728390.08 45.07 471472.38 728390.08 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471472.22 728390.13 27.71 471471.64 728388.31 27.71 471471.64 728388.31 45.07 471472.22 728390.13 45.07 471472.22 728390.13 27.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D872-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471471.64 728388.31 45.07 471473.26 728387.8 45.07 471473.29 728387.9 45.07 471504.6 728377.95 45.07 471504.57 728377.85 45.07 471506.22 728377.35 45.07 471508.63 728384.96 45.07 471509.46 728387.57 45.07 471510.22 728389.99 45.07 471510.01 728390.06 45.07 471527.6 728445.41 45.07 471493.39 728456.29 45.07 471472.38 728390.08 45.07 471472.22 728390.13 45.07 471471.64 728388.31 45.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CB61-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CB61-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.37</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB61-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471307.86 728187.77 35.74 471309.9 728194.21 35.74 471314.1 728192.9 35.74 471312.02 728186.5 35.74 471307.86 728187.77 35.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB61-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471307.86 728187.77 35.74 471312.02 728186.5 35.74 471312.02 728186.5 39.11 471307.86 728187.77 39.11 471307.86 728187.77 35.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB61-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.02 728186.5 35.74 471314.1 728192.9 35.74 471314.1 728192.9 39.11 471312.02 728186.5 39.11 471312.02 728186.5 35.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB61-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.1 728192.9 35.74 471309.9 728194.21 35.74 471309.9 728194.21 39.11 471314.1 728192.9 39.11 471314.1 728192.9 35.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB61-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471309.9 728194.21 35.74 471307.86 728187.77 35.74 471307.86 728187.77 39.11 471309.9 728194.21 39.11 471309.9 728194.21 35.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB61-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471307.86 728187.77 39.11 471312.02 728186.5 39.11 471314.1 728192.9 39.11 471309.9 728194.21 39.11 471307.86 728187.77 39.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CC36-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CC36-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.14</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC36-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471595.53 728691.23 26.38 471601.37 728688.02 26.38 471601.4 728688.17 26.38 471601.66 728688.15 26.38 471600.71 728681.82 26.38 471600.43 728681.99 26.38 471600.49 728682.2 26.38 471592.92 728686.46 26.38 471595.53 728691.23 26.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC36-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471595.53 728691.23 26.38 471592.92 728686.46 26.38 471592.92 728686.46 29.52 471595.53 728691.23 29.52 471595.53 728691.23 26.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC36-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471592.92 728686.46 26.38 471600.49 728682.2 26.38 471600.49 728682.2 29.52 471592.92 728686.46 29.52 471592.92 728686.46 26.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC36-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471600.49 728682.2 26.38 471600.43 728681.99 26.38 471600.43 728681.99 29.52 471600.49 728682.2 29.52 471600.49 728682.2 26.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC36-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471600.43 728681.99 26.38 471600.71 728681.82 26.38 471600.71 728681.82 29.52 471600.43 728681.99 29.52 471600.43 728681.99 26.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC36-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471600.71 728681.82 26.38 471601.66 728688.15 26.38 471601.66 728688.15 29.52 471600.71 728681.82 29.52 471600.71 728681.82 26.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC36-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471601.66 728688.15 26.38 471601.4 728688.17 26.38 471601.4 728688.17 29.52 471601.66 728688.15 29.52 471601.66 728688.15 26.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC36-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471601.4 728688.17 26.38 471601.37 728688.02 26.38 471601.37 728688.02 29.52 471601.4 728688.17 29.52 471601.4 728688.17 26.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC36-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471601.37 728688.02 26.38 471595.53 728691.23 26.38 471595.53 728691.23 29.52 471601.37 728688.02 29.52 471601.37 728688.02 26.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC36-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471595.53 728691.23 29.52 471592.92 728686.46 29.52 471600.49 728682.2 29.52 471600.43 728681.99 29.52 471600.71 728681.82 29.52 471601.66 728688.15 29.52 471601.4 728688.17 29.52 471601.37 728688.02 29.52 471595.53 728691.23 29.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CC39-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CC39-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.09</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC39-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471436.89 728285.18 30.92 471445.58 728317.17 30.92 471452.33 728315.37 30.92 471443.64 728283.36 30.92 471436.89 728285.18 30.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC39-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471436.89 728285.18 30.92 471443.64 728283.36 30.92 471443.64 728283.36 34.01 471436.89 728285.18 34.01 471436.89 728285.18 30.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC39-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471443.64 728283.36 30.92 471452.33 728315.37 30.92 471452.33 728315.37 34.01 471443.64 728283.36 34.01 471443.64 728283.36 30.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC39-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471452.33 728315.37 30.92 471445.58 728317.17 30.92 471445.58 728317.17 34.01 471452.33 728315.37 34.01 471452.33 728315.37 30.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC39-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471445.58 728317.17 30.92 471436.89 728285.18 30.92 471436.89 728285.18 34.01 471445.58 728317.17 34.01 471445.58 728317.17 30.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC39-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471436.89 728285.18 34.01 471443.64 728283.36 34.01 471452.33 728315.37 34.01 471445.58 728317.17 34.01 471436.89 728285.18 34.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CC37-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CC37-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.03</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC37-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470154.27 728571.66 67.11 470158.47 728566.68 67.11 470153.01 728561.85 67.11 470148.6 728566.86 67.11 470154.27 728571.66 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC37-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470154.27 728571.66 67.11 470148.6 728566.86 67.11 470148.6 728566.86 70.14 470154.27 728571.66 70.14 470154.27 728571.66 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC37-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470148.6 728566.86 67.11 470153.01 728561.85 67.11 470153.01 728561.85 70.14 470148.6 728566.86 70.14 470148.6 728566.86 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC37-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470153.01 728561.85 67.11 470158.47 728566.68 67.11 470158.47 728566.68 70.14 470153.01 728561.85 70.14 470153.01 728561.85 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC37-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470158.47 728566.68 67.11 470154.27 728571.66 67.11 470154.27 728571.66 70.14 470158.47 728566.68 70.14 470158.47 728566.68 67.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC37-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470154.27 728571.66 70.14 470148.6 728566.86 70.14 470153.01 728561.85 70.14 470158.47 728566.68 70.14 470154.27 728571.66 70.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D870-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D870-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.96</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D870-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471563.72 728509.51 27.74 471564.05 728509.39 27.74 471563.67 728508.23 27.74 471564.29 728508.04 27.74 471594.79 728498.83 27.74 471593.5 728494.53 27.74 471562.09 728504.26 27.74 471563.54 728508.94 27.74 471563.72 728509.51 27.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D870-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471563.72 728509.51 27.74 471563.54 728508.94 27.74 471563.54 728508.94 32.7 471563.72 728509.51 32.7 471563.72 728509.51 27.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D870-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471563.54 728508.94 27.74 471562.09 728504.26 27.74 471562.09 728504.26 32.7 471563.54 728508.94 32.7 471563.54 728508.94 27.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D870-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471562.09 728504.26 27.74 471593.5 728494.53 27.74 471593.5 728494.53 32.7 471562.09 728504.26 32.7 471562.09 728504.26 27.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D870-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471593.5 728494.53 27.74 471594.79 728498.83 27.74 471594.79 728498.83 32.7 471593.5 728494.53 32.7 471593.5 728494.53 27.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D870-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471594.79 728498.83 27.74 471564.29 728508.04 27.74 471564.29 728508.04 32.7 471594.79 728498.83 32.7 471594.79 728498.83 27.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D870-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.29 728508.04 27.74 471563.67 728508.23 27.74 471563.67 728508.23 32.7 471564.29 728508.04 32.7 471564.29 728508.04 27.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D870-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471563.67 728508.23 27.74 471564.05 728509.39 27.74 471564.05 728509.39 32.7 471563.67 728508.23 32.7 471563.67 728508.23 27.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D870-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.05 728509.39 27.74 471563.72 728509.51 27.74 471563.72 728509.51 32.7 471564.05 728509.39 32.7 471564.05 728509.39 27.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D870-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471563.72 728509.51 32.7 471563.54 728508.94 32.7 471562.09 728504.26 32.7 471593.5 728494.53 32.7 471594.79 728498.83 32.7 471564.29 728508.04 32.7 471563.67 728508.23 32.7 471564.05 728509.39 32.7 471563.72 728509.51 32.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CB64-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CB64-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.78</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB64-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471251.47 728266.93 39.03 471252.79 728271.65 39.03 471259.52 728269.74 39.03 471258.2 728265.03 39.03 471251.47 728266.93 39.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB64-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471251.47 728266.93 39.03 471258.2 728265.03 39.03 471258.2 728265.03 41.81 471251.47 728266.93 41.81 471251.47 728266.93 39.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB64-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471258.2 728265.03 39.03 471259.52 728269.74 39.03 471259.52 728269.74 41.81 471258.2 728265.03 41.81 471258.2 728265.03 39.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB64-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471259.52 728269.74 39.03 471252.79 728271.65 39.03 471252.79 728271.65 41.81 471259.52 728269.74 41.81 471259.52 728269.74 39.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB64-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471252.79 728271.65 39.03 471251.47 728266.93 39.03 471251.47 728266.93 41.81 471252.79 728271.65 41.81 471252.79 728271.65 39.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB64-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471251.47 728266.93 41.81 471258.2 728265.03 41.81 471259.52 728269.74 41.81 471252.79 728271.65 41.81 471251.47 728266.93 41.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CB63-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CB63-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.93</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB63-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471276.74 728255.18 37.9 471281.17 728268.17 37.9 471285.55 728266.88 37.9 471281.22 728253.78 37.9 471276.74 728255.18 37.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB63-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471276.74 728255.18 37.9 471281.22 728253.78 37.9 471281.22 728253.78 40.83 471276.74 728255.18 40.83 471276.74 728255.18 37.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB63-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471281.22 728253.78 37.9 471285.55 728266.88 37.9 471285.55 728266.88 40.83 471281.22 728253.78 40.83 471281.22 728253.78 37.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB63-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471285.55 728266.88 37.9 471281.17 728268.17 37.9 471281.17 728268.17 40.83 471285.55 728266.88 40.83 471285.55 728266.88 37.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB63-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471281.17 728268.17 37.9 471276.74 728255.18 37.9 471276.74 728255.18 40.83 471281.17 728268.17 40.83 471281.17 728268.17 37.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB63-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471276.74 728255.18 40.83 471281.22 728253.78 40.83 471285.55 728266.88 40.83 471281.17 728268.17 40.83 471276.74 728255.18 40.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CB62-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CB62-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.61</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB62-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471222.88 728304.58 43.34 471226.14 728313.55 43.34 471231.3 728311.62 43.34 471230.23 728308.76 43.34 471235.08 728307.06 43.34 471234.66 728305.88 43.34 471234.91 728305.78 43.34 471233.16 728300.85 43.34 471222.88 728304.58 43.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB62-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471222.88 728304.58 43.34 471233.16 728300.85 43.34 471233.16 728300.85 48.95 471222.88 728304.58 48.95 471222.88 728304.58 43.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB62-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471233.16 728300.85 43.34 471234.91 728305.78 43.34 471234.91 728305.78 48.95 471233.16 728300.85 48.95 471233.16 728300.85 43.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB62-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471234.91 728305.78 43.34 471234.66 728305.88 43.34 471234.66 728305.88 48.95 471234.91 728305.78 48.95 471234.91 728305.78 43.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB62-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471234.66 728305.88 43.34 471235.08 728307.06 43.34 471235.08 728307.06 48.95 471234.66 728305.88 48.95 471234.66 728305.88 43.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB62-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471235.08 728307.06 43.34 471230.23 728308.76 43.34 471230.23 728308.76 48.95 471235.08 728307.06 48.95 471235.08 728307.06 43.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB62-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471230.23 728308.76 43.34 471231.3 728311.62 43.34 471231.3 728311.62 48.95 471230.23 728308.76 48.95 471230.23 728308.76 43.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB62-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471231.3 728311.62 43.34 471226.14 728313.55 43.34 471226.14 728313.55 48.95 471231.3 728311.62 48.95 471231.3 728311.62 43.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB62-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471226.14 728313.55 43.34 471222.88 728304.58 43.34 471222.88 728304.58 48.95 471226.14 728313.55 48.95 471226.14 728313.55 43.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB62-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471222.88 728304.58 48.95 471233.16 728300.85 48.95 471234.91 728305.78 48.95 471234.66 728305.88 48.95 471235.08 728307.06 48.95 471230.23 728308.76 48.95 471231.3 728311.62 48.95 471226.14 728313.55 48.95 471222.88 728304.58 48.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CB69-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CB69-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.15</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB69-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.27 728430.22 32.98 471425.78 728442.4 32.98 471432.12 728440.6 32.98 471428.61 728428.4 32.98 471422.27 728430.22 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB69-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.27 728430.22 32.98 471428.61 728428.4 32.98 471428.61 728428.4 36.13 471422.27 728430.22 36.13 471422.27 728430.22 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB69-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471428.61 728428.4 32.98 471432.12 728440.6 32.98 471432.12 728440.6 36.13 471428.61 728428.4 36.13 471428.61 728428.4 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB69-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471432.12 728440.6 32.98 471425.78 728442.4 32.98 471425.78 728442.4 36.13 471432.12 728440.6 36.13 471432.12 728440.6 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB69-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471425.78 728442.4 32.98 471422.27 728430.22 32.98 471422.27 728430.22 36.13 471425.78 728442.4 36.13 471425.78 728442.4 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB69-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.27 728430.22 36.13 471428.61 728428.4 36.13 471432.12 728440.6 36.13 471425.78 728442.4 36.13 471422.27 728430.22 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CB68-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CB68-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.68</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB68-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.91 728316.82 32.36 471387.24 728315.65 32.36 471380.96 728296.58 32.36 471377.86 728297.58 32.36 471383.91 728316.82 32.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB68-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.91 728316.82 32.36 471377.86 728297.58 32.36 471377.86 728297.58 35.04 471383.91 728316.82 35.04 471383.91 728316.82 32.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB68-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471377.86 728297.58 32.36 471380.96 728296.58 32.36 471380.96 728296.58 35.04 471377.86 728297.58 35.04 471377.86 728297.58 32.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB68-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.96 728296.58 32.36 471387.24 728315.65 32.36 471387.24 728315.65 35.04 471380.96 728296.58 35.04 471380.96 728296.58 32.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB68-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.24 728315.65 32.36 471383.91 728316.82 32.36 471383.91 728316.82 35.04 471387.24 728315.65 35.04 471387.24 728315.65 32.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB68-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.91 728316.82 35.04 471377.86 728297.58 35.04 471380.96 728296.58 35.04 471387.24 728315.65 35.04 471383.91 728316.82 35.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CB67-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CB67-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB67-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.32 728453.79 36.83 471340.62 728460.73 36.83 471346.86 728458.78 36.83 471344.39 728450.91 36.83 471340.99 728451.86 36.83 471340.45 728449.94 36.83 471338.53 728450.47 36.83 471339.36 728453.46 36.83 471338.32 728453.79 36.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB67-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.32 728453.79 36.83 471339.36 728453.46 36.83 471339.36 728453.46 39.12 471338.32 728453.79 39.12 471338.32 728453.79 36.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB67-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.36 728453.46 36.83 471338.53 728450.47 36.83 471338.53 728450.47 39.12 471339.36 728453.46 39.12 471339.36 728453.46 36.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB67-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.53 728450.47 36.83 471340.45 728449.94 36.83 471340.45 728449.94 39.12 471338.53 728450.47 39.12 471338.53 728450.47 36.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB67-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471340.45 728449.94 36.83 471340.99 728451.86 36.83 471340.99 728451.86 39.12 471340.45 728449.94 39.12 471340.45 728449.94 36.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB67-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471340.99 728451.86 36.83 471344.39 728450.91 36.83 471344.39 728450.91 39.12 471340.99 728451.86 39.12 471340.99 728451.86 36.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB67-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.39 728450.91 36.83 471346.86 728458.78 36.83 471346.86 728458.78 39.12 471344.39 728450.91 39.12 471344.39 728450.91 36.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB67-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471346.86 728458.78 36.83 471340.62 728460.73 36.83 471340.62 728460.73 39.12 471346.86 728458.78 39.12 471346.86 728458.78 36.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB67-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471340.62 728460.73 36.83 471338.32 728453.79 36.83 471338.32 728453.79 39.12 471340.62 728460.73 39.12 471340.62 728460.73 36.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB67-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.32 728453.79 39.12 471339.36 728453.46 39.12 471338.53 728450.47 39.12 471340.45 728449.94 39.12 471340.99 728451.86 39.12 471344.39 728450.91 39.12 471346.86 728458.78 39.12 471340.62 728460.73 39.12 471338.32 728453.79 39.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CB66-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CB66-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB66-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471229.03 728321.53 45.29 471235.93 728339.88 45.29 471244.28 728336.93 45.29 471237.35 728318.91 45.29 471229.03 728321.53 45.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB66-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471229.03 728321.53 45.29 471237.35 728318.91 45.29 471237.35 728318.91 49.08 471229.03 728321.53 49.08 471229.03 728321.53 45.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB66-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471237.35 728318.91 45.29 471244.28 728336.93 45.29 471244.28 728336.93 49.08 471237.35 728318.91 49.08 471237.35 728318.91 45.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB66-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471244.28 728336.93 45.29 471235.93 728339.88 45.29 471235.93 728339.88 49.08 471244.28 728336.93 49.08 471244.28 728336.93 45.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB66-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471235.93 728339.88 45.29 471229.03 728321.53 45.29 471229.03 728321.53 49.08 471235.93 728339.88 49.08 471235.93 728339.88 45.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB66-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471229.03 728321.53 49.08 471237.35 728318.91 49.08 471244.28 728336.93 49.08 471235.93 728339.88 49.08 471229.03 728321.53 49.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CB65-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CB65-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.28</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB65-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471308.26 728255.42 36.14 471309.15 728258.29 36.14 471323.47 728253.84 36.14 471322.55 728250.98 36.14 471308.26 728255.42 36.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB65-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471308.26 728255.42 36.14 471322.55 728250.98 36.14 471322.55 728250.98 38.42 471308.26 728255.42 38.42 471308.26 728255.42 36.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB65-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471322.55 728250.98 36.14 471323.47 728253.84 36.14 471323.47 728253.84 38.42 471322.55 728250.98 38.42 471322.55 728250.98 36.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB65-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471323.47 728253.84 36.14 471309.15 728258.29 36.14 471309.15 728258.29 38.42 471323.47 728253.84 38.42 471323.47 728253.84 36.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB65-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471309.15 728258.29 36.14 471308.26 728255.42 36.14 471308.26 728255.42 38.42 471309.15 728258.29 38.42 471309.15 728258.29 36.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB65-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471308.26 728255.42 38.42 471322.55 728250.98 38.42 471323.47 728253.84 38.42 471309.15 728258.29 38.42 471308.26 728255.42 38.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CA93-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CA93-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.56</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA93-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471217.88 728217.3 41.32 471212.12 728219.23 41.32 471213.18 728222.35 41.32 471218.87 728220.42 41.32 471217.88 728217.3 41.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA93-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471217.88 728217.3 41.32 471218.87 728220.42 41.32 471218.87 728220.42 43.88 471217.88 728217.3 43.88 471217.88 728217.3 41.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA93-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471218.87 728220.42 41.32 471213.18 728222.35 41.32 471213.18 728222.35 43.88 471218.87 728220.42 43.88 471218.87 728220.42 41.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA93-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471213.18 728222.35 41.32 471212.12 728219.23 41.32 471212.12 728219.23 43.88 471213.18 728222.35 43.88 471213.18 728222.35 41.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA93-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471212.12 728219.23 41.32 471217.88 728217.3 41.32 471217.88 728217.3 43.88 471212.12 728219.23 43.88 471212.12 728219.23 41.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA93-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471217.88 728217.3 43.88 471218.87 728220.42 43.88 471213.18 728222.35 43.88 471212.12 728219.23 43.88 471217.88 728217.3 43.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5585-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">17.18</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471496.12 728774.59 29.42 471496.92 728777.7 29.42 471498.03 728782.04 29.42 471502.97 728798.99 29.42 471516.3 728795.14 29.42 471513.5 728785.25 29.42 471512.55 728785.52 29.42 471512.36 728784.79 29.42 471513.31 728784.51 29.42 471512.65 728782.25 29.42 471511.69 728782.53 29.42 471511.5 728781.79 29.42 471512.45 728781.5 29.42 471511.82 728779.28 29.42 471510.85 728779.56 29.42 471510.65 728778.81 29.42 471511.62 728778.53 29.42 471510.96 728776.31 29.42 471510.04 728776.59 29.42 471509.82 728775.87 29.42 471510.79 728775.58 29.42 471510.25 728773.8 29.42 471507.35 728774.62 29.42 471499.92 728776.74 29.42 471499 728773.83 29.42 471496.12 728774.59 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471496.12 728774.59 29.42 471499 728773.83 29.42 471499 728773.83 46.6 471496.12 728774.59 46.6 471496.12 728774.59 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471499 728773.83 29.42 471499.92 728776.74 29.42 471499.92 728776.74 46.6 471499 728773.83 46.6 471499 728773.83 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471499.92 728776.74 29.42 471507.35 728774.62 29.42 471507.35 728774.62 46.6 471499.92 728776.74 46.6 471499.92 728776.74 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471507.35 728774.62 29.42 471510.25 728773.8 29.42 471510.25 728773.8 46.6 471507.35 728774.62 46.6 471507.35 728774.62 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471510.25 728773.8 29.42 471510.79 728775.58 29.42 471510.79 728775.58 46.6 471510.25 728773.8 46.6 471510.25 728773.8 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471510.79 728775.58 29.42 471509.82 728775.87 29.42 471509.82 728775.87 46.6 471510.79 728775.58 46.6 471510.79 728775.58 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471509.82 728775.87 29.42 471510.04 728776.59 29.42 471510.04 728776.59 46.6 471509.82 728775.87 46.6 471509.82 728775.87 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471510.04 728776.59 29.42 471510.96 728776.31 29.42 471510.96 728776.31 46.6 471510.04 728776.59 46.6 471510.04 728776.59 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471510.96 728776.31 29.42 471511.62 728778.53 29.42 471511.62 728778.53 46.6 471510.96 728776.31 46.6 471510.96 728776.31 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471511.62 728778.53 29.42 471510.65 728778.81 29.42 471510.65 728778.81 46.6 471511.62 728778.53 46.6 471511.62 728778.53 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471510.65 728778.81 29.42 471510.85 728779.56 29.42 471510.85 728779.56 46.6 471510.65 728778.81 46.6 471510.65 728778.81 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471510.85 728779.56 29.42 471511.82 728779.28 29.42 471511.82 728779.28 46.6 471510.85 728779.56 46.6 471510.85 728779.56 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471511.82 728779.28 29.42 471512.45 728781.5 29.42 471512.45 728781.5 46.6 471511.82 728779.28 46.6 471511.82 728779.28 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471512.45 728781.5 29.42 471511.5 728781.79 29.42 471511.5 728781.79 46.6 471512.45 728781.5 46.6 471512.45 728781.5 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471511.5 728781.79 29.42 471511.69 728782.53 29.42 471511.69 728782.53 46.6 471511.5 728781.79 46.6 471511.5 728781.79 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471511.69 728782.53 29.42 471512.65 728782.25 29.42 471512.65 728782.25 46.6 471511.69 728782.53 46.6 471511.69 728782.53 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471512.65 728782.25 29.42 471513.31 728784.51 29.42 471513.31 728784.51 46.6 471512.65 728782.25 46.6 471512.65 728782.25 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471513.31 728784.51 29.42 471512.36 728784.79 29.42 471512.36 728784.79 46.6 471513.31 728784.51 46.6 471513.31 728784.51 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471512.36 728784.79 29.42 471512.55 728785.52 29.42 471512.55 728785.52 46.6 471512.36 728784.79 46.6 471512.36 728784.79 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471512.55 728785.52 29.42 471513.5 728785.25 29.42 471513.5 728785.25 46.6 471512.55 728785.52 46.6 471512.55 728785.52 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471513.5 728785.25 29.42 471516.3 728795.14 29.42 471516.3 728795.14 46.6 471513.5 728785.25 46.6 471513.5 728785.25 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471516.3 728795.14 29.42 471502.97 728798.99 29.42 471502.97 728798.99 46.6 471516.3 728795.14 46.6 471516.3 728795.14 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471502.97 728798.99 29.42 471498.03 728782.04 29.42 471498.03 728782.04 46.6 471502.97 728798.99 46.6 471502.97 728798.99 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471498.03 728782.04 29.42 471496.92 728777.7 29.42 471496.92 728777.7 46.6 471498.03 728782.04 46.6 471498.03 728782.04 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471496.92 728777.7 29.42 471496.12 728774.59 29.42 471496.12 728774.59 46.6 471496.92 728777.7 46.6 471496.92 728777.7 29.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5585-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471496.12 728774.59 46.6 471499 728773.83 46.6 471499.92 728776.74 46.6 471507.35 728774.62 46.6 471510.25 728773.8 46.6 471510.79 728775.58 46.6 471509.82 728775.87 46.6 471510.04 728776.59 46.6 471510.96 728776.31 46.6 471511.62 728778.53 46.6 471510.65 728778.81 46.6 471510.85 728779.56 46.6 471511.82 728779.28 46.6 471512.45 728781.5 46.6 471511.5 728781.79 46.6 471511.69 728782.53 46.6 471512.65 728782.25 46.6 471513.31 728784.51 46.6 471512.36 728784.79 46.6 471512.55 728785.52 46.6 471513.5 728785.25 46.6 471516.3 728795.14 46.6 471502.97 728798.99 46.6 471498.03 728782.04 46.6 471496.92 728777.7 46.6 471496.12 728774.59 46.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.1</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471594.67 728562.11 23.7 471597.63 728561.19 23.7 471599.27 728559.98 23.7 471600.47 728558.62 23.7 471599.87 728556.78 23.7 471606.51 728554.7 23.7 471601.57 728538.97 23.7 471603.47 728535.48 23.7 471606.29 728537.23 23.7 471605.57 728538.65 23.7 471608.46 728547.84 23.7 471611.57 728547.81 23.7 471613.98 728546.11 23.7 471614.19 728546.04 23.7 471611.89 728538.7 23.7 471613 728538.35 23.7 471603.03 728506.69 23.7 471600.38 728507.52 23.7 471569.67 728517.13 23.7 471574.91 728533.82 23.7 471572.97 728537.2 23.7 471575.23 728544.39 23.7 471578.63 728546.21 23.7 471583.62 728561.9 23.7 471590.22 728559.82 23.7 471590.82 728561.61 23.7 471592.82 728562.09 23.7 471594.67 728562.11 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471594.67 728562.11 23.7 471592.82 728562.09 23.7 471592.82 728562.09 32.8 471594.67 728562.11 32.8 471594.67 728562.11 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471592.82 728562.09 23.7 471590.82 728561.61 23.7 471590.82 728561.61 32.8 471592.82 728562.09 32.8 471592.82 728562.09 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471590.82 728561.61 23.7 471590.22 728559.82 23.7 471590.22 728559.82 32.8 471590.82 728561.61 32.8 471590.82 728561.61 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471590.22 728559.82 23.7 471583.62 728561.9 23.7 471583.62 728561.9 32.8 471590.22 728559.82 32.8 471590.22 728559.82 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471583.62 728561.9 23.7 471578.63 728546.21 23.7 471578.63 728546.21 32.8 471583.62 728561.9 32.8 471583.62 728561.9 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471578.63 728546.21 23.7 471575.23 728544.39 23.7 471575.23 728544.39 32.8 471578.63 728546.21 32.8 471578.63 728546.21 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471575.23 728544.39 23.7 471572.97 728537.2 23.7 471572.97 728537.2 32.8 471575.23 728544.39 32.8 471575.23 728544.39 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471572.97 728537.2 23.7 471574.91 728533.82 23.7 471574.91 728533.82 32.8 471572.97 728537.2 32.8 471572.97 728537.2 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471574.91 728533.82 23.7 471569.67 728517.13 23.7 471569.67 728517.13 32.8 471574.91 728533.82 32.8 471574.91 728533.82 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471569.67 728517.13 23.7 471600.38 728507.52 23.7 471600.38 728507.52 32.8 471569.67 728517.13 32.8 471569.67 728517.13 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471600.38 728507.52 23.7 471603.03 728506.69 23.7 471603.03 728506.69 32.8 471600.38 728507.52 32.8 471600.38 728507.52 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471603.03 728506.69 23.7 471613 728538.35 23.7 471613 728538.35 32.8 471603.03 728506.69 32.8 471603.03 728506.69 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471613 728538.35 23.7 471611.89 728538.7 23.7 471611.89 728538.7 32.8 471613 728538.35 32.8 471613 728538.35 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471611.89 728538.7 23.7 471614.19 728546.04 23.7 471614.19 728546.04 32.8 471611.89 728538.7 32.8 471611.89 728538.7 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471614.19 728546.04 23.7 471613.98 728546.11 23.7 471613.98 728546.11 32.8 471614.19 728546.04 32.8 471614.19 728546.04 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471613.98 728546.11 23.7 471611.57 728547.81 23.7 471611.57 728547.81 32.8 471613.98 728546.11 32.8 471613.98 728546.11 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471611.57 728547.81 23.7 471608.46 728547.84 23.7 471608.46 728547.84 32.8 471611.57 728547.81 32.8 471611.57 728547.81 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471608.46 728547.84 23.7 471605.57 728538.65 23.7 471605.57 728538.65 32.8 471608.46 728547.84 32.8 471608.46 728547.84 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471605.57 728538.65 23.7 471606.29 728537.23 23.7 471606.29 728537.23 32.8 471605.57 728538.65 32.8 471605.57 728538.65 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471606.29 728537.23 23.7 471603.47 728535.48 23.7 471603.47 728535.48 32.8 471606.29 728537.23 32.8 471606.29 728537.23 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471603.47 728535.48 23.7 471601.57 728538.97 23.7 471601.57 728538.97 32.8 471603.47 728535.48 32.8 471603.47 728535.48 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471601.57 728538.97 23.7 471606.51 728554.7 23.7 471606.51 728554.7 32.8 471601.57 728538.97 32.8 471601.57 728538.97 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471606.51 728554.7 23.7 471599.87 728556.78 23.7 471599.87 728556.78 32.8 471606.51 728554.7 32.8 471606.51 728554.7 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471599.87 728556.78 23.7 471600.47 728558.62 23.7 471600.47 728558.62 32.8 471599.87 728556.78 32.8 471599.87 728556.78 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471600.47 728558.62 23.7 471599.27 728559.98 23.7 471599.27 728559.98 32.8 471600.47 728558.62 32.8 471600.47 728558.62 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471599.27 728559.98 23.7 471597.63 728561.19 23.7 471597.63 728561.19 32.8 471599.27 728559.98 32.8 471599.27 728559.98 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471597.63 728561.19 23.7 471594.67 728562.11 23.7 471594.67 728562.11 32.8 471597.63 728561.19 32.8 471597.63 728561.19 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B7-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471594.67 728562.11 32.8 471592.82 728562.09 32.8 471590.82 728561.61 32.8 471590.22 728559.82 32.8 471583.62 728561.9 32.8 471578.63 728546.21 32.8 471575.23 728544.39 32.8 471572.97 728537.2 32.8 471574.91 728533.82 32.8 471569.67 728517.13 32.8 471600.38 728507.52 32.8 471603.03 728506.69 32.8 471613 728538.35 32.8 471611.89 728538.7 32.8 471614.19 728546.04 32.8 471613.98 728546.11 32.8 471611.57 728547.81 32.8 471608.46 728547.84 32.8 471605.57 728538.65 32.8 471606.29 728537.23 32.8 471603.47 728535.48 32.8 471601.57 728538.97 32.8 471606.51 728554.7 32.8 471599.87 728556.78 32.8 471600.47 728558.62 32.8 471599.27 728559.98 32.8 471597.63 728561.19 32.8 471594.67 728562.11 32.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471538.65 728424.89 26.27 471541.34 728433.36 26.27 471540.87 728433.47 26.27 471540.79 728433.3 26.27 471540.51 728433.41 26.27 471541.29 728435.17 26.27 471541.02 728435.32 26.27 471541.97 728437.36 26.27 471542.54 728437.16 26.27 471545.81 728448.19 26.27 471545.52 728448.37 26.27 471545.9 728450.58 26.27 471546.2 728450.53 26.27 471546.55 728452.43 26.27 471546.81 728452.4 26.27 471546.87 728452.13 26.27 471547.25 728452.04 26.27 471550.85 728463.24 26.27 471585.75 728452.44 26.27 471573.48 728414 26.27 471538.65 728424.89 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471538.65 728424.89 26.27 471573.48 728414 26.27 471573.48 728414 36.21 471538.65 728424.89 36.21 471538.65 728424.89 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471573.48 728414 26.27 471585.75 728452.44 26.27 471585.75 728452.44 36.21 471573.48 728414 36.21 471573.48 728414 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471585.75 728452.44 26.27 471550.85 728463.24 26.27 471550.85 728463.24 36.21 471585.75 728452.44 36.21 471585.75 728452.44 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471550.85 728463.24 26.27 471547.25 728452.04 26.27 471547.25 728452.04 36.21 471550.85 728463.24 36.21 471550.85 728463.24 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471547.25 728452.04 26.27 471546.87 728452.13 26.27 471546.87 728452.13 36.21 471547.25 728452.04 36.21 471547.25 728452.04 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471546.87 728452.13 26.27 471546.81 728452.4 26.27 471546.81 728452.4 36.21 471546.87 728452.13 36.21 471546.87 728452.13 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471546.81 728452.4 26.27 471546.55 728452.43 26.27 471546.55 728452.43 36.21 471546.81 728452.4 36.21 471546.81 728452.4 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471546.55 728452.43 26.27 471546.2 728450.53 26.27 471546.2 728450.53 36.21 471546.55 728452.43 36.21 471546.55 728452.43 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471546.2 728450.53 26.27 471545.9 728450.58 26.27 471545.9 728450.58 36.21 471546.2 728450.53 36.21 471546.2 728450.53 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471545.9 728450.58 26.27 471545.52 728448.37 26.27 471545.52 728448.37 36.21 471545.9 728450.58 36.21 471545.9 728450.58 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471545.52 728448.37 26.27 471545.81 728448.19 26.27 471545.81 728448.19 36.21 471545.52 728448.37 36.21 471545.52 728448.37 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471545.81 728448.19 26.27 471542.54 728437.16 26.27 471542.54 728437.16 36.21 471545.81 728448.19 36.21 471545.81 728448.19 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471542.54 728437.16 26.27 471541.97 728437.36 26.27 471541.97 728437.36 36.21 471542.54 728437.16 36.21 471542.54 728437.16 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471541.97 728437.36 26.27 471541.02 728435.32 26.27 471541.02 728435.32 36.21 471541.97 728437.36 36.21 471541.97 728437.36 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471541.02 728435.32 26.27 471541.29 728435.17 26.27 471541.29 728435.17 36.21 471541.02 728435.32 36.21 471541.02 728435.32 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471541.29 728435.17 26.27 471540.51 728433.41 26.27 471540.51 728433.41 36.21 471541.29 728435.17 36.21 471541.29 728435.17 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471540.51 728433.41 26.27 471540.79 728433.3 26.27 471540.79 728433.3 36.21 471540.51 728433.41 36.21 471540.51 728433.41 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471540.79 728433.3 26.27 471540.87 728433.47 26.27 471540.87 728433.47 36.21 471540.79 728433.3 36.21 471540.79 728433.3 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471540.87 728433.47 26.27 471541.34 728433.36 26.27 471541.34 728433.36 36.21 471540.87 728433.47 36.21 471540.87 728433.47 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471541.34 728433.36 26.27 471538.65 728424.89 26.27 471538.65 728424.89 36.21 471541.34 728433.36 36.21 471541.34 728433.36 26.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D7B6-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471538.65 728424.89 36.21 471573.48 728414 36.21 471585.75 728452.44 36.21 471550.85 728463.24 36.21 471547.25 728452.04 36.21 471546.87 728452.13 36.21 471546.81 728452.4 36.21 471546.55 728452.43 36.21 471546.2 728450.53 36.21 471545.9 728450.58 36.21 471545.52 728448.37 36.21 471545.81 728448.19 36.21 471542.54 728437.16 36.21 471541.97 728437.36 36.21 471541.02 728435.32 36.21 471541.29 728435.17 36.21 471540.51 728433.41 36.21 471540.79 728433.3 36.21 471540.87 728433.47 36.21 471541.34 728433.36 36.21 471538.65 728424.89 36.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD98-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD98-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.24</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD98-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471389.13 728470.03 34.08 471414.2 728462.81 34.08 471412.12 728455.65 34.08 471387 728462.89 34.08 471387.14 728463.46 34.08 471389.13 728470.03 34.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD98-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471389.13 728470.03 34.08 471387.14 728463.46 34.08 471387.14 728463.46 44.32 471389.13 728470.03 44.32 471389.13 728470.03 34.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD98-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.14 728463.46 34.08 471387 728462.89 34.08 471387 728462.89 44.32 471387.14 728463.46 44.32 471387.14 728463.46 34.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD98-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387 728462.89 34.08 471412.12 728455.65 34.08 471412.12 728455.65 44.32 471387 728462.89 44.32 471387 728462.89 34.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD98-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.12 728455.65 34.08 471414.2 728462.81 34.08 471414.2 728462.81 44.32 471412.12 728455.65 44.32 471412.12 728455.65 34.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD98-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471414.2 728462.81 34.08 471389.13 728470.03 34.08 471389.13 728470.03 44.32 471414.2 728462.81 44.32 471414.2 728462.81 34.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD98-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471389.13 728470.03 44.32 471387.14 728463.46 44.32 471387 728462.89 44.32 471412.12 728455.65 44.32 471414.2 728462.81 44.32 471389.13 728470.03 44.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.39</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471388.85 728493.6 35.16 471396.5 728491.44 35.16 471394.1 728483.18 35.16 471391.59 728474.33 35.16 471390.44 728474.65 35.16 471389.13 728470.03 35.16 471387.14 728463.46 35.16 471380.78 728465.24 35.16 471380.86 728465.6 35.16 471374.96 728467.17 35.16 471379.72 728483.58 35.16 471382.68 728493.56 35.16 471388.34 728491.9 35.16 471388.85 728493.6 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471388.85 728493.6 35.16 471388.34 728491.9 35.16 471388.34 728491.9 41.550000000000004 471388.85 728493.6 41.550000000000004 471388.85 728493.6 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471388.34 728491.9 35.16 471382.68 728493.56 35.16 471382.68 728493.56 41.550000000000004 471388.34 728491.9 41.550000000000004 471388.34 728491.9 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471382.68 728493.56 35.16 471379.72 728483.58 35.16 471379.72 728483.58 41.550000000000004 471382.68 728493.56 41.550000000000004 471382.68 728493.56 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.72 728483.58 35.16 471374.96 728467.17 35.16 471374.96 728467.17 41.550000000000004 471379.72 728483.58 41.550000000000004 471379.72 728483.58 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471374.96 728467.17 35.16 471380.86 728465.6 35.16 471380.86 728465.6 41.550000000000004 471374.96 728467.17 41.550000000000004 471374.96 728467.17 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.86 728465.6 35.16 471380.78 728465.24 35.16 471380.78 728465.24 41.550000000000004 471380.86 728465.6 41.550000000000004 471380.86 728465.6 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.78 728465.24 35.16 471387.14 728463.46 35.16 471387.14 728463.46 41.550000000000004 471380.78 728465.24 41.550000000000004 471380.78 728465.24 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.14 728463.46 35.16 471389.13 728470.03 35.16 471389.13 728470.03 41.550000000000004 471387.14 728463.46 41.550000000000004 471387.14 728463.46 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471389.13 728470.03 35.16 471390.44 728474.65 35.16 471390.44 728474.65 41.550000000000004 471389.13 728470.03 41.550000000000004 471389.13 728470.03 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.44 728474.65 35.16 471391.59 728474.33 35.16 471391.59 728474.33 41.550000000000004 471390.44 728474.65 41.550000000000004 471390.44 728474.65 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471391.59 728474.33 35.16 471394.1 728483.18 35.16 471394.1 728483.18 41.550000000000004 471391.59 728474.33 41.550000000000004 471391.59 728474.33 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471394.1 728483.18 35.16 471396.5 728491.44 35.16 471396.5 728491.44 41.550000000000004 471394.1 728483.18 41.550000000000004 471394.1 728483.18 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.5 728491.44 35.16 471388.85 728493.6 35.16 471388.85 728493.6 41.550000000000004 471396.5 728491.44 41.550000000000004 471396.5 728491.44 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD97-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471388.85 728493.6 41.550000000000004 471388.34 728491.9 41.550000000000004 471382.68 728493.56 41.550000000000004 471379.72 728483.58 41.550000000000004 471374.96 728467.17 41.550000000000004 471380.86 728465.6 41.550000000000004 471380.78 728465.24 41.550000000000004 471387.14 728463.46 41.550000000000004 471389.13 728470.03 41.550000000000004 471390.44 728474.65 41.550000000000004 471391.59 728474.33 41.550000000000004 471394.1 728483.18 41.550000000000004 471396.5 728491.44 41.550000000000004 471388.85 728493.6 41.550000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD96-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD96-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.34</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD96-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471398.85 728519.89 34.15 471400.92 728529.27 34.15 471419.62 728525.22 34.15 471418.95 728521.97 34.15 471424.48 728521.42 34.15 471423.96 728518.74 34.15 471418.47 728519.65 34.15 471417.7 728515.83 34.15 471398.85 728519.89 34.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD96-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471398.85 728519.89 34.15 471417.7 728515.83 34.15 471417.7 728515.83 43.49 471398.85 728519.89 43.49 471398.85 728519.89 34.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD96-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471417.7 728515.83 34.15 471418.47 728519.65 34.15 471418.47 728519.65 43.49 471417.7 728515.83 43.49 471417.7 728515.83 34.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD96-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471418.47 728519.65 34.15 471423.96 728518.74 34.15 471423.96 728518.74 43.49 471418.47 728519.65 43.49 471418.47 728519.65 34.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD96-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.96 728518.74 34.15 471424.48 728521.42 34.15 471424.48 728521.42 43.49 471423.96 728518.74 43.49 471423.96 728518.74 34.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD96-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.48 728521.42 34.15 471418.95 728521.97 34.15 471418.95 728521.97 43.49 471424.48 728521.42 43.49 471424.48 728521.42 34.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD96-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471418.95 728521.97 34.15 471419.62 728525.22 34.15 471419.62 728525.22 43.49 471418.95 728521.97 43.49 471418.95 728521.97 34.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD96-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471419.62 728525.22 34.15 471400.92 728529.27 34.15 471400.92 728529.27 43.49 471419.62 728525.22 43.49 471419.62 728525.22 34.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD96-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471400.92 728529.27 34.15 471398.85 728519.89 34.15 471398.85 728519.89 43.49 471400.92 728529.27 43.49 471400.92 728529.27 34.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD96-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471398.85 728519.89 43.49 471417.7 728515.83 43.49 471418.47 728519.65 43.49 471423.96 728518.74 43.49 471424.48 728521.42 43.49 471418.95 728521.97 43.49 471419.62 728525.22 43.49 471400.92 728529.27 43.49 471398.85 728519.89 43.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CB60-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CB60-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB60-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471259.26 728221.96 37.9 471261.08 728228.36 37.9 471260.27 728228.81 37.9 471261.21 728232.47 37.9 471267.66 728230.64 37.9 471264.39 728220.6 37.9 471259.26 728221.96 37.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB60-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471259.26 728221.96 37.9 471264.39 728220.6 37.9 471264.39 728220.6 40.43 471259.26 728221.96 40.43 471259.26 728221.96 37.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB60-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471264.39 728220.6 37.9 471267.66 728230.64 37.9 471267.66 728230.64 40.43 471264.39 728220.6 40.43 471264.39 728220.6 37.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB60-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471267.66 728230.64 37.9 471261.21 728232.47 37.9 471261.21 728232.47 40.43 471267.66 728230.64 40.43 471267.66 728230.64 37.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB60-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471261.21 728232.47 37.9 471260.27 728228.81 37.9 471260.27 728228.81 40.43 471261.21 728232.47 40.43 471261.21 728232.47 37.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB60-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471260.27 728228.81 37.9 471261.08 728228.36 37.9 471261.08 728228.36 40.43 471260.27 728228.81 40.43 471260.27 728228.81 37.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB60-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471261.08 728228.36 37.9 471259.26 728221.96 37.9 471259.26 728221.96 40.43 471261.08 728228.36 40.43 471261.08 728228.36 37.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CB60-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471259.26 728221.96 40.43 471264.39 728220.6 40.43 471267.66 728230.64 40.43 471261.21 728232.47 40.43 471260.27 728228.81 40.43 471261.08 728228.36 40.43 471259.26 728221.96 40.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DAB6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DAB6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.58</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DAB6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.87 728717.21 32.98 471459.15 728747.82 32.98 471467.72 728745.18 32.98 471459.23 728716.85 32.98 471453.36 728718.62 32.98 471452.69 728716.36 32.98 471449.87 728717.21 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DAB6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.87 728717.21 32.98 471452.69 728716.36 32.98 471452.69 728716.36 38.56 471449.87 728717.21 38.56 471449.87 728717.21 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DAB6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471452.69 728716.36 32.98 471453.36 728718.62 32.98 471453.36 728718.62 38.56 471452.69 728716.36 38.56 471452.69 728716.36 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DAB6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471453.36 728718.62 32.98 471459.23 728716.85 32.98 471459.23 728716.85 38.56 471453.36 728718.62 38.56 471453.36 728718.62 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DAB6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471459.23 728716.85 32.98 471467.72 728745.18 32.98 471467.72 728745.18 38.56 471459.23 728716.85 38.56 471459.23 728716.85 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DAB6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471467.72 728745.18 32.98 471459.15 728747.82 32.98 471459.15 728747.82 38.56 471467.72 728745.18 38.56 471467.72 728745.18 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DAB6-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471459.15 728747.82 32.98 471449.87 728717.21 32.98 471449.87 728717.21 38.56 471459.15 728747.82 38.56 471459.15 728747.82 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DAB6-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.87 728717.21 38.56 471452.69 728716.36 38.56 471453.36 728718.62 38.56 471459.23 728716.85 38.56 471467.72 728745.18 38.56 471459.15 728747.82 38.56 471449.87 728717.21 38.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CC32-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CC32-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.07</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC32-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.62 728462.28 37.38 471330.84 728468.1 37.38 471337.92 728465.38 37.38 471335.66 728459.55 37.38 471328.62 728462.28 37.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC32-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.62 728462.28 37.38 471335.66 728459.55 37.38 471335.66 728459.55 40.45 471328.62 728462.28 40.45 471328.62 728462.28 37.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC32-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471335.66 728459.55 37.38 471337.92 728465.38 37.38 471337.92 728465.38 40.45 471335.66 728459.55 40.45 471335.66 728459.55 37.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC32-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.92 728465.38 37.38 471330.84 728468.1 37.38 471330.84 728468.1 40.45 471337.92 728465.38 40.45 471337.92 728465.38 37.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC32-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.84 728468.1 37.38 471328.62 728462.28 37.38 471328.62 728462.28 40.45 471330.84 728468.1 40.45 471330.84 728468.1 37.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC32-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.62 728462.28 40.45 471335.66 728459.55 40.45 471337.92 728465.38 40.45 471330.84 728468.1 40.45 471328.62 728462.28 40.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CC31-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CC31-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.69</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC31-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471454.93 728600.07 30.15 471455.45 728604.4 30.15 471464.83 728603.25 30.15 471463.65 728593.71 30.15 471458.23 728594.32 30.15 471458.87 728599.59 30.15 471454.93 728600.07 30.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC31-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471454.93 728600.07 30.15 471458.87 728599.59 30.15 471458.87 728599.59 33.84 471454.93 728600.07 33.84 471454.93 728600.07 30.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC31-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471458.87 728599.59 30.15 471458.23 728594.32 30.15 471458.23 728594.32 33.84 471458.87 728599.59 33.84 471458.87 728599.59 30.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC31-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471458.23 728594.32 30.15 471463.65 728593.71 30.15 471463.65 728593.71 33.84 471458.23 728594.32 33.84 471458.23 728594.32 30.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC31-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471463.65 728593.71 30.15 471464.83 728603.25 30.15 471464.83 728603.25 33.84 471463.65 728593.71 33.84 471463.65 728593.71 30.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC31-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471464.83 728603.25 30.15 471455.45 728604.4 30.15 471455.45 728604.4 33.84 471464.83 728603.25 33.84 471464.83 728603.25 30.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC31-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.45 728604.4 30.15 471454.93 728600.07 30.15 471454.93 728600.07 33.84 471455.45 728604.4 33.84 471455.45 728604.4 30.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC31-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471454.93 728600.07 33.84 471458.87 728599.59 33.84 471458.23 728594.32 33.84 471463.65 728593.71 33.84 471464.83 728603.25 33.84 471455.45 728604.4 33.84 471454.93 728600.07 33.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C577-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.54</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470252.02 728427.43 67.75 470252.5 728422.89 67.75 470254.9 728423.14 67.75 470255.4 728418.23 67.75 470252.99 728418.1 67.75 470240.08 728416.68 67.75 470239.59 728420.96 67.75 470238.55 728420.86 67.75 470238.35 728422.73 67.75 470239.4 728422.84 67.75 470239.05 728426.08 67.75 470252.02 728427.43 67.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470252.02 728427.43 67.75 470239.05 728426.08 67.75 470239.05 728426.08 74.29 470252.02 728427.43 74.29 470252.02 728427.43 67.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470239.05 728426.08 67.75 470239.4 728422.84 67.75 470239.4 728422.84 74.29 470239.05 728426.08 74.29 470239.05 728426.08 67.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470239.4 728422.84 67.75 470238.35 728422.73 67.75 470238.35 728422.73 74.29 470239.4 728422.84 74.29 470239.4 728422.84 67.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470238.35 728422.73 67.75 470238.55 728420.86 67.75 470238.55 728420.86 74.29 470238.35 728422.73 74.29 470238.35 728422.73 67.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470238.55 728420.86 67.75 470239.59 728420.96 67.75 470239.59 728420.96 74.29 470238.55 728420.86 74.29 470238.55 728420.86 67.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470239.59 728420.96 67.75 470240.08 728416.68 67.75 470240.08 728416.68 74.29 470239.59 728420.96 74.29 470239.59 728420.96 67.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470240.08 728416.68 67.75 470252.99 728418.1 67.75 470252.99 728418.1 74.29 470240.08 728416.68 74.29 470240.08 728416.68 67.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470252.99 728418.1 67.75 470255.4 728418.23 67.75 470255.4 728418.23 74.29 470252.99 728418.1 74.29 470252.99 728418.1 67.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470255.4 728418.23 67.75 470254.9 728423.14 67.75 470254.9 728423.14 74.29 470255.4 728418.23 74.29 470255.4 728418.23 67.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470254.9 728423.14 67.75 470252.5 728422.89 67.75 470252.5 728422.89 74.29 470254.9 728423.14 74.29 470254.9 728423.14 67.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470252.5 728422.89 67.75 470252.02 728427.43 67.75 470252.02 728427.43 74.29 470252.5 728422.89 74.29 470252.5 728422.89 67.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C577-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470252.02 728427.43 74.29 470239.05 728426.08 74.29 470239.4 728422.84 74.29 470238.35 728422.73 74.29 470238.55 728420.86 74.29 470239.59 728420.96 74.29 470240.08 728416.68 74.29 470252.99 728418.1 74.29 470255.4 728418.23 74.29 470254.9 728423.14 74.29 470252.5 728422.89 74.29 470252.02 728427.43 74.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C008-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.82</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.51 728438.16 35.51 471379.1 728450.68 35.51 471379.38 728450.58 35.51 471379.31 728450.32 35.51 471384.74 728448.74 35.51 471384.81 728449 35.51 471385.1 728448.92 35.51 471381.56 728436.44 35.51 471381.27 728436.51 35.51 471381.41 728437 35.51 471375.94 728438.57 35.51 471375.8 728438.09 35.51 471375.51 728438.16 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.51 728438.16 35.51 471375.8 728438.09 35.51 471375.8 728438.09 40.33 471375.51 728438.16 40.33 471375.51 728438.16 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.8 728438.09 35.51 471375.94 728438.57 35.51 471375.94 728438.57 40.33 471375.8 728438.09 40.33 471375.8 728438.09 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.94 728438.57 35.51 471381.41 728437 35.51 471381.41 728437 40.33 471375.94 728438.57 40.33 471375.94 728438.57 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.41 728437 35.51 471381.27 728436.51 35.51 471381.27 728436.51 40.33 471381.41 728437 40.33 471381.41 728437 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.27 728436.51 35.51 471381.56 728436.44 35.51 471381.56 728436.44 40.33 471381.27 728436.51 40.33 471381.27 728436.51 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.56 728436.44 35.51 471385.1 728448.92 35.51 471385.1 728448.92 40.33 471381.56 728436.44 40.33 471381.56 728436.44 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.1 728448.92 35.51 471384.81 728449 35.51 471384.81 728449 40.33 471385.1 728448.92 40.33 471385.1 728448.92 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.81 728449 35.51 471384.74 728448.74 35.51 471384.74 728448.74 40.33 471384.81 728449 40.33 471384.81 728449 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.74 728448.74 35.51 471379.31 728450.32 35.51 471379.31 728450.32 40.33 471384.74 728448.74 40.33 471384.74 728448.74 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.31 728450.32 35.51 471379.38 728450.58 35.51 471379.38 728450.58 40.33 471379.31 728450.32 40.33 471379.31 728450.32 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.38 728450.58 35.51 471379.1 728450.68 35.51 471379.1 728450.68 40.33 471379.38 728450.58 40.33 471379.38 728450.58 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.1 728450.68 35.51 471375.51 728438.16 35.51 471375.51 728438.16 40.33 471379.1 728450.68 40.33 471379.1 728450.68 35.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C008-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.51 728438.16 40.33 471375.8 728438.09 40.33 471375.94 728438.57 40.33 471381.41 728437 40.33 471381.27 728436.51 40.33 471381.56 728436.44 40.33 471385.1 728448.92 40.33 471384.81 728449 40.33 471384.74 728448.74 40.33 471379.31 728450.32 40.33 471379.38 728450.58 40.33 471379.1 728450.68 40.33 471375.51 728438.16 40.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD08-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD08-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.45</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD08-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470149.61 728577.32 67.02 470154.27 728571.66 67.02 470148.6 728566.86 67.02 470144.07 728572.74 67.02 470149.61 728577.32 67.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD08-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470149.61 728577.32 67.02 470144.07 728572.74 67.02 470144.07 728572.74 69.47 470149.61 728577.32 69.47 470149.61 728577.32 67.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD08-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470144.07 728572.74 67.02 470148.6 728566.86 67.02 470148.6 728566.86 69.47 470144.07 728572.74 69.47 470144.07 728572.74 67.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD08-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470148.6 728566.86 67.02 470154.27 728571.66 67.02 470154.27 728571.66 69.47 470148.6 728566.86 69.47 470148.6 728566.86 67.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD08-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470154.27 728571.66 67.02 470149.61 728577.32 67.02 470149.61 728577.32 69.47 470154.27 728571.66 69.47 470154.27 728571.66 67.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD08-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470149.61 728577.32 69.47 470144.07 728572.74 69.47 470148.6 728566.86 69.47 470154.27 728571.66 69.47 470149.61 728577.32 69.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD06-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD06-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.42</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD06-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470228.77 728427.12 66.99 470229.43 728420.68 66.99 470221.41 728419.86 66.99 470220.78 728426.31 66.99 470228.77 728427.12 66.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD06-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470228.77 728427.12 66.99 470220.78 728426.31 66.99 470220.78 728426.31 70.41 470228.77 728427.12 70.41 470228.77 728427.12 66.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD06-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470220.78 728426.31 66.99 470221.41 728419.86 66.99 470221.41 728419.86 70.41 470220.78 728426.31 70.41 470220.78 728426.31 66.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD06-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470221.41 728419.86 66.99 470229.43 728420.68 66.99 470229.43 728420.68 70.41 470221.41 728419.86 70.41 470221.41 728419.86 66.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD06-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470229.43 728420.68 66.99 470228.77 728427.12 66.99 470228.77 728427.12 70.41 470229.43 728420.68 70.41 470229.43 728420.68 66.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD06-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470228.77 728427.12 70.41 470220.78 728426.31 70.41 470221.41 728419.86 70.41 470229.43 728420.68 70.41 470228.77 728427.12 70.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD07-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD07-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.34</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD07-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470008.19 728714.89 71.2 470013.77 728712.57 71.2 470009.92 728703.31 71.2 470004.34 728705.63 71.2 470008.19 728714.89 71.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD07-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470008.19 728714.89 71.2 470004.34 728705.63 71.2 470004.34 728705.63 75.545 470008.19 728714.89 75.545 470008.19 728714.89 71.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD07-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470004.34 728705.63 71.2 470009.92 728703.31 71.2 470009.92 728703.31 75.545 470004.34 728705.63 75.545 470004.34 728705.63 71.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD07-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470009.92 728703.31 71.2 470013.77 728712.57 71.2 470013.77 728712.57 75.545 470009.92 728703.31 75.545 470009.92 728703.31 71.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD07-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470013.77 728712.57 71.2 470008.19 728714.89 71.2 470008.19 728714.89 75.545 470013.77 728712.57 75.545 470013.77 728712.57 71.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD07-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470008.19 728714.89 75.545 470004.34 728705.63 75.545 470009.92 728703.31 75.545 470013.77 728712.57 75.545 470008.19 728714.89 75.545</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD05-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD05-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD05-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470226.97 728444.74 66.94 470228.77 728427.12 66.94 470220.78 728426.31 66.94 470218.97 728443.93 66.94 470226.97 728444.74 66.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD05-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470226.97 728444.74 66.94 470218.97 728443.93 66.94 470218.97 728443.93 73.37 470226.97 728444.74 73.37 470226.97 728444.74 66.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD05-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470218.97 728443.93 66.94 470220.78 728426.31 66.94 470220.78 728426.31 73.37 470218.97 728443.93 73.37 470218.97 728443.93 66.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD05-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470220.78 728426.31 66.94 470228.77 728427.12 66.94 470228.77 728427.12 73.37 470220.78 728426.31 73.37 470220.78 728426.31 66.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD05-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470228.77 728427.12 66.94 470226.97 728444.74 66.94 470226.97 728444.74 73.37 470228.77 728427.12 73.37 470228.77 728427.12 66.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD05-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470226.97 728444.74 73.37 470218.97 728443.93 73.37 470220.78 728426.31 73.37 470228.77 728427.12 73.37 470226.97 728444.74 73.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4C99-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4C99-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.02</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C99-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470067.54 728657.99 69.47 470070.34 728656.39 69.47 470066.86 728650.25 69.47 470064.05 728651.86 69.47 470063.03 728652.44 69.47 470063.74 728653.67 69.47 470064.73 728653.11 69.47 470067.54 728657.99 69.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C99-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470067.54 728657.99 69.47 470064.73 728653.11 69.47 470064.73 728653.11 74.49 470067.54 728657.99 74.49 470067.54 728657.99 69.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C99-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470064.73 728653.11 69.47 470063.74 728653.67 69.47 470063.74 728653.67 74.49 470064.73 728653.11 74.49 470064.73 728653.11 69.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C99-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470063.74 728653.67 69.47 470063.03 728652.44 69.47 470063.03 728652.44 74.49 470063.74 728653.67 74.49 470063.74 728653.67 69.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C99-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470063.03 728652.44 69.47 470064.05 728651.86 69.47 470064.05 728651.86 74.49 470063.03 728652.44 74.49 470063.03 728652.44 69.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C99-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470064.05 728651.86 69.47 470066.86 728650.25 69.47 470066.86 728650.25 74.49 470064.05 728651.86 74.49 470064.05 728651.86 69.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C99-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470066.86 728650.25 69.47 470070.34 728656.39 69.47 470070.34 728656.39 74.49 470066.86 728650.25 74.49 470066.86 728650.25 69.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C99-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470070.34 728656.39 69.47 470067.54 728657.99 69.47 470067.54 728657.99 74.49 470070.34 728656.39 74.49 470070.34 728656.39 69.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C99-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470067.54 728657.99 74.49 470064.73 728653.11 74.49 470063.74 728653.67 74.49 470063.03 728652.44 74.49 470064.05 728651.86 74.49 470066.86 728650.25 74.49 470070.34 728656.39 74.49 470067.54 728657.99 74.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4C95-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4C95-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.15</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C95-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470078.42 728669.51 70.52 470084.55 728665.81 70.52 470080.07 728658.4 70.52 470073.94 728662.1 70.52 470078.42 728669.51 70.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C95-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470078.42 728669.51 70.52 470073.94 728662.1 70.52 470073.94 728662.1 76.67 470078.42 728669.51 76.67 470078.42 728669.51 70.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C95-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470073.94 728662.1 70.52 470080.07 728658.4 70.52 470080.07 728658.4 76.67 470073.94 728662.1 76.67 470073.94 728662.1 70.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C95-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470080.07 728658.4 70.52 470084.55 728665.81 70.52 470084.55 728665.81 76.67 470080.07 728658.4 76.67 470080.07 728658.4 70.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C95-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470084.55 728665.81 70.52 470078.42 728669.51 70.52 470078.42 728669.51 76.67 470084.55 728665.81 76.67 470084.55 728665.81 70.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C95-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470078.42 728669.51 76.67 470073.94 728662.1 76.67 470080.07 728658.4 76.67 470084.55 728665.81 76.67 470078.42 728669.51 76.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4C9A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4C9A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.27</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C9A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470070.34 728656.39 69.23 470072.95 728654.89 69.23 470070.21 728650.05 69.23 470071.24 728649.45 69.23 470070.51 728648.16 69.23 470069.46 728648.76 69.23 470066.86 728650.25 69.23 470070.34 728656.39 69.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C9A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470070.34 728656.39 69.23 470066.86 728650.25 69.23 470066.86 728650.25 74.5 470070.34 728656.39 74.5 470070.34 728656.39 69.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C9A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470066.86 728650.25 69.23 470069.46 728648.76 69.23 470069.46 728648.76 74.5 470066.86 728650.25 74.5 470066.86 728650.25 69.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C9A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470069.46 728648.76 69.23 470070.51 728648.16 69.23 470070.51 728648.16 74.5 470069.46 728648.76 74.5 470069.46 728648.76 69.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C9A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470070.51 728648.16 69.23 470071.24 728649.45 69.23 470071.24 728649.45 74.5 470070.51 728648.16 74.5 470070.51 728648.16 69.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C9A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470071.24 728649.45 69.23 470070.21 728650.05 69.23 470070.21 728650.05 74.5 470071.24 728649.45 74.5 470071.24 728649.45 69.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C9A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470070.21 728650.05 69.23 470072.95 728654.89 69.23 470072.95 728654.89 74.5 470070.21 728650.05 74.5 470070.21 728650.05 69.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C9A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470072.95 728654.89 69.23 470070.34 728656.39 69.23 470070.34 728656.39 74.5 470072.95 728654.89 74.5 470072.95 728654.89 69.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C9A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470070.34 728656.39 74.5 470066.86 728650.25 74.5 470069.46 728648.76 74.5 470070.51 728648.16 74.5 470071.24 728649.45 74.5 470070.21 728650.05 74.5 470072.95 728654.89 74.5 470070.34 728656.39 74.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6317-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.49</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.85 728443.91 36.39 471348.8 728446.85 36.39 471350.66 728446.25 36.39 471350.47 728445.88 36.39 471352.37 728445.25 36.39 471356.34 728457.33 36.39 471354.03 728458.14 36.39 471355.34 728461.95 36.39 471357.89 728461.12 36.39 471357.68 728460.55 36.39 471366.34 728457.89 36.39 471366.74 728459.07 36.39 471369.51 728458.13 36.39 471368.16 728453.99 36.39 471365.42 728454.81 36.39 471361.32 728442.65 36.39 471364.32 728441.73 36.39 471363.1 728437.99 36.39 471359.69 728439.05 36.39 471359.87 728439.65 36.39 471351.54 728442.59 36.39 471351.63 728442.85 36.39 471349.66 728443.46 36.39 471349.6 728443.27 36.39 471347.85 728443.91 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.85 728443.91 36.39 471349.6 728443.27 36.39 471349.6 728443.27 40.88 471347.85 728443.91 40.88 471347.85 728443.91 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471349.6 728443.27 36.39 471349.66 728443.46 36.39 471349.66 728443.46 40.88 471349.6 728443.27 40.88 471349.6 728443.27 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471349.66 728443.46 36.39 471351.63 728442.85 36.39 471351.63 728442.85 40.88 471349.66 728443.46 40.88 471349.66 728443.46 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471351.63 728442.85 36.39 471351.54 728442.59 36.39 471351.54 728442.59 40.88 471351.63 728442.85 40.88 471351.63 728442.85 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471351.54 728442.59 36.39 471359.87 728439.65 36.39 471359.87 728439.65 40.88 471351.54 728442.59 40.88 471351.54 728442.59 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471359.87 728439.65 36.39 471359.69 728439.05 36.39 471359.69 728439.05 40.88 471359.87 728439.65 40.88 471359.87 728439.65 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471359.69 728439.05 36.39 471363.1 728437.99 36.39 471363.1 728437.99 40.88 471359.69 728439.05 40.88 471359.69 728439.05 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471363.1 728437.99 36.39 471364.32 728441.73 36.39 471364.32 728441.73 40.88 471363.1 728437.99 40.88 471363.1 728437.99 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.32 728441.73 36.39 471361.32 728442.65 36.39 471361.32 728442.65 40.88 471364.32 728441.73 40.88 471364.32 728441.73 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471361.32 728442.65 36.39 471365.42 728454.81 36.39 471365.42 728454.81 40.88 471361.32 728442.65 40.88 471361.32 728442.65 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471365.42 728454.81 36.39 471368.16 728453.99 36.39 471368.16 728453.99 40.88 471365.42 728454.81 40.88 471365.42 728454.81 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.16 728453.99 36.39 471369.51 728458.13 36.39 471369.51 728458.13 40.88 471368.16 728453.99 40.88 471368.16 728453.99 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.51 728458.13 36.39 471366.74 728459.07 36.39 471366.74 728459.07 40.88 471369.51 728458.13 40.88 471369.51 728458.13 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471366.74 728459.07 36.39 471366.34 728457.89 36.39 471366.34 728457.89 40.88 471366.74 728459.07 40.88 471366.74 728459.07 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471366.34 728457.89 36.39 471357.68 728460.55 36.39 471357.68 728460.55 40.88 471366.34 728457.89 40.88 471366.34 728457.89 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471357.68 728460.55 36.39 471357.89 728461.12 36.39 471357.89 728461.12 40.88 471357.68 728460.55 40.88 471357.68 728460.55 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471357.89 728461.12 36.39 471355.34 728461.95 36.39 471355.34 728461.95 40.88 471357.89 728461.12 40.88 471357.89 728461.12 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.34 728461.95 36.39 471354.03 728458.14 36.39 471354.03 728458.14 40.88 471355.34 728461.95 40.88 471355.34 728461.95 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.03 728458.14 36.39 471356.34 728457.33 36.39 471356.34 728457.33 40.88 471354.03 728458.14 40.88 471354.03 728458.14 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471356.34 728457.33 36.39 471352.37 728445.25 36.39 471352.37 728445.25 40.88 471356.34 728457.33 40.88 471356.34 728457.33 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471352.37 728445.25 36.39 471350.47 728445.88 36.39 471350.47 728445.88 40.88 471352.37 728445.25 40.88 471352.37 728445.25 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.47 728445.88 36.39 471350.66 728446.25 36.39 471350.66 728446.25 40.88 471350.47 728445.88 40.88 471350.47 728445.88 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.66 728446.25 36.39 471348.8 728446.85 36.39 471348.8 728446.85 40.88 471350.66 728446.25 40.88 471350.66 728446.25 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471348.8 728446.85 36.39 471347.85 728443.91 36.39 471347.85 728443.91 40.88 471348.8 728446.85 40.88 471348.8 728446.85 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6317-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.85 728443.91 40.88 471349.6 728443.27 40.88 471349.66 728443.46 40.88 471351.63 728442.85 40.88 471351.54 728442.59 40.88 471359.87 728439.65 40.88 471359.69 728439.05 40.88 471363.1 728437.99 40.88 471364.32 728441.73 40.88 471361.32 728442.65 40.88 471365.42 728454.81 40.88 471368.16 728453.99 40.88 471369.51 728458.13 40.88 471366.74 728459.07 40.88 471366.34 728457.89 40.88 471357.68 728460.55 40.88 471357.89 728461.12 40.88 471355.34 728461.95 40.88 471354.03 728458.14 40.88 471356.34 728457.33 40.88 471352.37 728445.25 40.88 471350.47 728445.88 40.88 471350.66 728446.25 40.88 471348.8 728446.85 40.88 471347.85 728443.91 40.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-631C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-631C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.67</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.05 728509.39 26.89 471563.72 728509.51 26.89 471556.4 728511.9 26.89 471559.19 728520.52 26.89 471560.21 728523.7 26.89 471567.09 728521.48 26.89 471566.06 728518.3 26.89 471566.89 728518.05 26.89 471564.05 728509.39 26.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.05 728509.39 26.89 471566.89 728518.05 26.89 471566.89 728518.05 31.560000000000002 471564.05 728509.39 31.560000000000002 471564.05 728509.39 26.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471566.89 728518.05 26.89 471566.06 728518.3 26.89 471566.06 728518.3 31.560000000000002 471566.89 728518.05 31.560000000000002 471566.89 728518.05 26.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471566.06 728518.3 26.89 471567.09 728521.48 26.89 471567.09 728521.48 31.560000000000002 471566.06 728518.3 31.560000000000002 471566.06 728518.3 26.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471567.09 728521.48 26.89 471560.21 728523.7 26.89 471560.21 728523.7 31.560000000000002 471567.09 728521.48 31.560000000000002 471567.09 728521.48 26.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471560.21 728523.7 26.89 471559.19 728520.52 26.89 471559.19 728520.52 31.560000000000002 471560.21 728523.7 31.560000000000002 471560.21 728523.7 26.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.19 728520.52 26.89 471556.4 728511.9 26.89 471556.4 728511.9 31.560000000000002 471559.19 728520.52 31.560000000000002 471559.19 728520.52 26.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471556.4 728511.9 26.89 471563.72 728509.51 26.89 471563.72 728509.51 31.560000000000002 471556.4 728511.9 31.560000000000002 471556.4 728511.9 26.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471563.72 728509.51 26.89 471564.05 728509.39 26.89 471564.05 728509.39 31.560000000000002 471563.72 728509.51 31.560000000000002 471563.72 728509.51 26.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.05 728509.39 31.560000000000002 471566.89 728518.05 31.560000000000002 471566.06 728518.3 31.560000000000002 471567.09 728521.48 31.560000000000002 471560.21 728523.7 31.560000000000002 471559.19 728520.52 31.560000000000002 471556.4 728511.9 31.560000000000002 471563.72 728509.51 31.560000000000002 471564.05 728509.39 31.560000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-631B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.07</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471485.5 728719.13 28.1 471489 728731.25 28.1 471495.69 728729.36 28.1 471494.78 728726.16 28.1 471497.93 728725.26 28.1 471500.49 728734.14 28.1 471512.09 728730.83 28.1 471517.33 728730.19 28.1 471518.1 728734.95 28.1 471519.38 728734.75 28.1 471519.36 728734.52 28.1 471538.88 728732.49 28.1 471538.94 728732.69 28.1 471539.18 728732.68 28.1 471537.93 728721.26 28.1 471537.61 728721.36 28.1 471537.67 728721.59 28.1 471510.3 728724.52 28.1 471499.56 728686.71 28.1 471505.45 728685 28.1 471505.34 728684.61 28.1 471505.11 728684.64 28.1 471502.8 728676.42 28.1 471506.37 728675.39 28.1 471506.26 728675 28.1 471506.02 728675.08 28.1 471503.83 728666.75 28.1 471507.5 728665.69 28.1 471507.41 728665.32 28.1 471507.16 728665.37 28.1 471504.9 728657.1 28.1 471505.08 728657.03 28.1 471505 728656.66 28.1 471492.49 728660.16 28.1 471492.59 728660.55 28.1 471492.84 728660.49 28.1 471495.15 728668.75 28.1 471491.44 728669.87 28.1 471491.55 728670.2 28.1 471491.79 728670.13 28.1 471494.27 728678.33 28.1 471488.15 728680.08 28.1 471488.28 728680.46 28.1 471488.45 728680.44 28.1 471490.81 728688.65 28.1 471490.57 728688.71 28.1 471490.7 728689.11 28.1 471491.17 728688.96 28.1 471491.93 728691.37 28.1 471492.67 728692.46 28.1 471488.83 728693.56 28.1 471496.38 728719.81 28.1 471493.19 728720.76 28.1 471492.13 728717.18 28.1 471485.5 728719.13 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471485.5 728719.13 28.1 471492.13 728717.18 28.1 471492.13 728717.18 35.17 471485.5 728719.13 35.17 471485.5 728719.13 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471492.13 728717.18 28.1 471493.19 728720.76 28.1 471493.19 728720.76 35.17 471492.13 728717.18 35.17 471492.13 728717.18 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471493.19 728720.76 28.1 471496.38 728719.81 28.1 471496.38 728719.81 35.17 471493.19 728720.76 35.17 471493.19 728720.76 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471496.38 728719.81 28.1 471488.83 728693.56 28.1 471488.83 728693.56 35.17 471496.38 728719.81 35.17 471496.38 728719.81 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471488.83 728693.56 28.1 471492.67 728692.46 28.1 471492.67 728692.46 35.17 471488.83 728693.56 35.17 471488.83 728693.56 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471492.67 728692.46 28.1 471491.93 728691.37 28.1 471491.93 728691.37 35.17 471492.67 728692.46 35.17 471492.67 728692.46 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471491.93 728691.37 28.1 471491.17 728688.96 28.1 471491.17 728688.96 35.17 471491.93 728691.37 35.17 471491.93 728691.37 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471491.17 728688.96 28.1 471490.7 728689.11 28.1 471490.7 728689.11 35.17 471491.17 728688.96 35.17 471491.17 728688.96 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471490.7 728689.11 28.1 471490.57 728688.71 28.1 471490.57 728688.71 35.17 471490.7 728689.11 35.17 471490.7 728689.11 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471490.57 728688.71 28.1 471490.81 728688.65 28.1 471490.81 728688.65 35.17 471490.57 728688.71 35.17 471490.57 728688.71 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471490.81 728688.65 28.1 471488.45 728680.44 28.1 471488.45 728680.44 35.17 471490.81 728688.65 35.17 471490.81 728688.65 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471488.45 728680.44 28.1 471488.28 728680.46 28.1 471488.28 728680.46 35.17 471488.45 728680.44 35.17 471488.45 728680.44 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471488.28 728680.46 28.1 471488.15 728680.08 28.1 471488.15 728680.08 35.17 471488.28 728680.46 35.17 471488.28 728680.46 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471488.15 728680.08 28.1 471494.27 728678.33 28.1 471494.27 728678.33 35.17 471488.15 728680.08 35.17 471488.15 728680.08 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471494.27 728678.33 28.1 471491.79 728670.13 28.1 471491.79 728670.13 35.17 471494.27 728678.33 35.17 471494.27 728678.33 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471491.79 728670.13 28.1 471491.55 728670.2 28.1 471491.55 728670.2 35.17 471491.79 728670.13 35.17 471491.79 728670.13 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471491.55 728670.2 28.1 471491.44 728669.87 28.1 471491.44 728669.87 35.17 471491.55 728670.2 35.17 471491.55 728670.2 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471491.44 728669.87 28.1 471495.15 728668.75 28.1 471495.15 728668.75 35.17 471491.44 728669.87 35.17 471491.44 728669.87 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471495.15 728668.75 28.1 471492.84 728660.49 28.1 471492.84 728660.49 35.17 471495.15 728668.75 35.17 471495.15 728668.75 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471492.84 728660.49 28.1 471492.59 728660.55 28.1 471492.59 728660.55 35.17 471492.84 728660.49 35.17 471492.84 728660.49 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471492.59 728660.55 28.1 471492.49 728660.16 28.1 471492.49 728660.16 35.17 471492.59 728660.55 35.17 471492.59 728660.55 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471492.49 728660.16 28.1 471505 728656.66 28.1 471505 728656.66 35.17 471492.49 728660.16 35.17 471492.49 728660.16 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471505 728656.66 28.1 471505.08 728657.03 28.1 471505.08 728657.03 35.17 471505 728656.66 35.17 471505 728656.66 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471505.08 728657.03 28.1 471504.9 728657.1 28.1 471504.9 728657.1 35.17 471505.08 728657.03 35.17 471505.08 728657.03 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471504.9 728657.1 28.1 471507.16 728665.37 28.1 471507.16 728665.37 35.17 471504.9 728657.1 35.17 471504.9 728657.1 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471507.16 728665.37 28.1 471507.41 728665.32 28.1 471507.41 728665.32 35.17 471507.16 728665.37 35.17 471507.16 728665.37 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471507.41 728665.32 28.1 471507.5 728665.69 28.1 471507.5 728665.69 35.17 471507.41 728665.32 35.17 471507.41 728665.32 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471507.5 728665.69 28.1 471503.83 728666.75 28.1 471503.83 728666.75 35.17 471507.5 728665.69 35.17 471507.5 728665.69 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471503.83 728666.75 28.1 471506.02 728675.08 28.1 471506.02 728675.08 35.17 471503.83 728666.75 35.17 471503.83 728666.75 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471506.02 728675.08 28.1 471506.26 728675 28.1 471506.26 728675 35.17 471506.02 728675.08 35.17 471506.02 728675.08 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471506.26 728675 28.1 471506.37 728675.39 28.1 471506.37 728675.39 35.17 471506.26 728675 35.17 471506.26 728675 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471506.37 728675.39 28.1 471502.8 728676.42 28.1 471502.8 728676.42 35.17 471506.37 728675.39 35.17 471506.37 728675.39 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471502.8 728676.42 28.1 471505.11 728684.64 28.1 471505.11 728684.64 35.17 471502.8 728676.42 35.17 471502.8 728676.42 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471505.11 728684.64 28.1 471505.34 728684.61 28.1 471505.34 728684.61 35.17 471505.11 728684.64 35.17 471505.11 728684.64 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471505.34 728684.61 28.1 471505.45 728685 28.1 471505.45 728685 35.17 471505.34 728684.61 35.17 471505.34 728684.61 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471505.45 728685 28.1 471499.56 728686.71 28.1 471499.56 728686.71 35.17 471505.45 728685 35.17 471505.45 728685 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471499.56 728686.71 28.1 471510.3 728724.52 28.1 471510.3 728724.52 35.17 471499.56 728686.71 35.17 471499.56 728686.71 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471510.3 728724.52 28.1 471537.67 728721.59 28.1 471537.67 728721.59 35.17 471510.3 728724.52 35.17 471510.3 728724.52 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471537.67 728721.59 28.1 471537.61 728721.36 28.1 471537.61 728721.36 35.17 471537.67 728721.59 35.17 471537.67 728721.59 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471537.61 728721.36 28.1 471537.93 728721.26 28.1 471537.93 728721.26 35.17 471537.61 728721.36 35.17 471537.61 728721.36 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471537.93 728721.26 28.1 471539.18 728732.68 28.1 471539.18 728732.68 35.17 471537.93 728721.26 35.17 471537.93 728721.26 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471539.18 728732.68 28.1 471538.94 728732.69 28.1 471538.94 728732.69 35.17 471539.18 728732.68 35.17 471539.18 728732.68 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471538.94 728732.69 28.1 471538.88 728732.49 28.1 471538.88 728732.49 35.17 471538.94 728732.69 35.17 471538.94 728732.69 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471538.88 728732.49 28.1 471519.36 728734.52 28.1 471519.36 728734.52 35.17 471538.88 728732.49 35.17 471538.88 728732.49 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471519.36 728734.52 28.1 471519.38 728734.75 28.1 471519.38 728734.75 35.17 471519.36 728734.52 35.17 471519.36 728734.52 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471519.38 728734.75 28.1 471518.1 728734.95 28.1 471518.1 728734.95 35.17 471519.38 728734.75 35.17 471519.38 728734.75 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471518.1 728734.95 28.1 471517.33 728730.19 28.1 471517.33 728730.19 35.17 471518.1 728734.95 35.17 471518.1 728734.95 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471517.33 728730.19 28.1 471512.09 728730.83 28.1 471512.09 728730.83 35.17 471517.33 728730.19 35.17 471517.33 728730.19 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471512.09 728730.83 28.1 471500.49 728734.14 28.1 471500.49 728734.14 35.17 471512.09 728730.83 35.17 471512.09 728730.83 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471500.49 728734.14 28.1 471497.93 728725.26 28.1 471497.93 728725.26 35.17 471500.49 728734.14 35.17 471500.49 728734.14 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471497.93 728725.26 28.1 471494.78 728726.16 28.1 471494.78 728726.16 35.17 471497.93 728725.26 35.17 471497.93 728725.26 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471494.78 728726.16 28.1 471495.69 728729.36 28.1 471495.69 728729.36 35.17 471494.78 728726.16 35.17 471494.78 728726.16 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471495.69 728729.36 28.1 471489 728731.25 28.1 471489 728731.25 35.17 471495.69 728729.36 35.17 471495.69 728729.36 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471489 728731.25 28.1 471485.5 728719.13 28.1 471485.5 728719.13 35.17 471489 728731.25 35.17 471489 728731.25 28.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631B-FAF6-E053-CA2BA8C0FAE4_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471485.5 728719.13 35.17 471492.13 728717.18 35.17 471493.19 728720.76 35.17 471496.38 728719.81 35.17 471488.83 728693.56 35.17 471492.67 728692.46 35.17 471491.93 728691.37 35.17 471491.17 728688.96 35.17 471490.7 728689.11 35.17 471490.57 728688.71 35.17 471490.81 728688.65 35.17 471488.45 728680.44 35.17 471488.28 728680.46 35.17 471488.15 728680.08 35.17 471494.27 728678.33 35.17 471491.79 728670.13 35.17 471491.55 728670.2 35.17 471491.44 728669.87 35.17 471495.15 728668.75 35.17 471492.84 728660.49 35.17 471492.59 728660.55 35.17 471492.49 728660.16 35.17 471505 728656.66 35.17 471505.08 728657.03 35.17 471504.9 728657.1 35.17 471507.16 728665.37 35.17 471507.41 728665.32 35.17 471507.5 728665.69 35.17 471503.83 728666.75 35.17 471506.02 728675.08 35.17 471506.26 728675 35.17 471506.37 728675.39 35.17 471502.8 728676.42 35.17 471505.11 728684.64 35.17 471505.34 728684.61 35.17 471505.45 728685 35.17 471499.56 728686.71 35.17 471510.3 728724.52 35.17 471537.67 728721.59 35.17 471537.61 728721.36 35.17 471537.93 728721.26 35.17 471539.18 728732.68 35.17 471538.94 728732.69 35.17 471538.88 728732.49 35.17 471519.36 728734.52 35.17 471519.38 728734.75 35.17 471518.1 728734.95 35.17 471517.33 728730.19 35.17 471512.09 728730.83 35.17 471500.49 728734.14 35.17 471497.93 728725.26 35.17 471494.78 728726.16 35.17 471495.69 728729.36 35.17 471489 728731.25 35.17 471485.5 728719.13 35.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6319-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471433.15 728430.1 32.16 471435.33 728437.76 32.16 471445.05 728435.06 32.16 471445.94 728437.97 32.16 471450.84 728436.59 32.16 471451.04 728436.14 32.16 471454.66 728434.91 32.16 471453.44 728430.82 32.16 471450.3 728431.68 32.16 471449.42 728428.43 32.16 471452 728427.55 32.16 471451.18 728424.94 32.16 471433.15 728430.1 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471433.15 728430.1 32.16 471451.18 728424.94 32.16 471451.18 728424.94 37.95 471433.15 728430.1 37.95 471433.15 728430.1 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471451.18 728424.94 32.16 471452 728427.55 32.16 471452 728427.55 37.95 471451.18 728424.94 37.95 471451.18 728424.94 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471452 728427.55 32.16 471449.42 728428.43 32.16 471449.42 728428.43 37.95 471452 728427.55 37.95 471452 728427.55 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471449.42 728428.43 32.16 471450.3 728431.68 32.16 471450.3 728431.68 37.95 471449.42 728428.43 37.95 471449.42 728428.43 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.3 728431.68 32.16 471453.44 728430.82 32.16 471453.44 728430.82 37.95 471450.3 728431.68 37.95 471450.3 728431.68 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471453.44 728430.82 32.16 471454.66 728434.91 32.16 471454.66 728434.91 37.95 471453.44 728430.82 37.95 471453.44 728430.82 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471454.66 728434.91 32.16 471451.04 728436.14 32.16 471451.04 728436.14 37.95 471454.66 728434.91 37.95 471454.66 728434.91 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471451.04 728436.14 32.16 471450.84 728436.59 32.16 471450.84 728436.59 37.95 471451.04 728436.14 37.95 471451.04 728436.14 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471450.84 728436.59 32.16 471445.94 728437.97 32.16 471445.94 728437.97 37.95 471450.84 728436.59 37.95 471450.84 728436.59 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471445.94 728437.97 32.16 471445.05 728435.06 32.16 471445.05 728435.06 37.95 471445.94 728437.97 37.95 471445.94 728437.97 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471445.05 728435.06 32.16 471435.33 728437.76 32.16 471435.33 728437.76 37.95 471445.05 728435.06 37.95 471445.05 728435.06 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471435.33 728437.76 32.16 471433.15 728430.1 32.16 471433.15 728430.1 37.95 471435.33 728437.76 37.95 471435.33 728437.76 32.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6319-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471433.15 728430.1 37.95 471451.18 728424.94 37.95 471452 728427.55 37.95 471449.42 728428.43 37.95 471450.3 728431.68 37.95 471453.44 728430.82 37.95 471454.66 728434.91 37.95 471451.04 728436.14 37.95 471450.84 728436.59 37.95 471445.94 728437.97 37.95 471445.05 728435.06 37.95 471435.33 728437.76 37.95 471433.15 728430.1 37.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-631A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">16.59</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471479.32 728763.56 31.44 471484.79 728781.42 31.44 471496.92 728777.7 31.44 471496.12 728774.59 31.44 471499 728773.83 31.44 471499.92 728776.74 31.44 471507.35 728774.62 31.44 471505.8 728768.78 31.44 471508.7 728768.02 31.44 471505.62 728756.36 31.44 471479.32 728763.56 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471479.32 728763.56 31.44 471505.62 728756.36 31.44 471505.62 728756.36 48.03 471479.32 728763.56 48.03 471479.32 728763.56 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471505.62 728756.36 31.44 471508.7 728768.02 31.44 471508.7 728768.02 48.03 471505.62 728756.36 48.03 471505.62 728756.36 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471508.7 728768.02 31.44 471505.8 728768.78 31.44 471505.8 728768.78 48.03 471508.7 728768.02 48.03 471508.7 728768.02 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471505.8 728768.78 31.44 471507.35 728774.62 31.44 471507.35 728774.62 48.03 471505.8 728768.78 48.03 471505.8 728768.78 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471507.35 728774.62 31.44 471499.92 728776.74 31.44 471499.92 728776.74 48.03 471507.35 728774.62 48.03 471507.35 728774.62 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471499.92 728776.74 31.44 471499 728773.83 31.44 471499 728773.83 48.03 471499.92 728776.74 48.03 471499.92 728776.74 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471499 728773.83 31.44 471496.12 728774.59 31.44 471496.12 728774.59 48.03 471499 728773.83 48.03 471499 728773.83 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471496.12 728774.59 31.44 471496.92 728777.7 31.44 471496.92 728777.7 48.03 471496.12 728774.59 48.03 471496.12 728774.59 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471496.92 728777.7 31.44 471484.79 728781.42 31.44 471484.79 728781.42 48.03 471496.92 728777.7 48.03 471496.92 728777.7 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471484.79 728781.42 31.44 471479.32 728763.56 31.44 471479.32 728763.56 48.03 471484.79 728781.42 48.03 471484.79 728781.42 31.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631A-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471479.32 728763.56 48.03 471505.62 728756.36 48.03 471508.7 728768.02 48.03 471505.8 728768.78 48.03 471507.35 728774.62 48.03 471499.92 728776.74 48.03 471499 728773.83 48.03 471496.12 728774.59 48.03 471496.92 728777.7 48.03 471484.79 728781.42 48.03 471479.32 728763.56 48.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.58</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471324.69 728323.17 34.93 471326.73 728329.44 34.93 471330.05 728328.36 34.93 471330.96 728331.06 34.93 471338.15 728328.66 34.93 471337.38 728325.92 34.93 471339.14 728325.35 34.93 471337.07 728319.08 34.93 471333.31 728320.32 34.93 471333.17 728319.9 34.93 471328.24 728321.52 34.93 471328.38 728321.95 34.93 471324.69 728323.17 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471324.69 728323.17 34.93 471328.38 728321.95 34.93 471328.38 728321.95 43.51 471324.69 728323.17 43.51 471324.69 728323.17 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.38 728321.95 34.93 471328.24 728321.52 34.93 471328.24 728321.52 43.51 471328.38 728321.95 43.51 471328.38 728321.95 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.24 728321.52 34.93 471333.17 728319.9 34.93 471333.17 728319.9 43.51 471328.24 728321.52 43.51 471328.24 728321.52 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471333.17 728319.9 34.93 471333.31 728320.32 34.93 471333.31 728320.32 43.51 471333.17 728319.9 43.51 471333.17 728319.9 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471333.31 728320.32 34.93 471337.07 728319.08 34.93 471337.07 728319.08 43.51 471333.31 728320.32 43.51 471333.31 728320.32 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.07 728319.08 34.93 471339.14 728325.35 34.93 471339.14 728325.35 43.51 471337.07 728319.08 43.51 471337.07 728319.08 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.14 728325.35 34.93 471337.38 728325.92 34.93 471337.38 728325.92 43.51 471339.14 728325.35 43.51 471339.14 728325.35 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.38 728325.92 34.93 471338.15 728328.66 34.93 471338.15 728328.66 43.51 471337.38 728325.92 43.51 471337.38 728325.92 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.15 728328.66 34.93 471330.96 728331.06 34.93 471330.96 728331.06 43.51 471338.15 728328.66 43.51 471338.15 728328.66 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.96 728331.06 34.93 471330.05 728328.36 34.93 471330.05 728328.36 43.51 471330.96 728331.06 43.51 471330.96 728331.06 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.05 728328.36 34.93 471326.73 728329.44 34.93 471326.73 728329.44 43.51 471330.05 728328.36 43.51 471330.05 728328.36 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471326.73 728329.44 34.93 471324.69 728323.17 34.93 471324.69 728323.17 43.51 471326.73 728329.44 43.51 471326.73 728329.44 34.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D7-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471324.69 728323.17 43.51 471328.38 728321.95 43.51 471328.24 728321.52 43.51 471333.17 728319.9 43.51 471333.31 728320.32 43.51 471337.07 728319.08 43.51 471339.14 728325.35 43.51 471337.38 728325.92 43.51 471338.15 728328.66 43.51 471330.96 728331.06 43.51 471330.05 728328.36 43.51 471326.73 728329.44 43.51 471324.69 728323.17 43.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6318-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6318-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.64</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6318-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.26 728426.71 36.74 471348.61 728437.41 36.74 471356.95 728434.8 36.74 471353.58 728424.07 36.74 471345.26 728426.71 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6318-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.26 728426.71 36.74 471353.58 728424.07 36.74 471353.58 728424.07 45.38 471345.26 728426.71 45.38 471345.26 728426.71 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6318-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471353.58 728424.07 36.74 471356.95 728434.8 36.74 471356.95 728434.8 45.38 471353.58 728424.07 45.38 471353.58 728424.07 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6318-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471356.95 728434.8 36.74 471348.61 728437.41 36.74 471348.61 728437.41 45.38 471356.95 728434.8 45.38 471356.95 728434.8 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6318-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471348.61 728437.41 36.74 471345.26 728426.71 36.74 471345.26 728426.71 45.38 471348.61 728437.41 45.38 471348.61 728437.41 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6318-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.26 728426.71 45.38 471353.58 728424.07 45.38 471356.95 728434.8 45.38 471348.61 728437.41 45.38 471345.26 728426.71 45.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.19</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471566.89 728518.05 26.94 471569.67 728517.13 26.94 471603.03 728506.69 26.94 471599.91 728496.95 26.94 471596.02 728498.2 26.94 471595.26 728498.44 26.94 471595.32 728498.65 26.94 471594.79 728498.83 26.94 471564.29 728508.04 26.94 471563.67 728508.23 26.94 471564.05 728509.39 26.94 471566.89 728518.05 26.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471566.89 728518.05 26.94 471564.05 728509.39 26.94 471564.05 728509.39 32.13 471566.89 728518.05 32.13 471566.89 728518.05 26.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.05 728509.39 26.94 471563.67 728508.23 26.94 471563.67 728508.23 32.13 471564.05 728509.39 32.13 471564.05 728509.39 26.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471563.67 728508.23 26.94 471564.29 728508.04 26.94 471564.29 728508.04 32.13 471563.67 728508.23 32.13 471563.67 728508.23 26.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.29 728508.04 26.94 471594.79 728498.83 26.94 471594.79 728498.83 32.13 471564.29 728508.04 32.13 471564.29 728508.04 26.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471594.79 728498.83 26.94 471595.32 728498.65 26.94 471595.32 728498.65 32.13 471594.79 728498.83 32.13 471594.79 728498.83 26.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471595.32 728498.65 26.94 471595.26 728498.44 26.94 471595.26 728498.44 32.13 471595.32 728498.65 32.13 471595.32 728498.65 26.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471595.26 728498.44 26.94 471596.02 728498.2 26.94 471596.02 728498.2 32.13 471595.26 728498.44 32.13 471595.26 728498.44 26.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471596.02 728498.2 26.94 471599.91 728496.95 26.94 471599.91 728496.95 32.13 471596.02 728498.2 32.13 471596.02 728498.2 26.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471599.91 728496.95 26.94 471603.03 728506.69 26.94 471603.03 728506.69 32.13 471599.91 728496.95 32.13 471599.91 728496.95 26.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471603.03 728506.69 26.94 471569.67 728517.13 26.94 471569.67 728517.13 32.13 471603.03 728506.69 32.13 471603.03 728506.69 26.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471569.67 728517.13 26.94 471566.89 728518.05 26.94 471566.89 728518.05 32.13 471569.67 728517.13 32.13 471569.67 728517.13 26.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4EF4-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471566.89 728518.05 32.13 471564.05 728509.39 32.13 471563.67 728508.23 32.13 471564.29 728508.04 32.13 471594.79 728498.83 32.13 471595.32 728498.65 32.13 471595.26 728498.44 32.13 471596.02 728498.2 32.13 471599.91 728496.95 32.13 471603.03 728506.69 32.13 471569.67 728517.13 32.13 471566.89 728518.05 32.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-648C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-648C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471242.85 728225.11 38.66 471245.77 728234.58 38.66 471253.96 728232.06 38.66 471253.09 728229.4 38.66 471256.25 728228.43 38.66 471254.35 728222.09 38.66 471248 728223.96 38.66 471247.9 728223.64 38.66 471242.85 728225.11 38.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471242.85 728225.11 38.66 471247.9 728223.64 38.66 471247.9 728223.64 47.13 471242.85 728225.11 47.13 471242.85 728225.11 38.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471247.9 728223.64 38.66 471248 728223.96 38.66 471248 728223.96 47.13 471247.9 728223.64 47.13 471247.9 728223.64 38.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471248 728223.96 38.66 471254.35 728222.09 38.66 471254.35 728222.09 47.13 471248 728223.96 47.13 471248 728223.96 38.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471254.35 728222.09 38.66 471256.25 728228.43 38.66 471256.25 728228.43 47.13 471254.35 728222.09 47.13 471254.35 728222.09 38.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471256.25 728228.43 38.66 471253.09 728229.4 38.66 471253.09 728229.4 47.13 471256.25 728228.43 47.13 471256.25 728228.43 38.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471253.09 728229.4 38.66 471253.96 728232.06 38.66 471253.96 728232.06 47.13 471253.09 728229.4 47.13 471253.09 728229.4 38.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471253.96 728232.06 38.66 471245.77 728234.58 38.66 471245.77 728234.58 47.13 471253.96 728232.06 47.13 471253.96 728232.06 38.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471245.77 728234.58 38.66 471242.85 728225.11 38.66 471242.85 728225.11 47.13 471245.77 728234.58 47.13 471245.77 728234.58 38.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471242.85 728225.11 47.13 471247.9 728223.64 47.13 471248 728223.96 47.13 471254.35 728222.09 47.13 471256.25 728228.43 47.13 471253.09 728229.4 47.13 471253.96 728232.06 47.13 471245.77 728234.58 47.13 471242.85 728225.11 47.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-648F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-648F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.25</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.7 728192.68 36.03 471291.74 728196.27 36.03 471296.41 728194.9 36.03 471296.88 728196.52 36.03 471300.14 728195.56 36.03 471299.73 728194.15 36.03 471306.59 728192.09 36.03 471305.5 728188.44 36.03 471290.7 728192.68 36.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.7 728192.68 36.03 471305.5 728188.44 36.03 471305.5 728188.44 39.28 471290.7 728192.68 39.28 471290.7 728192.68 36.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.5 728188.44 36.03 471306.59 728192.09 36.03 471306.59 728192.09 39.28 471305.5 728188.44 39.28 471305.5 728188.44 36.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471306.59 728192.09 36.03 471299.73 728194.15 36.03 471299.73 728194.15 39.28 471306.59 728192.09 39.28 471306.59 728192.09 36.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471299.73 728194.15 36.03 471300.14 728195.56 36.03 471300.14 728195.56 39.28 471299.73 728194.15 39.28 471299.73 728194.15 36.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471300.14 728195.56 36.03 471296.88 728196.52 36.03 471296.88 728196.52 39.28 471300.14 728195.56 39.28 471300.14 728195.56 36.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471296.88 728196.52 36.03 471296.41 728194.9 36.03 471296.41 728194.9 39.28 471296.88 728196.52 39.28 471296.88 728196.52 36.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471296.41 728194.9 36.03 471291.74 728196.27 36.03 471291.74 728196.27 39.28 471296.41 728194.9 39.28 471296.41 728194.9 36.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471291.74 728196.27 36.03 471290.7 728192.68 36.03 471290.7 728192.68 39.28 471291.74 728196.27 39.28 471291.74 728196.27 36.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.7 728192.68 39.28 471305.5 728188.44 39.28 471306.59 728192.09 39.28 471299.73 728194.15 39.28 471300.14 728195.56 39.28 471296.88 728196.52 39.28 471296.41 728194.9 39.28 471291.74 728196.27 39.28 471290.7 728192.68 39.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6492-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471316.66 728185.11 35.08 471319.02 728193.21 35.08 471320.7 728192.64 35.08 471320.56 728192.19 35.08 471321.67 728191.83 35.08 471323.64 728191.17 35.08 471322.28 728186.73 35.08 471322.22 728186.5 35.08 471322.08 728186.54 35.08 471321.26 728183.81 35.08 471316.66 728185.11 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471316.66 728185.11 35.08 471321.26 728183.81 35.08 471321.26 728183.81 37.71 471316.66 728185.11 37.71 471316.66 728185.11 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471321.26 728183.81 35.08 471322.08 728186.54 35.08 471322.08 728186.54 37.71 471321.26 728183.81 37.71 471321.26 728183.81 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471322.08 728186.54 35.08 471322.22 728186.5 35.08 471322.22 728186.5 37.71 471322.08 728186.54 37.71 471322.08 728186.54 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471322.22 728186.5 35.08 471322.28 728186.73 35.08 471322.28 728186.73 37.71 471322.22 728186.5 37.71 471322.22 728186.5 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471322.28 728186.73 35.08 471323.64 728191.17 35.08 471323.64 728191.17 37.71 471322.28 728186.73 37.71 471322.28 728186.73 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471323.64 728191.17 35.08 471321.67 728191.83 35.08 471321.67 728191.83 37.71 471323.64 728191.17 37.71 471323.64 728191.17 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471321.67 728191.83 35.08 471320.56 728192.19 35.08 471320.56 728192.19 37.71 471321.67 728191.83 37.71 471321.67 728191.83 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471320.56 728192.19 35.08 471320.7 728192.64 35.08 471320.7 728192.64 37.71 471320.56 728192.19 37.71 471320.56 728192.19 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471320.7 728192.64 35.08 471319.02 728193.21 35.08 471319.02 728193.21 37.71 471320.7 728192.64 37.71 471320.7 728192.64 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471319.02 728193.21 35.08 471316.66 728185.11 35.08 471316.66 728185.11 37.71 471319.02 728193.21 37.71 471319.02 728193.21 35.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6492-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471316.66 728185.11 37.71 471321.26 728183.81 37.71 471322.08 728186.54 37.71 471322.22 728186.5 37.71 471322.28 728186.73 37.71 471323.64 728191.17 37.71 471321.67 728191.83 37.71 471320.56 728192.19 37.71 471320.7 728192.64 37.71 471319.02 728193.21 37.71 471316.66 728185.11 37.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-648E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.2</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471254.11 728183.85 37.14 471255.27 728187.7 37.14 471255.04 728187.77 37.14 471257.81 728196.94 37.14 471260.15 728196.24 37.14 471261.28 728199.96 37.14 471267.79 728197.99 37.14 471266.57 728194.04 37.14 471265.01 728194.65 37.14 471264.22 728192.14 37.14 471265.86 728191.62 37.14 471263.9 728185.15 37.14 471265.36 728184.69 37.14 471264.15 728180.74 37.14 471254.11 728183.85 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471254.11 728183.85 37.14 471264.15 728180.74 37.14 471264.15 728180.74 45.34 471254.11 728183.85 45.34 471254.11 728183.85 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471264.15 728180.74 37.14 471265.36 728184.69 37.14 471265.36 728184.69 45.34 471264.15 728180.74 45.34 471264.15 728180.74 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471265.36 728184.69 37.14 471263.9 728185.15 37.14 471263.9 728185.15 45.34 471265.36 728184.69 45.34 471265.36 728184.69 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471263.9 728185.15 37.14 471265.86 728191.62 37.14 471265.86 728191.62 45.34 471263.9 728185.15 45.34 471263.9 728185.15 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471265.86 728191.62 37.14 471264.22 728192.14 37.14 471264.22 728192.14 45.34 471265.86 728191.62 45.34 471265.86 728191.62 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471264.22 728192.14 37.14 471265.01 728194.65 37.14 471265.01 728194.65 45.34 471264.22 728192.14 45.34 471264.22 728192.14 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471265.01 728194.65 37.14 471266.57 728194.04 37.14 471266.57 728194.04 45.34 471265.01 728194.65 45.34 471265.01 728194.65 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471266.57 728194.04 37.14 471267.79 728197.99 37.14 471267.79 728197.99 45.34 471266.57 728194.04 45.34 471266.57 728194.04 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471267.79 728197.99 37.14 471261.28 728199.96 37.14 471261.28 728199.96 45.34 471267.79 728197.99 45.34 471267.79 728197.99 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471261.28 728199.96 37.14 471260.15 728196.24 37.14 471260.15 728196.24 45.34 471261.28 728199.96 45.34 471261.28 728199.96 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471260.15 728196.24 37.14 471257.81 728196.94 37.14 471257.81 728196.94 45.34 471260.15 728196.24 45.34 471260.15 728196.24 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471257.81 728196.94 37.14 471255.04 728187.77 37.14 471255.04 728187.77 45.34 471257.81 728196.94 45.34 471257.81 728196.94 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471255.04 728187.77 37.14 471255.27 728187.7 37.14 471255.27 728187.7 45.34 471255.04 728187.77 45.34 471255.04 728187.77 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471255.27 728187.7 37.14 471254.11 728183.85 37.14 471254.11 728183.85 45.34 471255.27 728187.7 45.34 471255.27 728187.7 37.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648E-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471254.11 728183.85 45.34 471264.15 728180.74 45.34 471265.36 728184.69 45.34 471263.9 728185.15 45.34 471265.86 728191.62 45.34 471264.22 728192.14 45.34 471265.01 728194.65 45.34 471266.57 728194.04 45.34 471267.79 728197.99 45.34 471261.28 728199.96 45.34 471260.15 728196.24 45.34 471257.81 728196.94 45.34 471255.04 728187.77 45.34 471255.27 728187.7 45.34 471254.11 728183.85 45.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-648D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.68</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471200.32 728200.13 42.55 471201.6 728204.22 42.55 471201.26 728204.33 42.55 471203.92 728213.47 42.55 471211.48 728211.19 42.55 471213.14 728210.69 42.55 471212.3 728207.96 42.55 471210.3 728201.37 42.55 471209.64 728201.6 42.55 471208.56 728198.01 42.55 471208.48 728197.74 42.55 471207.23 728198.11 42.55 471200.32 728200.13 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471200.32 728200.13 42.55 471207.23 728198.11 42.55 471207.23 728198.11 51.230000000000004 471200.32 728200.13 51.230000000000004 471200.32 728200.13 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471207.23 728198.11 42.55 471208.48 728197.74 42.55 471208.48 728197.74 51.230000000000004 471207.23 728198.11 51.230000000000004 471207.23 728198.11 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471208.48 728197.74 42.55 471208.56 728198.01 42.55 471208.56 728198.01 51.230000000000004 471208.48 728197.74 51.230000000000004 471208.48 728197.74 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471208.56 728198.01 42.55 471209.64 728201.6 42.55 471209.64 728201.6 51.230000000000004 471208.56 728198.01 51.230000000000004 471208.56 728198.01 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471209.64 728201.6 42.55 471210.3 728201.37 42.55 471210.3 728201.37 51.230000000000004 471209.64 728201.6 51.230000000000004 471209.64 728201.6 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471210.3 728201.37 42.55 471212.3 728207.96 42.55 471212.3 728207.96 51.230000000000004 471210.3 728201.37 51.230000000000004 471210.3 728201.37 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471212.3 728207.96 42.55 471213.14 728210.69 42.55 471213.14 728210.69 51.230000000000004 471212.3 728207.96 51.230000000000004 471212.3 728207.96 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471213.14 728210.69 42.55 471211.48 728211.19 42.55 471211.48 728211.19 51.230000000000004 471213.14 728210.69 51.230000000000004 471213.14 728210.69 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471211.48 728211.19 42.55 471203.92 728213.47 42.55 471203.92 728213.47 51.230000000000004 471211.48 728211.19 51.230000000000004 471211.48 728211.19 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471203.92 728213.47 42.55 471201.26 728204.33 42.55 471201.26 728204.33 51.230000000000004 471203.92 728213.47 51.230000000000004 471203.92 728213.47 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471201.26 728204.33 42.55 471201.6 728204.22 42.55 471201.6 728204.22 51.230000000000004 471201.26 728204.33 51.230000000000004 471201.26 728204.33 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471201.6 728204.22 42.55 471200.32 728200.13 42.55 471200.32 728200.13 51.230000000000004 471201.6 728204.22 51.230000000000004 471201.6 728204.22 42.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-648D-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471200.32 728200.13 51.230000000000004 471207.23 728198.11 51.230000000000004 471208.48 728197.74 51.230000000000004 471208.56 728198.01 51.230000000000004 471209.64 728201.6 51.230000000000004 471210.3 728201.37 51.230000000000004 471212.3 728207.96 51.230000000000004 471213.14 728210.69 51.230000000000004 471211.48 728211.19 51.230000000000004 471203.92 728213.47 51.230000000000004 471201.26 728204.33 51.230000000000004 471201.6 728204.22 51.230000000000004 471200.32 728200.13 51.230000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471281.02 728362.14 37.91 471283.69 728369.88 37.91 471286.58 728368.89 37.91 471287.22 728370.78 37.91 471294.8 728368.41 37.91 471293.88 728365.56 37.91 471295.6 728365.01 37.91 471293.47 728358.46 37.91 471289.94 728359.58 37.91 471289.78 728359.25 37.91 471281.02 728362.14 37.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471281.02 728362.14 37.91 471289.78 728359.25 37.91 471289.78 728359.25 46.72 471281.02 728362.14 46.72 471281.02 728362.14 37.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471289.78 728359.25 37.91 471289.94 728359.58 37.91 471289.94 728359.58 46.72 471289.78 728359.25 46.72 471289.78 728359.25 37.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471289.94 728359.58 37.91 471293.47 728358.46 37.91 471293.47 728358.46 46.72 471289.94 728359.58 46.72 471289.94 728359.58 37.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471293.47 728358.46 37.91 471295.6 728365.01 37.91 471295.6 728365.01 46.72 471293.47 728358.46 46.72 471293.47 728358.46 37.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471295.6 728365.01 37.91 471293.88 728365.56 37.91 471293.88 728365.56 46.72 471295.6 728365.01 46.72 471295.6 728365.01 37.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471293.88 728365.56 37.91 471294.8 728368.41 37.91 471294.8 728368.41 46.72 471293.88 728365.56 46.72 471293.88 728365.56 37.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471294.8 728368.41 37.91 471287.22 728370.78 37.91 471287.22 728370.78 46.72 471294.8 728368.41 46.72 471294.8 728368.41 37.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471287.22 728370.78 37.91 471286.58 728368.89 37.91 471286.58 728368.89 46.72 471287.22 728370.78 46.72 471287.22 728370.78 37.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471286.58 728368.89 37.91 471283.69 728369.88 37.91 471283.69 728369.88 46.72 471286.58 728368.89 46.72 471286.58 728368.89 37.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471283.69 728369.88 37.91 471281.02 728362.14 37.91 471281.02 728362.14 46.72 471283.69 728369.88 46.72 471283.69 728369.88 37.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D5-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471281.02 728362.14 46.72 471289.78 728359.25 46.72 471289.94 728359.58 46.72 471293.47 728358.46 46.72 471295.6 728365.01 46.72 471293.88 728365.56 46.72 471294.8 728368.41 46.72 471287.22 728370.78 46.72 471286.58 728368.89 46.72 471283.69 728369.88 46.72 471281.02 728362.14 46.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-63D6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-63D6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471326.01 728361.66 36.25 471328.51 728369.16 36.25 471338.46 728366.02 36.25 471337.74 728363.63 36.25 471332.07 728365.36 36.25 471330.37 728360.29 36.25 471326.01 728361.66 36.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471326.01 728361.66 36.25 471330.37 728360.29 36.25 471330.37 728360.29 39.25 471326.01 728361.66 39.25 471326.01 728361.66 36.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.37 728360.29 36.25 471332.07 728365.36 36.25 471332.07 728365.36 39.25 471330.37 728360.29 39.25 471330.37 728360.29 36.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471332.07 728365.36 36.25 471337.74 728363.63 36.25 471337.74 728363.63 39.25 471332.07 728365.36 39.25 471332.07 728365.36 36.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.74 728363.63 36.25 471338.46 728366.02 36.25 471338.46 728366.02 39.25 471337.74 728363.63 39.25 471337.74 728363.63 36.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.46 728366.02 36.25 471328.51 728369.16 36.25 471328.51 728369.16 39.25 471338.46 728366.02 39.25 471338.46 728366.02 36.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D6-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.51 728369.16 36.25 471326.01 728361.66 36.25 471326.01 728361.66 39.25 471328.51 728369.16 39.25 471328.51 728369.16 36.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D6-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471326.01 728361.66 39.25 471330.37 728360.29 39.25 471332.07 728365.36 39.25 471337.74 728363.63 39.25 471338.46 728366.02 39.25 471328.51 728369.16 39.25 471326.01 728361.66 39.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6490-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.82</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471221.68 728172.85 39.5 471223.71 728179.5 39.5 471227.55 728178.34 39.5 471227.69 728178.81 39.5 471239.28 728175.26 39.5 471238.27 728172.16 39.5 471235.9 728172.88 39.5 471234.07 728166.76 39.5 471230.53 728167.83 39.5 471230.43 728167.49 39.5 471225.05 728169.1 39.5 471225.12 728169.29 39.5 471224.78 728169.4 39.5 471225.46 728171.67 39.5 471221.68 728172.85 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471221.68 728172.85 39.5 471225.46 728171.67 39.5 471225.46 728171.67 48.32 471221.68 728172.85 48.32 471221.68 728172.85 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471225.46 728171.67 39.5 471224.78 728169.4 39.5 471224.78 728169.4 48.32 471225.46 728171.67 48.32 471225.46 728171.67 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471224.78 728169.4 39.5 471225.12 728169.29 39.5 471225.12 728169.29 48.32 471224.78 728169.4 48.32 471224.78 728169.4 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471225.12 728169.29 39.5 471225.05 728169.1 39.5 471225.05 728169.1 48.32 471225.12 728169.29 48.32 471225.12 728169.29 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471225.05 728169.1 39.5 471230.43 728167.49 39.5 471230.43 728167.49 48.32 471225.05 728169.1 48.32 471225.05 728169.1 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471230.43 728167.49 39.5 471230.53 728167.83 39.5 471230.53 728167.83 48.32 471230.43 728167.49 48.32 471230.43 728167.49 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471230.53 728167.83 39.5 471234.07 728166.76 39.5 471234.07 728166.76 48.32 471230.53 728167.83 48.32 471230.53 728167.83 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471234.07 728166.76 39.5 471235.9 728172.88 39.5 471235.9 728172.88 48.32 471234.07 728166.76 48.32 471234.07 728166.76 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471235.9 728172.88 39.5 471238.27 728172.16 39.5 471238.27 728172.16 48.32 471235.9 728172.88 48.32 471235.9 728172.88 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471238.27 728172.16 39.5 471239.28 728175.26 39.5 471239.28 728175.26 48.32 471238.27 728172.16 48.32 471238.27 728172.16 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471239.28 728175.26 39.5 471227.69 728178.81 39.5 471227.69 728178.81 48.32 471239.28 728175.26 48.32 471239.28 728175.26 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471227.69 728178.81 39.5 471227.55 728178.34 39.5 471227.55 728178.34 48.32 471227.69 728178.81 48.32 471227.69 728178.81 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471227.55 728178.34 39.5 471223.71 728179.5 39.5 471223.71 728179.5 48.32 471227.55 728178.34 48.32 471227.55 728178.34 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471223.71 728179.5 39.5 471221.68 728172.85 39.5 471221.68 728172.85 48.32 471223.71 728179.5 48.32 471223.71 728179.5 39.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6490-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471221.68 728172.85 48.32 471225.46 728171.67 48.32 471224.78 728169.4 48.32 471225.12 728169.29 48.32 471225.05 728169.1 48.32 471230.43 728167.49 48.32 471230.53 728167.83 48.32 471234.07 728166.76 48.32 471235.9 728172.88 48.32 471238.27 728172.16 48.32 471239.28 728175.26 48.32 471227.69 728178.81 48.32 471227.55 728178.34 48.32 471223.71 728179.5 48.32 471221.68 728172.85 48.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-63D4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-63D4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.49</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471262.11 728369.29 40.71 471265.91 728382.3 40.71 471273.32 728380.01 40.71 471272.49 728377.33 40.71 471274.2 728376.85 40.71 471271.02 728366.54 40.71 471262.11 728369.29 40.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471262.11 728369.29 40.71 471271.02 728366.54 40.71 471271.02 728366.54 49.2 471262.11 728369.29 49.2 471262.11 728369.29 40.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471271.02 728366.54 40.71 471274.2 728376.85 40.71 471274.2 728376.85 49.2 471271.02 728366.54 49.2 471271.02 728366.54 40.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471274.2 728376.85 40.71 471272.49 728377.33 40.71 471272.49 728377.33 49.2 471274.2 728376.85 49.2 471274.2 728376.85 40.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471272.49 728377.33 40.71 471273.32 728380.01 40.71 471273.32 728380.01 49.2 471272.49 728377.33 49.2 471272.49 728377.33 40.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471273.32 728380.01 40.71 471265.91 728382.3 40.71 471265.91 728382.3 49.2 471273.32 728380.01 49.2 471273.32 728380.01 40.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471265.91 728382.3 40.71 471262.11 728369.29 40.71 471262.11 728369.29 49.2 471265.91 728382.3 49.2 471265.91 728382.3 40.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471262.11 728369.29 49.2 471271.02 728366.54 49.2 471274.2 728376.85 49.2 471272.49 728377.33 49.2 471273.32 728380.01 49.2 471265.91 728382.3 49.2 471262.11 728369.29 49.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87">
			<gen:stringAttribute name="buildingId">
				<gen:value>41976bc0-6003-441e-a463-1c225f2ddf87</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">14.35</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.97 728327.94 24.79 471468.81 728369.11 24.79 471492.23 728361.81 24.79 471492.1 728361.55 24.79 471510.77 728355.69 24.79 471511.32 728357.89 24.79 471511.78 728357.76 24.79 471514.38 728356.96 24.79 471516.75 728356.23 24.79 471513.95 728347.93 24.79 471544.9 728338.27 24.79 471547.36 728346.05 24.79 471551.45 728344.81 24.79 471557.23 728362.96 24.79 471569.49 728401.49 24.79 471573.48 728414 24.79 471585.75 728452.44 24.79 471594.36 728479.34 24.79 471597.21 728478.39 24.79 471597.78 728480.12 24.79 471607.04 728477.16 24.79 471606.25 728474.74 24.79 471606.33 728472.8 24.79 471606.21 728469.86 24.79 471602.13 728457.08 24.79 471600.51 728454.61 24.79 471564.64 728341.85 24.79 471562.89 728342.42 24.79 471560.53 728335.2 24.79 471559.93 728335.39 24.79 471560.04 728335.72 24.79 471558.06 728336.38 24.79 471550.85 728313.87 24.79 471507.33 728327.51 24.79 471503.07 728313.69 24.79 471479.55 728321 24.79 471479.43 728320.67 24.79 471455.97 728327.94 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.97 728327.94 24.79 471479.43 728320.67 24.79 471479.43 728320.67 39.14 471455.97 728327.94 39.14 471455.97 728327.94 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471479.43 728320.67 24.79 471479.55 728321 24.79 471479.55 728321 39.14 471479.43 728320.67 39.14 471479.43 728320.67 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471479.55 728321 24.79 471503.07 728313.69 24.79 471503.07 728313.69 39.14 471479.55 728321 39.14 471479.55 728321 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471503.07 728313.69 24.79 471507.33 728327.51 24.79 471507.33 728327.51 39.14 471503.07 728313.69 39.14 471503.07 728313.69 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471507.33 728327.51 24.79 471550.85 728313.87 24.79 471550.85 728313.87 39.14 471507.33 728327.51 39.14 471507.33 728327.51 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471550.85 728313.87 24.79 471558.06 728336.38 24.79 471558.06 728336.38 39.14 471550.85 728313.87 39.14 471550.85 728313.87 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471558.06 728336.38 24.79 471560.04 728335.72 24.79 471560.04 728335.72 39.14 471558.06 728336.38 39.14 471558.06 728336.38 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471560.04 728335.72 24.79 471559.93 728335.39 24.79 471559.93 728335.39 39.14 471560.04 728335.72 39.14 471560.04 728335.72 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.93 728335.39 24.79 471560.53 728335.2 24.79 471560.53 728335.2 39.14 471559.93 728335.39 39.14 471559.93 728335.39 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471560.53 728335.2 24.79 471562.89 728342.42 24.79 471562.89 728342.42 39.14 471560.53 728335.2 39.14 471560.53 728335.2 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471562.89 728342.42 24.79 471564.64 728341.85 24.79 471564.64 728341.85 39.14 471562.89 728342.42 39.14 471562.89 728342.42 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.64 728341.85 24.79 471600.51 728454.61 24.79 471600.51 728454.61 39.14 471564.64 728341.85 39.14 471564.64 728341.85 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471600.51 728454.61 24.79 471602.13 728457.08 24.79 471602.13 728457.08 39.14 471600.51 728454.61 39.14 471600.51 728454.61 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471602.13 728457.08 24.79 471606.21 728469.86 24.79 471606.21 728469.86 39.14 471602.13 728457.08 39.14 471602.13 728457.08 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471606.21 728469.86 24.79 471606.33 728472.8 24.79 471606.33 728472.8 39.14 471606.21 728469.86 39.14 471606.21 728469.86 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471606.33 728472.8 24.79 471606.25 728474.74 24.79 471606.25 728474.74 39.14 471606.33 728472.8 39.14 471606.33 728472.8 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471606.25 728474.74 24.79 471607.04 728477.16 24.79 471607.04 728477.16 39.14 471606.25 728474.74 39.14 471606.25 728474.74 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471607.04 728477.16 24.79 471597.78 728480.12 24.79 471597.78 728480.12 39.14 471607.04 728477.16 39.14 471607.04 728477.16 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471597.78 728480.12 24.79 471597.21 728478.39 24.79 471597.21 728478.39 39.14 471597.78 728480.12 39.14 471597.78 728480.12 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471597.21 728478.39 24.79 471594.36 728479.34 24.79 471594.36 728479.34 39.14 471597.21 728478.39 39.14 471597.21 728478.39 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471594.36 728479.34 24.79 471585.75 728452.44 24.79 471585.75 728452.44 39.14 471594.36 728479.34 39.14 471594.36 728479.34 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471585.75 728452.44 24.79 471573.48 728414 24.79 471573.48 728414 39.14 471585.75 728452.44 39.14 471585.75 728452.44 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471573.48 728414 24.79 471569.49 728401.49 24.79 471569.49 728401.49 39.14 471573.48 728414 39.14 471573.48 728414 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471569.49 728401.49 24.79 471557.23 728362.96 24.79 471557.23 728362.96 39.14 471569.49 728401.49 39.14 471569.49 728401.49 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471557.23 728362.96 24.79 471551.45 728344.81 24.79 471551.45 728344.81 39.14 471557.23 728362.96 39.14 471557.23 728362.96 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471551.45 728344.81 24.79 471547.36 728346.05 24.79 471547.36 728346.05 39.14 471551.45 728344.81 39.14 471551.45 728344.81 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471547.36 728346.05 24.79 471544.9 728338.27 24.79 471544.9 728338.27 39.14 471547.36 728346.05 39.14 471547.36 728346.05 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471544.9 728338.27 24.79 471513.95 728347.93 24.79 471513.95 728347.93 39.14 471544.9 728338.27 39.14 471544.9 728338.27 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471513.95 728347.93 24.79 471516.75 728356.23 24.79 471516.75 728356.23 39.14 471513.95 728347.93 39.14 471513.95 728347.93 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471516.75 728356.23 24.79 471514.38 728356.96 24.79 471514.38 728356.96 39.14 471516.75 728356.23 39.14 471516.75 728356.23 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471514.38 728356.96 24.79 471511.78 728357.76 24.79 471511.78 728357.76 39.14 471514.38 728356.96 39.14 471514.38 728356.96 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471511.78 728357.76 24.79 471511.32 728357.89 24.79 471511.32 728357.89 39.14 471511.78 728357.76 39.14 471511.78 728357.76 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471511.32 728357.89 24.79 471510.77 728355.69 24.79 471510.77 728355.69 39.14 471511.32 728357.89 39.14 471511.32 728357.89 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471510.77 728355.69 24.79 471492.1 728361.55 24.79 471492.1 728361.55 39.14 471510.77 728355.69 39.14 471510.77 728355.69 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471492.1 728361.55 24.79 471492.23 728361.81 24.79 471492.23 728361.81 39.14 471492.1 728361.55 39.14 471492.1 728361.55 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471492.23 728361.81 24.79 471468.81 728369.11 24.79 471468.81 728369.11 39.14 471492.23 728361.81 39.14 471492.23 728361.81 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471468.81 728369.11 24.79 471455.97 728327.94 24.79 471455.97 728327.94 39.14 471468.81 728369.11 39.14 471468.81 728369.11 24.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-41976bc0-6003-441e-a463-1c225f2ddf87_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471455.97 728327.94 39.14 471479.43 728320.67 39.14 471479.55 728321 39.14 471503.07 728313.69 39.14 471507.33 728327.51 39.14 471550.85 728313.87 39.14 471558.06 728336.38 39.14 471560.04 728335.72 39.14 471559.93 728335.39 39.14 471560.53 728335.2 39.14 471562.89 728342.42 39.14 471564.64 728341.85 39.14 471600.51 728454.61 39.14 471602.13 728457.08 39.14 471606.21 728469.86 39.14 471606.33 728472.8 39.14 471606.25 728474.74 39.14 471607.04 728477.16 39.14 471597.78 728480.12 39.14 471597.21 728478.39 39.14 471594.36 728479.34 39.14 471585.75 728452.44 39.14 471573.48 728414 39.14 471569.49 728401.49 39.14 471557.23 728362.96 39.14 471551.45 728344.81 39.14 471547.36 728346.05 39.14 471544.9 728338.27 39.14 471513.95 728347.93 39.14 471516.75 728356.23 39.14 471514.38 728356.96 39.14 471511.78 728357.76 39.14 471511.32 728357.89 39.14 471510.77 728355.69 39.14 471492.1 728361.55 39.14 471492.23 728361.81 39.14 471468.81 728369.11 39.14 471455.97 728327.94 39.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-97ffce62-c2b6-4631-818f-34266b874042">
			<gen:stringAttribute name="buildingId">
				<gen:value>97ffce62-c2b6-4631-818f-34266b874042</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.52</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-97ffce62-c2b6-4631-818f-34266b874042_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471198.67 728223.25 41.39 471194.82 728224.66 41.39 471198.24 728233.96 41.39 471202.1 728232.54 41.39 471198.67 728223.25 41.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-97ffce62-c2b6-4631-818f-34266b874042_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471198.67 728223.25 41.39 471202.1 728232.54 41.39 471202.1 728232.54 43.910000000000004 471198.67 728223.25 43.910000000000004 471198.67 728223.25 41.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-97ffce62-c2b6-4631-818f-34266b874042_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471202.1 728232.54 41.39 471198.24 728233.96 41.39 471198.24 728233.96 43.910000000000004 471202.1 728232.54 43.910000000000004 471202.1 728232.54 41.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-97ffce62-c2b6-4631-818f-34266b874042_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471198.24 728233.96 41.39 471194.82 728224.66 41.39 471194.82 728224.66 43.910000000000004 471198.24 728233.96 43.910000000000004 471198.24 728233.96 41.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-97ffce62-c2b6-4631-818f-34266b874042_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471194.82 728224.66 41.39 471198.67 728223.25 41.39 471198.67 728223.25 43.910000000000004 471194.82 728224.66 43.910000000000004 471194.82 728224.66 41.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-97ffce62-c2b6-4631-818f-34266b874042_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471198.67 728223.25 43.910000000000004 471202.1 728232.54 43.910000000000004 471198.24 728233.96 43.910000000000004 471194.82 728224.66 43.910000000000004 471198.67 728223.25 43.910000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-066fb4e6-0868-47e3-998f-ef09d3c28d28">
			<gen:stringAttribute name="buildingId">
				<gen:value>066fb4e6-0868-47e3-998f-ef09d3c28d28</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.74</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-066fb4e6-0868-47e3-998f-ef09d3c28d28_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471388.18 728338.31 33.04 471384.27 728339.57 33.04 471383.36 728339.86 33.04 471383.51 728340.34 33.04 471384.43 728340.05 33.04 471386.09 728344.96 33.04 471384.95 728345.35 33.04 471386.63 728350.37 33.04 471391.71 728348.85 33.04 471388.18 728338.31 33.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-066fb4e6-0868-47e3-998f-ef09d3c28d28_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471388.18 728338.31 33.04 471391.71 728348.85 33.04 471391.71 728348.85 35.78 471388.18 728338.31 35.78 471388.18 728338.31 33.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-066fb4e6-0868-47e3-998f-ef09d3c28d28_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471391.71 728348.85 33.04 471386.63 728350.37 33.04 471386.63 728350.37 35.78 471391.71 728348.85 35.78 471391.71 728348.85 33.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-066fb4e6-0868-47e3-998f-ef09d3c28d28_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471386.63 728350.37 33.04 471384.95 728345.35 33.04 471384.95 728345.35 35.78 471386.63 728350.37 35.78 471386.63 728350.37 33.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-066fb4e6-0868-47e3-998f-ef09d3c28d28_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.95 728345.35 33.04 471386.09 728344.96 33.04 471386.09 728344.96 35.78 471384.95 728345.35 35.78 471384.95 728345.35 33.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-066fb4e6-0868-47e3-998f-ef09d3c28d28_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471386.09 728344.96 33.04 471384.43 728340.05 33.04 471384.43 728340.05 35.78 471386.09 728344.96 35.78 471386.09 728344.96 33.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-066fb4e6-0868-47e3-998f-ef09d3c28d28_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.43 728340.05 33.04 471383.51 728340.34 33.04 471383.51 728340.34 35.78 471384.43 728340.05 35.78 471384.43 728340.05 33.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-066fb4e6-0868-47e3-998f-ef09d3c28d28_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.51 728340.34 33.04 471383.36 728339.86 33.04 471383.36 728339.86 35.78 471383.51 728340.34 35.78 471383.51 728340.34 33.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-066fb4e6-0868-47e3-998f-ef09d3c28d28_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.36 728339.86 33.04 471384.27 728339.57 33.04 471384.27 728339.57 35.78 471383.36 728339.86 35.78 471383.36 728339.86 33.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-066fb4e6-0868-47e3-998f-ef09d3c28d28_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.27 728339.57 33.04 471388.18 728338.31 33.04 471388.18 728338.31 35.78 471384.27 728339.57 35.78 471384.27 728339.57 33.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-066fb4e6-0868-47e3-998f-ef09d3c28d28_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471388.18 728338.31 35.78 471391.71 728348.85 35.78 471386.63 728350.37 35.78 471384.95 728345.35 35.78 471386.09 728344.96 35.78 471384.43 728340.05 35.78 471383.51 728340.34 35.78 471383.36 728339.86 35.78 471384.27 728339.57 35.78 471388.18 728338.31 35.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.57</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471420.54 728492.75 33.71 471423.12 728505.21 33.71 471421.76 728505.48 33.71 471421.36 728506.1 33.71 471421.95 728508.95 33.71 471422.47 728509.37 33.71 471423.91 728509.08 33.71 471425.11 728515.06 33.71 471424.15 728515.26 33.71 471423.54 728516.54 33.71 471423.96 728518.74 33.71 471424.48 728521.42 33.71 471424.84 728523.26 33.71 471432.89 728521.38 33.71 471432.81 728520.98 33.71 471434.94 728520.54 33.71 471434.3 728517.71 33.71 471434.56 728517.66 33.71 471433.79 728513.95 33.71 471434.47 728513.35 33.71 471434.18 728511.81 33.71 471433.29 728511.56 33.71 471432.49 728507.86 33.71 471433.68 728507.63 33.71 471432.52 728502.08 33.71 471434.86 728501.53 33.71 471435.19 728501.09 33.71 471434.12 728496.04 33.71 471433.72 728495.78 33.71 471431.33 728496.33 33.71 471430.13 728490.76 33.71 471429.65 728490.86 33.71 471428.82 728486.91 33.71 471426.76 728485.83 33.71 471424.52 728486.28 33.71 471423.07 728488.09 33.71 471423.89 728492.05 33.71 471420.54 728492.75 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471420.54 728492.75 33.71 471423.89 728492.05 33.71 471423.89 728492.05 43.28 471420.54 728492.75 43.28 471420.54 728492.75 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.89 728492.05 33.71 471423.07 728488.09 33.71 471423.07 728488.09 43.28 471423.89 728492.05 43.28 471423.89 728492.05 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.07 728488.09 33.71 471424.52 728486.28 33.71 471424.52 728486.28 43.28 471423.07 728488.09 43.28 471423.07 728488.09 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.52 728486.28 33.71 471426.76 728485.83 33.71 471426.76 728485.83 43.28 471424.52 728486.28 43.28 471424.52 728486.28 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471426.76 728485.83 33.71 471428.82 728486.91 33.71 471428.82 728486.91 43.28 471426.76 728485.83 43.28 471426.76 728485.83 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471428.82 728486.91 33.71 471429.65 728490.86 33.71 471429.65 728490.86 43.28 471428.82 728486.91 43.28 471428.82 728486.91 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.65 728490.86 33.71 471430.13 728490.76 33.71 471430.13 728490.76 43.28 471429.65 728490.86 43.28 471429.65 728490.86 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471430.13 728490.76 33.71 471431.33 728496.33 33.71 471431.33 728496.33 43.28 471430.13 728490.76 43.28 471430.13 728490.76 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471431.33 728496.33 33.71 471433.72 728495.78 33.71 471433.72 728495.78 43.28 471431.33 728496.33 43.28 471431.33 728496.33 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471433.72 728495.78 33.71 471434.12 728496.04 33.71 471434.12 728496.04 43.28 471433.72 728495.78 43.28 471433.72 728495.78 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471434.12 728496.04 33.71 471435.19 728501.09 33.71 471435.19 728501.09 43.28 471434.12 728496.04 43.28 471434.12 728496.04 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471435.19 728501.09 33.71 471434.86 728501.53 33.71 471434.86 728501.53 43.28 471435.19 728501.09 43.28 471435.19 728501.09 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471434.86 728501.53 33.71 471432.52 728502.08 33.71 471432.52 728502.08 43.28 471434.86 728501.53 43.28 471434.86 728501.53 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471432.52 728502.08 33.71 471433.68 728507.63 33.71 471433.68 728507.63 43.28 471432.52 728502.08 43.28 471432.52 728502.08 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471433.68 728507.63 33.71 471432.49 728507.86 33.71 471432.49 728507.86 43.28 471433.68 728507.63 43.28 471433.68 728507.63 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471432.49 728507.86 33.71 471433.29 728511.56 33.71 471433.29 728511.56 43.28 471432.49 728507.86 43.28 471432.49 728507.86 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471433.29 728511.56 33.71 471434.18 728511.81 33.71 471434.18 728511.81 43.28 471433.29 728511.56 43.28 471433.29 728511.56 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471434.18 728511.81 33.71 471434.47 728513.35 33.71 471434.47 728513.35 43.28 471434.18 728511.81 43.28 471434.18 728511.81 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471434.47 728513.35 33.71 471433.79 728513.95 33.71 471433.79 728513.95 43.28 471434.47 728513.35 43.28 471434.47 728513.35 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471433.79 728513.95 33.71 471434.56 728517.66 33.71 471434.56 728517.66 43.28 471433.79 728513.95 43.28 471433.79 728513.95 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471434.56 728517.66 33.71 471434.3 728517.71 33.71 471434.3 728517.71 43.28 471434.56 728517.66 43.28 471434.56 728517.66 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471434.3 728517.71 33.71 471434.94 728520.54 33.71 471434.94 728520.54 43.28 471434.3 728517.71 43.28 471434.3 728517.71 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471434.94 728520.54 33.71 471432.81 728520.98 33.71 471432.81 728520.98 43.28 471434.94 728520.54 43.28 471434.94 728520.54 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471432.81 728520.98 33.71 471432.89 728521.38 33.71 471432.89 728521.38 43.28 471432.81 728520.98 43.28 471432.81 728520.98 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471432.89 728521.38 33.71 471424.84 728523.26 33.71 471424.84 728523.26 43.28 471432.89 728521.38 43.28 471432.89 728521.38 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.84 728523.26 33.71 471424.48 728521.42 33.71 471424.48 728521.42 43.28 471424.84 728523.26 43.28 471424.84 728523.26 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.48 728521.42 33.71 471423.96 728518.74 33.71 471423.96 728518.74 43.28 471424.48 728521.42 43.28 471424.48 728521.42 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.96 728518.74 33.71 471423.54 728516.54 33.71 471423.54 728516.54 43.28 471423.96 728518.74 43.28 471423.96 728518.74 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.54 728516.54 33.71 471424.15 728515.26 33.71 471424.15 728515.26 43.28 471423.54 728516.54 43.28 471423.54 728516.54 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471424.15 728515.26 33.71 471425.11 728515.06 33.71 471425.11 728515.06 43.28 471424.15 728515.26 43.28 471424.15 728515.26 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471425.11 728515.06 33.71 471423.91 728509.08 33.71 471423.91 728509.08 43.28 471425.11 728515.06 43.28 471425.11 728515.06 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.91 728509.08 33.71 471422.47 728509.37 33.71 471422.47 728509.37 43.28 471423.91 728509.08 43.28 471423.91 728509.08 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.47 728509.37 33.71 471421.95 728508.95 33.71 471421.95 728508.95 43.28 471422.47 728509.37 43.28 471422.47 728509.37 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471421.95 728508.95 33.71 471421.36 728506.1 33.71 471421.36 728506.1 43.28 471421.95 728508.95 43.28 471421.95 728508.95 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471421.36 728506.1 33.71 471421.76 728505.48 33.71 471421.76 728505.48 43.28 471421.36 728506.1 43.28 471421.36 728506.1 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471421.76 728505.48 33.71 471423.12 728505.21 33.71 471423.12 728505.21 43.28 471421.76 728505.48 43.28 471421.76 728505.48 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.12 728505.21 33.71 471420.54 728492.75 33.71 471420.54 728492.75 43.28 471423.12 728505.21 43.28 471423.12 728505.21 33.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63CF-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471420.54 728492.75 43.28 471423.89 728492.05 43.28 471423.07 728488.09 43.28 471424.52 728486.28 43.28 471426.76 728485.83 43.28 471428.82 728486.91 43.28 471429.65 728490.86 43.28 471430.13 728490.76 43.28 471431.33 728496.33 43.28 471433.72 728495.78 43.28 471434.12 728496.04 43.28 471435.19 728501.09 43.28 471434.86 728501.53 43.28 471432.52 728502.08 43.28 471433.68 728507.63 43.28 471432.49 728507.86 43.28 471433.29 728511.56 43.28 471434.18 728511.81 43.28 471434.47 728513.35 43.28 471433.79 728513.95 43.28 471434.56 728517.66 43.28 471434.3 728517.71 43.28 471434.94 728520.54 43.28 471432.81 728520.98 43.28 471432.89 728521.38 43.28 471424.84 728523.26 43.28 471424.48 728521.42 43.28 471423.96 728518.74 43.28 471423.54 728516.54 43.28 471424.15 728515.26 43.28 471425.11 728515.06 43.28 471423.91 728509.08 43.28 471422.47 728509.37 43.28 471421.95 728508.95 43.28 471421.36 728506.1 43.28 471421.76 728505.48 43.28 471423.12 728505.21 43.28 471420.54 728492.75 43.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.28</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471295.04 728474.73 38.17 471297.91 728483.77 38.17 471298.2 728484.64 38.17 471299.43 728488.53 38.17 471304.08 728487.17 38.17 471302.98 728483.67 38.17 471304.46 728483.21 38.17 471304.05 728481.86 38.17 471305.33 728481.46 38.17 471304.49 728478.91 38.17 471306.3 728478.33 38.17 471304.21 728471.78 38.17 471300.39 728472.95 38.17 471300.27 728472.57 38.17 471295.13 728474.2 38.17 471295.22 728474.58 38.17 471295.04 728474.73 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471295.04 728474.73 38.17 471295.22 728474.58 38.17 471295.22 728474.58 46.45 471295.04 728474.73 46.45 471295.04 728474.73 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471295.22 728474.58 38.17 471295.13 728474.2 38.17 471295.13 728474.2 46.45 471295.22 728474.58 46.45 471295.22 728474.58 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471295.13 728474.2 38.17 471300.27 728472.57 38.17 471300.27 728472.57 46.45 471295.13 728474.2 46.45 471295.13 728474.2 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471300.27 728472.57 38.17 471300.39 728472.95 38.17 471300.39 728472.95 46.45 471300.27 728472.57 46.45 471300.27 728472.57 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471300.39 728472.95 38.17 471304.21 728471.78 38.17 471304.21 728471.78 46.45 471300.39 728472.95 46.45 471300.39 728472.95 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.21 728471.78 38.17 471306.3 728478.33 38.17 471306.3 728478.33 46.45 471304.21 728471.78 46.45 471304.21 728471.78 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471306.3 728478.33 38.17 471304.49 728478.91 38.17 471304.49 728478.91 46.45 471306.3 728478.33 46.45 471306.3 728478.33 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.49 728478.91 38.17 471305.33 728481.46 38.17 471305.33 728481.46 46.45 471304.49 728478.91 46.45 471304.49 728478.91 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.33 728481.46 38.17 471304.05 728481.86 38.17 471304.05 728481.86 46.45 471305.33 728481.46 46.45 471305.33 728481.46 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.05 728481.86 38.17 471304.46 728483.21 38.17 471304.46 728483.21 46.45 471304.05 728481.86 46.45 471304.05 728481.86 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.46 728483.21 38.17 471302.98 728483.67 38.17 471302.98 728483.67 46.45 471304.46 728483.21 46.45 471304.46 728483.21 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471302.98 728483.67 38.17 471304.08 728487.17 38.17 471304.08 728487.17 46.45 471302.98 728483.67 46.45 471302.98 728483.67 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.08 728487.17 38.17 471299.43 728488.53 38.17 471299.43 728488.53 46.45 471304.08 728487.17 46.45 471304.08 728487.17 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471299.43 728488.53 38.17 471298.2 728484.64 38.17 471298.2 728484.64 46.45 471299.43 728488.53 46.45 471299.43 728488.53 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471298.2 728484.64 38.17 471297.91 728483.77 38.17 471297.91 728483.77 46.45 471298.2 728484.64 46.45 471298.2 728484.64 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471297.91 728483.77 38.17 471295.04 728474.73 38.17 471295.04 728474.73 46.45 471297.91 728483.77 46.45 471297.91 728483.77 38.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D0-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471295.04 728474.73 46.45 471295.22 728474.58 46.45 471295.13 728474.2 46.45 471300.27 728472.57 46.45 471300.39 728472.95 46.45 471304.21 728471.78 46.45 471306.3 728478.33 46.45 471304.49 728478.91 46.45 471305.33 728481.46 46.45 471304.05 728481.86 46.45 471304.46 728483.21 46.45 471302.98 728483.67 46.45 471304.08 728487.17 46.45 471299.43 728488.53 46.45 471298.2 728484.64 46.45 471297.91 728483.77 46.45 471295.04 728474.73 46.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7800-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7800-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.97</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7800-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471395.82 728716.57 36.46 471398.91 728726.27 36.46 471429.81 728716.4 36.46 471436.43 728714.31 36.46 471433.33 728704.6 36.46 471395.82 728716.57 36.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7800-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471395.82 728716.57 36.46 471433.33 728704.6 36.46 471433.33 728704.6 42.43 471395.82 728716.57 42.43 471395.82 728716.57 36.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7800-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471433.33 728704.6 36.46 471436.43 728714.31 36.46 471436.43 728714.31 42.43 471433.33 728704.6 42.43 471433.33 728704.6 36.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7800-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471436.43 728714.31 36.46 471429.81 728716.4 36.46 471429.81 728716.4 42.43 471436.43 728714.31 42.43 471436.43 728714.31 36.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7800-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.81 728716.4 36.46 471398.91 728726.27 36.46 471398.91 728726.27 42.43 471429.81 728716.4 42.43 471429.81 728716.4 36.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7800-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471398.91 728726.27 36.46 471395.82 728716.57 36.46 471395.82 728716.57 42.43 471398.91 728726.27 42.43 471398.91 728726.27 36.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7800-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471395.82 728716.57 42.43 471433.33 728704.6 42.43 471436.43 728714.31 42.43 471429.81 728716.4 42.43 471398.91 728726.27 42.43 471395.82 728716.57 42.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471361.47 728405.7 35.59 471363.46 728409.14 35.59 471363.07 728409.34 35.59 471367.94 728417.77 35.59 471369.03 728417.44 35.59 471373.8 728414.37 35.59 471374.76 728413.85 35.59 471373.52 728411.54 35.59 471375.1 728410.57 35.59 471369.39 728401.12 35.59 471361.47 728405.7 35.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471361.47 728405.7 35.59 471369.39 728401.12 35.59 471369.39 728401.12 44.4 471361.47 728405.7 44.4 471361.47 728405.7 35.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.39 728401.12 35.59 471375.1 728410.57 35.59 471375.1 728410.57 44.4 471369.39 728401.12 44.4 471369.39 728401.12 35.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.1 728410.57 35.59 471373.52 728411.54 35.59 471373.52 728411.54 44.4 471375.1 728410.57 44.4 471375.1 728410.57 35.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.52 728411.54 35.59 471374.76 728413.85 35.59 471374.76 728413.85 44.4 471373.52 728411.54 44.4 471373.52 728411.54 35.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471374.76 728413.85 35.59 471373.8 728414.37 35.59 471373.8 728414.37 44.4 471374.76 728413.85 44.4 471374.76 728413.85 35.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.8 728414.37 35.59 471369.03 728417.44 35.59 471369.03 728417.44 44.4 471373.8 728414.37 44.4 471373.8 728414.37 35.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.03 728417.44 35.59 471367.94 728417.77 35.59 471367.94 728417.77 44.4 471369.03 728417.44 44.4 471369.03 728417.44 35.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471367.94 728417.77 35.59 471363.07 728409.34 35.59 471363.07 728409.34 44.4 471367.94 728417.77 44.4 471367.94 728417.77 35.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471363.07 728409.34 35.59 471363.46 728409.14 35.59 471363.46 728409.14 44.4 471363.07 728409.34 44.4 471363.07 728409.34 35.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471363.46 728409.14 35.59 471361.47 728405.7 35.59 471361.47 728405.7 44.4 471363.46 728409.14 44.4 471363.46 728409.14 35.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D3-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471361.47 728405.7 44.4 471369.39 728401.12 44.4 471375.1 728410.57 44.4 471373.52 728411.54 44.4 471374.76 728413.85 44.4 471373.8 728414.37 44.4 471369.03 728417.44 44.4 471367.94 728417.77 44.4 471363.07 728409.34 44.4 471363.46 728409.14 44.4 471361.47 728405.7 44.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-63D2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-63D2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471391.47 728411.37 33.4 471393.99 728420.39 33.4 471404.79 728417.26 33.4 471403.81 728414.23 33.4 471402.33 728414.77 33.4 471399.01 728403.7 33.4 471394.97 728404.85 33.4 471396.43 728409.95 33.4 471391.47 728411.37 33.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471391.47 728411.37 33.4 471396.43 728409.95 33.4 471396.43 728409.95 42.21 471391.47 728411.37 42.21 471391.47 728411.37 33.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471396.43 728409.95 33.4 471394.97 728404.85 33.4 471394.97 728404.85 42.21 471396.43 728409.95 42.21 471396.43 728409.95 33.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471394.97 728404.85 33.4 471399.01 728403.7 33.4 471399.01 728403.7 42.21 471394.97 728404.85 42.21 471394.97 728404.85 33.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471399.01 728403.7 33.4 471402.33 728414.77 33.4 471402.33 728414.77 42.21 471399.01 728403.7 42.21 471399.01 728403.7 33.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471402.33 728414.77 33.4 471403.81 728414.23 33.4 471403.81 728414.23 42.21 471402.33 728414.77 42.21 471402.33 728414.77 33.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D2-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471403.81 728414.23 33.4 471404.79 728417.26 33.4 471404.79 728417.26 42.21 471403.81 728414.23 42.21 471403.81 728414.23 33.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D2-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471404.79 728417.26 33.4 471393.99 728420.39 33.4 471393.99 728420.39 42.21 471404.79 728417.26 42.21 471404.79 728417.26 33.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D2-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.99 728420.39 33.4 471391.47 728411.37 33.4 471391.47 728411.37 42.21 471393.99 728420.39 42.21 471393.99 728420.39 33.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D2-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471391.47 728411.37 42.21 471396.43 728409.95 42.21 471394.97 728404.85 42.21 471399.01 728403.7 42.21 471402.33 728414.77 42.21 471403.81 728414.23 42.21 471404.79 728417.26 42.21 471393.99 728420.39 42.21 471391.47 728411.37 42.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-63D1-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-63D1-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D1-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471285.03 728455.37 38.77 471288.06 728465 38.77 471293.44 728463.14 38.77 471294.31 728465.9 38.77 471301.49 728463.65 38.77 471296.38 728447.69 38.77 471288.01 728450.27 38.77 471289.28 728454.02 38.77 471285.03 728455.37 38.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D1-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471285.03 728455.37 38.77 471289.28 728454.02 38.77 471289.28 728454.02 45.300000000000004 471285.03 728455.37 45.300000000000004 471285.03 728455.37 38.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D1-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471289.28 728454.02 38.77 471288.01 728450.27 38.77 471288.01 728450.27 45.300000000000004 471289.28 728454.02 45.300000000000004 471289.28 728454.02 38.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D1-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471288.01 728450.27 38.77 471296.38 728447.69 38.77 471296.38 728447.69 45.300000000000004 471288.01 728450.27 45.300000000000004 471288.01 728450.27 38.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D1-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471296.38 728447.69 38.77 471301.49 728463.65 38.77 471301.49 728463.65 45.300000000000004 471296.38 728447.69 45.300000000000004 471296.38 728447.69 38.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D1-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471301.49 728463.65 38.77 471294.31 728465.9 38.77 471294.31 728465.9 45.300000000000004 471301.49 728463.65 45.300000000000004 471301.49 728463.65 38.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D1-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471294.31 728465.9 38.77 471293.44 728463.14 38.77 471293.44 728463.14 45.300000000000004 471294.31 728465.9 45.300000000000004 471294.31 728465.9 38.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D1-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471293.44 728463.14 38.77 471288.06 728465 38.77 471288.06 728465 45.300000000000004 471293.44 728463.14 45.300000000000004 471293.44 728463.14 38.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D1-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471288.06 728465 38.77 471285.03 728455.37 38.77 471285.03 728455.37 45.300000000000004 471288.06 728465 45.300000000000004 471288.06 728465 38.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-63D1-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471285.03 728455.37 45.300000000000004 471289.28 728454.02 45.300000000000004 471288.01 728450.27 45.300000000000004 471296.38 728447.69 45.300000000000004 471301.49 728463.65 45.300000000000004 471294.31 728465.9 45.300000000000004 471293.44 728463.14 45.300000000000004 471288.06 728465 45.300000000000004 471285.03 728455.37 45.300000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4F8D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4F8D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.93</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F8D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471271.66 728430.31 40.09 471278.08 728429.46 40.09 471275.38 728408.37 40.09 471269.08 728409.06 40.09 471271.66 728430.31 40.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F8D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471271.66 728430.31 40.09 471269.08 728409.06 40.09 471269.08 728409.06 43.02 471271.66 728430.31 43.02 471271.66 728430.31 40.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F8D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471269.08 728409.06 40.09 471275.38 728408.37 40.09 471275.38 728408.37 43.02 471269.08 728409.06 43.02 471269.08 728409.06 40.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F8D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471275.38 728408.37 40.09 471278.08 728429.46 40.09 471278.08 728429.46 43.02 471275.38 728408.37 43.02 471275.38 728408.37 40.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F8D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471278.08 728429.46 40.09 471271.66 728430.31 40.09 471271.66 728430.31 43.02 471278.08 728429.46 43.02 471278.08 728429.46 40.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F8D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471271.66 728430.31 43.02 471269.08 728409.06 43.02 471275.38 728408.37 43.02 471278.08 728429.46 43.02 471271.66 728430.31 43.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5398-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5398-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.26</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5398-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.98 728194.66 35.41 471319.02 728193.21 35.41 471316.66 728185.11 35.41 471312.31 728186.46 35.41 471314.98 728194.66 35.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5398-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.98 728194.66 35.41 471312.31 728186.46 35.41 471312.31 728186.46 38.67 471314.98 728194.66 38.67 471314.98 728194.66 35.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5398-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.31 728186.46 35.41 471316.66 728185.11 35.41 471316.66 728185.11 38.67 471312.31 728186.46 38.67 471312.31 728186.46 35.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5398-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471316.66 728185.11 35.41 471319.02 728193.21 35.41 471319.02 728193.21 38.67 471316.66 728185.11 38.67 471316.66 728185.11 35.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5398-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471319.02 728193.21 35.41 471314.98 728194.66 35.41 471314.98 728194.66 38.67 471319.02 728193.21 38.67 471319.02 728193.21 35.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5398-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.98 728194.66 38.67 471312.31 728186.46 38.67 471316.66 728185.11 38.67 471319.02 728193.21 38.67 471314.98 728194.66 38.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.36</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471365.63 728218.42 32.68 471368.98 728227.86 32.68 471367.6 728228.38 32.68 471368.77 728231.65 32.68 471370.18 728231.14 32.68 471373.63 728240.58 32.68 471383.03 728237.18 32.68 471379.67 728227.83 32.68 471381.1 728227.3 32.68 471379.92 728223.87 32.68 471378.49 728224.37 32.68 471375.87 728217.08 32.68 471376.5 728215.76 32.68 471373.67 728214.46 32.68 471373.03 728215.78 32.68 471365.63 728218.42 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471365.63 728218.42 32.68 471373.03 728215.78 32.68 471373.03 728215.78 42.04 471365.63 728218.42 42.04 471365.63 728218.42 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.03 728215.78 32.68 471373.67 728214.46 32.68 471373.67 728214.46 42.04 471373.03 728215.78 42.04 471373.03 728215.78 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.67 728214.46 32.68 471376.5 728215.76 32.68 471376.5 728215.76 42.04 471373.67 728214.46 42.04 471373.67 728214.46 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471376.5 728215.76 32.68 471375.87 728217.08 32.68 471375.87 728217.08 42.04 471376.5 728215.76 42.04 471376.5 728215.76 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.87 728217.08 32.68 471378.49 728224.37 32.68 471378.49 728224.37 42.04 471375.87 728217.08 42.04 471375.87 728217.08 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471378.49 728224.37 32.68 471379.92 728223.87 32.68 471379.92 728223.87 42.04 471378.49 728224.37 42.04 471378.49 728224.37 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.92 728223.87 32.68 471381.1 728227.3 32.68 471381.1 728227.3 42.04 471379.92 728223.87 42.04 471379.92 728223.87 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471381.1 728227.3 32.68 471379.67 728227.83 32.68 471379.67 728227.83 42.04 471381.1 728227.3 42.04 471381.1 728227.3 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.67 728227.83 32.68 471383.03 728237.18 32.68 471383.03 728237.18 42.04 471379.67 728227.83 42.04 471379.67 728227.83 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.03 728237.18 32.68 471373.63 728240.58 32.68 471373.63 728240.58 42.04 471383.03 728237.18 42.04 471383.03 728237.18 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.63 728240.58 32.68 471370.18 728231.14 32.68 471370.18 728231.14 42.04 471373.63 728240.58 42.04 471373.63 728240.58 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.18 728231.14 32.68 471368.77 728231.65 32.68 471368.77 728231.65 42.04 471370.18 728231.14 42.04 471370.18 728231.14 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.77 728231.65 32.68 471367.6 728228.38 32.68 471367.6 728228.38 42.04 471368.77 728231.65 42.04 471368.77 728231.65 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471367.6 728228.38 32.68 471368.98 728227.86 32.68 471368.98 728227.86 42.04 471367.6 728228.38 42.04 471367.6 728228.38 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.98 728227.86 32.68 471365.63 728218.42 32.68 471365.63 728218.42 42.04 471368.98 728227.86 42.04 471368.98 728227.86 32.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8C4-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471365.63 728218.42 42.04 471373.03 728215.78 42.04 471373.67 728214.46 42.04 471376.5 728215.76 42.04 471375.87 728217.08 42.04 471378.49 728224.37 42.04 471379.92 728223.87 42.04 471381.1 728227.3 42.04 471379.67 728227.83 42.04 471383.03 728237.18 42.04 471373.63 728240.58 42.04 471370.18 728231.14 42.04 471368.77 728231.65 42.04 471367.6 728228.38 42.04 471368.98 728227.86 42.04 471365.63 728218.42 42.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-44F8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-44F8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.42</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471302.15 728232.43 35.63 471305.28 728242.49 35.63 471324.38 728236.3 35.63 471321.2 728226.32 35.63 471302.15 728232.43 35.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471302.15 728232.43 35.63 471321.2 728226.32 35.63 471321.2 728226.32 43.050000000000004 471302.15 728232.43 43.050000000000004 471302.15 728232.43 35.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471321.2 728226.32 35.63 471324.38 728236.3 35.63 471324.38 728236.3 43.050000000000004 471321.2 728226.32 43.050000000000004 471321.2 728226.32 35.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471324.38 728236.3 35.63 471305.28 728242.49 35.63 471305.28 728242.49 43.050000000000004 471324.38 728236.3 43.050000000000004 471324.38 728236.3 35.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.28 728242.49 35.63 471302.15 728232.43 35.63 471302.15 728232.43 43.050000000000004 471305.28 728242.49 43.050000000000004 471305.28 728242.49 35.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471302.15 728232.43 43.050000000000004 471321.2 728226.32 43.050000000000004 471324.38 728236.3 43.050000000000004 471305.28 728242.49 43.050000000000004 471302.15 728232.43 43.050000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.26</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.67 728237.85 34.96 471332.65 728236.93 34.96 471332.17 728235.38 34.96 471336.69 728233.96 34.96 471337.18 728235.48 34.96 471341.55 728234.18 34.96 471341.04 728232.59 34.96 471344.2 728231.58 34.96 471344.58 728232.81 34.96 471347.39 728231.9 34.96 471347.01 728230.69 34.96 471347.28 728230.61 34.96 471344.54 728222 34.96 471326.33 728227.76 34.96 471329.04 728236.39 34.96 471329.2 728236.33 34.96 471329.67 728237.85 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.67 728237.85 34.96 471329.2 728236.33 34.96 471329.2 728236.33 40.22 471329.67 728237.85 40.22 471329.67 728237.85 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.2 728236.33 34.96 471329.04 728236.39 34.96 471329.04 728236.39 40.22 471329.2 728236.33 40.22 471329.2 728236.33 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.04 728236.39 34.96 471326.33 728227.76 34.96 471326.33 728227.76 40.22 471329.04 728236.39 40.22 471329.04 728236.39 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471326.33 728227.76 34.96 471344.54 728222 34.96 471344.54 728222 40.22 471326.33 728227.76 40.22 471326.33 728227.76 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.54 728222 34.96 471347.28 728230.61 34.96 471347.28 728230.61 40.22 471344.54 728222 40.22 471344.54 728222 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.28 728230.61 34.96 471347.01 728230.69 34.96 471347.01 728230.69 40.22 471347.28 728230.61 40.22 471347.28 728230.61 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.01 728230.69 34.96 471347.39 728231.9 34.96 471347.39 728231.9 40.22 471347.01 728230.69 40.22 471347.01 728230.69 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.39 728231.9 34.96 471344.58 728232.81 34.96 471344.58 728232.81 40.22 471347.39 728231.9 40.22 471347.39 728231.9 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.58 728232.81 34.96 471344.2 728231.58 34.96 471344.2 728231.58 40.22 471344.58 728232.81 40.22 471344.58 728232.81 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.2 728231.58 34.96 471341.04 728232.59 34.96 471341.04 728232.59 40.22 471344.2 728231.58 40.22 471344.2 728231.58 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471341.04 728232.59 34.96 471341.55 728234.18 34.96 471341.55 728234.18 40.22 471341.04 728232.59 40.22 471341.04 728232.59 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471341.55 728234.18 34.96 471337.18 728235.48 34.96 471337.18 728235.48 40.22 471341.55 728234.18 40.22 471341.55 728234.18 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.18 728235.48 34.96 471336.69 728233.96 34.96 471336.69 728233.96 40.22 471337.18 728235.48 40.22 471337.18 728235.48 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471336.69 728233.96 34.96 471332.17 728235.38 34.96 471332.17 728235.38 40.22 471336.69 728233.96 40.22 471336.69 728233.96 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471332.17 728235.38 34.96 471332.65 728236.93 34.96 471332.65 728236.93 40.22 471332.17 728235.38 40.22 471332.17 728235.38 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471332.65 728236.93 34.96 471329.67 728237.85 34.96 471329.67 728237.85 40.22 471332.65 728236.93 40.22 471332.65 728236.93 34.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F7-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.67 728237.85 40.22 471329.2 728236.33 40.22 471329.04 728236.39 40.22 471326.33 728227.76 40.22 471344.54 728222 40.22 471347.28 728230.61 40.22 471347.01 728230.69 40.22 471347.39 728231.9 40.22 471344.58 728232.81 40.22 471344.2 728231.58 40.22 471341.04 728232.59 40.22 471341.55 728234.18 40.22 471337.18 728235.48 40.22 471336.69 728233.96 40.22 471332.17 728235.38 40.22 471332.65 728236.93 40.22 471329.67 728237.85 40.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.73</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471292.28 728212.3 35.8 471295.29 728221.95 35.8 471305.63 728218.7 35.8 471307.34 728218.16 35.8 471307.46 728218.11 35.8 471315.67 728215.53 35.8 471316.71 728213.58 35.8 471316.32 728212.38 35.8 471314.08 728205.44 35.8 471313.37 728205.67 35.8 471312.84 728204.23 35.8 471308.33 728205.63 35.8 471308.81 728207.09 35.8 471292.28 728212.3 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471292.28 728212.3 35.8 471308.81 728207.09 35.8 471308.81 728207.09 45.53 471292.28 728212.3 45.53 471292.28 728212.3 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471308.81 728207.09 35.8 471308.33 728205.63 35.8 471308.33 728205.63 45.53 471308.81 728207.09 45.53 471308.81 728207.09 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471308.33 728205.63 35.8 471312.84 728204.23 35.8 471312.84 728204.23 45.53 471308.33 728205.63 45.53 471308.33 728205.63 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.84 728204.23 35.8 471313.37 728205.67 35.8 471313.37 728205.67 45.53 471312.84 728204.23 45.53 471312.84 728204.23 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471313.37 728205.67 35.8 471314.08 728205.44 35.8 471314.08 728205.44 45.53 471313.37 728205.67 45.53 471313.37 728205.67 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.08 728205.44 35.8 471316.32 728212.38 35.8 471316.32 728212.38 45.53 471314.08 728205.44 45.53 471314.08 728205.44 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471316.32 728212.38 35.8 471316.71 728213.58 35.8 471316.71 728213.58 45.53 471316.32 728212.38 45.53 471316.32 728212.38 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471316.71 728213.58 35.8 471315.67 728215.53 35.8 471315.67 728215.53 45.53 471316.71 728213.58 45.53 471316.71 728213.58 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471315.67 728215.53 35.8 471307.46 728218.11 35.8 471307.46 728218.11 45.53 471315.67 728215.53 45.53 471315.67 728215.53 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471307.46 728218.11 35.8 471307.34 728218.16 35.8 471307.34 728218.16 45.53 471307.46 728218.11 45.53 471307.46 728218.11 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471307.34 728218.16 35.8 471305.63 728218.7 35.8 471305.63 728218.7 45.53 471307.34 728218.16 45.53 471307.34 728218.16 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.63 728218.7 35.8 471295.29 728221.95 35.8 471295.29 728221.95 45.53 471305.63 728218.7 45.53 471305.63 728218.7 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471295.29 728221.95 35.8 471292.28 728212.3 35.8 471292.28 728212.3 45.53 471295.29 728221.95 45.53 471295.29 728221.95 35.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F6-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471292.28 728212.3 45.53 471308.81 728207.09 45.53 471308.33 728205.63 45.53 471312.84 728204.23 45.53 471313.37 728205.67 45.53 471314.08 728205.44 45.53 471316.32 728212.38 45.53 471316.71 728213.58 45.53 471315.67 728215.53 45.53 471307.46 728218.11 45.53 471307.34 728218.16 45.53 471305.63 728218.7 45.53 471295.29 728221.95 45.53 471292.28 728212.3 45.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">14.56</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471573.41 728697.25 25.05 471579.52 728708.71 25.05 471580.6 728708.13 25.05 471585.36 728716.45 25.05 471586.37 728715.9 25.05 471597.23 728709.83 25.05 471598.77 728708.97 25.05 471593.79 728700.29 25.05 471590.21 728702.3 25.05 471588.99 728700.04 25.05 471591.49 728698.59 25.05 471586.82 728689.84 25.05 471573.41 728697.25 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471573.41 728697.25 25.05 471586.82 728689.84 25.05 471586.82 728689.84 39.61 471573.41 728697.25 39.61 471573.41 728697.25 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471586.82 728689.84 25.05 471591.49 728698.59 25.05 471591.49 728698.59 39.61 471586.82 728689.84 39.61 471586.82 728689.84 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471591.49 728698.59 25.05 471588.99 728700.04 25.05 471588.99 728700.04 39.61 471591.49 728698.59 39.61 471591.49 728698.59 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471588.99 728700.04 25.05 471590.21 728702.3 25.05 471590.21 728702.3 39.61 471588.99 728700.04 39.61 471588.99 728700.04 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471590.21 728702.3 25.05 471593.79 728700.29 25.05 471593.79 728700.29 39.61 471590.21 728702.3 39.61 471590.21 728702.3 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471593.79 728700.29 25.05 471598.77 728708.97 25.05 471598.77 728708.97 39.61 471593.79 728700.29 39.61 471593.79 728700.29 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471598.77 728708.97 25.05 471597.23 728709.83 25.05 471597.23 728709.83 39.61 471598.77 728708.97 39.61 471598.77 728708.97 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471597.23 728709.83 25.05 471586.37 728715.9 25.05 471586.37 728715.9 39.61 471597.23 728709.83 39.61 471597.23 728709.83 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471586.37 728715.9 25.05 471585.36 728716.45 25.05 471585.36 728716.45 39.61 471586.37 728715.9 39.61 471586.37 728715.9 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471585.36 728716.45 25.05 471580.6 728708.13 25.05 471580.6 728708.13 39.61 471585.36 728716.45 39.61 471585.36 728716.45 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471580.6 728708.13 25.05 471579.52 728708.71 25.05 471579.52 728708.71 39.61 471580.6 728708.13 39.61 471580.6 728708.13 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471579.52 728708.71 25.05 471573.41 728697.25 25.05 471573.41 728697.25 39.61 471579.52 728708.71 39.61 471579.52 728708.71 25.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F4-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471573.41 728697.25 39.61 471586.82 728689.84 39.61 471591.49 728698.59 39.61 471588.99 728700.04 39.61 471590.21 728702.3 39.61 471593.79 728700.29 39.61 471598.77 728708.97 39.61 471597.23 728709.83 39.61 471586.37 728715.9 39.61 471585.36 728716.45 39.61 471580.6 728708.13 39.61 471579.52 728708.71 39.61 471573.41 728697.25 39.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-44F5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-44F5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471323.76 728212.91 34.14 471343.36 728206.57 34.14 471340.11 728196.51 34.14 471320.6 728202.86 34.14 471323.76 728212.91 34.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471323.76 728212.91 34.14 471320.6 728202.86 34.14 471320.6 728202.86 43.13 471323.76 728212.91 43.13 471323.76 728212.91 34.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471320.6 728202.86 34.14 471340.11 728196.51 34.14 471340.11 728196.51 43.13 471320.6 728202.86 43.13 471320.6 728202.86 34.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471340.11 728196.51 34.14 471343.36 728206.57 34.14 471343.36 728206.57 43.13 471340.11 728196.51 43.13 471340.11 728196.51 34.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471343.36 728206.57 34.14 471323.76 728212.91 34.14 471323.76 728212.91 43.13 471343.36 728206.57 43.13 471343.36 728206.57 34.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471323.76 728212.91 43.13 471320.6 728202.86 43.13 471340.11 728196.51 43.13 471343.36 728206.57 43.13 471323.76 728212.91 43.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.12</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.47 728400.12 31.7 471430.47 728398.04 31.7 471431.9 728397.59 31.7 471439.41 728395.33 31.7 471435.96 728383.97 31.7 471427.5 728386.57 31.7 471426.47 728383.19 31.7 471422.05 728384.55 31.7 471422.76 728386.9 31.7 471423.39 728386.74 31.7 471423.69 728387.73 31.7 471423.08 728387.93 31.7 471420.01 728388.87 31.7 471423.47 728400.12 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.47 728400.12 31.7 471420.01 728388.87 31.7 471420.01 728388.87 40.82 471423.47 728400.12 40.82 471423.47 728400.12 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471420.01 728388.87 31.7 471423.08 728387.93 31.7 471423.08 728387.93 40.82 471420.01 728388.87 40.82 471420.01 728388.87 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.08 728387.93 31.7 471423.69 728387.73 31.7 471423.69 728387.73 40.82 471423.08 728387.93 40.82 471423.08 728387.93 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.69 728387.73 31.7 471423.39 728386.74 31.7 471423.39 728386.74 40.82 471423.69 728387.73 40.82 471423.69 728387.73 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.39 728386.74 31.7 471422.76 728386.9 31.7 471422.76 728386.9 40.82 471423.39 728386.74 40.82 471423.39 728386.74 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.76 728386.9 31.7 471422.05 728384.55 31.7 471422.05 728384.55 40.82 471422.76 728386.9 40.82 471422.76 728386.9 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471422.05 728384.55 31.7 471426.47 728383.19 31.7 471426.47 728383.19 40.82 471422.05 728384.55 40.82 471422.05 728384.55 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471426.47 728383.19 31.7 471427.5 728386.57 31.7 471427.5 728386.57 40.82 471426.47 728383.19 40.82 471426.47 728383.19 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471427.5 728386.57 31.7 471435.96 728383.97 31.7 471435.96 728383.97 40.82 471427.5 728386.57 40.82 471427.5 728386.57 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471435.96 728383.97 31.7 471439.41 728395.33 31.7 471439.41 728395.33 40.82 471435.96 728383.97 40.82 471435.96 728383.97 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471439.41 728395.33 31.7 471431.9 728397.59 31.7 471431.9 728397.59 40.82 471439.41 728395.33 40.82 471439.41 728395.33 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471431.9 728397.59 31.7 471430.47 728398.04 31.7 471430.47 728398.04 40.82 471431.9 728397.59 40.82 471431.9 728397.59 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471430.47 728398.04 31.7 471423.47 728400.12 31.7 471423.47 728400.12 40.82 471430.47 728398.04 40.82 471430.47 728398.04 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F2-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471423.47 728400.12 40.82 471420.01 728388.87 40.82 471423.08 728387.93 40.82 471423.69 728387.73 40.82 471423.39 728386.74 40.82 471422.76 728386.9 40.82 471422.05 728384.55 40.82 471426.47 728383.19 40.82 471427.5 728386.57 40.82 471435.96 728383.97 40.82 471439.41 728395.33 40.82 471431.9 728397.59 40.82 471430.47 728398.04 40.82 471423.47 728400.12 40.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.09</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.52 728419.36 32.1 471436.45 728417.24 32.1 471437.85 728416.8 32.1 471445.41 728414.47 32.1 471441.88 728402.87 32.1 471433.07 728405.57 32.1 471432.36 728403.25 32.1 471429.02 728404.32 32.1 471429.71 728406.65 32.1 471428.42 728407.02 32.1 471425.92 728407.78 32.1 471429.52 728419.36 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.52 728419.36 32.1 471425.92 728407.78 32.1 471425.92 728407.78 41.19 471429.52 728419.36 41.19 471429.52 728419.36 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471425.92 728407.78 32.1 471428.42 728407.02 32.1 471428.42 728407.02 41.19 471425.92 728407.78 41.19 471425.92 728407.78 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471428.42 728407.02 32.1 471429.71 728406.65 32.1 471429.71 728406.65 41.19 471428.42 728407.02 41.19 471428.42 728407.02 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.71 728406.65 32.1 471429.02 728404.32 32.1 471429.02 728404.32 41.19 471429.71 728406.65 41.19 471429.71 728406.65 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.02 728404.32 32.1 471432.36 728403.25 32.1 471432.36 728403.25 41.19 471429.02 728404.32 41.19 471429.02 728404.32 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471432.36 728403.25 32.1 471433.07 728405.57 32.1 471433.07 728405.57 41.19 471432.36 728403.25 41.19 471432.36 728403.25 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471433.07 728405.57 32.1 471441.88 728402.87 32.1 471441.88 728402.87 41.19 471433.07 728405.57 41.19 471433.07 728405.57 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471441.88 728402.87 32.1 471445.41 728414.47 32.1 471445.41 728414.47 41.19 471441.88 728402.87 41.19 471441.88 728402.87 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471445.41 728414.47 32.1 471437.85 728416.8 32.1 471437.85 728416.8 41.19 471445.41 728414.47 41.19 471445.41 728414.47 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471437.85 728416.8 32.1 471436.45 728417.24 32.1 471436.45 728417.24 41.19 471437.85 728416.8 41.19 471437.85 728416.8 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471436.45 728417.24 32.1 471429.52 728419.36 32.1 471429.52 728419.36 41.19 471436.45 728417.24 41.19 471436.45 728417.24 32.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F3-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.52 728419.36 41.19 471425.92 728407.78 41.19 471428.42 728407.02 41.19 471429.71 728406.65 41.19 471429.02 728404.32 41.19 471432.36 728403.25 41.19 471433.07 728405.57 41.19 471441.88 728402.87 41.19 471445.41 728414.47 41.19 471437.85 728416.8 41.19 471436.45 728417.24 41.19 471429.52 728419.36 41.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">15.85</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471586.37 728715.9 24.16 471589.68 728722.12 24.16 471589.52 728722.17 24.16 471589.75 728725.3 24.16 471594.62 728724.88 24.16 471594.89 728727.38 24.16 471598.13 728727.11 24.16 471597.96 728724.62 24.16 471600.53 728724.38 24.16 471600.61 728725.28 24.16 471612.2 728724.21 24.16 471612.27 728725.15 24.16 471615.17 728724.87 24.16 471615.13 728724.22 24.16 471621.2 728723.65 24.16 471620.14 728711.66 24.16 471613.64 728712.21 24.16 471613.71 728713.35 24.16 471604.81 728714.22 24.16 471604.96 728716.02 24.16 471600.69 728716.41 24.16 471597.23 728709.83 24.16 471586.37 728715.9 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471586.37 728715.9 24.16 471597.23 728709.83 24.16 471597.23 728709.83 40.01 471586.37 728715.9 40.01 471586.37 728715.9 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471597.23 728709.83 24.16 471600.69 728716.41 24.16 471600.69 728716.41 40.01 471597.23 728709.83 40.01 471597.23 728709.83 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471600.69 728716.41 24.16 471604.96 728716.02 24.16 471604.96 728716.02 40.01 471600.69 728716.41 40.01 471600.69 728716.41 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471604.96 728716.02 24.16 471604.81 728714.22 24.16 471604.81 728714.22 40.01 471604.96 728716.02 40.01 471604.96 728716.02 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471604.81 728714.22 24.16 471613.71 728713.35 24.16 471613.71 728713.35 40.01 471604.81 728714.22 40.01 471604.81 728714.22 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471613.71 728713.35 24.16 471613.64 728712.21 24.16 471613.64 728712.21 40.01 471613.71 728713.35 40.01 471613.71 728713.35 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471613.64 728712.21 24.16 471620.14 728711.66 24.16 471620.14 728711.66 40.01 471613.64 728712.21 40.01 471613.64 728712.21 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471620.14 728711.66 24.16 471621.2 728723.65 24.16 471621.2 728723.65 40.01 471620.14 728711.66 40.01 471620.14 728711.66 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471621.2 728723.65 24.16 471615.13 728724.22 24.16 471615.13 728724.22 40.01 471621.2 728723.65 40.01 471621.2 728723.65 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471615.13 728724.22 24.16 471615.17 728724.87 24.16 471615.17 728724.87 40.01 471615.13 728724.22 40.01 471615.13 728724.22 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471615.17 728724.87 24.16 471612.27 728725.15 24.16 471612.27 728725.15 40.01 471615.17 728724.87 40.01 471615.17 728724.87 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471612.27 728725.15 24.16 471612.2 728724.21 24.16 471612.2 728724.21 40.01 471612.27 728725.15 40.01 471612.27 728725.15 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471612.2 728724.21 24.16 471600.61 728725.28 24.16 471600.61 728725.28 40.01 471612.2 728724.21 40.01 471612.2 728724.21 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471600.61 728725.28 24.16 471600.53 728724.38 24.16 471600.53 728724.38 40.01 471600.61 728725.28 40.01 471600.61 728725.28 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471600.53 728724.38 24.16 471597.96 728724.62 24.16 471597.96 728724.62 40.01 471600.53 728724.38 40.01 471600.53 728724.38 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471597.96 728724.62 24.16 471598.13 728727.11 24.16 471598.13 728727.11 40.01 471597.96 728724.62 40.01 471597.96 728724.62 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471598.13 728727.11 24.16 471594.89 728727.38 24.16 471594.89 728727.38 40.01 471598.13 728727.11 40.01 471598.13 728727.11 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471594.89 728727.38 24.16 471594.62 728724.88 24.16 471594.62 728724.88 40.01 471594.89 728727.38 40.01 471594.89 728727.38 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471594.62 728724.88 24.16 471589.75 728725.3 24.16 471589.75 728725.3 40.01 471594.62 728724.88 40.01 471594.62 728724.88 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471589.75 728725.3 24.16 471589.52 728722.17 24.16 471589.52 728722.17 40.01 471589.75 728725.3 40.01 471589.75 728725.3 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471589.52 728722.17 24.16 471589.68 728722.12 24.16 471589.68 728722.12 40.01 471589.52 728722.17 40.01 471589.52 728722.17 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471589.68 728722.12 24.16 471586.37 728715.9 24.16 471586.37 728715.9 40.01 471589.68 728722.12 40.01 471589.68 728722.12 24.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F1-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471586.37 728715.9 40.01 471597.23 728709.83 40.01 471600.69 728716.41 40.01 471604.96 728716.02 40.01 471604.81 728714.22 40.01 471613.71 728713.35 40.01 471613.64 728712.21 40.01 471620.14 728711.66 40.01 471621.2 728723.65 40.01 471615.13 728724.22 40.01 471615.17 728724.87 40.01 471612.27 728725.15 40.01 471612.2 728724.21 40.01 471600.61 728725.28 40.01 471600.53 728724.38 40.01 471597.96 728724.62 40.01 471598.13 728727.11 40.01 471594.89 728727.38 40.01 471594.62 728724.88 40.01 471589.75 728725.3 40.01 471589.52 728722.17 40.01 471589.68 728722.12 40.01 471586.37 728715.9 40.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2921-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471365.96 728337.76 32.58 471368.32 728344.98 32.58 471379.8 728341.2 32.58 471379.88 728341.45 32.58 471383.51 728340.34 32.58 471383.36 728339.86 32.58 471382.36 728336.74 32.58 471380.9 728337.18 32.58 471379.01 728331.41 32.58 471375.48 728332.53 32.58 471375.34 728332.13 32.58 471375.21 728332.17 32.58 471375.01 728331.49 32.58 471369.93 728333.05 32.58 471370.13 728333.72 32.58 471370.01 728333.76 32.58 471370.13 728334.13 32.58 471369.73 728334.29 32.58 471370.38 728336.32 32.58 471365.96 728337.76 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471365.96 728337.76 32.58 471370.38 728336.32 32.58 471370.38 728336.32 41.13 471365.96 728337.76 41.13 471365.96 728337.76 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.38 728336.32 32.58 471369.73 728334.29 32.58 471369.73 728334.29 41.13 471370.38 728336.32 41.13 471370.38 728336.32 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.73 728334.29 32.58 471370.13 728334.13 32.58 471370.13 728334.13 41.13 471369.73 728334.29 41.13 471369.73 728334.29 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.13 728334.13 32.58 471370.01 728333.76 32.58 471370.01 728333.76 41.13 471370.13 728334.13 41.13 471370.13 728334.13 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.01 728333.76 32.58 471370.13 728333.72 32.58 471370.13 728333.72 41.13 471370.01 728333.76 41.13 471370.01 728333.76 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.13 728333.72 32.58 471369.93 728333.05 32.58 471369.93 728333.05 41.13 471370.13 728333.72 41.13 471370.13 728333.72 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.93 728333.05 32.58 471375.01 728331.49 32.58 471375.01 728331.49 41.13 471369.93 728333.05 41.13 471369.93 728333.05 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.01 728331.49 32.58 471375.21 728332.17 32.58 471375.21 728332.17 41.13 471375.01 728331.49 41.13 471375.01 728331.49 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.21 728332.17 32.58 471375.34 728332.13 32.58 471375.34 728332.13 41.13 471375.21 728332.17 41.13 471375.21 728332.17 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.34 728332.13 32.58 471375.48 728332.53 32.58 471375.48 728332.53 41.13 471375.34 728332.13 41.13 471375.34 728332.13 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.48 728332.53 32.58 471379.01 728331.41 32.58 471379.01 728331.41 41.13 471375.48 728332.53 41.13 471375.48 728332.53 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.01 728331.41 32.58 471380.9 728337.18 32.58 471380.9 728337.18 41.13 471379.01 728331.41 41.13 471379.01 728331.41 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.9 728337.18 32.58 471382.36 728336.74 32.58 471382.36 728336.74 41.13 471380.9 728337.18 41.13 471380.9 728337.18 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471382.36 728336.74 32.58 471383.36 728339.86 32.58 471383.36 728339.86 41.13 471382.36 728336.74 41.13 471382.36 728336.74 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.36 728339.86 32.58 471383.51 728340.34 32.58 471383.51 728340.34 41.13 471383.36 728339.86 41.13 471383.36 728339.86 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.51 728340.34 32.58 471379.88 728341.45 32.58 471379.88 728341.45 41.13 471383.51 728340.34 41.13 471383.51 728340.34 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.88 728341.45 32.58 471379.8 728341.2 32.58 471379.8 728341.2 41.13 471379.88 728341.45 41.13 471379.88 728341.45 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.8 728341.2 32.58 471368.32 728344.98 32.58 471368.32 728344.98 41.13 471379.8 728341.2 41.13 471379.8 728341.2 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.32 728344.98 32.58 471365.96 728337.76 32.58 471365.96 728337.76 41.13 471368.32 728344.98 41.13 471368.32 728344.98 32.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2921-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471365.96 728337.76 41.13 471370.38 728336.32 41.13 471369.73 728334.29 41.13 471370.13 728334.13 41.13 471370.01 728333.76 41.13 471370.13 728333.72 41.13 471369.93 728333.05 41.13 471375.01 728331.49 41.13 471375.21 728332.17 41.13 471375.34 728332.13 41.13 471375.48 728332.53 41.13 471379.01 728331.41 41.13 471380.9 728337.18 41.13 471382.36 728336.74 41.13 471383.36 728339.86 41.13 471383.51 728340.34 41.13 471379.88 728341.45 41.13 471379.8 728341.2 41.13 471368.32 728344.98 41.13 471365.96 728337.76 41.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2875-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.37</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471241.92 728303.72 40.55 471243.42 728308.21 40.55 471247.33 728306.96 40.55 471248.92 728311.44 40.55 471259.58 728307.67 40.55 471258.58 728304.9 40.55 471257.02 728305.47 40.55 471253.29 728295.3 40.55 471242.1 728299.3 40.55 471243.39 728303.2 40.55 471241.92 728303.72 40.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471241.92 728303.72 40.55 471243.39 728303.2 40.55 471243.39 728303.2 48.915 471241.92 728303.72 48.915 471241.92 728303.72 40.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471243.39 728303.2 40.55 471242.1 728299.3 40.55 471242.1 728299.3 48.915 471243.39 728303.2 48.915 471243.39 728303.2 40.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471242.1 728299.3 40.55 471253.29 728295.3 40.55 471253.29 728295.3 48.915 471242.1 728299.3 48.915 471242.1 728299.3 40.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471253.29 728295.3 40.55 471257.02 728305.47 40.55 471257.02 728305.47 48.915 471253.29 728295.3 48.915 471253.29 728295.3 40.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471257.02 728305.47 40.55 471258.58 728304.9 40.55 471258.58 728304.9 48.915 471257.02 728305.47 48.915 471257.02 728305.47 40.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471258.58 728304.9 40.55 471259.58 728307.67 40.55 471259.58 728307.67 48.915 471258.58 728304.9 48.915 471258.58 728304.9 40.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471259.58 728307.67 40.55 471248.92 728311.44 40.55 471248.92 728311.44 48.915 471259.58 728307.67 48.915 471259.58 728307.67 40.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471248.92 728311.44 40.55 471247.33 728306.96 40.55 471247.33 728306.96 48.915 471248.92 728311.44 48.915 471248.92 728311.44 40.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471247.33 728306.96 40.55 471243.42 728308.21 40.55 471243.42 728308.21 48.915 471247.33 728306.96 48.915 471247.33 728306.96 40.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471243.42 728308.21 40.55 471241.92 728303.72 40.55 471241.92 728303.72 48.915 471243.42 728308.21 48.915 471243.42 728308.21 40.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2875-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471241.92 728303.72 48.915 471243.39 728303.2 48.915 471242.1 728299.3 48.915 471253.29 728295.3 48.915 471257.02 728305.47 48.915 471258.58 728304.9 48.915 471259.58 728307.67 48.915 471248.92 728311.44 48.915 471247.33 728306.96 48.915 471243.42 728308.21 48.915 471241.92 728303.72 48.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.9 728826.04 39.24 471414.59 728831.23 39.24 471419.59 728829.65 39.24 471421.07 728834.38 39.24 471428.82 728831.89 39.24 471425.62 728821.96 39.24 471417.76 728824.48 39.24 471416.96 728822 39.24 471414.3 728822.86 39.24 471415.09 728825.33 39.24 471412.9 728826.04 39.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.9 728826.04 39.24 471415.09 728825.33 39.24 471415.09 728825.33 43.08 471412.9 728826.04 43.08 471412.9 728826.04 39.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471415.09 728825.33 39.24 471414.3 728822.86 39.24 471414.3 728822.86 43.08 471415.09 728825.33 43.08 471415.09 728825.33 39.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471414.3 728822.86 39.24 471416.96 728822 39.24 471416.96 728822 43.08 471414.3 728822.86 43.08 471414.3 728822.86 39.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471416.96 728822 39.24 471417.76 728824.48 39.24 471417.76 728824.48 43.08 471416.96 728822 43.08 471416.96 728822 39.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471417.76 728824.48 39.24 471425.62 728821.96 39.24 471425.62 728821.96 43.08 471417.76 728824.48 43.08 471417.76 728824.48 39.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471425.62 728821.96 39.24 471428.82 728831.89 39.24 471428.82 728831.89 43.08 471425.62 728821.96 43.08 471425.62 728821.96 39.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471428.82 728831.89 39.24 471421.07 728834.38 39.24 471421.07 728834.38 43.08 471428.82 728831.89 43.08 471428.82 728831.89 39.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471421.07 728834.38 39.24 471419.59 728829.65 39.24 471419.59 728829.65 43.08 471421.07 728834.38 43.08 471421.07 728834.38 39.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471419.59 728829.65 39.24 471414.59 728831.23 39.24 471414.59 728831.23 43.08 471419.59 728829.65 43.08 471419.59 728829.65 39.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471414.59 728831.23 39.24 471412.9 728826.04 39.24 471412.9 728826.04 43.08 471414.59 728831.23 43.08 471414.59 728831.23 39.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D5-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.9 728826.04 43.08 471415.09 728825.33 43.08 471414.3 728822.86 43.08 471416.96 728822 43.08 471417.76 728824.48 43.08 471425.62 728821.96 43.08 471428.82 728831.89 43.08 471421.07 728834.38 43.08 471419.59 728829.65 43.08 471414.59 728831.23 43.08 471412.9 728826.04 43.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471278.59 728436.25 39.32 471282.04 728447.56 39.32 471288.64 728445.56 39.32 471287.97 728443.41 39.32 471292.79 728441.94 39.32 471292.27 728440.16 39.32 471294.09 728439.59 39.32 471290.45 728428.46 39.32 471281.74 728431.14 39.32 471282.78 728434.47 39.32 471282.56 728434.56 39.32 471282.7 728435 39.32 471278.59 728436.25 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471278.59 728436.25 39.32 471282.7 728435 39.32 471282.7 728435 47.64 471278.59 728436.25 47.64 471278.59 728436.25 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471282.7 728435 39.32 471282.56 728434.56 39.32 471282.56 728434.56 47.64 471282.7 728435 47.64 471282.7 728435 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471282.56 728434.56 39.32 471282.78 728434.47 39.32 471282.78 728434.47 47.64 471282.56 728434.56 47.64 471282.56 728434.56 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471282.78 728434.47 39.32 471281.74 728431.14 39.32 471281.74 728431.14 47.64 471282.78 728434.47 47.64 471282.78 728434.47 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471281.74 728431.14 39.32 471290.45 728428.46 39.32 471290.45 728428.46 47.64 471281.74 728431.14 47.64 471281.74 728431.14 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.45 728428.46 39.32 471294.09 728439.59 39.32 471294.09 728439.59 47.64 471290.45 728428.46 47.64 471290.45 728428.46 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471294.09 728439.59 39.32 471292.27 728440.16 39.32 471292.27 728440.16 47.64 471294.09 728439.59 47.64 471294.09 728439.59 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471292.27 728440.16 39.32 471292.79 728441.94 39.32 471292.79 728441.94 47.64 471292.27 728440.16 47.64 471292.27 728440.16 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471292.79 728441.94 39.32 471287.97 728443.41 39.32 471287.97 728443.41 47.64 471292.79 728441.94 47.64 471292.79 728441.94 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471287.97 728443.41 39.32 471288.64 728445.56 39.32 471288.64 728445.56 47.64 471287.97 728443.41 47.64 471287.97 728443.41 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471288.64 728445.56 39.32 471282.04 728447.56 39.32 471282.04 728447.56 47.64 471288.64 728445.56 47.64 471288.64 728445.56 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471282.04 728447.56 39.32 471278.59 728436.25 39.32 471278.59 728436.25 47.64 471282.04 728447.56 47.64 471282.04 728447.56 39.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D4-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471278.59 728436.25 47.64 471282.7 728435 47.64 471282.56 728434.56 47.64 471282.78 728434.47 47.64 471281.74 728431.14 47.64 471290.45 728428.46 47.64 471294.09 728439.59 47.64 471292.27 728440.16 47.64 471292.79 728441.94 47.64 471287.97 728443.41 47.64 471288.64 728445.56 47.64 471282.04 728447.56 47.64 471278.59 728436.25 47.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-45B7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-45B7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">33.92</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471333.58 728375.35 35.16 471334.03 728390.66 35.16 471347.74 728390.28 35.16 471347.82 728393.05 35.16 471350.85 728392.94 35.16 471350.74 728390.21 35.16 471361.68 728389.9 35.16 471361.2 728374.53 35.16 471333.58 728375.35 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471333.58 728375.35 35.16 471361.2 728374.53 35.16 471361.2 728374.53 69.08 471333.58 728375.35 69.08 471333.58 728375.35 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471361.2 728374.53 35.16 471361.68 728389.9 35.16 471361.68 728389.9 69.08 471361.2 728374.53 69.08 471361.2 728374.53 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471361.68 728389.9 35.16 471350.74 728390.21 35.16 471350.74 728390.21 69.08 471361.68 728389.9 69.08 471361.68 728389.9 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.74 728390.21 35.16 471350.85 728392.94 35.16 471350.85 728392.94 69.08 471350.74 728390.21 69.08 471350.74 728390.21 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.85 728392.94 35.16 471347.82 728393.05 35.16 471347.82 728393.05 69.08 471350.85 728392.94 69.08 471350.85 728392.94 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.82 728393.05 35.16 471347.74 728390.28 35.16 471347.74 728390.28 69.08 471347.82 728393.05 69.08 471347.82 728393.05 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.74 728390.28 35.16 471334.03 728390.66 35.16 471334.03 728390.66 69.08 471347.74 728390.28 69.08 471347.74 728390.28 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471334.03 728390.66 35.16 471333.58 728375.35 35.16 471333.58 728375.35 69.08 471334.03 728390.66 69.08 471334.03 728390.66 35.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471333.58 728375.35 69.08 471361.2 728374.53 69.08 471361.68 728389.9 69.08 471350.74 728390.21 69.08 471350.85 728392.94 69.08 471347.82 728393.05 69.08 471347.74 728390.28 69.08 471334.03 728390.66 69.08 471333.58 728375.35 69.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-286D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-286D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471204 728237.37 40.23 471205.92 728243.62 40.23 471205.48 728243.75 40.23 471206.45 728246.83 40.23 471214.81 728244.14 40.23 471211.91 728234.12 40.23 471207.29 728235.47 40.23 471207.54 728236.28 40.23 471204 728237.37 40.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471204 728237.37 40.23 471207.54 728236.28 40.23 471207.54 728236.28 47.660000000000004 471204 728237.37 47.660000000000004 471204 728237.37 40.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471207.54 728236.28 40.23 471207.29 728235.47 40.23 471207.29 728235.47 47.660000000000004 471207.54 728236.28 47.660000000000004 471207.54 728236.28 40.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471207.29 728235.47 40.23 471211.91 728234.12 40.23 471211.91 728234.12 47.660000000000004 471207.29 728235.47 47.660000000000004 471207.29 728235.47 40.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471211.91 728234.12 40.23 471214.81 728244.14 40.23 471214.81 728244.14 47.660000000000004 471211.91 728234.12 47.660000000000004 471211.91 728234.12 40.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471214.81 728244.14 40.23 471206.45 728246.83 40.23 471206.45 728246.83 47.660000000000004 471214.81 728244.14 47.660000000000004 471214.81 728244.14 40.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471206.45 728246.83 40.23 471205.48 728243.75 40.23 471205.48 728243.75 47.660000000000004 471206.45 728246.83 47.660000000000004 471206.45 728246.83 40.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471205.48 728243.75 40.23 471205.92 728243.62 40.23 471205.92 728243.62 47.660000000000004 471205.48 728243.75 47.660000000000004 471205.48 728243.75 40.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471205.92 728243.62 40.23 471204 728237.37 40.23 471204 728237.37 47.660000000000004 471205.92 728243.62 47.660000000000004 471205.92 728243.62 40.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286D-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471204 728237.37 47.660000000000004 471207.54 728236.28 47.660000000000004 471207.29 728235.47 47.660000000000004 471211.91 728234.12 47.660000000000004 471214.81 728244.14 47.660000000000004 471206.45 728246.83 47.660000000000004 471205.48 728243.75 47.660000000000004 471205.92 728243.62 47.660000000000004 471204 728237.37 47.660000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.16</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471286.95 728173.78 35.55 471288.13 728177.64 35.55 471287.73 728177.77 35.55 471290.53 728186.9 35.55 471291.07 728186.74 35.55 471292.65 728192.06 35.55 471302.88 728189.14 35.55 471300.49 728180.97 35.55 471298.74 728181.48 35.55 471295.5 728171.1 35.55 471286.95 728173.78 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471286.95 728173.78 35.55 471295.5 728171.1 35.55 471295.5 728171.1 43.71 471286.95 728173.78 43.71 471286.95 728173.78 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471295.5 728171.1 35.55 471298.74 728181.48 35.55 471298.74 728181.48 43.71 471295.5 728171.1 43.71 471295.5 728171.1 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471298.74 728181.48 35.55 471300.49 728180.97 35.55 471300.49 728180.97 43.71 471298.74 728181.48 43.71 471298.74 728181.48 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471300.49 728180.97 35.55 471302.88 728189.14 35.55 471302.88 728189.14 43.71 471300.49 728180.97 43.71 471300.49 728180.97 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471302.88 728189.14 35.55 471292.65 728192.06 35.55 471292.65 728192.06 43.71 471302.88 728189.14 43.71 471302.88 728189.14 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471292.65 728192.06 35.55 471291.07 728186.74 35.55 471291.07 728186.74 43.71 471292.65 728192.06 43.71 471292.65 728192.06 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471291.07 728186.74 35.55 471290.53 728186.9 35.55 471290.53 728186.9 43.71 471291.07 728186.74 43.71 471291.07 728186.74 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.53 728186.9 35.55 471287.73 728177.77 35.55 471287.73 728177.77 43.71 471290.53 728186.9 43.71 471290.53 728186.9 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471287.73 728177.77 35.55 471288.13 728177.64 35.55 471288.13 728177.64 43.71 471287.73 728177.77 43.71 471287.73 728177.77 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471288.13 728177.64 35.55 471286.95 728173.78 35.55 471286.95 728173.78 43.71 471288.13 728177.64 43.71 471288.13 728177.64 35.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C8-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471286.95 728173.78 43.71 471295.5 728171.1 43.71 471298.74 728181.48 43.71 471300.49 728180.97 43.71 471302.88 728189.14 43.71 471292.65 728192.06 43.71 471291.07 728186.74 43.71 471290.53 728186.9 43.71 471287.73 728177.77 43.71 471288.13 728177.64 43.71 471286.95 728173.78 43.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-286F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.3</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471231.55 728228.8 38.86 471233.56 728235.62 38.86 471236.65 728234.67 38.86 471237.4 728236.85 38.86 471239.2 728236.25 38.86 471239.31 728236.58 38.86 471245.77 728234.58 38.86 471242.85 728225.11 38.86 471238.19 728226.54 38.86 471238.28 728226.79 38.86 471231.55 728228.8 38.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471231.55 728228.8 38.86 471238.28 728226.79 38.86 471238.28 728226.79 47.160000000000004 471231.55 728228.8 47.160000000000004 471231.55 728228.8 38.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471238.28 728226.79 38.86 471238.19 728226.54 38.86 471238.19 728226.54 47.160000000000004 471238.28 728226.79 47.160000000000004 471238.28 728226.79 38.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471238.19 728226.54 38.86 471242.85 728225.11 38.86 471242.85 728225.11 47.160000000000004 471238.19 728226.54 47.160000000000004 471238.19 728226.54 38.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471242.85 728225.11 38.86 471245.77 728234.58 38.86 471245.77 728234.58 47.160000000000004 471242.85 728225.11 47.160000000000004 471242.85 728225.11 38.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471245.77 728234.58 38.86 471239.31 728236.58 38.86 471239.31 728236.58 47.160000000000004 471245.77 728234.58 47.160000000000004 471245.77 728234.58 38.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471239.31 728236.58 38.86 471239.2 728236.25 38.86 471239.2 728236.25 47.160000000000004 471239.31 728236.58 47.160000000000004 471239.31 728236.58 38.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471239.2 728236.25 38.86 471237.4 728236.85 38.86 471237.4 728236.85 47.160000000000004 471239.2 728236.25 47.160000000000004 471239.2 728236.25 38.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471237.4 728236.85 38.86 471236.65 728234.67 38.86 471236.65 728234.67 47.160000000000004 471237.4 728236.85 47.160000000000004 471237.4 728236.85 38.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471236.65 728234.67 38.86 471233.56 728235.62 38.86 471233.56 728235.62 47.160000000000004 471236.65 728234.67 47.160000000000004 471236.65 728234.67 38.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471233.56 728235.62 38.86 471231.55 728228.8 38.86 471231.55 728228.8 47.160000000000004 471233.56 728235.62 47.160000000000004 471233.56 728235.62 38.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286F-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471231.55 728228.8 47.160000000000004 471238.28 728226.79 47.160000000000004 471238.19 728226.54 47.160000000000004 471242.85 728225.11 47.160000000000004 471245.77 728234.58 47.160000000000004 471239.31 728236.58 47.160000000000004 471239.2 728236.25 47.160000000000004 471237.4 728236.85 47.160000000000004 471236.65 728234.67 47.160000000000004 471233.56 728235.62 47.160000000000004 471231.55 728228.8 47.160000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-291D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.64</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471261.03 728339.28 40.21 471263.71 728348.53 40.21 471265.4 728348.03 40.21 471266.58 728352.01 40.21 471267.89 728351.61 40.21 471267.81 728351.34 40.21 471268.37 728351.16 40.21 471268.45 728351.46 40.21 471272.26 728350.33 40.21 471272.17 728350.03 40.21 471268.41 728337.13 40.21 471268.31 728336.79 40.21 471264.35 728337.96 40.21 471264.43 728338.29 40.21 471261.03 728339.28 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471261.03 728339.28 40.21 471264.43 728338.29 40.21 471264.43 728338.29 49.85 471261.03 728339.28 49.85 471261.03 728339.28 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471264.43 728338.29 40.21 471264.35 728337.96 40.21 471264.35 728337.96 49.85 471264.43 728338.29 49.85 471264.43 728338.29 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471264.35 728337.96 40.21 471268.31 728336.79 40.21 471268.31 728336.79 49.85 471264.35 728337.96 49.85 471264.35 728337.96 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471268.31 728336.79 40.21 471268.41 728337.13 40.21 471268.41 728337.13 49.85 471268.31 728336.79 49.85 471268.31 728336.79 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471268.41 728337.13 40.21 471272.17 728350.03 40.21 471272.17 728350.03 49.85 471268.41 728337.13 49.85 471268.41 728337.13 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471272.17 728350.03 40.21 471272.26 728350.33 40.21 471272.26 728350.33 49.85 471272.17 728350.03 49.85 471272.17 728350.03 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471272.26 728350.33 40.21 471268.45 728351.46 40.21 471268.45 728351.46 49.85 471272.26 728350.33 49.85 471272.26 728350.33 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471268.45 728351.46 40.21 471268.37 728351.16 40.21 471268.37 728351.16 49.85 471268.45 728351.46 49.85 471268.45 728351.46 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471268.37 728351.16 40.21 471267.81 728351.34 40.21 471267.81 728351.34 49.85 471268.37 728351.16 49.85 471268.37 728351.16 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471267.81 728351.34 40.21 471267.89 728351.61 40.21 471267.89 728351.61 49.85 471267.81 728351.34 49.85 471267.81 728351.34 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471267.89 728351.61 40.21 471266.58 728352.01 40.21 471266.58 728352.01 49.85 471267.89 728351.61 49.85 471267.89 728351.61 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471266.58 728352.01 40.21 471265.4 728348.03 40.21 471265.4 728348.03 49.85 471266.58 728352.01 49.85 471266.58 728352.01 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471265.4 728348.03 40.21 471263.71 728348.53 40.21 471263.71 728348.53 49.85 471265.4 728348.03 49.85 471265.4 728348.03 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471263.71 728348.53 40.21 471261.03 728339.28 40.21 471261.03 728339.28 49.85 471263.71 728348.53 49.85 471263.71 728348.53 40.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291D-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471261.03 728339.28 49.85 471264.43 728338.29 49.85 471264.35 728337.96 49.85 471268.31 728336.79 49.85 471268.41 728337.13 49.85 471272.17 728350.03 49.85 471272.26 728350.33 49.85 471268.45 728351.46 49.85 471268.37 728351.16 49.85 471267.81 728351.34 49.85 471267.89 728351.61 49.85 471266.58 728352.01 49.85 471265.4 728348.03 49.85 471263.71 728348.53 49.85 471261.03 728339.28 49.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-291C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-291C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471255.31 728314.39 40.93 471259.93 728327.11 40.93 471270.69 728323.19 40.93 471269.48 728320.11 40.93 471267.9 728320.59 40.93 471264.33 728311.08 40.93 471255.31 728314.39 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471255.31 728314.39 40.93 471264.33 728311.08 40.93 471264.33 728311.08 49.765 471255.31 728314.39 49.765 471255.31 728314.39 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471264.33 728311.08 40.93 471267.9 728320.59 40.93 471267.9 728320.59 49.765 471264.33 728311.08 49.765 471264.33 728311.08 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471267.9 728320.59 40.93 471269.48 728320.11 40.93 471269.48 728320.11 49.765 471267.9 728320.59 49.765 471267.9 728320.59 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471269.48 728320.11 40.93 471270.69 728323.19 40.93 471270.69 728323.19 49.765 471269.48 728320.11 49.765 471269.48 728320.11 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471270.69 728323.19 40.93 471259.93 728327.11 40.93 471259.93 728327.11 49.765 471270.69 728323.19 49.765 471270.69 728323.19 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471259.93 728327.11 40.93 471255.31 728314.39 40.93 471255.31 728314.39 49.765 471259.93 728327.11 49.765 471259.93 728327.11 40.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471255.31 728314.39 49.765 471264.33 728311.08 49.765 471267.9 728320.59 49.765 471269.48 728320.11 49.765 471270.69 728323.19 49.765 471259.93 728327.11 49.765 471255.31 728314.39 49.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-291B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-291B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.96</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.74 728257.49 35.12 471341.25 728266.09 35.12 471344.98 728265 35.12 471345.12 728265.42 35.12 471347.98 728264.57 35.12 471345.32 728255.54 35.12 471338.74 728257.49 35.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.74 728257.49 35.12 471345.32 728255.54 35.12 471345.32 728255.54 42.08 471338.74 728257.49 42.08 471338.74 728257.49 35.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.32 728255.54 35.12 471347.98 728264.57 35.12 471347.98 728264.57 42.08 471345.32 728255.54 42.08 471345.32 728255.54 35.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.98 728264.57 35.12 471345.12 728265.42 35.12 471345.12 728265.42 42.08 471347.98 728264.57 42.08 471347.98 728264.57 35.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.12 728265.42 35.12 471344.98 728265 35.12 471344.98 728265 42.08 471345.12 728265.42 42.08 471345.12 728265.42 35.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471344.98 728265 35.12 471341.25 728266.09 35.12 471341.25 728266.09 42.08 471344.98 728265 42.08 471344.98 728265 35.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471341.25 728266.09 35.12 471338.74 728257.49 35.12 471338.74 728257.49 42.08 471341.25 728266.09 42.08 471341.25 728266.09 35.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291B-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.74 728257.49 42.08 471345.32 728255.54 42.08 471347.98 728264.57 42.08 471345.12 728265.42 42.08 471344.98 728265 42.08 471341.25 728266.09 42.08 471338.74 728257.49 42.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-291A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-291A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.45</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.32 728255.54 34.63 471347.98 728264.57 34.63 471350.85 728263.72 34.63 471350.73 728263.31 34.63 471354.47 728262.2 34.63 471351.94 728253.6 34.63 471345.32 728255.54 34.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.32 728255.54 34.63 471351.94 728253.6 34.63 471351.94 728253.6 42.08 471345.32 728255.54 42.08 471345.32 728255.54 34.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471351.94 728253.6 34.63 471354.47 728262.2 34.63 471354.47 728262.2 42.08 471351.94 728253.6 42.08 471351.94 728253.6 34.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.47 728262.2 34.63 471350.73 728263.31 34.63 471350.73 728263.31 42.08 471354.47 728262.2 42.08 471354.47 728262.2 34.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.73 728263.31 34.63 471350.85 728263.72 34.63 471350.85 728263.72 42.08 471350.73 728263.31 42.08 471350.73 728263.31 34.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.85 728263.72 34.63 471347.98 728264.57 34.63 471347.98 728264.57 42.08 471350.85 728263.72 42.08 471350.85 728263.72 34.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.98 728264.57 34.63 471345.32 728255.54 34.63 471345.32 728255.54 42.08 471347.98 728264.57 42.08 471347.98 728264.57 34.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.32 728255.54 42.08 471351.94 728253.6 42.08 471354.47 728262.2 42.08 471350.73 728263.31 42.08 471350.85 728263.72 42.08 471347.98 728264.57 42.08 471345.32 728255.54 42.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-286C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.66</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471192.75 728175.28 43.39 471194 728178.79 43.39 471193.39 728179.02 43.39 471196.3 728188.38 43.39 471204.79 728185.73 43.39 471204.27 728184.28 43.39 471203.23 728184.65 43.39 471202.83 728183.52 43.39 471204.47 728182.93 43.39 471202.54 728176.62 43.39 471205.93 728175.56 43.39 471204.3 728170.35 43.39 471199.25 728171.94 43.39 471199.58 728173.18 43.39 471192.75 728175.28 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471192.75 728175.28 43.39 471199.58 728173.18 43.39 471199.58 728173.18 52.050000000000004 471192.75 728175.28 52.050000000000004 471192.75 728175.28 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471199.58 728173.18 43.39 471199.25 728171.94 43.39 471199.25 728171.94 52.050000000000004 471199.58 728173.18 52.050000000000004 471199.58 728173.18 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471199.25 728171.94 43.39 471204.3 728170.35 43.39 471204.3 728170.35 52.050000000000004 471199.25 728171.94 52.050000000000004 471199.25 728171.94 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471204.3 728170.35 43.39 471205.93 728175.56 43.39 471205.93 728175.56 52.050000000000004 471204.3 728170.35 52.050000000000004 471204.3 728170.35 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471205.93 728175.56 43.39 471202.54 728176.62 43.39 471202.54 728176.62 52.050000000000004 471205.93 728175.56 52.050000000000004 471205.93 728175.56 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471202.54 728176.62 43.39 471204.47 728182.93 43.39 471204.47 728182.93 52.050000000000004 471202.54 728176.62 52.050000000000004 471202.54 728176.62 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471204.47 728182.93 43.39 471202.83 728183.52 43.39 471202.83 728183.52 52.050000000000004 471204.47 728182.93 52.050000000000004 471204.47 728182.93 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471202.83 728183.52 43.39 471203.23 728184.65 43.39 471203.23 728184.65 52.050000000000004 471202.83 728183.52 52.050000000000004 471202.83 728183.52 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471203.23 728184.65 43.39 471204.27 728184.28 43.39 471204.27 728184.28 52.050000000000004 471203.23 728184.65 52.050000000000004 471203.23 728184.65 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471204.27 728184.28 43.39 471204.79 728185.73 43.39 471204.79 728185.73 52.050000000000004 471204.27 728184.28 52.050000000000004 471204.27 728184.28 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471204.79 728185.73 43.39 471196.3 728188.38 43.39 471196.3 728188.38 52.050000000000004 471204.79 728185.73 52.050000000000004 471204.79 728185.73 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471196.3 728188.38 43.39 471193.39 728179.02 43.39 471193.39 728179.02 52.050000000000004 471196.3 728188.38 52.050000000000004 471196.3 728188.38 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471193.39 728179.02 43.39 471194 728178.79 43.39 471194 728178.79 52.050000000000004 471193.39 728179.02 52.050000000000004 471193.39 728179.02 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471194 728178.79 43.39 471192.75 728175.28 43.39 471192.75 728175.28 52.050000000000004 471194 728178.79 52.050000000000004 471194 728178.79 43.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286C-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471192.75 728175.28 52.050000000000004 471199.58 728173.18 52.050000000000004 471199.25 728171.94 52.050000000000004 471204.3 728170.35 52.050000000000004 471205.93 728175.56 52.050000000000004 471202.54 728176.62 52.050000000000004 471204.47 728182.93 52.050000000000004 471202.83 728183.52 52.050000000000004 471203.23 728184.65 52.050000000000004 471204.27 728184.28 52.050000000000004 471204.79 728185.73 52.050000000000004 471196.3 728188.38 52.050000000000004 471193.39 728179.02 52.050000000000004 471194 728178.79 52.050000000000004 471192.75 728175.28 52.050000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-286B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.5</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471286.91 728335.23 37.76 471289.99 728344.38 37.76 471301 728340.91 37.76 471300.1 728338.18 37.76 471301.82 728337.6 37.76 471299.74 728331.06 37.76 471296.16 728332.22 37.76 471296.04 728331.87 37.76 471290.7 728333.53 37.76 471290.83 728333.95 37.76 471286.91 728335.23 37.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471286.91 728335.23 37.76 471290.83 728333.95 37.76 471290.83 728333.95 46.26 471286.91 728335.23 46.26 471286.91 728335.23 37.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.83 728333.95 37.76 471290.7 728333.53 37.76 471290.7 728333.53 46.26 471290.83 728333.95 46.26 471290.83 728333.95 37.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.7 728333.53 37.76 471296.04 728331.87 37.76 471296.04 728331.87 46.26 471290.7 728333.53 46.26 471290.7 728333.53 37.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471296.04 728331.87 37.76 471296.16 728332.22 37.76 471296.16 728332.22 46.26 471296.04 728331.87 46.26 471296.04 728331.87 37.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471296.16 728332.22 37.76 471299.74 728331.06 37.76 471299.74 728331.06 46.26 471296.16 728332.22 46.26 471296.16 728332.22 37.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471299.74 728331.06 37.76 471301.82 728337.6 37.76 471301.82 728337.6 46.26 471299.74 728331.06 46.26 471299.74 728331.06 37.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471301.82 728337.6 37.76 471300.1 728338.18 37.76 471300.1 728338.18 46.26 471301.82 728337.6 46.26 471301.82 728337.6 37.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471300.1 728338.18 37.76 471301 728340.91 37.76 471301 728340.91 46.26 471300.1 728338.18 46.26 471300.1 728338.18 37.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471301 728340.91 37.76 471289.99 728344.38 37.76 471289.99 728344.38 46.26 471301 728340.91 46.26 471301 728340.91 37.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471289.99 728344.38 37.76 471286.91 728335.23 37.76 471286.91 728335.23 46.26 471289.99 728344.38 46.26 471289.99 728344.38 37.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286B-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471286.91 728335.23 46.26 471290.83 728333.95 46.26 471290.7 728333.53 46.26 471296.04 728331.87 46.26 471296.16 728332.22 46.26 471299.74 728331.06 46.26 471301.82 728337.6 46.26 471300.1 728338.18 46.26 471301 728340.91 46.26 471289.99 728344.38 46.26 471286.91 728335.23 46.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.86</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471324.69 728348.76 35.11 471327.53 728357.83 35.11 471338.48 728354.35 35.11 471337.63 728351.64 35.11 471339.3 728351.13 35.11 471337.25 728344.75 35.11 471333.74 728345.88 35.11 471333.6 728345.58 35.11 471328.48 728347.18 35.11 471328.61 728347.56 35.11 471324.69 728348.76 35.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471324.69 728348.76 35.11 471328.61 728347.56 35.11 471328.61 728347.56 43.97 471324.69 728348.76 43.97 471324.69 728348.76 35.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.61 728347.56 35.11 471328.48 728347.18 35.11 471328.48 728347.18 43.97 471328.61 728347.56 43.97 471328.61 728347.56 35.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.48 728347.18 35.11 471333.6 728345.58 35.11 471333.6 728345.58 43.97 471328.48 728347.18 43.97 471328.48 728347.18 35.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471333.6 728345.58 35.11 471333.74 728345.88 35.11 471333.74 728345.88 43.97 471333.6 728345.58 43.97 471333.6 728345.58 35.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471333.74 728345.88 35.11 471337.25 728344.75 35.11 471337.25 728344.75 43.97 471333.74 728345.88 43.97 471333.74 728345.88 35.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.25 728344.75 35.11 471339.3 728351.13 35.11 471339.3 728351.13 43.97 471337.25 728344.75 43.97 471337.25 728344.75 35.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.3 728351.13 35.11 471337.63 728351.64 35.11 471337.63 728351.64 43.97 471339.3 728351.13 43.97 471339.3 728351.13 35.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471337.63 728351.64 35.11 471338.48 728354.35 35.11 471338.48 728354.35 43.97 471337.63 728351.64 43.97 471337.63 728351.64 35.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471338.48 728354.35 35.11 471327.53 728357.83 35.11 471327.53 728357.83 43.97 471338.48 728354.35 43.97 471338.48 728354.35 35.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.53 728357.83 35.11 471324.69 728348.76 35.11 471324.69 728348.76 43.97 471327.53 728357.83 43.97 471327.53 728357.83 35.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CC-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471324.69 728348.76 43.97 471328.61 728347.56 43.97 471328.48 728347.18 43.97 471333.6 728345.58 43.97 471333.74 728345.88 43.97 471337.25 728344.75 43.97 471339.3 728351.13 43.97 471337.63 728351.64 43.97 471338.48 728354.35 43.97 471327.53 728357.83 43.97 471324.69 728348.76 43.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.98</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311 728367.68 36.69 471321.41 728364.44 36.69 471318.62 728355.34 36.69 471317.21 728355.79 36.69 471315.71 728351.46 36.69 471312.2 728352.55 36.69 471311.21 728349.01 36.69 471306.02 728350.59 36.69 471307.15 728354.13 36.69 471306.76 728354.24 36.69 471311 728367.68 36.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311 728367.68 36.69 471306.76 728354.24 36.69 471306.76 728354.24 45.67 471311 728367.68 45.67 471311 728367.68 36.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471306.76 728354.24 36.69 471307.15 728354.13 36.69 471307.15 728354.13 45.67 471306.76 728354.24 45.67 471306.76 728354.24 36.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471307.15 728354.13 36.69 471306.02 728350.59 36.69 471306.02 728350.59 45.67 471307.15 728354.13 45.67 471307.15 728354.13 36.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471306.02 728350.59 36.69 471311.21 728349.01 36.69 471311.21 728349.01 45.67 471306.02 728350.59 45.67 471306.02 728350.59 36.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311.21 728349.01 36.69 471312.2 728352.55 36.69 471312.2 728352.55 45.67 471311.21 728349.01 45.67 471311.21 728349.01 36.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.2 728352.55 36.69 471315.71 728351.46 36.69 471315.71 728351.46 45.67 471312.2 728352.55 45.67 471312.2 728352.55 36.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471315.71 728351.46 36.69 471317.21 728355.79 36.69 471317.21 728355.79 45.67 471315.71 728351.46 45.67 471315.71 728351.46 36.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.21 728355.79 36.69 471318.62 728355.34 36.69 471318.62 728355.34 45.67 471317.21 728355.79 45.67 471317.21 728355.79 36.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.62 728355.34 36.69 471321.41 728364.44 36.69 471321.41 728364.44 45.67 471318.62 728355.34 45.67 471318.62 728355.34 36.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471321.41 728364.44 36.69 471311 728367.68 36.69 471311 728367.68 45.67 471321.41 728364.44 45.67 471321.41 728364.44 36.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CB-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471311 728367.68 45.67 471306.76 728354.24 45.67 471307.15 728354.13 45.67 471306.02 728350.59 45.67 471311.21 728349.01 45.67 471312.2 728352.55 45.67 471315.71 728351.46 45.67 471317.21 728355.79 45.67 471318.62 728355.34 45.67 471321.41 728364.44 45.67 471311 728367.68 45.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.85</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.12 728266.34 31.89 471389.85 728280.6 31.89 471386.75 728281.64 31.89 471387.8 728284.78 31.89 471402.77 728279.73 31.89 471401.76 728276.69 31.89 471398.3 728277.86 31.89 471393.48 728263.51 31.89 471391.61 728264.14 31.89 471390.95 728262.31 31.89 471387.39 728263.49 31.89 471388.02 728265.37 31.89 471385.12 728266.34 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.12 728266.34 31.89 471388.02 728265.37 31.89 471388.02 728265.37 36.74 471385.12 728266.34 36.74 471385.12 728266.34 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471388.02 728265.37 31.89 471387.39 728263.49 31.89 471387.39 728263.49 36.74 471388.02 728265.37 36.74 471388.02 728265.37 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.39 728263.49 31.89 471390.95 728262.31 31.89 471390.95 728262.31 36.74 471387.39 728263.49 36.74 471387.39 728263.49 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.95 728262.31 31.89 471391.61 728264.14 31.89 471391.61 728264.14 36.74 471390.95 728262.31 36.74 471390.95 728262.31 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471391.61 728264.14 31.89 471393.48 728263.51 31.89 471393.48 728263.51 36.74 471391.61 728264.14 36.74 471391.61 728264.14 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.48 728263.51 31.89 471398.3 728277.86 31.89 471398.3 728277.86 36.74 471393.48 728263.51 36.74 471393.48 728263.51 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471398.3 728277.86 31.89 471401.76 728276.69 31.89 471401.76 728276.69 36.74 471398.3 728277.86 36.74 471398.3 728277.86 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471401.76 728276.69 31.89 471402.77 728279.73 31.89 471402.77 728279.73 36.74 471401.76 728276.69 36.74 471401.76 728276.69 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471402.77 728279.73 31.89 471387.8 728284.78 31.89 471387.8 728284.78 36.74 471402.77 728279.73 36.74 471402.77 728279.73 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.8 728284.78 31.89 471386.75 728281.64 31.89 471386.75 728281.64 36.74 471387.8 728284.78 36.74 471387.8 728284.78 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471386.75 728281.64 31.89 471389.85 728280.6 31.89 471389.85 728280.6 36.74 471386.75 728281.64 36.74 471386.75 728281.64 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471389.85 728280.6 31.89 471385.12 728266.34 31.89 471385.12 728266.34 36.74 471389.85 728280.6 36.74 471389.85 728280.6 31.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CA-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.12 728266.34 36.74 471388.02 728265.37 36.74 471387.39 728263.49 36.74 471390.95 728262.31 36.74 471391.61 728264.14 36.74 471393.48 728263.51 36.74 471398.3 728277.86 36.74 471401.76 728276.69 36.74 471402.77 728279.73 36.74 471387.8 728284.78 36.74 471386.75 728281.64 36.74 471389.85 728280.6 36.74 471385.12 728266.34 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-29D1-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-29D1-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.75</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D1-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471286.29 728475.56 38.56 471289.85 728487.19 38.56 471298.2 728484.64 38.56 471297.91 728483.77 38.56 471295.04 728474.73 38.56 471294.51 728473.06 38.56 471286.29 728475.56 38.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D1-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471286.29 728475.56 38.56 471294.51 728473.06 38.56 471294.51 728473.06 45.31 471286.29 728475.56 45.31 471286.29 728475.56 38.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D1-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471294.51 728473.06 38.56 471295.04 728474.73 38.56 471295.04 728474.73 45.31 471294.51 728473.06 45.31 471294.51 728473.06 38.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D1-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471295.04 728474.73 38.56 471297.91 728483.77 38.56 471297.91 728483.77 45.31 471295.04 728474.73 45.31 471295.04 728474.73 38.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D1-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471297.91 728483.77 38.56 471298.2 728484.64 38.56 471298.2 728484.64 45.31 471297.91 728483.77 45.31 471297.91 728483.77 38.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D1-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471298.2 728484.64 38.56 471289.85 728487.19 38.56 471289.85 728487.19 45.31 471298.2 728484.64 45.31 471298.2 728484.64 38.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D1-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471289.85 728487.19 38.56 471286.29 728475.56 38.56 471286.29 728475.56 45.31 471289.85 728487.19 45.31 471289.85 728487.19 38.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D1-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471286.29 728475.56 45.31 471294.51 728473.06 45.31 471295.04 728474.73 45.31 471297.91 728483.77 45.31 471298.2 728484.64 45.31 471289.85 728487.19 45.31 471286.29 728475.56 45.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.39</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.43 728458.3 37.39 471315.73 728462.2 37.39 471315.84 728462.17 37.39 471316.59 728464.44 37.39 471317.99 728463.97 37.39 471318.74 728466.56 37.39 471318.37 728466.69 37.39 471321.39 728475.94 37.39 471328.98 728473.5 37.39 471328.16 728470.89 37.39 471329.85 728470.26 37.39 471327.13 728461.86 37.39 471328.22 728461.49 37.39 471327.42 728459.05 37.39 471326.32 728459.41 37.39 471325.41 728456.62 37.39 471321.71 728457.85 37.39 471321.09 728456.03 37.39 471314.43 728458.3 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.43 728458.3 37.39 471321.09 728456.03 37.39 471321.09 728456.03 43.78 471314.43 728458.3 43.78 471314.43 728458.3 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471321.09 728456.03 37.39 471321.71 728457.85 37.39 471321.71 728457.85 43.78 471321.09 728456.03 43.78 471321.09 728456.03 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471321.71 728457.85 37.39 471325.41 728456.62 37.39 471325.41 728456.62 43.78 471321.71 728457.85 43.78 471321.71 728457.85 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471325.41 728456.62 37.39 471326.32 728459.41 37.39 471326.32 728459.41 43.78 471325.41 728456.62 43.78 471325.41 728456.62 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471326.32 728459.41 37.39 471327.42 728459.05 37.39 471327.42 728459.05 43.78 471326.32 728459.41 43.78 471326.32 728459.41 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.42 728459.05 37.39 471328.22 728461.49 37.39 471328.22 728461.49 43.78 471327.42 728459.05 43.78 471327.42 728459.05 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.22 728461.49 37.39 471327.13 728461.86 37.39 471327.13 728461.86 43.78 471328.22 728461.49 43.78 471328.22 728461.49 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.13 728461.86 37.39 471329.85 728470.26 37.39 471329.85 728470.26 43.78 471327.13 728461.86 43.78 471327.13 728461.86 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.85 728470.26 37.39 471328.16 728470.89 37.39 471328.16 728470.89 43.78 471329.85 728470.26 43.78 471329.85 728470.26 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.16 728470.89 37.39 471328.98 728473.5 37.39 471328.98 728473.5 43.78 471328.16 728470.89 43.78 471328.16 728470.89 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.98 728473.5 37.39 471321.39 728475.94 37.39 471321.39 728475.94 43.78 471328.98 728473.5 43.78 471328.98 728473.5 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471321.39 728475.94 37.39 471318.37 728466.69 37.39 471318.37 728466.69 43.78 471321.39 728475.94 43.78 471321.39 728475.94 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.37 728466.69 37.39 471318.74 728466.56 37.39 471318.74 728466.56 43.78 471318.37 728466.69 43.78 471318.37 728466.69 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.74 728466.56 37.39 471317.99 728463.97 37.39 471317.99 728463.97 43.78 471318.74 728466.56 43.78 471318.74 728466.56 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471317.99 728463.97 37.39 471316.59 728464.44 37.39 471316.59 728464.44 43.78 471317.99 728463.97 43.78 471317.99 728463.97 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471316.59 728464.44 37.39 471315.84 728462.17 37.39 471315.84 728462.17 43.78 471316.59 728464.44 43.78 471316.59 728464.44 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471315.84 728462.17 37.39 471315.73 728462.2 37.39 471315.73 728462.2 43.78 471315.84 728462.17 43.78 471315.84 728462.17 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471315.73 728462.2 37.39 471314.43 728458.3 37.39 471314.43 728458.3 43.78 471315.73 728462.2 43.78 471315.73 728462.2 37.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D2-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.43 728458.3 43.78 471321.09 728456.03 43.78 471321.71 728457.85 43.78 471325.41 728456.62 43.78 471326.32 728459.41 43.78 471327.42 728459.05 43.78 471328.22 728461.49 43.78 471327.13 728461.86 43.78 471329.85 728470.26 43.78 471328.16 728470.89 43.78 471328.98 728473.5 43.78 471321.39 728475.94 43.78 471318.37 728466.69 43.78 471318.74 728466.56 43.78 471317.99 728463.97 43.78 471316.59 728464.44 43.78 471315.84 728462.17 43.78 471315.73 728462.2 43.78 471314.43 728458.3 43.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">11.42</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471322.26 728425.82 35.77 471325.19 728435.03 35.77 471335.88 728431.62 35.77 471335.11 728429.24 35.77 471336.71 728428.66 35.77 471334.59 728421.76 35.77 471331.05 728422.97 35.77 471330.93 728422.55 35.77 471325.71 728424.25 35.77 471325.86 728424.65 35.77 471322.26 728425.82 35.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471322.26 728425.82 35.77 471325.86 728424.65 35.77 471325.86 728424.65 47.19 471322.26 728425.82 47.19 471322.26 728425.82 35.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471325.86 728424.65 35.77 471325.71 728424.25 35.77 471325.71 728424.25 47.19 471325.86 728424.65 47.19 471325.86 728424.65 35.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471325.71 728424.25 35.77 471330.93 728422.55 35.77 471330.93 728422.55 47.19 471325.71 728424.25 47.19 471325.71 728424.25 35.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.93 728422.55 35.77 471331.05 728422.97 35.77 471331.05 728422.97 47.19 471330.93 728422.55 47.19 471330.93 728422.55 35.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471331.05 728422.97 35.77 471334.59 728421.76 35.77 471334.59 728421.76 47.19 471331.05 728422.97 47.19 471331.05 728422.97 35.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471334.59 728421.76 35.77 471336.71 728428.66 35.77 471336.71 728428.66 47.19 471334.59 728421.76 47.19 471334.59 728421.76 35.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471336.71 728428.66 35.77 471335.11 728429.24 35.77 471335.11 728429.24 47.19 471336.71 728428.66 47.19 471336.71 728428.66 35.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471335.11 728429.24 35.77 471335.88 728431.62 35.77 471335.88 728431.62 47.19 471335.11 728429.24 47.19 471335.11 728429.24 35.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471335.88 728431.62 35.77 471325.19 728435.03 35.77 471325.19 728435.03 47.19 471335.88 728431.62 47.19 471335.88 728431.62 35.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471325.19 728435.03 35.77 471322.26 728425.82 35.77 471322.26 728425.82 47.19 471325.19 728435.03 47.19 471325.19 728435.03 35.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29D0-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471322.26 728425.82 47.19 471325.86 728424.65 47.19 471325.71 728424.25 47.19 471330.93 728422.55 47.19 471331.05 728422.97 47.19 471334.59 728421.76 47.19 471336.71 728428.66 47.19 471335.11 728429.24 47.19 471335.88 728431.62 47.19 471325.19 728435.03 47.19 471322.26 728425.82 47.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-27C7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-27C7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.68</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471276.33 728229.01 37.35 471287.15 728225.59 37.35 471277.83 728196.41 37.35 471266.99 728199.66 37.35 471276.33 728229.01 37.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471276.33 728229.01 37.35 471266.99 728199.66 37.35 471266.99 728199.66 47.03 471276.33 728229.01 47.03 471276.33 728229.01 37.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471266.99 728199.66 37.35 471277.83 728196.41 37.35 471277.83 728196.41 47.03 471266.99 728199.66 47.03 471266.99 728199.66 37.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471277.83 728196.41 37.35 471287.15 728225.59 37.35 471287.15 728225.59 47.03 471277.83 728196.41 47.03 471277.83 728196.41 37.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471287.15 728225.59 37.35 471276.33 728229.01 37.35 471276.33 728229.01 47.03 471287.15 728225.59 47.03 471287.15 728225.59 37.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471276.33 728229.01 47.03 471266.99 728199.66 47.03 471277.83 728196.41 47.03 471287.15 728225.59 47.03 471276.33 728229.01 47.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.06</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.76 728313.88 33.94 471343.6 728316.35 33.94 471343.71 728316.32 33.94 471345.68 728323.24 33.94 471349.22 728322.13 33.94 471350.06 728324.81 33.94 471357.4 728322.46 33.94 471356.53 728319.77 33.94 471358.22 728319.21 33.94 471356 728312.42 33.94 471352.89 728313.45 33.94 471352.76 728313.06 33.94 471347.8 728314.61 33.94 471347.15 728312.51 33.94 471342.76 728313.88 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.76 728313.88 33.94 471347.15 728312.51 33.94 471347.15 728312.51 43 471342.76 728313.88 43 471342.76 728313.88 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.15 728312.51 33.94 471347.8 728314.61 33.94 471347.8 728314.61 43 471347.15 728312.51 43 471347.15 728312.51 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.8 728314.61 33.94 471352.76 728313.06 33.94 471352.76 728313.06 43 471347.8 728314.61 43 471347.8 728314.61 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471352.76 728313.06 33.94 471352.89 728313.45 33.94 471352.89 728313.45 43 471352.76 728313.06 43 471352.76 728313.06 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471352.89 728313.45 33.94 471356 728312.42 33.94 471356 728312.42 43 471352.89 728313.45 43 471352.89 728313.45 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471356 728312.42 33.94 471358.22 728319.21 33.94 471358.22 728319.21 43 471356 728312.42 43 471356 728312.42 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471358.22 728319.21 33.94 471356.53 728319.77 33.94 471356.53 728319.77 43 471358.22 728319.21 43 471358.22 728319.21 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471356.53 728319.77 33.94 471357.4 728322.46 33.94 471357.4 728322.46 43 471356.53 728319.77 43 471356.53 728319.77 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471357.4 728322.46 33.94 471350.06 728324.81 33.94 471350.06 728324.81 43 471357.4 728322.46 43 471357.4 728322.46 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471350.06 728324.81 33.94 471349.22 728322.13 33.94 471349.22 728322.13 43 471350.06 728324.81 43 471350.06 728324.81 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471349.22 728322.13 33.94 471345.68 728323.24 33.94 471345.68 728323.24 43 471349.22 728322.13 43 471349.22 728322.13 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471345.68 728323.24 33.94 471343.71 728316.32 33.94 471343.71 728316.32 43 471345.68 728323.24 43 471345.68 728323.24 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471343.71 728316.32 33.94 471343.6 728316.35 33.94 471343.6 728316.35 43 471343.71 728316.32 43 471343.71 728316.32 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471343.6 728316.35 33.94 471342.76 728313.88 33.94 471342.76 728313.88 43 471343.6 728316.35 43 471343.6 728316.35 33.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C5-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471342.76 728313.88 43 471347.15 728312.51 43 471347.8 728314.61 43 471352.76 728313.06 43 471352.89 728313.45 43 471356 728312.42 43 471358.22 728319.21 43 471356.53 728319.77 43 471357.4 728322.46 43 471350.06 728324.81 43 471349.22 728322.13 43 471345.68 728323.24 43 471343.71 728316.32 43 471343.6 728316.35 43 471342.76 728313.88 43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-27C6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-27C6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471331.2 728299.55 35.22 471339.24 728297.16 35.22 471335.13 728283.55 35.22 471327.09 728285.94 35.22 471331.2 728299.55 35.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471331.2 728299.55 35.22 471327.09 728285.94 35.22 471327.09 728285.94 43.21 471331.2 728299.55 43.21 471331.2 728299.55 35.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.09 728285.94 35.22 471335.13 728283.55 35.22 471335.13 728283.55 43.21 471327.09 728285.94 43.21 471327.09 728285.94 35.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471335.13 728283.55 35.22 471339.24 728297.16 35.22 471339.24 728297.16 43.21 471335.13 728283.55 43.21 471335.13 728283.55 35.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471339.24 728297.16 35.22 471331.2 728299.55 35.22 471331.2 728299.55 43.21 471339.24 728297.16 43.21 471339.24 728297.16 35.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-27C6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471331.2 728299.55 43.21 471327.09 728285.94 43.21 471335.13 728283.55 43.21 471339.24 728297.16 43.21 471331.2 728299.55 43.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.48</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.19 728252.59 31.5 471366.63 728259.39 31.5 471384.2 728254.18 31.5 471388.72 728252.84 31.5 471386.46 728246.42 31.5 471386.6 728246.36 31.5 471385.59 728243.49 31.5 471385.45 728243.54 31.5 471383.03 728237.18 31.5 471373.63 728240.58 31.5 471375.62 728246.18 31.5 471374.21 728246.69 31.5 471375.45 728250.14 31.5 471376.87 728249.63 31.5 471377.3 728250.86 31.5 471373.78 728252.12 31.5 471373.04 728249.88 31.5 471364.19 728252.59 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.19 728252.59 31.5 471373.04 728249.88 31.5 471373.04 728249.88 41.980000000000004 471364.19 728252.59 41.980000000000004 471364.19 728252.59 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.04 728249.88 31.5 471373.78 728252.12 31.5 471373.78 728252.12 41.980000000000004 471373.04 728249.88 41.980000000000004 471373.04 728249.88 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.78 728252.12 31.5 471377.3 728250.86 31.5 471377.3 728250.86 41.980000000000004 471373.78 728252.12 41.980000000000004 471373.78 728252.12 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471377.3 728250.86 31.5 471376.87 728249.63 31.5 471376.87 728249.63 41.980000000000004 471377.3 728250.86 41.980000000000004 471377.3 728250.86 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471376.87 728249.63 31.5 471375.45 728250.14 31.5 471375.45 728250.14 41.980000000000004 471376.87 728249.63 41.980000000000004 471376.87 728249.63 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.45 728250.14 31.5 471374.21 728246.69 31.5 471374.21 728246.69 41.980000000000004 471375.45 728250.14 41.980000000000004 471375.45 728250.14 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471374.21 728246.69 31.5 471375.62 728246.18 31.5 471375.62 728246.18 41.980000000000004 471374.21 728246.69 41.980000000000004 471374.21 728246.69 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.62 728246.18 31.5 471373.63 728240.58 31.5 471373.63 728240.58 41.980000000000004 471375.62 728246.18 41.980000000000004 471375.62 728246.18 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.63 728240.58 31.5 471383.03 728237.18 31.5 471383.03 728237.18 41.980000000000004 471373.63 728240.58 41.980000000000004 471373.63 728240.58 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.03 728237.18 31.5 471385.45 728243.54 31.5 471385.45 728243.54 41.980000000000004 471383.03 728237.18 41.980000000000004 471383.03 728237.18 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.45 728243.54 31.5 471385.59 728243.49 31.5 471385.59 728243.49 41.980000000000004 471385.45 728243.54 41.980000000000004 471385.45 728243.54 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.59 728243.49 31.5 471386.6 728246.36 31.5 471386.6 728246.36 41.980000000000004 471385.59 728243.49 41.980000000000004 471385.59 728243.49 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471386.6 728246.36 31.5 471386.46 728246.42 31.5 471386.46 728246.42 41.980000000000004 471386.6 728246.36 41.980000000000004 471386.6 728246.36 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471386.46 728246.42 31.5 471388.72 728252.84 31.5 471388.72 728252.84 41.980000000000004 471386.46 728246.42 41.980000000000004 471386.46 728246.42 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471388.72 728252.84 31.5 471384.2 728254.18 31.5 471384.2 728254.18 41.980000000000004 471388.72 728252.84 41.980000000000004 471388.72 728252.84 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471384.2 728254.18 31.5 471366.63 728259.39 31.5 471366.63 728259.39 41.980000000000004 471384.2 728254.18 41.980000000000004 471384.2 728254.18 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471366.63 728259.39 31.5 471364.19 728252.59 31.5 471364.19 728252.59 41.980000000000004 471366.63 728259.39 41.980000000000004 471366.63 728259.39 31.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45BA-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471364.19 728252.59 41.980000000000004 471373.04 728249.88 41.980000000000004 471373.78 728252.12 41.980000000000004 471377.3 728250.86 41.980000000000004 471376.87 728249.63 41.980000000000004 471375.45 728250.14 41.980000000000004 471374.21 728246.69 41.980000000000004 471375.62 728246.18 41.980000000000004 471373.63 728240.58 41.980000000000004 471383.03 728237.18 41.980000000000004 471385.45 728243.54 41.980000000000004 471385.59 728243.49 41.980000000000004 471386.6 728246.36 41.980000000000004 471386.46 728246.42 41.980000000000004 471388.72 728252.84 41.980000000000004 471384.2 728254.18 41.980000000000004 471366.63 728259.39 41.980000000000004 471364.19 728252.59 41.980000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-286E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471231.37 728190.74 39.57 471232.58 728194.62 39.57 471235.44 728203.57 39.57 471236.71 728203.16 39.57 471237.63 728205.94 39.57 471240.04 728205.25 39.57 471240.26 728205.98 39.57 471247.02 728203.85 39.57 471246.11 728200.5 39.57 471246.26 728200.45 39.57 471246.1 728199.92 39.57 471244.23 728200.45 39.57 471241.71 728191.76 39.57 471240.11 728192.22 39.57 471238.91 728188.47 39.57 471231.37 728190.74 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471231.37 728190.74 39.57 471238.91 728188.47 39.57 471238.91 728188.47 48 471231.37 728190.74 48 471231.37 728190.74 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471238.91 728188.47 39.57 471240.11 728192.22 39.57 471240.11 728192.22 48 471238.91 728188.47 48 471238.91 728188.47 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471240.11 728192.22 39.57 471241.71 728191.76 39.57 471241.71 728191.76 48 471240.11 728192.22 48 471240.11 728192.22 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471241.71 728191.76 39.57 471244.23 728200.45 39.57 471244.23 728200.45 48 471241.71 728191.76 48 471241.71 728191.76 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471244.23 728200.45 39.57 471246.1 728199.92 39.57 471246.1 728199.92 48 471244.23 728200.45 48 471244.23 728200.45 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471246.1 728199.92 39.57 471246.26 728200.45 39.57 471246.26 728200.45 48 471246.1 728199.92 48 471246.1 728199.92 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471246.26 728200.45 39.57 471246.11 728200.5 39.57 471246.11 728200.5 48 471246.26 728200.45 48 471246.26 728200.45 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471246.11 728200.5 39.57 471247.02 728203.85 39.57 471247.02 728203.85 48 471246.11 728200.5 48 471246.11 728200.5 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471247.02 728203.85 39.57 471240.26 728205.98 39.57 471240.26 728205.98 48 471247.02 728203.85 48 471247.02 728203.85 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471240.26 728205.98 39.57 471240.04 728205.25 39.57 471240.04 728205.25 48 471240.26 728205.98 48 471240.26 728205.98 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471240.04 728205.25 39.57 471237.63 728205.94 39.57 471237.63 728205.94 48 471240.04 728205.25 48 471240.04 728205.25 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471237.63 728205.94 39.57 471236.71 728203.16 39.57 471236.71 728203.16 48 471237.63 728205.94 48 471237.63 728205.94 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471236.71 728203.16 39.57 471235.44 728203.57 39.57 471235.44 728203.57 48 471236.71 728203.16 48 471236.71 728203.16 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471235.44 728203.57 39.57 471232.58 728194.62 39.57 471232.58 728194.62 48 471235.44 728203.57 48 471235.44 728203.57 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471232.58 728194.62 39.57 471231.37 728190.74 39.57 471231.37 728190.74 48 471232.58 728194.62 48 471232.58 728194.62 39.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-286E-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471231.37 728190.74 48 471238.91 728188.47 48 471240.11 728192.22 48 471241.71 728191.76 48 471244.23 728200.45 48 471246.1 728199.92 48 471246.26 728200.45 48 471246.11 728200.5 48 471247.02 728203.85 48 471240.26 728205.98 48 471240.04 728205.25 48 471237.63 728205.94 48 471236.71 728203.16 48 471235.44 728203.57 48 471232.58 728194.62 48 471231.37 728190.74 48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.76</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.67 728438.1 33.89 471394 728449.68 33.89 471392.56 728450.05 33.89 471393.76 728454.4 33.89 471398.88 728452.96 33.89 471397.74 728448.88 33.89 471405.58 728446.83 33.89 471406.61 728450.79 33.89 471412.97 728448.75 33.89 471411.09 728442.61 33.89 471408.89 728443.28 33.89 471406.57 728435.23 33.89 471405.56 728435.51 33.89 471405.47 728435.22 33.89 471403.24 728435.82 33.89 471403.74 728437.68 33.89 471395.33 728439.98 33.89 471394.53 728437.04 33.89 471390.67 728438.1 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.67 728438.1 33.89 471394.53 728437.04 33.89 471394.53 728437.04 38.65 471390.67 728438.1 38.65 471390.67 728438.1 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471394.53 728437.04 33.89 471395.33 728439.98 33.89 471395.33 728439.98 38.65 471394.53 728437.04 38.65 471394.53 728437.04 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471395.33 728439.98 33.89 471403.74 728437.68 33.89 471403.74 728437.68 38.65 471395.33 728439.98 38.65 471395.33 728439.98 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471403.74 728437.68 33.89 471403.24 728435.82 33.89 471403.24 728435.82 38.65 471403.74 728437.68 38.65 471403.74 728437.68 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471403.24 728435.82 33.89 471405.47 728435.22 33.89 471405.47 728435.22 38.65 471403.24 728435.82 38.65 471403.24 728435.82 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471405.47 728435.22 33.89 471405.56 728435.51 33.89 471405.56 728435.51 38.65 471405.47 728435.22 38.65 471405.47 728435.22 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471405.56 728435.51 33.89 471406.57 728435.23 33.89 471406.57 728435.23 38.65 471405.56 728435.51 38.65 471405.56 728435.51 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471406.57 728435.23 33.89 471408.89 728443.28 33.89 471408.89 728443.28 38.65 471406.57 728435.23 38.65 471406.57 728435.23 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471408.89 728443.28 33.89 471411.09 728442.61 33.89 471411.09 728442.61 38.65 471408.89 728443.28 38.65 471408.89 728443.28 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471411.09 728442.61 33.89 471412.97 728448.75 33.89 471412.97 728448.75 38.65 471411.09 728442.61 38.65 471411.09 728442.61 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471412.97 728448.75 33.89 471406.61 728450.79 33.89 471406.61 728450.79 38.65 471412.97 728448.75 38.65 471412.97 728448.75 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471406.61 728450.79 33.89 471405.58 728446.83 33.89 471405.58 728446.83 38.65 471406.61 728450.79 38.65 471406.61 728450.79 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471405.58 728446.83 33.89 471397.74 728448.88 33.89 471397.74 728448.88 38.65 471405.58 728446.83 38.65 471405.58 728446.83 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471397.74 728448.88 33.89 471398.88 728452.96 33.89 471398.88 728452.96 38.65 471397.74 728448.88 38.65 471397.74 728448.88 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471398.88 728452.96 33.89 471393.76 728454.4 33.89 471393.76 728454.4 38.65 471398.88 728452.96 38.65 471398.88 728452.96 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.76 728454.4 33.89 471392.56 728450.05 33.89 471392.56 728450.05 38.65 471393.76 728454.4 38.65 471393.76 728454.4 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471392.56 728450.05 33.89 471394 728449.68 33.89 471394 728449.68 38.65 471392.56 728450.05 38.65 471392.56 728450.05 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471394 728449.68 33.89 471390.67 728438.1 33.89 471390.67 728438.1 38.65 471394 728449.68 38.65 471394 728449.68 33.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CE-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.67 728438.1 38.65 471394.53 728437.04 38.65 471395.33 728439.98 38.65 471403.74 728437.68 38.65 471403.24 728435.82 38.65 471405.47 728435.22 38.65 471405.56 728435.51 38.65 471406.57 728435.23 38.65 471408.89 728443.28 38.65 471411.09 728442.61 38.65 471412.97 728448.75 38.65 471406.61 728450.79 38.65 471405.58 728446.83 38.65 471397.74 728448.88 38.65 471398.88 728452.96 38.65 471393.76 728454.4 38.65 471392.56 728450.05 38.65 471394 728449.68 38.65 471390.67 728438.1 38.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.87</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471349.08 728340.82 34.7 471351.82 728350.2 34.7 471359.3 728347.9 34.7 471358.48 728345.22 34.7 471360.2 728344.71 34.7 471358.28 728338.02 34.7 471354.83 728339.01 34.7 471354.69 728338.53 34.7 471349.46 728340.38 34.7 471349.55 728340.67 34.7 471349.08 728340.82 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471349.08 728340.82 34.7 471349.55 728340.67 34.7 471349.55 728340.67 42.57 471349.08 728340.82 42.57 471349.08 728340.82 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471349.55 728340.67 34.7 471349.46 728340.38 34.7 471349.46 728340.38 42.57 471349.55 728340.67 42.57 471349.55 728340.67 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471349.46 728340.38 34.7 471354.69 728338.53 34.7 471354.69 728338.53 42.57 471349.46 728340.38 42.57 471349.46 728340.38 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.69 728338.53 34.7 471354.83 728339.01 34.7 471354.83 728339.01 42.57 471354.69 728338.53 42.57 471354.69 728338.53 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471354.83 728339.01 34.7 471358.28 728338.02 34.7 471358.28 728338.02 42.57 471354.83 728339.01 42.57 471354.83 728339.01 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471358.28 728338.02 34.7 471360.2 728344.71 34.7 471360.2 728344.71 42.57 471358.28 728338.02 42.57 471358.28 728338.02 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471360.2 728344.71 34.7 471358.48 728345.22 34.7 471358.48 728345.22 42.57 471360.2 728344.71 42.57 471360.2 728344.71 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471358.48 728345.22 34.7 471359.3 728347.9 34.7 471359.3 728347.9 42.57 471358.48 728345.22 42.57 471358.48 728345.22 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471359.3 728347.9 34.7 471351.82 728350.2 34.7 471351.82 728350.2 42.57 471359.3 728347.9 42.57 471359.3 728347.9 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471351.82 728350.2 34.7 471349.08 728340.82 34.7 471349.08 728340.82 42.57 471351.82 728350.2 42.57 471351.82 728350.2 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CD-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471349.08 728340.82 42.57 471349.55 728340.67 42.57 471349.46 728340.38 42.57 471354.69 728338.53 42.57 471354.83 728339.01 42.57 471358.28 728338.02 42.57 471360.2 728344.71 42.57 471358.48 728345.22 42.57 471359.3 728347.9 42.57 471351.82 728350.2 42.57 471349.08 728340.82 42.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2920-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.76</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.85 728329.18 36.39 471308.83 728338.17 36.39 471319.43 728334.92 36.39 471318.66 728332.24 36.39 471320.28 728331.72 36.39 471318.16 728325.18 36.39 471314.6 728326.33 36.39 471314.47 728325.95 36.39 471309.27 728327.6 36.39 471309.4 728328.01 36.39 471305.85 728329.18 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.85 728329.18 36.39 471309.4 728328.01 36.39 471309.4 728328.01 45.15 471305.85 728329.18 45.15 471305.85 728329.18 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471309.4 728328.01 36.39 471309.27 728327.6 36.39 471309.27 728327.6 45.15 471309.4 728328.01 45.15 471309.4 728328.01 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471309.27 728327.6 36.39 471314.47 728325.95 36.39 471314.47 728325.95 45.15 471309.27 728327.6 45.15 471309.27 728327.6 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.47 728325.95 36.39 471314.6 728326.33 36.39 471314.6 728326.33 45.15 471314.47 728325.95 45.15 471314.47 728325.95 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.6 728326.33 36.39 471318.16 728325.18 36.39 471318.16 728325.18 45.15 471314.6 728326.33 45.15 471314.6 728326.33 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.16 728325.18 36.39 471320.28 728331.72 36.39 471320.28 728331.72 45.15 471318.16 728325.18 45.15 471318.16 728325.18 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471320.28 728331.72 36.39 471318.66 728332.24 36.39 471318.66 728332.24 45.15 471320.28 728331.72 45.15 471320.28 728331.72 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.66 728332.24 36.39 471319.43 728334.92 36.39 471319.43 728334.92 45.15 471318.66 728332.24 45.15 471318.66 728332.24 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471319.43 728334.92 36.39 471308.83 728338.17 36.39 471308.83 728338.17 45.15 471319.43 728334.92 45.15 471319.43 728334.92 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471308.83 728338.17 36.39 471305.85 728329.18 36.39 471305.85 728329.18 45.15 471308.83 728338.17 45.15 471308.83 728338.17 36.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2920-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.85 728329.18 45.15 471309.4 728328.01 45.15 471309.27 728327.6 45.15 471314.47 728325.95 45.15 471314.6 728326.33 45.15 471318.16 728325.18 45.15 471320.28 728331.72 45.15 471318.66 728332.24 45.15 471319.43 728334.92 45.15 471308.83 728338.17 45.15 471305.85 728329.18 45.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-291F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.85</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471268.41 728337.13 39.64 471272.17 728350.03 39.64 471272.63 728349.89 39.64 471274.22 728349.47 39.64 471274.29 728349.74 39.64 471280.25 728348 39.64 471278.01 728339.76 39.64 471279.06 728339.45 39.64 471277.52 728334.12 39.64 471270.41 728336.18 39.64 471270.52 728336.49 39.64 471268.41 728337.13 39.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471268.41 728337.13 39.64 471270.52 728336.49 39.64 471270.52 728336.49 48.49 471268.41 728337.13 48.49 471268.41 728337.13 39.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471270.52 728336.49 39.64 471270.41 728336.18 39.64 471270.41 728336.18 48.49 471270.52 728336.49 48.49 471270.52 728336.49 39.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471270.41 728336.18 39.64 471277.52 728334.12 39.64 471277.52 728334.12 48.49 471270.41 728336.18 48.49 471270.41 728336.18 39.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471277.52 728334.12 39.64 471279.06 728339.45 39.64 471279.06 728339.45 48.49 471277.52 728334.12 48.49 471277.52 728334.12 39.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471279.06 728339.45 39.64 471278.01 728339.76 39.64 471278.01 728339.76 48.49 471279.06 728339.45 48.49 471279.06 728339.45 39.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471278.01 728339.76 39.64 471280.25 728348 39.64 471280.25 728348 48.49 471278.01 728339.76 48.49 471278.01 728339.76 39.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471280.25 728348 39.64 471274.29 728349.74 39.64 471274.29 728349.74 48.49 471280.25 728348 48.49 471280.25 728348 39.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471274.29 728349.74 39.64 471274.22 728349.47 39.64 471274.22 728349.47 48.49 471274.29 728349.74 48.49 471274.29 728349.74 39.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471274.22 728349.47 39.64 471272.63 728349.89 39.64 471272.63 728349.89 48.49 471274.22 728349.47 48.49 471274.22 728349.47 39.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471272.63 728349.89 39.64 471272.17 728350.03 39.64 471272.17 728350.03 48.49 471272.63 728349.89 48.49 471272.63 728349.89 39.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471272.17 728350.03 39.64 471268.41 728337.13 39.64 471268.41 728337.13 48.49 471272.17 728350.03 48.49 471272.17 728350.03 39.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291F-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471268.41 728337.13 48.49 471270.52 728336.49 48.49 471270.41 728336.18 48.49 471277.52 728334.12 48.49 471279.06 728339.45 48.49 471278.01 728339.76 48.49 471280.25 728348 48.49 471274.29 728349.74 48.49 471274.22 728349.47 48.49 471272.63 728349.89 48.49 471272.17 728350.03 48.49 471268.41 728337.13 48.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-291E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">11.36</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471245.61 728349.75 43.18 471246.01 728350.98 43.18 471248.38 728358.12 43.18 471253.02 728356.59 43.18 471253.53 728358.17 43.18 471256.62 728357.17 43.18 471255.95 728355.03 43.18 471258.65 728354.08 43.18 471257.69 728351.16 43.18 471258.31 728350.96 43.18 471256.7 728346.09 43.18 471245.61 728349.75 43.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471245.61 728349.75 43.18 471256.7 728346.09 43.18 471256.7 728346.09 54.54 471245.61 728349.75 54.54 471245.61 728349.75 43.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471256.7 728346.09 43.18 471258.31 728350.96 43.18 471258.31 728350.96 54.54 471256.7 728346.09 54.54 471256.7 728346.09 43.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471258.31 728350.96 43.18 471257.69 728351.16 43.18 471257.69 728351.16 54.54 471258.31 728350.96 54.54 471258.31 728350.96 43.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471257.69 728351.16 43.18 471258.65 728354.08 43.18 471258.65 728354.08 54.54 471257.69 728351.16 54.54 471257.69 728351.16 43.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471258.65 728354.08 43.18 471255.95 728355.03 43.18 471255.95 728355.03 54.54 471258.65 728354.08 54.54 471258.65 728354.08 43.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471255.95 728355.03 43.18 471256.62 728357.17 43.18 471256.62 728357.17 54.54 471255.95 728355.03 54.54 471255.95 728355.03 43.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471256.62 728357.17 43.18 471253.53 728358.17 43.18 471253.53 728358.17 54.54 471256.62 728357.17 54.54 471256.62 728357.17 43.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471253.53 728358.17 43.18 471253.02 728356.59 43.18 471253.02 728356.59 54.54 471253.53 728358.17 54.54 471253.53 728358.17 43.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471253.02 728356.59 43.18 471248.38 728358.12 43.18 471248.38 728358.12 54.54 471253.02 728356.59 54.54 471253.02 728356.59 43.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471248.38 728358.12 43.18 471246.01 728350.98 43.18 471246.01 728350.98 54.54 471248.38 728358.12 54.54 471248.38 728358.12 43.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471246.01 728350.98 43.18 471245.61 728349.75 43.18 471245.61 728349.75 54.54 471246.01 728350.98 54.54 471246.01 728350.98 43.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-291E-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471245.61 728349.75 54.54 471256.7 728346.09 54.54 471258.31 728350.96 54.54 471257.69 728351.16 54.54 471258.65 728354.08 54.54 471255.95 728355.03 54.54 471256.62 728357.17 54.54 471253.53 728358.17 54.54 471253.02 728356.59 54.54 471248.38 728358.12 54.54 471246.01 728350.98 54.54 471245.61 728349.75 54.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-45B9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-45B9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">14.15</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471576.82 728664.17 25.58 471580.28 728671.56 25.58 471583.78 728677.91 25.58 471594.96 728671.66 25.58 471592.04 728666.45 25.58 471589.61 728667.76 25.58 471585.02 728659.42 25.58 471576.82 728664.17 25.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471576.82 728664.17 25.58 471585.02 728659.42 25.58 471585.02 728659.42 39.730000000000004 471576.82 728664.17 39.730000000000004 471576.82 728664.17 25.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471585.02 728659.42 25.58 471589.61 728667.76 25.58 471589.61 728667.76 39.730000000000004 471585.02 728659.42 39.730000000000004 471585.02 728659.42 25.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471589.61 728667.76 25.58 471592.04 728666.45 25.58 471592.04 728666.45 39.730000000000004 471589.61 728667.76 39.730000000000004 471589.61 728667.76 25.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471592.04 728666.45 25.58 471594.96 728671.66 25.58 471594.96 728671.66 39.730000000000004 471592.04 728666.45 39.730000000000004 471592.04 728666.45 25.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471594.96 728671.66 25.58 471583.78 728677.91 25.58 471583.78 728677.91 39.730000000000004 471594.96 728671.66 39.730000000000004 471594.96 728671.66 25.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B9-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471583.78 728677.91 25.58 471580.28 728671.56 25.58 471580.28 728671.56 39.730000000000004 471583.78 728677.91 39.730000000000004 471583.78 728677.91 25.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B9-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471580.28 728671.56 25.58 471576.82 728664.17 25.58 471576.82 728664.17 39.730000000000004 471580.28 728671.56 39.730000000000004 471580.28 728671.56 25.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B9-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471576.82 728664.17 39.730000000000004 471585.02 728659.42 39.730000000000004 471589.61 728667.76 39.730000000000004 471592.04 728666.45 39.730000000000004 471594.96 728671.66 39.730000000000004 471583.78 728677.91 39.730000000000004 471580.28 728671.56 39.730000000000004 471576.82 728664.17 39.730000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-45B8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-45B8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">34.38</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.89 728359.21 32.6 471380.37 728374.81 32.6 471394.09 728374.35 32.6 471394.13 728376.89 32.6 471397.25 728376.74 32.6 471397.19 728374.26 32.6 471408.11 728373.88 32.6 471407.66 728358.34 32.6 471379.89 728359.21 32.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.89 728359.21 32.6 471407.66 728358.34 32.6 471407.66 728358.34 66.98 471379.89 728359.21 66.98 471379.89 728359.21 32.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471407.66 728358.34 32.6 471408.11 728373.88 32.6 471408.11 728373.88 66.98 471407.66 728358.34 66.98 471407.66 728358.34 32.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471408.11 728373.88 32.6 471397.19 728374.26 32.6 471397.19 728374.26 66.98 471408.11 728373.88 66.98 471408.11 728373.88 32.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471397.19 728374.26 32.6 471397.25 728376.74 32.6 471397.25 728376.74 66.98 471397.19 728374.26 66.98 471397.19 728374.26 32.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471397.25 728376.74 32.6 471394.13 728376.89 32.6 471394.13 728376.89 66.98 471397.25 728376.74 66.98 471397.25 728376.74 32.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B8-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471394.13 728376.89 32.6 471394.09 728374.35 32.6 471394.09 728374.35 66.98 471394.13 728376.89 66.98 471394.13 728376.89 32.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B8-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471394.09 728374.35 32.6 471380.37 728374.81 32.6 471380.37 728374.81 66.98 471394.09 728374.35 66.98 471394.09 728374.35 32.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B8-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.37 728374.81 32.6 471379.89 728359.21 32.6 471379.89 728359.21 66.98 471380.37 728374.81 66.98 471380.37 728374.81 32.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B8-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.89 728359.21 66.98 471407.66 728358.34 66.98 471408.11 728373.88 66.98 471397.19 728374.26 66.98 471397.25 728376.74 66.98 471394.13 728376.89 66.98 471394.09 728374.35 66.98 471380.37 728374.81 66.98 471379.89 728359.21 66.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2A80-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2A80-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.34</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A80-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470017.7 728706.18 70.73 470031.7 728700.34 70.73 470028.26 728692.08 70.73 470014.25 728697.9 70.73 470017.7 728706.18 70.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A80-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470017.7 728706.18 70.73 470014.25 728697.9 70.73 470014.25 728697.9 77.07000000000001 470017.7 728706.18 77.07000000000001 470017.7 728706.18 70.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A80-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470014.25 728697.9 70.73 470028.26 728692.08 70.73 470028.26 728692.08 77.07000000000001 470014.25 728697.9 77.07000000000001 470014.25 728697.9 70.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A80-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470028.26 728692.08 70.73 470031.7 728700.34 70.73 470031.7 728700.34 77.07000000000001 470028.26 728692.08 77.07000000000001 470028.26 728692.08 70.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A80-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470031.7 728700.34 70.73 470017.7 728706.18 70.73 470017.7 728706.18 77.07000000000001 470031.7 728700.34 77.07000000000001 470031.7 728700.34 70.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A80-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470017.7 728706.18 77.07000000000001 470014.25 728697.9 77.07000000000001 470028.26 728692.08 77.07000000000001 470031.7 728700.34 77.07000000000001 470017.7 728706.18 77.07000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.02</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470162.21 728592.71 67.61 470163.99 728590.63 67.61 470162.47 728589.34 67.61 470165.61 728585.7 67.61 470169.03 728581.73 67.61 470170.43 728582.82 67.61 470172.46 728580.47 67.61 470162.69 728572.13 67.61 470160.71 728574.45 67.61 470161.94 728575.49 67.61 470154.57 728584.12 67.61 470152.86 728582.65 67.61 470151.25 728584.53 67.61 470152.39 728585.52 67.61 470152.03 728585.93 67.61 470152.52 728586.35 67.61 470152.88 728585.94 67.61 470160.21 728592.19 67.61 470160.79 728591.51 67.61 470162.21 728592.71 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470162.21 728592.71 67.61 470160.79 728591.51 67.61 470160.79 728591.51 72.63 470162.21 728592.71 72.63 470162.21 728592.71 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470160.79 728591.51 67.61 470160.21 728592.19 67.61 470160.21 728592.19 72.63 470160.79 728591.51 72.63 470160.79 728591.51 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470160.21 728592.19 67.61 470152.88 728585.94 67.61 470152.88 728585.94 72.63 470160.21 728592.19 72.63 470160.21 728592.19 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470152.88 728585.94 67.61 470152.52 728586.35 67.61 470152.52 728586.35 72.63 470152.88 728585.94 72.63 470152.88 728585.94 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470152.52 728586.35 67.61 470152.03 728585.93 67.61 470152.03 728585.93 72.63 470152.52 728586.35 72.63 470152.52 728586.35 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470152.03 728585.93 67.61 470152.39 728585.52 67.61 470152.39 728585.52 72.63 470152.03 728585.93 72.63 470152.03 728585.93 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470152.39 728585.52 67.61 470151.25 728584.53 67.61 470151.25 728584.53 72.63 470152.39 728585.52 72.63 470152.39 728585.52 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470151.25 728584.53 67.61 470152.86 728582.65 67.61 470152.86 728582.65 72.63 470151.25 728584.53 72.63 470151.25 728584.53 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470152.86 728582.65 67.61 470154.57 728584.12 67.61 470154.57 728584.12 72.63 470152.86 728582.65 72.63 470152.86 728582.65 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470154.57 728584.12 67.61 470161.94 728575.49 67.61 470161.94 728575.49 72.63 470154.57 728584.12 72.63 470154.57 728584.12 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470161.94 728575.49 67.61 470160.71 728574.45 67.61 470160.71 728574.45 72.63 470161.94 728575.49 72.63 470161.94 728575.49 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470160.71 728574.45 67.61 470162.69 728572.13 67.61 470162.69 728572.13 72.63 470160.71 728574.45 72.63 470160.71 728574.45 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470162.69 728572.13 67.61 470172.46 728580.47 67.61 470172.46 728580.47 72.63 470162.69 728572.13 72.63 470162.69 728572.13 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470172.46 728580.47 67.61 470170.43 728582.82 67.61 470170.43 728582.82 72.63 470172.46 728580.47 72.63 470172.46 728580.47 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470170.43 728582.82 67.61 470169.03 728581.73 67.61 470169.03 728581.73 72.63 470170.43 728582.82 72.63 470170.43 728582.82 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470169.03 728581.73 67.61 470165.61 728585.7 67.61 470165.61 728585.7 72.63 470169.03 728581.73 72.63 470169.03 728581.73 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470165.61 728585.7 67.61 470162.47 728589.34 67.61 470162.47 728589.34 72.63 470165.61 728585.7 72.63 470165.61 728585.7 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470162.47 728589.34 67.61 470163.99 728590.63 67.61 470163.99 728590.63 72.63 470162.47 728589.34 72.63 470162.47 728589.34 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470163.99 728590.63 67.61 470162.21 728592.71 67.61 470162.21 728592.71 72.63 470163.99 728590.63 72.63 470163.99 728590.63 67.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7E-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470162.21 728592.71 72.63 470160.79 728591.51 72.63 470160.21 728592.19 72.63 470152.88 728585.94 72.63 470152.52 728586.35 72.63 470152.03 728585.93 72.63 470152.39 728585.52 72.63 470151.25 728584.53 72.63 470152.86 728582.65 72.63 470154.57 728584.12 72.63 470161.94 728575.49 72.63 470160.71 728574.45 72.63 470162.69 728572.13 72.63 470172.46 728580.47 72.63 470170.43 728582.82 72.63 470169.03 728581.73 72.63 470165.61 728585.7 72.63 470162.47 728589.34 72.63 470163.99 728590.63 72.63 470162.21 728592.71 72.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2A7F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2A7F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.12</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470072.6 728673.25 70.51 470078.42 728669.51 70.51 470073.94 728662.1 70.51 470068.08 728665.88 70.51 470072.6 728673.25 70.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470072.6 728673.25 70.51 470068.08 728665.88 70.51 470068.08 728665.88 76.63 470072.6 728673.25 76.63 470072.6 728673.25 70.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470068.08 728665.88 70.51 470073.94 728662.1 70.51 470073.94 728662.1 76.63 470068.08 728665.88 76.63 470068.08 728665.88 70.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470073.94 728662.1 70.51 470078.42 728669.51 70.51 470078.42 728669.51 76.63 470073.94 728662.1 76.63 470073.94 728662.1 70.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470078.42 728669.51 70.51 470072.6 728673.25 70.51 470072.6 728673.25 76.63 470078.42 728669.51 76.63 470078.42 728669.51 70.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>470072.6 728673.25 76.63 470068.08 728665.88 76.63 470073.94 728662.1 76.63 470078.42 728669.51 76.63 470072.6 728673.25 76.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2874-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.25</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471260.58 728288.79 37.94 471264.79 728292.22 37.94 471265.65 728291.17 37.94 471267.05 728289.4 37.94 471268.51 728290.58 37.94 471274.39 728283.35 37.94 471277.29 728285.66 37.94 471285.35 728283.13 37.94 471284.79 728281.57 37.94 471284.09 728279.44 37.94 471284.84 728278.26 37.94 471284.34 728276.8 37.94 471283.05 728276.36 37.94 471281.83 728272.8 37.94 471270.37 728276.64 37.94 471269.06 728278.25 37.94 471267.44 728276.91 37.94 471261.09 728284.68 37.94 471262.81 728286.1 37.94 471260.58 728288.79 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471260.58 728288.79 37.94 471262.81 728286.1 37.94 471262.81 728286.1 47.19 471260.58 728288.79 47.19 471260.58 728288.79 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471262.81 728286.1 37.94 471261.09 728284.68 37.94 471261.09 728284.68 47.19 471262.81 728286.1 47.19 471262.81 728286.1 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471261.09 728284.68 37.94 471267.44 728276.91 37.94 471267.44 728276.91 47.19 471261.09 728284.68 47.19 471261.09 728284.68 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471267.44 728276.91 37.94 471269.06 728278.25 37.94 471269.06 728278.25 47.19 471267.44 728276.91 47.19 471267.44 728276.91 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471269.06 728278.25 37.94 471270.37 728276.64 37.94 471270.37 728276.64 47.19 471269.06 728278.25 47.19 471269.06 728278.25 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471270.37 728276.64 37.94 471281.83 728272.8 37.94 471281.83 728272.8 47.19 471270.37 728276.64 47.19 471270.37 728276.64 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471281.83 728272.8 37.94 471283.05 728276.36 37.94 471283.05 728276.36 47.19 471281.83 728272.8 47.19 471281.83 728272.8 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471283.05 728276.36 37.94 471284.34 728276.8 37.94 471284.34 728276.8 47.19 471283.05 728276.36 47.19 471283.05 728276.36 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471284.34 728276.8 37.94 471284.84 728278.26 37.94 471284.84 728278.26 47.19 471284.34 728276.8 47.19 471284.34 728276.8 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471284.84 728278.26 37.94 471284.09 728279.44 37.94 471284.09 728279.44 47.19 471284.84 728278.26 47.19 471284.84 728278.26 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471284.09 728279.44 37.94 471284.79 728281.57 37.94 471284.79 728281.57 47.19 471284.09 728279.44 47.19 471284.09 728279.44 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471284.79 728281.57 37.94 471285.35 728283.13 37.94 471285.35 728283.13 47.19 471284.79 728281.57 47.19 471284.79 728281.57 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471285.35 728283.13 37.94 471277.29 728285.66 37.94 471277.29 728285.66 47.19 471285.35 728283.13 47.19 471285.35 728283.13 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471277.29 728285.66 37.94 471274.39 728283.35 37.94 471274.39 728283.35 47.19 471277.29 728285.66 47.19 471277.29 728285.66 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471274.39 728283.35 37.94 471268.51 728290.58 37.94 471268.51 728290.58 47.19 471274.39 728283.35 47.19 471274.39 728283.35 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471268.51 728290.58 37.94 471267.05 728289.4 37.94 471267.05 728289.4 47.19 471268.51 728290.58 47.19 471268.51 728290.58 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471267.05 728289.4 37.94 471265.65 728291.17 37.94 471265.65 728291.17 47.19 471267.05 728289.4 47.19 471267.05 728289.4 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471265.65 728291.17 37.94 471264.79 728292.22 37.94 471264.79 728292.22 47.19 471265.65 728291.17 47.19 471265.65 728291.17 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471264.79 728292.22 37.94 471260.58 728288.79 37.94 471260.58 728288.79 47.19 471264.79 728292.22 47.19 471264.79 728292.22 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2874-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471260.58 728288.79 47.19 471262.81 728286.1 47.19 471261.09 728284.68 47.19 471267.44 728276.91 47.19 471269.06 728278.25 47.19 471270.37 728276.64 47.19 471281.83 728272.8 47.19 471283.05 728276.36 47.19 471284.34 728276.8 47.19 471284.84 728278.26 47.19 471284.09 728279.44 47.19 471284.79 728281.57 47.19 471285.35 728283.13 47.19 471277.29 728285.66 47.19 471274.39 728283.35 47.19 471268.51 728290.58 47.19 471267.05 728289.4 47.19 471265.65 728291.17 47.19 471264.79 728292.22 47.19 471260.58 728288.79 47.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2873-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2873-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.02</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2873-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471229.93 728283.83 40.13 471230.98 728287.53 40.13 471232.49 728287.1 40.13 471234.98 728295.94 40.13 471244.24 728293.21 40.13 471240.56 728280.8 40.13 471229.93 728283.83 40.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2873-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471229.93 728283.83 40.13 471240.56 728280.8 40.13 471240.56 728280.8 50.15 471229.93 728283.83 50.15 471229.93 728283.83 40.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2873-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471240.56 728280.8 40.13 471244.24 728293.21 40.13 471244.24 728293.21 50.15 471240.56 728280.8 50.15 471240.56 728280.8 40.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2873-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471244.24 728293.21 40.13 471234.98 728295.94 40.13 471234.98 728295.94 50.15 471244.24 728293.21 50.15 471244.24 728293.21 40.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2873-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471234.98 728295.94 40.13 471232.49 728287.1 40.13 471232.49 728287.1 50.15 471234.98 728295.94 50.15 471234.98 728295.94 40.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2873-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471232.49 728287.1 40.13 471230.98 728287.53 40.13 471230.98 728287.53 50.15 471232.49 728287.1 50.15 471232.49 728287.1 40.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2873-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471230.98 728287.53 40.13 471229.93 728283.83 40.13 471229.93 728283.83 50.15 471230.98 728287.53 50.15 471230.98 728287.53 40.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2873-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471229.93 728283.83 50.15 471240.56 728280.8 50.15 471244.24 728293.21 50.15 471234.98 728295.94 50.15 471232.49 728287.1 50.15 471230.98 728287.53 50.15 471229.93 728283.83 50.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2871-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2871-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2871-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471281.21 728240.02 37.09 471284.17 728248.31 37.09 471299.69 728242.75 37.09 471296.71 728234.42 37.09 471281.21 728240.02 37.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2871-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471281.21 728240.02 37.09 471296.71 728234.42 37.09 471296.71 728234.42 43.52 471281.21 728240.02 43.52 471281.21 728240.02 37.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2871-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471296.71 728234.42 37.09 471299.69 728242.75 37.09 471299.69 728242.75 43.52 471296.71 728234.42 43.52 471296.71 728234.42 37.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2871-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471299.69 728242.75 37.09 471284.17 728248.31 37.09 471284.17 728248.31 43.52 471299.69 728242.75 43.52 471299.69 728242.75 37.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2871-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471284.17 728248.31 37.09 471281.21 728240.02 37.09 471281.21 728240.02 43.52 471284.17 728248.31 43.52 471284.17 728248.31 37.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2871-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471281.21 728240.02 43.52 471296.71 728234.42 43.52 471299.69 728242.75 43.52 471284.17 728248.31 43.52 471281.21 728240.02 43.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2870-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2870-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.28</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2870-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471211.91 728234.12 39.21 471214.81 728244.14 39.21 471223.33 728241.44 39.21 471222.49 728238.68 39.21 471222.09 728238.81 39.21 471220.17 728232.55 39.21 471216.44 728233.7 39.21 471216.19 728232.88 39.21 471211.91 728234.12 39.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2870-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471211.91 728234.12 39.21 471216.19 728232.88 39.21 471216.19 728232.88 47.49 471211.91 728234.12 47.49 471211.91 728234.12 39.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2870-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471216.19 728232.88 39.21 471216.44 728233.7 39.21 471216.44 728233.7 47.49 471216.19 728232.88 47.49 471216.19 728232.88 39.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2870-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471216.44 728233.7 39.21 471220.17 728232.55 39.21 471220.17 728232.55 47.49 471216.44 728233.7 47.49 471216.44 728233.7 39.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2870-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471220.17 728232.55 39.21 471222.09 728238.81 39.21 471222.09 728238.81 47.49 471220.17 728232.55 47.49 471220.17 728232.55 39.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2870-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471222.09 728238.81 39.21 471222.49 728238.68 39.21 471222.49 728238.68 47.49 471222.09 728238.81 47.49 471222.09 728238.81 39.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2870-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471222.49 728238.68 39.21 471223.33 728241.44 39.21 471223.33 728241.44 47.49 471222.49 728238.68 47.49 471222.49 728238.68 39.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2870-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471223.33 728241.44 39.21 471214.81 728244.14 39.21 471214.81 728244.14 47.49 471223.33 728241.44 47.49 471223.33 728241.44 39.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2870-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471214.81 728244.14 39.21 471211.91 728234.12 39.21 471211.91 728234.12 47.49 471214.81 728244.14 47.49 471214.81 728244.14 39.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2870-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471211.91 728234.12 47.49 471216.19 728232.88 47.49 471216.44 728233.7 47.49 471220.17 728232.55 47.49 471222.09 728238.81 47.49 471222.49 728238.68 47.49 471223.33 728241.44 47.49 471214.81 728244.14 47.49 471211.91 728234.12 47.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.89</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.34 728418.68 35.38 471371.25 728428.01 35.38 471372.01 728427.78 35.38 471373.13 728431.46 35.38 471380.12 728429.29 35.38 471380.52 728430.34 35.38 471385.75 728428.64 35.38 471383.97 728422.7 35.38 471379.62 728424.08 35.38 471378.57 728420.78 35.38 471379.45 728420.49 35.38 471378.59 728417.83 35.38 471377.72 728418.11 35.38 471377.08 728416.12 35.38 471374.4 728416.95 35.38 471373.8 728414.37 35.38 471369.03 728417.44 35.38 471369.2 728418.42 35.38 471368.34 728418.68 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.34 728418.68 35.38 471369.2 728418.42 35.38 471369.2 728418.42 45.27 471368.34 728418.68 45.27 471368.34 728418.68 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.2 728418.42 35.38 471369.03 728417.44 35.38 471369.03 728417.44 45.27 471369.2 728418.42 45.27 471369.2 728418.42 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471369.03 728417.44 35.38 471373.8 728414.37 35.38 471373.8 728414.37 45.27 471369.03 728417.44 45.27 471369.03 728417.44 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.8 728414.37 35.38 471374.4 728416.95 35.38 471374.4 728416.95 45.27 471373.8 728414.37 45.27 471373.8 728414.37 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471374.4 728416.95 35.38 471377.08 728416.12 35.38 471377.08 728416.12 45.27 471374.4 728416.95 45.27 471374.4 728416.95 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471377.08 728416.12 35.38 471377.72 728418.11 35.38 471377.72 728418.11 45.27 471377.08 728416.12 45.27 471377.08 728416.12 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471377.72 728418.11 35.38 471378.59 728417.83 35.38 471378.59 728417.83 45.27 471377.72 728418.11 45.27 471377.72 728418.11 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471378.59 728417.83 35.38 471379.45 728420.49 35.38 471379.45 728420.49 45.27 471378.59 728417.83 45.27 471378.59 728417.83 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.45 728420.49 35.38 471378.57 728420.78 35.38 471378.57 728420.78 45.27 471379.45 728420.49 45.27 471379.45 728420.49 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471378.57 728420.78 35.38 471379.62 728424.08 35.38 471379.62 728424.08 45.27 471378.57 728420.78 45.27 471378.57 728420.78 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471379.62 728424.08 35.38 471383.97 728422.7 35.38 471383.97 728422.7 45.27 471379.62 728424.08 45.27 471379.62 728424.08 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471383.97 728422.7 35.38 471385.75 728428.64 35.38 471385.75 728428.64 45.27 471383.97 728422.7 45.27 471383.97 728422.7 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471385.75 728428.64 35.38 471380.52 728430.34 35.38 471380.52 728430.34 45.27 471385.75 728428.64 45.27 471385.75 728428.64 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.52 728430.34 35.38 471380.12 728429.29 35.38 471380.12 728429.29 45.27 471380.52 728430.34 45.27 471380.52 728430.34 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471380.12 728429.29 35.38 471373.13 728431.46 35.38 471373.13 728431.46 45.27 471380.12 728429.29 45.27 471380.12 728429.29 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471373.13 728431.46 35.38 471372.01 728427.78 35.38 471372.01 728427.78 45.27 471373.13 728431.46 45.27 471373.13 728431.46 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471372.01 728427.78 35.38 471371.25 728428.01 35.38 471371.25 728428.01 45.27 471372.01 728427.78 45.27 471372.01 728427.78 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.25 728428.01 35.38 471368.34 728418.68 35.38 471368.34 728418.68 45.27 471371.25 728428.01 45.27 471371.25 728428.01 35.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-29CF-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471368.34 728418.68 45.27 471369.2 728418.42 45.27 471369.03 728417.44 45.27 471373.8 728414.37 45.27 471374.4 728416.95 45.27 471377.08 728416.12 45.27 471377.72 728418.11 45.27 471378.59 728417.83 45.27 471379.45 728420.49 45.27 471378.57 728420.78 45.27 471379.62 728424.08 45.27 471383.97 728422.7 45.27 471385.75 728428.64 45.27 471380.52 728430.34 45.27 471380.12 728429.29 45.27 471373.13 728431.46 45.27 471372.01 728427.78 45.27 471371.25 728428.01 45.27 471368.34 728418.68 45.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2922-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.15</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471363.77 728307.37 32.14 471367.67 728319.34 32.14 471371.03 728317.99 32.14 471370.65 728316.85 32.14 471375.94 728315.1 32.14 471374.1 728309.35 32.14 471378.58 728307.53 32.14 471376.56 728301.44 32.14 471371.51 728303.19 32.14 471372.06 728304.48 32.14 471363.77 728307.37 32.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471363.77 728307.37 32.14 471372.06 728304.48 32.14 471372.06 728304.48 41.29 471363.77 728307.37 41.29 471363.77 728307.37 32.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471372.06 728304.48 32.14 471371.51 728303.19 32.14 471371.51 728303.19 41.29 471372.06 728304.48 41.29 471372.06 728304.48 32.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.51 728303.19 32.14 471376.56 728301.44 32.14 471376.56 728301.44 41.29 471371.51 728303.19 41.29 471371.51 728303.19 32.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471376.56 728301.44 32.14 471378.58 728307.53 32.14 471378.58 728307.53 41.29 471376.56 728301.44 41.29 471376.56 728301.44 32.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471378.58 728307.53 32.14 471374.1 728309.35 32.14 471374.1 728309.35 41.29 471378.58 728307.53 41.29 471378.58 728307.53 32.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471374.1 728309.35 32.14 471375.94 728315.1 32.14 471375.94 728315.1 41.29 471374.1 728309.35 41.29 471374.1 728309.35 32.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471375.94 728315.1 32.14 471370.65 728316.85 32.14 471370.65 728316.85 41.29 471375.94 728315.1 41.29 471375.94 728315.1 32.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471370.65 728316.85 32.14 471371.03 728317.99 32.14 471371.03 728317.99 41.29 471370.65 728316.85 41.29 471370.65 728316.85 32.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471371.03 728317.99 32.14 471367.67 728319.34 32.14 471367.67 728319.34 41.29 471371.03 728317.99 41.29 471371.03 728317.99 32.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471367.67 728319.34 32.14 471363.77 728307.37 32.14 471363.77 728307.37 41.29 471367.67 728319.34 41.29 471367.67 728319.34 32.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2922-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471363.77 728307.37 41.29 471372.06 728304.48 41.29 471371.51 728303.19 41.29 471376.56 728301.44 41.29 471378.58 728307.53 41.29 471374.1 728309.35 41.29 471375.94 728315.1 41.29 471370.65 728316.85 41.29 471371.03 728317.99 41.29 471367.67 728319.34 41.29 471363.77 728307.37 41.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2923-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.33</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471346.13 728289.5 34.29 471347.95 728295.67 34.29 471351.37 728294.65 34.29 471351.72 728295.82 34.29 471361.58 728292.89 34.29 471360.53 728289.34 34.29 471363.38 728288.62 34.29 471361.15 728281.17 34.29 471356.78 728282.41 34.29 471355.34 728277.37 34.29 471351.83 728278.4 34.29 471351.67 728277.95 34.29 471346.33 728279.61 34.29 471346.44 728280 34.29 471346.16 728280.09 34.29 471348.67 728288.76 34.29 471346.13 728289.5 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471346.13 728289.5 34.29 471348.67 728288.76 34.29 471348.67 728288.76 43.62 471346.13 728289.5 43.62 471346.13 728289.5 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471348.67 728288.76 34.29 471346.16 728280.09 34.29 471346.16 728280.09 43.62 471348.67 728288.76 43.62 471348.67 728288.76 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471346.16 728280.09 34.29 471346.44 728280 34.29 471346.44 728280 43.62 471346.16 728280.09 43.62 471346.16 728280.09 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471346.44 728280 34.29 471346.33 728279.61 34.29 471346.33 728279.61 43.62 471346.44 728280 43.62 471346.44 728280 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471346.33 728279.61 34.29 471351.67 728277.95 34.29 471351.67 728277.95 43.62 471346.33 728279.61 43.62 471346.33 728279.61 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471351.67 728277.95 34.29 471351.83 728278.4 34.29 471351.83 728278.4 43.62 471351.67 728277.95 43.62 471351.67 728277.95 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471351.83 728278.4 34.29 471355.34 728277.37 34.29 471355.34 728277.37 43.62 471351.83 728278.4 43.62 471351.83 728278.4 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471355.34 728277.37 34.29 471356.78 728282.41 34.29 471356.78 728282.41 43.62 471355.34 728277.37 43.62 471355.34 728277.37 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471356.78 728282.41 34.29 471361.15 728281.17 34.29 471361.15 728281.17 43.62 471356.78 728282.41 43.62 471356.78 728282.41 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471361.15 728281.17 34.29 471363.38 728288.62 34.29 471363.38 728288.62 43.62 471361.15 728281.17 43.62 471361.15 728281.17 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471363.38 728288.62 34.29 471360.53 728289.34 34.29 471360.53 728289.34 43.62 471363.38 728288.62 43.62 471363.38 728288.62 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471360.53 728289.34 34.29 471361.58 728292.89 34.29 471361.58 728292.89 43.62 471360.53 728289.34 43.62 471360.53 728289.34 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471361.58 728292.89 34.29 471351.72 728295.82 34.29 471351.72 728295.82 43.62 471361.58 728292.89 43.62 471361.58 728292.89 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471351.72 728295.82 34.29 471351.37 728294.65 34.29 471351.37 728294.65 43.62 471351.72 728295.82 43.62 471351.72 728295.82 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471351.37 728294.65 34.29 471347.95 728295.67 34.29 471347.95 728295.67 43.62 471351.37 728294.65 43.62 471351.37 728294.65 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471347.95 728295.67 34.29 471346.13 728289.5 34.29 471346.13 728289.5 43.62 471347.95 728295.67 43.62 471347.95 728295.67 34.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2923-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471346.13 728289.5 43.62 471348.67 728288.76 43.62 471346.16 728280.09 43.62 471346.44 728280 43.62 471346.33 728279.61 43.62 471351.67 728277.95 43.62 471351.83 728278.4 43.62 471355.34 728277.37 43.62 471356.78 728282.41 43.62 471361.15 728281.17 43.62 471363.38 728288.62 43.62 471360.53 728289.34 43.62 471361.58 728292.89 43.62 471351.72 728295.82 43.62 471351.37 728294.65 43.62 471347.95 728295.67 43.62 471346.13 728289.5 43.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2A7D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2A7D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471609.74 728755.09 24.67 471612.19 728759.23 24.67 471619.96 728754.63 24.67 471616.37 728748.45 24.67 471614.65 728749.45 24.67 471615.83 728751.47 24.67 471609.74 728755.09 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471609.74 728755.09 24.67 471615.83 728751.47 24.67 471615.83 728751.47 30.67 471609.74 728755.09 30.67 471609.74 728755.09 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471615.83 728751.47 24.67 471614.65 728749.45 24.67 471614.65 728749.45 30.67 471615.83 728751.47 30.67 471615.83 728751.47 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471614.65 728749.45 24.67 471616.37 728748.45 24.67 471616.37 728748.45 30.67 471614.65 728749.45 30.67 471614.65 728749.45 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471616.37 728748.45 24.67 471619.96 728754.63 24.67 471619.96 728754.63 30.67 471616.37 728748.45 30.67 471616.37 728748.45 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471619.96 728754.63 24.67 471612.19 728759.23 24.67 471612.19 728759.23 30.67 471619.96 728754.63 30.67 471619.96 728754.63 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471612.19 728759.23 24.67 471609.74 728755.09 24.67 471609.74 728755.09 30.67 471612.19 728759.23 30.67 471612.19 728759.23 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471609.74 728755.09 30.67 471615.83 728751.47 30.67 471614.65 728749.45 30.67 471616.37 728748.45 30.67 471619.96 728754.63 30.67 471612.19 728759.23 30.67 471609.74 728755.09 30.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.5</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471603.24 728746.16 24.67 471608.83 728755.62 24.67 471609.74 728755.09 24.67 471615.83 728751.47 24.67 471614.65 728749.45 24.67 471616.37 728748.45 24.67 471615.01 728746.11 24.67 471611.25 728748.19 24.67 471608.13 728743.19 24.67 471603.24 728746.16 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471603.24 728746.16 24.67 471608.13 728743.19 24.67 471608.13 728743.19 30.17 471603.24 728746.16 30.17 471603.24 728746.16 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471608.13 728743.19 24.67 471611.25 728748.19 24.67 471611.25 728748.19 30.17 471608.13 728743.19 30.17 471608.13 728743.19 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471611.25 728748.19 24.67 471615.01 728746.11 24.67 471615.01 728746.11 30.17 471611.25 728748.19 30.17 471611.25 728748.19 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471615.01 728746.11 24.67 471616.37 728748.45 24.67 471616.37 728748.45 30.17 471615.01 728746.11 30.17 471615.01 728746.11 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471616.37 728748.45 24.67 471614.65 728749.45 24.67 471614.65 728749.45 30.17 471616.37 728748.45 30.17 471616.37 728748.45 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471614.65 728749.45 24.67 471615.83 728751.47 24.67 471615.83 728751.47 30.17 471614.65 728749.45 30.17 471614.65 728749.45 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471615.83 728751.47 24.67 471609.74 728755.09 24.67 471609.74 728755.09 30.17 471615.83 728751.47 30.17 471615.83 728751.47 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471609.74 728755.09 24.67 471608.83 728755.62 24.67 471608.83 728755.62 30.17 471609.74 728755.09 30.17 471609.74 728755.09 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471608.83 728755.62 24.67 471603.24 728746.16 24.67 471603.24 728746.16 30.17 471608.83 728755.62 30.17 471608.83 728755.62 24.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A7C-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471603.24 728746.16 30.17 471608.13 728743.19 30.17 471611.25 728748.19 30.17 471615.01 728746.11 30.17 471616.37 728748.45 30.17 471614.65 728749.45 30.17 471615.83 728751.47 30.17 471609.74 728755.09 30.17 471608.83 728755.62 30.17 471603.24 728746.16 30.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2919-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.59</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.78 728271.72 36.13 471293.1 728279.35 36.13 471296.98 728278.16 36.13 471297.51 728279.87 36.13 471304.97 728277.49 36.13 471304.27 728274.74 36.13 471305.95 728274.15 36.13 471303.94 728267.64 36.13 471300.14 728268.85 36.13 471300.02 728268.37 36.13 471294.61 728269.87 36.13 471294.8 728270.55 36.13 471290.78 728271.72 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.78 728271.72 36.13 471294.8 728270.55 36.13 471294.8 728270.55 44.72 471290.78 728271.72 44.72 471290.78 728271.72 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471294.8 728270.55 36.13 471294.61 728269.87 36.13 471294.61 728269.87 44.72 471294.8 728270.55 44.72 471294.8 728270.55 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471294.61 728269.87 36.13 471300.02 728268.37 36.13 471300.02 728268.37 44.72 471294.61 728269.87 44.72 471294.61 728269.87 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471300.02 728268.37 36.13 471300.14 728268.85 36.13 471300.14 728268.85 44.72 471300.02 728268.37 44.72 471300.02 728268.37 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471300.14 728268.85 36.13 471303.94 728267.64 36.13 471303.94 728267.64 44.72 471300.14 728268.85 44.72 471300.14 728268.85 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471303.94 728267.64 36.13 471305.95 728274.15 36.13 471305.95 728274.15 44.72 471303.94 728267.64 44.72 471303.94 728267.64 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471305.95 728274.15 36.13 471304.27 728274.74 36.13 471304.27 728274.74 44.72 471305.95 728274.15 44.72 471305.95 728274.15 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.27 728274.74 36.13 471304.97 728277.49 36.13 471304.97 728277.49 44.72 471304.27 728274.74 44.72 471304.27 728274.74 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.97 728277.49 36.13 471297.51 728279.87 36.13 471297.51 728279.87 44.72 471304.97 728277.49 44.72 471304.97 728277.49 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471297.51 728279.87 36.13 471296.98 728278.16 36.13 471296.98 728278.16 44.72 471297.51 728279.87 44.72 471297.51 728279.87 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471296.98 728278.16 36.13 471293.1 728279.35 36.13 471293.1 728279.35 44.72 471296.98 728278.16 44.72 471296.98 728278.16 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471293.1 728279.35 36.13 471290.78 728271.72 36.13 471290.78 728271.72 44.72 471293.1 728279.35 44.72 471293.1 728279.35 36.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2919-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471290.78 728271.72 44.72 471294.8 728270.55 44.72 471294.61 728269.87 44.72 471300.02 728268.37 44.72 471300.14 728268.85 44.72 471303.94 728267.64 44.72 471305.95 728274.15 44.72 471304.27 728274.74 44.72 471304.97 728277.49 44.72 471297.51 728279.87 44.72 471296.98 728278.16 44.72 471293.1 728279.35 44.72 471290.78 728271.72 44.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2918-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.72</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471257.88 728253.35 37.92 471260.39 728261.76 37.92 471265.07 728260.36 37.92 471264.94 728259.98 37.92 471270 728258.48 37.92 471269.19 728255.29 37.92 471267.41 728255.8 37.92 471267.02 728254.44 37.92 471266.07 728251.37 37.92 471262.7 728252.34 37.92 471262.58 728251.97 37.92 471257.88 728253.35 37.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471257.88 728253.35 37.92 471262.58 728251.97 37.92 471262.58 728251.97 47.64 471257.88 728253.35 47.64 471257.88 728253.35 37.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471262.58 728251.97 37.92 471262.7 728252.34 37.92 471262.7 728252.34 47.64 471262.58 728251.97 47.64 471262.58 728251.97 37.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471262.7 728252.34 37.92 471266.07 728251.37 37.92 471266.07 728251.37 47.64 471262.7 728252.34 47.64 471262.7 728252.34 37.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471266.07 728251.37 37.92 471267.02 728254.44 37.92 471267.02 728254.44 47.64 471266.07 728251.37 47.64 471266.07 728251.37 37.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471267.02 728254.44 37.92 471267.41 728255.8 37.92 471267.41 728255.8 47.64 471267.02 728254.44 47.64 471267.02 728254.44 37.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471267.41 728255.8 37.92 471269.19 728255.29 37.92 471269.19 728255.29 47.64 471267.41 728255.8 47.64 471267.41 728255.8 37.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471269.19 728255.29 37.92 471270 728258.48 37.92 471270 728258.48 47.64 471269.19 728255.29 47.64 471269.19 728255.29 37.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471270 728258.48 37.92 471264.94 728259.98 37.92 471264.94 728259.98 47.64 471270 728258.48 47.64 471270 728258.48 37.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471264.94 728259.98 37.92 471265.07 728260.36 37.92 471265.07 728260.36 47.64 471264.94 728259.98 47.64 471264.94 728259.98 37.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471265.07 728260.36 37.92 471260.39 728261.76 37.92 471260.39 728261.76 47.64 471265.07 728260.36 47.64 471265.07 728260.36 37.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471260.39 728261.76 37.92 471257.88 728253.35 37.92 471257.88 728253.35 47.64 471260.39 728261.76 47.64 471260.39 728261.76 37.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2918-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471257.88 728253.35 47.64 471262.58 728251.97 47.64 471262.7 728252.34 47.64 471266.07 728251.37 47.64 471267.02 728254.44 47.64 471267.41 728255.8 47.64 471269.19 728255.29 47.64 471270 728258.48 47.64 471264.94 728259.98 47.64 471265.07 728260.36 47.64 471260.39 728261.76 47.64 471257.88 728253.35 47.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2A81-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2A81-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.85</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A81-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.19 728249.38 35.3 471328.68 728253.73 35.3 471333.05 728252.24 35.3 471332.31 728249.87 35.3 471331.7 728247.88 35.3 471327.19 728249.38 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A81-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.19 728249.38 35.3 471331.7 728247.88 35.3 471331.7 728247.88 38.15 471327.19 728249.38 38.15 471327.19 728249.38 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A81-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471331.7 728247.88 35.3 471332.31 728249.87 35.3 471332.31 728249.87 38.15 471331.7 728247.88 38.15 471331.7 728247.88 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A81-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471332.31 728249.87 35.3 471333.05 728252.24 35.3 471333.05 728252.24 38.15 471332.31 728249.87 38.15 471332.31 728249.87 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A81-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471333.05 728252.24 35.3 471328.68 728253.73 35.3 471328.68 728253.73 38.15 471333.05 728252.24 38.15 471333.05 728252.24 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A81-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.68 728253.73 35.3 471327.19 728249.38 35.3 471327.19 728249.38 38.15 471328.68 728253.73 38.15 471328.68 728253.73 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A81-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.19 728249.38 38.15 471331.7 728247.88 38.15 471332.31 728249.87 38.15 471333.05 728252.24 38.15 471328.68 728253.73 38.15 471327.19 728249.38 38.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.33</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.37 728261.34 34.79 471314.84 728262.87 34.79 471314.73 728262.94 34.79 471316.43 728269.09 34.79 471320.27 728267.96 34.79 471321.69 728272.24 34.79 471328.99 728269.97 34.79 471330.89 728269.54 34.79 471330.43 728268.36 34.79 471332.89 728267.61 34.79 471331.51 728263.14 34.79 471329.13 728263.87 34.79 471327.75 728259.41 34.79 471331.46 728258.33 34.79 471330.05 728253.41 34.79 471319.31 728256.51 34.79 471320.6 728260.98 34.79 471318.79 728261.5 34.79 471318.36 728260.12 34.79 471314.37 728261.34 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.37 728261.34 34.79 471318.36 728260.12 34.79 471318.36 728260.12 43.12 471314.37 728261.34 43.12 471314.37 728261.34 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.36 728260.12 34.79 471318.79 728261.5 34.79 471318.79 728261.5 43.12 471318.36 728260.12 43.12 471318.36 728260.12 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471318.79 728261.5 34.79 471320.6 728260.98 34.79 471320.6 728260.98 43.12 471318.79 728261.5 43.12 471318.79 728261.5 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471320.6 728260.98 34.79 471319.31 728256.51 34.79 471319.31 728256.51 43.12 471320.6 728260.98 43.12 471320.6 728260.98 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471319.31 728256.51 34.79 471330.05 728253.41 34.79 471330.05 728253.41 43.12 471319.31 728256.51 43.12 471319.31 728256.51 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.05 728253.41 34.79 471331.46 728258.33 34.79 471331.46 728258.33 43.12 471330.05 728253.41 43.12 471330.05 728253.41 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471331.46 728258.33 34.79 471327.75 728259.41 34.79 471327.75 728259.41 43.12 471331.46 728258.33 43.12 471331.46 728258.33 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471327.75 728259.41 34.79 471329.13 728263.87 34.79 471329.13 728263.87 43.12 471327.75 728259.41 43.12 471327.75 728259.41 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471329.13 728263.87 34.79 471331.51 728263.14 34.79 471331.51 728263.14 43.12 471329.13 728263.87 43.12 471329.13 728263.87 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471331.51 728263.14 34.79 471332.89 728267.61 34.79 471332.89 728267.61 43.12 471331.51 728263.14 43.12 471331.51 728263.14 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471332.89 728267.61 34.79 471330.43 728268.36 34.79 471330.43 728268.36 43.12 471332.89 728267.61 43.12 471332.89 728267.61 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.43 728268.36 34.79 471330.89 728269.54 34.79 471330.89 728269.54 43.12 471330.43 728268.36 43.12 471330.43 728268.36 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471330.89 728269.54 34.79 471328.99 728269.97 34.79 471328.99 728269.97 43.12 471330.89 728269.54 43.12 471330.89 728269.54 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471328.99 728269.97 34.79 471321.69 728272.24 34.79 471321.69 728272.24 43.12 471328.99 728269.97 43.12 471328.99 728269.97 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471321.69 728272.24 34.79 471320.27 728267.96 34.79 471320.27 728267.96 43.12 471321.69 728272.24 43.12 471321.69 728272.24 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471320.27 728267.96 34.79 471316.43 728269.09 34.79 471316.43 728269.09 43.12 471320.27 728267.96 43.12 471320.27 728267.96 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471316.43 728269.09 34.79 471314.73 728262.94 34.79 471314.73 728262.94 43.12 471316.43 728269.09 43.12 471316.43 728269.09 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.73 728262.94 34.79 471314.84 728262.87 34.79 471314.84 728262.87 43.12 471314.73 728262.94 43.12 471314.73 728262.94 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.84 728262.87 34.79 471314.37 728261.34 34.79 471314.37 728261.34 43.12 471314.84 728262.87 43.12 471314.84 728262.87 34.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A82-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.37 728261.34 43.12 471318.36 728260.12 43.12 471318.79 728261.5 43.12 471320.6 728260.98 43.12 471319.31 728256.51 43.12 471330.05 728253.41 43.12 471331.46 728258.33 43.12 471327.75 728259.41 43.12 471329.13 728263.87 43.12 471331.51 728263.14 43.12 471332.89 728267.61 43.12 471330.43 728268.36 43.12 471330.89 728269.54 43.12 471328.99 728269.97 43.12 471321.69 728272.24 43.12 471320.27 728267.96 43.12 471316.43 728269.09 43.12 471314.73 728262.94 43.12 471314.84 728262.87 43.12 471314.37 728261.34 43.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-44FB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-44FB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.09</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471303.06 728311.72 36.78 471312.75 728308.93 36.78 471306.75 728288.69 36.78 471297.12 728291.6 36.78 471303.06 728311.72 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471303.06 728311.72 36.78 471297.12 728291.6 36.78 471297.12 728291.6 46.87 471303.06 728311.72 46.87 471303.06 728311.72 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471297.12 728291.6 36.78 471306.75 728288.69 36.78 471306.75 728288.69 46.87 471297.12 728291.6 46.87 471297.12 728291.6 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471306.75 728288.69 36.78 471312.75 728308.93 36.78 471312.75 728308.93 46.87 471306.75 728288.69 46.87 471306.75 728288.69 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471312.75 728308.93 36.78 471303.06 728311.72 36.78 471303.06 728311.72 46.87 471312.75 728308.93 46.87 471312.75 728308.93 36.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471303.06 728311.72 46.87 471297.12 728291.6 46.87 471306.75 728288.69 46.87 471312.75 728308.93 46.87 471303.06 728311.72 46.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.15</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471395.79 728312.66 31.79 471404.46 728309.63 31.79 471397.92 728290.67 31.79 471389.28 728293.68 31.79 471389.94 728295.62 31.79 471387.72 728296.38 31.79 471389.54 728301.68 31.79 471391.76 728300.92 31.79 471392.23 728302.29 31.79 471390.86 728302.75 31.79 471391.46 728304.52 31.79 471392.84 728304.05 31.79 471393.31 728305.42 31.79 471390.83 728306.27 31.79 471392.58 728311.39 31.79 471395.06 728310.53 31.79 471395.79 728312.66 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471395.79 728312.66 31.79 471395.06 728310.53 31.79 471395.06 728310.53 37.94 471395.79 728312.66 37.94 471395.79 728312.66 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471395.06 728310.53 31.79 471392.58 728311.39 31.79 471392.58 728311.39 37.94 471395.06 728310.53 37.94 471395.06 728310.53 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471392.58 728311.39 31.79 471390.83 728306.27 31.79 471390.83 728306.27 37.94 471392.58 728311.39 37.94 471392.58 728311.39 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.83 728306.27 31.79 471393.31 728305.42 31.79 471393.31 728305.42 37.94 471390.83 728306.27 37.94 471390.83 728306.27 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471393.31 728305.42 31.79 471392.84 728304.05 31.79 471392.84 728304.05 37.94 471393.31 728305.42 37.94 471393.31 728305.42 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471392.84 728304.05 31.79 471391.46 728304.52 31.79 471391.46 728304.52 37.94 471392.84 728304.05 37.94 471392.84 728304.05 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471391.46 728304.52 31.79 471390.86 728302.75 31.79 471390.86 728302.75 37.94 471391.46 728304.52 37.94 471391.46 728304.52 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471390.86 728302.75 31.79 471392.23 728302.29 31.79 471392.23 728302.29 37.94 471390.86 728302.75 37.94 471390.86 728302.75 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471392.23 728302.29 31.79 471391.76 728300.92 31.79 471391.76 728300.92 37.94 471392.23 728302.29 37.94 471392.23 728302.29 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471391.76 728300.92 31.79 471389.54 728301.68 31.79 471389.54 728301.68 37.94 471391.76 728300.92 37.94 471391.76 728300.92 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471389.54 728301.68 31.79 471387.72 728296.38 31.79 471387.72 728296.38 37.94 471389.54 728301.68 37.94 471389.54 728301.68 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471387.72 728296.38 31.79 471389.94 728295.62 31.79 471389.94 728295.62 37.94 471387.72 728296.38 37.94 471387.72 728296.38 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471389.94 728295.62 31.79 471389.28 728293.68 31.79 471389.28 728293.68 37.94 471389.94 728295.62 37.94 471389.94 728295.62 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471389.28 728293.68 31.79 471397.92 728290.67 31.79 471397.92 728290.67 37.94 471389.28 728293.68 37.94 471389.28 728293.68 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471397.92 728290.67 31.79 471404.46 728309.63 31.79 471404.46 728309.63 37.94 471397.92 728290.67 37.94 471397.92 728290.67 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471404.46 728309.63 31.79 471395.79 728312.66 31.79 471395.79 728312.66 37.94 471404.46 728309.63 37.94 471404.46 728309.63 31.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44FA-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471395.79 728312.66 37.94 471395.06 728310.53 37.94 471392.58 728311.39 37.94 471390.83 728306.27 37.94 471393.31 728305.42 37.94 471392.84 728304.05 37.94 471391.46 728304.52 37.94 471390.86 728302.75 37.94 471392.23 728302.29 37.94 471391.76 728300.92 37.94 471389.54 728301.68 37.94 471387.72 728296.38 37.94 471389.94 728295.62 37.94 471389.28 728293.68 37.94 471397.92 728290.67 37.94 471404.46 728309.63 37.94 471395.79 728312.66 37.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">11.21</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.57 728671.87 26.81 471564.33 728680.48 26.81 471568.26 728678.27 26.81 471570.1 728681.21 26.81 471572.71 728679.8 26.81 471573.43 728681.13 26.81 471576.42 728679.46 26.81 471575.71 728678.16 26.81 471578.37 728676.7 26.81 471576.67 728673.55 26.81 471580.28 728671.56 26.81 471576.82 728664.17 26.81 471576.07 728662.84 26.81 471571.47 728665.3 26.81 471571.88 728666.07 26.81 471570.97 728666.57 26.81 471570.29 728665.36 26.81 471564.79 728668.4 26.81 471565.48 728669.63 26.81 471564.57 728670.13 26.81 471564.08 728669.4 26.81 471559.57 728671.87 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.57 728671.87 26.81 471564.08 728669.4 26.81 471564.08 728669.4 38.02 471559.57 728671.87 38.02 471559.57 728671.87 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.08 728669.4 26.81 471564.57 728670.13 26.81 471564.57 728670.13 38.02 471564.08 728669.4 38.02 471564.08 728669.4 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.57 728670.13 26.81 471565.48 728669.63 26.81 471565.48 728669.63 38.02 471564.57 728670.13 38.02 471564.57 728670.13 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471565.48 728669.63 26.81 471564.79 728668.4 26.81 471564.79 728668.4 38.02 471565.48 728669.63 38.02 471565.48 728669.63 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.79 728668.4 26.81 471570.29 728665.36 26.81 471570.29 728665.36 38.02 471564.79 728668.4 38.02 471564.79 728668.4 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471570.29 728665.36 26.81 471570.97 728666.57 26.81 471570.97 728666.57 38.02 471570.29 728665.36 38.02 471570.29 728665.36 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471570.97 728666.57 26.81 471571.88 728666.07 26.81 471571.88 728666.07 38.02 471570.97 728666.57 38.02 471570.97 728666.57 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471571.88 728666.07 26.81 471571.47 728665.3 26.81 471571.47 728665.3 38.02 471571.88 728666.07 38.02 471571.88 728666.07 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471571.47 728665.3 26.81 471576.07 728662.84 26.81 471576.07 728662.84 38.02 471571.47 728665.3 38.02 471571.47 728665.3 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471576.07 728662.84 26.81 471576.82 728664.17 26.81 471576.82 728664.17 38.02 471576.07 728662.84 38.02 471576.07 728662.84 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471576.82 728664.17 26.81 471580.28 728671.56 26.81 471580.28 728671.56 38.02 471576.82 728664.17 38.02 471576.82 728664.17 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471580.28 728671.56 26.81 471576.67 728673.55 26.81 471576.67 728673.55 38.02 471580.28 728671.56 38.02 471580.28 728671.56 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471576.67 728673.55 26.81 471578.37 728676.7 26.81 471578.37 728676.7 38.02 471576.67 728673.55 38.02 471576.67 728673.55 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471578.37 728676.7 26.81 471575.71 728678.16 26.81 471575.71 728678.16 38.02 471578.37 728676.7 38.02 471578.37 728676.7 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471575.71 728678.16 26.81 471576.42 728679.46 26.81 471576.42 728679.46 38.02 471575.71 728678.16 38.02 471575.71 728678.16 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471576.42 728679.46 26.81 471573.43 728681.13 26.81 471573.43 728681.13 38.02 471576.42 728679.46 38.02 471576.42 728679.46 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471573.43 728681.13 26.81 471572.71 728679.8 26.81 471572.71 728679.8 38.02 471573.43 728681.13 38.02 471573.43 728681.13 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471572.71 728679.8 26.81 471570.1 728681.21 26.81 471570.1 728681.21 38.02 471572.71 728679.8 38.02 471572.71 728679.8 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471570.1 728681.21 26.81 471568.26 728678.27 26.81 471568.26 728678.27 38.02 471570.1 728681.21 38.02 471570.1 728681.21 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471568.26 728678.27 26.81 471564.33 728680.48 26.81 471564.33 728680.48 38.02 471568.26 728678.27 38.02 471568.26 728678.27 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471564.33 728680.48 26.81 471559.57 728671.87 26.81 471559.57 728671.87 38.02 471564.33 728680.48 38.02 471564.33 728680.48 26.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-44F9-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.57 728671.87 38.02 471564.08 728669.4 38.02 471564.57 728670.13 38.02 471565.48 728669.63 38.02 471564.79 728668.4 38.02 471570.29 728665.36 38.02 471570.97 728666.57 38.02 471571.88 728666.07 38.02 471571.47 728665.3 38.02 471576.07 728662.84 38.02 471576.82 728664.17 38.02 471580.28 728671.56 38.02 471576.67 728673.55 38.02 471578.37 728676.7 38.02 471575.71 728678.16 38.02 471576.42 728679.46 38.02 471573.43 728681.13 38.02 471572.71 728679.8 38.02 471570.1 728681.21 38.02 471568.26 728678.27 38.02 471564.33 728680.48 38.02 471559.57 728671.87 38.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-45B6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-45B6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">34.12</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471287.09 728391.26 35.75 471287.47 728406.84 35.75 471301.03 728406.51 35.75 471301.26 728408.99 35.75 471304.26 728408.9 35.75 471304.2 728406.42 35.75 471315.24 728406.16 35.75 471314.81 728390.55 35.75 471287.09 728391.26 35.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471287.09 728391.26 35.75 471314.81 728390.55 35.75 471314.81 728390.55 69.87 471287.09 728391.26 69.87 471287.09 728391.26 35.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471314.81 728390.55 35.75 471315.24 728406.16 35.75 471315.24 728406.16 69.87 471314.81 728390.55 69.87 471314.81 728390.55 35.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471315.24 728406.16 35.75 471304.2 728406.42 35.75 471304.2 728406.42 69.87 471315.24 728406.16 69.87 471315.24 728406.16 35.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.2 728406.42 35.75 471304.26 728408.9 35.75 471304.26 728408.9 69.87 471304.2 728406.42 69.87 471304.2 728406.42 35.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471304.26 728408.9 35.75 471301.26 728408.99 35.75 471301.26 728408.99 69.87 471304.26 728408.9 69.87 471304.26 728408.9 35.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B6-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471301.26 728408.99 35.75 471301.03 728406.51 35.75 471301.03 728406.51 69.87 471301.26 728408.99 69.87 471301.26 728408.99 35.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B6-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471301.03 728406.51 35.75 471287.47 728406.84 35.75 471287.47 728406.84 69.87 471301.03 728406.51 69.87 471301.03 728406.51 35.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B6-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471287.47 728406.84 35.75 471287.09 728391.26 35.75 471287.09 728391.26 69.87 471287.47 728406.84 69.87 471287.47 728406.84 35.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B6-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471287.09 728391.26 69.87 471314.81 728390.55 69.87 471315.24 728406.16 69.87 471304.2 728406.42 69.87 471304.26 728408.9 69.87 471301.26 728408.99 69.87 471301.03 728406.51 69.87 471287.47 728406.84 69.87 471287.09 728391.26 69.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-45B5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-45B5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.67</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471283.31 728317.69 38.35 471291.63 728315.16 38.35 471288.83 728306.03 38.35 471288.1 728303.57 38.35 471283.94 728304.81 38.35 471284.68 728307.27 38.35 471283.59 728307.61 38.35 471280.52 728308.54 38.35 471283.31 728317.69 38.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471283.31 728317.69 38.35 471280.52 728308.54 38.35 471280.52 728308.54 48.02 471283.31 728317.69 48.02 471283.31 728317.69 38.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471280.52 728308.54 38.35 471283.59 728307.61 38.35 471283.59 728307.61 48.02 471280.52 728308.54 48.02 471280.52 728308.54 38.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471283.59 728307.61 38.35 471284.68 728307.27 38.35 471284.68 728307.27 48.02 471283.59 728307.61 48.02 471283.59 728307.61 38.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471284.68 728307.27 38.35 471283.94 728304.81 38.35 471283.94 728304.81 48.02 471284.68 728307.27 48.02 471284.68 728307.27 38.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471283.94 728304.81 38.35 471288.1 728303.57 38.35 471288.1 728303.57 48.02 471283.94 728304.81 48.02 471283.94 728304.81 38.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471288.1 728303.57 38.35 471288.83 728306.03 38.35 471288.83 728306.03 48.02 471288.1 728303.57 48.02 471288.1 728303.57 38.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471288.83 728306.03 38.35 471291.63 728315.16 38.35 471291.63 728315.16 48.02 471288.83 728306.03 48.02 471288.83 728306.03 38.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471291.63 728315.16 38.35 471283.31 728317.69 38.35 471283.31 728317.69 48.02 471291.63 728315.16 48.02 471291.63 728315.16 38.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-45B5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471283.31 728317.69 48.02 471280.52 728308.54 48.02 471283.59 728307.61 48.02 471284.68 728307.27 48.02 471283.94 728304.81 48.02 471288.1 728303.57 48.02 471288.83 728306.03 48.02 471291.63 728315.16 48.02 471283.31 728317.69 48.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c">
			<gen:stringAttribute name="buildingId">
				<gen:value>ea77b7e7-4bcb-4d88-a2fc-202b9252e48c</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.83</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471442.13 728741.96 36.62 471436.04 728722.78 36.62 471434.65 728723.23 36.62 471432.21 728715.67 36.62 471429.81 728716.4 36.62 471432.19 728724 36.62 471416.88 728728.87 36.62 471426.01 728757.53 36.62 471441.5 728752.64 36.62 471438.47 728743.11 36.62 471442.13 728741.96 36.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471442.13 728741.96 36.62 471438.47 728743.11 36.62 471438.47 728743.11 40.45 471442.13 728741.96 40.45 471442.13 728741.96 36.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471438.47 728743.11 36.62 471441.5 728752.64 36.62 471441.5 728752.64 40.45 471438.47 728743.11 40.45 471438.47 728743.11 36.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471441.5 728752.64 36.62 471426.01 728757.53 36.62 471426.01 728757.53 40.45 471441.5 728752.64 40.45 471441.5 728752.64 36.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471426.01 728757.53 36.62 471416.88 728728.87 36.62 471416.88 728728.87 40.45 471426.01 728757.53 40.45 471426.01 728757.53 36.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471416.88 728728.87 36.62 471432.19 728724 36.62 471432.19 728724 40.45 471416.88 728728.87 40.45 471416.88 728728.87 36.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471432.19 728724 36.62 471429.81 728716.4 36.62 471429.81 728716.4 40.45 471432.19 728724 40.45 471432.19 728724 36.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471429.81 728716.4 36.62 471432.21 728715.67 36.62 471432.21 728715.67 40.45 471429.81 728716.4 40.45 471429.81 728716.4 36.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471432.21 728715.67 36.62 471434.65 728723.23 36.62 471434.65 728723.23 40.45 471432.21 728715.67 40.45 471432.21 728715.67 36.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471434.65 728723.23 36.62 471436.04 728722.78 36.62 471436.04 728722.78 40.45 471434.65 728723.23 40.45 471434.65 728723.23 36.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471436.04 728722.78 36.62 471442.13 728741.96 36.62 471442.13 728741.96 40.45 471436.04 728722.78 40.45 471436.04 728722.78 36.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ea77b7e7-4bcb-4d88-a2fc-202b9252e48c_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471442.13 728741.96 40.45 471438.47 728743.11 40.45 471441.5 728752.64 40.45 471426.01 728757.53 40.45 471416.88 728728.87 40.45 471432.19 728724 40.45 471429.81 728716.4 40.45 471432.21 728715.67 40.45 471434.65 728723.23 40.45 471436.04 728722.78 40.45 471442.13 728741.96 40.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-631D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">16.95</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471547.89 728514.04 25.36 471542.38 728515.71 25.36 471525.59 728520.83 25.36 471512.58 728479.84 25.36 471506.79 728460.91 25.36 471492.86 728465.14 25.36 471497.39 728480.27 25.36 471518.23 728547.32 25.36 471532.49 728542.92 25.36 471529.26 728532.67 25.36 471540.06 728529.34 25.36 471541.21 728533.07 25.36 471541.51 728532.97 25.36 471541.79 728533.85 25.36 471545.12 728532.83 25.36 471543.71 728528.22 25.36 471546.09 728527.48 25.36 471562.31 728578.81 25.36 471576.64 728574.75 25.36 471560.21 728523.7 25.36 471559.19 728520.52 25.36 471556.4 728511.9 25.36 471556.27 728511.48 25.36 471550.79 728513.14 25.36 471549.69 728509.72 25.36 471546.94 728510.55 25.36 471547.89 728514.04 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471547.89 728514.04 25.36 471546.94 728510.55 25.36 471546.94 728510.55 42.31 471547.89 728514.04 42.31 471547.89 728514.04 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471546.94 728510.55 25.36 471549.69 728509.72 25.36 471549.69 728509.72 42.31 471546.94 728510.55 42.31 471546.94 728510.55 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471549.69 728509.72 25.36 471550.79 728513.14 25.36 471550.79 728513.14 42.31 471549.69 728509.72 42.31 471549.69 728509.72 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471550.79 728513.14 25.36 471556.27 728511.48 25.36 471556.27 728511.48 42.31 471550.79 728513.14 42.31 471550.79 728513.14 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471556.27 728511.48 25.36 471556.4 728511.9 25.36 471556.4 728511.9 42.31 471556.27 728511.48 42.31 471556.27 728511.48 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471556.4 728511.9 25.36 471559.19 728520.52 25.36 471559.19 728520.52 42.31 471556.4 728511.9 42.31 471556.4 728511.9 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471559.19 728520.52 25.36 471560.21 728523.7 25.36 471560.21 728523.7 42.31 471559.19 728520.52 42.31 471559.19 728520.52 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471560.21 728523.7 25.36 471576.64 728574.75 25.36 471576.64 728574.75 42.31 471560.21 728523.7 42.31 471560.21 728523.7 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471576.64 728574.75 25.36 471562.31 728578.81 25.36 471562.31 728578.81 42.31 471576.64 728574.75 42.31 471576.64 728574.75 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471562.31 728578.81 25.36 471546.09 728527.48 25.36 471546.09 728527.48 42.31 471562.31 728578.81 42.31 471562.31 728578.81 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471546.09 728527.48 25.36 471543.71 728528.22 25.36 471543.71 728528.22 42.31 471546.09 728527.48 42.31 471546.09 728527.48 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471543.71 728528.22 25.36 471545.12 728532.83 25.36 471545.12 728532.83 42.31 471543.71 728528.22 42.31 471543.71 728528.22 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471545.12 728532.83 25.36 471541.79 728533.85 25.36 471541.79 728533.85 42.31 471545.12 728532.83 42.31 471545.12 728532.83 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471541.79 728533.85 25.36 471541.51 728532.97 25.36 471541.51 728532.97 42.31 471541.79 728533.85 42.31 471541.79 728533.85 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471541.51 728532.97 25.36 471541.21 728533.07 25.36 471541.21 728533.07 42.31 471541.51 728532.97 42.31 471541.51 728532.97 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471541.21 728533.07 25.36 471540.06 728529.34 25.36 471540.06 728529.34 42.31 471541.21 728533.07 42.31 471541.21 728533.07 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471540.06 728529.34 25.36 471529.26 728532.67 25.36 471529.26 728532.67 42.31 471540.06 728529.34 42.31 471540.06 728529.34 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471529.26 728532.67 25.36 471532.49 728542.92 25.36 471532.49 728542.92 42.31 471529.26 728532.67 42.31 471529.26 728532.67 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471532.49 728542.92 25.36 471518.23 728547.32 25.36 471518.23 728547.32 42.31 471532.49 728542.92 42.31 471532.49 728542.92 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471518.23 728547.32 25.36 471497.39 728480.27 25.36 471497.39 728480.27 42.31 471518.23 728547.32 42.31 471518.23 728547.32 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471497.39 728480.27 25.36 471492.86 728465.14 25.36 471492.86 728465.14 42.31 471497.39 728480.27 42.31 471497.39 728480.27 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471492.86 728465.14 25.36 471506.79 728460.91 25.36 471506.79 728460.91 42.31 471492.86 728465.14 42.31 471492.86 728465.14 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471506.79 728460.91 25.36 471512.58 728479.84 25.36 471512.58 728479.84 42.31 471506.79 728460.91 42.31 471506.79 728460.91 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471512.58 728479.84 25.36 471525.59 728520.83 25.36 471525.59 728520.83 42.31 471512.58 728479.84 42.31 471512.58 728479.84 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471525.59 728520.83 25.36 471542.38 728515.71 25.36 471542.38 728515.71 42.31 471525.59 728520.83 42.31 471525.59 728520.83 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471542.38 728515.71 25.36 471547.89 728514.04 25.36 471547.89 728514.04 42.31 471542.38 728515.71 42.31 471542.38 728515.71 25.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-631D-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471547.89 728514.04 42.31 471546.94 728510.55 42.31 471549.69 728509.72 42.31 471550.79 728513.14 42.31 471556.27 728511.48 42.31 471556.4 728511.9 42.31 471559.19 728520.52 42.31 471560.21 728523.7 42.31 471576.64 728574.75 42.31 471562.31 728578.81 42.31 471546.09 728527.48 42.31 471543.71 728528.22 42.31 471545.12 728532.83 42.31 471541.79 728533.85 42.31 471541.51 728532.97 42.31 471541.21 728533.07 42.31 471540.06 728529.34 42.31 471529.26 728532.67 42.31 471532.49 728542.92 42.31 471518.23 728547.32 42.31 471497.39 728480.27 42.31 471492.86 728465.14 42.31 471506.79 728460.91 42.31 471512.58 728479.84 42.31 471525.59 728520.83 42.31 471542.38 728515.71 42.31 471547.89 728514.04 42.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2872-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2872-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.71</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2872-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471240.46 728270.84 39.43 471237.67 728262.39 39.43 471226.44 728266.1 39.43 471229.23 728274.55 39.43 471240.46 728270.84 39.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2872-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471240.46 728270.84 39.43 471229.23 728274.55 39.43 471229.23 728274.55 47.14 471240.46 728270.84 47.14 471240.46 728270.84 39.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2872-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471229.23 728274.55 39.43 471226.44 728266.1 39.43 471226.44 728266.1 47.14 471229.23 728274.55 47.14 471229.23 728274.55 39.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2872-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471226.44 728266.1 39.43 471237.67 728262.39 39.43 471237.67 728262.39 47.14 471226.44 728266.1 47.14 471226.44 728266.1 39.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2872-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471237.67 728262.39 39.43 471240.46 728270.84 39.43 471240.46 728270.84 47.14 471237.67 728262.39 47.14 471237.67 728262.39 39.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2872-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>471240.46 728270.84 47.14 471229.23 728274.55 47.14 471226.44 728266.1 47.14 471237.67 728262.39 47.14 471240.46 728270.84 47.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
</CityModel>
<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0" xmlns="http://www.opengis.net/citygml/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
			<gml:lowerCorner>463481.45 723540.36 128.2</gml:lowerCorner>
			<gml:upperCorner>465554.87 725891.67 164</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC7A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC7A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.19</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463487.24 724884.33 128.2 463491.43 724880.96 128.2 463493.68 724883.72 128.2 463497.98 724880.33 128.2 463495.76 724877.56 128.2 463497.17 724876.44 128.2 463491.31 724869.36 128.2 463481.45 724877.28 128.2 463487.24 724884.33 128.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463487.24 724884.33 128.2 463481.45 724877.28 128.2 463481.45 724877.28 133.39000000000001 463487.24 724884.33 133.39000000000001 463487.24 724884.33 128.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463481.45 724877.28 128.2 463491.31 724869.36 128.2 463491.31 724869.36 133.39000000000001 463481.45 724877.28 133.39000000000001 463481.45 724877.28 128.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463491.31 724869.36 128.2 463497.17 724876.44 128.2 463497.17 724876.44 133.39000000000001 463491.31 724869.36 133.39000000000001 463491.31 724869.36 128.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463497.17 724876.44 128.2 463495.76 724877.56 128.2 463495.76 724877.56 133.39000000000001 463497.17 724876.44 133.39000000000001 463497.17 724876.44 128.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463495.76 724877.56 128.2 463497.98 724880.33 128.2 463497.98 724880.33 133.39000000000001 463495.76 724877.56 133.39000000000001 463495.76 724877.56 128.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463497.98 724880.33 128.2 463493.68 724883.72 128.2 463493.68 724883.72 133.39000000000001 463497.98 724880.33 133.39000000000001 463497.98 724880.33 128.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463493.68 724883.72 128.2 463491.43 724880.96 128.2 463491.43 724880.96 133.39000000000001 463493.68 724883.72 133.39000000000001 463493.68 724883.72 128.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463491.43 724880.96 128.2 463487.24 724884.33 128.2 463487.24 724884.33 133.39000000000001 463491.43 724880.96 133.39000000000001 463491.43 724880.96 128.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463487.24 724884.33 133.39000000000001 463481.45 724877.28 133.39000000000001 463491.31 724869.36 133.39000000000001 463497.17 724876.44 133.39000000000001 463495.76 724877.56 133.39000000000001 463497.98 724880.33 133.39000000000001 463493.68 724883.72 133.39000000000001 463491.43 724880.96 133.39000000000001 463487.24 724884.33 133.39000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.23</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465513.6 725554.09 139.83 465516.22 725552.62 139.83 465515.35 725551.06 139.83 465518.6 725549.21 139.83 465517.62 725547.46 139.83 465518.02 725546.33 139.83 465517.24 725544.93 139.83 465516.07 725544.67 139.83 465513.73 725540.48 139.83 465505.29 725545.23 139.83 465510.19 725553.95 139.83 465512.73 725552.52 139.83 465513.6 725554.09 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465513.6 725554.09 139.83 465512.73 725552.52 139.83 465512.73 725552.52 149.06 465513.6 725554.09 149.06 465513.6 725554.09 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465512.73 725552.52 139.83 465510.19 725553.95 139.83 465510.19 725553.95 149.06 465512.73 725552.52 149.06 465512.73 725552.52 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465510.19 725553.95 139.83 465505.29 725545.23 139.83 465505.29 725545.23 149.06 465510.19 725553.95 149.06 465510.19 725553.95 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465505.29 725545.23 139.83 465513.73 725540.48 139.83 465513.73 725540.48 149.06 465505.29 725545.23 149.06 465505.29 725545.23 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465513.73 725540.48 139.83 465516.07 725544.67 139.83 465516.07 725544.67 149.06 465513.73 725540.48 149.06 465513.73 725540.48 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465516.07 725544.67 139.83 465517.24 725544.93 139.83 465517.24 725544.93 149.06 465516.07 725544.67 149.06 465516.07 725544.67 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465517.24 725544.93 139.83 465518.02 725546.33 139.83 465518.02 725546.33 149.06 465517.24 725544.93 149.06 465517.24 725544.93 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465518.02 725546.33 139.83 465517.62 725547.46 139.83 465517.62 725547.46 149.06 465518.02 725546.33 149.06 465518.02 725546.33 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465517.62 725547.46 139.83 465518.6 725549.21 139.83 465518.6 725549.21 149.06 465517.62 725547.46 149.06 465517.62 725547.46 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465518.6 725549.21 139.83 465515.35 725551.06 139.83 465515.35 725551.06 149.06 465518.6 725549.21 149.06 465518.6 725549.21 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465515.35 725551.06 139.83 465516.22 725552.62 139.83 465516.22 725552.62 149.06 465515.35 725551.06 149.06 465515.35 725551.06 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465516.22 725552.62 139.83 465513.6 725554.09 139.83 465513.6 725554.09 149.06 465516.22 725552.62 149.06 465516.22 725552.62 139.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E44D-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465513.6 725554.09 149.06 465512.73 725552.52 149.06 465510.19 725553.95 149.06 465505.29 725545.23 149.06 465513.73 725540.48 149.06 465516.07 725544.67 149.06 465517.24 725544.93 149.06 465518.02 725546.33 149.06 465517.62 725547.46 149.06 465518.6 725549.21 149.06 465515.35 725551.06 149.06 465516.22 725552.62 149.06 465513.6 725554.09 149.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-505C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.56</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465439.03 724248.09 137.38 465447.1 724244.74 137.38 465454.77 724242.67 137.38 465459.08 724241.84 137.38 465458.56 724237.76 137.38 465465.61 724236.35 137.38 465473.15 724234.55 137.38 465480.18 724232.45 137.38 465482.03 724231.84 137.38 465487.02 724230.15 137.38 465494.04 724227.29 137.38 465494.34 724227.06 137.38 465494.31 724226.46 137.38 465494.05 724225.86 137.38 465499.45 724223.54 137.38 465499.74 724224.08 137.38 465500.04 724224.39 137.38 465500.52 724224.32 137.38 465506.35 724221.32 137.38 465512.95 724217.53 137.38 465519.07 724213.56 137.38 465525.82 724208.74 137.38 465528.39 724211.93 137.38 465531.84 724209.51 137.38 465534.53 724207.77 137.38 465539.04 724205.12 137.38 465542.26 724203.4 137.38 465544.83 724202.27 137.38 465546.73 724201.43 137.38 465545.29 724198.09 137.38 465546.48 724197.39 137.38 465547.33 724196.43 137.38 465547.92 724195.33 137.38 465548.19 724194.06 137.38 465547.79 724191.72 137.38 465547.4 724190.8 137.38 465545.45 724191.59 137.38 465544.86 724190.23 137.38 465546.8 724189.39 137.38 465544.01 724183.02 137.38 465552.7 724179.23 137.38 465550.16 724173.43 137.38 465554.87 724171.34 137.38 465552.28 724165.26 137.38 465547.42 724167.3 137.38 465544.96 724161.63 137.38 465518.44 724173.1 137.38 465520.44 724177.69 137.38 465513.2 724180.78 137.38 465513.51 724181.58 137.38 465494.13 724189.76 137.38 465493.77 724188.91 137.38 465490.04 724179.82 137.38 465468.81 724188.91 137.38 465472.75 724197.97 137.38 465473.09 724198.76 137.38 465453.91 724207.25 137.38 465453.54 724206.62 137.38 465446.23 724209.83 137.38 465444.18 724205.17 137.38 465415.42 724217.54 137.38 465420.49 724229.19 137.38 465420.59 724229.4 137.38 465423.17 724235.42 137.38 465427.53 724233.58 137.38 465429.46 724238.22 137.38 465431.43 724239.12 137.38 465434.71 724237.76 137.38 465435.87 724240.61 137.38 465435.21 724241.22 137.38 465431.57 724244.58 137.38 465432.64 724245.78 137.38 465437.09 724243.57 137.38 465437.37 724244.22 137.38 465439.03 724248.09 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465439.03 724248.09 137.38 465437.37 724244.22 137.38 465437.37 724244.22 146.94 465439.03 724248.09 146.94 465439.03 724248.09 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465437.37 724244.22 137.38 465437.09 724243.57 137.38 465437.09 724243.57 146.94 465437.37 724244.22 146.94 465437.37 724244.22 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465437.09 724243.57 137.38 465432.64 724245.78 137.38 465432.64 724245.78 146.94 465437.09 724243.57 146.94 465437.09 724243.57 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465432.64 724245.78 137.38 465431.57 724244.58 137.38 465431.57 724244.58 146.94 465432.64 724245.78 146.94 465432.64 724245.78 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465431.57 724244.58 137.38 465435.21 724241.22 137.38 465435.21 724241.22 146.94 465431.57 724244.58 146.94 465431.57 724244.58 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465435.21 724241.22 137.38 465435.87 724240.61 137.38 465435.87 724240.61 146.94 465435.21 724241.22 146.94 465435.21 724241.22 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465435.87 724240.61 137.38 465434.71 724237.76 137.38 465434.71 724237.76 146.94 465435.87 724240.61 146.94 465435.87 724240.61 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465434.71 724237.76 137.38 465431.43 724239.12 137.38 465431.43 724239.12 146.94 465434.71 724237.76 146.94 465434.71 724237.76 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465431.43 724239.12 137.38 465429.46 724238.22 137.38 465429.46 724238.22 146.94 465431.43 724239.12 146.94 465431.43 724239.12 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465429.46 724238.22 137.38 465427.53 724233.58 137.38 465427.53 724233.58 146.94 465429.46 724238.22 146.94 465429.46 724238.22 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465427.53 724233.58 137.38 465423.17 724235.42 137.38 465423.17 724235.42 146.94 465427.53 724233.58 146.94 465427.53 724233.58 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465423.17 724235.42 137.38 465420.59 724229.4 137.38 465420.59 724229.4 146.94 465423.17 724235.42 146.94 465423.17 724235.42 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465420.59 724229.4 137.38 465420.49 724229.19 137.38 465420.49 724229.19 146.94 465420.59 724229.4 146.94 465420.59 724229.4 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465420.49 724229.19 137.38 465415.42 724217.54 137.38 465415.42 724217.54 146.94 465420.49 724229.19 146.94 465420.49 724229.19 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465415.42 724217.54 137.38 465444.18 724205.17 137.38 465444.18 724205.17 146.94 465415.42 724217.54 146.94 465415.42 724217.54 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465444.18 724205.17 137.38 465446.23 724209.83 137.38 465446.23 724209.83 146.94 465444.18 724205.17 146.94 465444.18 724205.17 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465446.23 724209.83 137.38 465453.54 724206.62 137.38 465453.54 724206.62 146.94 465446.23 724209.83 146.94 465446.23 724209.83 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465453.54 724206.62 137.38 465453.91 724207.25 137.38 465453.91 724207.25 146.94 465453.54 724206.62 146.94 465453.54 724206.62 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465453.91 724207.25 137.38 465473.09 724198.76 137.38 465473.09 724198.76 146.94 465453.91 724207.25 146.94 465453.91 724207.25 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465473.09 724198.76 137.38 465472.75 724197.97 137.38 465472.75 724197.97 146.94 465473.09 724198.76 146.94 465473.09 724198.76 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465472.75 724197.97 137.38 465468.81 724188.91 137.38 465468.81 724188.91 146.94 465472.75 724197.97 146.94 465472.75 724197.97 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465468.81 724188.91 137.38 465490.04 724179.82 137.38 465490.04 724179.82 146.94 465468.81 724188.91 146.94 465468.81 724188.91 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465490.04 724179.82 137.38 465493.77 724188.91 137.38 465493.77 724188.91 146.94 465490.04 724179.82 146.94 465490.04 724179.82 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465493.77 724188.91 137.38 465494.13 724189.76 137.38 465494.13 724189.76 146.94 465493.77 724188.91 146.94 465493.77 724188.91 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465494.13 724189.76 137.38 465513.51 724181.58 137.38 465513.51 724181.58 146.94 465494.13 724189.76 146.94 465494.13 724189.76 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465513.51 724181.58 137.38 465513.2 724180.78 137.38 465513.2 724180.78 146.94 465513.51 724181.58 146.94 465513.51 724181.58 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465513.2 724180.78 137.38 465520.44 724177.69 137.38 465520.44 724177.69 146.94 465513.2 724180.78 146.94 465513.2 724180.78 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465520.44 724177.69 137.38 465518.44 724173.1 137.38 465518.44 724173.1 146.94 465520.44 724177.69 146.94 465520.44 724177.69 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465518.44 724173.1 137.38 465544.96 724161.63 137.38 465544.96 724161.63 146.94 465518.44 724173.1 146.94 465518.44 724173.1 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465544.96 724161.63 137.38 465547.42 724167.3 137.38 465547.42 724167.3 146.94 465544.96 724161.63 146.94 465544.96 724161.63 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465547.42 724167.3 137.38 465552.28 724165.26 137.38 465552.28 724165.26 146.94 465547.42 724167.3 146.94 465547.42 724167.3 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465552.28 724165.26 137.38 465554.87 724171.34 137.38 465554.87 724171.34 146.94 465552.28 724165.26 146.94 465552.28 724165.26 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465554.87 724171.34 137.38 465550.16 724173.43 137.38 465550.16 724173.43 146.94 465554.87 724171.34 146.94 465554.87 724171.34 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465550.16 724173.43 137.38 465552.7 724179.23 137.38 465552.7 724179.23 146.94 465550.16 724173.43 146.94 465550.16 724173.43 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465552.7 724179.23 137.38 465544.01 724183.02 137.38 465544.01 724183.02 146.94 465552.7 724179.23 146.94 465552.7 724179.23 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465544.01 724183.02 137.38 465546.8 724189.39 137.38 465546.8 724189.39 146.94 465544.01 724183.02 146.94 465544.01 724183.02 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465546.8 724189.39 137.38 465544.86 724190.23 137.38 465544.86 724190.23 146.94 465546.8 724189.39 146.94 465546.8 724189.39 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465544.86 724190.23 137.38 465545.45 724191.59 137.38 465545.45 724191.59 146.94 465544.86 724190.23 146.94 465544.86 724190.23 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465545.45 724191.59 137.38 465547.4 724190.8 137.38 465547.4 724190.8 146.94 465545.45 724191.59 146.94 465545.45 724191.59 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465547.4 724190.8 137.38 465547.79 724191.72 137.38 465547.79 724191.72 146.94 465547.4 724190.8 146.94 465547.4 724190.8 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465547.79 724191.72 137.38 465548.19 724194.06 137.38 465548.19 724194.06 146.94 465547.79 724191.72 146.94 465547.79 724191.72 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465548.19 724194.06 137.38 465547.92 724195.33 137.38 465547.92 724195.33 146.94 465548.19 724194.06 146.94 465548.19 724194.06 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465547.92 724195.33 137.38 465547.33 724196.43 137.38 465547.33 724196.43 146.94 465547.92 724195.33 146.94 465547.92 724195.33 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465547.33 724196.43 137.38 465546.48 724197.39 137.38 465546.48 724197.39 146.94 465547.33 724196.43 146.94 465547.33 724196.43 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465546.48 724197.39 137.38 465545.29 724198.09 137.38 465545.29 724198.09 146.94 465546.48 724197.39 146.94 465546.48 724197.39 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465545.29 724198.09 137.38 465546.73 724201.43 137.38 465546.73 724201.43 146.94 465545.29 724198.09 146.94 465545.29 724198.09 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465546.73 724201.43 137.38 465544.83 724202.27 137.38 465544.83 724202.27 146.94 465546.73 724201.43 146.94 465546.73 724201.43 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465544.83 724202.27 137.38 465542.26 724203.4 137.38 465542.26 724203.4 146.94 465544.83 724202.27 146.94 465544.83 724202.27 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465542.26 724203.4 137.38 465539.04 724205.12 137.38 465539.04 724205.12 146.94 465542.26 724203.4 146.94 465542.26 724203.4 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465539.04 724205.12 137.38 465534.53 724207.77 137.38 465534.53 724207.77 146.94 465539.04 724205.12 146.94 465539.04 724205.12 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465534.53 724207.77 137.38 465531.84 724209.51 137.38 465531.84 724209.51 146.94 465534.53 724207.77 146.94 465534.53 724207.77 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465531.84 724209.51 137.38 465528.39 724211.93 137.38 465528.39 724211.93 146.94 465531.84 724209.51 146.94 465531.84 724209.51 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465528.39 724211.93 137.38 465525.82 724208.74 137.38 465525.82 724208.74 146.94 465528.39 724211.93 146.94 465528.39 724211.93 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465525.82 724208.74 137.38 465519.07 724213.56 137.38 465519.07 724213.56 146.94 465525.82 724208.74 146.94 465525.82 724208.74 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465519.07 724213.56 137.38 465512.95 724217.53 137.38 465512.95 724217.53 146.94 465519.07 724213.56 146.94 465519.07 724213.56 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465512.95 724217.53 137.38 465506.35 724221.32 137.38 465506.35 724221.32 146.94 465512.95 724217.53 146.94 465512.95 724217.53 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465506.35 724221.32 137.38 465500.52 724224.32 137.38 465500.52 724224.32 146.94 465506.35 724221.32 146.94 465506.35 724221.32 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465500.52 724224.32 137.38 465500.04 724224.39 137.38 465500.04 724224.39 146.94 465500.52 724224.32 146.94 465500.52 724224.32 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465500.04 724224.39 137.38 465499.74 724224.08 137.38 465499.74 724224.08 146.94 465500.04 724224.39 146.94 465500.04 724224.39 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465499.74 724224.08 137.38 465499.45 724223.54 137.38 465499.45 724223.54 146.94 465499.74 724224.08 146.94 465499.74 724224.08 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465499.45 724223.54 137.38 465494.05 724225.86 137.38 465494.05 724225.86 146.94 465499.45 724223.54 146.94 465499.45 724223.54 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465494.05 724225.86 137.38 465494.31 724226.46 137.38 465494.31 724226.46 146.94 465494.05 724225.86 146.94 465494.05 724225.86 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465494.31 724226.46 137.38 465494.34 724227.06 137.38 465494.34 724227.06 146.94 465494.31 724226.46 146.94 465494.31 724226.46 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465494.34 724227.06 137.38 465494.04 724227.29 137.38 465494.04 724227.29 146.94 465494.34 724227.06 146.94 465494.34 724227.06 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465494.04 724227.29 137.38 465487.02 724230.15 137.38 465487.02 724230.15 146.94 465494.04 724227.29 146.94 465494.04 724227.29 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465487.02 724230.15 137.38 465482.03 724231.84 137.38 465482.03 724231.84 146.94 465487.02 724230.15 146.94 465487.02 724230.15 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465482.03 724231.84 137.38 465480.18 724232.45 137.38 465480.18 724232.45 146.94 465482.03 724231.84 146.94 465482.03 724231.84 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465480.18 724232.45 137.38 465473.15 724234.55 137.38 465473.15 724234.55 146.94 465480.18 724232.45 146.94 465480.18 724232.45 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465473.15 724234.55 137.38 465465.61 724236.35 137.38 465465.61 724236.35 146.94 465473.15 724234.55 146.94 465473.15 724234.55 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465465.61 724236.35 137.38 465458.56 724237.76 137.38 465458.56 724237.76 146.94 465465.61 724236.35 146.94 465465.61 724236.35 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_72">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465458.56 724237.76 137.38 465459.08 724241.84 137.38 465459.08 724241.84 146.94 465458.56 724237.76 146.94 465458.56 724237.76 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465459.08 724241.84 137.38 465454.77 724242.67 137.38 465454.77 724242.67 146.94 465459.08 724241.84 146.94 465459.08 724241.84 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_74">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465454.77 724242.67 137.38 465447.1 724244.74 137.38 465447.1 724244.74 146.94 465454.77 724242.67 146.94 465454.77 724242.67 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_75">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465447.1 724244.74 137.38 465439.03 724248.09 137.38 465439.03 724248.09 146.94 465447.1 724244.74 146.94 465447.1 724244.74 137.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-505C-FAF6-E053-CA2BA8C0FAE4_PG_76">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465439.03 724248.09 146.94 465437.37 724244.22 146.94 465437.09 724243.57 146.94 465432.64 724245.78 146.94 465431.57 724244.58 146.94 465435.21 724241.22 146.94 465435.87 724240.61 146.94 465434.71 724237.76 146.94 465431.43 724239.12 146.94 465429.46 724238.22 146.94 465427.53 724233.58 146.94 465423.17 724235.42 146.94 465420.59 724229.4 146.94 465420.49 724229.19 146.94 465415.42 724217.54 146.94 465444.18 724205.17 146.94 465446.23 724209.83 146.94 465453.54 724206.62 146.94 465453.91 724207.25 146.94 465473.09 724198.76 146.94 465472.75 724197.97 146.94 465468.81 724188.91 146.94 465490.04 724179.82 146.94 465493.77 724188.91 146.94 465494.13 724189.76 146.94 465513.51 724181.58 146.94 465513.2 724180.78 146.94 465520.44 724177.69 146.94 465518.44 724173.1 146.94 465544.96 724161.63 146.94 465547.42 724167.3 146.94 465552.28 724165.26 146.94 465554.87 724171.34 146.94 465550.16 724173.43 146.94 465552.7 724179.23 146.94 465544.01 724183.02 146.94 465546.8 724189.39 146.94 465544.86 724190.23 146.94 465545.45 724191.59 146.94 465547.4 724190.8 146.94 465547.79 724191.72 146.94 465548.19 724194.06 146.94 465547.92 724195.33 146.94 465547.33 724196.43 146.94 465546.48 724197.39 146.94 465545.29 724198.09 146.94 465546.73 724201.43 146.94 465544.83 724202.27 146.94 465542.26 724203.4 146.94 465539.04 724205.12 146.94 465534.53 724207.77 146.94 465531.84 724209.51 146.94 465528.39 724211.93 146.94 465525.82 724208.74 146.94 465519.07 724213.56 146.94 465512.95 724217.53 146.94 465506.35 724221.32 146.94 465500.52 724224.32 146.94 465500.04 724224.39 146.94 465499.74 724224.08 146.94 465499.45 724223.54 146.94 465494.05 724225.86 146.94 465494.31 724226.46 146.94 465494.34 724227.06 146.94 465494.04 724227.29 146.94 465487.02 724230.15 146.94 465482.03 724231.84 146.94 465480.18 724232.45 146.94 465473.15 724234.55 146.94 465465.61 724236.35 146.94 465458.56 724237.76 146.94 465459.08 724241.84 146.94 465454.77 724242.67 146.94 465447.1 724244.74 146.94 465439.03 724248.09 146.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db">
			<gen:stringAttribute name="buildingId">
				<gen:value>cebd500c-f864-45ff-aa95-a8b5bf48f4db</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.44</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465448.33 725875.47 141.13 465443.14 725879.79 141.13 465442.5 725879.03 141.13 465440.77 725880.46 141.13 465438.57 725877.81 141.13 465433.27 725882.24 141.13 465439.81 725890.06 141.13 465442.48 725887.83 141.13 465445.68 725891.67 141.13 465451.97 725886.42 141.13 465449.72 725883.73 141.13 465453.73 725880.39 141.13 465451.19 725877.35 141.13 465450.42 725877.99 141.13 465448.33 725875.47 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465448.33 725875.47 141.13 465450.42 725877.99 141.13 465450.42 725877.99 148.57 465448.33 725875.47 148.57 465448.33 725875.47 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465450.42 725877.99 141.13 465451.19 725877.35 141.13 465451.19 725877.35 148.57 465450.42 725877.99 148.57 465450.42 725877.99 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465451.19 725877.35 141.13 465453.73 725880.39 141.13 465453.73 725880.39 148.57 465451.19 725877.35 148.57 465451.19 725877.35 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465453.73 725880.39 141.13 465449.72 725883.73 141.13 465449.72 725883.73 148.57 465453.73 725880.39 148.57 465453.73 725880.39 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465449.72 725883.73 141.13 465451.97 725886.42 141.13 465451.97 725886.42 148.57 465449.72 725883.73 148.57 465449.72 725883.73 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465451.97 725886.42 141.13 465445.68 725891.67 141.13 465445.68 725891.67 148.57 465451.97 725886.42 148.57 465451.97 725886.42 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465445.68 725891.67 141.13 465442.48 725887.83 141.13 465442.48 725887.83 148.57 465445.68 725891.67 148.57 465445.68 725891.67 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465442.48 725887.83 141.13 465439.81 725890.06 141.13 465439.81 725890.06 148.57 465442.48 725887.83 148.57 465442.48 725887.83 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465439.81 725890.06 141.13 465433.27 725882.24 141.13 465433.27 725882.24 148.57 465439.81 725890.06 148.57 465439.81 725890.06 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465433.27 725882.24 141.13 465438.57 725877.81 141.13 465438.57 725877.81 148.57 465433.27 725882.24 148.57 465433.27 725882.24 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465438.57 725877.81 141.13 465440.77 725880.46 141.13 465440.77 725880.46 148.57 465438.57 725877.81 148.57 465438.57 725877.81 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465440.77 725880.46 141.13 465442.5 725879.03 141.13 465442.5 725879.03 148.57 465440.77 725880.46 148.57 465440.77 725880.46 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465442.5 725879.03 141.13 465443.14 725879.79 141.13 465443.14 725879.79 148.57 465442.5 725879.03 148.57 465442.5 725879.03 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465443.14 725879.79 141.13 465448.33 725875.47 141.13 465448.33 725875.47 148.57 465443.14 725879.79 148.57 465443.14 725879.79 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cebd500c-f864-45ff-aa95-a8b5bf48f4db_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465448.33 725875.47 148.57 465450.42 725877.99 148.57 465451.19 725877.35 148.57 465453.73 725880.39 148.57 465449.72 725883.73 148.57 465451.97 725886.42 148.57 465445.68 725891.67 148.57 465442.48 725887.83 148.57 465439.81 725890.06 148.57 465433.27 725882.24 148.57 465438.57 725877.81 148.57 465440.77 725880.46 148.57 465442.5 725879.03 148.57 465443.14 725879.79 148.57 465448.33 725875.47 148.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-d1e99ec0-781f-4ccb-be7f-c8fd1c493f20">
			<gen:stringAttribute name="buildingId">
				<gen:value>d1e99ec0-781f-4ccb-be7f-c8fd1c493f20</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.1</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d1e99ec0-781f-4ccb-be7f-c8fd1c493f20_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465503.79 725595.27 140.88 465508.46 725603.58 140.88 465520.13 725597.06 140.88 465519.85 725596.57 140.88 465522.67 725594.97 140.88 465518.59 725587.66 140.88 465515.61 725589.3 140.88 465515.33 725588.8 140.88 465503.79 725595.27 140.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d1e99ec0-781f-4ccb-be7f-c8fd1c493f20_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465503.79 725595.27 140.88 465515.33 725588.8 140.88 465515.33 725588.8 147.98 465503.79 725595.27 147.98 465503.79 725595.27 140.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d1e99ec0-781f-4ccb-be7f-c8fd1c493f20_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465515.33 725588.8 140.88 465515.61 725589.3 140.88 465515.61 725589.3 147.98 465515.33 725588.8 147.98 465515.33 725588.8 140.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d1e99ec0-781f-4ccb-be7f-c8fd1c493f20_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465515.61 725589.3 140.88 465518.59 725587.66 140.88 465518.59 725587.66 147.98 465515.61 725589.3 147.98 465515.61 725589.3 140.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d1e99ec0-781f-4ccb-be7f-c8fd1c493f20_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465518.59 725587.66 140.88 465522.67 725594.97 140.88 465522.67 725594.97 147.98 465518.59 725587.66 147.98 465518.59 725587.66 140.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d1e99ec0-781f-4ccb-be7f-c8fd1c493f20_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465522.67 725594.97 140.88 465519.85 725596.57 140.88 465519.85 725596.57 147.98 465522.67 725594.97 147.98 465522.67 725594.97 140.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d1e99ec0-781f-4ccb-be7f-c8fd1c493f20_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465519.85 725596.57 140.88 465520.13 725597.06 140.88 465520.13 725597.06 147.98 465519.85 725596.57 147.98 465519.85 725596.57 140.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d1e99ec0-781f-4ccb-be7f-c8fd1c493f20_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465520.13 725597.06 140.88 465508.46 725603.58 140.88 465508.46 725603.58 147.98 465520.13 725597.06 147.98 465520.13 725597.06 140.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d1e99ec0-781f-4ccb-be7f-c8fd1c493f20_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465508.46 725603.58 140.88 465503.79 725595.27 140.88 465503.79 725595.27 147.98 465508.46 725603.58 147.98 465508.46 725603.58 140.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d1e99ec0-781f-4ccb-be7f-c8fd1c493f20_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465503.79 725595.27 147.98 465515.33 725588.8 147.98 465515.61 725589.3 147.98 465518.59 725587.66 147.98 465522.67 725594.97 147.98 465519.85 725596.57 147.98 465520.13 725597.06 147.98 465508.46 725603.58 147.98 465503.79 725595.27 147.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf">
			<gen:stringAttribute name="buildingId">
				<gen:value>d18d8bce-8915-43d3-9383-a46ffba04ebf</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464278.4 723589.84 131.96 464278.59 723590 131.96 464285.1 723602.61 131.96 464289.61 723600.23 131.96 464313.37 723622.06 131.96 464347.57 723584.91 131.96 464334.61 723572.96 131.96 464341.77 723565.18 131.96 464337.96 723561.7 131.96 464340.25 723559.2 131.96 464331.78 723551.37 131.96 464334.04 723548.96 131.96 464324.73 723540.36 131.96 464320.31 723545.17 131.96 464320.98 723545.79 131.96 464318.92 723547.99 131.96 464317.91 723547.08 131.96 464314.52 723550.74 131.96 464317.16 723553.58 131.96 464317.12 723553.62 131.96 464315.92 723554.9 131.96 464312.27 723551.59 131.96 464311.77 723552.13 131.96 464312.52 723552.82 131.96 464293.3 723573.69 131.96 464278.4 723589.84 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464278.4 723589.84 131.96 464293.3 723573.69 131.96 464293.3 723573.69 140.96 464278.4 723589.84 140.96 464278.4 723589.84 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464293.3 723573.69 131.96 464312.52 723552.82 131.96 464312.52 723552.82 140.96 464293.3 723573.69 140.96 464293.3 723573.69 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464312.52 723552.82 131.96 464311.77 723552.13 131.96 464311.77 723552.13 140.96 464312.52 723552.82 140.96 464312.52 723552.82 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464311.77 723552.13 131.96 464312.27 723551.59 131.96 464312.27 723551.59 140.96 464311.77 723552.13 140.96 464311.77 723552.13 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464312.27 723551.59 131.96 464315.92 723554.9 131.96 464315.92 723554.9 140.96 464312.27 723551.59 140.96 464312.27 723551.59 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464315.92 723554.9 131.96 464317.12 723553.62 131.96 464317.12 723553.62 140.96 464315.92 723554.9 140.96 464315.92 723554.9 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464317.12 723553.62 131.96 464317.16 723553.58 131.96 464317.16 723553.58 140.96 464317.12 723553.62 140.96 464317.12 723553.62 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464317.16 723553.58 131.96 464314.52 723550.74 131.96 464314.52 723550.74 140.96 464317.16 723553.58 140.96 464317.16 723553.58 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464314.52 723550.74 131.96 464317.91 723547.08 131.96 464317.91 723547.08 140.96 464314.52 723550.74 140.96 464314.52 723550.74 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464317.91 723547.08 131.96 464318.92 723547.99 131.96 464318.92 723547.99 140.96 464317.91 723547.08 140.96 464317.91 723547.08 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464318.92 723547.99 131.96 464320.98 723545.79 131.96 464320.98 723545.79 140.96 464318.92 723547.99 140.96 464318.92 723547.99 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464320.98 723545.79 131.96 464320.31 723545.17 131.96 464320.31 723545.17 140.96 464320.98 723545.79 140.96 464320.98 723545.79 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464320.31 723545.17 131.96 464324.73 723540.36 131.96 464324.73 723540.36 140.96 464320.31 723545.17 140.96 464320.31 723545.17 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464324.73 723540.36 131.96 464334.04 723548.96 131.96 464334.04 723548.96 140.96 464324.73 723540.36 140.96 464324.73 723540.36 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464334.04 723548.96 131.96 464331.78 723551.37 131.96 464331.78 723551.37 140.96 464334.04 723548.96 140.96 464334.04 723548.96 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464331.78 723551.37 131.96 464340.25 723559.2 131.96 464340.25 723559.2 140.96 464331.78 723551.37 140.96 464331.78 723551.37 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464340.25 723559.2 131.96 464337.96 723561.7 131.96 464337.96 723561.7 140.96 464340.25 723559.2 140.96 464340.25 723559.2 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464337.96 723561.7 131.96 464341.77 723565.18 131.96 464341.77 723565.18 140.96 464337.96 723561.7 140.96 464337.96 723561.7 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464341.77 723565.18 131.96 464334.61 723572.96 131.96 464334.61 723572.96 140.96 464341.77 723565.18 140.96 464341.77 723565.18 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464334.61 723572.96 131.96 464347.57 723584.91 131.96 464347.57 723584.91 140.96 464334.61 723572.96 140.96 464334.61 723572.96 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464347.57 723584.91 131.96 464313.37 723622.06 131.96 464313.37 723622.06 140.96 464347.57 723584.91 140.96 464347.57 723584.91 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464313.37 723622.06 131.96 464289.61 723600.23 131.96 464289.61 723600.23 140.96 464313.37 723622.06 140.96 464313.37 723622.06 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464289.61 723600.23 131.96 464285.1 723602.61 131.96 464285.1 723602.61 140.96 464289.61 723600.23 140.96 464289.61 723600.23 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464285.1 723602.61 131.96 464278.59 723590 131.96 464278.59 723590 140.96 464285.1 723602.61 140.96 464285.1 723602.61 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464278.59 723590 131.96 464278.4 723589.84 131.96 464278.4 723589.84 140.96 464278.59 723590 140.96 464278.59 723590 131.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d18d8bce-8915-43d3-9383-a46ffba04ebf_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464278.4 723589.84 140.96 464293.3 723573.69 140.96 464312.52 723552.82 140.96 464311.77 723552.13 140.96 464312.27 723551.59 140.96 464315.92 723554.9 140.96 464317.12 723553.62 140.96 464317.16 723553.58 140.96 464314.52 723550.74 140.96 464317.91 723547.08 140.96 464318.92 723547.99 140.96 464320.98 723545.79 140.96 464320.31 723545.17 140.96 464324.73 723540.36 140.96 464334.04 723548.96 140.96 464331.78 723551.37 140.96 464340.25 723559.2 140.96 464337.96 723561.7 140.96 464341.77 723565.18 140.96 464334.61 723572.96 140.96 464347.57 723584.91 140.96 464313.37 723622.06 140.96 464289.61 723600.23 140.96 464285.1 723602.61 140.96 464278.59 723590 140.96 464278.4 723589.84 140.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C9DA-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C9DA-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.64</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9DA-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464244.92 724961.93 138.06 464259.99 724952.64 138.06 464255.59 724945.51 138.06 464240.44 724954.85 138.06 464244.92 724961.93 138.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9DA-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464244.92 724961.93 138.06 464240.44 724954.85 138.06 464240.44 724954.85 143.70000000000002 464244.92 724961.93 143.70000000000002 464244.92 724961.93 138.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9DA-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464240.44 724954.85 138.06 464255.59 724945.51 138.06 464255.59 724945.51 143.70000000000002 464240.44 724954.85 143.70000000000002 464240.44 724954.85 138.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9DA-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464255.59 724945.51 138.06 464259.99 724952.64 138.06 464259.99 724952.64 143.70000000000002 464255.59 724945.51 143.70000000000002 464255.59 724945.51 138.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9DA-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464259.99 724952.64 138.06 464244.92 724961.93 138.06 464244.92 724961.93 143.70000000000002 464259.99 724952.64 143.70000000000002 464259.99 724952.64 138.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9DA-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464244.92 724961.93 143.70000000000002 464240.44 724954.85 143.70000000000002 464255.59 724945.51 143.70000000000002 464259.99 724952.64 143.70000000000002 464244.92 724961.93 143.70000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E501-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.54</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465270.54 725655.1 139.48 465276.45 725652.92 139.48 465277.07 725654.61 139.48 465280.26 725653.45 139.48 465279.63 725651.75 139.48 465285.95 725649.4 139.48 465283.05 725641.59 139.48 465279.21 725643.02 139.48 465278.29 725640.45 139.48 465270.57 725643.41 139.48 465271.45 725645.91 139.48 465267.62 725647.34 139.48 465270.54 725655.1 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465270.54 725655.1 139.48 465267.62 725647.34 139.48 465267.62 725647.34 145.02 465270.54 725655.1 145.02 465270.54 725655.1 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465267.62 725647.34 139.48 465271.45 725645.91 139.48 465271.45 725645.91 145.02 465267.62 725647.34 145.02 465267.62 725647.34 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465271.45 725645.91 139.48 465270.57 725643.41 139.48 465270.57 725643.41 145.02 465271.45 725645.91 145.02 465271.45 725645.91 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465270.57 725643.41 139.48 465278.29 725640.45 139.48 465278.29 725640.45 145.02 465270.57 725643.41 145.02 465270.57 725643.41 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465278.29 725640.45 139.48 465279.21 725643.02 139.48 465279.21 725643.02 145.02 465278.29 725640.45 145.02 465278.29 725640.45 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465279.21 725643.02 139.48 465283.05 725641.59 139.48 465283.05 725641.59 145.02 465279.21 725643.02 145.02 465279.21 725643.02 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465283.05 725641.59 139.48 465285.95 725649.4 139.48 465285.95 725649.4 145.02 465283.05 725641.59 145.02 465283.05 725641.59 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465285.95 725649.4 139.48 465279.63 725651.75 139.48 465279.63 725651.75 145.02 465285.95 725649.4 145.02 465285.95 725649.4 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465279.63 725651.75 139.48 465280.26 725653.45 139.48 465280.26 725653.45 145.02 465279.63 725651.75 145.02 465279.63 725651.75 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465280.26 725653.45 139.48 465277.07 725654.61 139.48 465277.07 725654.61 145.02 465280.26 725653.45 145.02 465280.26 725653.45 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465277.07 725654.61 139.48 465276.45 725652.92 139.48 465276.45 725652.92 145.02 465277.07 725654.61 145.02 465277.07 725654.61 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465276.45 725652.92 139.48 465270.54 725655.1 139.48 465270.54 725655.1 145.02 465276.45 725652.92 145.02 465276.45 725652.92 139.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E501-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465270.54 725655.1 145.02 465267.62 725647.34 145.02 465271.45 725645.91 145.02 465270.57 725643.41 145.02 465278.29 725640.45 145.02 465279.21 725643.02 145.02 465283.05 725641.59 145.02 465285.95 725649.4 145.02 465279.63 725651.75 145.02 465280.26 725653.45 145.02 465277.07 725654.61 145.02 465276.45 725652.92 145.02 465270.54 725655.1 145.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-EC3F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-EC3F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EC3F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465434.95 725633.78 140.86 465449.51 725628.32 140.86 465446.88 725621.1 140.86 465432.27 725626.57 140.86 465434.95 725633.78 140.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EC3F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465434.95 725633.78 140.86 465432.27 725626.57 140.86 465432.27 725626.57 145.8 465434.95 725633.78 145.8 465434.95 725633.78 140.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EC3F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465432.27 725626.57 140.86 465446.88 725621.1 140.86 465446.88 725621.1 145.8 465432.27 725626.57 145.8 465432.27 725626.57 140.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EC3F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465446.88 725621.1 140.86 465449.51 725628.32 140.86 465449.51 725628.32 145.8 465446.88 725621.1 145.8 465446.88 725621.1 140.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EC3F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465449.51 725628.32 140.86 465434.95 725633.78 140.86 465434.95 725633.78 145.8 465449.51 725628.32 145.8 465449.51 725628.32 140.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EC3F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465434.95 725633.78 145.8 465432.27 725626.57 145.8 465446.88 725621.1 145.8 465449.51 725628.32 145.8 465434.95 725633.78 145.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC7C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC7C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.31</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463669.45 724150.27 132.85 463673.84 724157.87 132.85 463686.12 724150.67 132.85 463686.87 724151.93 132.85 463691.21 724149.35 132.85 463686.55 724141.51 132.85 463680.77 724145.4 132.85 463680.01 724144.11 132.85 463669.45 724150.27 132.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463669.45 724150.27 132.85 463680.01 724144.11 132.85 463680.01 724144.11 139.16 463669.45 724150.27 139.16 463669.45 724150.27 132.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463680.01 724144.11 132.85 463680.77 724145.4 132.85 463680.77 724145.4 139.16 463680.01 724144.11 139.16 463680.01 724144.11 132.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463680.77 724145.4 132.85 463686.55 724141.51 132.85 463686.55 724141.51 139.16 463680.77 724145.4 139.16 463680.77 724145.4 132.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463686.55 724141.51 132.85 463691.21 724149.35 132.85 463691.21 724149.35 139.16 463686.55 724141.51 139.16 463686.55 724141.51 132.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463691.21 724149.35 132.85 463686.87 724151.93 132.85 463686.87 724151.93 139.16 463691.21 724149.35 139.16 463691.21 724149.35 132.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463686.87 724151.93 132.85 463686.12 724150.67 132.85 463686.12 724150.67 139.16 463686.87 724151.93 139.16 463686.87 724151.93 132.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463686.12 724150.67 132.85 463673.84 724157.87 132.85 463673.84 724157.87 139.16 463686.12 724150.67 139.16 463686.12 724150.67 132.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463673.84 724157.87 132.85 463669.45 724150.27 132.85 463669.45 724150.27 139.16 463673.84 724157.87 139.16 463673.84 724157.87 132.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC7C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463669.45 724150.27 139.16 463680.01 724144.11 139.16 463680.77 724145.4 139.16 463686.55 724141.51 139.16 463691.21 724149.35 139.16 463686.87 724151.93 139.16 463686.12 724150.67 139.16 463673.84 724157.87 139.16 463669.45 724150.27 139.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C9BF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C9BF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.27</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463639.46 724144.49 132.37 463643.45 724141.54 132.37 463646.26 724139.46 132.37 463655.02 724133.76 132.37 463651.3 724128.07 132.37 463636.15 724138.6 132.37 463639.46 724144.49 132.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463639.46 724144.49 132.37 463636.15 724138.6 132.37 463636.15 724138.6 135.64000000000001 463639.46 724144.49 135.64000000000001 463639.46 724144.49 132.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463636.15 724138.6 132.37 463651.3 724128.07 132.37 463651.3 724128.07 135.64000000000001 463636.15 724138.6 135.64000000000001 463636.15 724138.6 132.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463651.3 724128.07 132.37 463655.02 724133.76 132.37 463655.02 724133.76 135.64000000000001 463651.3 724128.07 135.64000000000001 463651.3 724128.07 132.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463655.02 724133.76 132.37 463646.26 724139.46 132.37 463646.26 724139.46 135.64000000000001 463655.02 724133.76 135.64000000000001 463655.02 724133.76 132.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463646.26 724139.46 132.37 463643.45 724141.54 132.37 463643.45 724141.54 135.64000000000001 463646.26 724139.46 135.64000000000001 463646.26 724139.46 132.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463643.45 724141.54 132.37 463639.46 724144.49 132.37 463639.46 724144.49 135.64000000000001 463643.45 724141.54 135.64000000000001 463643.45 724141.54 132.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463639.46 724144.49 135.64000000000001 463636.15 724138.6 135.64000000000001 463651.3 724128.07 135.64000000000001 463655.02 724133.76 135.64000000000001 463646.26 724139.46 135.64000000000001 463643.45 724141.54 135.64000000000001 463639.46 724144.49 135.64000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.42</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465398.05 725755.03 142.36 465401.15 725752.68 142.36 465402.06 725753.89 142.36 465404.56 725751.98 142.36 465404.47 725751.85 142.36 465406.44 725750.32 142.36 465405.63 725749.25 142.36 465407.99 725747.43 142.36 465407.83 725747.21 142.36 465411.16 725744.6 142.36 465406.38 725738.39 142.36 465403.01 725740.99 142.36 465402.81 725740.7 142.36 465400.45 725742.53 142.36 465399.18 725740.85 142.36 465394.83 725744.19 142.36 465395.74 725745.38 142.36 465392.53 725747.84 142.36 465393.44 725749.03 142.36 465398.05 725755.03 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465398.05 725755.03 142.36 465393.44 725749.03 142.36 465393.44 725749.03 149.78 465398.05 725755.03 149.78 465398.05 725755.03 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465393.44 725749.03 142.36 465392.53 725747.84 142.36 465392.53 725747.84 149.78 465393.44 725749.03 149.78 465393.44 725749.03 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465392.53 725747.84 142.36 465395.74 725745.38 142.36 465395.74 725745.38 149.78 465392.53 725747.84 149.78 465392.53 725747.84 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465395.74 725745.38 142.36 465394.83 725744.19 142.36 465394.83 725744.19 149.78 465395.74 725745.38 149.78 465395.74 725745.38 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465394.83 725744.19 142.36 465399.18 725740.85 142.36 465399.18 725740.85 149.78 465394.83 725744.19 149.78 465394.83 725744.19 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465399.18 725740.85 142.36 465400.45 725742.53 142.36 465400.45 725742.53 149.78 465399.18 725740.85 149.78 465399.18 725740.85 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465400.45 725742.53 142.36 465402.81 725740.7 142.36 465402.81 725740.7 149.78 465400.45 725742.53 149.78 465400.45 725742.53 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465402.81 725740.7 142.36 465403.01 725740.99 142.36 465403.01 725740.99 149.78 465402.81 725740.7 149.78 465402.81 725740.7 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465403.01 725740.99 142.36 465406.38 725738.39 142.36 465406.38 725738.39 149.78 465403.01 725740.99 149.78 465403.01 725740.99 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465406.38 725738.39 142.36 465411.16 725744.6 142.36 465411.16 725744.6 149.78 465406.38 725738.39 149.78 465406.38 725738.39 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465411.16 725744.6 142.36 465407.83 725747.21 142.36 465407.83 725747.21 149.78 465411.16 725744.6 149.78 465411.16 725744.6 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465407.83 725747.21 142.36 465407.99 725747.43 142.36 465407.99 725747.43 149.78 465407.83 725747.21 149.78 465407.83 725747.21 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465407.99 725747.43 142.36 465405.63 725749.25 142.36 465405.63 725749.25 149.78 465407.99 725747.43 149.78 465407.99 725747.43 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465405.63 725749.25 142.36 465406.44 725750.32 142.36 465406.44 725750.32 149.78 465405.63 725749.25 149.78 465405.63 725749.25 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465406.44 725750.32 142.36 465404.47 725751.85 142.36 465404.47 725751.85 149.78 465406.44 725750.32 149.78 465406.44 725750.32 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465404.47 725751.85 142.36 465404.56 725751.98 142.36 465404.56 725751.98 149.78 465404.47 725751.85 149.78 465404.47 725751.85 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465404.56 725751.98 142.36 465402.06 725753.89 142.36 465402.06 725753.89 149.78 465404.56 725751.98 149.78 465404.56 725751.98 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465402.06 725753.89 142.36 465401.15 725752.68 142.36 465401.15 725752.68 149.78 465402.06 725753.89 149.78 465402.06 725753.89 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465401.15 725752.68 142.36 465398.05 725755.03 142.36 465398.05 725755.03 149.78 465401.15 725752.68 149.78 465401.15 725752.68 142.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E8B6-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465398.05 725755.03 149.78 465393.44 725749.03 149.78 465392.53 725747.84 149.78 465395.74 725745.38 149.78 465394.83 725744.19 149.78 465399.18 725740.85 149.78 465400.45 725742.53 149.78 465402.81 725740.7 149.78 465403.01 725740.99 149.78 465406.38 725738.39 149.78 465411.16 725744.6 149.78 465407.83 725747.21 149.78 465407.99 725747.43 149.78 465405.63 725749.25 149.78 465406.44 725750.32 149.78 465404.47 725751.85 149.78 465404.56 725751.98 149.78 465402.06 725753.89 149.78 465401.15 725752.68 149.78 465398.05 725755.03 149.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C5EE-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C5EE-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.06</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C5EE-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464082.32 723630.42 131.34 464090.49 723624.57 131.34 464083.18 723614.96 131.34 464078.44 723618.32 131.34 464075.09 723620.86 131.34 464082.32 723630.42 131.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C5EE-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464082.32 723630.42 131.34 464075.09 723620.86 131.34 464075.09 723620.86 136.4 464082.32 723630.42 136.4 464082.32 723630.42 131.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C5EE-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464075.09 723620.86 131.34 464078.44 723618.32 131.34 464078.44 723618.32 136.4 464075.09 723620.86 136.4 464075.09 723620.86 131.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C5EE-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464078.44 723618.32 131.34 464083.18 723614.96 131.34 464083.18 723614.96 136.4 464078.44 723618.32 136.4 464078.44 723618.32 131.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C5EE-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464083.18 723614.96 131.34 464090.49 723624.57 131.34 464090.49 723624.57 136.4 464083.18 723614.96 136.4 464083.18 723614.96 131.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C5EE-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464090.49 723624.57 131.34 464082.32 723630.42 131.34 464082.32 723630.42 136.4 464090.49 723624.57 136.4 464090.49 723624.57 131.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C5EE-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464082.32 723630.42 136.4 464075.09 723620.86 136.4 464078.44 723618.32 136.4 464083.18 723614.96 136.4 464090.49 723624.57 136.4 464082.32 723630.42 136.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-EF68-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-EF68-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.87</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EF68-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465390.31 725613.75 139.82 465400.23 725610.03 139.82 465400.45 725610.59 139.82 465404.31 725609.14 139.82 465401.22 725600.84 139.82 465397.82 725602.11 139.82 465397.54 725601.36 139.82 465387.13 725605.26 139.82 465390.31 725613.75 139.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EF68-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465390.31 725613.75 139.82 465387.13 725605.26 139.82 465387.13 725605.26 146.69 465390.31 725613.75 146.69 465390.31 725613.75 139.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EF68-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465387.13 725605.26 139.82 465397.54 725601.36 139.82 465397.54 725601.36 146.69 465387.13 725605.26 146.69 465387.13 725605.26 139.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EF68-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465397.54 725601.36 139.82 465397.82 725602.11 139.82 465397.82 725602.11 146.69 465397.54 725601.36 146.69 465397.54 725601.36 139.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EF68-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465397.82 725602.11 139.82 465401.22 725600.84 139.82 465401.22 725600.84 146.69 465397.82 725602.11 146.69 465397.82 725602.11 139.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EF68-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465401.22 725600.84 139.82 465404.31 725609.14 139.82 465404.31 725609.14 146.69 465401.22 725600.84 146.69 465401.22 725600.84 139.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EF68-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465404.31 725609.14 139.82 465400.45 725610.59 139.82 465400.45 725610.59 146.69 465404.31 725609.14 146.69 465404.31 725609.14 139.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EF68-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465400.45 725610.59 139.82 465400.23 725610.03 139.82 465400.23 725610.03 146.69 465400.45 725610.59 146.69 465400.45 725610.59 139.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EF68-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465400.23 725610.03 139.82 465390.31 725613.75 139.82 465390.31 725613.75 146.69 465400.23 725610.03 146.69 465400.23 725610.03 139.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EF68-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465390.31 725613.75 146.69 465387.13 725605.26 146.69 465397.54 725601.36 146.69 465397.82 725602.11 146.69 465401.22 725600.84 146.69 465404.31 725609.14 146.69 465400.45 725610.59 146.69 465400.23 725610.03 146.69 465390.31 725613.75 146.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A9C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A9C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.97</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A9C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464480.93 723913.93 136.68 464512.32 723901.59 136.68 464507.77 723889.99 136.68 464476.26 723902.37 136.68 464480.93 723913.93 136.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A9C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464480.93 723913.93 136.68 464476.26 723902.37 136.68 464476.26 723902.37 142.65 464480.93 723913.93 142.65 464480.93 723913.93 136.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A9C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464476.26 723902.37 136.68 464507.77 723889.99 136.68 464507.77 723889.99 142.65 464476.26 723902.37 142.65 464476.26 723902.37 136.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A9C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464507.77 723889.99 136.68 464512.32 723901.59 136.68 464512.32 723901.59 142.65 464507.77 723889.99 142.65 464507.77 723889.99 136.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A9C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464512.32 723901.59 136.68 464480.93 723913.93 136.68 464480.93 723913.93 142.65 464512.32 723901.59 142.65 464512.32 723901.59 136.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A9C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464480.93 723913.93 142.65 464476.26 723902.37 142.65 464507.77 723889.99 142.65 464512.32 723901.59 142.65 464480.93 723913.93 142.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5C65-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5C65-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.78</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C65-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464078.44 723618.32 131.33 464083.18 723614.96 131.33 464085.38 723613.42 131.33 464083.15 723609.18 131.33 464078.47 723611.35 131.33 464075.71 723612.78 131.33 464078.44 723618.32 131.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C65-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464078.44 723618.32 131.33 464075.71 723612.78 131.33 464075.71 723612.78 135.11 464078.44 723618.32 135.11 464078.44 723618.32 131.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C65-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464075.71 723612.78 131.33 464078.47 723611.35 131.33 464078.47 723611.35 135.11 464075.71 723612.78 135.11 464075.71 723612.78 131.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C65-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464078.47 723611.35 131.33 464083.15 723609.18 131.33 464083.15 723609.18 135.11 464078.47 723611.35 135.11 464078.47 723611.35 131.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C65-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464083.15 723609.18 131.33 464085.38 723613.42 131.33 464085.38 723613.42 135.11 464083.15 723609.18 135.11 464083.15 723609.18 131.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C65-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464085.38 723613.42 131.33 464083.18 723614.96 131.33 464083.18 723614.96 135.11 464085.38 723613.42 135.11 464085.38 723613.42 131.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C65-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464083.18 723614.96 131.33 464078.44 723618.32 131.33 464078.44 723618.32 135.11 464083.18 723614.96 135.11 464083.18 723614.96 131.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C65-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464078.44 723618.32 135.11 464075.71 723612.78 135.11 464078.47 723611.35 135.11 464083.15 723609.18 135.11 464085.38 723613.42 135.11 464083.18 723614.96 135.11 464078.44 723618.32 135.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.91</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464240.23 724935.04 138.14 464246.6 724931.39 138.14 464245.38 724929.28 138.14 464251.59 724925.69 138.14 464249.58 724922.15 138.14 464251.1 724921.28 138.14 464249.89 724919.07 138.14 464248.34 724919.94 138.14 464246.92 724917.42 138.14 464234.28 724924.67 138.14 464240.23 724935.04 138.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464240.23 724935.04 138.14 464234.28 724924.67 138.14 464234.28 724924.67 145.05 464240.23 724935.04 145.05 464240.23 724935.04 138.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464234.28 724924.67 138.14 464246.92 724917.42 138.14 464246.92 724917.42 145.05 464234.28 724924.67 145.05 464234.28 724924.67 138.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464246.92 724917.42 138.14 464248.34 724919.94 138.14 464248.34 724919.94 145.05 464246.92 724917.42 145.05 464246.92 724917.42 138.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464248.34 724919.94 138.14 464249.89 724919.07 138.14 464249.89 724919.07 145.05 464248.34 724919.94 145.05 464248.34 724919.94 138.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464249.89 724919.07 138.14 464251.1 724921.28 138.14 464251.1 724921.28 145.05 464249.89 724919.07 145.05 464249.89 724919.07 138.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464251.1 724921.28 138.14 464249.58 724922.15 138.14 464249.58 724922.15 145.05 464251.1 724921.28 145.05 464251.1 724921.28 138.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464249.58 724922.15 138.14 464251.59 724925.69 138.14 464251.59 724925.69 145.05 464249.58 724922.15 145.05 464249.58 724922.15 138.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464251.59 724925.69 138.14 464245.38 724929.28 138.14 464245.38 724929.28 145.05 464251.59 724925.69 145.05 464251.59 724925.69 138.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464245.38 724929.28 138.14 464246.6 724931.39 138.14 464246.6 724931.39 145.05 464245.38 724929.28 145.05 464245.38 724929.28 138.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464246.6 724931.39 138.14 464240.23 724935.04 138.14 464240.23 724935.04 145.05 464246.6 724931.39 145.05 464246.6 724931.39 138.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB17-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464240.23 724935.04 145.05 464234.28 724924.67 145.05 464246.92 724917.42 145.05 464248.34 724919.94 145.05 464249.89 724919.07 145.05 464251.1 724921.28 145.05 464249.58 724922.15 145.05 464251.59 724925.69 145.05 464245.38 724929.28 145.05 464246.6 724931.39 145.05 464240.23 724935.04 145.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C1ED-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C1ED-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.97</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1ED-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464501.41 724719.04 137.52 464520.67 724702.99 137.52 464515.61 724696.92 137.52 464496.33 724712.98 137.52 464501.41 724719.04 137.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1ED-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464501.41 724719.04 137.52 464496.33 724712.98 137.52 464496.33 724712.98 142.49 464501.41 724719.04 142.49 464501.41 724719.04 137.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1ED-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464496.33 724712.98 137.52 464515.61 724696.92 137.52 464515.61 724696.92 142.49 464496.33 724712.98 142.49 464496.33 724712.98 137.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1ED-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464515.61 724696.92 137.52 464520.67 724702.99 137.52 464520.67 724702.99 142.49 464515.61 724696.92 142.49 464515.61 724696.92 137.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1ED-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464520.67 724702.99 137.52 464501.41 724719.04 137.52 464501.41 724719.04 142.49 464520.67 724702.99 142.49 464520.67 724702.99 137.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1ED-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464501.41 724719.04 142.49 464496.33 724712.98 142.49 464515.61 724696.92 142.49 464520.67 724702.99 142.49 464501.41 724719.04 142.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-BED6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-BED6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BED6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465504.36 725511.64 140.67 465509.7 725508.93 140.67 465504.5 725498.72 140.67 465499.16 725501.43 140.67 465504.36 725511.64 140.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BED6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465504.36 725511.64 140.67 465499.16 725501.43 140.67 465499.16 725501.43 143.46 465504.36 725511.64 143.46 465504.36 725511.64 140.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BED6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465499.16 725501.43 140.67 465504.5 725498.72 140.67 465504.5 725498.72 143.46 465499.16 725501.43 143.46 465499.16 725501.43 140.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BED6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465504.5 725498.72 140.67 465509.7 725508.93 140.67 465509.7 725508.93 143.46 465504.5 725498.72 143.46 465504.5 725498.72 140.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BED6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465509.7 725508.93 140.67 465504.36 725511.64 140.67 465504.36 725511.64 143.46 465509.7 725508.93 143.46 465509.7 725508.93 140.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BED6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465504.36 725511.64 143.46 465499.16 725501.43 143.46 465504.5 725498.72 143.46 465509.7 725508.93 143.46 465504.36 725511.64 143.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C435-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C435-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.51</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C435-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464187.77 723606.22 132.27 464213.76 723595.39 132.27 464214.91 723598.17 132.27 464217.78 723596.97 132.27 464213.71 723587.22 132.27 464184.87 723599.24 132.27 464187.77 723606.22 132.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C435-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464187.77 723606.22 132.27 464184.87 723599.24 132.27 464184.87 723599.24 139.78 464187.77 723606.22 139.78 464187.77 723606.22 132.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C435-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464184.87 723599.24 132.27 464213.71 723587.22 132.27 464213.71 723587.22 139.78 464184.87 723599.24 139.78 464184.87 723599.24 132.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C435-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464213.71 723587.22 132.27 464217.78 723596.97 132.27 464217.78 723596.97 139.78 464213.71 723587.22 139.78 464213.71 723587.22 132.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C435-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464217.78 723596.97 132.27 464214.91 723598.17 132.27 464214.91 723598.17 139.78 464217.78 723596.97 139.78 464217.78 723596.97 132.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C435-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464214.91 723598.17 132.27 464213.76 723595.39 132.27 464213.76 723595.39 139.78 464214.91 723598.17 139.78 464214.91 723598.17 132.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C435-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464213.76 723595.39 132.27 464187.77 723606.22 132.27 464187.77 723606.22 139.78 464213.76 723595.39 139.78 464213.76 723595.39 132.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C435-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464187.77 723606.22 139.78 464184.87 723599.24 139.78 464213.71 723587.22 139.78 464217.78 723596.97 139.78 464214.91 723598.17 139.78 464213.76 723595.39 139.78 464187.77 723606.22 139.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.78</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465370.63 725774.14 141.82 465374.24 725771.38 141.82 465374.28 725770.7 141.82 465375.9 725769.46 141.82 465378.96 725773.45 141.82 465384.17 725769.47 141.82 465375.43 725758.12 141.82 465364.68 725766.4 141.82 465366.68 725768.98 141.82 465365.89 725769.51 141.82 465367.9 725772.14 141.82 465368.66 725771.56 141.82 465370.63 725774.14 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465370.63 725774.14 141.82 465368.66 725771.56 141.82 465368.66 725771.56 148.6 465370.63 725774.14 148.6 465370.63 725774.14 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465368.66 725771.56 141.82 465367.9 725772.14 141.82 465367.9 725772.14 148.6 465368.66 725771.56 148.6 465368.66 725771.56 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465367.9 725772.14 141.82 465365.89 725769.51 141.82 465365.89 725769.51 148.6 465367.9 725772.14 148.6 465367.9 725772.14 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465365.89 725769.51 141.82 465366.68 725768.98 141.82 465366.68 725768.98 148.6 465365.89 725769.51 148.6 465365.89 725769.51 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465366.68 725768.98 141.82 465364.68 725766.4 141.82 465364.68 725766.4 148.6 465366.68 725768.98 148.6 465366.68 725768.98 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465364.68 725766.4 141.82 465375.43 725758.12 141.82 465375.43 725758.12 148.6 465364.68 725766.4 148.6 465364.68 725766.4 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465375.43 725758.12 141.82 465384.17 725769.47 141.82 465384.17 725769.47 148.6 465375.43 725758.12 148.6 465375.43 725758.12 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465384.17 725769.47 141.82 465378.96 725773.45 141.82 465378.96 725773.45 148.6 465384.17 725769.47 148.6 465384.17 725769.47 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465378.96 725773.45 141.82 465375.9 725769.46 141.82 465375.9 725769.46 148.6 465378.96 725773.45 148.6 465378.96 725773.45 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465375.9 725769.46 141.82 465374.28 725770.7 141.82 465374.28 725770.7 148.6 465375.9 725769.46 148.6 465375.9 725769.46 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465374.28 725770.7 141.82 465374.24 725771.38 141.82 465374.24 725771.38 148.6 465374.28 725770.7 148.6 465374.28 725770.7 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465374.24 725771.38 141.82 465370.63 725774.14 141.82 465370.63 725774.14 148.6 465374.24 725771.38 148.6 465374.24 725771.38 141.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F4E-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465370.63 725774.14 148.6 465368.66 725771.56 148.6 465367.9 725772.14 148.6 465365.89 725769.51 148.6 465366.68 725768.98 148.6 465364.68 725766.4 148.6 465375.43 725758.12 148.6 465384.17 725769.47 148.6 465378.96 725773.45 148.6 465375.9 725769.46 148.6 465374.28 725770.7 148.6 465374.24 725771.38 148.6 465370.63 725774.14 148.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">18.24</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465288.08 724795.51 136.81 465273.35 724805.52 136.81 465273.26 724805.39 136.81 465271.93 724806.3 136.81 465272.86 724807.65 136.81 465272.98 724807.57 136.81 465289.4 724831.72 136.81 465289.26 724831.8 136.81 465290.11 724833.05 136.81 465276.84 724842.06 136.81 465276 724840.81 136.81 465275.86 724840.9 136.81 465258.69 724815.6 136.81 465251.04 724804.34 136.81 465251.17 724804.26 136.81 465250.33 724803.02 136.81 465234.13 724814.02 136.81 465234.97 724815.26 136.81 465235.09 724815.16 136.81 465242.74 724826.38 136.81 465277.85 724877.84 136.81 465277.72 724877.92 136.81 465278.55 724879.17 136.81 465294.81 724868.52 136.81 465294.04 724867.35 136.81 465293.95 724867.41 136.81 465289.64 724860.88 136.81 465303.58 724851.7 136.81 465307.82 724858.28 136.81 465307.71 724858.34 136.81 465308.47 724859.52 136.81 465324.63 724849.11 136.81 465323.81 724847.84 136.81 465323.68 724847.92 136.81 465288.08 724795.51 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465288.08 724795.51 136.81 465323.68 724847.92 136.81 465323.68 724847.92 155.05 465288.08 724795.51 155.05 465288.08 724795.51 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465323.68 724847.92 136.81 465323.81 724847.84 136.81 465323.81 724847.84 155.05 465323.68 724847.92 155.05 465323.68 724847.92 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465323.81 724847.84 136.81 465324.63 724849.11 136.81 465324.63 724849.11 155.05 465323.81 724847.84 155.05 465323.81 724847.84 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465324.63 724849.11 136.81 465308.47 724859.52 136.81 465308.47 724859.52 155.05 465324.63 724849.11 155.05 465324.63 724849.11 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465308.47 724859.52 136.81 465307.71 724858.34 136.81 465307.71 724858.34 155.05 465308.47 724859.52 155.05 465308.47 724859.52 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465307.71 724858.34 136.81 465307.82 724858.28 136.81 465307.82 724858.28 155.05 465307.71 724858.34 155.05 465307.71 724858.34 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465307.82 724858.28 136.81 465303.58 724851.7 136.81 465303.58 724851.7 155.05 465307.82 724858.28 155.05 465307.82 724858.28 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465303.58 724851.7 136.81 465289.64 724860.88 136.81 465289.64 724860.88 155.05 465303.58 724851.7 155.05 465303.58 724851.7 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465289.64 724860.88 136.81 465293.95 724867.41 136.81 465293.95 724867.41 155.05 465289.64 724860.88 155.05 465289.64 724860.88 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465293.95 724867.41 136.81 465294.04 724867.35 136.81 465294.04 724867.35 155.05 465293.95 724867.41 155.05 465293.95 724867.41 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465294.04 724867.35 136.81 465294.81 724868.52 136.81 465294.81 724868.52 155.05 465294.04 724867.35 155.05 465294.04 724867.35 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465294.81 724868.52 136.81 465278.55 724879.17 136.81 465278.55 724879.17 155.05 465294.81 724868.52 155.05 465294.81 724868.52 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465278.55 724879.17 136.81 465277.72 724877.92 136.81 465277.72 724877.92 155.05 465278.55 724879.17 155.05 465278.55 724879.17 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465277.72 724877.92 136.81 465277.85 724877.84 136.81 465277.85 724877.84 155.05 465277.72 724877.92 155.05 465277.72 724877.92 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465277.85 724877.84 136.81 465242.74 724826.38 136.81 465242.74 724826.38 155.05 465277.85 724877.84 155.05 465277.85 724877.84 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465242.74 724826.38 136.81 465235.09 724815.16 136.81 465235.09 724815.16 155.05 465242.74 724826.38 155.05 465242.74 724826.38 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465235.09 724815.16 136.81 465234.97 724815.26 136.81 465234.97 724815.26 155.05 465235.09 724815.16 155.05 465235.09 724815.16 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465234.97 724815.26 136.81 465234.13 724814.02 136.81 465234.13 724814.02 155.05 465234.97 724815.26 155.05 465234.97 724815.26 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465234.13 724814.02 136.81 465250.33 724803.02 136.81 465250.33 724803.02 155.05 465234.13 724814.02 155.05 465234.13 724814.02 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465250.33 724803.02 136.81 465251.17 724804.26 136.81 465251.17 724804.26 155.05 465250.33 724803.02 155.05 465250.33 724803.02 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465251.17 724804.26 136.81 465251.04 724804.34 136.81 465251.04 724804.34 155.05 465251.17 724804.26 155.05 465251.17 724804.26 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465251.04 724804.34 136.81 465258.69 724815.6 136.81 465258.69 724815.6 155.05 465251.04 724804.34 155.05 465251.04 724804.34 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465258.69 724815.6 136.81 465275.86 724840.9 136.81 465275.86 724840.9 155.05 465258.69 724815.6 155.05 465258.69 724815.6 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465275.86 724840.9 136.81 465276 724840.81 136.81 465276 724840.81 155.05 465275.86 724840.9 155.05 465275.86 724840.9 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465276 724840.81 136.81 465276.84 724842.06 136.81 465276.84 724842.06 155.05 465276 724840.81 155.05 465276 724840.81 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465276.84 724842.06 136.81 465290.11 724833.05 136.81 465290.11 724833.05 155.05 465276.84 724842.06 155.05 465276.84 724842.06 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465290.11 724833.05 136.81 465289.26 724831.8 136.81 465289.26 724831.8 155.05 465290.11 724833.05 155.05 465290.11 724833.05 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465289.26 724831.8 136.81 465289.4 724831.72 136.81 465289.4 724831.72 155.05 465289.26 724831.8 155.05 465289.26 724831.8 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465289.4 724831.72 136.81 465272.98 724807.57 136.81 465272.98 724807.57 155.05 465289.4 724831.72 155.05 465289.4 724831.72 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465272.98 724807.57 136.81 465272.86 724807.65 136.81 465272.86 724807.65 155.05 465272.98 724807.57 155.05 465272.98 724807.57 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465272.86 724807.65 136.81 465271.93 724806.3 136.81 465271.93 724806.3 155.05 465272.86 724807.65 155.05 465272.86 724807.65 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465271.93 724806.3 136.81 465273.26 724805.39 136.81 465273.26 724805.39 155.05 465271.93 724806.3 155.05 465271.93 724806.3 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465273.26 724805.39 136.81 465273.35 724805.52 136.81 465273.35 724805.52 155.05 465273.26 724805.39 155.05 465273.26 724805.39 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465273.35 724805.52 136.81 465288.08 724795.51 136.81 465288.08 724795.51 155.05 465273.35 724805.52 155.05 465273.35 724805.52 136.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5D0C-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465288.08 724795.51 155.05 465323.68 724847.92 155.05 465323.81 724847.84 155.05 465324.63 724849.11 155.05 465308.47 724859.52 155.05 465307.71 724858.34 155.05 465307.82 724858.28 155.05 465303.58 724851.7 155.05 465289.64 724860.88 155.05 465293.95 724867.41 155.05 465294.04 724867.35 155.05 465294.81 724868.52 155.05 465278.55 724879.17 155.05 465277.72 724877.92 155.05 465277.85 724877.84 155.05 465242.74 724826.38 155.05 465235.09 724815.16 155.05 465234.97 724815.26 155.05 465234.13 724814.02 155.05 465250.33 724803.02 155.05 465251.17 724804.26 155.05 465251.04 724804.34 155.05 465258.69 724815.6 155.05 465275.86 724840.9 155.05 465276 724840.81 155.05 465276.84 724842.06 155.05 465290.11 724833.05 155.05 465289.26 724831.8 155.05 465289.4 724831.72 155.05 465272.98 724807.57 155.05 465272.86 724807.65 155.05 465271.93 724806.3 155.05 465273.26 724805.39 155.05 465273.35 724805.52 155.05 465288.08 724795.51 155.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C6AF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C6AF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.45</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C6AF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464090.49 723624.57 131.44 464094.09 723621.86 131.44 464086.88 723612.31 131.44 464085.38 723613.42 131.44 464083.18 723614.96 131.44 464090.49 723624.57 131.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C6AF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464090.49 723624.57 131.44 464083.18 723614.96 131.44 464083.18 723614.96 135.89000000000001 464090.49 723624.57 135.89000000000001 464090.49 723624.57 131.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C6AF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464083.18 723614.96 131.44 464085.38 723613.42 131.44 464085.38 723613.42 135.89000000000001 464083.18 723614.96 135.89000000000001 464083.18 723614.96 131.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C6AF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464085.38 723613.42 131.44 464086.88 723612.31 131.44 464086.88 723612.31 135.89000000000001 464085.38 723613.42 135.89000000000001 464085.38 723613.42 131.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C6AF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464086.88 723612.31 131.44 464094.09 723621.86 131.44 464094.09 723621.86 135.89000000000001 464086.88 723612.31 135.89000000000001 464086.88 723612.31 131.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C6AF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464094.09 723621.86 131.44 464090.49 723624.57 131.44 464090.49 723624.57 135.89000000000001 464094.09 723621.86 135.89000000000001 464094.09 723621.86 131.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C6AF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464090.49 723624.57 135.89000000000001 464083.18 723614.96 135.89000000000001 464085.38 723613.42 135.89000000000001 464086.88 723612.31 135.89000000000001 464094.09 723621.86 135.89000000000001 464090.49 723624.57 135.89000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C693-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C693-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.78</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C693-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464058.94 723630.06 130.54 464063.92 723628.26 130.54 464063.05 723625.72 130.54 464064.1 723625.35 130.54 464057.7 723606.07 130.54 464051.32 723608.06 130.54 464058.94 723630.06 130.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C693-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464058.94 723630.06 130.54 464051.32 723608.06 130.54 464051.32 723608.06 135.32 464058.94 723630.06 135.32 464058.94 723630.06 130.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C693-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464051.32 723608.06 130.54 464057.7 723606.07 130.54 464057.7 723606.07 135.32 464051.32 723608.06 135.32 464051.32 723608.06 130.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C693-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464057.7 723606.07 130.54 464064.1 723625.35 130.54 464064.1 723625.35 135.32 464057.7 723606.07 135.32 464057.7 723606.07 130.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C693-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464064.1 723625.35 130.54 464063.05 723625.72 130.54 464063.05 723625.72 135.32 464064.1 723625.35 135.32 464064.1 723625.35 130.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C693-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464063.05 723625.72 130.54 464063.92 723628.26 130.54 464063.92 723628.26 135.32 464063.05 723625.72 135.32 464063.05 723625.72 130.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C693-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464063.92 723628.26 130.54 464058.94 723630.06 130.54 464058.94 723630.06 135.32 464063.92 723628.26 135.32 464063.92 723628.26 130.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C693-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464058.94 723630.06 135.32 464051.32 723608.06 135.32 464057.7 723606.07 135.32 464064.1 723625.35 135.32 464063.05 723625.72 135.32 464063.92 723628.26 135.32 464058.94 723630.06 135.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C530-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.12</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465396.75 725641.42 141.26 465397.26 725642.76 141.26 465398.53 725643.35 141.26 465400.13 725647.55 141.26 465403.69 725646.2 141.26 465404.06 725647.17 141.26 465408.05 725645.67 141.26 465407.68 725644.68 141.26 465410.75 725643.52 141.26 465411.08 725644.37 141.26 465414.81 725642.95 141.26 465412.41 725636.6 141.26 465409.15 725637.84 141.26 465407.91 725634.43 141.26 465404.79 725635.6 141.26 465404.44 725634.69 141.26 465399.53 725636.52 141.26 465399.87 725637.44 141.26 465396.72 725638.59 141.26 465397.31 725640.19 141.26 465396.75 725641.42 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465396.75 725641.42 141.26 465397.31 725640.19 141.26 465397.31 725640.19 147.38 465396.75 725641.42 147.38 465396.75 725641.42 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465397.31 725640.19 141.26 465396.72 725638.59 141.26 465396.72 725638.59 147.38 465397.31 725640.19 147.38 465397.31 725640.19 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465396.72 725638.59 141.26 465399.87 725637.44 141.26 465399.87 725637.44 147.38 465396.72 725638.59 147.38 465396.72 725638.59 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465399.87 725637.44 141.26 465399.53 725636.52 141.26 465399.53 725636.52 147.38 465399.87 725637.44 147.38 465399.87 725637.44 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465399.53 725636.52 141.26 465404.44 725634.69 141.26 465404.44 725634.69 147.38 465399.53 725636.52 147.38 465399.53 725636.52 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465404.44 725634.69 141.26 465404.79 725635.6 141.26 465404.79 725635.6 147.38 465404.44 725634.69 147.38 465404.44 725634.69 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465404.79 725635.6 141.26 465407.91 725634.43 141.26 465407.91 725634.43 147.38 465404.79 725635.6 147.38 465404.79 725635.6 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465407.91 725634.43 141.26 465409.15 725637.84 141.26 465409.15 725637.84 147.38 465407.91 725634.43 147.38 465407.91 725634.43 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465409.15 725637.84 141.26 465412.41 725636.6 141.26 465412.41 725636.6 147.38 465409.15 725637.84 147.38 465409.15 725637.84 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465412.41 725636.6 141.26 465414.81 725642.95 141.26 465414.81 725642.95 147.38 465412.41 725636.6 147.38 465412.41 725636.6 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465414.81 725642.95 141.26 465411.08 725644.37 141.26 465411.08 725644.37 147.38 465414.81 725642.95 147.38 465414.81 725642.95 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465411.08 725644.37 141.26 465410.75 725643.52 141.26 465410.75 725643.52 147.38 465411.08 725644.37 147.38 465411.08 725644.37 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465410.75 725643.52 141.26 465407.68 725644.68 141.26 465407.68 725644.68 147.38 465410.75 725643.52 147.38 465410.75 725643.52 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465407.68 725644.68 141.26 465408.05 725645.67 141.26 465408.05 725645.67 147.38 465407.68 725644.68 147.38 465407.68 725644.68 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465408.05 725645.67 141.26 465404.06 725647.17 141.26 465404.06 725647.17 147.38 465408.05 725645.67 147.38 465408.05 725645.67 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465404.06 725647.17 141.26 465403.69 725646.2 141.26 465403.69 725646.2 147.38 465404.06 725647.17 147.38 465404.06 725647.17 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465403.69 725646.2 141.26 465400.13 725647.55 141.26 465400.13 725647.55 147.38 465403.69 725646.2 147.38 465403.69 725646.2 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465400.13 725647.55 141.26 465398.53 725643.35 141.26 465398.53 725643.35 147.38 465400.13 725647.55 147.38 465400.13 725647.55 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465398.53 725643.35 141.26 465397.26 725642.76 141.26 465397.26 725642.76 147.38 465398.53 725643.35 147.38 465398.53 725643.35 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465397.26 725642.76 141.26 465396.75 725641.42 141.26 465396.75 725641.42 147.38 465397.26 725642.76 147.38 465397.26 725642.76 141.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C530-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465396.75 725641.42 147.38 465397.31 725640.19 147.38 465396.72 725638.59 147.38 465399.87 725637.44 147.38 465399.53 725636.52 147.38 465404.44 725634.69 147.38 465404.79 725635.6 147.38 465407.91 725634.43 147.38 465409.15 725637.84 147.38 465412.41 725636.6 147.38 465414.81 725642.95 147.38 465411.08 725644.37 147.38 465410.75 725643.52 147.38 465407.68 725644.68 147.38 465408.05 725645.67 147.38 465404.06 725647.17 147.38 465403.69 725646.2 147.38 465400.13 725647.55 147.38 465398.53 725643.35 147.38 465397.26 725642.76 147.38 465396.75 725641.42 147.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-ED09-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-ED09-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED09-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464510.47 724685.2 136.97 464514.59 724681.61 136.97 464511.63 724678.44 136.97 464520.41 724670.78 136.97 464513.83 724663.19 136.97 464500.98 724674.37 136.97 464510.47 724685.2 136.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED09-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464510.47 724685.2 136.97 464500.98 724674.37 136.97 464500.98 724674.37 142.81 464510.47 724685.2 142.81 464510.47 724685.2 136.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED09-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464500.98 724674.37 136.97 464513.83 724663.19 136.97 464513.83 724663.19 142.81 464500.98 724674.37 142.81 464500.98 724674.37 136.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED09-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464513.83 724663.19 136.97 464520.41 724670.78 136.97 464520.41 724670.78 142.81 464513.83 724663.19 142.81 464513.83 724663.19 136.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED09-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464520.41 724670.78 136.97 464511.63 724678.44 136.97 464511.63 724678.44 142.81 464520.41 724670.78 142.81 464520.41 724670.78 136.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED09-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464511.63 724678.44 136.97 464514.59 724681.61 136.97 464514.59 724681.61 142.81 464511.63 724678.44 142.81 464511.63 724678.44 136.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED09-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464514.59 724681.61 136.97 464510.47 724685.2 136.97 464510.47 724685.2 142.81 464514.59 724681.61 142.81 464514.59 724681.61 136.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-ED09-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464510.47 724685.2 142.81 464500.98 724674.37 142.81 464513.83 724663.19 142.81 464520.41 724670.78 142.81 464511.63 724678.44 142.81 464514.59 724681.61 142.81 464510.47 724685.2 142.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C82C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C82C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.2</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C82C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464684.71 724480.23 139.84 464696.47 724474.95 139.84 464691.97 724464.85 139.84 464680.23 724470.09 139.84 464684.71 724480.23 139.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C82C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464684.71 724480.23 139.84 464680.23 724470.09 139.84 464680.23 724470.09 144.04 464684.71 724480.23 144.04 464684.71 724480.23 139.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C82C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464680.23 724470.09 139.84 464691.97 724464.85 139.84 464691.97 724464.85 144.04 464680.23 724470.09 144.04 464680.23 724470.09 139.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C82C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464691.97 724464.85 139.84 464696.47 724474.95 139.84 464696.47 724474.95 144.04 464691.97 724464.85 144.04 464691.97 724464.85 139.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C82C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464696.47 724474.95 139.84 464684.71 724480.23 139.84 464684.71 724480.23 144.04 464696.47 724474.95 144.04 464696.47 724474.95 139.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C82C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464684.71 724480.23 144.04 464680.23 724470.09 144.04 464691.97 724464.85 144.04 464696.47 724474.95 144.04 464684.71 724480.23 144.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-EA16-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-EA16-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.24</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA16-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464060.71 723597.98 130.34 464073.42 723594.47 130.34 464079.58 723592.7 130.34 464077 723583.6 130.34 464070.79 723585.36 130.34 464058.16 723588.74 130.34 464060.71 723597.98 130.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA16-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464060.71 723597.98 130.34 464058.16 723588.74 130.34 464058.16 723588.74 137.58 464060.71 723597.98 137.58 464060.71 723597.98 130.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA16-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464058.16 723588.74 130.34 464070.79 723585.36 130.34 464070.79 723585.36 137.58 464058.16 723588.74 137.58 464058.16 723588.74 130.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA16-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464070.79 723585.36 130.34 464077 723583.6 130.34 464077 723583.6 137.58 464070.79 723585.36 137.58 464070.79 723585.36 130.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA16-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464077 723583.6 130.34 464079.58 723592.7 130.34 464079.58 723592.7 137.58 464077 723583.6 137.58 464077 723583.6 130.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA16-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464079.58 723592.7 130.34 464073.42 723594.47 130.34 464073.42 723594.47 137.58 464079.58 723592.7 137.58 464079.58 723592.7 130.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA16-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464073.42 723594.47 130.34 464060.71 723597.98 130.34 464060.71 723597.98 137.58 464073.42 723594.47 137.58 464073.42 723594.47 130.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA16-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464060.71 723597.98 137.58 464058.16 723588.74 137.58 464070.79 723585.36 137.58 464077 723583.6 137.58 464079.58 723592.7 137.58 464073.42 723594.47 137.58 464060.71 723597.98 137.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C9BB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C9BB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463533.49 724871.67 129.51 463523 724879.93 129.51 463526.76 724884.52 129.51 463537.24 724876.23 129.51 463533.49 724871.67 129.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463533.49 724871.67 129.51 463537.24 724876.23 129.51 463537.24 724876.23 133.35 463533.49 724871.67 133.35 463533.49 724871.67 129.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463537.24 724876.23 129.51 463526.76 724884.52 129.51 463526.76 724884.52 133.35 463537.24 724876.23 133.35 463537.24 724876.23 129.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463526.76 724884.52 129.51 463523 724879.93 129.51 463523 724879.93 133.35 463526.76 724884.52 133.35 463526.76 724884.52 129.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463523 724879.93 129.51 463533.49 724871.67 129.51 463533.49 724871.67 133.35 463523 724879.93 133.35 463523 724879.93 129.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C9BB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463533.49 724871.67 133.35 463537.24 724876.23 133.35 463526.76 724884.52 133.35 463523 724879.93 133.35 463533.49 724871.67 133.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.28</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465416.64 725605.01 140.14 465420.02 725603.77 140.14 465420.21 725604.35 140.14 465422.93 725603.33 140.14 465422.75 725602.76 140.14 465426.12 725601.52 140.14 465425.85 725600.79 140.14 465429.11 725599.57 140.14 465426.77 725593.27 140.14 465423.48 725594.43 140.14 465423.18 725593.7 140.14 465413.73 725597.2 140.14 465414.02 725597.99 140.14 465413.39 725599.18 140.14 465413.93 725600.63 140.14 465415.2 725601.15 140.14 465416.64 725605.01 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465416.64 725605.01 140.14 465415.2 725601.15 140.14 465415.2 725601.15 146.42000000000002 465416.64 725605.01 146.42000000000002 465416.64 725605.01 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465415.2 725601.15 140.14 465413.93 725600.63 140.14 465413.93 725600.63 146.42000000000002 465415.2 725601.15 146.42000000000002 465415.2 725601.15 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465413.93 725600.63 140.14 465413.39 725599.18 140.14 465413.39 725599.18 146.42000000000002 465413.93 725600.63 146.42000000000002 465413.93 725600.63 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465413.39 725599.18 140.14 465414.02 725597.99 140.14 465414.02 725597.99 146.42000000000002 465413.39 725599.18 146.42000000000002 465413.39 725599.18 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465414.02 725597.99 140.14 465413.73 725597.2 140.14 465413.73 725597.2 146.42000000000002 465414.02 725597.99 146.42000000000002 465414.02 725597.99 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465413.73 725597.2 140.14 465423.18 725593.7 140.14 465423.18 725593.7 146.42000000000002 465413.73 725597.2 146.42000000000002 465413.73 725597.2 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465423.18 725593.7 140.14 465423.48 725594.43 140.14 465423.48 725594.43 146.42000000000002 465423.18 725593.7 146.42000000000002 465423.18 725593.7 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465423.48 725594.43 140.14 465426.77 725593.27 140.14 465426.77 725593.27 146.42000000000002 465423.48 725594.43 146.42000000000002 465423.48 725594.43 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465426.77 725593.27 140.14 465429.11 725599.57 140.14 465429.11 725599.57 146.42000000000002 465426.77 725593.27 146.42000000000002 465426.77 725593.27 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465429.11 725599.57 140.14 465425.85 725600.79 140.14 465425.85 725600.79 146.42000000000002 465429.11 725599.57 146.42000000000002 465429.11 725599.57 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465425.85 725600.79 140.14 465426.12 725601.52 140.14 465426.12 725601.52 146.42000000000002 465425.85 725600.79 146.42000000000002 465425.85 725600.79 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465426.12 725601.52 140.14 465422.75 725602.76 140.14 465422.75 725602.76 146.42000000000002 465426.12 725601.52 146.42000000000002 465426.12 725601.52 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465422.75 725602.76 140.14 465422.93 725603.33 140.14 465422.93 725603.33 146.42000000000002 465422.75 725602.76 146.42000000000002 465422.75 725602.76 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465422.93 725603.33 140.14 465420.21 725604.35 140.14 465420.21 725604.35 146.42000000000002 465422.93 725603.33 146.42000000000002 465422.93 725603.33 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465420.21 725604.35 140.14 465420.02 725603.77 140.14 465420.02 725603.77 146.42000000000002 465420.21 725604.35 146.42000000000002 465420.21 725604.35 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465420.02 725603.77 140.14 465416.64 725605.01 140.14 465416.64 725605.01 146.42000000000002 465420.02 725603.77 146.42000000000002 465420.02 725603.77 140.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EB37-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465416.64 725605.01 146.42000000000002 465415.2 725601.15 146.42000000000002 465413.93 725600.63 146.42000000000002 465413.39 725599.18 146.42000000000002 465414.02 725597.99 146.42000000000002 465413.73 725597.2 146.42000000000002 465423.18 725593.7 146.42000000000002 465423.48 725594.43 146.42000000000002 465426.77 725593.27 146.42000000000002 465429.11 725599.57 146.42000000000002 465425.85 725600.79 146.42000000000002 465426.12 725601.52 146.42000000000002 465422.75 725602.76 146.42000000000002 465422.93 725603.33 146.42000000000002 465420.21 725604.35 146.42000000000002 465420.02 725603.77 146.42000000000002 465416.64 725605.01 146.42000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5C62-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5C62-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.44</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C62-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464077.73 723633.9 131.38 464082.32 723630.42 131.38 464075.09 723620.86 131.38 464068.24 723626.06 131.38 464068.09 723628.12 131.38 464070.63 723631.28 131.38 464074.18 723628.77 131.38 464077.73 723633.9 131.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C62-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464077.73 723633.9 131.38 464074.18 723628.77 131.38 464074.18 723628.77 136.82 464077.73 723633.9 136.82 464077.73 723633.9 131.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C62-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464074.18 723628.77 131.38 464070.63 723631.28 131.38 464070.63 723631.28 136.82 464074.18 723628.77 136.82 464074.18 723628.77 131.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C62-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464070.63 723631.28 131.38 464068.09 723628.12 131.38 464068.09 723628.12 136.82 464070.63 723631.28 136.82 464070.63 723631.28 131.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C62-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464068.09 723628.12 131.38 464068.24 723626.06 131.38 464068.24 723626.06 136.82 464068.09 723628.12 136.82 464068.09 723628.12 131.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C62-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464068.24 723626.06 131.38 464075.09 723620.86 131.38 464075.09 723620.86 136.82 464068.24 723626.06 136.82 464068.24 723626.06 131.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C62-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464075.09 723620.86 131.38 464082.32 723630.42 131.38 464082.32 723630.42 136.82 464075.09 723620.86 136.82 464075.09 723620.86 131.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C62-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464082.32 723630.42 131.38 464077.73 723633.9 131.38 464077.73 723633.9 136.82 464082.32 723630.42 136.82 464082.32 723630.42 131.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5C62-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464077.73 723633.9 136.82 464074.18 723628.77 136.82 464070.63 723631.28 136.82 464068.09 723628.12 136.82 464068.24 723626.06 136.82 464075.09 723620.86 136.82 464082.32 723630.42 136.82 464077.73 723633.9 136.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6112-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6112-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.09</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6112-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463645.16 724154.66 132.54 463649.45 724152.24 132.54 463643.45 724141.54 132.54 463639.46 724144.49 132.54 463645.16 724154.66 132.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6112-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463645.16 724154.66 132.54 463639.46 724144.49 132.54 463639.46 724144.49 137.63 463645.16 724154.66 137.63 463645.16 724154.66 132.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6112-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463639.46 724144.49 132.54 463643.45 724141.54 132.54 463643.45 724141.54 137.63 463639.46 724144.49 137.63 463639.46 724144.49 132.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6112-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463643.45 724141.54 132.54 463649.45 724152.24 132.54 463649.45 724152.24 137.63 463643.45 724141.54 137.63 463643.45 724141.54 132.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6112-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463649.45 724152.24 132.54 463645.16 724154.66 132.54 463645.16 724154.66 137.63 463649.45 724152.24 137.63 463649.45 724152.24 132.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6112-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463645.16 724154.66 137.63 463639.46 724144.49 137.63 463643.45 724141.54 137.63 463649.45 724152.24 137.63 463645.16 724154.66 137.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-587B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.62</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464155.43 723782.49 132.94 464177.15 723761.15 132.94 464160.35 723744.1 132.94 464163.93 723740.56 132.94 464168.78 723745.46 132.94 464169.2 723745.04 132.94 464168.99 723744.83 132.94 464174.76 723739.17 132.94 464174.96 723739.38 132.94 464175.39 723738.94 132.94 464175.19 723738.73 132.94 464179.03 723734.96 132.94 464165.59 723721.26 132.94 464161.91 723724.82 132.94 464162.6 723725.53 132.94 464159.41 723728.67 132.94 464158.74 723727.97 132.94 464155.12 723731.56 132.94 464161.99 723738.56 132.94 464158.47 723742.05 132.94 464151.6 723735.11 132.94 464129.9 723756.56 132.94 464155.43 723782.49 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464155.43 723782.49 132.94 464129.9 723756.56 132.94 464129.9 723756.56 140.56 464155.43 723782.49 140.56 464155.43 723782.49 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464129.9 723756.56 132.94 464151.6 723735.11 132.94 464151.6 723735.11 140.56 464129.9 723756.56 140.56 464129.9 723756.56 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464151.6 723735.11 132.94 464158.47 723742.05 132.94 464158.47 723742.05 140.56 464151.6 723735.11 140.56 464151.6 723735.11 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464158.47 723742.05 132.94 464161.99 723738.56 132.94 464161.99 723738.56 140.56 464158.47 723742.05 140.56 464158.47 723742.05 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464161.99 723738.56 132.94 464155.12 723731.56 132.94 464155.12 723731.56 140.56 464161.99 723738.56 140.56 464161.99 723738.56 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464155.12 723731.56 132.94 464158.74 723727.97 132.94 464158.74 723727.97 140.56 464155.12 723731.56 140.56 464155.12 723731.56 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464158.74 723727.97 132.94 464159.41 723728.67 132.94 464159.41 723728.67 140.56 464158.74 723727.97 140.56 464158.74 723727.97 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464159.41 723728.67 132.94 464162.6 723725.53 132.94 464162.6 723725.53 140.56 464159.41 723728.67 140.56 464159.41 723728.67 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464162.6 723725.53 132.94 464161.91 723724.82 132.94 464161.91 723724.82 140.56 464162.6 723725.53 140.56 464162.6 723725.53 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464161.91 723724.82 132.94 464165.59 723721.26 132.94 464165.59 723721.26 140.56 464161.91 723724.82 140.56 464161.91 723724.82 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464165.59 723721.26 132.94 464179.03 723734.96 132.94 464179.03 723734.96 140.56 464165.59 723721.26 140.56 464165.59 723721.26 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464179.03 723734.96 132.94 464175.19 723738.73 132.94 464175.19 723738.73 140.56 464179.03 723734.96 140.56 464179.03 723734.96 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464175.19 723738.73 132.94 464175.39 723738.94 132.94 464175.39 723738.94 140.56 464175.19 723738.73 140.56 464175.19 723738.73 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464175.39 723738.94 132.94 464174.96 723739.38 132.94 464174.96 723739.38 140.56 464175.39 723738.94 140.56 464175.39 723738.94 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464174.96 723739.38 132.94 464174.76 723739.17 132.94 464174.76 723739.17 140.56 464174.96 723739.38 140.56 464174.96 723739.38 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464174.76 723739.17 132.94 464168.99 723744.83 132.94 464168.99 723744.83 140.56 464174.76 723739.17 140.56 464174.76 723739.17 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464168.99 723744.83 132.94 464169.2 723745.04 132.94 464169.2 723745.04 140.56 464168.99 723744.83 140.56 464168.99 723744.83 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464169.2 723745.04 132.94 464168.78 723745.46 132.94 464168.78 723745.46 140.56 464169.2 723745.04 140.56 464169.2 723745.04 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464168.78 723745.46 132.94 464163.93 723740.56 132.94 464163.93 723740.56 140.56 464168.78 723745.46 140.56 464168.78 723745.46 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464163.93 723740.56 132.94 464160.35 723744.1 132.94 464160.35 723744.1 140.56 464163.93 723740.56 140.56 464163.93 723740.56 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464160.35 723744.1 132.94 464177.15 723761.15 132.94 464177.15 723761.15 140.56 464160.35 723744.1 140.56 464160.35 723744.1 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464177.15 723761.15 132.94 464155.43 723782.49 132.94 464155.43 723782.49 140.56 464177.15 723761.15 140.56 464177.15 723761.15 132.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-587B-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464155.43 723782.49 140.56 464129.9 723756.56 140.56 464151.6 723735.11 140.56 464158.47 723742.05 140.56 464161.99 723738.56 140.56 464155.12 723731.56 140.56 464158.74 723727.97 140.56 464159.41 723728.67 140.56 464162.6 723725.53 140.56 464161.91 723724.82 140.56 464165.59 723721.26 140.56 464179.03 723734.96 140.56 464175.19 723738.73 140.56 464175.39 723738.94 140.56 464174.96 723739.38 140.56 464174.76 723739.17 140.56 464168.99 723744.83 140.56 464169.2 723745.04 140.56 464168.78 723745.46 140.56 464163.93 723740.56 140.56 464160.35 723744.1 140.56 464177.15 723761.15 140.56 464155.43 723782.49 140.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-EA5C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-EA5C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.68</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA5C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465378.12 725654.07 140.73 465380.84 725653.05 140.73 465380.2 725651.15 140.73 465386.51 725648.76 140.73 465383.75 725641.62 140.73 465371.4 725646.28 140.73 465374.06 725653.43 140.73 465377.43 725652.2 140.73 465378.12 725654.07 140.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA5C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465378.12 725654.07 140.73 465377.43 725652.2 140.73 465377.43 725652.2 147.405 465378.12 725654.07 147.405 465378.12 725654.07 140.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA5C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465377.43 725652.2 140.73 465374.06 725653.43 140.73 465374.06 725653.43 147.405 465377.43 725652.2 147.405 465377.43 725652.2 140.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA5C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465374.06 725653.43 140.73 465371.4 725646.28 140.73 465371.4 725646.28 147.405 465374.06 725653.43 147.405 465374.06 725653.43 140.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA5C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465371.4 725646.28 140.73 465383.75 725641.62 140.73 465383.75 725641.62 147.405 465371.4 725646.28 147.405 465371.4 725646.28 140.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA5C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465383.75 725641.62 140.73 465386.51 725648.76 140.73 465386.51 725648.76 147.405 465383.75 725641.62 147.405 465383.75 725641.62 140.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA5C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465386.51 725648.76 140.73 465380.2 725651.15 140.73 465380.2 725651.15 147.405 465386.51 725648.76 147.405 465386.51 725648.76 140.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA5C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465380.2 725651.15 140.73 465380.84 725653.05 140.73 465380.84 725653.05 147.405 465380.2 725651.15 147.405 465380.2 725651.15 140.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA5C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465380.84 725653.05 140.73 465378.12 725654.07 140.73 465378.12 725654.07 147.405 465380.84 725653.05 147.405 465380.84 725653.05 140.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EA5C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465378.12 725654.07 147.405 465377.43 725652.2 147.405 465374.06 725653.43 147.405 465371.4 725646.28 147.405 465383.75 725641.62 147.405 465386.51 725648.76 147.405 465380.2 725651.15 147.405 465380.84 725653.05 147.405 465378.12 725654.07 147.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-EBF2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-EBF2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.77</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EBF2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465299.44 725420.48 138.93 465302.37 725418.38 138.93 465300.43 725415.61 138.93 465302.96 725413.71 138.93 465300.23 725409.87 138.93 465291.84 725416.09 138.93 465294.59 725419.96 138.93 465297.56 725417.75 138.93 465299.44 725420.48 138.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EBF2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465299.44 725420.48 138.93 465297.56 725417.75 138.93 465297.56 725417.75 143.70000000000002 465299.44 725420.48 143.70000000000002 465299.44 725420.48 138.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EBF2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465297.56 725417.75 138.93 465294.59 725419.96 138.93 465294.59 725419.96 143.70000000000002 465297.56 725417.75 143.70000000000002 465297.56 725417.75 138.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EBF2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465294.59 725419.96 138.93 465291.84 725416.09 138.93 465291.84 725416.09 143.70000000000002 465294.59 725419.96 143.70000000000002 465294.59 725419.96 138.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EBF2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465291.84 725416.09 138.93 465300.23 725409.87 138.93 465300.23 725409.87 143.70000000000002 465291.84 725416.09 143.70000000000002 465291.84 725416.09 138.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EBF2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465300.23 725409.87 138.93 465302.96 725413.71 138.93 465302.96 725413.71 143.70000000000002 465300.23 725409.87 143.70000000000002 465300.23 725409.87 138.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EBF2-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465302.96 725413.71 138.93 465300.43 725415.61 138.93 465300.43 725415.61 143.70000000000002 465302.96 725413.71 143.70000000000002 465302.96 725413.71 138.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EBF2-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465300.43 725415.61 138.93 465302.37 725418.38 138.93 465302.37 725418.38 143.70000000000002 465300.43 725415.61 143.70000000000002 465300.43 725415.61 138.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EBF2-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465302.37 725418.38 138.93 465299.44 725420.48 138.93 465299.44 725420.48 143.70000000000002 465302.37 725418.38 143.70000000000002 465302.37 725418.38 138.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-EBF2-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465299.44 725420.48 143.70000000000002 465297.56 725417.75 143.70000000000002 465294.59 725419.96 143.70000000000002 465291.84 725416.09 143.70000000000002 465300.23 725409.87 143.70000000000002 465302.96 725413.71 143.70000000000002 465300.43 725415.61 143.70000000000002 465302.37 725418.38 143.70000000000002 465299.44 725420.48 143.70000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.97</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463517.38 724880.51 129.32 463522.44 724875.99 129.32 463521.58 724875.02 129.32 463522.74 724873.99 129.32 463521.49 724872.59 129.32 463524.2 724870.41 129.32 463520.48 724865.82 129.32 463515.48 724870.17 129.32 463515.09 724869.71 129.32 463510.97 724873.3 129.32 463517.38 724880.51 129.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463517.38 724880.51 129.32 463510.97 724873.3 129.32 463510.97 724873.3 135.29 463517.38 724880.51 135.29 463517.38 724880.51 129.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463510.97 724873.3 129.32 463515.09 724869.71 129.32 463515.09 724869.71 135.29 463510.97 724873.3 135.29 463510.97 724873.3 129.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463515.09 724869.71 129.32 463515.48 724870.17 129.32 463515.48 724870.17 135.29 463515.09 724869.71 135.29 463515.09 724869.71 129.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463515.48 724870.17 129.32 463520.48 724865.82 129.32 463520.48 724865.82 135.29 463515.48 724870.17 135.29 463515.48 724870.17 129.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463520.48 724865.82 129.32 463524.2 724870.41 129.32 463524.2 724870.41 135.29 463520.48 724865.82 135.29 463520.48 724865.82 129.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463524.2 724870.41 129.32 463521.49 724872.59 129.32 463521.49 724872.59 135.29 463524.2 724870.41 135.29 463524.2 724870.41 129.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463521.49 724872.59 129.32 463522.74 724873.99 129.32 463522.74 724873.99 135.29 463521.49 724872.59 135.29 463521.49 724872.59 129.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463522.74 724873.99 129.32 463521.58 724875.02 129.32 463521.58 724875.02 135.29 463522.74 724873.99 135.29 463522.74 724873.99 129.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463521.58 724875.02 129.32 463522.44 724875.99 129.32 463522.44 724875.99 135.29 463521.58 724875.02 135.29 463521.58 724875.02 129.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463522.44 724875.99 129.32 463517.38 724880.51 129.32 463517.38 724880.51 135.29 463522.44 724875.99 135.29 463522.44 724875.99 129.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DBC5-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463517.38 724880.51 135.29 463510.97 724873.3 135.29 463515.09 724869.71 135.29 463515.48 724870.17 135.29 463520.48 724865.82 135.29 463524.2 724870.41 135.29 463521.49 724872.59 135.29 463522.74 724873.99 135.29 463521.58 724875.02 135.29 463522.44 724875.99 135.29 463517.38 724880.51 135.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">20.4</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465290.66 724415.17 136.76 465363.68 724383.66 136.76 465366.83 724382.3 136.76 465449.75 724346.52 136.76 465422.25 724282.78 136.76 465416.84 724270.27 136.76 465413 724271.92 136.76 465406.68 724257.43 136.76 465423.32 724250.27 136.76 465437.37 724244.22 136.76 465437.09 724243.57 136.76 465432.64 724245.78 136.76 465431.57 724244.58 136.76 465435.21 724241.22 136.76 465421.87 724246.96 136.76 465405.25 724254.12 136.76 465404.79 724253.07 136.76 465401.47 724254.48 136.76 465409.61 724273.39 136.76 465406.07 724274.92 136.76 465399.96 724260.76 136.76 465401.04 724260.28 136.76 465397.74 724252.64 136.76 465392.24 724255.04 136.76 465395.53 724262.65 136.76 465396.63 724262.18 136.76 465402.73 724276.36 136.76 465385.1 724283.97 136.76 465368.23 724291.26 136.76 465365.35 724284.6 136.76 465362.12 724277.09 136.76 465365.66 724275.53 136.76 465364.59 724273.12 136.76 465362.16 724274.19 136.76 465359.86 724268.98 136.76 465354.4 724271.34 136.76 465357.68 724279.04 136.76 465358.78 724278.54 136.76 465361.44 724284.72 136.76 465364.88 724292.7 136.76 465334.56 724305.8 136.76 465330.37 724307.62 136.76 465324.26 724293.43 136.76 465327.81 724291.92 136.76 465326.76 724289.49 136.76 465324.33 724290.53 136.76 465322.04 724285.32 136.76 465316.53 724287.68 136.76 465319.8 724295.35 136.76 465320.92 724294.87 136.76 465327.03 724309.05 136.76 465292.53 724323.95 136.76 465286.43 724309.76 136.76 465289.74 724308.35 136.76 465288.65 724305.8 136.76 465286.46 724306.74 136.76 465284.2 724301.65 136.76 465278.68 724304.03 136.76 465281.97 724311.68 136.76 465283.09 724311.23 136.76 465289.19 724325.41 136.76 465270.5 724333.48 136.76 465257.8 724338.97 136.76 465254.77 724340.27 136.76 465248.64 724326.07 136.76 465252.2 724324.55 136.76 465251.18 724322.22 136.76 465248.66 724323.29 136.76 465246.35 724317.94 136.76 465240.83 724320.32 136.76 465244.12 724328 136.76 465245.15 724327.56 136.76 465251.28 724341.77 136.76 465216.95 724356.53 136.76 465210.82 724342.33 136.76 465214.34 724340.83 136.76 465213.34 724338.48 136.76 465210.83 724339.57 136.76 465208.49 724334.24 136.76 465202.95 724336.59 136.76 465206.3 724344.3 136.76 465207.28 724343.86 136.76 465213.41 724358.05 136.76 465202.72 724362.65 136.76 465219.96 724402.65 136.76 465235.58 724438.89 136.76 465242.86 724435.76 136.76 465255.71 724465.59 136.76 465259.2 724464.08 136.76 465246.35 724434.25 136.76 465272.33 724423.09 136.76 465290.66 724415.17 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465290.66 724415.17 136.76 465272.33 724423.09 136.76 465272.33 724423.09 157.16 465290.66 724415.17 157.16 465290.66 724415.17 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465272.33 724423.09 136.76 465246.35 724434.25 136.76 465246.35 724434.25 157.16 465272.33 724423.09 157.16 465272.33 724423.09 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465246.35 724434.25 136.76 465259.2 724464.08 136.76 465259.2 724464.08 157.16 465246.35 724434.25 157.16 465246.35 724434.25 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465259.2 724464.08 136.76 465255.71 724465.59 136.76 465255.71 724465.59 157.16 465259.2 724464.08 157.16 465259.2 724464.08 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465255.71 724465.59 136.76 465242.86 724435.76 136.76 465242.86 724435.76 157.16 465255.71 724465.59 157.16 465255.71 724465.59 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465242.86 724435.76 136.76 465235.58 724438.89 136.76 465235.58 724438.89 157.16 465242.86 724435.76 157.16 465242.86 724435.76 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465235.58 724438.89 136.76 465219.96 724402.65 136.76 465219.96 724402.65 157.16 465235.58 724438.89 157.16 465235.58 724438.89 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465219.96 724402.65 136.76 465202.72 724362.65 136.76 465202.72 724362.65 157.16 465219.96 724402.65 157.16 465219.96 724402.65 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465202.72 724362.65 136.76 465213.41 724358.05 136.76 465213.41 724358.05 157.16 465202.72 724362.65 157.16 465202.72 724362.65 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465213.41 724358.05 136.76 465207.28 724343.86 136.76 465207.28 724343.86 157.16 465213.41 724358.05 157.16 465213.41 724358.05 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465207.28 724343.86 136.76 465206.3 724344.3 136.76 465206.3 724344.3 157.16 465207.28 724343.86 157.16 465207.28 724343.86 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465206.3 724344.3 136.76 465202.95 724336.59 136.76 465202.95 724336.59 157.16 465206.3 724344.3 157.16 465206.3 724344.3 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465202.95 724336.59 136.76 465208.49 724334.24 136.76 465208.49 724334.24 157.16 465202.95 724336.59 157.16 465202.95 724336.59 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465208.49 724334.24 136.76 465210.83 724339.57 136.76 465210.83 724339.57 157.16 465208.49 724334.24 157.16 465208.49 724334.24 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465210.83 724339.57 136.76 465213.34 724338.48 136.76 465213.34 724338.48 157.16 465210.83 724339.57 157.16 465210.83 724339.57 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465213.34 724338.48 136.76 465214.34 724340.83 136.76 465214.34 724340.83 157.16 465213.34 724338.48 157.16 465213.34 724338.48 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465214.34 724340.83 136.76 465210.82 724342.33 136.76 465210.82 724342.33 157.16 465214.34 724340.83 157.16 465214.34 724340.83 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465210.82 724342.33 136.76 465216.95 724356.53 136.76 465216.95 724356.53 157.16 465210.82 724342.33 157.16 465210.82 724342.33 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465216.95 724356.53 136.76 465251.28 724341.77 136.76 465251.28 724341.77 157.16 465216.95 724356.53 157.16 465216.95 724356.53 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465251.28 724341.77 136.76 465245.15 724327.56 136.76 465245.15 724327.56 157.16 465251.28 724341.77 157.16 465251.28 724341.77 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465245.15 724327.56 136.76 465244.12 724328 136.76 465244.12 724328 157.16 465245.15 724327.56 157.16 465245.15 724327.56 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465244.12 724328 136.76 465240.83 724320.32 136.76 465240.83 724320.32 157.16 465244.12 724328 157.16 465244.12 724328 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465240.83 724320.32 136.76 465246.35 724317.94 136.76 465246.35 724317.94 157.16 465240.83 724320.32 157.16 465240.83 724320.32 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465246.35 724317.94 136.76 465248.66 724323.29 136.76 465248.66 724323.29 157.16 465246.35 724317.94 157.16 465246.35 724317.94 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465248.66 724323.29 136.76 465251.18 724322.22 136.76 465251.18 724322.22 157.16 465248.66 724323.29 157.16 465248.66 724323.29 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465251.18 724322.22 136.76 465252.2 724324.55 136.76 465252.2 724324.55 157.16 465251.18 724322.22 157.16 465251.18 724322.22 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465252.2 724324.55 136.76 465248.64 724326.07 136.76 465248.64 724326.07 157.16 465252.2 724324.55 157.16 465252.2 724324.55 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465248.64 724326.07 136.76 465254.77 724340.27 136.76 465254.77 724340.27 157.16 465248.64 724326.07 157.16 465248.64 724326.07 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465254.77 724340.27 136.76 465257.8 724338.97 136.76 465257.8 724338.97 157.16 465254.77 724340.27 157.16 465254.77 724340.27 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465257.8 724338.97 136.76 465270.5 724333.48 136.76 465270.5 724333.48 157.16 465257.8 724338.97 157.16 465257.8 724338.97 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465270.5 724333.48 136.76 465289.19 724325.41 136.76 465289.19 724325.41 157.16 465270.5 724333.48 157.16 465270.5 724333.48 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465289.19 724325.41 136.76 465283.09 724311.23 136.76 465283.09 724311.23 157.16 465289.19 724325.41 157.16 465289.19 724325.41 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465283.09 724311.23 136.76 465281.97 724311.68 136.76 465281.97 724311.68 157.16 465283.09 724311.23 157.16 465283.09 724311.23 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465281.97 724311.68 136.76 465278.68 724304.03 136.76 465278.68 724304.03 157.16 465281.97 724311.68 157.16 465281.97 724311.68 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465278.68 724304.03 136.76 465284.2 724301.65 136.76 465284.2 724301.65 157.16 465278.68 724304.03 157.16 465278.68 724304.03 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465284.2 724301.65 136.76 465286.46 724306.74 136.76 465286.46 724306.74 157.16 465284.2 724301.65 157.16 465284.2 724301.65 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465286.46 724306.74 136.76 465288.65 724305.8 136.76 465288.65 724305.8 157.16 465286.46 724306.74 157.16 465286.46 724306.74 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465288.65 724305.8 136.76 465289.74 724308.35 136.76 465289.74 724308.35 157.16 465288.65 724305.8 157.16 465288.65 724305.8 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465289.74 724308.35 136.76 465286.43 724309.76 136.76 465286.43 724309.76 157.16 465289.74 724308.35 157.16 465289.74 724308.35 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465286.43 724309.76 136.76 465292.53 724323.95 136.76 465292.53 724323.95 157.16 465286.43 724309.76 157.16 465286.43 724309.76 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465292.53 724323.95 136.76 465327.03 724309.05 136.76 465327.03 724309.05 157.16 465292.53 724323.95 157.16 465292.53 724323.95 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465327.03 724309.05 136.76 465320.92 724294.87 136.76 465320.92 724294.87 157.16 465327.03 724309.05 157.16 465327.03 724309.05 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465320.92 724294.87 136.76 465319.8 724295.35 136.76 465319.8 724295.35 157.16 465320.92 724294.87 157.16 465320.92 724294.87 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465319.8 724295.35 136.76 465316.53 724287.68 136.76 465316.53 724287.68 157.16 465319.8 724295.35 157.16 465319.8 724295.35 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465316.53 724287.68 136.76 465322.04 724285.32 136.76 465322.04 724285.32 157.16 465316.53 724287.68 157.16 465316.53 724287.68 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465322.04 724285.32 136.76 465324.33 724290.53 136.76 465324.33 724290.53 157.16 465322.04 724285.32 157.16 465322.04 724285.32 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465324.33 724290.53 136.76 465326.76 724289.49 136.76 465326.76 724289.49 157.16 465324.33 724290.53 157.16 465324.33 724290.53 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465326.76 724289.49 136.76 465327.81 724291.92 136.76 465327.81 724291.92 157.16 465326.76 724289.49 157.16 465326.76 724289.49 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465327.81 724291.92 136.76 465324.26 724293.43 136.76 465324.26 724293.43 157.16 465327.81 724291.92 157.16 465327.81 724291.92 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465324.26 724293.43 136.76 465330.37 724307.62 136.76 465330.37 724307.62 157.16 465324.26 724293.43 157.16 465324.26 724293.43 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465330.37 724307.62 136.76 465334.56 724305.8 136.76 465334.56 724305.8 157.16 465330.37 724307.62 157.16 465330.37 724307.62 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465334.56 724305.8 136.76 465364.88 724292.7 136.76 465364.88 724292.7 157.16 465334.56 724305.8 157.16 465334.56 724305.8 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465364.88 724292.7 136.76 465361.44 724284.72 136.76 465361.44 724284.72 157.16 465364.88 724292.7 157.16 465364.88 724292.7 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465361.44 724284.72 136.76 465358.78 724278.54 136.76 465358.78 724278.54 157.16 465361.44 724284.72 157.16 465361.44 724284.72 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465358.78 724278.54 136.76 465357.68 724279.04 136.76 465357.68 724279.04 157.16 465358.78 724278.54 157.16 465358.78 724278.54 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465357.68 724279.04 136.76 465354.4 724271.34 136.76 465354.4 724271.34 157.16 465357.68 724279.04 157.16 465357.68 724279.04 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465354.4 724271.34 136.76 465359.86 724268.98 136.76 465359.86 724268.98 157.16 465354.4 724271.34 157.16 465354.4 724271.34 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465359.86 724268.98 136.76 465362.16 724274.19 136.76 465362.16 724274.19 157.16 465359.86 724268.98 157.16 465359.86 724268.98 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465362.16 724274.19 136.76 465364.59 724273.12 136.76 465364.59 724273.12 157.16 465362.16 724274.19 157.16 465362.16 724274.19 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465364.59 724273.12 136.76 465365.66 724275.53 136.76 465365.66 724275.53 157.16 465364.59 724273.12 157.16 465364.59 724273.12 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465365.66 724275.53 136.76 465362.12 724277.09 136.76 465362.12 724277.09 157.16 465365.66 724275.53 157.16 465365.66 724275.53 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465362.12 724277.09 136.76 465365.35 724284.6 136.76 465365.35 724284.6 157.16 465362.12 724277.09 157.16 465362.12 724277.09 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465365.35 724284.6 136.76 465368.23 724291.26 136.76 465368.23 724291.26 157.16 465365.35 724284.6 157.16 465365.35 724284.6 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465368.23 724291.26 136.76 465385.1 724283.97 136.76 465385.1 724283.97 157.16 465368.23 724291.26 157.16 465368.23 724291.26 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465385.1 724283.97 136.76 465402.73 724276.36 136.76 465402.73 724276.36 157.16 465385.1 724283.97 157.16 465385.1 724283.97 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465402.73 724276.36 136.76 465396.63 724262.18 136.76 465396.63 724262.18 157.16 465402.73 724276.36 157.16 465402.73 724276.36 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465396.63 724262.18 136.76 465395.53 724262.65 136.76 465395.53 724262.65 157.16 465396.63 724262.18 157.16 465396.63 724262.18 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465395.53 724262.65 136.76 465392.24 724255.04 136.76 465392.24 724255.04 157.16 465395.53 724262.65 157.16 465395.53 724262.65 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465392.24 724255.04 136.76 465397.74 724252.64 136.76 465397.74 724252.64 157.16 465392.24 724255.04 157.16 465392.24 724255.04 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465397.74 724252.64 136.76 465401.04 724260.28 136.76 465401.04 724260.28 157.16 465397.74 724252.64 157.16 465397.74 724252.64 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_72">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465401.04 724260.28 136.76 465399.96 724260.76 136.76 465399.96 724260.76 157.16 465401.04 724260.28 157.16 465401.04 724260.28 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465399.96 724260.76 136.76 465406.07 724274.92 136.76 465406.07 724274.92 157.16 465399.96 724260.76 157.16 465399.96 724260.76 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_74">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465406.07 724274.92 136.76 465409.61 724273.39 136.76 465409.61 724273.39 157.16 465406.07 724274.92 157.16 465406.07 724274.92 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_75">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465409.61 724273.39 136.76 465401.47 724254.48 136.76 465401.47 724254.48 157.16 465409.61 724273.39 157.16 465409.61 724273.39 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_76">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465401.47 724254.48 136.76 465404.79 724253.07 136.76 465404.79 724253.07 157.16 465401.47 724254.48 157.16 465401.47 724254.48 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_77">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465404.79 724253.07 136.76 465405.25 724254.12 136.76 465405.25 724254.12 157.16 465404.79 724253.07 157.16 465404.79 724253.07 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_78">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465405.25 724254.12 136.76 465421.87 724246.96 136.76 465421.87 724246.96 157.16 465405.25 724254.12 157.16 465405.25 724254.12 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_79">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465421.87 724246.96 136.76 465435.21 724241.22 136.76 465435.21 724241.22 157.16 465421.87 724246.96 157.16 465421.87 724246.96 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465435.21 724241.22 136.76 465431.57 724244.58 136.76 465431.57 724244.58 157.16 465435.21 724241.22 157.16 465435.21 724241.22 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_81">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465431.57 724244.58 136.76 465432.64 724245.78 136.76 465432.64 724245.78 157.16 465431.57 724244.58 157.16 465431.57 724244.58 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_82">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465432.64 724245.78 136.76 465437.09 724243.57 136.76 465437.09 724243.57 157.16 465432.64 724245.78 157.16 465432.64 724245.78 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_83">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465437.09 724243.57 136.76 465437.37 724244.22 136.76 465437.37 724244.22 157.16 465437.09 724243.57 157.16 465437.09 724243.57 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_84">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465437.37 724244.22 136.76 465423.32 724250.27 136.76 465423.32 724250.27 157.16 465437.37 724244.22 157.16 465437.37 724244.22 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_85">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465423.32 724250.27 136.76 465406.68 724257.43 136.76 465406.68 724257.43 157.16 465423.32 724250.27 157.16 465423.32 724250.27 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_86">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465406.68 724257.43 136.76 465413 724271.92 136.76 465413 724271.92 157.16 465406.68 724257.43 157.16 465406.68 724257.43 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_87">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465413 724271.92 136.76 465416.84 724270.27 136.76 465416.84 724270.27 157.16 465413 724271.92 157.16 465413 724271.92 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_88">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465416.84 724270.27 136.76 465422.25 724282.78 136.76 465422.25 724282.78 157.16 465416.84 724270.27 157.16 465416.84 724270.27 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_89">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465422.25 724282.78 136.76 465449.75 724346.52 136.76 465449.75 724346.52 157.16 465422.25 724282.78 157.16 465422.25 724282.78 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_90">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465449.75 724346.52 136.76 465366.83 724382.3 136.76 465366.83 724382.3 157.16 465449.75 724346.52 157.16 465449.75 724346.52 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465366.83 724382.3 136.76 465363.68 724383.66 136.76 465363.68 724383.66 157.16 465366.83 724382.3 157.16 465366.83 724382.3 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_92">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465363.68 724383.66 136.76 465290.66 724415.17 136.76 465290.66 724415.17 157.16 465363.68 724383.66 157.16 465363.68 724383.66 136.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-56CE-FAF6-E053-CA2BA8C0FAE4_PG_93">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465290.66 724415.17 157.16 465272.33 724423.09 157.16 465246.35 724434.25 157.16 465259.2 724464.08 157.16 465255.71 724465.59 157.16 465242.86 724435.76 157.16 465235.58 724438.89 157.16 465219.96 724402.65 157.16 465202.72 724362.65 157.16 465213.41 724358.05 157.16 465207.28 724343.86 157.16 465206.3 724344.3 157.16 465202.95 724336.59 157.16 465208.49 724334.24 157.16 465210.83 724339.57 157.16 465213.34 724338.48 157.16 465214.34 724340.83 157.16 465210.82 724342.33 157.16 465216.95 724356.53 157.16 465251.28 724341.77 157.16 465245.15 724327.56 157.16 465244.12 724328 157.16 465240.83 724320.32 157.16 465246.35 724317.94 157.16 465248.66 724323.29 157.16 465251.18 724322.22 157.16 465252.2 724324.55 157.16 465248.64 724326.07 157.16 465254.77 724340.27 157.16 465257.8 724338.97 157.16 465270.5 724333.48 157.16 465289.19 724325.41 157.16 465283.09 724311.23 157.16 465281.97 724311.68 157.16 465278.68 724304.03 157.16 465284.2 724301.65 157.16 465286.46 724306.74 157.16 465288.65 724305.8 157.16 465289.74 724308.35 157.16 465286.43 724309.76 157.16 465292.53 724323.95 157.16 465327.03 724309.05 157.16 465320.92 724294.87 157.16 465319.8 724295.35 157.16 465316.53 724287.68 157.16 465322.04 724285.32 157.16 465324.33 724290.53 157.16 465326.76 724289.49 157.16 465327.81 724291.92 157.16 465324.26 724293.43 157.16 465330.37 724307.62 157.16 465334.56 724305.8 157.16 465364.88 724292.7 157.16 465361.44 724284.72 157.16 465358.78 724278.54 157.16 465357.68 724279.04 157.16 465354.4 724271.34 157.16 465359.86 724268.98 157.16 465362.16 724274.19 157.16 465364.59 724273.12 157.16 465365.66 724275.53 157.16 465362.12 724277.09 157.16 465365.35 724284.6 157.16 465368.23 724291.26 157.16 465385.1 724283.97 157.16 465402.73 724276.36 157.16 465396.63 724262.18 157.16 465395.53 724262.65 157.16 465392.24 724255.04 157.16 465397.74 724252.64 157.16 465401.04 724260.28 157.16 465399.96 724260.76 157.16 465406.07 724274.92 157.16 465409.61 724273.39 157.16 465401.47 724254.48 157.16 465404.79 724253.07 157.16 465405.25 724254.12 157.16 465421.87 724246.96 157.16 465435.21 724241.22 157.16 465431.57 724244.58 157.16 465432.64 724245.78 157.16 465437.09 724243.57 157.16 465437.37 724244.22 157.16 465423.32 724250.27 157.16 465406.68 724257.43 157.16 465413 724271.92 157.16 465416.84 724270.27 157.16 465422.25 724282.78 157.16 465449.75 724346.52 157.16 465366.83 724382.3 157.16 465363.68 724383.66 157.16 465290.66 724415.17 157.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.56</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465452.12 725583.42 140.02 465456.49 725580.99 140.02 465457.47 725582.73 140.02 465465.61 725578.22 140.02 465463.23 725574.27 140.02 465468.84 725571.19 140.02 465465.55 725565.26 140.02 465460.12 725568.31 140.02 465459.53 725567.23 140.02 465451.36 725571.78 140.02 465453.23 725575.1 140.02 465448.81 725577.51 140.02 465452.12 725583.42 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465452.12 725583.42 140.02 465448.81 725577.51 140.02 465448.81 725577.51 147.58 465452.12 725583.42 147.58 465452.12 725583.42 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465448.81 725577.51 140.02 465453.23 725575.1 140.02 465453.23 725575.1 147.58 465448.81 725577.51 147.58 465448.81 725577.51 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465453.23 725575.1 140.02 465451.36 725571.78 140.02 465451.36 725571.78 147.58 465453.23 725575.1 147.58 465453.23 725575.1 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465451.36 725571.78 140.02 465459.53 725567.23 140.02 465459.53 725567.23 147.58 465451.36 725571.78 147.58 465451.36 725571.78 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465459.53 725567.23 140.02 465460.12 725568.31 140.02 465460.12 725568.31 147.58 465459.53 725567.23 147.58 465459.53 725567.23 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465460.12 725568.31 140.02 465465.55 725565.26 140.02 465465.55 725565.26 147.58 465460.12 725568.31 147.58 465460.12 725568.31 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465465.55 725565.26 140.02 465468.84 725571.19 140.02 465468.84 725571.19 147.58 465465.55 725565.26 147.58 465465.55 725565.26 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465468.84 725571.19 140.02 465463.23 725574.27 140.02 465463.23 725574.27 147.58 465468.84 725571.19 147.58 465468.84 725571.19 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465463.23 725574.27 140.02 465465.61 725578.22 140.02 465465.61 725578.22 147.58 465463.23 725574.27 147.58 465463.23 725574.27 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465465.61 725578.22 140.02 465457.47 725582.73 140.02 465457.47 725582.73 147.58 465465.61 725578.22 147.58 465465.61 725578.22 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465457.47 725582.73 140.02 465456.49 725580.99 140.02 465456.49 725580.99 147.58 465457.47 725582.73 147.58 465457.47 725582.73 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465456.49 725580.99 140.02 465452.12 725583.42 140.02 465452.12 725583.42 147.58 465456.49 725580.99 147.58 465456.49 725580.99 140.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5DCB-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465452.12 725583.42 147.58 465448.81 725577.51 147.58 465453.23 725575.1 147.58 465451.36 725571.78 147.58 465459.53 725567.23 147.58 465460.12 725568.31 147.58 465465.55 725565.26 147.58 465468.84 725571.19 147.58 465463.23 725574.27 147.58 465465.61 725578.22 147.58 465457.47 725582.73 147.58 465456.49 725580.99 147.58 465452.12 725583.42 147.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465461.26 725756.17 142.38 465464.1 725753.98 142.38 465465.44 725755.73 142.38 465469.71 725752.45 142.38 465468.36 725750.71 142.38 465470.8 725748.86 142.38 465472.12 725750.6 142.38 465482.07 725743 142.38 465480.76 725741.25 142.38 465483.15 725739.4 142.38 465484.48 725741.15 142.38 465488.74 725737.88 142.38 465487.42 725736.14 142.38 465490.26 725733.95 142.38 465489.26 725732.64 142.38 465490.4 725731.69 142.38 465486.47 725726.55 142.38 465485.28 725727.47 142.38 465484.28 725726.14 142.38 465481.41 725728.3 142.38 465480.51 725727.14 142.38 465476.25 725730.39 142.38 465477.18 725731.59 142.38 465474.75 725733.42 142.38 465473.85 725732.23 142.38 465463.86 725739.85 142.38 465464.77 725741.02 142.38 465462.38 725742.9 142.38 465461.45 725741.72 142.38 465457.19 725745.04 142.38 465458.09 725746.17 142.38 465455.25 725748.38 142.38 465456.28 725749.72 142.38 465455.09 725750.64 142.38 465459.05 725755.77 142.38 465460.25 725754.86 142.38 465461.26 725756.17 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465461.26 725756.17 142.38 465460.25 725754.86 142.38 465460.25 725754.86 150.17000000000002 465461.26 725756.17 150.17000000000002 465461.26 725756.17 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465460.25 725754.86 142.38 465459.05 725755.77 142.38 465459.05 725755.77 150.17000000000002 465460.25 725754.86 150.17000000000002 465460.25 725754.86 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465459.05 725755.77 142.38 465455.09 725750.64 142.38 465455.09 725750.64 150.17000000000002 465459.05 725755.77 150.17000000000002 465459.05 725755.77 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465455.09 725750.64 142.38 465456.28 725749.72 142.38 465456.28 725749.72 150.17000000000002 465455.09 725750.64 150.17000000000002 465455.09 725750.64 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465456.28 725749.72 142.38 465455.25 725748.38 142.38 465455.25 725748.38 150.17000000000002 465456.28 725749.72 150.17000000000002 465456.28 725749.72 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465455.25 725748.38 142.38 465458.09 725746.17 142.38 465458.09 725746.17 150.17000000000002 465455.25 725748.38 150.17000000000002 465455.25 725748.38 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465458.09 725746.17 142.38 465457.19 725745.04 142.38 465457.19 725745.04 150.17000000000002 465458.09 725746.17 150.17000000000002 465458.09 725746.17 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465457.19 725745.04 142.38 465461.45 725741.72 142.38 465461.45 725741.72 150.17000000000002 465457.19 725745.04 150.17000000000002 465457.19 725745.04 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465461.45 725741.72 142.38 465462.38 725742.9 142.38 465462.38 725742.9 150.17000000000002 465461.45 725741.72 150.17000000000002 465461.45 725741.72 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465462.38 725742.9 142.38 465464.77 725741.02 142.38 465464.77 725741.02 150.17000000000002 465462.38 725742.9 150.17000000000002 465462.38 725742.9 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465464.77 725741.02 142.38 465463.86 725739.85 142.38 465463.86 725739.85 150.17000000000002 465464.77 725741.02 150.17000000000002 465464.77 725741.02 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465463.86 725739.85 142.38 465473.85 725732.23 142.38 465473.85 725732.23 150.17000000000002 465463.86 725739.85 150.17000000000002 465463.86 725739.85 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465473.85 725732.23 142.38 465474.75 725733.42 142.38 465474.75 725733.42 150.17000000000002 465473.85 725732.23 150.17000000000002 465473.85 725732.23 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465474.75 725733.42 142.38 465477.18 725731.59 142.38 465477.18 725731.59 150.17000000000002 465474.75 725733.42 150.17000000000002 465474.75 725733.42 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465477.18 725731.59 142.38 465476.25 725730.39 142.38 465476.25 725730.39 150.17000000000002 465477.18 725731.59 150.17000000000002 465477.18 725731.59 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465476.25 725730.39 142.38 465480.51 725727.14 142.38 465480.51 725727.14 150.17000000000002 465476.25 725730.39 150.17000000000002 465476.25 725730.39 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465480.51 725727.14 142.38 465481.41 725728.3 142.38 465481.41 725728.3 150.17000000000002 465480.51 725727.14 150.17000000000002 465480.51 725727.14 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465481.41 725728.3 142.38 465484.28 725726.14 142.38 465484.28 725726.14 150.17000000000002 465481.41 725728.3 150.17000000000002 465481.41 725728.3 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465484.28 725726.14 142.38 465485.28 725727.47 142.38 465485.28 725727.47 150.17000000000002 465484.28 725726.14 150.17000000000002 465484.28 725726.14 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465485.28 725727.47 142.38 465486.47 725726.55 142.38 465486.47 725726.55 150.17000000000002 465485.28 725727.47 150.17000000000002 465485.28 725727.47 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465486.47 725726.55 142.38 465490.4 725731.69 142.38 465490.4 725731.69 150.17000000000002 465486.47 725726.55 150.17000000000002 465486.47 725726.55 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465490.4 725731.69 142.38 465489.26 725732.64 142.38 465489.26 725732.64 150.17000000000002 465490.4 725731.69 150.17000000000002 465490.4 725731.69 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465489.26 725732.64 142.38 465490.26 725733.95 142.38 465490.26 725733.95 150.17000000000002 465489.26 725732.64 150.17000000000002 465489.26 725732.64 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465490.26 725733.95 142.38 465487.42 725736.14 142.38 465487.42 725736.14 150.17000000000002 465490.26 725733.95 150.17000000000002 465490.26 725733.95 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465487.42 725736.14 142.38 465488.74 725737.88 142.38 465488.74 725737.88 150.17000000000002 465487.42 725736.14 150.17000000000002 465487.42 725736.14 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465488.74 725737.88 142.38 465484.48 725741.15 142.38 465484.48 725741.15 150.17000000000002 465488.74 725737.88 150.17000000000002 465488.74 725737.88 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465484.48 725741.15 142.38 465483.15 725739.4 142.38 465483.15 725739.4 150.17000000000002 465484.48 725741.15 150.17000000000002 465484.48 725741.15 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465483.15 725739.4 142.38 465480.76 725741.25 142.38 465480.76 725741.25 150.17000000000002 465483.15 725739.4 150.17000000000002 465483.15 725739.4 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465480.76 725741.25 142.38 465482.07 725743 142.38 465482.07 725743 150.17000000000002 465480.76 725741.25 150.17000000000002 465480.76 725741.25 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465482.07 725743 142.38 465472.12 725750.6 142.38 465472.12 725750.6 150.17000000000002 465482.07 725743 150.17000000000002 465482.07 725743 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465472.12 725750.6 142.38 465470.8 725748.86 142.38 465470.8 725748.86 150.17000000000002 465472.12 725750.6 150.17000000000002 465472.12 725750.6 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465470.8 725748.86 142.38 465468.36 725750.71 142.38 465468.36 725750.71 150.17000000000002 465470.8 725748.86 150.17000000000002 465470.8 725748.86 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465468.36 725750.71 142.38 465469.71 725752.45 142.38 465469.71 725752.45 150.17000000000002 465468.36 725750.71 150.17000000000002 465468.36 725750.71 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465469.71 725752.45 142.38 465465.44 725755.73 142.38 465465.44 725755.73 150.17000000000002 465469.71 725752.45 150.17000000000002 465469.71 725752.45 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465465.44 725755.73 142.38 465464.1 725753.98 142.38 465464.1 725753.98 150.17000000000002 465465.44 725755.73 150.17000000000002 465465.44 725755.73 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465464.1 725753.98 142.38 465461.26 725756.17 142.38 465461.26 725756.17 150.17000000000002 465464.1 725753.98 150.17000000000002 465464.1 725753.98 142.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4F50-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465461.26 725756.17 150.17000000000002 465460.25 725754.86 150.17000000000002 465459.05 725755.77 150.17000000000002 465455.09 725750.64 150.17000000000002 465456.28 725749.72 150.17000000000002 465455.25 725748.38 150.17000000000002 465458.09 725746.17 150.17000000000002 465457.19 725745.04 150.17000000000002 465461.45 725741.72 150.17000000000002 465462.38 725742.9 150.17000000000002 465464.77 725741.02 150.17000000000002 465463.86 725739.85 150.17000000000002 465473.85 725732.23 150.17000000000002 465474.75 725733.42 150.17000000000002 465477.18 725731.59 150.17000000000002 465476.25 725730.39 150.17000000000002 465480.51 725727.14 150.17000000000002 465481.41 725728.3 150.17000000000002 465484.28 725726.14 150.17000000000002 465485.28 725727.47 150.17000000000002 465486.47 725726.55 150.17000000000002 465490.4 725731.69 150.17000000000002 465489.26 725732.64 150.17000000000002 465490.26 725733.95 150.17000000000002 465487.42 725736.14 150.17000000000002 465488.74 725737.88 150.17000000000002 465484.48 725741.15 150.17000000000002 465483.15 725739.4 150.17000000000002 465480.76 725741.25 150.17000000000002 465482.07 725743 150.17000000000002 465472.12 725750.6 150.17000000000002 465470.8 725748.86 150.17000000000002 465468.36 725750.71 150.17000000000002 465469.71 725752.45 150.17000000000002 465465.44 725755.73 150.17000000000002 465464.1 725753.98 150.17000000000002 465461.26 725756.17 150.17000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6113-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6113-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.93</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6113-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463649.45 724152.24 132.43 463652.55 724150.51 132.43 463646.26 724139.46 132.43 463643.45 724141.54 132.43 463649.45 724152.24 132.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6113-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463649.45 724152.24 132.43 463643.45 724141.54 132.43 463643.45 724141.54 136.36 463649.45 724152.24 136.36 463649.45 724152.24 132.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6113-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463643.45 724141.54 132.43 463646.26 724139.46 132.43 463646.26 724139.46 136.36 463643.45 724141.54 136.36 463643.45 724141.54 132.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6113-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463646.26 724139.46 132.43 463652.55 724150.51 132.43 463652.55 724150.51 136.36 463646.26 724139.46 136.36 463646.26 724139.46 132.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6113-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463652.55 724150.51 132.43 463649.45 724152.24 132.43 463649.45 724152.24 136.36 463652.55 724150.51 136.36 463652.55 724150.51 132.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6113-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>463649.45 724152.24 136.36 463643.45 724141.54 136.36 463646.26 724139.46 136.36 463652.55 724150.51 136.36 463649.45 724152.24 136.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5EA5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5EA5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.08</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5EA5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464471.88 724697.45 137.5 464485.66 724686.97 137.5 464481.91 724681.81 137.5 464468.06 724691.87 137.5 464469.5 724693.85 137.5 464469.58 724693.79 137.5 464471.88 724697.45 137.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5EA5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464471.88 724697.45 137.5 464469.58 724693.79 137.5 464469.58 724693.79 140.58 464471.88 724697.45 140.58 464471.88 724697.45 137.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5EA5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464469.58 724693.79 137.5 464469.5 724693.85 137.5 464469.5 724693.85 140.58 464469.58 724693.79 140.58 464469.58 724693.79 137.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5EA5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464469.5 724693.85 137.5 464468.06 724691.87 137.5 464468.06 724691.87 140.58 464469.5 724693.85 140.58 464469.5 724693.85 137.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5EA5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464468.06 724691.87 137.5 464481.91 724681.81 137.5 464481.91 724681.81 140.58 464468.06 724691.87 140.58 464468.06 724691.87 137.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5EA5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464481.91 724681.81 137.5 464485.66 724686.97 137.5 464485.66 724686.97 140.58 464481.91 724681.81 140.58 464481.91 724681.81 137.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5EA5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464485.66 724686.97 137.5 464471.88 724697.45 137.5 464471.88 724697.45 140.58 464485.66 724686.97 140.58 464485.66 724686.97 137.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5EA5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464471.88 724697.45 140.58 464469.58 724693.79 140.58 464469.5 724693.85 140.58 464468.06 724691.87 140.58 464481.91 724681.81 140.58 464485.66 724686.97 140.58 464471.88 724697.45 140.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.97</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465306.88 725647.78 139.75 465314.02 725645.15 139.75 465311.84 725639.25 139.75 465315.36 725637.95 139.75 465311.86 725628.41 139.75 465302.19 725631.97 139.75 465302.5 725632.83 139.75 465300.42 725633.67 139.75 465299.64 725631.53 139.75 465292.4 725634.18 139.75 465296.34 725644.95 139.75 465300.67 725643.38 139.75 465300.34 725642.51 139.75 465302.58 725641.67 139.75 465302.9 725642.57 139.75 465304.74 725641.88 139.75 465306.88 725647.78 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465306.88 725647.78 139.75 465304.74 725641.88 139.75 465304.74 725641.88 144.72 465306.88 725647.78 144.72 465306.88 725647.78 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465304.74 725641.88 139.75 465302.9 725642.57 139.75 465302.9 725642.57 144.72 465304.74 725641.88 144.72 465304.74 725641.88 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465302.9 725642.57 139.75 465302.58 725641.67 139.75 465302.58 725641.67 144.72 465302.9 725642.57 144.72 465302.9 725642.57 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465302.58 725641.67 139.75 465300.34 725642.51 139.75 465300.34 725642.51 144.72 465302.58 725641.67 144.72 465302.58 725641.67 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465300.34 725642.51 139.75 465300.67 725643.38 139.75 465300.67 725643.38 144.72 465300.34 725642.51 144.72 465300.34 725642.51 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465300.67 725643.38 139.75 465296.34 725644.95 139.75 465296.34 725644.95 144.72 465300.67 725643.38 144.72 465300.67 725643.38 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465296.34 725644.95 139.75 465292.4 725634.18 139.75 465292.4 725634.18 144.72 465296.34 725644.95 144.72 465296.34 725644.95 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465292.4 725634.18 139.75 465299.64 725631.53 139.75 465299.64 725631.53 144.72 465292.4 725634.18 144.72 465292.4 725634.18 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465299.64 725631.53 139.75 465300.42 725633.67 139.75 465300.42 725633.67 144.72 465299.64 725631.53 144.72 465299.64 725631.53 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465300.42 725633.67 139.75 465302.5 725632.83 139.75 465302.5 725632.83 144.72 465300.42 725633.67 144.72 465300.42 725633.67 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465302.5 725632.83 139.75 465302.19 725631.97 139.75 465302.19 725631.97 144.72 465302.5 725632.83 144.72 465302.5 725632.83 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465302.19 725631.97 139.75 465311.86 725628.41 139.75 465311.86 725628.41 144.72 465302.19 725631.97 144.72 465302.19 725631.97 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465311.86 725628.41 139.75 465315.36 725637.95 139.75 465315.36 725637.95 144.72 465311.86 725628.41 144.72 465311.86 725628.41 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465315.36 725637.95 139.75 465311.84 725639.25 139.75 465311.84 725639.25 144.72 465315.36 725637.95 144.72 465315.36 725637.95 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465311.84 725639.25 139.75 465314.02 725645.15 139.75 465314.02 725645.15 144.72 465311.84 725639.25 144.72 465311.84 725639.25 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465314.02 725645.15 139.75 465306.88 725647.78 139.75 465306.88 725647.78 144.72 465314.02 725645.15 144.72 465314.02 725645.15 139.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C27-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465306.88 725647.78 144.72 465304.74 725641.88 144.72 465302.9 725642.57 144.72 465302.58 725641.67 144.72 465300.34 725642.51 144.72 465300.67 725643.38 144.72 465296.34 725644.95 144.72 465292.4 725634.18 144.72 465299.64 725631.53 144.72 465300.42 725633.67 144.72 465302.5 725632.83 144.72 465302.19 725631.97 144.72 465311.86 725628.41 144.72 465315.36 725637.95 144.72 465311.84 725639.25 144.72 465314.02 725645.15 144.72 465306.88 725647.78 144.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6C74-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6C74-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.06</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C74-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464051.15 723608.11 130.66 464051.32 723608.06 130.66 464057.7 723606.07 130.66 464055.78 723600.28 130.66 464049.3 723602.29 130.66 464051.15 723608.11 130.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C74-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464051.15 723608.11 130.66 464049.3 723602.29 130.66 464049.3 723602.29 134.72 464051.15 723608.11 134.72 464051.15 723608.11 130.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C74-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464049.3 723602.29 130.66 464055.78 723600.28 130.66 464055.78 723600.28 134.72 464049.3 723602.29 134.72 464049.3 723602.29 130.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C74-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464055.78 723600.28 130.66 464057.7 723606.07 130.66 464057.7 723606.07 134.72 464055.78 723600.28 134.72 464055.78 723600.28 130.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C74-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464057.7 723606.07 130.66 464051.32 723608.06 130.66 464051.32 723608.06 134.72 464057.7 723606.07 134.72 464057.7 723606.07 130.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C74-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464051.32 723608.06 130.66 464051.15 723608.11 130.66 464051.15 723608.11 134.72 464051.32 723608.06 134.72 464051.32 723608.06 130.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C74-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464051.15 723608.11 134.72 464049.3 723602.29 134.72 464055.78 723600.28 134.72 464057.7 723606.07 134.72 464051.32 723608.06 134.72 464051.15 723608.11 134.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700">
			<gen:stringAttribute name="buildingId">
				<gen:value>91d09dba-4e7f-47a1-a616-9078731a1700</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.07</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465423.22 725734.53 142.71 465422.86 725734.05 142.71 465425.11 725732.34 142.71 465425.46 725732.81 142.71 465427.98 725730.87 142.71 465427.35 725730.04 142.71 465437.02 725722.64 142.71 465437.66 725723.48 142.71 465440.19 725721.54 142.71 465439.82 725721.07 142.71 465442.06 725719.35 142.71 465442.43 725719.82 142.71 465445.56 725717.42 142.71 465439.33 725709.33 142.71 465434.02 725713.37 142.71 465433.32 725712.46 142.71 465433.13 725712.6 142.71 465433.84 725713.52 142.71 465431.42 725715.38 142.71 465432.05 725716.2 142.71 465422.37 725723.6 142.71 465421.73 725722.78 142.71 465419.29 725724.64 142.71 465418.59 725723.73 142.71 465418.4 725723.86 142.71 465419.11 725724.78 142.71 465413.83 725728.82 142.71 465420.07 725736.94 142.71 465423.22 725734.53 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465423.22 725734.53 142.71 465420.07 725736.94 142.71 465420.07 725736.94 148.78 465423.22 725734.53 148.78 465423.22 725734.53 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465420.07 725736.94 142.71 465413.83 725728.82 142.71 465413.83 725728.82 148.78 465420.07 725736.94 148.78 465420.07 725736.94 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465413.83 725728.82 142.71 465419.11 725724.78 142.71 465419.11 725724.78 148.78 465413.83 725728.82 148.78 465413.83 725728.82 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465419.11 725724.78 142.71 465418.4 725723.86 142.71 465418.4 725723.86 148.78 465419.11 725724.78 148.78 465419.11 725724.78 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.4 725723.86 142.71 465418.59 725723.73 142.71 465418.59 725723.73 148.78 465418.4 725723.86 148.78 465418.4 725723.86 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.59 725723.73 142.71 465419.29 725724.64 142.71 465419.29 725724.64 148.78 465418.59 725723.73 148.78 465418.59 725723.73 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465419.29 725724.64 142.71 465421.73 725722.78 142.71 465421.73 725722.78 148.78 465419.29 725724.64 148.78 465419.29 725724.64 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465421.73 725722.78 142.71 465422.37 725723.6 142.71 465422.37 725723.6 148.78 465421.73 725722.78 148.78 465421.73 725722.78 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465422.37 725723.6 142.71 465432.05 725716.2 142.71 465432.05 725716.2 148.78 465422.37 725723.6 148.78 465422.37 725723.6 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465432.05 725716.2 142.71 465431.42 725715.38 142.71 465431.42 725715.38 148.78 465432.05 725716.2 148.78 465432.05 725716.2 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465431.42 725715.38 142.71 465433.84 725713.52 142.71 465433.84 725713.52 148.78 465431.42 725715.38 148.78 465431.42 725715.38 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465433.84 725713.52 142.71 465433.13 725712.6 142.71 465433.13 725712.6 148.78 465433.84 725713.52 148.78 465433.84 725713.52 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465433.13 725712.6 142.71 465433.32 725712.46 142.71 465433.32 725712.46 148.78 465433.13 725712.6 148.78 465433.13 725712.6 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465433.32 725712.46 142.71 465434.02 725713.37 142.71 465434.02 725713.37 148.78 465433.32 725712.46 148.78 465433.32 725712.46 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465434.02 725713.37 142.71 465439.33 725709.33 142.71 465439.33 725709.33 148.78 465434.02 725713.37 148.78 465434.02 725713.37 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465439.33 725709.33 142.71 465445.56 725717.42 142.71 465445.56 725717.42 148.78 465439.33 725709.33 148.78 465439.33 725709.33 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465445.56 725717.42 142.71 465442.43 725719.82 142.71 465442.43 725719.82 148.78 465445.56 725717.42 148.78 465445.56 725717.42 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465442.43 725719.82 142.71 465442.06 725719.35 142.71 465442.06 725719.35 148.78 465442.43 725719.82 148.78 465442.43 725719.82 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465442.06 725719.35 142.71 465439.82 725721.07 142.71 465439.82 725721.07 148.78 465442.06 725719.35 148.78 465442.06 725719.35 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465439.82 725721.07 142.71 465440.19 725721.54 142.71 465440.19 725721.54 148.78 465439.82 725721.07 148.78 465439.82 725721.07 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465440.19 725721.54 142.71 465437.66 725723.48 142.71 465437.66 725723.48 148.78 465440.19 725721.54 148.78 465440.19 725721.54 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465437.66 725723.48 142.71 465437.02 725722.64 142.71 465437.02 725722.64 148.78 465437.66 725723.48 148.78 465437.66 725723.48 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465437.02 725722.64 142.71 465427.35 725730.04 142.71 465427.35 725730.04 148.78 465437.02 725722.64 148.78 465437.02 725722.64 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465427.35 725730.04 142.71 465427.98 725730.87 142.71 465427.98 725730.87 148.78 465427.35 725730.04 148.78 465427.35 725730.04 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465427.98 725730.87 142.71 465425.46 725732.81 142.71 465425.46 725732.81 148.78 465427.98 725730.87 148.78 465427.98 725730.87 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465425.46 725732.81 142.71 465425.11 725732.34 142.71 465425.11 725732.34 148.78 465425.46 725732.81 148.78 465425.46 725732.81 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465425.11 725732.34 142.71 465422.86 725734.05 142.71 465422.86 725734.05 148.78 465425.11 725732.34 148.78 465425.11 725732.34 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465422.86 725734.05 142.71 465423.22 725734.53 142.71 465423.22 725734.53 148.78 465422.86 725734.05 148.78 465422.86 725734.05 142.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91d09dba-4e7f-47a1-a616-9078731a1700_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465423.22 725734.53 148.78 465420.07 725736.94 148.78 465413.83 725728.82 148.78 465419.11 725724.78 148.78 465418.4 725723.86 148.78 465418.59 725723.73 148.78 465419.29 725724.64 148.78 465421.73 725722.78 148.78 465422.37 725723.6 148.78 465432.05 725716.2 148.78 465431.42 725715.38 148.78 465433.84 725713.52 148.78 465433.13 725712.6 148.78 465433.32 725712.46 148.78 465434.02 725713.37 148.78 465439.33 725709.33 148.78 465445.56 725717.42 148.78 465442.43 725719.82 148.78 465442.06 725719.35 148.78 465439.82 725721.07 148.78 465440.19 725721.54 148.78 465437.66 725723.48 148.78 465437.02 725722.64 148.78 465427.35 725730.04 148.78 465427.98 725730.87 148.78 465425.46 725732.81 148.78 465425.11 725732.34 148.78 465422.86 725734.05 148.78 465423.22 725734.53 148.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a">
			<gen:stringAttribute name="buildingId">
				<gen:value>f670a78f-9159-4702-a87d-62b8f70b9d5a</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">18.04</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465218.41 724842.87 136.83 465211.76 724847.34 136.83 465211.82 724847.42 136.83 465203.68 724852.98 136.83 465203.53 724852.77 136.83 465202.24 724853.66 136.83 465203.28 724855.2 136.83 465205 724857.73 136.83 465205.25 724857.57 136.83 465207.5 724860.87 136.83 465207.25 724861.04 136.83 465220.44 724880.44 136.83 465207.16 724889.45 136.83 465194.02 724870.09 136.83 465193.82 724870.22 136.83 465188.9 724863.06 136.83 465173.16 724873.73 136.83 465174.07 724875.07 136.83 465182.72 724887.78 136.83 465182.47 724887.94 136.83 465209.3 724927.47 136.83 465225.38 724916.56 136.83 465224.58 724915.39 136.83 465224.47 724915.46 136.83 465224.22 724915.09 136.83 465220.07 724908.99 136.83 465233.84 724899.64 136.83 465238 724905.77 136.83 465238.23 724906.11 136.83 465238.12 724906.18 136.83 465238.91 724907.34 136.83 465254.98 724896.44 136.83 465254.16 724895.23 136.83 465254.02 724895.32 136.83 465253.44 724894.47 136.83 465253.36 724894.53 136.83 465250.55 724890.4 136.83 465250.63 724890.35 136.83 465248.75 724887.57 136.83 465248.68 724887.62 136.83 465245.87 724883.5 136.83 465245.95 724883.44 136.83 465244.07 724880.66 136.83 465243.99 724880.72 136.83 465241.19 724876.58 136.83 465241.4 724876.44 136.83 465232.58 724863.45 136.83 465228.1 724856.84 136.83 465227.6 724856.11 136.83 465227.39 724856.25 136.83 465223.98 724851.23 136.83 465224.06 724851.17 136.83 465218.41 724842.87 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465218.41 724842.87 136.83 465224.06 724851.17 136.83 465224.06 724851.17 154.87 465218.41 724842.87 154.87 465218.41 724842.87 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465224.06 724851.17 136.83 465223.98 724851.23 136.83 465223.98 724851.23 154.87 465224.06 724851.17 154.87 465224.06 724851.17 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465223.98 724851.23 136.83 465227.39 724856.25 136.83 465227.39 724856.25 154.87 465223.98 724851.23 154.87 465223.98 724851.23 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465227.39 724856.25 136.83 465227.6 724856.11 136.83 465227.6 724856.11 154.87 465227.39 724856.25 154.87 465227.39 724856.25 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465227.6 724856.11 136.83 465228.1 724856.84 136.83 465228.1 724856.84 154.87 465227.6 724856.11 154.87 465227.6 724856.11 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465228.1 724856.84 136.83 465232.58 724863.45 136.83 465232.58 724863.45 154.87 465228.1 724856.84 154.87 465228.1 724856.84 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465232.58 724863.45 136.83 465241.4 724876.44 136.83 465241.4 724876.44 154.87 465232.58 724863.45 154.87 465232.58 724863.45 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465241.4 724876.44 136.83 465241.19 724876.58 136.83 465241.19 724876.58 154.87 465241.4 724876.44 154.87 465241.4 724876.44 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465241.19 724876.58 136.83 465243.99 724880.72 136.83 465243.99 724880.72 154.87 465241.19 724876.58 154.87 465241.19 724876.58 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465243.99 724880.72 136.83 465244.07 724880.66 136.83 465244.07 724880.66 154.87 465243.99 724880.72 154.87 465243.99 724880.72 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465244.07 724880.66 136.83 465245.95 724883.44 136.83 465245.95 724883.44 154.87 465244.07 724880.66 154.87 465244.07 724880.66 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465245.95 724883.44 136.83 465245.87 724883.5 136.83 465245.87 724883.5 154.87 465245.95 724883.44 154.87 465245.95 724883.44 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465245.87 724883.5 136.83 465248.68 724887.62 136.83 465248.68 724887.62 154.87 465245.87 724883.5 154.87 465245.87 724883.5 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465248.68 724887.62 136.83 465248.75 724887.57 136.83 465248.75 724887.57 154.87 465248.68 724887.62 154.87 465248.68 724887.62 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465248.75 724887.57 136.83 465250.63 724890.35 136.83 465250.63 724890.35 154.87 465248.75 724887.57 154.87 465248.75 724887.57 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465250.63 724890.35 136.83 465250.55 724890.4 136.83 465250.55 724890.4 154.87 465250.63 724890.35 154.87 465250.63 724890.35 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465250.55 724890.4 136.83 465253.36 724894.53 136.83 465253.36 724894.53 154.87 465250.55 724890.4 154.87 465250.55 724890.4 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465253.36 724894.53 136.83 465253.44 724894.47 136.83 465253.44 724894.47 154.87 465253.36 724894.53 154.87 465253.36 724894.53 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465253.44 724894.47 136.83 465254.02 724895.32 136.83 465254.02 724895.32 154.87 465253.44 724894.47 154.87 465253.44 724894.47 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465254.02 724895.32 136.83 465254.16 724895.23 136.83 465254.16 724895.23 154.87 465254.02 724895.32 154.87 465254.02 724895.32 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465254.16 724895.23 136.83 465254.98 724896.44 136.83 465254.98 724896.44 154.87 465254.16 724895.23 154.87 465254.16 724895.23 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465254.98 724896.44 136.83 465238.91 724907.34 136.83 465238.91 724907.34 154.87 465254.98 724896.44 154.87 465254.98 724896.44 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465238.91 724907.34 136.83 465238.12 724906.18 136.83 465238.12 724906.18 154.87 465238.91 724907.34 154.87 465238.91 724907.34 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465238.12 724906.18 136.83 465238.23 724906.11 136.83 465238.23 724906.11 154.87 465238.12 724906.18 154.87 465238.12 724906.18 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465238.23 724906.11 136.83 465238 724905.77 136.83 465238 724905.77 154.87 465238.23 724906.11 154.87 465238.23 724906.11 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465238 724905.77 136.83 465233.84 724899.64 136.83 465233.84 724899.64 154.87 465238 724905.77 154.87 465238 724905.77 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465233.84 724899.64 136.83 465220.07 724908.99 136.83 465220.07 724908.99 154.87 465233.84 724899.64 154.87 465233.84 724899.64 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465220.07 724908.99 136.83 465224.22 724915.09 136.83 465224.22 724915.09 154.87 465220.07 724908.99 154.87 465220.07 724908.99 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465224.22 724915.09 136.83 465224.47 724915.46 136.83 465224.47 724915.46 154.87 465224.22 724915.09 154.87 465224.22 724915.09 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465224.47 724915.46 136.83 465224.58 724915.39 136.83 465224.58 724915.39 154.87 465224.47 724915.46 154.87 465224.47 724915.46 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465224.58 724915.39 136.83 465225.38 724916.56 136.83 465225.38 724916.56 154.87 465224.58 724915.39 154.87 465224.58 724915.39 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465225.38 724916.56 136.83 465209.3 724927.47 136.83 465209.3 724927.47 154.87 465225.38 724916.56 154.87 465225.38 724916.56 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465209.3 724927.47 136.83 465182.47 724887.94 136.83 465182.47 724887.94 154.87 465209.3 724927.47 154.87 465209.3 724927.47 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465182.47 724887.94 136.83 465182.72 724887.78 136.83 465182.72 724887.78 154.87 465182.47 724887.94 154.87 465182.47 724887.94 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465182.72 724887.78 136.83 465174.07 724875.07 136.83 465174.07 724875.07 154.87 465182.72 724887.78 154.87 465182.72 724887.78 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465174.07 724875.07 136.83 465173.16 724873.73 136.83 465173.16 724873.73 154.87 465174.07 724875.07 154.87 465174.07 724875.07 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465173.16 724873.73 136.83 465188.9 724863.06 136.83 465188.9 724863.06 154.87 465173.16 724873.73 154.87 465173.16 724873.73 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465188.9 724863.06 136.83 465193.82 724870.22 136.83 465193.82 724870.22 154.87 465188.9 724863.06 154.87 465188.9 724863.06 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465193.82 724870.22 136.83 465194.02 724870.09 136.83 465194.02 724870.09 154.87 465193.82 724870.22 154.87 465193.82 724870.22 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465194.02 724870.09 136.83 465207.16 724889.45 136.83 465207.16 724889.45 154.87 465194.02 724870.09 154.87 465194.02 724870.09 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465207.16 724889.45 136.83 465220.44 724880.44 136.83 465220.44 724880.44 154.87 465207.16 724889.45 154.87 465207.16 724889.45 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465220.44 724880.44 136.83 465207.25 724861.04 136.83 465207.25 724861.04 154.87 465220.44 724880.44 154.87 465220.44 724880.44 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465207.25 724861.04 136.83 465207.5 724860.87 136.83 465207.5 724860.87 154.87 465207.25 724861.04 154.87 465207.25 724861.04 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465207.5 724860.87 136.83 465205.25 724857.57 136.83 465205.25 724857.57 154.87 465207.5 724860.87 154.87 465207.5 724860.87 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465205.25 724857.57 136.83 465205 724857.73 136.83 465205 724857.73 154.87 465205.25 724857.57 154.87 465205.25 724857.57 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465205 724857.73 136.83 465203.28 724855.2 136.83 465203.28 724855.2 154.87 465205 724857.73 154.87 465205 724857.73 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465203.28 724855.2 136.83 465202.24 724853.66 136.83 465202.24 724853.66 154.87 465203.28 724855.2 154.87 465203.28 724855.2 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465202.24 724853.66 136.83 465203.53 724852.77 136.83 465203.53 724852.77 154.87 465202.24 724853.66 154.87 465202.24 724853.66 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465203.53 724852.77 136.83 465203.68 724852.98 136.83 465203.68 724852.98 154.87 465203.53 724852.77 154.87 465203.53 724852.77 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465203.68 724852.98 136.83 465211.82 724847.42 136.83 465211.82 724847.42 154.87 465203.68 724852.98 154.87 465203.68 724852.98 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465211.82 724847.42 136.83 465211.76 724847.34 136.83 465211.76 724847.34 154.87 465211.82 724847.42 154.87 465211.82 724847.42 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465211.76 724847.34 136.83 465218.41 724842.87 136.83 465218.41 724842.87 154.87 465211.76 724847.34 154.87 465211.76 724847.34 136.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f670a78f-9159-4702-a87d-62b8f70b9d5a_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465218.41 724842.87 154.87 465224.06 724851.17 154.87 465223.98 724851.23 154.87 465227.39 724856.25 154.87 465227.6 724856.11 154.87 465228.1 724856.84 154.87 465232.58 724863.45 154.87 465241.4 724876.44 154.87 465241.19 724876.58 154.87 465243.99 724880.72 154.87 465244.07 724880.66 154.87 465245.95 724883.44 154.87 465245.87 724883.5 154.87 465248.68 724887.62 154.87 465248.75 724887.57 154.87 465250.63 724890.35 154.87 465250.55 724890.4 154.87 465253.36 724894.53 154.87 465253.44 724894.47 154.87 465254.02 724895.32 154.87 465254.16 724895.23 154.87 465254.98 724896.44 154.87 465238.91 724907.34 154.87 465238.12 724906.18 154.87 465238.23 724906.11 154.87 465238 724905.77 154.87 465233.84 724899.64 154.87 465220.07 724908.99 154.87 465224.22 724915.09 154.87 465224.47 724915.46 154.87 465224.58 724915.39 154.87 465225.38 724916.56 154.87 465209.3 724927.47 154.87 465182.47 724887.94 154.87 465182.72 724887.78 154.87 465174.07 724875.07 154.87 465173.16 724873.73 154.87 465188.9 724863.06 154.87 465193.82 724870.22 154.87 465194.02 724870.09 154.87 465207.16 724889.45 154.87 465220.44 724880.44 154.87 465207.25 724861.04 154.87 465207.5 724860.87 154.87 465205.25 724857.57 154.87 465205 724857.73 154.87 465203.28 724855.2 154.87 465202.24 724853.66 154.87 465203.53 724852.77 154.87 465203.68 724852.98 154.87 465211.82 724847.42 154.87 465211.76 724847.34 154.87 465218.41 724842.87 154.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528">
			<gen:stringAttribute name="buildingId">
				<gen:value>29f596c2-2b38-4268-aff9-4645c1600528</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.02</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465295.87 725814.33 140.19 465302.82 725823.46 140.19 465304.53 725822.14 140.19 465306 725824.03 140.19 465307.86 725822.61 140.19 465310.37 725825.8 140.19 465316.67 725820.96 140.19 465314.26 725817.71 140.19 465316.11 725816.31 140.19 465314.65 725814.42 140.19 465316.37 725813.09 140.19 465309.45 725803.98 140.19 465295.87 725814.33 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465295.87 725814.33 140.19 465309.45 725803.98 140.19 465309.45 725803.98 147.21 465295.87 725814.33 147.21 465295.87 725814.33 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465309.45 725803.98 140.19 465316.37 725813.09 140.19 465316.37 725813.09 147.21 465309.45 725803.98 147.21 465309.45 725803.98 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465316.37 725813.09 140.19 465314.65 725814.42 140.19 465314.65 725814.42 147.21 465316.37 725813.09 147.21 465316.37 725813.09 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465314.65 725814.42 140.19 465316.11 725816.31 140.19 465316.11 725816.31 147.21 465314.65 725814.42 147.21 465314.65 725814.42 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465316.11 725816.31 140.19 465314.26 725817.71 140.19 465314.26 725817.71 147.21 465316.11 725816.31 147.21 465316.11 725816.31 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465314.26 725817.71 140.19 465316.67 725820.96 140.19 465316.67 725820.96 147.21 465314.26 725817.71 147.21 465314.26 725817.71 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465316.67 725820.96 140.19 465310.37 725825.8 140.19 465310.37 725825.8 147.21 465316.67 725820.96 147.21 465316.67 725820.96 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465310.37 725825.8 140.19 465307.86 725822.61 140.19 465307.86 725822.61 147.21 465310.37 725825.8 147.21 465310.37 725825.8 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465307.86 725822.61 140.19 465306 725824.03 140.19 465306 725824.03 147.21 465307.86 725822.61 147.21 465307.86 725822.61 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465306 725824.03 140.19 465304.53 725822.14 140.19 465304.53 725822.14 147.21 465306 725824.03 147.21 465306 725824.03 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465304.53 725822.14 140.19 465302.82 725823.46 140.19 465302.82 725823.46 147.21 465304.53 725822.14 147.21 465304.53 725822.14 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465302.82 725823.46 140.19 465295.87 725814.33 140.19 465295.87 725814.33 147.21 465302.82 725823.46 147.21 465302.82 725823.46 140.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-29f596c2-2b38-4268-aff9-4645c1600528_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465295.87 725814.33 147.21 465309.45 725803.98 147.21 465316.37 725813.09 147.21 465314.65 725814.42 147.21 465316.11 725816.31 147.21 465314.26 725817.71 147.21 465316.67 725820.96 147.21 465310.37 725825.8 147.21 465307.86 725822.61 147.21 465306 725824.03 147.21 465304.53 725822.14 147.21 465302.82 725823.46 147.21 465295.87 725814.33 147.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.44</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465331.67 725653.15 140.76 465334.8 725661.52 140.76 465336.12 725661.05 140.76 465339.51 725670.03 140.76 465345.72 725667.74 140.76 465342.44 725658.71 140.76 465344.89 725657.75 140.76 465343.94 725654.97 140.76 465344.39 725653.81 140.76 465343.46 725651.14 140.76 465342.32 725650.6 140.76 465341.8 725649.34 140.76 465331.67 725653.15 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465331.67 725653.15 140.76 465341.8 725649.34 140.76 465341.8 725649.34 147.20000000000002 465331.67 725653.15 147.20000000000002 465331.67 725653.15 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465341.8 725649.34 140.76 465342.32 725650.6 140.76 465342.32 725650.6 147.20000000000002 465341.8 725649.34 147.20000000000002 465341.8 725649.34 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465342.32 725650.6 140.76 465343.46 725651.14 140.76 465343.46 725651.14 147.20000000000002 465342.32 725650.6 147.20000000000002 465342.32 725650.6 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465343.46 725651.14 140.76 465344.39 725653.81 140.76 465344.39 725653.81 147.20000000000002 465343.46 725651.14 147.20000000000002 465343.46 725651.14 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465344.39 725653.81 140.76 465343.94 725654.97 140.76 465343.94 725654.97 147.20000000000002 465344.39 725653.81 147.20000000000002 465344.39 725653.81 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465343.94 725654.97 140.76 465344.89 725657.75 140.76 465344.89 725657.75 147.20000000000002 465343.94 725654.97 147.20000000000002 465343.94 725654.97 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465344.89 725657.75 140.76 465342.44 725658.71 140.76 465342.44 725658.71 147.20000000000002 465344.89 725657.75 147.20000000000002 465344.89 725657.75 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465342.44 725658.71 140.76 465345.72 725667.74 140.76 465345.72 725667.74 147.20000000000002 465342.44 725658.71 147.20000000000002 465342.44 725658.71 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465345.72 725667.74 140.76 465339.51 725670.03 140.76 465339.51 725670.03 147.20000000000002 465345.72 725667.74 147.20000000000002 465345.72 725667.74 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465339.51 725670.03 140.76 465336.12 725661.05 140.76 465336.12 725661.05 147.20000000000002 465339.51 725670.03 147.20000000000002 465339.51 725670.03 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465336.12 725661.05 140.76 465334.8 725661.52 140.76 465334.8 725661.52 147.20000000000002 465336.12 725661.05 147.20000000000002 465336.12 725661.05 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465334.8 725661.52 140.76 465331.67 725653.15 140.76 465331.67 725653.15 147.20000000000002 465334.8 725661.52 147.20000000000002 465334.8 725661.52 140.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B8F-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465331.67 725653.15 147.20000000000002 465341.8 725649.34 147.20000000000002 465342.32 725650.6 147.20000000000002 465343.46 725651.14 147.20000000000002 465344.39 725653.81 147.20000000000002 465343.94 725654.97 147.20000000000002 465344.89 725657.75 147.20000000000002 465342.44 725658.71 147.20000000000002 465345.72 725667.74 147.20000000000002 465339.51 725670.03 147.20000000000002 465336.12 725661.05 147.20000000000002 465334.8 725661.52 147.20000000000002 465331.67 725653.15 147.20000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530">
			<gen:stringAttribute name="buildingId">
				<gen:value>ed37e973-2ff5-4d4e-9142-b41d1acc9530</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465409.93 725804.63 141.98 465410.35 725805.16 141.98 465410.7 725804.89 141.98 465412.03 725806.61 141.98 465411.67 725806.88 141.98 465412.09 725807.42 141.98 465412.45 725807.14 141.98 465413.98 725809.13 141.98 465414.38 725808.82 141.98 465418.24 725813.82 141.98 465425.39 725808.31 141.98 465421.6 725803.29 141.98 465422.01 725802.97 141.98 465420.32 725800.8 141.98 465420.68 725800.52 141.98 465420.27 725800 141.98 465419.91 725800.28 141.98 465418.85 725798.91 141.98 465419.2 725798.63 141.98 465418.79 725798.11 141.98 465418.44 725798.38 141.98 465416.76 725796.21 141.98 465414.07 725798.27 141.98 465413.7 725797.8 141.98 465411.12 725799.77 141.98 465411.49 725800.25 141.98 465408.75 725802.35 141.98 465410.29 725804.35 141.98 465409.93 725804.63 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465409.93 725804.63 141.98 465410.29 725804.35 141.98 465410.29 725804.35 148.92000000000002 465409.93 725804.63 148.92000000000002 465409.93 725804.63 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465410.29 725804.35 141.98 465408.75 725802.35 141.98 465408.75 725802.35 148.92000000000002 465410.29 725804.35 148.92000000000002 465410.29 725804.35 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465408.75 725802.35 141.98 465411.49 725800.25 141.98 465411.49 725800.25 148.92000000000002 465408.75 725802.35 148.92000000000002 465408.75 725802.35 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465411.49 725800.25 141.98 465411.12 725799.77 141.98 465411.12 725799.77 148.92000000000002 465411.49 725800.25 148.92000000000002 465411.49 725800.25 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465411.12 725799.77 141.98 465413.7 725797.8 141.98 465413.7 725797.8 148.92000000000002 465411.12 725799.77 148.92000000000002 465411.12 725799.77 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465413.7 725797.8 141.98 465414.07 725798.27 141.98 465414.07 725798.27 148.92000000000002 465413.7 725797.8 148.92000000000002 465413.7 725797.8 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465414.07 725798.27 141.98 465416.76 725796.21 141.98 465416.76 725796.21 148.92000000000002 465414.07 725798.27 148.92000000000002 465414.07 725798.27 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465416.76 725796.21 141.98 465418.44 725798.38 141.98 465418.44 725798.38 148.92000000000002 465416.76 725796.21 148.92000000000002 465416.76 725796.21 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.44 725798.38 141.98 465418.79 725798.11 141.98 465418.79 725798.11 148.92000000000002 465418.44 725798.38 148.92000000000002 465418.44 725798.38 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.79 725798.11 141.98 465419.2 725798.63 141.98 465419.2 725798.63 148.92000000000002 465418.79 725798.11 148.92000000000002 465418.79 725798.11 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465419.2 725798.63 141.98 465418.85 725798.91 141.98 465418.85 725798.91 148.92000000000002 465419.2 725798.63 148.92000000000002 465419.2 725798.63 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.85 725798.91 141.98 465419.91 725800.28 141.98 465419.91 725800.28 148.92000000000002 465418.85 725798.91 148.92000000000002 465418.85 725798.91 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465419.91 725800.28 141.98 465420.27 725800 141.98 465420.27 725800 148.92000000000002 465419.91 725800.28 148.92000000000002 465419.91 725800.28 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465420.27 725800 141.98 465420.68 725800.52 141.98 465420.68 725800.52 148.92000000000002 465420.27 725800 148.92000000000002 465420.27 725800 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465420.68 725800.52 141.98 465420.32 725800.8 141.98 465420.32 725800.8 148.92000000000002 465420.68 725800.52 148.92000000000002 465420.68 725800.52 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465420.32 725800.8 141.98 465422.01 725802.97 141.98 465422.01 725802.97 148.92000000000002 465420.32 725800.8 148.92000000000002 465420.32 725800.8 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465422.01 725802.97 141.98 465421.6 725803.29 141.98 465421.6 725803.29 148.92000000000002 465422.01 725802.97 148.92000000000002 465422.01 725802.97 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465421.6 725803.29 141.98 465425.39 725808.31 141.98 465425.39 725808.31 148.92000000000002 465421.6 725803.29 148.92000000000002 465421.6 725803.29 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465425.39 725808.31 141.98 465418.24 725813.82 141.98 465418.24 725813.82 148.92000000000002 465425.39 725808.31 148.92000000000002 465425.39 725808.31 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.24 725813.82 141.98 465414.38 725808.82 141.98 465414.38 725808.82 148.92000000000002 465418.24 725813.82 148.92000000000002 465418.24 725813.82 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465414.38 725808.82 141.98 465413.98 725809.13 141.98 465413.98 725809.13 148.92000000000002 465414.38 725808.82 148.92000000000002 465414.38 725808.82 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465413.98 725809.13 141.98 465412.45 725807.14 141.98 465412.45 725807.14 148.92000000000002 465413.98 725809.13 148.92000000000002 465413.98 725809.13 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465412.45 725807.14 141.98 465412.09 725807.42 141.98 465412.09 725807.42 148.92000000000002 465412.45 725807.14 148.92000000000002 465412.45 725807.14 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465412.09 725807.42 141.98 465411.67 725806.88 141.98 465411.67 725806.88 148.92000000000002 465412.09 725807.42 148.92000000000002 465412.09 725807.42 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465411.67 725806.88 141.98 465412.03 725806.61 141.98 465412.03 725806.61 148.92000000000002 465411.67 725806.88 148.92000000000002 465411.67 725806.88 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465412.03 725806.61 141.98 465410.7 725804.89 141.98 465410.7 725804.89 148.92000000000002 465412.03 725806.61 148.92000000000002 465412.03 725806.61 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465410.7 725804.89 141.98 465410.35 725805.16 141.98 465410.35 725805.16 148.92000000000002 465410.7 725804.89 148.92000000000002 465410.7 725804.89 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465410.35 725805.16 141.98 465409.93 725804.63 141.98 465409.93 725804.63 148.92000000000002 465410.35 725805.16 148.92000000000002 465410.35 725805.16 141.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ed37e973-2ff5-4d4e-9142-b41d1acc9530_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465409.93 725804.63 148.92000000000002 465410.29 725804.35 148.92000000000002 465408.75 725802.35 148.92000000000002 465411.49 725800.25 148.92000000000002 465411.12 725799.77 148.92000000000002 465413.7 725797.8 148.92000000000002 465414.07 725798.27 148.92000000000002 465416.76 725796.21 148.92000000000002 465418.44 725798.38 148.92000000000002 465418.79 725798.11 148.92000000000002 465419.2 725798.63 148.92000000000002 465418.85 725798.91 148.92000000000002 465419.91 725800.28 148.92000000000002 465420.27 725800 148.92000000000002 465420.68 725800.52 148.92000000000002 465420.32 725800.8 148.92000000000002 465422.01 725802.97 148.92000000000002 465421.6 725803.29 148.92000000000002 465425.39 725808.31 148.92000000000002 465418.24 725813.82 148.92000000000002 465414.38 725808.82 148.92000000000002 465413.98 725809.13 148.92000000000002 465412.45 725807.14 148.92000000000002 465412.09 725807.42 148.92000000000002 465411.67 725806.88 148.92000000000002 465412.03 725806.61 148.92000000000002 465410.7 725804.89 148.92000000000002 465410.35 725805.16 148.92000000000002 465409.93 725804.63 148.92000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142">
			<gen:stringAttribute name="buildingId">
				<gen:value>0caebc79-8cbe-4317-a507-16e565b5f142</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.72</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465279.18 725677.51 141.3 465282.21 725685.85 141.3 465287.71 725683.86 141.3 465289.78 725689.52 141.3 465296.74 725687.02 141.3 465291.64 725672.9 141.3 465288.23 725674.14 141.3 465287.49 725671.96 141.3 465281.72 725674.05 141.3 465282.51 725676.3 141.3 465279.18 725677.51 141.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465279.18 725677.51 141.3 465282.51 725676.3 141.3 465282.51 725676.3 148.02 465279.18 725677.51 148.02 465279.18 725677.51 141.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465282.51 725676.3 141.3 465281.72 725674.05 141.3 465281.72 725674.05 148.02 465282.51 725676.3 148.02 465282.51 725676.3 141.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465281.72 725674.05 141.3 465287.49 725671.96 141.3 465287.49 725671.96 148.02 465281.72 725674.05 148.02 465281.72 725674.05 141.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465287.49 725671.96 141.3 465288.23 725674.14 141.3 465288.23 725674.14 148.02 465287.49 725671.96 148.02 465287.49 725671.96 141.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465288.23 725674.14 141.3 465291.64 725672.9 141.3 465291.64 725672.9 148.02 465288.23 725674.14 148.02 465288.23 725674.14 141.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465291.64 725672.9 141.3 465296.74 725687.02 141.3 465296.74 725687.02 148.02 465291.64 725672.9 148.02 465291.64 725672.9 141.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465296.74 725687.02 141.3 465289.78 725689.52 141.3 465289.78 725689.52 148.02 465296.74 725687.02 148.02 465296.74 725687.02 141.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465289.78 725689.52 141.3 465287.71 725683.86 141.3 465287.71 725683.86 148.02 465289.78 725689.52 148.02 465289.78 725689.52 141.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465287.71 725683.86 141.3 465282.21 725685.85 141.3 465282.21 725685.85 148.02 465287.71 725683.86 148.02 465287.71 725683.86 141.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465282.21 725685.85 141.3 465279.18 725677.51 141.3 465279.18 725677.51 148.02 465282.21 725685.85 148.02 465282.21 725685.85 141.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0caebc79-8cbe-4317-a507-16e565b5f142_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465279.18 725677.51 148.02 465282.51 725676.3 148.02 465281.72 725674.05 148.02 465287.49 725671.96 148.02 465288.23 725674.14 148.02 465291.64 725672.9 148.02 465296.74 725687.02 148.02 465289.78 725689.52 148.02 465287.71 725683.86 148.02 465282.21 725685.85 148.02 465279.18 725677.51 148.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.07</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465308.13 725679.75 141.13 465311.99 725678.3 141.13 465310.91 725675.57 141.13 465324.19 725670.62 141.13 465325.25 725673.34 141.13 465329.07 725671.91 141.13 465326.24 725664.41 141.13 465322.98 725665.75 141.13 465322.08 725663.25 141.13 465307.73 725668.49 141.13 465308.64 725670.98 141.13 465305.33 725672.22 141.13 465308.13 725679.75 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465308.13 725679.75 141.13 465305.33 725672.22 141.13 465305.33 725672.22 148.20000000000002 465308.13 725679.75 148.20000000000002 465308.13 725679.75 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465305.33 725672.22 141.13 465308.64 725670.98 141.13 465308.64 725670.98 148.20000000000002 465305.33 725672.22 148.20000000000002 465305.33 725672.22 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465308.64 725670.98 141.13 465307.73 725668.49 141.13 465307.73 725668.49 148.20000000000002 465308.64 725670.98 148.20000000000002 465308.64 725670.98 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465307.73 725668.49 141.13 465322.08 725663.25 141.13 465322.08 725663.25 148.20000000000002 465307.73 725668.49 148.20000000000002 465307.73 725668.49 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465322.08 725663.25 141.13 465322.98 725665.75 141.13 465322.98 725665.75 148.20000000000002 465322.08 725663.25 148.20000000000002 465322.08 725663.25 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465322.98 725665.75 141.13 465326.24 725664.41 141.13 465326.24 725664.41 148.20000000000002 465322.98 725665.75 148.20000000000002 465322.98 725665.75 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465326.24 725664.41 141.13 465329.07 725671.91 141.13 465329.07 725671.91 148.20000000000002 465326.24 725664.41 148.20000000000002 465326.24 725664.41 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465329.07 725671.91 141.13 465325.25 725673.34 141.13 465325.25 725673.34 148.20000000000002 465329.07 725671.91 148.20000000000002 465329.07 725671.91 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465325.25 725673.34 141.13 465324.19 725670.62 141.13 465324.19 725670.62 148.20000000000002 465325.25 725673.34 148.20000000000002 465325.25 725673.34 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465324.19 725670.62 141.13 465310.91 725675.57 141.13 465310.91 725675.57 148.20000000000002 465324.19 725670.62 148.20000000000002 465324.19 725670.62 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465310.91 725675.57 141.13 465311.99 725678.3 141.13 465311.99 725678.3 148.20000000000002 465310.91 725675.57 148.20000000000002 465310.91 725675.57 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465311.99 725678.3 141.13 465308.13 725679.75 141.13 465308.13 725679.75 148.20000000000002 465311.99 725678.3 148.20000000000002 465311.99 725678.3 141.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C1D-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465308.13 725679.75 148.20000000000002 465305.33 725672.22 148.20000000000002 465308.64 725670.98 148.20000000000002 465307.73 725668.49 148.20000000000002 465322.08 725663.25 148.20000000000002 465322.98 725665.75 148.20000000000002 465326.24 725664.41 148.20000000000002 465329.07 725671.91 148.20000000000002 465325.25 725673.34 148.20000000000002 465324.19 725670.62 148.20000000000002 465310.91 725675.57 148.20000000000002 465311.99 725678.3 148.20000000000002 465308.13 725679.75 148.20000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.02</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464469.58 724693.79 137.42 464469.5 724693.85 137.42 464461.47 724699.93 137.42 464478.2 724726.1 137.42 464486.72 724720.78 137.42 464490.81 724718.22 137.42 464487.98 724713.71 137.42 464483.77 724716.35 137.42 464471.88 724697.45 137.42 464469.58 724693.79 137.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464469.58 724693.79 137.42 464471.88 724697.45 137.42 464471.88 724697.45 144.44 464469.58 724693.79 144.44 464469.58 724693.79 137.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464471.88 724697.45 137.42 464483.77 724716.35 137.42 464483.77 724716.35 144.44 464471.88 724697.45 144.44 464471.88 724697.45 137.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464483.77 724716.35 137.42 464487.98 724713.71 137.42 464487.98 724713.71 144.44 464483.77 724716.35 144.44 464483.77 724716.35 137.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464487.98 724713.71 137.42 464490.81 724718.22 137.42 464490.81 724718.22 144.44 464487.98 724713.71 144.44 464487.98 724713.71 137.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464490.81 724718.22 137.42 464486.72 724720.78 137.42 464486.72 724720.78 144.44 464490.81 724718.22 144.44 464490.81 724718.22 137.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464486.72 724720.78 137.42 464478.2 724726.1 137.42 464478.2 724726.1 144.44 464486.72 724720.78 144.44 464486.72 724720.78 137.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464478.2 724726.1 137.42 464461.47 724699.93 137.42 464461.47 724699.93 144.44 464478.2 724726.1 144.44 464478.2 724726.1 137.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464461.47 724699.93 137.42 464469.5 724693.85 137.42 464469.5 724693.85 144.44 464461.47 724699.93 144.44 464461.47 724699.93 137.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464469.5 724693.85 137.42 464469.58 724693.79 137.42 464469.58 724693.79 144.44 464469.5 724693.85 144.44 464469.5 724693.85 137.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-75BD-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464469.58 724693.79 144.44 464471.88 724697.45 144.44 464483.77 724716.35 144.44 464487.98 724713.71 144.44 464490.81 724718.22 144.44 464486.72 724720.78 144.44 464478.2 724726.1 144.44 464461.47 724699.93 144.44 464469.5 724693.85 144.44 464469.58 724693.79 144.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C1FC-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C1FC-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.85</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1FC-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464210.95 724939.94 137.59 464225.18 724925.9 137.59 464219.49 724920.16 137.59 464205.28 724934.25 137.59 464210.95 724939.94 137.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1FC-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464210.95 724939.94 137.59 464205.28 724934.25 137.59 464205.28 724934.25 143.44 464210.95 724939.94 143.44 464210.95 724939.94 137.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1FC-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464205.28 724934.25 137.59 464219.49 724920.16 137.59 464219.49 724920.16 143.44 464205.28 724934.25 143.44 464205.28 724934.25 137.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1FC-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464219.49 724920.16 137.59 464225.18 724925.9 137.59 464225.18 724925.9 143.44 464219.49 724920.16 143.44 464219.49 724920.16 137.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1FC-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464225.18 724925.9 137.59 464210.95 724939.94 137.59 464210.95 724939.94 143.44 464225.18 724925.9 143.44 464225.18 724925.9 137.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1FC-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464210.95 724939.94 143.44 464205.28 724934.25 143.44 464219.49 724920.16 143.44 464225.18 724925.9 143.44 464210.95 724939.94 143.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.74 725781.17 142.43 465422.5 725786.07 142.43 465423.69 725785.15 142.43 465424.72 725786.51 142.43 465427.58 725784.32 142.43 465428.92 725786.05 142.43 465432.87 725782.99 142.43 465431.54 725781.24 142.43 465434.2 725779.22 142.43 465435.62 725780.94 142.43 465445.31 725773.51 142.43 465443.93 725771.7 142.43 465446.61 725769.66 142.43 465447.99 725771.47 142.43 465452.01 725768.4 142.43 465450.62 725766.59 142.43 465453.49 725764.4 142.43 465452.49 725763.1 142.43 465453.69 725762.18 142.43 465449.93 725757.26 142.43 465448.72 725758.17 142.43 465447.71 725756.84 142.43 465444.85 725759.02 142.43 465443.96 725757.84 142.43 465439.96 725760.92 142.43 465440.87 725762.11 142.43 465438.2 725764.15 142.43 465437.3 725762.95 142.43 465427.52 725770.41 142.43 465428.43 725771.59 142.43 465425.79 725773.62 142.43 465424.89 725772.41 142.43 465420.89 725775.49 142.43 465421.83 725776.7 142.43 465418.93 725778.91 142.43 465419.95 725780.25 142.43 465418.74 725781.17 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.74 725781.17 142.43 465419.95 725780.25 142.43 465419.95 725780.25 150.43 465418.74 725781.17 150.43 465418.74 725781.17 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465419.95 725780.25 142.43 465418.93 725778.91 142.43 465418.93 725778.91 150.43 465419.95 725780.25 150.43 465419.95 725780.25 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.93 725778.91 142.43 465421.83 725776.7 142.43 465421.83 725776.7 150.43 465418.93 725778.91 150.43 465418.93 725778.91 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465421.83 725776.7 142.43 465420.89 725775.49 142.43 465420.89 725775.49 150.43 465421.83 725776.7 150.43 465421.83 725776.7 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465420.89 725775.49 142.43 465424.89 725772.41 142.43 465424.89 725772.41 150.43 465420.89 725775.49 150.43 465420.89 725775.49 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465424.89 725772.41 142.43 465425.79 725773.62 142.43 465425.79 725773.62 150.43 465424.89 725772.41 150.43 465424.89 725772.41 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465425.79 725773.62 142.43 465428.43 725771.59 142.43 465428.43 725771.59 150.43 465425.79 725773.62 150.43 465425.79 725773.62 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465428.43 725771.59 142.43 465427.52 725770.41 142.43 465427.52 725770.41 150.43 465428.43 725771.59 150.43 465428.43 725771.59 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465427.52 725770.41 142.43 465437.3 725762.95 142.43 465437.3 725762.95 150.43 465427.52 725770.41 150.43 465427.52 725770.41 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465437.3 725762.95 142.43 465438.2 725764.15 142.43 465438.2 725764.15 150.43 465437.3 725762.95 150.43 465437.3 725762.95 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465438.2 725764.15 142.43 465440.87 725762.11 142.43 465440.87 725762.11 150.43 465438.2 725764.15 150.43 465438.2 725764.15 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465440.87 725762.11 142.43 465439.96 725760.92 142.43 465439.96 725760.92 150.43 465440.87 725762.11 150.43 465440.87 725762.11 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465439.96 725760.92 142.43 465443.96 725757.84 142.43 465443.96 725757.84 150.43 465439.96 725760.92 150.43 465439.96 725760.92 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465443.96 725757.84 142.43 465444.85 725759.02 142.43 465444.85 725759.02 150.43 465443.96 725757.84 150.43 465443.96 725757.84 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465444.85 725759.02 142.43 465447.71 725756.84 142.43 465447.71 725756.84 150.43 465444.85 725759.02 150.43 465444.85 725759.02 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465447.71 725756.84 142.43 465448.72 725758.17 142.43 465448.72 725758.17 150.43 465447.71 725756.84 150.43 465447.71 725756.84 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465448.72 725758.17 142.43 465449.93 725757.26 142.43 465449.93 725757.26 150.43 465448.72 725758.17 150.43 465448.72 725758.17 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465449.93 725757.26 142.43 465453.69 725762.18 142.43 465453.69 725762.18 150.43 465449.93 725757.26 150.43 465449.93 725757.26 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465453.69 725762.18 142.43 465452.49 725763.1 142.43 465452.49 725763.1 150.43 465453.69 725762.18 150.43 465453.69 725762.18 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465452.49 725763.1 142.43 465453.49 725764.4 142.43 465453.49 725764.4 150.43 465452.49 725763.1 150.43 465452.49 725763.1 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465453.49 725764.4 142.43 465450.62 725766.59 142.43 465450.62 725766.59 150.43 465453.49 725764.4 150.43 465453.49 725764.4 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465450.62 725766.59 142.43 465452.01 725768.4 142.43 465452.01 725768.4 150.43 465450.62 725766.59 150.43 465450.62 725766.59 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465452.01 725768.4 142.43 465447.99 725771.47 142.43 465447.99 725771.47 150.43 465452.01 725768.4 150.43 465452.01 725768.4 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465447.99 725771.47 142.43 465446.61 725769.66 142.43 465446.61 725769.66 150.43 465447.99 725771.47 150.43 465447.99 725771.47 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465446.61 725769.66 142.43 465443.93 725771.7 142.43 465443.93 725771.7 150.43 465446.61 725769.66 150.43 465446.61 725769.66 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465443.93 725771.7 142.43 465445.31 725773.51 142.43 465445.31 725773.51 150.43 465443.93 725771.7 150.43 465443.93 725771.7 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465445.31 725773.51 142.43 465435.62 725780.94 142.43 465435.62 725780.94 150.43 465445.31 725773.51 150.43 465445.31 725773.51 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465435.62 725780.94 142.43 465434.2 725779.22 142.43 465434.2 725779.22 150.43 465435.62 725780.94 150.43 465435.62 725780.94 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465434.2 725779.22 142.43 465431.54 725781.24 142.43 465431.54 725781.24 150.43 465434.2 725779.22 150.43 465434.2 725779.22 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465431.54 725781.24 142.43 465432.87 725782.99 142.43 465432.87 725782.99 150.43 465431.54 725781.24 150.43 465431.54 725781.24 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465432.87 725782.99 142.43 465428.92 725786.05 142.43 465428.92 725786.05 150.43 465432.87 725782.99 150.43 465432.87 725782.99 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465428.92 725786.05 142.43 465427.58 725784.32 142.43 465427.58 725784.32 150.43 465428.92 725786.05 150.43 465428.92 725786.05 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465427.58 725784.32 142.43 465424.72 725786.51 142.43 465424.72 725786.51 150.43 465427.58 725784.32 150.43 465427.58 725784.32 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465424.72 725786.51 142.43 465423.69 725785.15 142.43 465423.69 725785.15 150.43 465424.72 725786.51 150.43 465424.72 725786.51 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465423.69 725785.15 142.43 465422.5 725786.07 142.43 465422.5 725786.07 150.43 465423.69 725785.15 150.43 465423.69 725785.15 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465422.5 725786.07 142.43 465418.74 725781.17 142.43 465418.74 725781.17 150.43 465422.5 725786.07 150.43 465422.5 725786.07 142.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B90-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465418.74 725781.17 150.43 465419.95 725780.25 150.43 465418.93 725778.91 150.43 465421.83 725776.7 150.43 465420.89 725775.49 150.43 465424.89 725772.41 150.43 465425.79 725773.62 150.43 465428.43 725771.59 150.43 465427.52 725770.41 150.43 465437.3 725762.95 150.43 465438.2 725764.15 150.43 465440.87 725762.11 150.43 465439.96 725760.92 150.43 465443.96 725757.84 150.43 465444.85 725759.02 150.43 465447.71 725756.84 150.43 465448.72 725758.17 150.43 465449.93 725757.26 150.43 465453.69 725762.18 150.43 465452.49 725763.1 150.43 465453.49 725764.4 150.43 465450.62 725766.59 150.43 465452.01 725768.4 150.43 465447.99 725771.47 150.43 465446.61 725769.66 150.43 465443.93 725771.7 150.43 465445.31 725773.51 150.43 465435.62 725780.94 150.43 465434.2 725779.22 150.43 465431.54 725781.24 150.43 465432.87 725782.99 150.43 465428.92 725786.05 150.43 465427.58 725784.32 150.43 465424.72 725786.51 150.43 465423.69 725785.15 150.43 465422.5 725786.07 150.43 465418.74 725781.17 150.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C648-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.46</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465001.13 724434.69 137.6 465010.05 724430.91 137.6 465008.96 724428.36 137.6 465011.98 724427.05 137.6 465005.98 724413.24 137.6 465007.53 724412.55 137.6 464999.66 724394.42 137.6 464996.91 724395.61 137.6 464995.36 724392.05 137.6 464987.96 724395.24 137.6 464991.44 724403.11 137.6 464986.69 724405.17 137.6 464991.84 724417.12 137.6 464993.24 724416.5 137.6 465001.13 724434.69 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465001.13 724434.69 137.6 464993.24 724416.5 137.6 464993.24 724416.5 143.06 465001.13 724434.69 143.06 465001.13 724434.69 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464993.24 724416.5 137.6 464991.84 724417.12 137.6 464991.84 724417.12 143.06 464993.24 724416.5 143.06 464993.24 724416.5 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464991.84 724417.12 137.6 464986.69 724405.17 137.6 464986.69 724405.17 143.06 464991.84 724417.12 143.06 464991.84 724417.12 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464986.69 724405.17 137.6 464991.44 724403.11 137.6 464991.44 724403.11 143.06 464986.69 724405.17 143.06 464986.69 724405.17 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464991.44 724403.11 137.6 464987.96 724395.24 137.6 464987.96 724395.24 143.06 464991.44 724403.11 143.06 464991.44 724403.11 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464987.96 724395.24 137.6 464995.36 724392.05 137.6 464995.36 724392.05 143.06 464987.96 724395.24 143.06 464987.96 724395.24 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464995.36 724392.05 137.6 464996.91 724395.61 137.6 464996.91 724395.61 143.06 464995.36 724392.05 143.06 464995.36 724392.05 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464996.91 724395.61 137.6 464999.66 724394.42 137.6 464999.66 724394.42 143.06 464996.91 724395.61 143.06 464996.91 724395.61 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464999.66 724394.42 137.6 465007.53 724412.55 137.6 465007.53 724412.55 143.06 464999.66 724394.42 143.06 464999.66 724394.42 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465007.53 724412.55 137.6 465005.98 724413.24 137.6 465005.98 724413.24 143.06 465007.53 724412.55 143.06 465007.53 724412.55 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465005.98 724413.24 137.6 465011.98 724427.05 137.6 465011.98 724427.05 143.06 465005.98 724413.24 143.06 465005.98 724413.24 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465011.98 724427.05 137.6 465008.96 724428.36 137.6 465008.96 724428.36 143.06 465011.98 724427.05 143.06 465011.98 724427.05 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465008.96 724428.36 137.6 465010.05 724430.91 137.6 465010.05 724430.91 143.06 465008.96 724428.36 143.06 465008.96 724428.36 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465010.05 724430.91 137.6 465001.13 724434.69 137.6 465001.13 724434.69 143.06 465010.05 724430.91 143.06 465010.05 724430.91 137.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C648-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465001.13 724434.69 143.06 464993.24 724416.5 143.06 464991.84 724417.12 143.06 464986.69 724405.17 143.06 464991.44 724403.11 143.06 464987.96 724395.24 143.06 464995.36 724392.05 143.06 464996.91 724395.61 143.06 464999.66 724394.42 143.06 465007.53 724412.55 143.06 465005.98 724413.24 143.06 465011.98 724427.05 143.06 465008.96 724428.36 143.06 465010.05 724430.91 143.06 465001.13 724434.69 143.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-BE15-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-BE15-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.85</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BE15-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465394.48 725769.12 142.45 465400.4 725764.59 142.45 465396.6 725759.63 142.45 465390.68 725764.15 142.45 465394.48 725769.12 142.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BE15-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465394.48 725769.12 142.45 465390.68 725764.15 142.45 465390.68 725764.15 148.3 465394.48 725769.12 148.3 465394.48 725769.12 142.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BE15-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465390.68 725764.15 142.45 465396.6 725759.63 142.45 465396.6 725759.63 148.3 465390.68 725764.15 148.3 465390.68 725764.15 142.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BE15-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465396.6 725759.63 142.45 465400.4 725764.59 142.45 465400.4 725764.59 148.3 465396.6 725759.63 148.3 465396.6 725759.63 142.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BE15-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465400.4 725764.59 142.45 465394.48 725769.12 142.45 465394.48 725769.12 148.3 465400.4 725764.59 148.3 465400.4 725764.59 142.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-BE15-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465394.48 725769.12 148.3 465390.68 725764.15 148.3 465396.6 725759.63 148.3 465400.4 725764.59 148.3 465394.48 725769.12 148.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-64656b2d-e33a-4fd8-8e57-20c348f1e6d9">
			<gen:stringAttribute name="buildingId">
				<gen:value>64656b2d-e33a-4fd8-8e57-20c348f1e6d9</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.9</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64656b2d-e33a-4fd8-8e57-20c348f1e6d9_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465259.51 725821.24 139.71 465267.54 725831.48 139.71 465276.41 725824.53 139.71 465279.08 725827.94 139.71 465284.63 725823.59 139.71 465273.93 725809.94 139.71 465259.51 725821.24 139.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64656b2d-e33a-4fd8-8e57-20c348f1e6d9_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465259.51 725821.24 139.71 465273.93 725809.94 139.71 465273.93 725809.94 144.61 465259.51 725821.24 144.61 465259.51 725821.24 139.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64656b2d-e33a-4fd8-8e57-20c348f1e6d9_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465273.93 725809.94 139.71 465284.63 725823.59 139.71 465284.63 725823.59 144.61 465273.93 725809.94 144.61 465273.93 725809.94 139.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64656b2d-e33a-4fd8-8e57-20c348f1e6d9_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465284.63 725823.59 139.71 465279.08 725827.94 139.71 465279.08 725827.94 144.61 465284.63 725823.59 144.61 465284.63 725823.59 139.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64656b2d-e33a-4fd8-8e57-20c348f1e6d9_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465279.08 725827.94 139.71 465276.41 725824.53 139.71 465276.41 725824.53 144.61 465279.08 725827.94 144.61 465279.08 725827.94 139.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64656b2d-e33a-4fd8-8e57-20c348f1e6d9_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465276.41 725824.53 139.71 465267.54 725831.48 139.71 465267.54 725831.48 144.61 465276.41 725824.53 144.61 465276.41 725824.53 139.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64656b2d-e33a-4fd8-8e57-20c348f1e6d9_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465267.54 725831.48 139.71 465259.51 725821.24 139.71 465259.51 725821.24 144.61 465267.54 725831.48 144.61 465267.54 725831.48 139.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-64656b2d-e33a-4fd8-8e57-20c348f1e6d9_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465259.51 725821.24 144.61 465273.93 725809.94 144.61 465284.63 725823.59 144.61 465279.08 725827.94 144.61 465276.41 725824.53 144.61 465267.54 725831.48 144.61 465259.51 725821.24 144.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-311ccff5-1ca2-46d0-b1c7-f4b3aa3d3327">
			<gen:stringAttribute name="buildingId">
				<gen:value>311ccff5-1ca2-46d0-b1c7-f4b3aa3d3327</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.59</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-311ccff5-1ca2-46d0-b1c7-f4b3aa3d3327_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465268.16 725847.78 138.76 465273.66 725854.61 138.76 465283.98 725846.31 138.76 465278.47 725839.47 138.76 465268.16 725847.78 138.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-311ccff5-1ca2-46d0-b1c7-f4b3aa3d3327_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465268.16 725847.78 138.76 465278.47 725839.47 138.76 465278.47 725839.47 143.35 465268.16 725847.78 143.35 465268.16 725847.78 138.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-311ccff5-1ca2-46d0-b1c7-f4b3aa3d3327_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465278.47 725839.47 138.76 465283.98 725846.31 138.76 465283.98 725846.31 143.35 465278.47 725839.47 143.35 465278.47 725839.47 138.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-311ccff5-1ca2-46d0-b1c7-f4b3aa3d3327_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465283.98 725846.31 138.76 465273.66 725854.61 138.76 465273.66 725854.61 143.35 465283.98 725846.31 143.35 465283.98 725846.31 138.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-311ccff5-1ca2-46d0-b1c7-f4b3aa3d3327_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465273.66 725854.61 138.76 465268.16 725847.78 138.76 465268.16 725847.78 143.35 465273.66 725854.61 143.35 465273.66 725854.61 138.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-311ccff5-1ca2-46d0-b1c7-f4b3aa3d3327_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465268.16 725847.78 143.35 465278.47 725839.47 143.35 465283.98 725846.31 143.35 465273.66 725854.61 143.35 465268.16 725847.78 143.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-749be72c-4a70-408c-b1ea-f51ce564ff87">
			<gen:stringAttribute name="buildingId">
				<gen:value>749be72c-4a70-408c-b1ea-f51ce564ff87</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">25.52</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-749be72c-4a70-408c-b1ea-f51ce564ff87_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465291.64 724475.87 138.48 465241.62 724500.22 138.48 465272.06 724556.33 138.48 465319.93 724532.46 138.48 465312.65 724511.57 138.48 465291.64 724475.87 138.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-749be72c-4a70-408c-b1ea-f51ce564ff87_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465291.64 724475.87 138.48 465312.65 724511.57 138.48 465312.65 724511.57 164 465291.64 724475.87 164 465291.64 724475.87 138.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-749be72c-4a70-408c-b1ea-f51ce564ff87_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465312.65 724511.57 138.48 465319.93 724532.46 138.48 465319.93 724532.46 164 465312.65 724511.57 164 465312.65 724511.57 138.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-749be72c-4a70-408c-b1ea-f51ce564ff87_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465319.93 724532.46 138.48 465272.06 724556.33 138.48 465272.06 724556.33 164 465319.93 724532.46 164 465319.93 724532.46 138.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-749be72c-4a70-408c-b1ea-f51ce564ff87_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465272.06 724556.33 138.48 465241.62 724500.22 138.48 465241.62 724500.22 164 465272.06 724556.33 164 465272.06 724556.33 138.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-749be72c-4a70-408c-b1ea-f51ce564ff87_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465241.62 724500.22 138.48 465291.64 724475.87 138.48 465291.64 724475.87 164 465241.62 724500.22 164 465241.62 724500.22 138.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-749be72c-4a70-408c-b1ea-f51ce564ff87_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465291.64 724475.87 164 465312.65 724511.57 164 465319.93 724532.46 164 465272.06 724556.33 164 465241.62 724500.22 164 465291.64 724475.87 164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27">
			<gen:stringAttribute name="buildingId">
				<gen:value>511d9273-9a8e-4719-8b80-52ecf0282a27</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.52</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465449.4 724562.23 138.42 465453.59 724568.45 138.42 465454.09 724568.14 138.42 465453.76 724567.61 138.42 465470.57 724556.31 138.42 465473.71 724554.2 138.42 465474.99 724553.32 138.42 465474.78 724553.03 138.42 465474.43 724552.95 138.42 465467.42 724551.4 138.42 465465.96 724551.03 138.42 465449.4 724562.23 138.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465449.4 724562.23 138.42 465465.96 724551.03 138.42 465465.96 724551.03 142.94 465449.4 724562.23 142.94 465449.4 724562.23 138.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465465.96 724551.03 138.42 465467.42 724551.4 138.42 465467.42 724551.4 142.94 465465.96 724551.03 142.94 465465.96 724551.03 138.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465467.42 724551.4 138.42 465474.43 724552.95 138.42 465474.43 724552.95 142.94 465467.42 724551.4 142.94 465467.42 724551.4 138.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465474.43 724552.95 138.42 465474.78 724553.03 138.42 465474.78 724553.03 142.94 465474.43 724552.95 142.94 465474.43 724552.95 138.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465474.78 724553.03 138.42 465474.99 724553.32 138.42 465474.99 724553.32 142.94 465474.78 724553.03 142.94 465474.78 724553.03 138.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465474.99 724553.32 138.42 465473.71 724554.2 138.42 465473.71 724554.2 142.94 465474.99 724553.32 142.94 465474.99 724553.32 138.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465473.71 724554.2 138.42 465470.57 724556.31 138.42 465470.57 724556.31 142.94 465473.71 724554.2 142.94 465473.71 724554.2 138.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465470.57 724556.31 138.42 465453.76 724567.61 138.42 465453.76 724567.61 142.94 465470.57 724556.31 142.94 465470.57 724556.31 138.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465453.76 724567.61 138.42 465454.09 724568.14 138.42 465454.09 724568.14 142.94 465453.76 724567.61 142.94 465453.76 724567.61 138.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465454.09 724568.14 138.42 465453.59 724568.45 138.42 465453.59 724568.45 142.94 465454.09 724568.14 142.94 465454.09 724568.14 138.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465453.59 724568.45 138.42 465449.4 724562.23 138.42 465449.4 724562.23 142.94 465453.59 724568.45 142.94 465453.59 724568.45 138.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-511d9273-9a8e-4719-8b80-52ecf0282a27_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>465449.4 724562.23 142.94 465465.96 724551.03 142.94 465467.42 724551.4 142.94 465474.43 724552.95 142.94 465474.78 724553.03 142.94 465474.99 724553.32 142.94 465473.71 724554.2 142.94 465470.57 724556.31 142.94 465453.76 724567.61 142.94 465454.09 724568.14 142.94 465453.59 724568.45 142.94 465449.4 724562.23 142.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C1FD-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C1FD-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.36</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1FD-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464219.31 724968.66 138.03 464227.44 724962.76 138.03 464219.2 724951.41 138.03 464211.06 724957.28 138.03 464219.31 724968.66 138.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1FD-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464219.31 724968.66 138.03 464211.06 724957.28 138.03 464211.06 724957.28 143.39000000000001 464219.31 724968.66 143.39000000000001 464219.31 724968.66 138.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1FD-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464211.06 724957.28 138.03 464219.2 724951.41 138.03 464219.2 724951.41 143.39000000000001 464211.06 724957.28 143.39000000000001 464211.06 724957.28 138.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1FD-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464219.2 724951.41 138.03 464227.44 724962.76 138.03 464227.44 724962.76 143.39000000000001 464219.2 724951.41 143.39000000000001 464219.2 724951.41 138.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1FD-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464227.44 724962.76 138.03 464219.31 724968.66 138.03 464219.31 724968.66 143.39000000000001 464227.44 724962.76 143.39000000000001 464227.44 724962.76 138.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C1FD-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464219.31 724968.66 143.39000000000001 464211.06 724957.28 143.39000000000001 464219.2 724951.41 143.39000000000001 464227.44 724962.76 143.39000000000001 464219.31 724968.66 143.39000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6C75-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6C75-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.31</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C75-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464086.08 723649.65 131.58 464113.04 723629.98 131.58 464106.24 723620.66 131.58 464079.28 723640.32 131.58 464086.08 723649.65 131.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C75-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464086.08 723649.65 131.58 464079.28 723640.32 131.58 464079.28 723640.32 136.89000000000001 464086.08 723649.65 136.89000000000001 464086.08 723649.65 131.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C75-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464079.28 723640.32 131.58 464106.24 723620.66 131.58 464106.24 723620.66 136.89000000000001 464079.28 723640.32 136.89000000000001 464079.28 723640.32 131.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C75-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464106.24 723620.66 131.58 464113.04 723629.98 131.58 464113.04 723629.98 136.89000000000001 464106.24 723620.66 136.89000000000001 464106.24 723620.66 131.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C75-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464113.04 723629.98 131.58 464086.08 723649.65 131.58 464086.08 723649.65 136.89000000000001 464113.04 723629.98 136.89000000000001 464113.04 723629.98 131.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6C75-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>464086.08 723649.65 136.89000000000001 464079.28 723640.32 136.89000000000001 464106.24 723620.66 136.89000000000001 464113.04 723629.98 136.89000000000001 464086.08 723649.65 136.89000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
</CityModel>
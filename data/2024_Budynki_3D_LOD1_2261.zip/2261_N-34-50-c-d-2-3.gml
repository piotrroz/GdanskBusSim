<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0" xmlns="http://www.opengis.net/citygml/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
			<gml:lowerCorner>479796.71 723461.87 1.3</gml:lowerCorner>
			<gml:upperCorner>481666.18 725834.05 28.580000000000002</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-01ba76de-945f-4a7b-9f28-3a82fb7479ec">
			<gen:stringAttribute name="buildingId">
				<gen:value>01ba76de-945f-4a7b-9f28-3a82fb7479ec</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">13.39</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01ba76de-945f-4a7b-9f28-3a82fb7479ec_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480847.29 723599.14 2.12 480748.71 723461.87 2.12 480630.91 723546.46 2.12 480729.45 723683.84 2.12 480847.29 723599.14 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01ba76de-945f-4a7b-9f28-3a82fb7479ec_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480847.29 723599.14 2.12 480729.45 723683.84 2.12 480729.45 723683.84 15.510000000000002 480847.29 723599.14 15.510000000000002 480847.29 723599.14 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01ba76de-945f-4a7b-9f28-3a82fb7479ec_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480729.45 723683.84 2.12 480630.91 723546.46 2.12 480630.91 723546.46 15.510000000000002 480729.45 723683.84 15.510000000000002 480729.45 723683.84 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01ba76de-945f-4a7b-9f28-3a82fb7479ec_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480630.91 723546.46 2.12 480748.71 723461.87 2.12 480748.71 723461.87 15.510000000000002 480630.91 723546.46 15.510000000000002 480630.91 723546.46 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01ba76de-945f-4a7b-9f28-3a82fb7479ec_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480748.71 723461.87 2.12 480847.29 723599.14 2.12 480847.29 723599.14 15.510000000000002 480748.71 723461.87 15.510000000000002 480748.71 723461.87 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01ba76de-945f-4a7b-9f28-3a82fb7479ec_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480847.29 723599.14 15.510000000000002 480729.45 723683.84 15.510000000000002 480630.91 723546.46 15.510000000000002 480748.71 723461.87 15.510000000000002 480847.29 723599.14 15.510000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4A67-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4A67-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.17</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4A67-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479838.22 725833.69 4.06 479845.03 725834.05 4.06 479853.87 725683.63 4.06 479847.06 725683.27 4.06 479838.22 725833.69 4.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4A67-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479838.22 725833.69 4.06 479847.06 725683.27 4.06 479847.06 725683.27 13.23 479838.22 725833.69 13.23 479838.22 725833.69 4.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4A67-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479847.06 725683.27 4.06 479853.87 725683.63 4.06 479853.87 725683.63 13.23 479847.06 725683.27 13.23 479847.06 725683.27 4.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4A67-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479853.87 725683.63 4.06 479845.03 725834.05 4.06 479845.03 725834.05 13.23 479853.87 725683.63 13.23 479853.87 725683.63 4.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4A67-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479845.03 725834.05 4.06 479838.22 725833.69 4.06 479838.22 725833.69 13.23 479845.03 725834.05 13.23 479845.03 725834.05 4.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4A67-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479838.22 725833.69 13.23 479847.06 725683.27 13.23 479853.87 725683.63 13.23 479845.03 725834.05 13.23 479838.22 725833.69 13.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.64</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.29 725537.87 2.42 479967.57 725537.56 2.42 479967.56 725537.07 2.42 479967.28 725537.07 2.42 479966.93 725510.37 2.42 479991.13 725509.82 2.42 479991.13 725510.25 2.42 479991.63 725510.25 2.42 479991.53 725494.09 2.42 479990.89 725494.11 2.42 479990.89 725494.49 2.42 479951.8 725495.25 2.42 479951.8 725494.9 2.42 479951.09 725494.89 2.42 479951.05 725501.66 2.42 479951.4 725501.66 2.42 479951.68 725537.37 2.42 479951.28 725537.38 2.42 479951.29 725537.87 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.29 725537.87 2.42 479951.28 725537.38 2.42 479951.28 725537.38 11.06 479951.29 725537.87 11.06 479951.29 725537.87 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.28 725537.38 2.42 479951.68 725537.37 2.42 479951.68 725537.37 11.06 479951.28 725537.38 11.06 479951.28 725537.38 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.68 725537.37 2.42 479951.4 725501.66 2.42 479951.4 725501.66 11.06 479951.68 725537.37 11.06 479951.68 725537.37 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.4 725501.66 2.42 479951.05 725501.66 2.42 479951.05 725501.66 11.06 479951.4 725501.66 11.06 479951.4 725501.66 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.05 725501.66 2.42 479951.09 725494.89 2.42 479951.09 725494.89 11.06 479951.05 725501.66 11.06 479951.05 725501.66 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.09 725494.89 2.42 479951.8 725494.9 2.42 479951.8 725494.9 11.06 479951.09 725494.89 11.06 479951.09 725494.89 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.8 725494.9 2.42 479951.8 725495.25 2.42 479951.8 725495.25 11.06 479951.8 725494.9 11.06 479951.8 725494.9 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.8 725495.25 2.42 479990.89 725494.49 2.42 479990.89 725494.49 11.06 479951.8 725495.25 11.06 479951.8 725495.25 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479990.89 725494.49 2.42 479990.89 725494.11 2.42 479990.89 725494.11 11.06 479990.89 725494.49 11.06 479990.89 725494.49 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479990.89 725494.11 2.42 479991.53 725494.09 2.42 479991.53 725494.09 11.06 479990.89 725494.11 11.06 479990.89 725494.11 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479991.53 725494.09 2.42 479991.63 725510.25 2.42 479991.63 725510.25 11.06 479991.53 725494.09 11.06 479991.53 725494.09 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479991.63 725510.25 2.42 479991.13 725510.25 2.42 479991.13 725510.25 11.06 479991.63 725510.25 11.06 479991.63 725510.25 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479991.13 725510.25 2.42 479991.13 725509.82 2.42 479991.13 725509.82 11.06 479991.13 725510.25 11.06 479991.13 725510.25 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479991.13 725509.82 2.42 479966.93 725510.37 2.42 479966.93 725510.37 11.06 479991.13 725509.82 11.06 479991.13 725509.82 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479966.93 725510.37 2.42 479967.28 725537.07 2.42 479967.28 725537.07 11.06 479966.93 725510.37 11.06 479966.93 725510.37 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479967.28 725537.07 2.42 479967.56 725537.07 2.42 479967.56 725537.07 11.06 479967.28 725537.07 11.06 479967.28 725537.07 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479967.56 725537.07 2.42 479967.57 725537.56 2.42 479967.57 725537.56 11.06 479967.56 725537.07 11.06 479967.56 725537.07 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479967.57 725537.56 2.42 479951.29 725537.87 2.42 479951.29 725537.87 11.06 479967.57 725537.56 11.06 479967.57 725537.56 2.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4B7-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.29 725537.87 11.06 479951.28 725537.38 11.06 479951.68 725537.37 11.06 479951.4 725501.66 11.06 479951.05 725501.66 11.06 479951.09 725494.89 11.06 479951.8 725494.9 11.06 479951.8 725495.25 11.06 479990.89 725494.49 11.06 479990.89 725494.11 11.06 479991.53 725494.09 11.06 479991.63 725510.25 11.06 479991.13 725510.25 11.06 479991.13 725509.82 11.06 479966.93 725510.37 11.06 479967.28 725537.07 11.06 479967.56 725537.07 11.06 479967.57 725537.56 11.06 479951.29 725537.87 11.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CA9B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CA9B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.62</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA9B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480054.95 725027.33 2.97 480040.08 725035.29 2.97 480044.06 725042.86 2.97 480058.86 725034.65 2.97 480054.95 725027.33 2.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA9B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480054.95 725027.33 2.97 480058.86 725034.65 2.97 480058.86 725034.65 8.59 480054.95 725027.33 8.59 480054.95 725027.33 2.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA9B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480058.86 725034.65 2.97 480044.06 725042.86 2.97 480044.06 725042.86 8.59 480058.86 725034.65 8.59 480058.86 725034.65 2.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA9B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480044.06 725042.86 2.97 480040.08 725035.29 2.97 480040.08 725035.29 8.59 480044.06 725042.86 8.59 480044.06 725042.86 2.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA9B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480040.08 725035.29 2.97 480054.95 725027.33 2.97 480054.95 725027.33 8.59 480040.08 725035.29 8.59 480040.08 725035.29 2.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA9B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480054.95 725027.33 8.59 480058.86 725034.65 8.59 480044.06 725042.86 8.59 480040.08 725035.29 8.59 480054.95 725027.33 8.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E087-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480049.3 725215.88 2.87 480049.42 725224.49 2.87 480049.78 725224.47 2.87 480049.81 725224.32 2.87 480055.39 725224.26 2.87 480055.4 725224.39 2.87 480055.79 725224.38 2.87 480055.68 725215.75 2.87 480055.3 725215.75 2.87 480055.32 725215.85 2.87 480049.64 725216.07 2.87 480049.65 725215.89 2.87 480049.3 725215.88 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480049.3 725215.88 2.87 480049.65 725215.89 2.87 480049.65 725215.89 7.4 480049.3 725215.88 7.4 480049.3 725215.88 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480049.65 725215.89 2.87 480049.64 725216.07 2.87 480049.64 725216.07 7.4 480049.65 725215.89 7.4 480049.65 725215.89 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480049.64 725216.07 2.87 480055.32 725215.85 2.87 480055.32 725215.85 7.4 480049.64 725216.07 7.4 480049.64 725216.07 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480055.32 725215.85 2.87 480055.3 725215.75 2.87 480055.3 725215.75 7.4 480055.32 725215.85 7.4 480055.32 725215.85 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480055.3 725215.75 2.87 480055.68 725215.75 2.87 480055.68 725215.75 7.4 480055.3 725215.75 7.4 480055.3 725215.75 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480055.68 725215.75 2.87 480055.79 725224.38 2.87 480055.79 725224.38 7.4 480055.68 725215.75 7.4 480055.68 725215.75 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480055.79 725224.38 2.87 480055.4 725224.39 2.87 480055.4 725224.39 7.4 480055.79 725224.38 7.4 480055.79 725224.38 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480055.4 725224.39 2.87 480055.39 725224.26 2.87 480055.39 725224.26 7.4 480055.4 725224.39 7.4 480055.4 725224.39 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480055.39 725224.26 2.87 480049.81 725224.32 2.87 480049.81 725224.32 7.4 480055.39 725224.26 7.4 480055.39 725224.26 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480049.81 725224.32 2.87 480049.78 725224.47 2.87 480049.78 725224.47 7.4 480049.81 725224.32 7.4 480049.81 725224.32 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480049.78 725224.47 2.87 480049.42 725224.49 2.87 480049.42 725224.49 7.4 480049.78 725224.47 7.4 480049.78 725224.47 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480049.42 725224.49 2.87 480049.3 725215.88 2.87 480049.3 725215.88 7.4 480049.42 725224.49 7.4 480049.42 725224.49 2.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E087-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480049.3 725215.88 7.4 480049.65 725215.89 7.4 480049.64 725216.07 7.4 480055.32 725215.85 7.4 480055.3 725215.75 7.4 480055.68 725215.75 7.4 480055.79 725224.38 7.4 480055.4 725224.39 7.4 480055.39 725224.26 7.4 480049.81 725224.32 7.4 480049.78 725224.47 7.4 480049.42 725224.49 7.4 480049.3 725215.88 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-78D7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-78D7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480979.68 725243.44 2.33 480984.33 725245.97 2.33 480988.21 725238.9 2.33 480983.56 725236.36 2.33 480979.68 725243.44 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480979.68 725243.44 2.33 480983.56 725236.36 2.33 480983.56 725236.36 5.8 480979.68 725243.44 5.8 480979.68 725243.44 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480983.56 725236.36 2.33 480988.21 725238.9 2.33 480988.21 725238.9 5.8 480983.56 725236.36 5.8 480983.56 725236.36 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.21 725238.9 2.33 480984.33 725245.97 2.33 480984.33 725245.97 5.8 480988.21 725238.9 5.8 480988.21 725238.9 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.33 725245.97 2.33 480979.68 725243.44 2.33 480979.68 725243.44 5.8 480984.33 725245.97 5.8 480984.33 725245.97 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480979.68 725243.44 5.8 480983.56 725236.36 5.8 480988.21 725238.9 5.8 480984.33 725245.97 5.8 480979.68 725243.44 5.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C582-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.26</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481218.12 724461.78 2.9 481220.99 724458.94 2.9 481218.87 724456.81 2.9 481228.37 724447.44 2.9 481230.46 724449.58 2.9 481233.22 724446.85 2.9 481240.4 724454.08 2.9 481249.24 724445.32 2.9 481242.09 724438.08 2.9 481244.86 724435.34 2.9 481242.75 724433.2 2.9 481252.19 724423.86 2.9 481254.28 724425.98 2.9 481257.19 724423.15 2.9 481245.25 724411.03 2.9 481206.15 724449.75 2.9 481218.12 724461.78 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481218.12 724461.78 2.9 481206.15 724449.75 2.9 481206.15 724449.75 11.16 481218.12 724461.78 11.16 481218.12 724461.78 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481206.15 724449.75 2.9 481245.25 724411.03 2.9 481245.25 724411.03 11.16 481206.15 724449.75 11.16 481206.15 724449.75 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481245.25 724411.03 2.9 481257.19 724423.15 2.9 481257.19 724423.15 11.16 481245.25 724411.03 11.16 481245.25 724411.03 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481257.19 724423.15 2.9 481254.28 724425.98 2.9 481254.28 724425.98 11.16 481257.19 724423.15 11.16 481257.19 724423.15 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481254.28 724425.98 2.9 481252.19 724423.86 2.9 481252.19 724423.86 11.16 481254.28 724425.98 11.16 481254.28 724425.98 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481252.19 724423.86 2.9 481242.75 724433.2 2.9 481242.75 724433.2 11.16 481252.19 724423.86 11.16 481252.19 724423.86 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481242.75 724433.2 2.9 481244.86 724435.34 2.9 481244.86 724435.34 11.16 481242.75 724433.2 11.16 481242.75 724433.2 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481244.86 724435.34 2.9 481242.09 724438.08 2.9 481242.09 724438.08 11.16 481244.86 724435.34 11.16 481244.86 724435.34 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481242.09 724438.08 2.9 481249.24 724445.32 2.9 481249.24 724445.32 11.16 481242.09 724438.08 11.16 481242.09 724438.08 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481249.24 724445.32 2.9 481240.4 724454.08 2.9 481240.4 724454.08 11.16 481249.24 724445.32 11.16 481249.24 724445.32 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481240.4 724454.08 2.9 481233.22 724446.85 2.9 481233.22 724446.85 11.16 481240.4 724454.08 11.16 481240.4 724454.08 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481233.22 724446.85 2.9 481230.46 724449.58 2.9 481230.46 724449.58 11.16 481233.22 724446.85 11.16 481233.22 724446.85 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481230.46 724449.58 2.9 481228.37 724447.44 2.9 481228.37 724447.44 11.16 481230.46 724449.58 11.16 481230.46 724449.58 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481228.37 724447.44 2.9 481218.87 724456.81 2.9 481218.87 724456.81 11.16 481228.37 724447.44 11.16 481228.37 724447.44 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481218.87 724456.81 2.9 481220.99 724458.94 2.9 481220.99 724458.94 11.16 481218.87 724456.81 11.16 481218.87 724456.81 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481220.99 724458.94 2.9 481218.12 724461.78 2.9 481218.12 724461.78 11.16 481220.99 724458.94 11.16 481220.99 724458.94 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C582-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481218.12 724461.78 11.16 481206.15 724449.75 11.16 481245.25 724411.03 11.16 481257.19 724423.15 11.16 481254.28 724425.98 11.16 481252.19 724423.86 11.16 481242.75 724433.2 11.16 481244.86 724435.34 11.16 481242.09 724438.08 11.16 481249.24 724445.32 11.16 481240.4 724454.08 11.16 481233.22 724446.85 11.16 481230.46 724449.58 11.16 481228.37 724447.44 11.16 481218.87 724456.81 11.16 481220.99 724458.94 11.16 481218.12 724461.78 11.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CAA0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CAA0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CAA0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480060.69 725409.78 2.29 480060.59 725390.01 2.29 480049.89 725390.07 2.29 480049.94 725409.53 2.29 480060.69 725409.78 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CAA0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480060.69 725409.78 2.29 480049.94 725409.53 2.29 480049.94 725409.53 7.92 480060.69 725409.78 7.92 480060.69 725409.78 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CAA0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480049.94 725409.53 2.29 480049.89 725390.07 2.29 480049.89 725390.07 7.92 480049.94 725409.53 7.92 480049.94 725409.53 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CAA0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480049.89 725390.07 2.29 480060.59 725390.01 2.29 480060.59 725390.01 7.92 480049.89 725390.07 7.92 480049.89 725390.07 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CAA0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480060.59 725390.01 2.29 480060.69 725409.78 2.29 480060.69 725409.78 7.92 480060.59 725390.01 7.92 480060.59 725390.01 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CAA0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480060.69 725409.78 7.92 480049.94 725409.53 7.92 480049.89 725390.07 7.92 480060.59 725390.01 7.92 480060.69 725409.78 7.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CA9E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CA9E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.31</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA9E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480051.7 725369.7 2.4 480056.79 725369.5 2.4 480056.68 725359.67 2.4 480051.42 725359.9 2.4 480051.7 725369.7 2.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA9E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480051.7 725369.7 2.4 480051.42 725359.9 2.4 480051.42 725359.9 6.710000000000001 480051.7 725369.7 6.710000000000001 480051.7 725369.7 2.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA9E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480051.42 725359.9 2.4 480056.68 725359.67 2.4 480056.68 725359.67 6.710000000000001 480051.42 725359.9 6.710000000000001 480051.42 725359.9 2.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA9E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480056.68 725359.67 2.4 480056.79 725369.5 2.4 480056.79 725369.5 6.710000000000001 480056.68 725359.67 6.710000000000001 480056.68 725359.67 2.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA9E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480056.79 725369.5 2.4 480051.7 725369.7 2.4 480051.7 725369.7 6.710000000000001 480056.79 725369.5 6.710000000000001 480056.79 725369.5 2.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CA9E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480051.7 725369.7 6.710000000000001 480051.42 725359.9 6.710000000000001 480056.68 725359.67 6.710000000000001 480056.79 725369.5 6.710000000000001 480051.7 725369.7 6.710000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C583-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">11.88</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481248.33 724333.08 2.82 481248.52 724335.63 2.82 481249.77 724343.26 2.82 481264.56 724340.98 2.82 481263.4 724333.41 2.82 481272.21 724326.29 2.82 481272.05 724326.12 2.82 481276.6 724322.43 2.82 481276.75 724322.62 2.82 481280.73 724319.4 2.82 481280.35 724318.92 2.82 481282.31 724317.33 2.82 481282.71 724317.81 2.82 481300.18 724303.69 2.82 481299.77 724303.17 2.82 481301.75 724301.6 2.82 481302.15 724302.09 2.82 481306.29 724299.06 2.82 481306.14 724298.88 2.82 481310.69 724295.53 2.82 481313.01 724298.42 2.82 481318.47 724294 2.82 481316.15 724291.14 2.82 481318.55 724289.21 2.82 481306.68 724274.42 2.82 481294.29 724284.42 2.82 481296.58 724287.26 2.82 481292.72 724290.38 2.82 481293.12 724290.88 2.82 481291.14 724292.45 2.82 481290.62 724291.81 2.82 481288.69 724293.38 2.82 481288.82 724293.55 2.82 481267.33 724310.91 2.82 481267.7 724311.39 2.82 481263.15 724315.08 2.82 481262.77 724314.6 2.82 481253.83 724321.84 2.82 481251.97 724323.63 2.82 481250.43 724325.69 2.82 481249.31 724328.07 2.82 481248.6 724330.53 2.82 481248.33 724333.08 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481248.33 724333.08 2.82 481248.6 724330.53 2.82 481248.6 724330.53 14.700000000000001 481248.33 724333.08 14.700000000000001 481248.33 724333.08 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481248.6 724330.53 2.82 481249.31 724328.07 2.82 481249.31 724328.07 14.700000000000001 481248.6 724330.53 14.700000000000001 481248.6 724330.53 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481249.31 724328.07 2.82 481250.43 724325.69 2.82 481250.43 724325.69 14.700000000000001 481249.31 724328.07 14.700000000000001 481249.31 724328.07 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481250.43 724325.69 2.82 481251.97 724323.63 2.82 481251.97 724323.63 14.700000000000001 481250.43 724325.69 14.700000000000001 481250.43 724325.69 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481251.97 724323.63 2.82 481253.83 724321.84 2.82 481253.83 724321.84 14.700000000000001 481251.97 724323.63 14.700000000000001 481251.97 724323.63 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481253.83 724321.84 2.82 481262.77 724314.6 2.82 481262.77 724314.6 14.700000000000001 481253.83 724321.84 14.700000000000001 481253.83 724321.84 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481262.77 724314.6 2.82 481263.15 724315.08 2.82 481263.15 724315.08 14.700000000000001 481262.77 724314.6 14.700000000000001 481262.77 724314.6 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481263.15 724315.08 2.82 481267.7 724311.39 2.82 481267.7 724311.39 14.700000000000001 481263.15 724315.08 14.700000000000001 481263.15 724315.08 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481267.7 724311.39 2.82 481267.33 724310.91 2.82 481267.33 724310.91 14.700000000000001 481267.7 724311.39 14.700000000000001 481267.7 724311.39 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481267.33 724310.91 2.82 481288.82 724293.55 2.82 481288.82 724293.55 14.700000000000001 481267.33 724310.91 14.700000000000001 481267.33 724310.91 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481288.82 724293.55 2.82 481288.69 724293.38 2.82 481288.69 724293.38 14.700000000000001 481288.82 724293.55 14.700000000000001 481288.82 724293.55 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481288.69 724293.38 2.82 481290.62 724291.81 2.82 481290.62 724291.81 14.700000000000001 481288.69 724293.38 14.700000000000001 481288.69 724293.38 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481290.62 724291.81 2.82 481291.14 724292.45 2.82 481291.14 724292.45 14.700000000000001 481290.62 724291.81 14.700000000000001 481290.62 724291.81 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481291.14 724292.45 2.82 481293.12 724290.88 2.82 481293.12 724290.88 14.700000000000001 481291.14 724292.45 14.700000000000001 481291.14 724292.45 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481293.12 724290.88 2.82 481292.72 724290.38 2.82 481292.72 724290.38 14.700000000000001 481293.12 724290.88 14.700000000000001 481293.12 724290.88 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481292.72 724290.38 2.82 481296.58 724287.26 2.82 481296.58 724287.26 14.700000000000001 481292.72 724290.38 14.700000000000001 481292.72 724290.38 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481296.58 724287.26 2.82 481294.29 724284.42 2.82 481294.29 724284.42 14.700000000000001 481296.58 724287.26 14.700000000000001 481296.58 724287.26 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481294.29 724284.42 2.82 481306.68 724274.42 2.82 481306.68 724274.42 14.700000000000001 481294.29 724284.42 14.700000000000001 481294.29 724284.42 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481306.68 724274.42 2.82 481318.55 724289.21 2.82 481318.55 724289.21 14.700000000000001 481306.68 724274.42 14.700000000000001 481306.68 724274.42 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481318.55 724289.21 2.82 481316.15 724291.14 2.82 481316.15 724291.14 14.700000000000001 481318.55 724289.21 14.700000000000001 481318.55 724289.21 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481316.15 724291.14 2.82 481318.47 724294 2.82 481318.47 724294 14.700000000000001 481316.15 724291.14 14.700000000000001 481316.15 724291.14 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481318.47 724294 2.82 481313.01 724298.42 2.82 481313.01 724298.42 14.700000000000001 481318.47 724294 14.700000000000001 481318.47 724294 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481313.01 724298.42 2.82 481310.69 724295.53 2.82 481310.69 724295.53 14.700000000000001 481313.01 724298.42 14.700000000000001 481313.01 724298.42 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481310.69 724295.53 2.82 481306.14 724298.88 2.82 481306.14 724298.88 14.700000000000001 481310.69 724295.53 14.700000000000001 481310.69 724295.53 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481306.14 724298.88 2.82 481306.29 724299.06 2.82 481306.29 724299.06 14.700000000000001 481306.14 724298.88 14.700000000000001 481306.14 724298.88 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481306.29 724299.06 2.82 481302.15 724302.09 2.82 481302.15 724302.09 14.700000000000001 481306.29 724299.06 14.700000000000001 481306.29 724299.06 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481302.15 724302.09 2.82 481301.75 724301.6 2.82 481301.75 724301.6 14.700000000000001 481302.15 724302.09 14.700000000000001 481302.15 724302.09 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481301.75 724301.6 2.82 481299.77 724303.17 2.82 481299.77 724303.17 14.700000000000001 481301.75 724301.6 14.700000000000001 481301.75 724301.6 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481299.77 724303.17 2.82 481300.18 724303.69 2.82 481300.18 724303.69 14.700000000000001 481299.77 724303.17 14.700000000000001 481299.77 724303.17 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481300.18 724303.69 2.82 481282.71 724317.81 2.82 481282.71 724317.81 14.700000000000001 481300.18 724303.69 14.700000000000001 481300.18 724303.69 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481282.71 724317.81 2.82 481282.31 724317.33 2.82 481282.31 724317.33 14.700000000000001 481282.71 724317.81 14.700000000000001 481282.71 724317.81 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481282.31 724317.33 2.82 481280.35 724318.92 2.82 481280.35 724318.92 14.700000000000001 481282.31 724317.33 14.700000000000001 481282.31 724317.33 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481280.35 724318.92 2.82 481280.73 724319.4 2.82 481280.73 724319.4 14.700000000000001 481280.35 724318.92 14.700000000000001 481280.35 724318.92 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481280.73 724319.4 2.82 481276.75 724322.62 2.82 481276.75 724322.62 14.700000000000001 481280.73 724319.4 14.700000000000001 481280.73 724319.4 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481276.75 724322.62 2.82 481276.6 724322.43 2.82 481276.6 724322.43 14.700000000000001 481276.75 724322.62 14.700000000000001 481276.75 724322.62 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481276.6 724322.43 2.82 481272.05 724326.12 2.82 481272.05 724326.12 14.700000000000001 481276.6 724322.43 14.700000000000001 481276.6 724322.43 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481272.05 724326.12 2.82 481272.21 724326.29 2.82 481272.21 724326.29 14.700000000000001 481272.05 724326.12 14.700000000000001 481272.05 724326.12 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481272.21 724326.29 2.82 481263.4 724333.41 2.82 481263.4 724333.41 14.700000000000001 481272.21 724326.29 14.700000000000001 481272.21 724326.29 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481263.4 724333.41 2.82 481264.56 724340.98 2.82 481264.56 724340.98 14.700000000000001 481263.4 724333.41 14.700000000000001 481263.4 724333.41 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481264.56 724340.98 2.82 481249.77 724343.26 2.82 481249.77 724343.26 14.700000000000001 481264.56 724340.98 14.700000000000001 481264.56 724340.98 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481249.77 724343.26 2.82 481248.52 724335.63 2.82 481248.52 724335.63 14.700000000000001 481249.77 724343.26 14.700000000000001 481249.77 724343.26 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481248.52 724335.63 2.82 481248.33 724333.08 2.82 481248.33 724333.08 14.700000000000001 481248.52 724335.63 14.700000000000001 481248.52 724335.63 2.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C583-FAF6-E053-CA2BA8C0FAE4_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481248.33 724333.08 14.700000000000001 481248.6 724330.53 14.700000000000001 481249.31 724328.07 14.700000000000001 481250.43 724325.69 14.700000000000001 481251.97 724323.63 14.700000000000001 481253.83 724321.84 14.700000000000001 481262.77 724314.6 14.700000000000001 481263.15 724315.08 14.700000000000001 481267.7 724311.39 14.700000000000001 481267.33 724310.91 14.700000000000001 481288.82 724293.55 14.700000000000001 481288.69 724293.38 14.700000000000001 481290.62 724291.81 14.700000000000001 481291.14 724292.45 14.700000000000001 481293.12 724290.88 14.700000000000001 481292.72 724290.38 14.700000000000001 481296.58 724287.26 14.700000000000001 481294.29 724284.42 14.700000000000001 481306.68 724274.42 14.700000000000001 481318.55 724289.21 14.700000000000001 481316.15 724291.14 14.700000000000001 481318.47 724294 14.700000000000001 481313.01 724298.42 14.700000000000001 481310.69 724295.53 14.700000000000001 481306.14 724298.88 14.700000000000001 481306.29 724299.06 14.700000000000001 481302.15 724302.09 14.700000000000001 481301.75 724301.6 14.700000000000001 481299.77 724303.17 14.700000000000001 481300.18 724303.69 14.700000000000001 481282.71 724317.81 14.700000000000001 481282.31 724317.33 14.700000000000001 481280.35 724318.92 14.700000000000001 481280.73 724319.4 14.700000000000001 481276.75 724322.62 14.700000000000001 481276.6 724322.43 14.700000000000001 481272.05 724326.12 14.700000000000001 481272.21 724326.29 14.700000000000001 481263.4 724333.41 14.700000000000001 481264.56 724340.98 14.700000000000001 481249.77 724343.26 14.700000000000001 481248.52 724335.63 14.700000000000001 481248.33 724333.08 14.700000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">13.21</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480981.26 725233.73 2.11 480981.46 725233.82 2.11 480981.71 725233.93 2.11 480982.21 725234.11 2.11 480982.5 725234.2 2.11 480982.9 725234.31 2.11 480983.26 725234.38 2.11 480983.64 725234.43 2.11 480984.09 725234.48 2.11 480984.43 725234.47 2.11 480984.69 725234.48 2.11 480985.04 725234.47 2.11 480985.33 725234.45 2.11 480985.65 725234.43 2.11 480985.97 725234.37 2.11 480986.3 725234.32 2.11 480986.58 725234.24 2.11 480986.96 725234.16 2.11 480987.24 725234.04 2.11 480987.62 725233.88 2.11 480987.98 725233.7 2.11 480988.33 725233.51 2.11 480988.65 725233.31 2.11 480988.92 725233.12 2.11 480989.24 725232.89 2.11 480989.6 725232.58 2.11 480989.82 725232.38 2.11 480990.08 725232.1 2.11 480990.38 725231.77 2.11 480990.54 725231.57 2.11 480990.71 725231.35 2.11 480990.91 725231.05 2.11 480991.09 725230.77 2.11 480991.22 725230.51 2.11 480991.36 725230.16 2.11 480991.59 725229.59 2.11 480991.78 725229.05 2.11 480991.9 725228.61 2.11 480991.98 725228.21 2.11 480992.08 725227.5 2.11 480992.1 725227.24 2.11 480992.11 725226.91 2.11 480992.11 725226.66 2.11 480992.1 725226.38 2.11 480992.06 725226.02 2.11 480992.02 725225.69 2.11 480991.97 725225.44 2.11 480991.92 725225.18 2.11 480991.82 725224.86 2.11 480991.74 725224.59 2.11 480991.64 725224.27 2.11 480991.49 725223.96 2.11 480991.41 725223.78 2.11 480991.26 725223.47 2.11 480991.1 725223.19 2.11 480990.97 725222.96 2.11 480990.8 725222.7 2.11 480990.65 725222.5 2.11 480990.49 725222.29 2.11 480990.34 725222.1 2.11 480990.16 725221.9 2.11 480989.96 725221.66 2.11 480989.75 725221.47 2.11 480989.51 725221.25 2.11 480989.13 725220.93 2.11 480988.67 725220.59 2.11 480988.21 725220.33 2.11 480987.98 725220.22 2.11 480987.77 725220.12 2.11 480987.61 725220.05 2.11 480987.21 725219.87 2.11 480986.81 725219.74 2.11 480986.5 725219.64 2.11 480986.14 725219.57 2.11 480985.68 725219.49 2.11 480984.98 725219.42 2.11 480984.47 725219.41 2.11 480983.86 725219.44 2.11 480983.45 725219.49 2.11 480983.04 725219.56 2.11 480982.67 725219.66 2.11 480982.26 725219.77 2.11 480981.87 725219.91 2.11 480981.67 725219.99 2.11 480981.52 725220.05 2.11 480981.31 725220.15 2.11 480981.09 725220.26 2.11 480981.01 725220.3 2.11 480980.78 725220.42 2.11 480980.56 725220.55 2.11 480980.41 725220.66 2.11 480980.09 725220.87 2.11 480979.94 725221 2.11 480979.67 725221.23 2.11 480979.43 725221.44 2.11 480979.19 725221.69 2.11 480978.92 725221.97 2.11 480978.72 725222.21 2.11 480978.54 725222.44 2.11 480978.26 725222.82 2.11 480978.08 725223.15 2.11 480977.88 725223.48 2.11 480977.8 725223.64 2.11 480977.66 725223.94 2.11 480977.5 725224.34 2.11 480977.39 725224.67 2.11 480977.28 725225.01 2.11 480977.21 725225.35 2.11 480977.15 725225.64 2.11 480977.1 725225.96 2.11 480977.05 725226.35 2.11 480977.04 725226.73 2.11 480977.02 725226.98 2.11 480977.04 725227.32 2.11 480977.05 725227.62 2.11 480977.1 725227.92 2.11 480977.12 725228.16 2.11 480977.18 725228.45 2.11 480977.25 725228.72 2.11 480977.31 725228.98 2.11 480977.4 725229.28 2.11 480977.59 725229.79 2.11 480977.72 725230.08 2.11 480977.85 725230.33 2.11 480977.97 725230.58 2.11 480978.09 725230.77 2.11 480978.23 725231.01 2.11 480978.41 725231.28 2.11 480978.7 725231.63 2.11 480978.96 725231.95 2.11 480979.24 725232.24 2.11 480979.44 725232.45 2.11 480979.71 725232.71 2.11 480980.05 725232.98 2.11 480980.37 725233.21 2.11 480981.26 725233.73 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480981.26 725233.73 2.11 480980.37 725233.21 2.11 480980.37 725233.21 15.32 480981.26 725233.73 15.32 480981.26 725233.73 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480980.37 725233.21 2.11 480980.05 725232.98 2.11 480980.05 725232.98 15.32 480980.37 725233.21 15.32 480980.37 725233.21 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480980.05 725232.98 2.11 480979.71 725232.71 2.11 480979.71 725232.71 15.32 480980.05 725232.98 15.32 480980.05 725232.98 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480979.71 725232.71 2.11 480979.44 725232.45 2.11 480979.44 725232.45 15.32 480979.71 725232.71 15.32 480979.71 725232.71 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480979.44 725232.45 2.11 480979.24 725232.24 2.11 480979.24 725232.24 15.32 480979.44 725232.45 15.32 480979.44 725232.45 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480979.24 725232.24 2.11 480978.96 725231.95 2.11 480978.96 725231.95 15.32 480979.24 725232.24 15.32 480979.24 725232.24 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480978.96 725231.95 2.11 480978.7 725231.63 2.11 480978.7 725231.63 15.32 480978.96 725231.95 15.32 480978.96 725231.95 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480978.7 725231.63 2.11 480978.41 725231.28 2.11 480978.41 725231.28 15.32 480978.7 725231.63 15.32 480978.7 725231.63 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480978.41 725231.28 2.11 480978.23 725231.01 2.11 480978.23 725231.01 15.32 480978.41 725231.28 15.32 480978.41 725231.28 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480978.23 725231.01 2.11 480978.09 725230.77 2.11 480978.09 725230.77 15.32 480978.23 725231.01 15.32 480978.23 725231.01 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480978.09 725230.77 2.11 480977.97 725230.58 2.11 480977.97 725230.58 15.32 480978.09 725230.77 15.32 480978.09 725230.77 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.97 725230.58 2.11 480977.85 725230.33 2.11 480977.85 725230.33 15.32 480977.97 725230.58 15.32 480977.97 725230.58 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.85 725230.33 2.11 480977.72 725230.08 2.11 480977.72 725230.08 15.32 480977.85 725230.33 15.32 480977.85 725230.33 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.72 725230.08 2.11 480977.59 725229.79 2.11 480977.59 725229.79 15.32 480977.72 725230.08 15.32 480977.72 725230.08 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.59 725229.79 2.11 480977.4 725229.28 2.11 480977.4 725229.28 15.32 480977.59 725229.79 15.32 480977.59 725229.79 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.4 725229.28 2.11 480977.31 725228.98 2.11 480977.31 725228.98 15.32 480977.4 725229.28 15.32 480977.4 725229.28 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.31 725228.98 2.11 480977.25 725228.72 2.11 480977.25 725228.72 15.32 480977.31 725228.98 15.32 480977.31 725228.98 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.25 725228.72 2.11 480977.18 725228.45 2.11 480977.18 725228.45 15.32 480977.25 725228.72 15.32 480977.25 725228.72 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.18 725228.45 2.11 480977.12 725228.16 2.11 480977.12 725228.16 15.32 480977.18 725228.45 15.32 480977.18 725228.45 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.12 725228.16 2.11 480977.1 725227.92 2.11 480977.1 725227.92 15.32 480977.12 725228.16 15.32 480977.12 725228.16 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.1 725227.92 2.11 480977.05 725227.62 2.11 480977.05 725227.62 15.32 480977.1 725227.92 15.32 480977.1 725227.92 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.05 725227.62 2.11 480977.04 725227.32 2.11 480977.04 725227.32 15.32 480977.05 725227.62 15.32 480977.05 725227.62 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.04 725227.32 2.11 480977.02 725226.98 2.11 480977.02 725226.98 15.32 480977.04 725227.32 15.32 480977.04 725227.32 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.02 725226.98 2.11 480977.04 725226.73 2.11 480977.04 725226.73 15.32 480977.02 725226.98 15.32 480977.02 725226.98 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.04 725226.73 2.11 480977.05 725226.35 2.11 480977.05 725226.35 15.32 480977.04 725226.73 15.32 480977.04 725226.73 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.05 725226.35 2.11 480977.1 725225.96 2.11 480977.1 725225.96 15.32 480977.05 725226.35 15.32 480977.05 725226.35 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.1 725225.96 2.11 480977.15 725225.64 2.11 480977.15 725225.64 15.32 480977.1 725225.96 15.32 480977.1 725225.96 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.15 725225.64 2.11 480977.21 725225.35 2.11 480977.21 725225.35 15.32 480977.15 725225.64 15.32 480977.15 725225.64 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.21 725225.35 2.11 480977.28 725225.01 2.11 480977.28 725225.01 15.32 480977.21 725225.35 15.32 480977.21 725225.35 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.28 725225.01 2.11 480977.39 725224.67 2.11 480977.39 725224.67 15.32 480977.28 725225.01 15.32 480977.28 725225.01 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.39 725224.67 2.11 480977.5 725224.34 2.11 480977.5 725224.34 15.32 480977.39 725224.67 15.32 480977.39 725224.67 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.5 725224.34 2.11 480977.66 725223.94 2.11 480977.66 725223.94 15.32 480977.5 725224.34 15.32 480977.5 725224.34 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.66 725223.94 2.11 480977.8 725223.64 2.11 480977.8 725223.64 15.32 480977.66 725223.94 15.32 480977.66 725223.94 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.8 725223.64 2.11 480977.88 725223.48 2.11 480977.88 725223.48 15.32 480977.8 725223.64 15.32 480977.8 725223.64 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480977.88 725223.48 2.11 480978.08 725223.15 2.11 480978.08 725223.15 15.32 480977.88 725223.48 15.32 480977.88 725223.48 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480978.08 725223.15 2.11 480978.26 725222.82 2.11 480978.26 725222.82 15.32 480978.08 725223.15 15.32 480978.08 725223.15 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480978.26 725222.82 2.11 480978.54 725222.44 2.11 480978.54 725222.44 15.32 480978.26 725222.82 15.32 480978.26 725222.82 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480978.54 725222.44 2.11 480978.72 725222.21 2.11 480978.72 725222.21 15.32 480978.54 725222.44 15.32 480978.54 725222.44 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480978.72 725222.21 2.11 480978.92 725221.97 2.11 480978.92 725221.97 15.32 480978.72 725222.21 15.32 480978.72 725222.21 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480978.92 725221.97 2.11 480979.19 725221.69 2.11 480979.19 725221.69 15.32 480978.92 725221.97 15.32 480978.92 725221.97 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480979.19 725221.69 2.11 480979.43 725221.44 2.11 480979.43 725221.44 15.32 480979.19 725221.69 15.32 480979.19 725221.69 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480979.43 725221.44 2.11 480979.67 725221.23 2.11 480979.67 725221.23 15.32 480979.43 725221.44 15.32 480979.43 725221.44 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480979.67 725221.23 2.11 480979.94 725221 2.11 480979.94 725221 15.32 480979.67 725221.23 15.32 480979.67 725221.23 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480979.94 725221 2.11 480980.09 725220.87 2.11 480980.09 725220.87 15.32 480979.94 725221 15.32 480979.94 725221 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480980.09 725220.87 2.11 480980.41 725220.66 2.11 480980.41 725220.66 15.32 480980.09 725220.87 15.32 480980.09 725220.87 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480980.41 725220.66 2.11 480980.56 725220.55 2.11 480980.56 725220.55 15.32 480980.41 725220.66 15.32 480980.41 725220.66 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480980.56 725220.55 2.11 480980.78 725220.42 2.11 480980.78 725220.42 15.32 480980.56 725220.55 15.32 480980.56 725220.55 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480980.78 725220.42 2.11 480981.01 725220.3 2.11 480981.01 725220.3 15.32 480980.78 725220.42 15.32 480980.78 725220.42 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480981.01 725220.3 2.11 480981.09 725220.26 2.11 480981.09 725220.26 15.32 480981.01 725220.3 15.32 480981.01 725220.3 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480981.09 725220.26 2.11 480981.31 725220.15 2.11 480981.31 725220.15 15.32 480981.09 725220.26 15.32 480981.09 725220.26 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480981.31 725220.15 2.11 480981.52 725220.05 2.11 480981.52 725220.05 15.32 480981.31 725220.15 15.32 480981.31 725220.15 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480981.52 725220.05 2.11 480981.67 725219.99 2.11 480981.67 725219.99 15.32 480981.52 725220.05 15.32 480981.52 725220.05 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480981.67 725219.99 2.11 480981.87 725219.91 2.11 480981.87 725219.91 15.32 480981.67 725219.99 15.32 480981.67 725219.99 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480981.87 725219.91 2.11 480982.26 725219.77 2.11 480982.26 725219.77 15.32 480981.87 725219.91 15.32 480981.87 725219.91 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480982.26 725219.77 2.11 480982.67 725219.66 2.11 480982.67 725219.66 15.32 480982.26 725219.77 15.32 480982.26 725219.77 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480982.67 725219.66 2.11 480983.04 725219.56 2.11 480983.04 725219.56 15.32 480982.67 725219.66 15.32 480982.67 725219.66 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480983.04 725219.56 2.11 480983.45 725219.49 2.11 480983.45 725219.49 15.32 480983.04 725219.56 15.32 480983.04 725219.56 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480983.45 725219.49 2.11 480983.86 725219.44 2.11 480983.86 725219.44 15.32 480983.45 725219.49 15.32 480983.45 725219.49 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480983.86 725219.44 2.11 480984.47 725219.41 2.11 480984.47 725219.41 15.32 480983.86 725219.44 15.32 480983.86 725219.44 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.47 725219.41 2.11 480984.98 725219.42 2.11 480984.98 725219.42 15.32 480984.47 725219.41 15.32 480984.47 725219.41 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.98 725219.42 2.11 480985.68 725219.49 2.11 480985.68 725219.49 15.32 480984.98 725219.42 15.32 480984.98 725219.42 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.68 725219.49 2.11 480986.14 725219.57 2.11 480986.14 725219.57 15.32 480985.68 725219.49 15.32 480985.68 725219.49 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.14 725219.57 2.11 480986.5 725219.64 2.11 480986.5 725219.64 15.32 480986.14 725219.57 15.32 480986.14 725219.57 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.5 725219.64 2.11 480986.81 725219.74 2.11 480986.81 725219.74 15.32 480986.5 725219.64 15.32 480986.5 725219.64 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.81 725219.74 2.11 480987.21 725219.87 2.11 480987.21 725219.87 15.32 480986.81 725219.74 15.32 480986.81 725219.74 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.21 725219.87 2.11 480987.61 725220.05 2.11 480987.61 725220.05 15.32 480987.21 725219.87 15.32 480987.21 725219.87 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.61 725220.05 2.11 480987.77 725220.12 2.11 480987.77 725220.12 15.32 480987.61 725220.05 15.32 480987.61 725220.05 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.77 725220.12 2.11 480987.98 725220.22 2.11 480987.98 725220.22 15.32 480987.77 725220.12 15.32 480987.77 725220.12 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.98 725220.22 2.11 480988.21 725220.33 2.11 480988.21 725220.33 15.32 480987.98 725220.22 15.32 480987.98 725220.22 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.21 725220.33 2.11 480988.67 725220.59 2.11 480988.67 725220.59 15.32 480988.21 725220.33 15.32 480988.21 725220.33 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_72">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.67 725220.59 2.11 480989.13 725220.93 2.11 480989.13 725220.93 15.32 480988.67 725220.59 15.32 480988.67 725220.59 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480989.13 725220.93 2.11 480989.51 725221.25 2.11 480989.51 725221.25 15.32 480989.13 725220.93 15.32 480989.13 725220.93 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_74">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480989.51 725221.25 2.11 480989.75 725221.47 2.11 480989.75 725221.47 15.32 480989.51 725221.25 15.32 480989.51 725221.25 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_75">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480989.75 725221.47 2.11 480989.96 725221.66 2.11 480989.96 725221.66 15.32 480989.75 725221.47 15.32 480989.75 725221.47 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_76">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480989.96 725221.66 2.11 480990.16 725221.9 2.11 480990.16 725221.9 15.32 480989.96 725221.66 15.32 480989.96 725221.66 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_77">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.16 725221.9 2.11 480990.34 725222.1 2.11 480990.34 725222.1 15.32 480990.16 725221.9 15.32 480990.16 725221.9 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_78">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.34 725222.1 2.11 480990.49 725222.29 2.11 480990.49 725222.29 15.32 480990.34 725222.1 15.32 480990.34 725222.1 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_79">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.49 725222.29 2.11 480990.65 725222.5 2.11 480990.65 725222.5 15.32 480990.49 725222.29 15.32 480990.49 725222.29 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.65 725222.5 2.11 480990.8 725222.7 2.11 480990.8 725222.7 15.32 480990.65 725222.5 15.32 480990.65 725222.5 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_81">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.8 725222.7 2.11 480990.97 725222.96 2.11 480990.97 725222.96 15.32 480990.8 725222.7 15.32 480990.8 725222.7 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_82">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.97 725222.96 2.11 480991.1 725223.19 2.11 480991.1 725223.19 15.32 480990.97 725222.96 15.32 480990.97 725222.96 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_83">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.1 725223.19 2.11 480991.26 725223.47 2.11 480991.26 725223.47 15.32 480991.1 725223.19 15.32 480991.1 725223.19 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_84">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.26 725223.47 2.11 480991.41 725223.78 2.11 480991.41 725223.78 15.32 480991.26 725223.47 15.32 480991.26 725223.47 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_85">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.41 725223.78 2.11 480991.49 725223.96 2.11 480991.49 725223.96 15.32 480991.41 725223.78 15.32 480991.41 725223.78 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_86">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.49 725223.96 2.11 480991.64 725224.27 2.11 480991.64 725224.27 15.32 480991.49 725223.96 15.32 480991.49 725223.96 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_87">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.64 725224.27 2.11 480991.74 725224.59 2.11 480991.74 725224.59 15.32 480991.64 725224.27 15.32 480991.64 725224.27 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_88">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.74 725224.59 2.11 480991.82 725224.86 2.11 480991.82 725224.86 15.32 480991.74 725224.59 15.32 480991.74 725224.59 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_89">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.82 725224.86 2.11 480991.92 725225.18 2.11 480991.92 725225.18 15.32 480991.82 725224.86 15.32 480991.82 725224.86 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_90">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.92 725225.18 2.11 480991.97 725225.44 2.11 480991.97 725225.44 15.32 480991.92 725225.18 15.32 480991.92 725225.18 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.97 725225.44 2.11 480992.02 725225.69 2.11 480992.02 725225.69 15.32 480991.97 725225.44 15.32 480991.97 725225.44 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_92">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.02 725225.69 2.11 480992.06 725226.02 2.11 480992.06 725226.02 15.32 480992.02 725225.69 15.32 480992.02 725225.69 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_93">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.06 725226.02 2.11 480992.1 725226.38 2.11 480992.1 725226.38 15.32 480992.06 725226.02 15.32 480992.06 725226.02 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_94">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.1 725226.38 2.11 480992.11 725226.66 2.11 480992.11 725226.66 15.32 480992.1 725226.38 15.32 480992.1 725226.38 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_95">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.11 725226.66 2.11 480992.11 725226.91 2.11 480992.11 725226.91 15.32 480992.11 725226.66 15.32 480992.11 725226.66 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_96">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.11 725226.91 2.11 480992.1 725227.24 2.11 480992.1 725227.24 15.32 480992.11 725226.91 15.32 480992.11 725226.91 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_97">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.1 725227.24 2.11 480992.08 725227.5 2.11 480992.08 725227.5 15.32 480992.1 725227.24 15.32 480992.1 725227.24 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_98">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.08 725227.5 2.11 480991.98 725228.21 2.11 480991.98 725228.21 15.32 480992.08 725227.5 15.32 480992.08 725227.5 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_99">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.98 725228.21 2.11 480991.9 725228.61 2.11 480991.9 725228.61 15.32 480991.98 725228.21 15.32 480991.98 725228.21 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_100">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.9 725228.61 2.11 480991.78 725229.05 2.11 480991.78 725229.05 15.32 480991.9 725228.61 15.32 480991.9 725228.61 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_101">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.78 725229.05 2.11 480991.59 725229.59 2.11 480991.59 725229.59 15.32 480991.78 725229.05 15.32 480991.78 725229.05 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_102">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.59 725229.59 2.11 480991.36 725230.16 2.11 480991.36 725230.16 15.32 480991.59 725229.59 15.32 480991.59 725229.59 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_103">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.36 725230.16 2.11 480991.22 725230.51 2.11 480991.22 725230.51 15.32 480991.36 725230.16 15.32 480991.36 725230.16 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_104">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.22 725230.51 2.11 480991.09 725230.77 2.11 480991.09 725230.77 15.32 480991.22 725230.51 15.32 480991.22 725230.51 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_105">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.09 725230.77 2.11 480990.91 725231.05 2.11 480990.91 725231.05 15.32 480991.09 725230.77 15.32 480991.09 725230.77 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_106">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.91 725231.05 2.11 480990.71 725231.35 2.11 480990.71 725231.35 15.32 480990.91 725231.05 15.32 480990.91 725231.05 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_107">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.71 725231.35 2.11 480990.54 725231.57 2.11 480990.54 725231.57 15.32 480990.71 725231.35 15.32 480990.71 725231.35 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_108">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.54 725231.57 2.11 480990.38 725231.77 2.11 480990.38 725231.77 15.32 480990.54 725231.57 15.32 480990.54 725231.57 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_109">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.38 725231.77 2.11 480990.08 725232.1 2.11 480990.08 725232.1 15.32 480990.38 725231.77 15.32 480990.38 725231.77 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_110">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.08 725232.1 2.11 480989.82 725232.38 2.11 480989.82 725232.38 15.32 480990.08 725232.1 15.32 480990.08 725232.1 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_111">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480989.82 725232.38 2.11 480989.6 725232.58 2.11 480989.6 725232.58 15.32 480989.82 725232.38 15.32 480989.82 725232.38 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_112">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480989.6 725232.58 2.11 480989.24 725232.89 2.11 480989.24 725232.89 15.32 480989.6 725232.58 15.32 480989.6 725232.58 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_113">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480989.24 725232.89 2.11 480988.92 725233.12 2.11 480988.92 725233.12 15.32 480989.24 725232.89 15.32 480989.24 725232.89 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_114">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.92 725233.12 2.11 480988.65 725233.31 2.11 480988.65 725233.31 15.32 480988.92 725233.12 15.32 480988.92 725233.12 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_115">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.65 725233.31 2.11 480988.33 725233.51 2.11 480988.33 725233.51 15.32 480988.65 725233.31 15.32 480988.65 725233.31 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_116">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.33 725233.51 2.11 480987.98 725233.7 2.11 480987.98 725233.7 15.32 480988.33 725233.51 15.32 480988.33 725233.51 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_117">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.98 725233.7 2.11 480987.62 725233.88 2.11 480987.62 725233.88 15.32 480987.98 725233.7 15.32 480987.98 725233.7 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_118">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.62 725233.88 2.11 480987.24 725234.04 2.11 480987.24 725234.04 15.32 480987.62 725233.88 15.32 480987.62 725233.88 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_119">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.24 725234.04 2.11 480986.96 725234.16 2.11 480986.96 725234.16 15.32 480987.24 725234.04 15.32 480987.24 725234.04 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_120">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.96 725234.16 2.11 480986.58 725234.24 2.11 480986.58 725234.24 15.32 480986.96 725234.16 15.32 480986.96 725234.16 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_121">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.58 725234.24 2.11 480986.3 725234.32 2.11 480986.3 725234.32 15.32 480986.58 725234.24 15.32 480986.58 725234.24 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_122">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.3 725234.32 2.11 480985.97 725234.37 2.11 480985.97 725234.37 15.32 480986.3 725234.32 15.32 480986.3 725234.32 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_123">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.97 725234.37 2.11 480985.65 725234.43 2.11 480985.65 725234.43 15.32 480985.97 725234.37 15.32 480985.97 725234.37 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_124">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.65 725234.43 2.11 480985.33 725234.45 2.11 480985.33 725234.45 15.32 480985.65 725234.43 15.32 480985.65 725234.43 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_125">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.33 725234.45 2.11 480985.04 725234.47 2.11 480985.04 725234.47 15.32 480985.33 725234.45 15.32 480985.33 725234.45 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_126">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.04 725234.47 2.11 480984.69 725234.48 2.11 480984.69 725234.48 15.32 480985.04 725234.47 15.32 480985.04 725234.47 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_127">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.69 725234.48 2.11 480984.43 725234.47 2.11 480984.43 725234.47 15.32 480984.69 725234.48 15.32 480984.69 725234.48 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_128">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.43 725234.47 2.11 480984.09 725234.48 2.11 480984.09 725234.48 15.32 480984.43 725234.47 15.32 480984.43 725234.47 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_129">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.09 725234.48 2.11 480983.64 725234.43 2.11 480983.64 725234.43 15.32 480984.09 725234.48 15.32 480984.09 725234.48 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_130">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480983.64 725234.43 2.11 480983.26 725234.38 2.11 480983.26 725234.38 15.32 480983.64 725234.43 15.32 480983.64 725234.43 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_131">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480983.26 725234.38 2.11 480982.9 725234.31 2.11 480982.9 725234.31 15.32 480983.26 725234.38 15.32 480983.26 725234.38 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_132">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480982.9 725234.31 2.11 480982.5 725234.2 2.11 480982.5 725234.2 15.32 480982.9 725234.31 15.32 480982.9 725234.31 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_133">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480982.5 725234.2 2.11 480982.21 725234.11 2.11 480982.21 725234.11 15.32 480982.5 725234.2 15.32 480982.5 725234.2 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_134">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480982.21 725234.11 2.11 480981.71 725233.93 2.11 480981.71 725233.93 15.32 480982.21 725234.11 15.32 480982.21 725234.11 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_135">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480981.71 725233.93 2.11 480981.46 725233.82 2.11 480981.46 725233.82 15.32 480981.71 725233.93 15.32 480981.71 725233.93 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_136">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480981.46 725233.82 2.11 480981.26 725233.73 2.11 480981.26 725233.73 15.32 480981.46 725233.82 15.32 480981.46 725233.82 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D8-FAF6-E053-CA2BA8C0FAE4_PG_137">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480981.26 725233.73 15.32 480980.37 725233.21 15.32 480980.05 725232.98 15.32 480979.71 725232.71 15.32 480979.44 725232.45 15.32 480979.24 725232.24 15.32 480978.96 725231.95 15.32 480978.7 725231.63 15.32 480978.41 725231.28 15.32 480978.23 725231.01 15.32 480978.09 725230.77 15.32 480977.97 725230.58 15.32 480977.85 725230.33 15.32 480977.72 725230.08 15.32 480977.59 725229.79 15.32 480977.4 725229.28 15.32 480977.31 725228.98 15.32 480977.25 725228.72 15.32 480977.18 725228.45 15.32 480977.12 725228.16 15.32 480977.1 725227.92 15.32 480977.05 725227.62 15.32 480977.04 725227.32 15.32 480977.02 725226.98 15.32 480977.04 725226.73 15.32 480977.05 725226.35 15.32 480977.1 725225.96 15.32 480977.15 725225.64 15.32 480977.21 725225.35 15.32 480977.28 725225.01 15.32 480977.39 725224.67 15.32 480977.5 725224.34 15.32 480977.66 725223.94 15.32 480977.8 725223.64 15.32 480977.88 725223.48 15.32 480978.08 725223.15 15.32 480978.26 725222.82 15.32 480978.54 725222.44 15.32 480978.72 725222.21 15.32 480978.92 725221.97 15.32 480979.19 725221.69 15.32 480979.43 725221.44 15.32 480979.67 725221.23 15.32 480979.94 725221 15.32 480980.09 725220.87 15.32 480980.41 725220.66 15.32 480980.56 725220.55 15.32 480980.78 725220.42 15.32 480981.01 725220.3 15.32 480981.09 725220.26 15.32 480981.31 725220.15 15.32 480981.52 725220.05 15.32 480981.67 725219.99 15.32 480981.87 725219.91 15.32 480982.26 725219.77 15.32 480982.67 725219.66 15.32 480983.04 725219.56 15.32 480983.45 725219.49 15.32 480983.86 725219.44 15.32 480984.47 725219.41 15.32 480984.98 725219.42 15.32 480985.68 725219.49 15.32 480986.14 725219.57 15.32 480986.5 725219.64 15.32 480986.81 725219.74 15.32 480987.21 725219.87 15.32 480987.61 725220.05 15.32 480987.77 725220.12 15.32 480987.98 725220.22 15.32 480988.21 725220.33 15.32 480988.67 725220.59 15.32 480989.13 725220.93 15.32 480989.51 725221.25 15.32 480989.75 725221.47 15.32 480989.96 725221.66 15.32 480990.16 725221.9 15.32 480990.34 725222.1 15.32 480990.49 725222.29 15.32 480990.65 725222.5 15.32 480990.8 725222.7 15.32 480990.97 725222.96 15.32 480991.1 725223.19 15.32 480991.26 725223.47 15.32 480991.41 725223.78 15.32 480991.49 725223.96 15.32 480991.64 725224.27 15.32 480991.74 725224.59 15.32 480991.82 725224.86 15.32 480991.92 725225.18 15.32 480991.97 725225.44 15.32 480992.02 725225.69 15.32 480992.06 725226.02 15.32 480992.1 725226.38 15.32 480992.11 725226.66 15.32 480992.11 725226.91 15.32 480992.1 725227.24 15.32 480992.08 725227.5 15.32 480991.98 725228.21 15.32 480991.9 725228.61 15.32 480991.78 725229.05 15.32 480991.59 725229.59 15.32 480991.36 725230.16 15.32 480991.22 725230.51 15.32 480991.09 725230.77 15.32 480990.91 725231.05 15.32 480990.71 725231.35 15.32 480990.54 725231.57 15.32 480990.38 725231.77 15.32 480990.08 725232.1 15.32 480989.82 725232.38 15.32 480989.6 725232.58 15.32 480989.24 725232.89 15.32 480988.92 725233.12 15.32 480988.65 725233.31 15.32 480988.33 725233.51 15.32 480987.98 725233.7 15.32 480987.62 725233.88 15.32 480987.24 725234.04 15.32 480986.96 725234.16 15.32 480986.58 725234.24 15.32 480986.3 725234.32 15.32 480985.97 725234.37 15.32 480985.65 725234.43 15.32 480985.33 725234.45 15.32 480985.04 725234.47 15.32 480984.69 725234.48 15.32 480984.43 725234.47 15.32 480984.09 725234.48 15.32 480983.64 725234.43 15.32 480983.26 725234.38 15.32 480982.9 725234.31 15.32 480982.5 725234.2 15.32 480982.21 725234.11 15.32 480981.71 725233.93 15.32 480981.46 725233.82 15.32 480981.26 725233.73 15.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C63E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C63E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.45</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C63E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479807.33 725605.95 3.17 479809.21 725578.33 3.17 479798.67 725577.76 3.17 479796.71 725605.14 3.17 479807.33 725605.95 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C63E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479807.33 725605.95 3.17 479796.71 725605.14 3.17 479796.71 725605.14 7.62 479807.33 725605.95 7.62 479807.33 725605.95 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C63E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479796.71 725605.14 3.17 479798.67 725577.76 3.17 479798.67 725577.76 7.62 479796.71 725605.14 7.62 479796.71 725605.14 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C63E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479798.67 725577.76 3.17 479809.21 725578.33 3.17 479809.21 725578.33 7.62 479798.67 725577.76 7.62 479798.67 725577.76 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C63E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479809.21 725578.33 3.17 479807.33 725605.95 3.17 479807.33 725605.95 7.62 479809.21 725578.33 7.62 479809.21 725578.33 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C63E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479807.33 725605.95 7.62 479796.71 725605.14 7.62 479798.67 725577.76 7.62 479809.21 725578.33 7.62 479807.33 725605.95 7.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.11</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481103.17 724462.22 3.19 481137.73 724456.84 3.19 481136.37 724448.19 3.19 481133.88 724448.57 3.19 481129.98 724449.19 3.19 481123.59 724450.18 3.19 481119.11 724450.87 3.19 481109.21 724452.41 3.19 481107.64 724452.65 3.19 481101.8 724453.55 3.19 481103.17 724462.22 3.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481103.17 724462.22 3.19 481101.8 724453.55 3.19 481101.8 724453.55 10.3 481103.17 724462.22 10.3 481103.17 724462.22 3.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481101.8 724453.55 3.19 481107.64 724452.65 3.19 481107.64 724452.65 10.3 481101.8 724453.55 10.3 481101.8 724453.55 3.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481107.64 724452.65 3.19 481109.21 724452.41 3.19 481109.21 724452.41 10.3 481107.64 724452.65 10.3 481107.64 724452.65 3.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481109.21 724452.41 3.19 481119.11 724450.87 3.19 481119.11 724450.87 10.3 481109.21 724452.41 10.3 481109.21 724452.41 3.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481119.11 724450.87 3.19 481123.59 724450.18 3.19 481123.59 724450.18 10.3 481119.11 724450.87 10.3 481119.11 724450.87 3.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481123.59 724450.18 3.19 481129.98 724449.19 3.19 481129.98 724449.19 10.3 481123.59 724450.18 10.3 481123.59 724450.18 3.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481129.98 724449.19 3.19 481133.88 724448.57 3.19 481133.88 724448.57 10.3 481129.98 724449.19 10.3 481129.98 724449.19 3.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481133.88 724448.57 3.19 481136.37 724448.19 3.19 481136.37 724448.19 10.3 481133.88 724448.57 10.3 481133.88 724448.57 3.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481136.37 724448.19 3.19 481137.73 724456.84 3.19 481137.73 724456.84 10.3 481136.37 724448.19 10.3 481136.37 724448.19 3.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481137.73 724456.84 3.19 481103.17 724462.22 3.19 481103.17 724462.22 10.3 481137.73 724456.84 10.3 481137.73 724456.84 3.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C56C-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481103.17 724462.22 10.3 481101.8 724453.55 10.3 481107.64 724452.65 10.3 481109.21 724452.41 10.3 481119.11 724450.87 10.3 481123.59 724450.18 10.3 481129.98 724449.19 10.3 481133.88 724448.57 10.3 481136.37 724448.19 10.3 481137.73 724456.84 10.3 481103.17 724462.22 10.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D3A7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D3A7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.46</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3A7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479817.04 724920.03 2.75 479820.21 724927.89 2.75 479820.6 724927.74 2.75 479820.5 724927.53 2.75 479829.28 724923.84 2.75 479829.39 724924.06 2.75 479829.74 724923.91 2.75 479826.59 724916.07 2.75 479817.04 724920.03 2.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3A7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479817.04 724920.03 2.75 479826.59 724916.07 2.75 479826.59 724916.07 7.21 479817.04 724920.03 7.21 479817.04 724920.03 2.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3A7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479826.59 724916.07 2.75 479829.74 724923.91 2.75 479829.74 724923.91 7.21 479826.59 724916.07 7.21 479826.59 724916.07 2.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3A7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479829.74 724923.91 2.75 479829.39 724924.06 2.75 479829.39 724924.06 7.21 479829.74 724923.91 7.21 479829.74 724923.91 2.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3A7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479829.39 724924.06 2.75 479829.28 724923.84 2.75 479829.28 724923.84 7.21 479829.39 724924.06 7.21 479829.39 724924.06 2.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3A7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479829.28 724923.84 2.75 479820.5 724927.53 2.75 479820.5 724927.53 7.21 479829.28 724923.84 7.21 479829.28 724923.84 2.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3A7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479820.5 724927.53 2.75 479820.6 724927.74 2.75 479820.6 724927.74 7.21 479820.5 724927.53 7.21 479820.5 724927.53 2.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3A7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479820.6 724927.74 2.75 479820.21 724927.89 2.75 479820.21 724927.89 7.21 479820.6 724927.74 7.21 479820.6 724927.74 2.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3A7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479820.21 724927.89 2.75 479817.04 724920.03 2.75 479817.04 724920.03 7.21 479820.21 724927.89 7.21 479820.21 724927.89 2.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3A7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479817.04 724920.03 7.21 479826.59 724916.07 7.21 479829.74 724923.91 7.21 479829.39 724924.06 7.21 479829.28 724923.84 7.21 479820.5 724927.53 7.21 479820.6 724927.74 7.21 479820.21 724927.89 7.21 479817.04 724920.03 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4B32-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4B32-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.64</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B32-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480137.11 725004.41 3.24 480145.15 725000.71 3.24 480132.7 724973.56 3.24 480124.44 724977.25 3.24 480137.11 725004.41 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B32-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480137.11 725004.41 3.24 480124.44 724977.25 3.24 480124.44 724977.25 8.88 480137.11 725004.41 8.88 480137.11 725004.41 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B32-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480124.44 724977.25 3.24 480132.7 724973.56 3.24 480132.7 724973.56 8.88 480124.44 724977.25 8.88 480124.44 724977.25 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B32-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480132.7 724973.56 3.24 480145.15 725000.71 3.24 480145.15 725000.71 8.88 480132.7 724973.56 8.88 480132.7 724973.56 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B32-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480145.15 725000.71 3.24 480137.11 725004.41 3.24 480137.11 725004.41 8.88 480145.15 725000.71 8.88 480145.15 725000.71 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B32-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480137.11 725004.41 8.88 480124.44 724977.25 8.88 480132.7 724973.56 8.88 480145.15 725000.71 8.88 480137.11 725004.41 8.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4B30-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4B30-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.74</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B30-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480051.38 725339.68 1.92 480057.62 725339.55 1.92 480057.17 725309.39 1.92 480050.98 725309.44 1.92 480051.38 725339.68 1.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B30-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480051.38 725339.68 1.92 480050.98 725309.44 1.92 480050.98 725309.44 6.66 480051.38 725339.68 6.66 480051.38 725339.68 1.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B30-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480050.98 725309.44 1.92 480057.17 725309.39 1.92 480057.17 725309.39 6.66 480050.98 725309.44 6.66 480050.98 725309.44 1.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B30-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480057.17 725309.39 1.92 480057.62 725339.55 1.92 480057.62 725339.55 6.66 480057.17 725309.39 6.66 480057.17 725309.39 1.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B30-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480057.62 725339.55 1.92 480051.38 725339.68 1.92 480051.38 725339.68 6.66 480057.62 725339.55 6.66 480057.62 725339.55 1.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B30-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480051.38 725339.68 6.66 480050.98 725309.44 6.66 480057.17 725309.39 6.66 480057.62 725339.55 6.66 480051.38 725339.68 6.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4C01-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4C01-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C01-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481470.93 724223.71 2.39 481565.01 724148.19 2.39 481526.92 724100.73 2.39 481432.81 724176.21 2.39 481470.8 724223.55 2.39 481470.93 724223.71 2.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C01-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481470.93 724223.71 2.39 481470.8 724223.55 2.39 481470.8 724223.55 11.39 481470.93 724223.71 11.39 481470.93 724223.71 2.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C01-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481470.8 724223.55 2.39 481432.81 724176.21 2.39 481432.81 724176.21 11.39 481470.8 724223.55 11.39 481470.8 724223.55 2.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C01-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481432.81 724176.21 2.39 481526.92 724100.73 2.39 481526.92 724100.73 11.39 481432.81 724176.21 11.39 481432.81 724176.21 2.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C01-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481526.92 724100.73 2.39 481565.01 724148.19 2.39 481565.01 724148.19 11.39 481526.92 724100.73 11.39 481526.92 724100.73 2.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C01-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481565.01 724148.19 2.39 481470.93 724223.71 2.39 481470.93 724223.71 11.39 481565.01 724148.19 11.39 481565.01 724148.19 2.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4C01-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481470.93 724223.71 11.39 481470.8 724223.55 11.39 481432.81 724176.21 11.39 481526.92 724100.73 11.39 481565.01 724148.19 11.39 481470.93 724223.71 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C3FF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C3FF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.2</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3FF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480046.67 724985.91 2.83 480054.64 724982 2.83 480060.13 724979.32 2.83 480070.92 724974.06 2.83 480065.47 724963.34 2.83 480041.25 724975.13 2.83 480046.67 724985.91 2.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3FF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480046.67 724985.91 2.83 480041.25 724975.13 2.83 480041.25 724975.13 9.03 480046.67 724985.91 9.03 480046.67 724985.91 2.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3FF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480041.25 724975.13 2.83 480065.47 724963.34 2.83 480065.47 724963.34 9.03 480041.25 724975.13 9.03 480041.25 724975.13 2.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3FF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480065.47 724963.34 2.83 480070.92 724974.06 2.83 480070.92 724974.06 9.03 480065.47 724963.34 9.03 480065.47 724963.34 2.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3FF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480070.92 724974.06 2.83 480060.13 724979.32 2.83 480060.13 724979.32 9.03 480070.92 724974.06 9.03 480070.92 724974.06 2.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3FF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480060.13 724979.32 2.83 480054.64 724982 2.83 480054.64 724982 9.03 480060.13 724979.32 9.03 480060.13 724979.32 2.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3FF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480054.64 724982 2.83 480046.67 724985.91 2.83 480046.67 724985.91 9.03 480054.64 724982 9.03 480054.64 724982 2.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3FF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480046.67 724985.91 9.03 480041.25 724975.13 9.03 480065.47 724963.34 9.03 480070.92 724974.06 9.03 480060.13 724979.32 9.03 480054.64 724982 9.03 480046.67 724985.91 9.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.62</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480460.37 725638.17 1.95 480456.69 725634.38 1.95 480455.31 725635.7 1.95 480453.32 725637.61 1.95 480452.08 725638.77 1.95 480451.54 725640.66 1.95 480441.15 725637.66 1.95 480437.98 725648.66 1.95 480440.89 725649.49 1.95 480444.35 725650.47 1.95 480446.89 725651.19 1.95 480448.27 725651.57 1.95 480449.39 725651.89 1.95 480454.16 725653.25 1.95 480456.97 725643.29 1.95 480457.24 725642.28 1.95 480457.68 725640.75 1.95 480458.57 725639.9 1.95 480460.37 725638.17 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480460.37 725638.17 1.95 480458.57 725639.9 1.95 480458.57 725639.9 10.57 480460.37 725638.17 10.57 480460.37 725638.17 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480458.57 725639.9 1.95 480457.68 725640.75 1.95 480457.68 725640.75 10.57 480458.57 725639.9 10.57 480458.57 725639.9 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480457.68 725640.75 1.95 480457.24 725642.28 1.95 480457.24 725642.28 10.57 480457.68 725640.75 10.57 480457.68 725640.75 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480457.24 725642.28 1.95 480456.97 725643.29 1.95 480456.97 725643.29 10.57 480457.24 725642.28 10.57 480457.24 725642.28 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480456.97 725643.29 1.95 480454.16 725653.25 1.95 480454.16 725653.25 10.57 480456.97 725643.29 10.57 480456.97 725643.29 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480454.16 725653.25 1.95 480449.39 725651.89 1.95 480449.39 725651.89 10.57 480454.16 725653.25 10.57 480454.16 725653.25 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480449.39 725651.89 1.95 480448.27 725651.57 1.95 480448.27 725651.57 10.57 480449.39 725651.89 10.57 480449.39 725651.89 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480448.27 725651.57 1.95 480446.89 725651.19 1.95 480446.89 725651.19 10.57 480448.27 725651.57 10.57 480448.27 725651.57 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480446.89 725651.19 1.95 480444.35 725650.47 1.95 480444.35 725650.47 10.57 480446.89 725651.19 10.57 480446.89 725651.19 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480444.35 725650.47 1.95 480440.89 725649.49 1.95 480440.89 725649.49 10.57 480444.35 725650.47 10.57 480444.35 725650.47 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480440.89 725649.49 1.95 480437.98 725648.66 1.95 480437.98 725648.66 10.57 480440.89 725649.49 10.57 480440.89 725649.49 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480437.98 725648.66 1.95 480441.15 725637.66 1.95 480441.15 725637.66 10.57 480437.98 725648.66 10.57 480437.98 725648.66 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480441.15 725637.66 1.95 480451.54 725640.66 1.95 480451.54 725640.66 10.57 480441.15 725637.66 10.57 480441.15 725637.66 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480451.54 725640.66 1.95 480452.08 725638.77 1.95 480452.08 725638.77 10.57 480451.54 725640.66 10.57 480451.54 725640.66 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480452.08 725638.77 1.95 480453.32 725637.61 1.95 480453.32 725637.61 10.57 480452.08 725638.77 10.57 480452.08 725638.77 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480453.32 725637.61 1.95 480455.31 725635.7 1.95 480455.31 725635.7 10.57 480453.32 725637.61 10.57 480453.32 725637.61 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480455.31 725635.7 1.95 480456.69 725634.38 1.95 480456.69 725634.38 10.57 480455.31 725635.7 10.57 480455.31 725635.7 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480456.69 725634.38 1.95 480460.37 725638.17 1.95 480460.37 725638.17 10.57 480456.69 725634.38 10.57 480456.69 725634.38 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-77D2-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480460.37 725638.17 10.57 480458.57 725639.9 10.57 480457.68 725640.75 10.57 480457.24 725642.28 10.57 480456.97 725643.29 10.57 480454.16 725653.25 10.57 480449.39 725651.89 10.57 480448.27 725651.57 10.57 480446.89 725651.19 10.57 480444.35 725650.47 10.57 480440.89 725649.49 10.57 480437.98 725648.66 10.57 480441.15 725637.66 10.57 480451.54 725640.66 10.57 480452.08 725638.77 10.57 480453.32 725637.61 10.57 480455.31 725635.7 10.57 480456.69 725634.38 10.57 480460.37 725638.17 10.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-788F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-788F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.58</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-788F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480149.54 725471.24 1.83 480134.51 725467 1.83 480132.34 725474.67 1.83 480147.36 725478.91 1.83 480149.54 725471.24 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-788F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480149.54 725471.24 1.83 480147.36 725478.91 1.83 480147.36 725478.91 8.41 480149.54 725471.24 8.41 480149.54 725471.24 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-788F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480147.36 725478.91 1.83 480132.34 725474.67 1.83 480132.34 725474.67 8.41 480147.36 725478.91 8.41 480147.36 725478.91 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-788F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480132.34 725474.67 1.83 480134.51 725467 1.83 480134.51 725467 8.41 480132.34 725474.67 8.41 480132.34 725474.67 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-788F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480134.51 725467 1.83 480149.54 725471.24 1.83 480149.54 725471.24 8.41 480134.51 725467 8.41 480134.51 725467 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-788F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480149.54 725471.24 8.41 480147.36 725478.91 8.41 480132.34 725474.67 8.41 480134.51 725467 8.41 480149.54 725471.24 8.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">13.38</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.21 725220.32 1.97 480992.51 725220.33 1.97 480992.76 725220.3 1.97 480993.05 725220.28 1.97 480993.32 725220.24 1.97 480993.54 725220.19 1.97 480993.74 725220.17 1.97 480993.99 725220.11 1.97 480994.25 725220.02 1.97 480994.48 725219.96 1.97 480994.72 725219.89 1.97 480995 725219.78 1.97 480995.27 725219.68 1.97 480995.45 725219.59 1.97 480995.67 725219.47 1.97 480995.93 725219.34 1.97 480996.32 725219.09 1.97 480996.72 725218.83 1.97 480997.14 725218.47 1.97 480997.39 725218.25 1.97 480997.66 725217.97 1.97 480997.86 725217.75 1.97 480998.09 725217.47 1.97 480998.26 725217.25 1.97 480998.4 725217.04 1.97 480998.58 725216.73 1.97 480998.75 725216.42 1.97 480998.93 725216.06 1.97 480999.03 725215.81 1.97 480999.42 725214.61 1.97 480999.47 725214.33 1.97 480999.53 725214.06 1.97 480999.57 725213.78 1.97 480999.61 725213.53 1.97 480999.64 725213.27 1.97 480999.64 725213.03 1.97 480999.66 725212.73 1.97 480999.64 725212.43 1.97 480999.63 725212.14 1.97 480999.6 725211.79 1.97 480999.55 725211.49 1.97 480999.51 725211.24 1.97 480999.43 725210.94 1.97 480999.35 725210.66 1.97 480999.28 725210.4 1.97 480999.16 725210.08 1.97 480999.1 725209.91 1.97 480998.97 725209.64 1.97 480998.75 725209.18 1.97 480998.6 725208.92 1.97 480998.32 725208.48 1.97 480998.06 725208.13 1.97 480997.77 725207.76 1.97 480997.37 725207.38 1.97 480996.97 725207 1.97 480996.76 725206.81 1.97 480996.53 725206.67 1.97 480996.21 725206.44 1.97 480995.86 725206.25 1.97 480995.57 725206.07 1.97 480995.28 725205.93 1.97 480994.94 725205.79 1.97 480994.69 725205.68 1.97 480994.44 725205.61 1.97 480994.18 725205.52 1.97 480993.88 725205.45 1.97 480993.65 725205.41 1.97 480993.41 725205.35 1.97 480993.13 725205.31 1.97 480992.87 725205.29 1.97 480992.54 725205.26 1.97 480992.24 725205.25 1.97 480992.01 725205.25 1.97 480991.39 725205.28 1.97 480991 725205.32 1.97 480990.53 725205.39 1.97 480990.12 725205.51 1.97 480989.91 725205.57 1.97 480989.48 725205.71 1.97 480988.99 725205.91 1.97 480988.71 725206.03 1.97 480988.45 725206.16 1.97 480988.29 725206.27 1.97 480988.12 725206.36 1.97 480987.88 725206.54 1.97 480987.52 725206.8 1.97 480987.21 725207.05 1.97 480986.96 725207.28 1.97 480986.67 725207.57 1.97 480986.45 725207.82 1.97 480986.21 725208.09 1.97 480985.89 725208.53 1.97 480985.63 725208.91 1.97 480985.43 725209.28 1.97 480985.24 725209.67 1.97 480985.13 725209.94 1.97 480984.98 725210.33 1.97 480984.89 725210.66 1.97 480984.77 725211.06 1.97 480984.72 725211.41 1.97 480984.66 725211.72 1.97 480984.64 725212.05 1.97 480984.6 725212.35 1.97 480984.61 725212.77 1.97 480984.61 725213.19 1.97 480984.66 725213.61 1.97 480984.7 725214.02 1.97 480984.8 725214.47 1.97 480984.97 725215.03 1.97 480985.06 725215.35 1.97 480985.18 725215.65 1.97 480985.3 725215.93 1.97 480985.41 725216.17 1.97 480985.57 725216.45 1.97 480985.72 725216.71 1.97 480985.94 725217.03 1.97 480986.17 725217.37 1.97 480986.44 725217.71 1.97 480986.66 725217.94 1.97 480986.89 725218.17 1.97 480987.02 725218.3 1.97 480987.29 725218.55 1.97 480987.47 725218.71 1.97 480987.7 725218.88 1.97 480987.99 725219.08 1.97 480988.3 725219.28 1.97 480988.58 725219.41 1.97 480988.92 725219.6 1.97 480989.21 725219.73 1.97 480989.51 725219.85 1.97 480990.16 725220.04 1.97 480990.49 725220.13 1.97 480990.65 725220.15 1.97 480990.83 725220.19 1.97 480991.04 725220.23 1.97 480991.27 725220.25 1.97 480991.46 725220.27 1.97 480991.71 725220.29 1.97 480992.21 725220.32 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.21 725220.32 1.97 480991.71 725220.29 1.97 480991.71 725220.29 15.35 480992.21 725220.32 15.35 480992.21 725220.32 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.71 725220.29 1.97 480991.46 725220.27 1.97 480991.46 725220.27 15.35 480991.71 725220.29 15.35 480991.71 725220.29 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.46 725220.27 1.97 480991.27 725220.25 1.97 480991.27 725220.25 15.35 480991.46 725220.27 15.35 480991.46 725220.27 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.27 725220.25 1.97 480991.04 725220.23 1.97 480991.04 725220.23 15.35 480991.27 725220.25 15.35 480991.27 725220.25 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.04 725220.23 1.97 480990.83 725220.19 1.97 480990.83 725220.19 15.35 480991.04 725220.23 15.35 480991.04 725220.23 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.83 725220.19 1.97 480990.65 725220.15 1.97 480990.65 725220.15 15.35 480990.83 725220.19 15.35 480990.83 725220.19 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.65 725220.15 1.97 480990.49 725220.13 1.97 480990.49 725220.13 15.35 480990.65 725220.15 15.35 480990.65 725220.15 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.49 725220.13 1.97 480990.16 725220.04 1.97 480990.16 725220.04 15.35 480990.49 725220.13 15.35 480990.49 725220.13 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.16 725220.04 1.97 480989.51 725219.85 1.97 480989.51 725219.85 15.35 480990.16 725220.04 15.35 480990.16 725220.04 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480989.51 725219.85 1.97 480989.21 725219.73 1.97 480989.21 725219.73 15.35 480989.51 725219.85 15.35 480989.51 725219.85 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480989.21 725219.73 1.97 480988.92 725219.6 1.97 480988.92 725219.6 15.35 480989.21 725219.73 15.35 480989.21 725219.73 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.92 725219.6 1.97 480988.58 725219.41 1.97 480988.58 725219.41 15.35 480988.92 725219.6 15.35 480988.92 725219.6 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.58 725219.41 1.97 480988.3 725219.28 1.97 480988.3 725219.28 15.35 480988.58 725219.41 15.35 480988.58 725219.41 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.3 725219.28 1.97 480987.99 725219.08 1.97 480987.99 725219.08 15.35 480988.3 725219.28 15.35 480988.3 725219.28 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.99 725219.08 1.97 480987.7 725218.88 1.97 480987.7 725218.88 15.35 480987.99 725219.08 15.35 480987.99 725219.08 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.7 725218.88 1.97 480987.47 725218.71 1.97 480987.47 725218.71 15.35 480987.7 725218.88 15.35 480987.7 725218.88 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.47 725218.71 1.97 480987.29 725218.55 1.97 480987.29 725218.55 15.35 480987.47 725218.71 15.35 480987.47 725218.71 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.29 725218.55 1.97 480987.02 725218.3 1.97 480987.02 725218.3 15.35 480987.29 725218.55 15.35 480987.29 725218.55 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.02 725218.3 1.97 480986.89 725218.17 1.97 480986.89 725218.17 15.35 480987.02 725218.3 15.35 480987.02 725218.3 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.89 725218.17 1.97 480986.66 725217.94 1.97 480986.66 725217.94 15.35 480986.89 725218.17 15.35 480986.89 725218.17 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.66 725217.94 1.97 480986.44 725217.71 1.97 480986.44 725217.71 15.35 480986.66 725217.94 15.35 480986.66 725217.94 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.44 725217.71 1.97 480986.17 725217.37 1.97 480986.17 725217.37 15.35 480986.44 725217.71 15.35 480986.44 725217.71 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.17 725217.37 1.97 480985.94 725217.03 1.97 480985.94 725217.03 15.35 480986.17 725217.37 15.35 480986.17 725217.37 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.94 725217.03 1.97 480985.72 725216.71 1.97 480985.72 725216.71 15.35 480985.94 725217.03 15.35 480985.94 725217.03 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.72 725216.71 1.97 480985.57 725216.45 1.97 480985.57 725216.45 15.35 480985.72 725216.71 15.35 480985.72 725216.71 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.57 725216.45 1.97 480985.41 725216.17 1.97 480985.41 725216.17 15.35 480985.57 725216.45 15.35 480985.57 725216.45 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.41 725216.17 1.97 480985.3 725215.93 1.97 480985.3 725215.93 15.35 480985.41 725216.17 15.35 480985.41 725216.17 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.3 725215.93 1.97 480985.18 725215.65 1.97 480985.18 725215.65 15.35 480985.3 725215.93 15.35 480985.3 725215.93 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.18 725215.65 1.97 480985.06 725215.35 1.97 480985.06 725215.35 15.35 480985.18 725215.65 15.35 480985.18 725215.65 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.06 725215.35 1.97 480984.97 725215.03 1.97 480984.97 725215.03 15.35 480985.06 725215.35 15.35 480985.06 725215.35 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.97 725215.03 1.97 480984.8 725214.47 1.97 480984.8 725214.47 15.35 480984.97 725215.03 15.35 480984.97 725215.03 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.8 725214.47 1.97 480984.7 725214.02 1.97 480984.7 725214.02 15.35 480984.8 725214.47 15.35 480984.8 725214.47 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.7 725214.02 1.97 480984.66 725213.61 1.97 480984.66 725213.61 15.35 480984.7 725214.02 15.35 480984.7 725214.02 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.66 725213.61 1.97 480984.61 725213.19 1.97 480984.61 725213.19 15.35 480984.66 725213.61 15.35 480984.66 725213.61 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.61 725213.19 1.97 480984.61 725212.77 1.97 480984.61 725212.77 15.35 480984.61 725213.19 15.35 480984.61 725213.19 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.61 725212.77 1.97 480984.6 725212.35 1.97 480984.6 725212.35 15.35 480984.61 725212.77 15.35 480984.61 725212.77 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.6 725212.35 1.97 480984.64 725212.05 1.97 480984.64 725212.05 15.35 480984.6 725212.35 15.35 480984.6 725212.35 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.64 725212.05 1.97 480984.66 725211.72 1.97 480984.66 725211.72 15.35 480984.64 725212.05 15.35 480984.64 725212.05 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.66 725211.72 1.97 480984.72 725211.41 1.97 480984.72 725211.41 15.35 480984.66 725211.72 15.35 480984.66 725211.72 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.72 725211.41 1.97 480984.77 725211.06 1.97 480984.77 725211.06 15.35 480984.72 725211.41 15.35 480984.72 725211.41 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.77 725211.06 1.97 480984.89 725210.66 1.97 480984.89 725210.66 15.35 480984.77 725211.06 15.35 480984.77 725211.06 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.89 725210.66 1.97 480984.98 725210.33 1.97 480984.98 725210.33 15.35 480984.89 725210.66 15.35 480984.89 725210.66 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480984.98 725210.33 1.97 480985.13 725209.94 1.97 480985.13 725209.94 15.35 480984.98 725210.33 15.35 480984.98 725210.33 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.13 725209.94 1.97 480985.24 725209.67 1.97 480985.24 725209.67 15.35 480985.13 725209.94 15.35 480985.13 725209.94 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.24 725209.67 1.97 480985.43 725209.28 1.97 480985.43 725209.28 15.35 480985.24 725209.67 15.35 480985.24 725209.67 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.43 725209.28 1.97 480985.63 725208.91 1.97 480985.63 725208.91 15.35 480985.43 725209.28 15.35 480985.43 725209.28 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.63 725208.91 1.97 480985.89 725208.53 1.97 480985.89 725208.53 15.35 480985.63 725208.91 15.35 480985.63 725208.91 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480985.89 725208.53 1.97 480986.21 725208.09 1.97 480986.21 725208.09 15.35 480985.89 725208.53 15.35 480985.89 725208.53 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.21 725208.09 1.97 480986.45 725207.82 1.97 480986.45 725207.82 15.35 480986.21 725208.09 15.35 480986.21 725208.09 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.45 725207.82 1.97 480986.67 725207.57 1.97 480986.67 725207.57 15.35 480986.45 725207.82 15.35 480986.45 725207.82 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.67 725207.57 1.97 480986.96 725207.28 1.97 480986.96 725207.28 15.35 480986.67 725207.57 15.35 480986.67 725207.57 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480986.96 725207.28 1.97 480987.21 725207.05 1.97 480987.21 725207.05 15.35 480986.96 725207.28 15.35 480986.96 725207.28 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.21 725207.05 1.97 480987.52 725206.8 1.97 480987.52 725206.8 15.35 480987.21 725207.05 15.35 480987.21 725207.05 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.52 725206.8 1.97 480987.88 725206.54 1.97 480987.88 725206.54 15.35 480987.52 725206.8 15.35 480987.52 725206.8 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480987.88 725206.54 1.97 480988.12 725206.36 1.97 480988.12 725206.36 15.35 480987.88 725206.54 15.35 480987.88 725206.54 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.12 725206.36 1.97 480988.29 725206.27 1.97 480988.29 725206.27 15.35 480988.12 725206.36 15.35 480988.12 725206.36 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.29 725206.27 1.97 480988.45 725206.16 1.97 480988.45 725206.16 15.35 480988.29 725206.27 15.35 480988.29 725206.27 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.45 725206.16 1.97 480988.71 725206.03 1.97 480988.71 725206.03 15.35 480988.45 725206.16 15.35 480988.45 725206.16 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.71 725206.03 1.97 480988.99 725205.91 1.97 480988.99 725205.91 15.35 480988.71 725206.03 15.35 480988.71 725206.03 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480988.99 725205.91 1.97 480989.48 725205.71 1.97 480989.48 725205.71 15.35 480988.99 725205.91 15.35 480988.99 725205.91 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480989.48 725205.71 1.97 480989.91 725205.57 1.97 480989.91 725205.57 15.35 480989.48 725205.71 15.35 480989.48 725205.71 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480989.91 725205.57 1.97 480990.12 725205.51 1.97 480990.12 725205.51 15.35 480989.91 725205.57 15.35 480989.91 725205.57 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.12 725205.51 1.97 480990.53 725205.39 1.97 480990.53 725205.39 15.35 480990.12 725205.51 15.35 480990.12 725205.51 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480990.53 725205.39 1.97 480991 725205.32 1.97 480991 725205.32 15.35 480990.53 725205.39 15.35 480990.53 725205.39 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991 725205.32 1.97 480991.39 725205.28 1.97 480991.39 725205.28 15.35 480991 725205.32 15.35 480991 725205.32 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480991.39 725205.28 1.97 480992.01 725205.25 1.97 480992.01 725205.25 15.35 480991.39 725205.28 15.35 480991.39 725205.28 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.01 725205.25 1.97 480992.24 725205.25 1.97 480992.24 725205.25 15.35 480992.01 725205.25 15.35 480992.01 725205.25 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.24 725205.25 1.97 480992.54 725205.26 1.97 480992.54 725205.26 15.35 480992.24 725205.25 15.35 480992.24 725205.25 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.54 725205.26 1.97 480992.87 725205.29 1.97 480992.87 725205.29 15.35 480992.54 725205.26 15.35 480992.54 725205.26 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.87 725205.29 1.97 480993.13 725205.31 1.97 480993.13 725205.31 15.35 480992.87 725205.29 15.35 480992.87 725205.29 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_72">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480993.13 725205.31 1.97 480993.41 725205.35 1.97 480993.41 725205.35 15.35 480993.13 725205.31 15.35 480993.13 725205.31 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480993.41 725205.35 1.97 480993.65 725205.41 1.97 480993.65 725205.41 15.35 480993.41 725205.35 15.35 480993.41 725205.35 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_74">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480993.65 725205.41 1.97 480993.88 725205.45 1.97 480993.88 725205.45 15.35 480993.65 725205.41 15.35 480993.65 725205.41 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_75">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480993.88 725205.45 1.97 480994.18 725205.52 1.97 480994.18 725205.52 15.35 480993.88 725205.45 15.35 480993.88 725205.45 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_76">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480994.18 725205.52 1.97 480994.44 725205.61 1.97 480994.44 725205.61 15.35 480994.18 725205.52 15.35 480994.18 725205.52 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_77">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480994.44 725205.61 1.97 480994.69 725205.68 1.97 480994.69 725205.68 15.35 480994.44 725205.61 15.35 480994.44 725205.61 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_78">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480994.69 725205.68 1.97 480994.94 725205.79 1.97 480994.94 725205.79 15.35 480994.69 725205.68 15.35 480994.69 725205.68 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_79">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480994.94 725205.79 1.97 480995.28 725205.93 1.97 480995.28 725205.93 15.35 480994.94 725205.79 15.35 480994.94 725205.79 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480995.28 725205.93 1.97 480995.57 725206.07 1.97 480995.57 725206.07 15.35 480995.28 725205.93 15.35 480995.28 725205.93 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_81">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480995.57 725206.07 1.97 480995.86 725206.25 1.97 480995.86 725206.25 15.35 480995.57 725206.07 15.35 480995.57 725206.07 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_82">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480995.86 725206.25 1.97 480996.21 725206.44 1.97 480996.21 725206.44 15.35 480995.86 725206.25 15.35 480995.86 725206.25 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_83">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480996.21 725206.44 1.97 480996.53 725206.67 1.97 480996.53 725206.67 15.35 480996.21 725206.44 15.35 480996.21 725206.44 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_84">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480996.53 725206.67 1.97 480996.76 725206.81 1.97 480996.76 725206.81 15.35 480996.53 725206.67 15.35 480996.53 725206.67 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_85">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480996.76 725206.81 1.97 480996.97 725207 1.97 480996.97 725207 15.35 480996.76 725206.81 15.35 480996.76 725206.81 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_86">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480996.97 725207 1.97 480997.37 725207.38 1.97 480997.37 725207.38 15.35 480996.97 725207 15.35 480996.97 725207 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_87">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480997.37 725207.38 1.97 480997.77 725207.76 1.97 480997.77 725207.76 15.35 480997.37 725207.38 15.35 480997.37 725207.38 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_88">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480997.77 725207.76 1.97 480998.06 725208.13 1.97 480998.06 725208.13 15.35 480997.77 725207.76 15.35 480997.77 725207.76 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_89">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480998.06 725208.13 1.97 480998.32 725208.48 1.97 480998.32 725208.48 15.35 480998.06 725208.13 15.35 480998.06 725208.13 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_90">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480998.32 725208.48 1.97 480998.6 725208.92 1.97 480998.6 725208.92 15.35 480998.32 725208.48 15.35 480998.32 725208.48 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480998.6 725208.92 1.97 480998.75 725209.18 1.97 480998.75 725209.18 15.35 480998.6 725208.92 15.35 480998.6 725208.92 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_92">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480998.75 725209.18 1.97 480998.97 725209.64 1.97 480998.97 725209.64 15.35 480998.75 725209.18 15.35 480998.75 725209.18 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_93">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480998.97 725209.64 1.97 480999.1 725209.91 1.97 480999.1 725209.91 15.35 480998.97 725209.64 15.35 480998.97 725209.64 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_94">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.1 725209.91 1.97 480999.16 725210.08 1.97 480999.16 725210.08 15.35 480999.1 725209.91 15.35 480999.1 725209.91 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_95">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.16 725210.08 1.97 480999.28 725210.4 1.97 480999.28 725210.4 15.35 480999.16 725210.08 15.35 480999.16 725210.08 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_96">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.28 725210.4 1.97 480999.35 725210.66 1.97 480999.35 725210.66 15.35 480999.28 725210.4 15.35 480999.28 725210.4 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_97">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.35 725210.66 1.97 480999.43 725210.94 1.97 480999.43 725210.94 15.35 480999.35 725210.66 15.35 480999.35 725210.66 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_98">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.43 725210.94 1.97 480999.51 725211.24 1.97 480999.51 725211.24 15.35 480999.43 725210.94 15.35 480999.43 725210.94 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_99">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.51 725211.24 1.97 480999.55 725211.49 1.97 480999.55 725211.49 15.35 480999.51 725211.24 15.35 480999.51 725211.24 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_100">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.55 725211.49 1.97 480999.6 725211.79 1.97 480999.6 725211.79 15.35 480999.55 725211.49 15.35 480999.55 725211.49 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_101">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.6 725211.79 1.97 480999.63 725212.14 1.97 480999.63 725212.14 15.35 480999.6 725211.79 15.35 480999.6 725211.79 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_102">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.63 725212.14 1.97 480999.64 725212.43 1.97 480999.64 725212.43 15.35 480999.63 725212.14 15.35 480999.63 725212.14 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_103">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.64 725212.43 1.97 480999.66 725212.73 1.97 480999.66 725212.73 15.35 480999.64 725212.43 15.35 480999.64 725212.43 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_104">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.66 725212.73 1.97 480999.64 725213.03 1.97 480999.64 725213.03 15.35 480999.66 725212.73 15.35 480999.66 725212.73 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_105">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.64 725213.03 1.97 480999.64 725213.27 1.97 480999.64 725213.27 15.35 480999.64 725213.03 15.35 480999.64 725213.03 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_106">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.64 725213.27 1.97 480999.61 725213.53 1.97 480999.61 725213.53 15.35 480999.64 725213.27 15.35 480999.64 725213.27 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_107">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.61 725213.53 1.97 480999.57 725213.78 1.97 480999.57 725213.78 15.35 480999.61 725213.53 15.35 480999.61 725213.53 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_108">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.57 725213.78 1.97 480999.53 725214.06 1.97 480999.53 725214.06 15.35 480999.57 725213.78 15.35 480999.57 725213.78 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_109">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.53 725214.06 1.97 480999.47 725214.33 1.97 480999.47 725214.33 15.35 480999.53 725214.06 15.35 480999.53 725214.06 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_110">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.47 725214.33 1.97 480999.42 725214.61 1.97 480999.42 725214.61 15.35 480999.47 725214.33 15.35 480999.47 725214.33 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_111">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.42 725214.61 1.97 480999.03 725215.81 1.97 480999.03 725215.81 15.35 480999.42 725214.61 15.35 480999.42 725214.61 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_112">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480999.03 725215.81 1.97 480998.93 725216.06 1.97 480998.93 725216.06 15.35 480999.03 725215.81 15.35 480999.03 725215.81 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_113">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480998.93 725216.06 1.97 480998.75 725216.42 1.97 480998.75 725216.42 15.35 480998.93 725216.06 15.35 480998.93 725216.06 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_114">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480998.75 725216.42 1.97 480998.58 725216.73 1.97 480998.58 725216.73 15.35 480998.75 725216.42 15.35 480998.75 725216.42 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_115">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480998.58 725216.73 1.97 480998.4 725217.04 1.97 480998.4 725217.04 15.35 480998.58 725216.73 15.35 480998.58 725216.73 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_116">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480998.4 725217.04 1.97 480998.26 725217.25 1.97 480998.26 725217.25 15.35 480998.4 725217.04 15.35 480998.4 725217.04 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_117">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480998.26 725217.25 1.97 480998.09 725217.47 1.97 480998.09 725217.47 15.35 480998.26 725217.25 15.35 480998.26 725217.25 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_118">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480998.09 725217.47 1.97 480997.86 725217.75 1.97 480997.86 725217.75 15.35 480998.09 725217.47 15.35 480998.09 725217.47 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_119">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480997.86 725217.75 1.97 480997.66 725217.97 1.97 480997.66 725217.97 15.35 480997.86 725217.75 15.35 480997.86 725217.75 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_120">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480997.66 725217.97 1.97 480997.39 725218.25 1.97 480997.39 725218.25 15.35 480997.66 725217.97 15.35 480997.66 725217.97 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_121">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480997.39 725218.25 1.97 480997.14 725218.47 1.97 480997.14 725218.47 15.35 480997.39 725218.25 15.35 480997.39 725218.25 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_122">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480997.14 725218.47 1.97 480996.72 725218.83 1.97 480996.72 725218.83 15.35 480997.14 725218.47 15.35 480997.14 725218.47 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_123">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480996.72 725218.83 1.97 480996.32 725219.09 1.97 480996.32 725219.09 15.35 480996.72 725218.83 15.35 480996.72 725218.83 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_124">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480996.32 725219.09 1.97 480995.93 725219.34 1.97 480995.93 725219.34 15.35 480996.32 725219.09 15.35 480996.32 725219.09 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_125">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480995.93 725219.34 1.97 480995.67 725219.47 1.97 480995.67 725219.47 15.35 480995.93 725219.34 15.35 480995.93 725219.34 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_126">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480995.67 725219.47 1.97 480995.45 725219.59 1.97 480995.45 725219.59 15.35 480995.67 725219.47 15.35 480995.67 725219.47 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_127">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480995.45 725219.59 1.97 480995.27 725219.68 1.97 480995.27 725219.68 15.35 480995.45 725219.59 15.35 480995.45 725219.59 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_128">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480995.27 725219.68 1.97 480995 725219.78 1.97 480995 725219.78 15.35 480995.27 725219.68 15.35 480995.27 725219.68 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_129">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480995 725219.78 1.97 480994.72 725219.89 1.97 480994.72 725219.89 15.35 480995 725219.78 15.35 480995 725219.78 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_130">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480994.72 725219.89 1.97 480994.48 725219.96 1.97 480994.48 725219.96 15.35 480994.72 725219.89 15.35 480994.72 725219.89 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_131">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480994.48 725219.96 1.97 480994.25 725220.02 1.97 480994.25 725220.02 15.35 480994.48 725219.96 15.35 480994.48 725219.96 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_132">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480994.25 725220.02 1.97 480993.99 725220.11 1.97 480993.99 725220.11 15.35 480994.25 725220.02 15.35 480994.25 725220.02 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_133">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480993.99 725220.11 1.97 480993.74 725220.17 1.97 480993.74 725220.17 15.35 480993.99 725220.11 15.35 480993.99 725220.11 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_134">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480993.74 725220.17 1.97 480993.54 725220.19 1.97 480993.54 725220.19 15.35 480993.74 725220.17 15.35 480993.74 725220.17 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_135">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480993.54 725220.19 1.97 480993.32 725220.24 1.97 480993.32 725220.24 15.35 480993.54 725220.19 15.35 480993.54 725220.19 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_136">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480993.32 725220.24 1.97 480993.05 725220.28 1.97 480993.05 725220.28 15.35 480993.32 725220.24 15.35 480993.32 725220.24 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_137">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480993.05 725220.28 1.97 480992.76 725220.3 1.97 480992.76 725220.3 15.35 480993.05 725220.28 15.35 480993.05 725220.28 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_138">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.76 725220.3 1.97 480992.51 725220.33 1.97 480992.51 725220.33 15.35 480992.76 725220.3 15.35 480992.76 725220.3 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_139">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.51 725220.33 1.97 480992.21 725220.32 1.97 480992.21 725220.32 15.35 480992.51 725220.33 15.35 480992.51 725220.33 1.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-78D9-FAF6-E053-CA2BA8C0FAE4_PG_140">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480992.21 725220.32 15.35 480991.71 725220.29 15.35 480991.46 725220.27 15.35 480991.27 725220.25 15.35 480991.04 725220.23 15.35 480990.83 725220.19 15.35 480990.65 725220.15 15.35 480990.49 725220.13 15.35 480990.16 725220.04 15.35 480989.51 725219.85 15.35 480989.21 725219.73 15.35 480988.92 725219.6 15.35 480988.58 725219.41 15.35 480988.3 725219.28 15.35 480987.99 725219.08 15.35 480987.7 725218.88 15.35 480987.47 725218.71 15.35 480987.29 725218.55 15.35 480987.02 725218.3 15.35 480986.89 725218.17 15.35 480986.66 725217.94 15.35 480986.44 725217.71 15.35 480986.17 725217.37 15.35 480985.94 725217.03 15.35 480985.72 725216.71 15.35 480985.57 725216.45 15.35 480985.41 725216.17 15.35 480985.3 725215.93 15.35 480985.18 725215.65 15.35 480985.06 725215.35 15.35 480984.97 725215.03 15.35 480984.8 725214.47 15.35 480984.7 725214.02 15.35 480984.66 725213.61 15.35 480984.61 725213.19 15.35 480984.61 725212.77 15.35 480984.6 725212.35 15.35 480984.64 725212.05 15.35 480984.66 725211.72 15.35 480984.72 725211.41 15.35 480984.77 725211.06 15.35 480984.89 725210.66 15.35 480984.98 725210.33 15.35 480985.13 725209.94 15.35 480985.24 725209.67 15.35 480985.43 725209.28 15.35 480985.63 725208.91 15.35 480985.89 725208.53 15.35 480986.21 725208.09 15.35 480986.45 725207.82 15.35 480986.67 725207.57 15.35 480986.96 725207.28 15.35 480987.21 725207.05 15.35 480987.52 725206.8 15.35 480987.88 725206.54 15.35 480988.12 725206.36 15.35 480988.29 725206.27 15.35 480988.45 725206.16 15.35 480988.71 725206.03 15.35 480988.99 725205.91 15.35 480989.48 725205.71 15.35 480989.91 725205.57 15.35 480990.12 725205.51 15.35 480990.53 725205.39 15.35 480991 725205.32 15.35 480991.39 725205.28 15.35 480992.01 725205.25 15.35 480992.24 725205.25 15.35 480992.54 725205.26 15.35 480992.87 725205.29 15.35 480993.13 725205.31 15.35 480993.41 725205.35 15.35 480993.65 725205.41 15.35 480993.88 725205.45 15.35 480994.18 725205.52 15.35 480994.44 725205.61 15.35 480994.69 725205.68 15.35 480994.94 725205.79 15.35 480995.28 725205.93 15.35 480995.57 725206.07 15.35 480995.86 725206.25 15.35 480996.21 725206.44 15.35 480996.53 725206.67 15.35 480996.76 725206.81 15.35 480996.97 725207 15.35 480997.37 725207.38 15.35 480997.77 725207.76 15.35 480998.06 725208.13 15.35 480998.32 725208.48 15.35 480998.6 725208.92 15.35 480998.75 725209.18 15.35 480998.97 725209.64 15.35 480999.1 725209.91 15.35 480999.16 725210.08 15.35 480999.28 725210.4 15.35 480999.35 725210.66 15.35 480999.43 725210.94 15.35 480999.51 725211.24 15.35 480999.55 725211.49 15.35 480999.6 725211.79 15.35 480999.63 725212.14 15.35 480999.64 725212.43 15.35 480999.66 725212.73 15.35 480999.64 725213.03 15.35 480999.64 725213.27 15.35 480999.61 725213.53 15.35 480999.57 725213.78 15.35 480999.53 725214.06 15.35 480999.47 725214.33 15.35 480999.42 725214.61 15.35 480999.03 725215.81 15.35 480998.93 725216.06 15.35 480998.75 725216.42 15.35 480998.58 725216.73 15.35 480998.4 725217.04 15.35 480998.26 725217.25 15.35 480998.09 725217.47 15.35 480997.86 725217.75 15.35 480997.66 725217.97 15.35 480997.39 725218.25 15.35 480997.14 725218.47 15.35 480996.72 725218.83 15.35 480996.32 725219.09 15.35 480995.93 725219.34 15.35 480995.67 725219.47 15.35 480995.45 725219.59 15.35 480995.27 725219.68 15.35 480995 725219.78 15.35 480994.72 725219.89 15.35 480994.48 725219.96 15.35 480994.25 725220.02 15.35 480993.99 725220.11 15.35 480993.74 725220.17 15.35 480993.54 725220.19 15.35 480993.32 725220.24 15.35 480993.05 725220.28 15.35 480992.76 725220.3 15.35 480992.51 725220.33 15.35 480992.21 725220.32 15.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-794C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.2</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480722.34 725760.77 1.78 480722.23 725760.74 1.78 480723.29 725756.73 1.78 480711.76 725753.56 1.78 480711.78 725753.44 1.78 480711.51 725753.37 1.78 480710.71 725753.15 1.78 480708.78 725752.63 1.78 480708.46 725752.53 1.78 480704.89 725765.49 1.78 480705.39 725765.62 1.78 480715.4 725768.35 1.78 480719.94 725769.6 1.78 480721.78 725762.85 1.78 480722.3 725760.9 1.78 480722.34 725760.77 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480722.34 725760.77 1.78 480722.3 725760.9 1.78 480722.3 725760.9 6.98 480722.34 725760.77 6.98 480722.34 725760.77 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480722.3 725760.9 1.78 480721.78 725762.85 1.78 480721.78 725762.85 6.98 480722.3 725760.9 6.98 480722.3 725760.9 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480721.78 725762.85 1.78 480719.94 725769.6 1.78 480719.94 725769.6 6.98 480721.78 725762.85 6.98 480721.78 725762.85 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480719.94 725769.6 1.78 480715.4 725768.35 1.78 480715.4 725768.35 6.98 480719.94 725769.6 6.98 480719.94 725769.6 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480715.4 725768.35 1.78 480705.39 725765.62 1.78 480705.39 725765.62 6.98 480715.4 725768.35 6.98 480715.4 725768.35 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480705.39 725765.62 1.78 480704.89 725765.49 1.78 480704.89 725765.49 6.98 480705.39 725765.62 6.98 480705.39 725765.62 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480704.89 725765.49 1.78 480708.46 725752.53 1.78 480708.46 725752.53 6.98 480704.89 725765.49 6.98 480704.89 725765.49 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480708.46 725752.53 1.78 480708.78 725752.63 1.78 480708.78 725752.63 6.98 480708.46 725752.53 6.98 480708.46 725752.53 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480708.78 725752.63 1.78 480710.71 725753.15 1.78 480710.71 725753.15 6.98 480708.78 725752.63 6.98 480708.78 725752.63 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480710.71 725753.15 1.78 480711.51 725753.37 1.78 480711.51 725753.37 6.98 480710.71 725753.15 6.98 480710.71 725753.15 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480711.51 725753.37 1.78 480711.78 725753.44 1.78 480711.78 725753.44 6.98 480711.51 725753.37 6.98 480711.51 725753.37 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480711.78 725753.44 1.78 480711.76 725753.56 1.78 480711.76 725753.56 6.98 480711.78 725753.44 6.98 480711.78 725753.44 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480711.76 725753.56 1.78 480723.29 725756.73 1.78 480723.29 725756.73 6.98 480711.76 725753.56 6.98 480711.76 725753.56 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480723.29 725756.73 1.78 480722.23 725760.74 1.78 480722.23 725760.74 6.98 480723.29 725756.73 6.98 480723.29 725756.73 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480722.23 725760.74 1.78 480722.34 725760.77 1.78 480722.34 725760.77 6.98 480722.23 725760.74 6.98 480722.23 725760.74 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794C-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480722.34 725760.77 6.98 480722.3 725760.9 6.98 480721.78 725762.85 6.98 480719.94 725769.6 6.98 480715.4 725768.35 6.98 480705.39 725765.62 6.98 480704.89 725765.49 6.98 480708.46 725752.53 6.98 480708.78 725752.63 6.98 480710.71 725753.15 6.98 480711.51 725753.37 6.98 480711.78 725753.44 6.98 480711.76 725753.56 6.98 480723.29 725756.73 6.98 480722.23 725760.74 6.98 480722.34 725760.77 6.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7899-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.98</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480797.75 725772.78 1.3 480794.55 725771.86 1.3 480792.72 725771.32 1.3 480788.89 725770.23 1.3 480787.49 725775.03 1.3 480787.3 725774.97 1.3 480784.61 725784.28 1.3 480793.96 725786.99 1.3 480796.61 725777.67 1.3 480796.37 725777.59 1.3 480797.75 725772.78 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480797.75 725772.78 1.3 480796.37 725777.59 1.3 480796.37 725777.59 8.28 480797.75 725772.78 8.28 480797.75 725772.78 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480796.37 725777.59 1.3 480796.61 725777.67 1.3 480796.61 725777.67 8.28 480796.37 725777.59 8.28 480796.37 725777.59 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480796.61 725777.67 1.3 480793.96 725786.99 1.3 480793.96 725786.99 8.28 480796.61 725777.67 8.28 480796.61 725777.67 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480793.96 725786.99 1.3 480784.61 725784.28 1.3 480784.61 725784.28 8.28 480793.96 725786.99 8.28 480793.96 725786.99 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480784.61 725784.28 1.3 480787.3 725774.97 1.3 480787.3 725774.97 8.28 480784.61 725784.28 8.28 480784.61 725784.28 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480787.3 725774.97 1.3 480787.49 725775.03 1.3 480787.49 725775.03 8.28 480787.3 725774.97 8.28 480787.3 725774.97 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480787.49 725775.03 1.3 480788.89 725770.23 1.3 480788.89 725770.23 8.28 480787.49 725775.03 8.28 480787.49 725775.03 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480788.89 725770.23 1.3 480792.72 725771.32 1.3 480792.72 725771.32 8.28 480788.89 725770.23 8.28 480788.89 725770.23 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480792.72 725771.32 1.3 480794.55 725771.86 1.3 480794.55 725771.86 8.28 480792.72 725771.32 8.28 480792.72 725771.32 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480794.55 725771.86 1.3 480797.75 725772.78 1.3 480797.75 725772.78 8.28 480794.55 725771.86 8.28 480794.55 725771.86 1.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7899-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480797.75 725772.78 8.28 480796.37 725777.59 8.28 480796.61 725777.67 8.28 480793.96 725786.99 8.28 480784.61 725784.28 8.28 480787.3 725774.97 8.28 480787.49 725775.03 8.28 480788.89 725770.23 8.28 480792.72 725771.32 8.28 480794.55 725771.86 8.28 480797.75 725772.78 8.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7898-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7898-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.77</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7898-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480429.1 725680.18 2.34 480423.1 725700.9 2.34 480433.53 725703.89 2.34 480439.49 725683.15 2.34 480429.1 725680.18 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7898-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480429.1 725680.18 2.34 480439.49 725683.15 2.34 480439.49 725683.15 6.11 480429.1 725680.18 6.11 480429.1 725680.18 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7898-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480439.49 725683.15 2.34 480433.53 725703.89 2.34 480433.53 725703.89 6.11 480439.49 725683.15 6.11 480439.49 725683.15 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7898-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480433.53 725703.89 2.34 480423.1 725700.9 2.34 480423.1 725700.9 6.11 480433.53 725703.89 6.11 480433.53 725703.89 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7898-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480423.1 725700.9 2.34 480429.1 725680.18 2.34 480429.1 725680.18 6.11 480423.1 725700.9 6.11 480423.1 725700.9 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7898-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480429.1 725680.18 6.11 480439.49 725683.15 6.11 480433.53 725703.89 6.11 480423.1 725700.9 6.11 480429.1 725680.18 6.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.7</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480236.98 724818.33 2.53 480235.5 724817.52 2.53 480229.71 724827.84 2.53 480242.38 724834.86 2.53 480247.92 724825.09 2.53 480249.58 724826.02 2.53 480251.21 724822.97 2.53 480252.57 724823.72 2.53 480257.79 724814.39 2.53 480243.65 724806.46 2.53 480236.98 724818.33 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480236.98 724818.33 2.53 480243.65 724806.46 2.53 480243.65 724806.46 9.23 480236.98 724818.33 9.23 480236.98 724818.33 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480243.65 724806.46 2.53 480257.79 724814.39 2.53 480257.79 724814.39 9.23 480243.65 724806.46 9.23 480243.65 724806.46 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480257.79 724814.39 2.53 480252.57 724823.72 2.53 480252.57 724823.72 9.23 480257.79 724814.39 9.23 480257.79 724814.39 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480252.57 724823.72 2.53 480251.21 724822.97 2.53 480251.21 724822.97 9.23 480252.57 724823.72 9.23 480252.57 724823.72 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480251.21 724822.97 2.53 480249.58 724826.02 2.53 480249.58 724826.02 9.23 480251.21 724822.97 9.23 480251.21 724822.97 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480249.58 724826.02 2.53 480247.92 724825.09 2.53 480247.92 724825.09 9.23 480249.58 724826.02 9.23 480249.58 724826.02 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480247.92 724825.09 2.53 480242.38 724834.86 2.53 480242.38 724834.86 9.23 480247.92 724825.09 9.23 480247.92 724825.09 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480242.38 724834.86 2.53 480229.71 724827.84 2.53 480229.71 724827.84 9.23 480242.38 724834.86 9.23 480242.38 724834.86 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480229.71 724827.84 2.53 480235.5 724817.52 2.53 480235.5 724817.52 9.23 480229.71 724827.84 9.23 480229.71 724827.84 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480235.5 724817.52 2.53 480236.98 724818.33 2.53 480236.98 724818.33 9.23 480235.5 724817.52 9.23 480235.5 724817.52 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BF-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480236.98 724818.33 9.23 480243.65 724806.46 9.23 480257.79 724814.39 9.23 480252.57 724823.72 9.23 480251.21 724822.97 9.23 480249.58 724826.02 9.23 480247.92 724825.09 9.23 480242.38 724834.86 9.23 480229.71 724827.84 9.23 480235.5 724817.52 9.23 480236.98 724818.33 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-70BE-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-70BE-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">13.27</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BE-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480425.89 723947.04 3.34 480350 724007.36 3.34 480440.07 724120.86 3.34 480516.02 724060.7 3.34 480425.89 723947.04 3.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BE-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480425.89 723947.04 3.34 480516.02 724060.7 3.34 480516.02 724060.7 16.61 480425.89 723947.04 16.61 480425.89 723947.04 3.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BE-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480516.02 724060.7 3.34 480440.07 724120.86 3.34 480440.07 724120.86 16.61 480516.02 724060.7 16.61 480516.02 724060.7 3.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BE-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480440.07 724120.86 3.34 480350 724007.36 3.34 480350 724007.36 16.61 480440.07 724120.86 16.61 480440.07 724120.86 3.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BE-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480350 724007.36 3.34 480425.89 723947.04 3.34 480425.89 723947.04 16.61 480350 724007.36 16.61 480350 724007.36 3.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-70BE-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480425.89 723947.04 16.61 480516.02 724060.7 16.61 480440.07 724120.86 16.61 480350 724007.36 16.61 480425.89 723947.04 16.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D61B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D61B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D61B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479864.99 725655.84 3.52 479861.01 725655.57 3.52 479857.36 725655.32 3.52 479856.21 725673.79 3.52 479863.44 725674.29 3.52 479864.99 725655.84 3.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D61B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479864.99 725655.84 3.52 479863.44 725674.29 3.52 479863.44 725674.29 12.81 479864.99 725655.84 12.81 479864.99 725655.84 3.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D61B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479863.44 725674.29 3.52 479856.21 725673.79 3.52 479856.21 725673.79 12.81 479863.44 725674.29 12.81 479863.44 725674.29 3.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D61B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479856.21 725673.79 3.52 479857.36 725655.32 3.52 479857.36 725655.32 12.81 479856.21 725673.79 12.81 479856.21 725673.79 3.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D61B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479857.36 725655.32 3.52 479861.01 725655.57 3.52 479861.01 725655.57 12.81 479857.36 725655.32 12.81 479857.36 725655.32 3.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D61B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479861.01 725655.57 3.52 479864.99 725655.84 3.52 479864.99 725655.84 12.81 479861.01 725655.57 12.81 479861.01 725655.57 3.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D61B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479864.99 725655.84 12.81 479863.44 725674.29 12.81 479856.21 725673.79 12.81 479857.36 725655.32 12.81 479861.01 725655.57 12.81 479864.99 725655.84 12.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D554-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D554-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.25</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D554-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479861.97 725730.36 3.45 479864.25 725687.47 3.45 479855.13 725686.91 3.45 479852.7 725729.82 3.45 479861.97 725730.36 3.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D554-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479861.97 725730.36 3.45 479852.7 725729.82 3.45 479852.7 725729.82 11.7 479861.97 725730.36 11.7 479861.97 725730.36 3.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D554-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479852.7 725729.82 3.45 479855.13 725686.91 3.45 479855.13 725686.91 11.7 479852.7 725729.82 11.7 479852.7 725729.82 3.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D554-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479855.13 725686.91 3.45 479864.25 725687.47 3.45 479864.25 725687.47 11.7 479855.13 725686.91 11.7 479855.13 725686.91 3.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D554-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479864.25 725687.47 3.45 479861.97 725730.36 3.45 479861.97 725730.36 11.7 479864.25 725687.47 11.7 479864.25 725687.47 3.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D554-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479861.97 725730.36 11.7 479852.7 725729.82 11.7 479855.13 725686.91 11.7 479864.25 725687.47 11.7 479861.97 725730.36 11.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4752-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">11.51</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481313.7 724259.35 2.86 481329.31 724278.79 2.86 481371.19 724245.22 2.86 481371.15 724245.17 2.86 481404.47 724218.4 2.86 481405.24 724217.79 2.86 481414.44 724229.29 2.86 481424.21 724221.41 2.86 481399.49 724190.59 2.86 481393.48 724195.38 2.86 481388.62 724199.31 2.86 481388.69 724199.41 2.86 481356 724225.69 2.86 481355.84 724225.48 2.86 481324.88 724250.36 2.86 481323.33 724248.42 2.86 481316.84 724253.64 2.86 481318.4 724255.58 2.86 481313.7 724259.35 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481313.7 724259.35 2.86 481318.4 724255.58 2.86 481318.4 724255.58 14.370000000000001 481313.7 724259.35 14.370000000000001 481313.7 724259.35 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481318.4 724255.58 2.86 481316.84 724253.64 2.86 481316.84 724253.64 14.370000000000001 481318.4 724255.58 14.370000000000001 481318.4 724255.58 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481316.84 724253.64 2.86 481323.33 724248.42 2.86 481323.33 724248.42 14.370000000000001 481316.84 724253.64 14.370000000000001 481316.84 724253.64 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481323.33 724248.42 2.86 481324.88 724250.36 2.86 481324.88 724250.36 14.370000000000001 481323.33 724248.42 14.370000000000001 481323.33 724248.42 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481324.88 724250.36 2.86 481355.84 724225.48 2.86 481355.84 724225.48 14.370000000000001 481324.88 724250.36 14.370000000000001 481324.88 724250.36 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481355.84 724225.48 2.86 481356 724225.69 2.86 481356 724225.69 14.370000000000001 481355.84 724225.48 14.370000000000001 481355.84 724225.48 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481356 724225.69 2.86 481388.69 724199.41 2.86 481388.69 724199.41 14.370000000000001 481356 724225.69 14.370000000000001 481356 724225.69 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481388.69 724199.41 2.86 481388.62 724199.31 2.86 481388.62 724199.31 14.370000000000001 481388.69 724199.41 14.370000000000001 481388.69 724199.41 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481388.62 724199.31 2.86 481393.48 724195.38 2.86 481393.48 724195.38 14.370000000000001 481388.62 724199.31 14.370000000000001 481388.62 724199.31 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481393.48 724195.38 2.86 481399.49 724190.59 2.86 481399.49 724190.59 14.370000000000001 481393.48 724195.38 14.370000000000001 481393.48 724195.38 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481399.49 724190.59 2.86 481424.21 724221.41 2.86 481424.21 724221.41 14.370000000000001 481399.49 724190.59 14.370000000000001 481399.49 724190.59 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481424.21 724221.41 2.86 481414.44 724229.29 2.86 481414.44 724229.29 14.370000000000001 481424.21 724221.41 14.370000000000001 481424.21 724221.41 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481414.44 724229.29 2.86 481405.24 724217.79 2.86 481405.24 724217.79 14.370000000000001 481414.44 724229.29 14.370000000000001 481414.44 724229.29 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481405.24 724217.79 2.86 481404.47 724218.4 2.86 481404.47 724218.4 14.370000000000001 481405.24 724217.79 14.370000000000001 481405.24 724217.79 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481404.47 724218.4 2.86 481371.15 724245.17 2.86 481371.15 724245.17 14.370000000000001 481404.47 724218.4 14.370000000000001 481404.47 724218.4 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481371.15 724245.17 2.86 481371.19 724245.22 2.86 481371.19 724245.22 14.370000000000001 481371.15 724245.17 14.370000000000001 481371.15 724245.17 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481371.19 724245.22 2.86 481329.31 724278.79 2.86 481329.31 724278.79 14.370000000000001 481371.19 724245.22 14.370000000000001 481371.19 724245.22 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481329.31 724278.79 2.86 481313.7 724259.35 2.86 481313.7 724259.35 14.370000000000001 481329.31 724278.79 14.370000000000001 481329.31 724278.79 2.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4752-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481313.7 724259.35 14.370000000000001 481318.4 724255.58 14.370000000000001 481316.84 724253.64 14.370000000000001 481323.33 724248.42 14.370000000000001 481324.88 724250.36 14.370000000000001 481355.84 724225.48 14.370000000000001 481356 724225.69 14.370000000000001 481388.69 724199.41 14.370000000000001 481388.62 724199.31 14.370000000000001 481393.48 724195.38 14.370000000000001 481399.49 724190.59 14.370000000000001 481424.21 724221.41 14.370000000000001 481414.44 724229.29 14.370000000000001 481405.24 724217.79 14.370000000000001 481404.47 724218.4 14.370000000000001 481371.15 724245.17 14.370000000000001 481371.19 724245.22 14.370000000000001 481329.31 724278.79 14.370000000000001 481313.7 724259.35 14.370000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4A6A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4A6A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.72</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4A6A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480044.05 725074.66 2.91 480051.22 725068.76 2.91 480027.49 725041.37 2.91 480020.65 725047.29 2.91 480044.05 725074.66 2.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4A6A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480044.05 725074.66 2.91 480020.65 725047.29 2.91 480020.65 725047.29 6.63 480044.05 725074.66 6.63 480044.05 725074.66 2.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4A6A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480020.65 725047.29 2.91 480027.49 725041.37 2.91 480027.49 725041.37 6.63 480020.65 725047.29 6.63 480020.65 725047.29 2.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4A6A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480027.49 725041.37 2.91 480051.22 725068.76 2.91 480051.22 725068.76 6.63 480027.49 725041.37 6.63 480027.49 725041.37 2.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4A6A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480051.22 725068.76 2.91 480044.05 725074.66 2.91 480044.05 725074.66 6.63 480051.22 725068.76 6.63 480051.22 725068.76 2.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4A6A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480044.05 725074.66 6.63 480020.65 725047.29 6.63 480027.49 725041.37 6.63 480051.22 725068.76 6.63 480044.05 725074.66 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4B2F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4B2F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480090.49 725058.95 3.24 480106.73 725050.89 3.24 480106.31 725050.02 3.24 480074.03 724983.14 3.24 480062.7 724988.61 3.24 480058.76 724990.52 3.24 480057.69 724991.03 3.24 480090.49 725058.95 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480090.49 725058.95 3.24 480057.69 724991.03 3.24 480057.69 724991.03 9.23 480090.49 725058.95 9.23 480090.49 725058.95 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480057.69 724991.03 3.24 480058.76 724990.52 3.24 480058.76 724990.52 9.23 480057.69 724991.03 9.23 480057.69 724991.03 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480058.76 724990.52 3.24 480062.7 724988.61 3.24 480062.7 724988.61 9.23 480058.76 724990.52 9.23 480058.76 724990.52 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480062.7 724988.61 3.24 480074.03 724983.14 3.24 480074.03 724983.14 9.23 480062.7 724988.61 9.23 480062.7 724988.61 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480074.03 724983.14 3.24 480106.31 725050.02 3.24 480106.31 725050.02 9.23 480074.03 724983.14 9.23 480074.03 724983.14 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480106.31 725050.02 3.24 480106.73 725050.89 3.24 480106.73 725050.89 9.23 480106.31 725050.02 9.23 480106.31 725050.02 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480106.73 725050.89 3.24 480090.49 725058.95 3.24 480090.49 725058.95 9.23 480106.73 725050.89 9.23 480106.73 725050.89 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480090.49 725058.95 9.23 480057.69 724991.03 9.23 480058.76 724990.52 9.23 480062.7 724988.61 9.23 480074.03 724983.14 9.23 480106.31 725050.02 9.23 480106.73 725050.89 9.23 480090.49 725058.95 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-59EA-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-59EA-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.35</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59EA-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480058.76 724990.52 3.17 480062.7 724988.61 3.17 480060.26 724983.56 3.17 480061.89 724982.71 3.17 480060.13 724979.32 3.17 480054.64 724982 3.17 480058.76 724990.52 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59EA-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480058.76 724990.52 3.17 480054.64 724982 3.17 480054.64 724982 6.5200000000000005 480058.76 724990.52 6.5200000000000005 480058.76 724990.52 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59EA-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480054.64 724982 3.17 480060.13 724979.32 3.17 480060.13 724979.32 6.5200000000000005 480054.64 724982 6.5200000000000005 480054.64 724982 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59EA-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480060.13 724979.32 3.17 480061.89 724982.71 3.17 480061.89 724982.71 6.5200000000000005 480060.13 724979.32 6.5200000000000005 480060.13 724979.32 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59EA-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480061.89 724982.71 3.17 480060.26 724983.56 3.17 480060.26 724983.56 6.5200000000000005 480061.89 724982.71 6.5200000000000005 480061.89 724982.71 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59EA-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480060.26 724983.56 3.17 480062.7 724988.61 3.17 480062.7 724988.61 6.5200000000000005 480060.26 724983.56 6.5200000000000005 480060.26 724983.56 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59EA-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480062.7 724988.61 3.17 480058.76 724990.52 3.17 480058.76 724990.52 6.5200000000000005 480062.7 724988.61 6.5200000000000005 480062.7 724988.61 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59EA-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480058.76 724990.52 6.5200000000000005 480054.64 724982 6.5200000000000005 480060.13 724979.32 6.5200000000000005 480061.89 724982.71 6.5200000000000005 480060.26 724983.56 6.5200000000000005 480062.7 724988.61 6.5200000000000005 480058.76 724990.52 6.5200000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4B2C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4B2C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479948.25 725284.44 2.35 479956.53 725284.31 2.35 479956.12 725265.52 2.35 479947.87 725265.86 2.35 479948.25 725284.44 2.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479948.25 725284.44 2.35 479947.87 725265.86 2.35 479947.87 725265.86 7.9 479948.25 725284.44 7.9 479948.25 725284.44 2.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479947.87 725265.86 2.35 479956.12 725265.52 2.35 479956.12 725265.52 7.9 479947.87 725265.86 7.9 479947.87 725265.86 2.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479956.12 725265.52 2.35 479956.53 725284.31 2.35 479956.53 725284.31 7.9 479956.12 725265.52 7.9 479956.12 725265.52 2.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479956.53 725284.31 2.35 479948.25 725284.44 2.35 479948.25 725284.44 7.9 479956.53 725284.31 7.9 479956.53 725284.31 2.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4B2C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479948.25 725284.44 7.9 479947.87 725265.86 7.9 479956.12 725265.52 7.9 479956.53 725284.31 7.9 479948.25 725284.44 7.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D20E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D20E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.26</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D20E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481246.07 724203.4 3.11 481230.8 724184.38 3.11 481225.44 724188.65 3.11 481236.13 724201.98 3.11 481234.8 724203.04 3.11 481239.33 724208.72 3.11 481246.07 724203.4 3.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D20E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481246.07 724203.4 3.11 481239.33 724208.72 3.11 481239.33 724208.72 7.369999999999999 481246.07 724203.4 7.369999999999999 481246.07 724203.4 3.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D20E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481239.33 724208.72 3.11 481234.8 724203.04 3.11 481234.8 724203.04 7.369999999999999 481239.33 724208.72 7.369999999999999 481239.33 724208.72 3.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D20E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481234.8 724203.04 3.11 481236.13 724201.98 3.11 481236.13 724201.98 7.369999999999999 481234.8 724203.04 7.369999999999999 481234.8 724203.04 3.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D20E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481236.13 724201.98 3.11 481225.44 724188.65 3.11 481225.44 724188.65 7.369999999999999 481236.13 724201.98 7.369999999999999 481236.13 724201.98 3.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D20E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481225.44 724188.65 3.11 481230.8 724184.38 3.11 481230.8 724184.38 7.369999999999999 481225.44 724188.65 7.369999999999999 481225.44 724188.65 3.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D20E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481230.8 724184.38 3.11 481246.07 724203.4 3.11 481246.07 724203.4 7.369999999999999 481230.8 724184.38 7.369999999999999 481230.8 724184.38 3.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D20E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481246.07 724203.4 7.369999999999999 481239.33 724208.72 7.369999999999999 481234.8 724203.04 7.369999999999999 481236.13 724201.98 7.369999999999999 481225.44 724188.65 7.369999999999999 481230.8 724184.38 7.369999999999999 481246.07 724203.4 7.369999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D623-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D623-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.9</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D623-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479886.89 725581.34 2.43 479906.5 725573.92 2.43 479902.69 725563.5 2.43 479883.27 725570.7 2.43 479886.89 725581.34 2.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D623-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479886.89 725581.34 2.43 479883.27 725570.7 2.43 479883.27 725570.7 5.33 479886.89 725581.34 5.33 479886.89 725581.34 2.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D623-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479883.27 725570.7 2.43 479902.69 725563.5 2.43 479902.69 725563.5 5.33 479883.27 725570.7 5.33 479883.27 725570.7 2.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D623-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479902.69 725563.5 2.43 479906.5 725573.92 2.43 479906.5 725573.92 5.33 479902.69 725563.5 5.33 479902.69 725563.5 2.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D623-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479906.5 725573.92 2.43 479886.89 725581.34 2.43 479886.89 725581.34 5.33 479906.5 725573.92 5.33 479906.5 725573.92 2.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D623-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479886.89 725581.34 5.33 479883.27 725570.7 5.33 479902.69 725563.5 5.33 479906.5 725573.92 5.33 479886.89 725581.34 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D209-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D209-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D209-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481168.39 724253.44 3.15 481173.41 724249.34 3.15 481172.47 724248.15 3.15 481171.04 724246.34 3.15 481169.12 724243.91 3.15 481168.35 724242.93 3.15 481168.26 724242.8 3.15 481163.17 724246.88 3.15 481168.39 724253.44 3.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D209-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481168.39 724253.44 3.15 481163.17 724246.88 3.15 481163.17 724246.88 7.15 481168.39 724253.44 7.15 481168.39 724253.44 3.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D209-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481163.17 724246.88 3.15 481168.26 724242.8 3.15 481168.26 724242.8 7.15 481163.17 724246.88 7.15 481163.17 724246.88 3.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D209-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481168.26 724242.8 3.15 481168.35 724242.93 3.15 481168.35 724242.93 7.15 481168.26 724242.8 7.15 481168.26 724242.8 3.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D209-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481168.35 724242.93 3.15 481169.12 724243.91 3.15 481169.12 724243.91 7.15 481168.35 724242.93 7.15 481168.35 724242.93 3.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D209-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481169.12 724243.91 3.15 481171.04 724246.34 3.15 481171.04 724246.34 7.15 481169.12 724243.91 7.15 481169.12 724243.91 3.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D209-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481171.04 724246.34 3.15 481172.47 724248.15 3.15 481172.47 724248.15 7.15 481171.04 724246.34 7.15 481171.04 724246.34 3.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D209-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481172.47 724248.15 3.15 481173.41 724249.34 3.15 481173.41 724249.34 7.15 481172.47 724248.15 7.15 481172.47 724248.15 3.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D209-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481173.41 724249.34 3.15 481168.39 724253.44 3.15 481168.39 724253.44 7.15 481173.41 724249.34 7.15 481173.41 724249.34 3.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D209-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481168.39 724253.44 7.15 481163.17 724246.88 7.15 481168.26 724242.8 7.15 481168.35 724242.93 7.15 481169.12 724243.91 7.15 481171.04 724246.34 7.15 481172.47 724248.15 7.15 481173.41 724249.34 7.15 481168.39 724253.44 7.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-cc316046-605a-4c70-afe4-1bedd55a6451">
			<gen:stringAttribute name="buildingId">
				<gen:value>cc316046-605a-4c70-afe4-1bedd55a6451</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.49</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cc316046-605a-4c70-afe4-1bedd55a6451_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479901.49 724980.15 2.43 479890.71 724984.63 2.43 479896.16 724997.73 2.43 479906.94 724993.24 2.43 479901.49 724980.15 2.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cc316046-605a-4c70-afe4-1bedd55a6451_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479901.49 724980.15 2.43 479906.94 724993.24 2.43 479906.94 724993.24 7.92 479901.49 724980.15 7.92 479901.49 724980.15 2.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cc316046-605a-4c70-afe4-1bedd55a6451_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479906.94 724993.24 2.43 479896.16 724997.73 2.43 479896.16 724997.73 7.92 479906.94 724993.24 7.92 479906.94 724993.24 2.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cc316046-605a-4c70-afe4-1bedd55a6451_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479896.16 724997.73 2.43 479890.71 724984.63 2.43 479890.71 724984.63 7.92 479896.16 724997.73 7.92 479896.16 724997.73 2.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cc316046-605a-4c70-afe4-1bedd55a6451_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479890.71 724984.63 2.43 479901.49 724980.15 2.43 479901.49 724980.15 7.92 479890.71 724984.63 7.92 479890.71 724984.63 2.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-cc316046-605a-4c70-afe4-1bedd55a6451_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479901.49 724980.15 7.92 479906.94 724993.24 7.92 479896.16 724997.73 7.92 479890.71 724984.63 7.92 479901.49 724980.15 7.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-c8dd8b1b-fbfd-4304-a47e-a5db348084f6">
			<gen:stringAttribute name="buildingId">
				<gen:value>c8dd8b1b-fbfd-4304-a47e-a5db348084f6</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">13.31</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8dd8b1b-fbfd-4304-a47e-a5db348084f6_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480501.05 723887.38 3.4 480425.89 723947.04 3.4 480516.02 724060.7 3.4 480591.32 724000.93 3.4 480583.88 723991.55 3.4 480516.06 723906.07 3.4 480501.05 723887.38 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8dd8b1b-fbfd-4304-a47e-a5db348084f6_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480501.05 723887.38 3.4 480516.06 723906.07 3.4 480516.06 723906.07 16.71 480501.05 723887.38 16.71 480501.05 723887.38 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8dd8b1b-fbfd-4304-a47e-a5db348084f6_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480516.06 723906.07 3.4 480583.88 723991.55 3.4 480583.88 723991.55 16.71 480516.06 723906.07 16.71 480516.06 723906.07 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8dd8b1b-fbfd-4304-a47e-a5db348084f6_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480583.88 723991.55 3.4 480591.32 724000.93 3.4 480591.32 724000.93 16.71 480583.88 723991.55 16.71 480583.88 723991.55 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8dd8b1b-fbfd-4304-a47e-a5db348084f6_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480591.32 724000.93 3.4 480516.02 724060.7 3.4 480516.02 724060.7 16.71 480591.32 724000.93 16.71 480591.32 724000.93 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8dd8b1b-fbfd-4304-a47e-a5db348084f6_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480516.02 724060.7 3.4 480425.89 723947.04 3.4 480425.89 723947.04 16.71 480516.02 724060.7 16.71 480516.02 724060.7 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8dd8b1b-fbfd-4304-a47e-a5db348084f6_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480425.89 723947.04 3.4 480501.05 723887.38 3.4 480501.05 723887.38 16.71 480425.89 723947.04 16.71 480425.89 723947.04 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8dd8b1b-fbfd-4304-a47e-a5db348084f6_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480501.05 723887.38 16.71 480516.06 723906.07 16.71 480583.88 723991.55 16.71 480591.32 724000.93 16.71 480516.02 724060.7 16.71 480425.89 723947.04 16.71 480501.05 723887.38 16.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-503ea16f-33af-417a-b29a-83ed312f34c7">
			<gen:stringAttribute name="buildingId">
				<gen:value>503ea16f-33af-417a-b29a-83ed312f34c7</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.89</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-503ea16f-33af-417a-b29a-83ed312f34c7_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480196.66 724389.76 3.17 480207.3 724395.99 3.17 480222.67 724369.62 3.17 480212 724363.43 3.17 480196.66 724389.76 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-503ea16f-33af-417a-b29a-83ed312f34c7_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480196.66 724389.76 3.17 480212 724363.43 3.17 480212 724363.43 9.06 480196.66 724389.76 9.06 480196.66 724389.76 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-503ea16f-33af-417a-b29a-83ed312f34c7_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480212 724363.43 3.17 480222.67 724369.62 3.17 480222.67 724369.62 9.06 480212 724363.43 9.06 480212 724363.43 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-503ea16f-33af-417a-b29a-83ed312f34c7_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480222.67 724369.62 3.17 480207.3 724395.99 3.17 480207.3 724395.99 9.06 480222.67 724369.62 9.06 480222.67 724369.62 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-503ea16f-33af-417a-b29a-83ed312f34c7_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480207.3 724395.99 3.17 480196.66 724389.76 3.17 480196.66 724389.76 9.06 480207.3 724395.99 9.06 480207.3 724395.99 3.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-503ea16f-33af-417a-b29a-83ed312f34c7_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480196.66 724389.76 9.06 480212 724363.43 9.06 480222.67 724369.62 9.06 480207.3 724395.99 9.06 480196.66 724389.76 9.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e">
			<gen:stringAttribute name="buildingId">
				<gen:value>1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.31</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480896.2 725404.09 2.78 480896.6 725406.87 2.78 480897.46 725408.7 2.78 480898.42 725409.99 2.78 480900.81 725411.83 2.78 480902.9 725412.58 2.78 480903.87 725412.72 2.78 480906.53 725412.55 2.78 480908.23 725412 2.78 480909.46 725411.28 2.78 480910.77 725410.17 2.78 480912.14 725408.33 2.78 480913.03 725405.75 2.78 480913.01 725402.73 2.78 480912.52 725401.05 2.78 480911.5 725399.27 2.78 480909.51 725397.33 2.78 480907.53 725396.31 2.78 480904.79 725395.82 2.78 480901.49 725396.43 2.78 480899.58 725397.54 2.78 480898.03 725399.03 2.78 480896.93 725400.85 2.78 480896.39 725402.57 2.78 480896.2 725404.09 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480896.2 725404.09 2.78 480896.39 725402.57 2.78 480896.39 725402.57 15.09 480896.2 725404.09 15.09 480896.2 725404.09 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480896.39 725402.57 2.78 480896.93 725400.85 2.78 480896.93 725400.85 15.09 480896.39 725402.57 15.09 480896.39 725402.57 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480896.93 725400.85 2.78 480898.03 725399.03 2.78 480898.03 725399.03 15.09 480896.93 725400.85 15.09 480896.93 725400.85 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480898.03 725399.03 2.78 480899.58 725397.54 2.78 480899.58 725397.54 15.09 480898.03 725399.03 15.09 480898.03 725399.03 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480899.58 725397.54 2.78 480901.49 725396.43 2.78 480901.49 725396.43 15.09 480899.58 725397.54 15.09 480899.58 725397.54 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480901.49 725396.43 2.78 480904.79 725395.82 2.78 480904.79 725395.82 15.09 480901.49 725396.43 15.09 480901.49 725396.43 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480904.79 725395.82 2.78 480907.53 725396.31 2.78 480907.53 725396.31 15.09 480904.79 725395.82 15.09 480904.79 725395.82 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480907.53 725396.31 2.78 480909.51 725397.33 2.78 480909.51 725397.33 15.09 480907.53 725396.31 15.09 480907.53 725396.31 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480909.51 725397.33 2.78 480911.5 725399.27 2.78 480911.5 725399.27 15.09 480909.51 725397.33 15.09 480909.51 725397.33 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480911.5 725399.27 2.78 480912.52 725401.05 2.78 480912.52 725401.05 15.09 480911.5 725399.27 15.09 480911.5 725399.27 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480912.52 725401.05 2.78 480913.01 725402.73 2.78 480913.01 725402.73 15.09 480912.52 725401.05 15.09 480912.52 725401.05 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480913.01 725402.73 2.78 480913.03 725405.75 2.78 480913.03 725405.75 15.09 480913.01 725402.73 15.09 480913.01 725402.73 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480913.03 725405.75 2.78 480912.14 725408.33 2.78 480912.14 725408.33 15.09 480913.03 725405.75 15.09 480913.03 725405.75 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480912.14 725408.33 2.78 480910.77 725410.17 2.78 480910.77 725410.17 15.09 480912.14 725408.33 15.09 480912.14 725408.33 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480910.77 725410.17 2.78 480909.46 725411.28 2.78 480909.46 725411.28 15.09 480910.77 725410.17 15.09 480910.77 725410.17 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480909.46 725411.28 2.78 480908.23 725412 2.78 480908.23 725412 15.09 480909.46 725411.28 15.09 480909.46 725411.28 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480908.23 725412 2.78 480906.53 725412.55 2.78 480906.53 725412.55 15.09 480908.23 725412 15.09 480908.23 725412 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480906.53 725412.55 2.78 480903.87 725412.72 2.78 480903.87 725412.72 15.09 480906.53 725412.55 15.09 480906.53 725412.55 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480903.87 725412.72 2.78 480902.9 725412.58 2.78 480902.9 725412.58 15.09 480903.87 725412.72 15.09 480903.87 725412.72 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480902.9 725412.58 2.78 480900.81 725411.83 2.78 480900.81 725411.83 15.09 480902.9 725412.58 15.09 480902.9 725412.58 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480900.81 725411.83 2.78 480898.42 725409.99 2.78 480898.42 725409.99 15.09 480900.81 725411.83 15.09 480900.81 725411.83 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480898.42 725409.99 2.78 480897.46 725408.7 2.78 480897.46 725408.7 15.09 480898.42 725409.99 15.09 480898.42 725409.99 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480897.46 725408.7 2.78 480896.6 725406.87 2.78 480896.6 725406.87 15.09 480897.46 725408.7 15.09 480897.46 725408.7 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480896.6 725406.87 2.78 480896.2 725404.09 2.78 480896.2 725404.09 15.09 480896.6 725406.87 15.09 480896.6 725406.87 2.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1a0ee0df-24c7-4e34-8bb6-47d42dc02f4e_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480896.2 725404.09 15.09 480896.39 725402.57 15.09 480896.93 725400.85 15.09 480898.03 725399.03 15.09 480899.58 725397.54 15.09 480901.49 725396.43 15.09 480904.79 725395.82 15.09 480907.53 725396.31 15.09 480909.51 725397.33 15.09 480911.5 725399.27 15.09 480912.52 725401.05 15.09 480913.01 725402.73 15.09 480913.03 725405.75 15.09 480912.14 725408.33 15.09 480910.77 725410.17 15.09 480909.46 725411.28 15.09 480908.23 725412 15.09 480906.53 725412.55 15.09 480903.87 725412.72 15.09 480902.9 725412.58 15.09 480900.81 725411.83 15.09 480898.42 725409.99 15.09 480897.46 725408.7 15.09 480896.6 725406.87 15.09 480896.2 725404.09 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-9d23a5b7-f63a-4802-a414-f38718a05415">
			<gen:stringAttribute name="buildingId">
				<gen:value>9d23a5b7-f63a-4802-a414-f38718a05415</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9d23a5b7-f63a-4802-a414-f38718a05415_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480334.22 725205.75 2.99 480318.19 725234.42 2.99 480326.47 725239.05 2.99 480342.49 725210.37 2.99 480334.22 725205.75 2.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9d23a5b7-f63a-4802-a414-f38718a05415_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480334.22 725205.75 2.99 480342.49 725210.37 2.99 480342.49 725210.37 7.59 480334.22 725205.75 7.59 480334.22 725205.75 2.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9d23a5b7-f63a-4802-a414-f38718a05415_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480342.49 725210.37 2.99 480326.47 725239.05 2.99 480326.47 725239.05 7.59 480342.49 725210.37 7.59 480342.49 725210.37 2.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9d23a5b7-f63a-4802-a414-f38718a05415_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480326.47 725239.05 2.99 480318.19 725234.42 2.99 480318.19 725234.42 7.59 480326.47 725239.05 7.59 480326.47 725239.05 2.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9d23a5b7-f63a-4802-a414-f38718a05415_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480318.19 725234.42 2.99 480334.22 725205.75 2.99 480334.22 725205.75 7.59 480318.19 725234.42 7.59 480318.19 725234.42 2.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9d23a5b7-f63a-4802-a414-f38718a05415_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480334.22 725205.75 7.59 480342.49 725210.37 7.59 480326.47 725239.05 7.59 480318.19 725234.42 7.59 480334.22 725205.75 7.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-5c3d3434-da36-49df-85f1-1412159405d0">
			<gen:stringAttribute name="buildingId">
				<gen:value>5c3d3434-da36-49df-85f1-1412159405d0</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">13.46</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5c3d3434-da36-49df-85f1-1412159405d0_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480233.48 723804.84 3.2 480148.25 723872.44 3.2 480238.2 723985.84 3.2 480323.43 723918.25 3.2 480233.48 723804.84 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5c3d3434-da36-49df-85f1-1412159405d0_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480233.48 723804.84 3.2 480323.43 723918.25 3.2 480323.43 723918.25 16.66 480233.48 723804.84 16.66 480233.48 723804.84 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5c3d3434-da36-49df-85f1-1412159405d0_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480323.43 723918.25 3.2 480238.2 723985.84 3.2 480238.2 723985.84 16.66 480323.43 723918.25 16.66 480323.43 723918.25 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5c3d3434-da36-49df-85f1-1412159405d0_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480238.2 723985.84 3.2 480148.25 723872.44 3.2 480148.25 723872.44 16.66 480238.2 723985.84 16.66 480238.2 723985.84 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5c3d3434-da36-49df-85f1-1412159405d0_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480148.25 723872.44 3.2 480233.48 723804.84 3.2 480233.48 723804.84 16.66 480148.25 723872.44 16.66 480148.25 723872.44 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5c3d3434-da36-49df-85f1-1412159405d0_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480233.48 723804.84 16.66 480323.43 723918.25 16.66 480238.2 723985.84 16.66 480148.25 723872.44 16.66 480233.48 723804.84 16.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-73cb1463-6338-42b2-8b71-397a6414bbb6">
			<gen:stringAttribute name="buildingId">
				<gen:value>73cb1463-6338-42b2-8b71-397a6414bbb6</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">13.39</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-73cb1463-6338-42b2-8b71-397a6414bbb6_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480516.06 723906.07 3.36 480583.88 723991.55 3.36 480742.96 723865.34 3.36 480766.34 723846.78 3.36 480735.91 723808.42 3.36 480723.28 723818.59 3.36 480717.28 723823.36 3.36 480712.52 723826.98 3.36 480675.14 723779.86 3.36 480516.06 723906.07 3.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-73cb1463-6338-42b2-8b71-397a6414bbb6_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480516.06 723906.07 3.36 480675.14 723779.86 3.36 480675.14 723779.86 16.75 480516.06 723906.07 16.75 480516.06 723906.07 3.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-73cb1463-6338-42b2-8b71-397a6414bbb6_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480675.14 723779.86 3.36 480712.52 723826.98 3.36 480712.52 723826.98 16.75 480675.14 723779.86 16.75 480675.14 723779.86 3.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-73cb1463-6338-42b2-8b71-397a6414bbb6_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480712.52 723826.98 3.36 480717.28 723823.36 3.36 480717.28 723823.36 16.75 480712.52 723826.98 16.75 480712.52 723826.98 3.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-73cb1463-6338-42b2-8b71-397a6414bbb6_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480717.28 723823.36 3.36 480723.28 723818.59 3.36 480723.28 723818.59 16.75 480717.28 723823.36 16.75 480717.28 723823.36 3.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-73cb1463-6338-42b2-8b71-397a6414bbb6_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480723.28 723818.59 3.36 480735.91 723808.42 3.36 480735.91 723808.42 16.75 480723.28 723818.59 16.75 480723.28 723818.59 3.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-73cb1463-6338-42b2-8b71-397a6414bbb6_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480735.91 723808.42 3.36 480766.34 723846.78 3.36 480766.34 723846.78 16.75 480735.91 723808.42 16.75 480735.91 723808.42 3.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-73cb1463-6338-42b2-8b71-397a6414bbb6_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480766.34 723846.78 3.36 480742.96 723865.34 3.36 480742.96 723865.34 16.75 480766.34 723846.78 16.75 480766.34 723846.78 3.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-73cb1463-6338-42b2-8b71-397a6414bbb6_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480742.96 723865.34 3.36 480583.88 723991.55 3.36 480583.88 723991.55 16.75 480742.96 723865.34 16.75 480742.96 723865.34 3.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-73cb1463-6338-42b2-8b71-397a6414bbb6_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480583.88 723991.55 3.36 480516.06 723906.07 3.36 480516.06 723906.07 16.75 480583.88 723991.55 16.75 480583.88 723991.55 3.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-73cb1463-6338-42b2-8b71-397a6414bbb6_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480516.06 723906.07 16.75 480675.14 723779.86 16.75 480712.52 723826.98 16.75 480717.28 723823.36 16.75 480723.28 723818.59 16.75 480735.91 723808.42 16.75 480766.34 723846.78 16.75 480742.96 723865.34 16.75 480583.88 723991.55 16.75 480516.06 723906.07 16.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad">
			<gen:stringAttribute name="buildingId">
				<gen:value>fb583ff9-15c3-4017-9303-aaf5ff54e6ad</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.36</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480877.16 725405.59 2.77 480871.02 725416.58 2.77 480870.87 725416.48 2.77 480856.19 725442.72 2.77 480856.09 725442.66 2.77 480847.07 725458.82 2.77 480857.89 725464.88 2.77 480866.92 725448.73 2.77 480866.82 725448.65 2.77 480881.49 725422.4 2.77 480881.34 725422.33 2.77 480887.45 725411.36 2.77 480877.16 725405.59 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480877.16 725405.59 2.77 480887.45 725411.36 2.77 480887.45 725411.36 8.13 480877.16 725405.59 8.13 480877.16 725405.59 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480887.45 725411.36 2.77 480881.34 725422.33 2.77 480881.34 725422.33 8.13 480887.45 725411.36 8.13 480887.45 725411.36 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480881.34 725422.33 2.77 480881.49 725422.4 2.77 480881.49 725422.4 8.13 480881.34 725422.33 8.13 480881.34 725422.33 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480881.49 725422.4 2.77 480866.82 725448.65 2.77 480866.82 725448.65 8.13 480881.49 725422.4 8.13 480881.49 725422.4 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480866.82 725448.65 2.77 480866.92 725448.73 2.77 480866.92 725448.73 8.13 480866.82 725448.65 8.13 480866.82 725448.65 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480866.92 725448.73 2.77 480857.89 725464.88 2.77 480857.89 725464.88 8.13 480866.92 725448.73 8.13 480866.92 725448.73 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480857.89 725464.88 2.77 480847.07 725458.82 2.77 480847.07 725458.82 8.13 480857.89 725464.88 8.13 480857.89 725464.88 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480847.07 725458.82 2.77 480856.09 725442.66 2.77 480856.09 725442.66 8.13 480847.07 725458.82 8.13 480847.07 725458.82 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480856.09 725442.66 2.77 480856.19 725442.72 2.77 480856.19 725442.72 8.13 480856.09 725442.66 8.13 480856.09 725442.66 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480856.19 725442.72 2.77 480870.87 725416.48 2.77 480870.87 725416.48 8.13 480856.19 725442.72 8.13 480856.19 725442.72 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480870.87 725416.48 2.77 480871.02 725416.58 2.77 480871.02 725416.58 8.13 480870.87 725416.48 8.13 480870.87 725416.48 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480871.02 725416.58 2.77 480877.16 725405.59 2.77 480877.16 725405.59 8.13 480871.02 725416.58 8.13 480871.02 725416.58 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fb583ff9-15c3-4017-9303-aaf5ff54e6ad_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480877.16 725405.59 8.13 480887.45 725411.36 8.13 480881.34 725422.33 8.13 480881.49 725422.4 8.13 480866.82 725448.65 8.13 480866.92 725448.73 8.13 480857.89 725464.88 8.13 480847.07 725458.82 8.13 480856.09 725442.66 8.13 480856.19 725442.72 8.13 480870.87 725416.48 8.13 480871.02 725416.58 8.13 480877.16 725405.59 8.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0">
			<gen:stringAttribute name="buildingId">
				<gen:value>488ea361-4e54-4e22-880a-0dc6cfcb6df0</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.37</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480881.36 725437.59 2.71 480881.4 725440.15 2.71 480882.29 725442.68 2.71 480883.38 725444.26 2.71 480884.71 725445.47 2.71 480887.13 725446.71 2.71 480889.8 725447.13 2.71 480892.24 725446.76 2.71 480894.11 725445.92 2.71 480895.29 725445.09 2.71 480896.39 725443.91 2.71 480897.46 725442.17 2.71 480898.06 725440.38 2.71 480898.21 725438.24 2.71 480897.83 725436.11 2.71 480897.13 725434.51 2.71 480896.17 725433.14 2.71 480894.62 725431.72 2.71 480892.35 725430.59 2.71 480889.8 725430.19 2.71 480887.63 725430.45 2.71 480885.38 725431.38 2.71 480884.15 725432.32 2.71 480882.65 725434.01 2.71 480881.68 725436.05 2.71 480881.36 725437.59 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480881.36 725437.59 2.71 480881.68 725436.05 2.71 480881.68 725436.05 15.080000000000002 480881.36 725437.59 15.080000000000002 480881.36 725437.59 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480881.68 725436.05 2.71 480882.65 725434.01 2.71 480882.65 725434.01 15.080000000000002 480881.68 725436.05 15.080000000000002 480881.68 725436.05 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480882.65 725434.01 2.71 480884.15 725432.32 2.71 480884.15 725432.32 15.080000000000002 480882.65 725434.01 15.080000000000002 480882.65 725434.01 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480884.15 725432.32 2.71 480885.38 725431.38 2.71 480885.38 725431.38 15.080000000000002 480884.15 725432.32 15.080000000000002 480884.15 725432.32 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480885.38 725431.38 2.71 480887.63 725430.45 2.71 480887.63 725430.45 15.080000000000002 480885.38 725431.38 15.080000000000002 480885.38 725431.38 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480887.63 725430.45 2.71 480889.8 725430.19 2.71 480889.8 725430.19 15.080000000000002 480887.63 725430.45 15.080000000000002 480887.63 725430.45 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480889.8 725430.19 2.71 480892.35 725430.59 2.71 480892.35 725430.59 15.080000000000002 480889.8 725430.19 15.080000000000002 480889.8 725430.19 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480892.35 725430.59 2.71 480894.62 725431.72 2.71 480894.62 725431.72 15.080000000000002 480892.35 725430.59 15.080000000000002 480892.35 725430.59 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480894.62 725431.72 2.71 480896.17 725433.14 2.71 480896.17 725433.14 15.080000000000002 480894.62 725431.72 15.080000000000002 480894.62 725431.72 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480896.17 725433.14 2.71 480897.13 725434.51 2.71 480897.13 725434.51 15.080000000000002 480896.17 725433.14 15.080000000000002 480896.17 725433.14 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480897.13 725434.51 2.71 480897.83 725436.11 2.71 480897.83 725436.11 15.080000000000002 480897.13 725434.51 15.080000000000002 480897.13 725434.51 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480897.83 725436.11 2.71 480898.21 725438.24 2.71 480898.21 725438.24 15.080000000000002 480897.83 725436.11 15.080000000000002 480897.83 725436.11 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480898.21 725438.24 2.71 480898.06 725440.38 2.71 480898.06 725440.38 15.080000000000002 480898.21 725438.24 15.080000000000002 480898.21 725438.24 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480898.06 725440.38 2.71 480897.46 725442.17 2.71 480897.46 725442.17 15.080000000000002 480898.06 725440.38 15.080000000000002 480898.06 725440.38 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480897.46 725442.17 2.71 480896.39 725443.91 2.71 480896.39 725443.91 15.080000000000002 480897.46 725442.17 15.080000000000002 480897.46 725442.17 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480896.39 725443.91 2.71 480895.29 725445.09 2.71 480895.29 725445.09 15.080000000000002 480896.39 725443.91 15.080000000000002 480896.39 725443.91 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480895.29 725445.09 2.71 480894.11 725445.92 2.71 480894.11 725445.92 15.080000000000002 480895.29 725445.09 15.080000000000002 480895.29 725445.09 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480894.11 725445.92 2.71 480892.24 725446.76 2.71 480892.24 725446.76 15.080000000000002 480894.11 725445.92 15.080000000000002 480894.11 725445.92 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480892.24 725446.76 2.71 480889.8 725447.13 2.71 480889.8 725447.13 15.080000000000002 480892.24 725446.76 15.080000000000002 480892.24 725446.76 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480889.8 725447.13 2.71 480887.13 725446.71 2.71 480887.13 725446.71 15.080000000000002 480889.8 725447.13 15.080000000000002 480889.8 725447.13 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480887.13 725446.71 2.71 480884.71 725445.47 2.71 480884.71 725445.47 15.080000000000002 480887.13 725446.71 15.080000000000002 480887.13 725446.71 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480884.71 725445.47 2.71 480883.38 725444.26 2.71 480883.38 725444.26 15.080000000000002 480884.71 725445.47 15.080000000000002 480884.71 725445.47 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480883.38 725444.26 2.71 480882.29 725442.68 2.71 480882.29 725442.68 15.080000000000002 480883.38 725444.26 15.080000000000002 480883.38 725444.26 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480882.29 725442.68 2.71 480881.4 725440.15 2.71 480881.4 725440.15 15.080000000000002 480882.29 725442.68 15.080000000000002 480882.29 725442.68 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480881.4 725440.15 2.71 480881.36 725437.59 2.71 480881.36 725437.59 15.080000000000002 480881.4 725440.15 15.080000000000002 480881.4 725440.15 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-488ea361-4e54-4e22-880a-0dc6cfcb6df0_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480881.36 725437.59 15.080000000000002 480881.68 725436.05 15.080000000000002 480882.65 725434.01 15.080000000000002 480884.15 725432.32 15.080000000000002 480885.38 725431.38 15.080000000000002 480887.63 725430.45 15.080000000000002 480889.8 725430.19 15.080000000000002 480892.35 725430.59 15.080000000000002 480894.62 725431.72 15.080000000000002 480896.17 725433.14 15.080000000000002 480897.13 725434.51 15.080000000000002 480897.83 725436.11 15.080000000000002 480898.21 725438.24 15.080000000000002 480898.06 725440.38 15.080000000000002 480897.46 725442.17 15.080000000000002 480896.39 725443.91 15.080000000000002 480895.29 725445.09 15.080000000000002 480894.11 725445.92 15.080000000000002 480892.24 725446.76 15.080000000000002 480889.8 725447.13 15.080000000000002 480887.13 725446.71 15.080000000000002 480884.71 725445.47 15.080000000000002 480883.38 725444.26 15.080000000000002 480882.29 725442.68 15.080000000000002 480881.4 725440.15 15.080000000000002 480881.36 725437.59 15.080000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-6eec7f06-82a9-4be2-8531-e0741e271927">
			<gen:stringAttribute name="buildingId">
				<gen:value>6eec7f06-82a9-4be2-8531-e0741e271927</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6eec7f06-82a9-4be2-8531-e0741e271927_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480319.78 725053.35 2.94 480303.53 725044.27 2.94 480297.79 725054.52 2.94 480297.02 725054.09 2.94 480292.04 725063.02 2.94 480292.8 725063.45 2.94 480284.03 725079.15 2.94 480300.28 725088.25 2.94 480319.78 725053.35 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6eec7f06-82a9-4be2-8531-e0741e271927_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480319.78 725053.35 2.94 480300.28 725088.25 2.94 480300.28 725088.25 11.540000000000001 480319.78 725053.35 11.540000000000001 480319.78 725053.35 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6eec7f06-82a9-4be2-8531-e0741e271927_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480300.28 725088.25 2.94 480284.03 725079.15 2.94 480284.03 725079.15 11.540000000000001 480300.28 725088.25 11.540000000000001 480300.28 725088.25 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6eec7f06-82a9-4be2-8531-e0741e271927_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480284.03 725079.15 2.94 480292.8 725063.45 2.94 480292.8 725063.45 11.540000000000001 480284.03 725079.15 11.540000000000001 480284.03 725079.15 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6eec7f06-82a9-4be2-8531-e0741e271927_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480292.8 725063.45 2.94 480292.04 725063.02 2.94 480292.04 725063.02 11.540000000000001 480292.8 725063.45 11.540000000000001 480292.8 725063.45 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6eec7f06-82a9-4be2-8531-e0741e271927_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480292.04 725063.02 2.94 480297.02 725054.09 2.94 480297.02 725054.09 11.540000000000001 480292.04 725063.02 11.540000000000001 480292.04 725063.02 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6eec7f06-82a9-4be2-8531-e0741e271927_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480297.02 725054.09 2.94 480297.79 725054.52 2.94 480297.79 725054.52 11.540000000000001 480297.02 725054.09 11.540000000000001 480297.02 725054.09 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6eec7f06-82a9-4be2-8531-e0741e271927_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480297.79 725054.52 2.94 480303.53 725044.27 2.94 480303.53 725044.27 11.540000000000001 480297.79 725054.52 11.540000000000001 480297.79 725054.52 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6eec7f06-82a9-4be2-8531-e0741e271927_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480303.53 725044.27 2.94 480319.78 725053.35 2.94 480319.78 725053.35 11.540000000000001 480303.53 725044.27 11.540000000000001 480303.53 725044.27 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6eec7f06-82a9-4be2-8531-e0741e271927_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480319.78 725053.35 11.540000000000001 480300.28 725088.25 11.540000000000001 480284.03 725079.15 11.540000000000001 480292.8 725063.45 11.540000000000001 480292.04 725063.02 11.540000000000001 480297.02 725054.09 11.540000000000001 480297.79 725054.52 11.540000000000001 480303.53 725044.27 11.540000000000001 480319.78 725053.35 11.540000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710">
			<gen:stringAttribute name="buildingId">
				<gen:value>03c27a72-fec6-48ca-afbb-95eee481c710</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480888.76 725421.12 2.77 480888.8 725422.49 2.77 480889.26 725424.4 2.77 480890.18 725426.19 2.77 480891.1 725427.34 2.77 480893.06 725428.86 2.77 480895.9 725429.85 2.77 480897.92 725429.92 2.77 480901.23 725428.93 2.77 480902.58 725428.04 2.77 480903.8 725426.79 2.77 480904.97 725424.88 2.77 480905.58 725422.88 2.77 480905.65 725420.77 2.77 480904.96 725418.05 2.77 480903.74 725416.07 2.77 480902.24 725414.64 2.77 480899.94 725413.45 2.77 480896.36 725413.05 2.77 480894.08 725413.6 2.77 480891.81 725414.95 2.77 480890.47 725416.36 2.77 480889.67 725417.6 2.77 480889.01 725419.35 2.77 480888.76 725421.12 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480888.76 725421.12 2.77 480889.01 725419.35 2.77 480889.01 725419.35 15.09 480888.76 725421.12 15.09 480888.76 725421.12 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480889.01 725419.35 2.77 480889.67 725417.6 2.77 480889.67 725417.6 15.09 480889.01 725419.35 15.09 480889.01 725419.35 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480889.67 725417.6 2.77 480890.47 725416.36 2.77 480890.47 725416.36 15.09 480889.67 725417.6 15.09 480889.67 725417.6 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480890.47 725416.36 2.77 480891.81 725414.95 2.77 480891.81 725414.95 15.09 480890.47 725416.36 15.09 480890.47 725416.36 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480891.81 725414.95 2.77 480894.08 725413.6 2.77 480894.08 725413.6 15.09 480891.81 725414.95 15.09 480891.81 725414.95 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480894.08 725413.6 2.77 480896.36 725413.05 2.77 480896.36 725413.05 15.09 480894.08 725413.6 15.09 480894.08 725413.6 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480896.36 725413.05 2.77 480899.94 725413.45 2.77 480899.94 725413.45 15.09 480896.36 725413.05 15.09 480896.36 725413.05 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480899.94 725413.45 2.77 480902.24 725414.64 2.77 480902.24 725414.64 15.09 480899.94 725413.45 15.09 480899.94 725413.45 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480902.24 725414.64 2.77 480903.74 725416.07 2.77 480903.74 725416.07 15.09 480902.24 725414.64 15.09 480902.24 725414.64 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480903.74 725416.07 2.77 480904.96 725418.05 2.77 480904.96 725418.05 15.09 480903.74 725416.07 15.09 480903.74 725416.07 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480904.96 725418.05 2.77 480905.65 725420.77 2.77 480905.65 725420.77 15.09 480904.96 725418.05 15.09 480904.96 725418.05 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480905.65 725420.77 2.77 480905.58 725422.88 2.77 480905.58 725422.88 15.09 480905.65 725420.77 15.09 480905.65 725420.77 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480905.58 725422.88 2.77 480904.97 725424.88 2.77 480904.97 725424.88 15.09 480905.58 725422.88 15.09 480905.58 725422.88 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480904.97 725424.88 2.77 480903.8 725426.79 2.77 480903.8 725426.79 15.09 480904.97 725424.88 15.09 480904.97 725424.88 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480903.8 725426.79 2.77 480902.58 725428.04 2.77 480902.58 725428.04 15.09 480903.8 725426.79 15.09 480903.8 725426.79 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480902.58 725428.04 2.77 480901.23 725428.93 2.77 480901.23 725428.93 15.09 480902.58 725428.04 15.09 480902.58 725428.04 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480901.23 725428.93 2.77 480897.92 725429.92 2.77 480897.92 725429.92 15.09 480901.23 725428.93 15.09 480901.23 725428.93 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480897.92 725429.92 2.77 480895.9 725429.85 2.77 480895.9 725429.85 15.09 480897.92 725429.92 15.09 480897.92 725429.92 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480895.9 725429.85 2.77 480893.06 725428.86 2.77 480893.06 725428.86 15.09 480895.9 725429.85 15.09 480895.9 725429.85 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480893.06 725428.86 2.77 480891.1 725427.34 2.77 480891.1 725427.34 15.09 480893.06 725428.86 15.09 480893.06 725428.86 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480891.1 725427.34 2.77 480890.18 725426.19 2.77 480890.18 725426.19 15.09 480891.1 725427.34 15.09 480891.1 725427.34 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480890.18 725426.19 2.77 480889.26 725424.4 2.77 480889.26 725424.4 15.09 480890.18 725426.19 15.09 480890.18 725426.19 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480889.26 725424.4 2.77 480888.8 725422.49 2.77 480888.8 725422.49 15.09 480889.26 725424.4 15.09 480889.26 725424.4 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480888.8 725422.49 2.77 480888.76 725421.12 2.77 480888.76 725421.12 15.09 480888.8 725422.49 15.09 480888.8 725422.49 2.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-03c27a72-fec6-48ca-afbb-95eee481c710_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480888.76 725421.12 15.09 480889.01 725419.35 15.09 480889.67 725417.6 15.09 480890.47 725416.36 15.09 480891.81 725414.95 15.09 480894.08 725413.6 15.09 480896.36 725413.05 15.09 480899.94 725413.45 15.09 480902.24 725414.64 15.09 480903.74 725416.07 15.09 480904.96 725418.05 15.09 480905.65 725420.77 15.09 480905.58 725422.88 15.09 480904.97 725424.88 15.09 480903.8 725426.79 15.09 480902.58 725428.04 15.09 480901.23 725428.93 15.09 480897.92 725429.92 15.09 480895.9 725429.85 15.09 480893.06 725428.86 15.09 480891.1 725427.34 15.09 480890.18 725426.19 15.09 480889.26 725424.4 15.09 480888.8 725422.49 15.09 480888.76 725421.12 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76">
			<gen:stringAttribute name="buildingId">
				<gen:value>1b02360b-ed4d-41e5-a55e-6081354f3a76</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480484.6 725369.14 2.13 480484.68 725372.27 2.13 480485.04 725375.32 2.13 480485.69 725378.38 2.13 480486.6 725381.31 2.13 480487.8 725384.2 2.13 480489.24 725386.92 2.13 480490.95 725389.54 2.13 480492.87 725391.95 2.13 480495.03 725394.21 2.13 480497.35 725396.22 2.13 480499.89 725398.05 2.13 480502.54 725399.6 2.13 480505.38 725400.93 2.13 480508.27 725401.96 2.13 480511.3 725402.74 2.13 480514.34 725403.24 2.13 480517.46 725403.44 2.13 480520.53 725403.37 2.13 480523.64 725403.01 2.13 480526.64 725402.37 2.13 480529.62 725401.44 2.13 480532.46 725400.26 2.13 480535.23 725398.79 2.13 480537.81 725397.12 2.13 480540.26 725395.17 2.13 480542.48 725393.04 2.13 480544.52 725390.68 2.13 480546.32 725388.18 2.13 480547.9 725385.48 2.13 480549.2 725382.69 2.13 480550.26 725379.76 2.13 480551.03 725376.78 2.13 480551.53 725373.7 2.13 480551.73 725370.62 2.13 480551.66 725367.5 2.13 480551.3 725364.44 2.13 480550.65 725361.38 2.13 480549.74 725358.45 2.13 480548.54 725355.56 2.13 480547.1 725352.84 2.13 480545.39 725350.23 2.13 480543.47 725347.81 2.13 480541.31 725345.56 2.13 480538.99 725343.54 2.13 480536.45 725341.72 2.13 480533.8 725340.17 2.13 480530.96 725338.84 2.13 480528.07 725337.8 2.13 480525.04 725337.02 2.13 480522.01 725336.52 2.13 480518.88 725336.31 2.13 480515.82 725336.39 2.13 480512.7 725336.76 2.13 480509.69 725337.39 2.13 480506.71 725338.32 2.13 480503.88 725339.5 2.13 480501.11 725340.97 2.13 480498.54 725342.64 2.13 480496.08 725344.59 2.13 480493.87 725346.72 2.13 480491.81 725349.08 2.13 480490.03 725351.58 2.13 480488.45 725354.28 2.13 480487.14 725357.06 2.13 480486.08 725360 2.13 480485.31 725362.98 2.13 480484.82 725366.07 2.13 480484.6 725369.14 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480484.6 725369.14 2.13 480484.82 725366.07 2.13 480484.82 725366.07 4.6000000000000005 480484.6 725369.14 4.6000000000000005 480484.6 725369.14 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480484.82 725366.07 2.13 480485.31 725362.98 2.13 480485.31 725362.98 4.6000000000000005 480484.82 725366.07 4.6000000000000005 480484.82 725366.07 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480485.31 725362.98 2.13 480486.08 725360 2.13 480486.08 725360 4.6000000000000005 480485.31 725362.98 4.6000000000000005 480485.31 725362.98 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480486.08 725360 2.13 480487.14 725357.06 2.13 480487.14 725357.06 4.6000000000000005 480486.08 725360 4.6000000000000005 480486.08 725360 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480487.14 725357.06 2.13 480488.45 725354.28 2.13 480488.45 725354.28 4.6000000000000005 480487.14 725357.06 4.6000000000000005 480487.14 725357.06 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480488.45 725354.28 2.13 480490.03 725351.58 2.13 480490.03 725351.58 4.6000000000000005 480488.45 725354.28 4.6000000000000005 480488.45 725354.28 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480490.03 725351.58 2.13 480491.81 725349.08 2.13 480491.81 725349.08 4.6000000000000005 480490.03 725351.58 4.6000000000000005 480490.03 725351.58 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480491.81 725349.08 2.13 480493.87 725346.72 2.13 480493.87 725346.72 4.6000000000000005 480491.81 725349.08 4.6000000000000005 480491.81 725349.08 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480493.87 725346.72 2.13 480496.08 725344.59 2.13 480496.08 725344.59 4.6000000000000005 480493.87 725346.72 4.6000000000000005 480493.87 725346.72 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480496.08 725344.59 2.13 480498.54 725342.64 2.13 480498.54 725342.64 4.6000000000000005 480496.08 725344.59 4.6000000000000005 480496.08 725344.59 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480498.54 725342.64 2.13 480501.11 725340.97 2.13 480501.11 725340.97 4.6000000000000005 480498.54 725342.64 4.6000000000000005 480498.54 725342.64 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480501.11 725340.97 2.13 480503.88 725339.5 2.13 480503.88 725339.5 4.6000000000000005 480501.11 725340.97 4.6000000000000005 480501.11 725340.97 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480503.88 725339.5 2.13 480506.71 725338.32 2.13 480506.71 725338.32 4.6000000000000005 480503.88 725339.5 4.6000000000000005 480503.88 725339.5 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480506.71 725338.32 2.13 480509.69 725337.39 2.13 480509.69 725337.39 4.6000000000000005 480506.71 725338.32 4.6000000000000005 480506.71 725338.32 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480509.69 725337.39 2.13 480512.7 725336.76 2.13 480512.7 725336.76 4.6000000000000005 480509.69 725337.39 4.6000000000000005 480509.69 725337.39 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480512.7 725336.76 2.13 480515.82 725336.39 2.13 480515.82 725336.39 4.6000000000000005 480512.7 725336.76 4.6000000000000005 480512.7 725336.76 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480515.82 725336.39 2.13 480518.88 725336.31 2.13 480518.88 725336.31 4.6000000000000005 480515.82 725336.39 4.6000000000000005 480515.82 725336.39 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480518.88 725336.31 2.13 480522.01 725336.52 2.13 480522.01 725336.52 4.6000000000000005 480518.88 725336.31 4.6000000000000005 480518.88 725336.31 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480522.01 725336.52 2.13 480525.04 725337.02 2.13 480525.04 725337.02 4.6000000000000005 480522.01 725336.52 4.6000000000000005 480522.01 725336.52 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480525.04 725337.02 2.13 480528.07 725337.8 2.13 480528.07 725337.8 4.6000000000000005 480525.04 725337.02 4.6000000000000005 480525.04 725337.02 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480528.07 725337.8 2.13 480530.96 725338.84 2.13 480530.96 725338.84 4.6000000000000005 480528.07 725337.8 4.6000000000000005 480528.07 725337.8 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480530.96 725338.84 2.13 480533.8 725340.17 2.13 480533.8 725340.17 4.6000000000000005 480530.96 725338.84 4.6000000000000005 480530.96 725338.84 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480533.8 725340.17 2.13 480536.45 725341.72 2.13 480536.45 725341.72 4.6000000000000005 480533.8 725340.17 4.6000000000000005 480533.8 725340.17 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480536.45 725341.72 2.13 480538.99 725343.54 2.13 480538.99 725343.54 4.6000000000000005 480536.45 725341.72 4.6000000000000005 480536.45 725341.72 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480538.99 725343.54 2.13 480541.31 725345.56 2.13 480541.31 725345.56 4.6000000000000005 480538.99 725343.54 4.6000000000000005 480538.99 725343.54 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480541.31 725345.56 2.13 480543.47 725347.81 2.13 480543.47 725347.81 4.6000000000000005 480541.31 725345.56 4.6000000000000005 480541.31 725345.56 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480543.47 725347.81 2.13 480545.39 725350.23 2.13 480545.39 725350.23 4.6000000000000005 480543.47 725347.81 4.6000000000000005 480543.47 725347.81 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480545.39 725350.23 2.13 480547.1 725352.84 2.13 480547.1 725352.84 4.6000000000000005 480545.39 725350.23 4.6000000000000005 480545.39 725350.23 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480547.1 725352.84 2.13 480548.54 725355.56 2.13 480548.54 725355.56 4.6000000000000005 480547.1 725352.84 4.6000000000000005 480547.1 725352.84 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480548.54 725355.56 2.13 480549.74 725358.45 2.13 480549.74 725358.45 4.6000000000000005 480548.54 725355.56 4.6000000000000005 480548.54 725355.56 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480549.74 725358.45 2.13 480550.65 725361.38 2.13 480550.65 725361.38 4.6000000000000005 480549.74 725358.45 4.6000000000000005 480549.74 725358.45 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480550.65 725361.38 2.13 480551.3 725364.44 2.13 480551.3 725364.44 4.6000000000000005 480550.65 725361.38 4.6000000000000005 480550.65 725361.38 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480551.3 725364.44 2.13 480551.66 725367.5 2.13 480551.66 725367.5 4.6000000000000005 480551.3 725364.44 4.6000000000000005 480551.3 725364.44 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480551.66 725367.5 2.13 480551.73 725370.62 2.13 480551.73 725370.62 4.6000000000000005 480551.66 725367.5 4.6000000000000005 480551.66 725367.5 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480551.73 725370.62 2.13 480551.53 725373.7 2.13 480551.53 725373.7 4.6000000000000005 480551.73 725370.62 4.6000000000000005 480551.73 725370.62 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480551.53 725373.7 2.13 480551.03 725376.78 2.13 480551.03 725376.78 4.6000000000000005 480551.53 725373.7 4.6000000000000005 480551.53 725373.7 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480551.03 725376.78 2.13 480550.26 725379.76 2.13 480550.26 725379.76 4.6000000000000005 480551.03 725376.78 4.6000000000000005 480551.03 725376.78 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480550.26 725379.76 2.13 480549.2 725382.69 2.13 480549.2 725382.69 4.6000000000000005 480550.26 725379.76 4.6000000000000005 480550.26 725379.76 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480549.2 725382.69 2.13 480547.9 725385.48 2.13 480547.9 725385.48 4.6000000000000005 480549.2 725382.69 4.6000000000000005 480549.2 725382.69 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480547.9 725385.48 2.13 480546.32 725388.18 2.13 480546.32 725388.18 4.6000000000000005 480547.9 725385.48 4.6000000000000005 480547.9 725385.48 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480546.32 725388.18 2.13 480544.52 725390.68 2.13 480544.52 725390.68 4.6000000000000005 480546.32 725388.18 4.6000000000000005 480546.32 725388.18 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480544.52 725390.68 2.13 480542.48 725393.04 2.13 480542.48 725393.04 4.6000000000000005 480544.52 725390.68 4.6000000000000005 480544.52 725390.68 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480542.48 725393.04 2.13 480540.26 725395.17 2.13 480540.26 725395.17 4.6000000000000005 480542.48 725393.04 4.6000000000000005 480542.48 725393.04 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480540.26 725395.17 2.13 480537.81 725397.12 2.13 480537.81 725397.12 4.6000000000000005 480540.26 725395.17 4.6000000000000005 480540.26 725395.17 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480537.81 725397.12 2.13 480535.23 725398.79 2.13 480535.23 725398.79 4.6000000000000005 480537.81 725397.12 4.6000000000000005 480537.81 725397.12 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480535.23 725398.79 2.13 480532.46 725400.26 2.13 480532.46 725400.26 4.6000000000000005 480535.23 725398.79 4.6000000000000005 480535.23 725398.79 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480532.46 725400.26 2.13 480529.62 725401.44 2.13 480529.62 725401.44 4.6000000000000005 480532.46 725400.26 4.6000000000000005 480532.46 725400.26 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480529.62 725401.44 2.13 480526.64 725402.37 2.13 480526.64 725402.37 4.6000000000000005 480529.62 725401.44 4.6000000000000005 480529.62 725401.44 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480526.64 725402.37 2.13 480523.64 725403.01 2.13 480523.64 725403.01 4.6000000000000005 480526.64 725402.37 4.6000000000000005 480526.64 725402.37 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480523.64 725403.01 2.13 480520.53 725403.37 2.13 480520.53 725403.37 4.6000000000000005 480523.64 725403.01 4.6000000000000005 480523.64 725403.01 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480520.53 725403.37 2.13 480517.46 725403.44 2.13 480517.46 725403.44 4.6000000000000005 480520.53 725403.37 4.6000000000000005 480520.53 725403.37 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480517.46 725403.44 2.13 480514.34 725403.24 2.13 480514.34 725403.24 4.6000000000000005 480517.46 725403.44 4.6000000000000005 480517.46 725403.44 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480514.34 725403.24 2.13 480511.3 725402.74 2.13 480511.3 725402.74 4.6000000000000005 480514.34 725403.24 4.6000000000000005 480514.34 725403.24 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480511.3 725402.74 2.13 480508.27 725401.96 2.13 480508.27 725401.96 4.6000000000000005 480511.3 725402.74 4.6000000000000005 480511.3 725402.74 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480508.27 725401.96 2.13 480505.38 725400.93 2.13 480505.38 725400.93 4.6000000000000005 480508.27 725401.96 4.6000000000000005 480508.27 725401.96 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480505.38 725400.93 2.13 480502.54 725399.6 2.13 480502.54 725399.6 4.6000000000000005 480505.38 725400.93 4.6000000000000005 480505.38 725400.93 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480502.54 725399.6 2.13 480499.89 725398.05 2.13 480499.89 725398.05 4.6000000000000005 480502.54 725399.6 4.6000000000000005 480502.54 725399.6 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480499.89 725398.05 2.13 480497.35 725396.22 2.13 480497.35 725396.22 4.6000000000000005 480499.89 725398.05 4.6000000000000005 480499.89 725398.05 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480497.35 725396.22 2.13 480495.03 725394.21 2.13 480495.03 725394.21 4.6000000000000005 480497.35 725396.22 4.6000000000000005 480497.35 725396.22 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480495.03 725394.21 2.13 480492.87 725391.95 2.13 480492.87 725391.95 4.6000000000000005 480495.03 725394.21 4.6000000000000005 480495.03 725394.21 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480492.87 725391.95 2.13 480490.95 725389.54 2.13 480490.95 725389.54 4.6000000000000005 480492.87 725391.95 4.6000000000000005 480492.87 725391.95 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480490.95 725389.54 2.13 480489.24 725386.92 2.13 480489.24 725386.92 4.6000000000000005 480490.95 725389.54 4.6000000000000005 480490.95 725389.54 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480489.24 725386.92 2.13 480487.8 725384.2 2.13 480487.8 725384.2 4.6000000000000005 480489.24 725386.92 4.6000000000000005 480489.24 725386.92 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480487.8 725384.2 2.13 480486.6 725381.31 2.13 480486.6 725381.31 4.6000000000000005 480487.8 725384.2 4.6000000000000005 480487.8 725384.2 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480486.6 725381.31 2.13 480485.69 725378.38 2.13 480485.69 725378.38 4.6000000000000005 480486.6 725381.31 4.6000000000000005 480486.6 725381.31 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480485.69 725378.38 2.13 480485.04 725375.32 2.13 480485.04 725375.32 4.6000000000000005 480485.69 725378.38 4.6000000000000005 480485.69 725378.38 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480485.04 725375.32 2.13 480484.68 725372.27 2.13 480484.68 725372.27 4.6000000000000005 480485.04 725375.32 4.6000000000000005 480485.04 725375.32 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480484.68 725372.27 2.13 480484.6 725369.14 2.13 480484.6 725369.14 4.6000000000000005 480484.68 725372.27 4.6000000000000005 480484.68 725372.27 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1b02360b-ed4d-41e5-a55e-6081354f3a76_PG_70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480484.6 725369.14 4.6000000000000005 480484.82 725366.07 4.6000000000000005 480485.31 725362.98 4.6000000000000005 480486.08 725360 4.6000000000000005 480487.14 725357.06 4.6000000000000005 480488.45 725354.28 4.6000000000000005 480490.03 725351.58 4.6000000000000005 480491.81 725349.08 4.6000000000000005 480493.87 725346.72 4.6000000000000005 480496.08 725344.59 4.6000000000000005 480498.54 725342.64 4.6000000000000005 480501.11 725340.97 4.6000000000000005 480503.88 725339.5 4.6000000000000005 480506.71 725338.32 4.6000000000000005 480509.69 725337.39 4.6000000000000005 480512.7 725336.76 4.6000000000000005 480515.82 725336.39 4.6000000000000005 480518.88 725336.31 4.6000000000000005 480522.01 725336.52 4.6000000000000005 480525.04 725337.02 4.6000000000000005 480528.07 725337.8 4.6000000000000005 480530.96 725338.84 4.6000000000000005 480533.8 725340.17 4.6000000000000005 480536.45 725341.72 4.6000000000000005 480538.99 725343.54 4.6000000000000005 480541.31 725345.56 4.6000000000000005 480543.47 725347.81 4.6000000000000005 480545.39 725350.23 4.6000000000000005 480547.1 725352.84 4.6000000000000005 480548.54 725355.56 4.6000000000000005 480549.74 725358.45 4.6000000000000005 480550.65 725361.38 4.6000000000000005 480551.3 725364.44 4.6000000000000005 480551.66 725367.5 4.6000000000000005 480551.73 725370.62 4.6000000000000005 480551.53 725373.7 4.6000000000000005 480551.03 725376.78 4.6000000000000005 480550.26 725379.76 4.6000000000000005 480549.2 725382.69 4.6000000000000005 480547.9 725385.48 4.6000000000000005 480546.32 725388.18 4.6000000000000005 480544.52 725390.68 4.6000000000000005 480542.48 725393.04 4.6000000000000005 480540.26 725395.17 4.6000000000000005 480537.81 725397.12 4.6000000000000005 480535.23 725398.79 4.6000000000000005 480532.46 725400.26 4.6000000000000005 480529.62 725401.44 4.6000000000000005 480526.64 725402.37 4.6000000000000005 480523.64 725403.01 4.6000000000000005 480520.53 725403.37 4.6000000000000005 480517.46 725403.44 4.6000000000000005 480514.34 725403.24 4.6000000000000005 480511.3 725402.74 4.6000000000000005 480508.27 725401.96 4.6000000000000005 480505.38 725400.93 4.6000000000000005 480502.54 725399.6 4.6000000000000005 480499.89 725398.05 4.6000000000000005 480497.35 725396.22 4.6000000000000005 480495.03 725394.21 4.6000000000000005 480492.87 725391.95 4.6000000000000005 480490.95 725389.54 4.6000000000000005 480489.24 725386.92 4.6000000000000005 480487.8 725384.2 4.6000000000000005 480486.6 725381.31 4.6000000000000005 480485.69 725378.38 4.6000000000000005 480485.04 725375.32 4.6000000000000005 480484.68 725372.27 4.6000000000000005 480484.6 725369.14 4.6000000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9">
			<gen:stringAttribute name="buildingId">
				<gen:value>a89a55a9-5260-44e3-89a9-aa46defe6df9</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480388.5 725317.36 2 480388.76 725320.52 2 480389.29 725323.53 2 480390.13 725326.58 2 480391.2 725329.43 2 480392.59 725332.29 2 480394.15 725334.88 2 480396.06 725337.45 2 480398.07 725339.7 2 480400.41 725341.88 2 480402.8 725343.72 2 480405.51 725345.43 2 480408.18 725346.81 2 480411.17 725347.99 2 480414.05 725348.84 2 480417.2 725349.46 2 480420.19 725349.76 2 480423.39 725349.8 2 480426.39 725349.56 2 480429.53 725348.99 2 480432.45 725348.2 2 480435.43 725347.08 2 480438.15 725345.75 2 480440.88 725344.11 2 480443.31 725342.3 2 480445.68 725340.2 2 480447.75 725337.97 2 480449.68 725335.46 2 480451.31 725332.88 2 480452.75 725330.08 2 480453.89 725327.24 2 480454.78 725324.24 2 480455.37 725321.21 2 480455.7 725318.11 2 480455.73 725315.01 2 480455.48 725311.91 2 480454.94 725308.85 2 480454.14 725305.87 2 480453.04 725302.94 2 480451.7 725300.17 2 480450.08 725297.49 2 480448.26 725295.01 2 480446.16 725292.68 2 480443.93 725290.58 2 480441.43 725288.66 2 480438.84 725287 2 480436.05 725285.57 2 480433.2 725284.42 2 480430.18 725283.54 2 480427.18 725282.93 2 480424.04 725282.61 2 480420.97 725282.57 2 480417.84 725282.82 2 480414.82 725283.36 2 480411.78 725284.18 2 480408.9 725285.26 2 480406.08 725286.62 2 480403.43 725288.21 2 480400.92 725290.07 2 480398.6 725292.13 2 480396.49 725294.41 2 480394.57 725296.88 2 480392.92 725299.49 2 480391.49 725302.28 2 480390.34 725305.14 2 480389.45 725308.15 2 480388.86 725311.17 2 480388.53 725314.3 2 480388.5 725317.36 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480388.5 725317.36 2 480388.53 725314.3 2 480388.53 725314.3 7.94 480388.5 725317.36 7.94 480388.5 725317.36 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480388.53 725314.3 2 480388.86 725311.17 2 480388.86 725311.17 7.94 480388.53 725314.3 7.94 480388.53 725314.3 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480388.86 725311.17 2 480389.45 725308.15 2 480389.45 725308.15 7.94 480388.86 725311.17 7.94 480388.86 725311.17 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480389.45 725308.15 2 480390.34 725305.14 2 480390.34 725305.14 7.94 480389.45 725308.15 7.94 480389.45 725308.15 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480390.34 725305.14 2 480391.49 725302.28 2 480391.49 725302.28 7.94 480390.34 725305.14 7.94 480390.34 725305.14 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480391.49 725302.28 2 480392.92 725299.49 2 480392.92 725299.49 7.94 480391.49 725302.28 7.94 480391.49 725302.28 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480392.92 725299.49 2 480394.57 725296.88 2 480394.57 725296.88 7.94 480392.92 725299.49 7.94 480392.92 725299.49 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480394.57 725296.88 2 480396.49 725294.41 2 480396.49 725294.41 7.94 480394.57 725296.88 7.94 480394.57 725296.88 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480396.49 725294.41 2 480398.6 725292.13 2 480398.6 725292.13 7.94 480396.49 725294.41 7.94 480396.49 725294.41 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480398.6 725292.13 2 480400.92 725290.07 2 480400.92 725290.07 7.94 480398.6 725292.13 7.94 480398.6 725292.13 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480400.92 725290.07 2 480403.43 725288.21 2 480403.43 725288.21 7.94 480400.92 725290.07 7.94 480400.92 725290.07 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480403.43 725288.21 2 480406.08 725286.62 2 480406.08 725286.62 7.94 480403.43 725288.21 7.94 480403.43 725288.21 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480406.08 725286.62 2 480408.9 725285.26 2 480408.9 725285.26 7.94 480406.08 725286.62 7.94 480406.08 725286.62 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480408.9 725285.26 2 480411.78 725284.18 2 480411.78 725284.18 7.94 480408.9 725285.26 7.94 480408.9 725285.26 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480411.78 725284.18 2 480414.82 725283.36 2 480414.82 725283.36 7.94 480411.78 725284.18 7.94 480411.78 725284.18 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480414.82 725283.36 2 480417.84 725282.82 2 480417.84 725282.82 7.94 480414.82 725283.36 7.94 480414.82 725283.36 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480417.84 725282.82 2 480420.97 725282.57 2 480420.97 725282.57 7.94 480417.84 725282.82 7.94 480417.84 725282.82 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480420.97 725282.57 2 480424.04 725282.61 2 480424.04 725282.61 7.94 480420.97 725282.57 7.94 480420.97 725282.57 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480424.04 725282.61 2 480427.18 725282.93 2 480427.18 725282.93 7.94 480424.04 725282.61 7.94 480424.04 725282.61 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480427.18 725282.93 2 480430.18 725283.54 2 480430.18 725283.54 7.94 480427.18 725282.93 7.94 480427.18 725282.93 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480430.18 725283.54 2 480433.2 725284.42 2 480433.2 725284.42 7.94 480430.18 725283.54 7.94 480430.18 725283.54 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480433.2 725284.42 2 480436.05 725285.57 2 480436.05 725285.57 7.94 480433.2 725284.42 7.94 480433.2 725284.42 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480436.05 725285.57 2 480438.84 725287 2 480438.84 725287 7.94 480436.05 725285.57 7.94 480436.05 725285.57 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480438.84 725287 2 480441.43 725288.66 2 480441.43 725288.66 7.94 480438.84 725287 7.94 480438.84 725287 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480441.43 725288.66 2 480443.93 725290.58 2 480443.93 725290.58 7.94 480441.43 725288.66 7.94 480441.43 725288.66 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480443.93 725290.58 2 480446.16 725292.68 2 480446.16 725292.68 7.94 480443.93 725290.58 7.94 480443.93 725290.58 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480446.16 725292.68 2 480448.26 725295.01 2 480448.26 725295.01 7.94 480446.16 725292.68 7.94 480446.16 725292.68 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480448.26 725295.01 2 480450.08 725297.49 2 480450.08 725297.49 7.94 480448.26 725295.01 7.94 480448.26 725295.01 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480450.08 725297.49 2 480451.7 725300.17 2 480451.7 725300.17 7.94 480450.08 725297.49 7.94 480450.08 725297.49 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480451.7 725300.17 2 480453.04 725302.94 2 480453.04 725302.94 7.94 480451.7 725300.17 7.94 480451.7 725300.17 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480453.04 725302.94 2 480454.14 725305.87 2 480454.14 725305.87 7.94 480453.04 725302.94 7.94 480453.04 725302.94 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480454.14 725305.87 2 480454.94 725308.85 2 480454.94 725308.85 7.94 480454.14 725305.87 7.94 480454.14 725305.87 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480454.94 725308.85 2 480455.48 725311.91 2 480455.48 725311.91 7.94 480454.94 725308.85 7.94 480454.94 725308.85 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480455.48 725311.91 2 480455.73 725315.01 2 480455.73 725315.01 7.94 480455.48 725311.91 7.94 480455.48 725311.91 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480455.73 725315.01 2 480455.7 725318.11 2 480455.7 725318.11 7.94 480455.73 725315.01 7.94 480455.73 725315.01 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480455.7 725318.11 2 480455.37 725321.21 2 480455.37 725321.21 7.94 480455.7 725318.11 7.94 480455.7 725318.11 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480455.37 725321.21 2 480454.78 725324.24 2 480454.78 725324.24 7.94 480455.37 725321.21 7.94 480455.37 725321.21 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480454.78 725324.24 2 480453.89 725327.24 2 480453.89 725327.24 7.94 480454.78 725324.24 7.94 480454.78 725324.24 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480453.89 725327.24 2 480452.75 725330.08 2 480452.75 725330.08 7.94 480453.89 725327.24 7.94 480453.89 725327.24 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480452.75 725330.08 2 480451.31 725332.88 2 480451.31 725332.88 7.94 480452.75 725330.08 7.94 480452.75 725330.08 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480451.31 725332.88 2 480449.68 725335.46 2 480449.68 725335.46 7.94 480451.31 725332.88 7.94 480451.31 725332.88 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480449.68 725335.46 2 480447.75 725337.97 2 480447.75 725337.97 7.94 480449.68 725335.46 7.94 480449.68 725335.46 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480447.75 725337.97 2 480445.68 725340.2 2 480445.68 725340.2 7.94 480447.75 725337.97 7.94 480447.75 725337.97 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480445.68 725340.2 2 480443.31 725342.3 2 480443.31 725342.3 7.94 480445.68 725340.2 7.94 480445.68 725340.2 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480443.31 725342.3 2 480440.88 725344.11 2 480440.88 725344.11 7.94 480443.31 725342.3 7.94 480443.31 725342.3 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480440.88 725344.11 2 480438.15 725345.75 2 480438.15 725345.75 7.94 480440.88 725344.11 7.94 480440.88 725344.11 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480438.15 725345.75 2 480435.43 725347.08 2 480435.43 725347.08 7.94 480438.15 725345.75 7.94 480438.15 725345.75 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480435.43 725347.08 2 480432.45 725348.2 2 480432.45 725348.2 7.94 480435.43 725347.08 7.94 480435.43 725347.08 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480432.45 725348.2 2 480429.53 725348.99 2 480429.53 725348.99 7.94 480432.45 725348.2 7.94 480432.45 725348.2 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480429.53 725348.99 2 480426.39 725349.56 2 480426.39 725349.56 7.94 480429.53 725348.99 7.94 480429.53 725348.99 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480426.39 725349.56 2 480423.39 725349.8 2 480423.39 725349.8 7.94 480426.39 725349.56 7.94 480426.39 725349.56 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480423.39 725349.8 2 480420.19 725349.76 2 480420.19 725349.76 7.94 480423.39 725349.8 7.94 480423.39 725349.8 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480420.19 725349.76 2 480417.2 725349.46 2 480417.2 725349.46 7.94 480420.19 725349.76 7.94 480420.19 725349.76 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480417.2 725349.46 2 480414.05 725348.84 2 480414.05 725348.84 7.94 480417.2 725349.46 7.94 480417.2 725349.46 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480414.05 725348.84 2 480411.17 725347.99 2 480411.17 725347.99 7.94 480414.05 725348.84 7.94 480414.05 725348.84 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480411.17 725347.99 2 480408.18 725346.81 2 480408.18 725346.81 7.94 480411.17 725347.99 7.94 480411.17 725347.99 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480408.18 725346.81 2 480405.51 725345.43 2 480405.51 725345.43 7.94 480408.18 725346.81 7.94 480408.18 725346.81 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480405.51 725345.43 2 480402.8 725343.72 2 480402.8 725343.72 7.94 480405.51 725345.43 7.94 480405.51 725345.43 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480402.8 725343.72 2 480400.41 725341.88 2 480400.41 725341.88 7.94 480402.8 725343.72 7.94 480402.8 725343.72 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480400.41 725341.88 2 480398.07 725339.7 2 480398.07 725339.7 7.94 480400.41 725341.88 7.94 480400.41 725341.88 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480398.07 725339.7 2 480396.06 725337.45 2 480396.06 725337.45 7.94 480398.07 725339.7 7.94 480398.07 725339.7 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480396.06 725337.45 2 480394.15 725334.88 2 480394.15 725334.88 7.94 480396.06 725337.45 7.94 480396.06 725337.45 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480394.15 725334.88 2 480392.59 725332.29 2 480392.59 725332.29 7.94 480394.15 725334.88 7.94 480394.15 725334.88 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480392.59 725332.29 2 480391.2 725329.43 2 480391.2 725329.43 7.94 480392.59 725332.29 7.94 480392.59 725332.29 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480391.2 725329.43 2 480390.13 725326.58 2 480390.13 725326.58 7.94 480391.2 725329.43 7.94 480391.2 725329.43 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480390.13 725326.58 2 480389.29 725323.53 2 480389.29 725323.53 7.94 480390.13 725326.58 7.94 480390.13 725326.58 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480389.29 725323.53 2 480388.76 725320.52 2 480388.76 725320.52 7.94 480389.29 725323.53 7.94 480389.29 725323.53 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480388.76 725320.52 2 480388.5 725317.36 2 480388.5 725317.36 7.94 480388.76 725320.52 7.94 480388.76 725320.52 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a89a55a9-5260-44e3-89a9-aa46defe6df9_PG_70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480388.5 725317.36 7.94 480388.53 725314.3 7.94 480388.86 725311.17 7.94 480389.45 725308.15 7.94 480390.34 725305.14 7.94 480391.49 725302.28 7.94 480392.92 725299.49 7.94 480394.57 725296.88 7.94 480396.49 725294.41 7.94 480398.6 725292.13 7.94 480400.92 725290.07 7.94 480403.43 725288.21 7.94 480406.08 725286.62 7.94 480408.9 725285.26 7.94 480411.78 725284.18 7.94 480414.82 725283.36 7.94 480417.84 725282.82 7.94 480420.97 725282.57 7.94 480424.04 725282.61 7.94 480427.18 725282.93 7.94 480430.18 725283.54 7.94 480433.2 725284.42 7.94 480436.05 725285.57 7.94 480438.84 725287 7.94 480441.43 725288.66 7.94 480443.93 725290.58 7.94 480446.16 725292.68 7.94 480448.26 725295.01 7.94 480450.08 725297.49 7.94 480451.7 725300.17 7.94 480453.04 725302.94 7.94 480454.14 725305.87 7.94 480454.94 725308.85 7.94 480455.48 725311.91 7.94 480455.73 725315.01 7.94 480455.7 725318.11 7.94 480455.37 725321.21 7.94 480454.78 725324.24 7.94 480453.89 725327.24 7.94 480452.75 725330.08 7.94 480451.31 725332.88 7.94 480449.68 725335.46 7.94 480447.75 725337.97 7.94 480445.68 725340.2 7.94 480443.31 725342.3 7.94 480440.88 725344.11 7.94 480438.15 725345.75 7.94 480435.43 725347.08 7.94 480432.45 725348.2 7.94 480429.53 725348.99 7.94 480426.39 725349.56 7.94 480423.39 725349.8 7.94 480420.19 725349.76 7.94 480417.2 725349.46 7.94 480414.05 725348.84 7.94 480411.17 725347.99 7.94 480408.18 725346.81 7.94 480405.51 725345.43 7.94 480402.8 725343.72 7.94 480400.41 725341.88 7.94 480398.07 725339.7 7.94 480396.06 725337.45 7.94 480394.15 725334.88 7.94 480392.59 725332.29 7.94 480391.2 725329.43 7.94 480390.13 725326.58 7.94 480389.29 725323.53 7.94 480388.76 725320.52 7.94 480388.5 725317.36 7.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61">
			<gen:stringAttribute name="buildingId">
				<gen:value>50f38e90-0544-411a-86d9-9a11ced5ba61</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">17.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480372.91 724252.81 3.9 480359.01 724270.35 3.9 480358.83 724270.21 3.9 480325.11 724312.85 3.9 480322.15 724310.5 3.9 480307.03 724329.52 3.9 480310.02 724331.88 3.9 480261.31 724393.33 3.9 480261.47 724393.46 3.9 480251.25 724406.36 3.9 480270.22 724421.39 3.9 480270.09 724421.54 3.9 480312.46 724455.14 3.9 480434.38 724301.32 3.9 480392 724267.69 3.9 480391.89 724267.86 3.9 480372.91 724252.81 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480372.91 724252.81 3.9 480391.89 724267.86 3.9 480391.89 724267.86 21.89 480372.91 724252.81 21.89 480372.91 724252.81 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480391.89 724267.86 3.9 480392 724267.69 3.9 480392 724267.69 21.89 480391.89 724267.86 21.89 480391.89 724267.86 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480392 724267.69 3.9 480434.38 724301.32 3.9 480434.38 724301.32 21.89 480392 724267.69 21.89 480392 724267.69 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480434.38 724301.32 3.9 480312.46 724455.14 3.9 480312.46 724455.14 21.89 480434.38 724301.32 21.89 480434.38 724301.32 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480312.46 724455.14 3.9 480270.09 724421.54 3.9 480270.09 724421.54 21.89 480312.46 724455.14 21.89 480312.46 724455.14 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480270.09 724421.54 3.9 480270.22 724421.39 3.9 480270.22 724421.39 21.89 480270.09 724421.54 21.89 480270.09 724421.54 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480270.22 724421.39 3.9 480251.25 724406.36 3.9 480251.25 724406.36 21.89 480270.22 724421.39 21.89 480270.22 724421.39 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480251.25 724406.36 3.9 480261.47 724393.46 3.9 480261.47 724393.46 21.89 480251.25 724406.36 21.89 480251.25 724406.36 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480261.47 724393.46 3.9 480261.31 724393.33 3.9 480261.31 724393.33 21.89 480261.47 724393.46 21.89 480261.47 724393.46 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480261.31 724393.33 3.9 480310.02 724331.88 3.9 480310.02 724331.88 21.89 480261.31 724393.33 21.89 480261.31 724393.33 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480310.02 724331.88 3.9 480307.03 724329.52 3.9 480307.03 724329.52 21.89 480310.02 724331.88 21.89 480310.02 724331.88 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480307.03 724329.52 3.9 480322.15 724310.5 3.9 480322.15 724310.5 21.89 480307.03 724329.52 21.89 480307.03 724329.52 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480322.15 724310.5 3.9 480325.11 724312.85 3.9 480325.11 724312.85 21.89 480322.15 724310.5 21.89 480322.15 724310.5 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480325.11 724312.85 3.9 480358.83 724270.21 3.9 480358.83 724270.21 21.89 480325.11 724312.85 21.89 480325.11 724312.85 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480358.83 724270.21 3.9 480359.01 724270.35 3.9 480359.01 724270.35 21.89 480358.83 724270.21 21.89 480358.83 724270.21 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480359.01 724270.35 3.9 480372.91 724252.81 3.9 480372.91 724252.81 21.89 480359.01 724270.35 21.89 480359.01 724270.35 3.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50f38e90-0544-411a-86d9-9a11ced5ba61_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480372.91 724252.81 21.89 480391.89 724267.86 21.89 480392 724267.69 21.89 480434.38 724301.32 21.89 480312.46 724455.14 21.89 480270.09 724421.54 21.89 480270.22 724421.39 21.89 480251.25 724406.36 21.89 480261.47 724393.46 21.89 480261.31 724393.33 21.89 480310.02 724331.88 21.89 480307.03 724329.52 21.89 480322.15 724310.5 21.89 480325.11 724312.85 21.89 480358.83 724270.21 21.89 480359.01 724270.35 21.89 480372.91 724252.81 21.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7913-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.34</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479850.93 725039.77 2.54 479851.83 725042.03 2.54 479863.24 725037.31 2.54 479853.46 725013.6 2.54 479853.74 725013.48 2.54 479839.65 724979.8 2.54 479827.83 724984.8 2.54 479842.03 725018.34 2.54 479842.32 725018.23 2.54 479846.82 725029.49 2.54 479844.56 725030.53 2.54 479848.63 725040.7 2.54 479850.93 725039.77 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479850.93 725039.77 2.54 479848.63 725040.7 2.54 479848.63 725040.7 9.88 479850.93 725039.77 9.88 479850.93 725039.77 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479848.63 725040.7 2.54 479844.56 725030.53 2.54 479844.56 725030.53 9.88 479848.63 725040.7 9.88 479848.63 725040.7 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479844.56 725030.53 2.54 479846.82 725029.49 2.54 479846.82 725029.49 9.88 479844.56 725030.53 9.88 479844.56 725030.53 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479846.82 725029.49 2.54 479842.32 725018.23 2.54 479842.32 725018.23 9.88 479846.82 725029.49 9.88 479846.82 725029.49 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479842.32 725018.23 2.54 479842.03 725018.34 2.54 479842.03 725018.34 9.88 479842.32 725018.23 9.88 479842.32 725018.23 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479842.03 725018.34 2.54 479827.83 724984.8 2.54 479827.83 724984.8 9.88 479842.03 725018.34 9.88 479842.03 725018.34 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479827.83 724984.8 2.54 479839.65 724979.8 2.54 479839.65 724979.8 9.88 479827.83 724984.8 9.88 479827.83 724984.8 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479839.65 724979.8 2.54 479853.74 725013.48 2.54 479853.74 725013.48 9.88 479839.65 724979.8 9.88 479839.65 724979.8 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479853.74 725013.48 2.54 479853.46 725013.6 2.54 479853.46 725013.6 9.88 479853.74 725013.48 9.88 479853.74 725013.48 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479853.46 725013.6 2.54 479863.24 725037.31 2.54 479863.24 725037.31 9.88 479853.46 725013.6 9.88 479853.46 725013.6 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479863.24 725037.31 2.54 479851.83 725042.03 2.54 479851.83 725042.03 9.88 479863.24 725037.31 9.88 479863.24 725037.31 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479851.83 725042.03 2.54 479850.93 725039.77 2.54 479850.93 725039.77 9.88 479851.83 725042.03 9.88 479851.83 725042.03 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7913-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479850.93 725039.77 9.88 479848.63 725040.7 9.88 479844.56 725030.53 9.88 479846.82 725029.49 9.88 479842.32 725018.23 9.88 479842.03 725018.34 9.88 479827.83 724984.8 9.88 479839.65 724979.8 9.88 479853.74 725013.48 9.88 479853.46 725013.6 9.88 479863.24 725037.31 9.88 479851.83 725042.03 9.88 479850.93 725039.77 9.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-79C8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-79C8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">18.06</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79C8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479863.71 725619.54 3.51 479827.3 725616.82 3.51 479824.79 725652.89 3.51 479857.36 725655.32 3.51 479861.01 725655.57 3.51 479861.45 725649.74 3.51 479861.58 725648.1 3.51 479863.71 725619.54 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79C8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479863.71 725619.54 3.51 479861.58 725648.1 3.51 479861.58 725648.1 21.57 479863.71 725619.54 21.57 479863.71 725619.54 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79C8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479861.58 725648.1 3.51 479861.45 725649.74 3.51 479861.45 725649.74 21.57 479861.58 725648.1 21.57 479861.58 725648.1 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79C8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479861.45 725649.74 3.51 479861.01 725655.57 3.51 479861.01 725655.57 21.57 479861.45 725649.74 21.57 479861.45 725649.74 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79C8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479861.01 725655.57 3.51 479857.36 725655.32 3.51 479857.36 725655.32 21.57 479861.01 725655.57 21.57 479861.01 725655.57 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79C8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479857.36 725655.32 3.51 479824.79 725652.89 3.51 479824.79 725652.89 21.57 479857.36 725655.32 21.57 479857.36 725655.32 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79C8-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479824.79 725652.89 3.51 479827.3 725616.82 3.51 479827.3 725616.82 21.57 479824.79 725652.89 21.57 479824.79 725652.89 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79C8-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479827.3 725616.82 3.51 479863.71 725619.54 3.51 479863.71 725619.54 21.57 479827.3 725616.82 21.57 479827.3 725616.82 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79C8-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479863.71 725619.54 21.57 479861.58 725648.1 21.57 479861.45 725649.74 21.57 479861.01 725655.57 21.57 479857.36 725655.32 21.57 479824.79 725652.89 21.57 479827.3 725616.82 21.57 479863.71 725619.54 21.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-7b2f2677-2bdc-497e-9642-91a0f6e48fa7">
			<gen:stringAttribute name="buildingId">
				<gen:value>7b2f2677-2bdc-497e-9642-91a0f6e48fa7</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.66</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7b2f2677-2bdc-497e-9642-91a0f6e48fa7_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480736.45 724730.75 2.8 480749.83 724739.93 2.8 480760.22 724724.86 2.8 480746.78 724715.66 2.8 480736.45 724730.75 2.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7b2f2677-2bdc-497e-9642-91a0f6e48fa7_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480736.45 724730.75 2.8 480746.78 724715.66 2.8 480746.78 724715.66 6.46 480736.45 724730.75 6.46 480736.45 724730.75 2.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7b2f2677-2bdc-497e-9642-91a0f6e48fa7_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480746.78 724715.66 2.8 480760.22 724724.86 2.8 480760.22 724724.86 6.46 480746.78 724715.66 6.46 480746.78 724715.66 2.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7b2f2677-2bdc-497e-9642-91a0f6e48fa7_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480760.22 724724.86 2.8 480749.83 724739.93 2.8 480749.83 724739.93 6.46 480760.22 724724.86 6.46 480760.22 724724.86 2.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7b2f2677-2bdc-497e-9642-91a0f6e48fa7_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480749.83 724739.93 2.8 480736.45 724730.75 2.8 480736.45 724730.75 6.46 480749.83 724739.93 6.46 480749.83 724739.93 2.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7b2f2677-2bdc-497e-9642-91a0f6e48fa7_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480736.45 724730.75 6.46 480746.78 724715.66 6.46 480760.22 724724.86 6.46 480749.83 724739.93 6.46 480736.45 724730.75 6.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da">
			<gen:stringAttribute name="buildingId">
				<gen:value>be3e25cd-2020-4987-9958-4fb6292bc7da</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">18.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480631.84 725329.36 2.04 480632.31 725333.52 2.04 480633.01 725336.76 2.04 480634.49 725341.16 2.04 480636.19 725344.71 2.04 480637.88 725347.49 2.04 480640.91 725351.41 2.04 480644.6 725355.01 2.04 480648.39 725357.81 2.04 480652.61 725360.14 2.04 480656.83 725361.79 2.04 480659.9 725362.62 2.04 480664.9 725363.39 2.04 480669.06 725363.49 2.04 480674.55 725362.89 2.04 480680.04 725361.41 2.04 480684.29 725359.56 2.04 480688.79 725356.83 2.04 480691.89 725354.35 2.04 480695.84 725350.23 2.04 480698.14 725347.06 2.04 480700.61 725342.58 2.04 480701.39 725340.8 2.04 480702.53 725337.45 2.04 480703.29 725334.29 2.04 480703.88 725329.6 2.04 480703.92 725325.97 2.04 480703.42 725321.33 2.04 480702.49 725317.33 2.04 480700.54 725312.14 2.04 480698.01 725307.63 2.04 480694.74 725303.38 2.04 480691.21 725299.94 2.04 480688.7 725297.99 2.04 480683.57 725294.96 2.04 480681.09 725293.88 2.04 480678.96 725293.12 2.04 480675.61 725292.21 2.04 480672.33 725291.65 2.04 480667.72 725291.36 2.04 480664.12 725291.56 2.04 480659.32 725292.39 2.04 480654.51 725293.94 2.04 480650.93 725295.59 2.04 480647.19 725297.88 2.04 480643.94 725300.44 2.04 480641.5 725302.82 2.04 480639.03 725305.77 2.04 480636.8 725309.11 2.04 480634.81 725313.01 2.04 480633.31 725317.09 2.04 480632.36 725321.09 2.04 480631.84 725325.58 2.04 480631.84 725329.36 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480631.84 725329.36 2.04 480631.84 725325.58 2.04 480631.84 725325.58 20.330000000000002 480631.84 725329.36 20.330000000000002 480631.84 725329.36 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480631.84 725325.58 2.04 480632.36 725321.09 2.04 480632.36 725321.09 20.330000000000002 480631.84 725325.58 20.330000000000002 480631.84 725325.58 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480632.36 725321.09 2.04 480633.31 725317.09 2.04 480633.31 725317.09 20.330000000000002 480632.36 725321.09 20.330000000000002 480632.36 725321.09 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480633.31 725317.09 2.04 480634.81 725313.01 2.04 480634.81 725313.01 20.330000000000002 480633.31 725317.09 20.330000000000002 480633.31 725317.09 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480634.81 725313.01 2.04 480636.8 725309.11 2.04 480636.8 725309.11 20.330000000000002 480634.81 725313.01 20.330000000000002 480634.81 725313.01 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480636.8 725309.11 2.04 480639.03 725305.77 2.04 480639.03 725305.77 20.330000000000002 480636.8 725309.11 20.330000000000002 480636.8 725309.11 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480639.03 725305.77 2.04 480641.5 725302.82 2.04 480641.5 725302.82 20.330000000000002 480639.03 725305.77 20.330000000000002 480639.03 725305.77 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480641.5 725302.82 2.04 480643.94 725300.44 2.04 480643.94 725300.44 20.330000000000002 480641.5 725302.82 20.330000000000002 480641.5 725302.82 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480643.94 725300.44 2.04 480647.19 725297.88 2.04 480647.19 725297.88 20.330000000000002 480643.94 725300.44 20.330000000000002 480643.94 725300.44 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480647.19 725297.88 2.04 480650.93 725295.59 2.04 480650.93 725295.59 20.330000000000002 480647.19 725297.88 20.330000000000002 480647.19 725297.88 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480650.93 725295.59 2.04 480654.51 725293.94 2.04 480654.51 725293.94 20.330000000000002 480650.93 725295.59 20.330000000000002 480650.93 725295.59 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480654.51 725293.94 2.04 480659.32 725292.39 2.04 480659.32 725292.39 20.330000000000002 480654.51 725293.94 20.330000000000002 480654.51 725293.94 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480659.32 725292.39 2.04 480664.12 725291.56 2.04 480664.12 725291.56 20.330000000000002 480659.32 725292.39 20.330000000000002 480659.32 725292.39 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480664.12 725291.56 2.04 480667.72 725291.36 2.04 480667.72 725291.36 20.330000000000002 480664.12 725291.56 20.330000000000002 480664.12 725291.56 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480667.72 725291.36 2.04 480672.33 725291.65 2.04 480672.33 725291.65 20.330000000000002 480667.72 725291.36 20.330000000000002 480667.72 725291.36 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480672.33 725291.65 2.04 480675.61 725292.21 2.04 480675.61 725292.21 20.330000000000002 480672.33 725291.65 20.330000000000002 480672.33 725291.65 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480675.61 725292.21 2.04 480678.96 725293.12 2.04 480678.96 725293.12 20.330000000000002 480675.61 725292.21 20.330000000000002 480675.61 725292.21 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480678.96 725293.12 2.04 480681.09 725293.88 2.04 480681.09 725293.88 20.330000000000002 480678.96 725293.12 20.330000000000002 480678.96 725293.12 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480681.09 725293.88 2.04 480683.57 725294.96 2.04 480683.57 725294.96 20.330000000000002 480681.09 725293.88 20.330000000000002 480681.09 725293.88 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480683.57 725294.96 2.04 480688.7 725297.99 2.04 480688.7 725297.99 20.330000000000002 480683.57 725294.96 20.330000000000002 480683.57 725294.96 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480688.7 725297.99 2.04 480691.21 725299.94 2.04 480691.21 725299.94 20.330000000000002 480688.7 725297.99 20.330000000000002 480688.7 725297.99 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480691.21 725299.94 2.04 480694.74 725303.38 2.04 480694.74 725303.38 20.330000000000002 480691.21 725299.94 20.330000000000002 480691.21 725299.94 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480694.74 725303.38 2.04 480698.01 725307.63 2.04 480698.01 725307.63 20.330000000000002 480694.74 725303.38 20.330000000000002 480694.74 725303.38 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480698.01 725307.63 2.04 480700.54 725312.14 2.04 480700.54 725312.14 20.330000000000002 480698.01 725307.63 20.330000000000002 480698.01 725307.63 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480700.54 725312.14 2.04 480702.49 725317.33 2.04 480702.49 725317.33 20.330000000000002 480700.54 725312.14 20.330000000000002 480700.54 725312.14 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480702.49 725317.33 2.04 480703.42 725321.33 2.04 480703.42 725321.33 20.330000000000002 480702.49 725317.33 20.330000000000002 480702.49 725317.33 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480703.42 725321.33 2.04 480703.92 725325.97 2.04 480703.92 725325.97 20.330000000000002 480703.42 725321.33 20.330000000000002 480703.42 725321.33 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480703.92 725325.97 2.04 480703.88 725329.6 2.04 480703.88 725329.6 20.330000000000002 480703.92 725325.97 20.330000000000002 480703.92 725325.97 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480703.88 725329.6 2.04 480703.29 725334.29 2.04 480703.29 725334.29 20.330000000000002 480703.88 725329.6 20.330000000000002 480703.88 725329.6 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480703.29 725334.29 2.04 480702.53 725337.45 2.04 480702.53 725337.45 20.330000000000002 480703.29 725334.29 20.330000000000002 480703.29 725334.29 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480702.53 725337.45 2.04 480701.39 725340.8 2.04 480701.39 725340.8 20.330000000000002 480702.53 725337.45 20.330000000000002 480702.53 725337.45 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480701.39 725340.8 2.04 480700.61 725342.58 2.04 480700.61 725342.58 20.330000000000002 480701.39 725340.8 20.330000000000002 480701.39 725340.8 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480700.61 725342.58 2.04 480698.14 725347.06 2.04 480698.14 725347.06 20.330000000000002 480700.61 725342.58 20.330000000000002 480700.61 725342.58 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480698.14 725347.06 2.04 480695.84 725350.23 2.04 480695.84 725350.23 20.330000000000002 480698.14 725347.06 20.330000000000002 480698.14 725347.06 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480695.84 725350.23 2.04 480691.89 725354.35 2.04 480691.89 725354.35 20.330000000000002 480695.84 725350.23 20.330000000000002 480695.84 725350.23 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480691.89 725354.35 2.04 480688.79 725356.83 2.04 480688.79 725356.83 20.330000000000002 480691.89 725354.35 20.330000000000002 480691.89 725354.35 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480688.79 725356.83 2.04 480684.29 725359.56 2.04 480684.29 725359.56 20.330000000000002 480688.79 725356.83 20.330000000000002 480688.79 725356.83 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480684.29 725359.56 2.04 480680.04 725361.41 2.04 480680.04 725361.41 20.330000000000002 480684.29 725359.56 20.330000000000002 480684.29 725359.56 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480680.04 725361.41 2.04 480674.55 725362.89 2.04 480674.55 725362.89 20.330000000000002 480680.04 725361.41 20.330000000000002 480680.04 725361.41 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480674.55 725362.89 2.04 480669.06 725363.49 2.04 480669.06 725363.49 20.330000000000002 480674.55 725362.89 20.330000000000002 480674.55 725362.89 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480669.06 725363.49 2.04 480664.9 725363.39 2.04 480664.9 725363.39 20.330000000000002 480669.06 725363.49 20.330000000000002 480669.06 725363.49 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480664.9 725363.39 2.04 480659.9 725362.62 2.04 480659.9 725362.62 20.330000000000002 480664.9 725363.39 20.330000000000002 480664.9 725363.39 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480659.9 725362.62 2.04 480656.83 725361.79 2.04 480656.83 725361.79 20.330000000000002 480659.9 725362.62 20.330000000000002 480659.9 725362.62 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480656.83 725361.79 2.04 480652.61 725360.14 2.04 480652.61 725360.14 20.330000000000002 480656.83 725361.79 20.330000000000002 480656.83 725361.79 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480652.61 725360.14 2.04 480648.39 725357.81 2.04 480648.39 725357.81 20.330000000000002 480652.61 725360.14 20.330000000000002 480652.61 725360.14 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480648.39 725357.81 2.04 480644.6 725355.01 2.04 480644.6 725355.01 20.330000000000002 480648.39 725357.81 20.330000000000002 480648.39 725357.81 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480644.6 725355.01 2.04 480640.91 725351.41 2.04 480640.91 725351.41 20.330000000000002 480644.6 725355.01 20.330000000000002 480644.6 725355.01 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480640.91 725351.41 2.04 480637.88 725347.49 2.04 480637.88 725347.49 20.330000000000002 480640.91 725351.41 20.330000000000002 480640.91 725351.41 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480637.88 725347.49 2.04 480636.19 725344.71 2.04 480636.19 725344.71 20.330000000000002 480637.88 725347.49 20.330000000000002 480637.88 725347.49 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480636.19 725344.71 2.04 480634.49 725341.16 2.04 480634.49 725341.16 20.330000000000002 480636.19 725344.71 20.330000000000002 480636.19 725344.71 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480634.49 725341.16 2.04 480633.01 725336.76 2.04 480633.01 725336.76 20.330000000000002 480634.49 725341.16 20.330000000000002 480634.49 725341.16 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480633.01 725336.76 2.04 480632.31 725333.52 2.04 480632.31 725333.52 20.330000000000002 480633.01 725336.76 20.330000000000002 480633.01 725336.76 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480632.31 725333.52 2.04 480631.84 725329.36 2.04 480631.84 725329.36 20.330000000000002 480632.31 725333.52 20.330000000000002 480632.31 725333.52 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-be3e25cd-2020-4987-9958-4fb6292bc7da_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480631.84 725329.36 20.330000000000002 480631.84 725325.58 20.330000000000002 480632.36 725321.09 20.330000000000002 480633.31 725317.09 20.330000000000002 480634.81 725313.01 20.330000000000002 480636.8 725309.11 20.330000000000002 480639.03 725305.77 20.330000000000002 480641.5 725302.82 20.330000000000002 480643.94 725300.44 20.330000000000002 480647.19 725297.88 20.330000000000002 480650.93 725295.59 20.330000000000002 480654.51 725293.94 20.330000000000002 480659.32 725292.39 20.330000000000002 480664.12 725291.56 20.330000000000002 480667.72 725291.36 20.330000000000002 480672.33 725291.65 20.330000000000002 480675.61 725292.21 20.330000000000002 480678.96 725293.12 20.330000000000002 480681.09 725293.88 20.330000000000002 480683.57 725294.96 20.330000000000002 480688.7 725297.99 20.330000000000002 480691.21 725299.94 20.330000000000002 480694.74 725303.38 20.330000000000002 480698.01 725307.63 20.330000000000002 480700.54 725312.14 20.330000000000002 480702.49 725317.33 20.330000000000002 480703.42 725321.33 20.330000000000002 480703.92 725325.97 20.330000000000002 480703.88 725329.6 20.330000000000002 480703.29 725334.29 20.330000000000002 480702.53 725337.45 20.330000000000002 480701.39 725340.8 20.330000000000002 480700.61 725342.58 20.330000000000002 480698.14 725347.06 20.330000000000002 480695.84 725350.23 20.330000000000002 480691.89 725354.35 20.330000000000002 480688.79 725356.83 20.330000000000002 480684.29 725359.56 20.330000000000002 480680.04 725361.41 20.330000000000002 480674.55 725362.89 20.330000000000002 480669.06 725363.49 20.330000000000002 480664.9 725363.39 20.330000000000002 480659.9 725362.62 20.330000000000002 480656.83 725361.79 20.330000000000002 480652.61 725360.14 20.330000000000002 480648.39 725357.81 20.330000000000002 480644.6 725355.01 20.330000000000002 480640.91 725351.41 20.330000000000002 480637.88 725347.49 20.330000000000002 480636.19 725344.71 20.330000000000002 480634.49 725341.16 20.330000000000002 480633.01 725336.76 20.330000000000002 480632.31 725333.52 20.330000000000002 480631.84 725329.36 20.330000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7821-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7821-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.17</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7821-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480207.91 724878.49 2.92 480221.86 724886.3 2.92 480223.18 724883.94 2.92 480209.22 724876.14 2.92 480207.91 724878.49 2.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7821-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480207.91 724878.49 2.92 480209.22 724876.14 2.92 480209.22 724876.14 6.09 480207.91 724878.49 6.09 480207.91 724878.49 2.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7821-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480209.22 724876.14 2.92 480223.18 724883.94 2.92 480223.18 724883.94 6.09 480209.22 724876.14 6.09 480209.22 724876.14 2.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7821-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480223.18 724883.94 2.92 480221.86 724886.3 2.92 480221.86 724886.3 6.09 480223.18 724883.94 6.09 480223.18 724883.94 2.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7821-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480221.86 724886.3 2.92 480207.91 724878.49 2.92 480207.91 724878.49 6.09 480221.86 724886.3 6.09 480221.86 724886.3 2.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7821-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480207.91 724878.49 6.09 480209.22 724876.14 6.09 480223.18 724883.94 6.09 480221.86 724886.3 6.09 480207.91 724878.49 6.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13">
			<gen:stringAttribute name="buildingId">
				<gen:value>34593b07-5053-48f1-ba24-fb654fa8db13</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.36</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480873.82 725456.26 2.73 480873.96 725457.51 2.73 480874.5 725459.19 2.73 480875.49 725460.92 2.73 480877.41 725462.78 2.73 480880.48 725464.13 2.73 480882.86 725464.3 2.73 480884.43 725464.04 2.73 480886.69 725463.08 2.73 480888.32 725461.82 2.73 480889.4 725460.44 2.73 480890.38 725458.36 2.73 480890.74 725456.47 2.73 480890.73 725455.19 2.73 480890.32 725453.16 2.73 480889.48 725451.37 2.73 480888.37 725449.94 2.73 480886.74 725448.64 2.73 480885.13 725447.87 2.73 480883.16 725447.42 2.73 480880.11 725447.65 2.73 480878.49 725448.27 2.73 480877.22 725449.04 2.73 480875.71 725450.49 2.73 480874.93 725451.64 2.73 480874.3 725452.99 2.73 480873.86 725454.82 2.73 480873.82 725456.26 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480873.82 725456.26 2.73 480873.86 725454.82 2.73 480873.86 725454.82 15.09 480873.82 725456.26 15.09 480873.82 725456.26 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480873.86 725454.82 2.73 480874.3 725452.99 2.73 480874.3 725452.99 15.09 480873.86 725454.82 15.09 480873.86 725454.82 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480874.3 725452.99 2.73 480874.93 725451.64 2.73 480874.93 725451.64 15.09 480874.3 725452.99 15.09 480874.3 725452.99 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480874.93 725451.64 2.73 480875.71 725450.49 2.73 480875.71 725450.49 15.09 480874.93 725451.64 15.09 480874.93 725451.64 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480875.71 725450.49 2.73 480877.22 725449.04 2.73 480877.22 725449.04 15.09 480875.71 725450.49 15.09 480875.71 725450.49 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480877.22 725449.04 2.73 480878.49 725448.27 2.73 480878.49 725448.27 15.09 480877.22 725449.04 15.09 480877.22 725449.04 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480878.49 725448.27 2.73 480880.11 725447.65 2.73 480880.11 725447.65 15.09 480878.49 725448.27 15.09 480878.49 725448.27 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480880.11 725447.65 2.73 480883.16 725447.42 2.73 480883.16 725447.42 15.09 480880.11 725447.65 15.09 480880.11 725447.65 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480883.16 725447.42 2.73 480885.13 725447.87 2.73 480885.13 725447.87 15.09 480883.16 725447.42 15.09 480883.16 725447.42 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480885.13 725447.87 2.73 480886.74 725448.64 2.73 480886.74 725448.64 15.09 480885.13 725447.87 15.09 480885.13 725447.87 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480886.74 725448.64 2.73 480888.37 725449.94 2.73 480888.37 725449.94 15.09 480886.74 725448.64 15.09 480886.74 725448.64 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480888.37 725449.94 2.73 480889.48 725451.37 2.73 480889.48 725451.37 15.09 480888.37 725449.94 15.09 480888.37 725449.94 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480889.48 725451.37 2.73 480890.32 725453.16 2.73 480890.32 725453.16 15.09 480889.48 725451.37 15.09 480889.48 725451.37 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480890.32 725453.16 2.73 480890.73 725455.19 2.73 480890.73 725455.19 15.09 480890.32 725453.16 15.09 480890.32 725453.16 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480890.73 725455.19 2.73 480890.74 725456.47 2.73 480890.74 725456.47 15.09 480890.73 725455.19 15.09 480890.73 725455.19 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480890.74 725456.47 2.73 480890.38 725458.36 2.73 480890.38 725458.36 15.09 480890.74 725456.47 15.09 480890.74 725456.47 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480890.38 725458.36 2.73 480889.4 725460.44 2.73 480889.4 725460.44 15.09 480890.38 725458.36 15.09 480890.38 725458.36 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480889.4 725460.44 2.73 480888.32 725461.82 2.73 480888.32 725461.82 15.09 480889.4 725460.44 15.09 480889.4 725460.44 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480888.32 725461.82 2.73 480886.69 725463.08 2.73 480886.69 725463.08 15.09 480888.32 725461.82 15.09 480888.32 725461.82 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480886.69 725463.08 2.73 480884.43 725464.04 2.73 480884.43 725464.04 15.09 480886.69 725463.08 15.09 480886.69 725463.08 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480884.43 725464.04 2.73 480882.86 725464.3 2.73 480882.86 725464.3 15.09 480884.43 725464.04 15.09 480884.43 725464.04 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480882.86 725464.3 2.73 480880.48 725464.13 2.73 480880.48 725464.13 15.09 480882.86 725464.3 15.09 480882.86 725464.3 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480880.48 725464.13 2.73 480877.41 725462.78 2.73 480877.41 725462.78 15.09 480880.48 725464.13 15.09 480880.48 725464.13 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480877.41 725462.78 2.73 480875.49 725460.92 2.73 480875.49 725460.92 15.09 480877.41 725462.78 15.09 480877.41 725462.78 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480875.49 725460.92 2.73 480874.5 725459.19 2.73 480874.5 725459.19 15.09 480875.49 725460.92 15.09 480875.49 725460.92 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480874.5 725459.19 2.73 480873.96 725457.51 2.73 480873.96 725457.51 15.09 480874.5 725459.19 15.09 480874.5 725459.19 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480873.96 725457.51 2.73 480873.82 725456.26 2.73 480873.82 725456.26 15.09 480873.96 725457.51 15.09 480873.96 725457.51 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-34593b07-5053-48f1-ba24-fb654fa8db13_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480873.82 725456.26 15.09 480873.86 725454.82 15.09 480874.3 725452.99 15.09 480874.93 725451.64 15.09 480875.71 725450.49 15.09 480877.22 725449.04 15.09 480878.49 725448.27 15.09 480880.11 725447.65 15.09 480883.16 725447.42 15.09 480885.13 725447.87 15.09 480886.74 725448.64 15.09 480888.37 725449.94 15.09 480889.48 725451.37 15.09 480890.32 725453.16 15.09 480890.73 725455.19 15.09 480890.74 725456.47 15.09 480890.38 725458.36 15.09 480889.4 725460.44 15.09 480888.32 725461.82 15.09 480886.69 725463.08 15.09 480884.43 725464.04 15.09 480882.86 725464.3 15.09 480880.48 725464.13 15.09 480877.41 725462.78 15.09 480875.49 725460.92 15.09 480874.5 725459.19 15.09 480873.96 725457.51 15.09 480873.82 725456.26 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-274bb53b-1297-4150-a0ea-9d0fc74c88a6">
			<gen:stringAttribute name="buildingId">
				<gen:value>274bb53b-1297-4150-a0ea-9d0fc74c88a6</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">13.31</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-274bb53b-1297-4150-a0ea-9d0fc74c88a6_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480346.24 723715.46 3.34 480233.48 723804.84 3.34 480323.43 723918.25 3.34 480436.19 723828.85 3.34 480346.24 723715.46 3.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-274bb53b-1297-4150-a0ea-9d0fc74c88a6_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480346.24 723715.46 3.34 480436.19 723828.85 3.34 480436.19 723828.85 16.65 480346.24 723715.46 16.65 480346.24 723715.46 3.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-274bb53b-1297-4150-a0ea-9d0fc74c88a6_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480436.19 723828.85 3.34 480323.43 723918.25 3.34 480323.43 723918.25 16.65 480436.19 723828.85 16.65 480436.19 723828.85 3.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-274bb53b-1297-4150-a0ea-9d0fc74c88a6_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480323.43 723918.25 3.34 480233.48 723804.84 3.34 480233.48 723804.84 16.65 480323.43 723918.25 16.65 480323.43 723918.25 3.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-274bb53b-1297-4150-a0ea-9d0fc74c88a6_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480233.48 723804.84 3.34 480346.24 723715.46 3.34 480346.24 723715.46 16.65 480233.48 723804.84 16.65 480233.48 723804.84 3.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-274bb53b-1297-4150-a0ea-9d0fc74c88a6_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480346.24 723715.46 16.65 480436.19 723828.85 16.65 480323.43 723918.25 16.65 480233.48 723804.84 16.65 480346.24 723715.46 16.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358">
			<gen:stringAttribute name="buildingId">
				<gen:value>a12455d4-cbb1-418b-a41c-2aed357c8358</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.4</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480578.08 725422.58 1.98 480578.33 725428.02 1.98 480579.61 725434.02 1.98 480581.4 725438.75 1.98 480584.5 725444.14 1.98 480587.58 725447.99 1.98 480590.22 725450.56 1.98 480592.98 725452.79 1.98 480596.13 725454.83 1.98 480599.87 725456.7 1.98 480603.48 725458.03 1.98 480607.57 725459.03 1.98 480613.23 725459.62 1.98 480617.83 725459.45 1.98 480623.93 725458.29 1.98 480629.77 725456.07 1.98 480633.44 725454.04 1.98 480636.75 725451.67 1.98 480639.77 725448.95 1.98 480642.8 725445.47 1.98 480645.49 725441.41 1.98 480647.3 725437.76 1.98 480648.61 725434.2 1.98 480649.38 725431.26 1.98 480649.95 725427.84 1.98 480650.17 725425.32 1.98 480650.14 725421.27 1.98 480649.84 725418.36 1.98 480649.21 725415.15 1.98 480648.18 725411.67 1.98 480646.62 725407.88 1.98 480645.4 725405.57 1.98 480643.43 725402.52 1.98 480642.04 725400.71 1.98 480640.36 725398.78 1.98 480637.21 725395.84 1.98 480633.99 725393.44 1.98 480630.32 725391.33 1.98 480626.43 725389.64 1.98 480621.14 725388.18 1.98 480616.17 725387.54 1.98 480610.99 725387.62 1.98 480605.57 725388.51 1.98 480601 725389.95 1.98 480596.82 725391.9 1.98 480592.99 725394.33 1.98 480589.47 725397.23 1.98 480586.17 725400.77 1.98 480583.74 725404.12 1.98 480581.65 725407.86 1.98 480580.25 725411.18 1.98 480579.09 725415 1.98 480578.4 725418.58 1.98 480578.08 725422.58 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480578.08 725422.58 1.98 480578.4 725418.58 1.98 480578.4 725418.58 9.38 480578.08 725422.58 9.38 480578.08 725422.58 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480578.4 725418.58 1.98 480579.09 725415 1.98 480579.09 725415 9.38 480578.4 725418.58 9.38 480578.4 725418.58 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480579.09 725415 1.98 480580.25 725411.18 1.98 480580.25 725411.18 9.38 480579.09 725415 9.38 480579.09 725415 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480580.25 725411.18 1.98 480581.65 725407.86 1.98 480581.65 725407.86 9.38 480580.25 725411.18 9.38 480580.25 725411.18 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480581.65 725407.86 1.98 480583.74 725404.12 1.98 480583.74 725404.12 9.38 480581.65 725407.86 9.38 480581.65 725407.86 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480583.74 725404.12 1.98 480586.17 725400.77 1.98 480586.17 725400.77 9.38 480583.74 725404.12 9.38 480583.74 725404.12 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480586.17 725400.77 1.98 480589.47 725397.23 1.98 480589.47 725397.23 9.38 480586.17 725400.77 9.38 480586.17 725400.77 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480589.47 725397.23 1.98 480592.99 725394.33 1.98 480592.99 725394.33 9.38 480589.47 725397.23 9.38 480589.47 725397.23 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480592.99 725394.33 1.98 480596.82 725391.9 1.98 480596.82 725391.9 9.38 480592.99 725394.33 9.38 480592.99 725394.33 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480596.82 725391.9 1.98 480601 725389.95 1.98 480601 725389.95 9.38 480596.82 725391.9 9.38 480596.82 725391.9 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480601 725389.95 1.98 480605.57 725388.51 1.98 480605.57 725388.51 9.38 480601 725389.95 9.38 480601 725389.95 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480605.57 725388.51 1.98 480610.99 725387.62 1.98 480610.99 725387.62 9.38 480605.57 725388.51 9.38 480605.57 725388.51 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480610.99 725387.62 1.98 480616.17 725387.54 1.98 480616.17 725387.54 9.38 480610.99 725387.62 9.38 480610.99 725387.62 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480616.17 725387.54 1.98 480621.14 725388.18 1.98 480621.14 725388.18 9.38 480616.17 725387.54 9.38 480616.17 725387.54 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480621.14 725388.18 1.98 480626.43 725389.64 1.98 480626.43 725389.64 9.38 480621.14 725388.18 9.38 480621.14 725388.18 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480626.43 725389.64 1.98 480630.32 725391.33 1.98 480630.32 725391.33 9.38 480626.43 725389.64 9.38 480626.43 725389.64 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480630.32 725391.33 1.98 480633.99 725393.44 1.98 480633.99 725393.44 9.38 480630.32 725391.33 9.38 480630.32 725391.33 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480633.99 725393.44 1.98 480637.21 725395.84 1.98 480637.21 725395.84 9.38 480633.99 725393.44 9.38 480633.99 725393.44 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480637.21 725395.84 1.98 480640.36 725398.78 1.98 480640.36 725398.78 9.38 480637.21 725395.84 9.38 480637.21 725395.84 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480640.36 725398.78 1.98 480642.04 725400.71 1.98 480642.04 725400.71 9.38 480640.36 725398.78 9.38 480640.36 725398.78 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480642.04 725400.71 1.98 480643.43 725402.52 1.98 480643.43 725402.52 9.38 480642.04 725400.71 9.38 480642.04 725400.71 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480643.43 725402.52 1.98 480645.4 725405.57 1.98 480645.4 725405.57 9.38 480643.43 725402.52 9.38 480643.43 725402.52 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480645.4 725405.57 1.98 480646.62 725407.88 1.98 480646.62 725407.88 9.38 480645.4 725405.57 9.38 480645.4 725405.57 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480646.62 725407.88 1.98 480648.18 725411.67 1.98 480648.18 725411.67 9.38 480646.62 725407.88 9.38 480646.62 725407.88 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480648.18 725411.67 1.98 480649.21 725415.15 1.98 480649.21 725415.15 9.38 480648.18 725411.67 9.38 480648.18 725411.67 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480649.21 725415.15 1.98 480649.84 725418.36 1.98 480649.84 725418.36 9.38 480649.21 725415.15 9.38 480649.21 725415.15 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480649.84 725418.36 1.98 480650.14 725421.27 1.98 480650.14 725421.27 9.38 480649.84 725418.36 9.38 480649.84 725418.36 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480650.14 725421.27 1.98 480650.17 725425.32 1.98 480650.17 725425.32 9.38 480650.14 725421.27 9.38 480650.14 725421.27 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480650.17 725425.32 1.98 480649.95 725427.84 1.98 480649.95 725427.84 9.38 480650.17 725425.32 9.38 480650.17 725425.32 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480649.95 725427.84 1.98 480649.38 725431.26 1.98 480649.38 725431.26 9.38 480649.95 725427.84 9.38 480649.95 725427.84 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480649.38 725431.26 1.98 480648.61 725434.2 1.98 480648.61 725434.2 9.38 480649.38 725431.26 9.38 480649.38 725431.26 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480648.61 725434.2 1.98 480647.3 725437.76 1.98 480647.3 725437.76 9.38 480648.61 725434.2 9.38 480648.61 725434.2 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480647.3 725437.76 1.98 480645.49 725441.41 1.98 480645.49 725441.41 9.38 480647.3 725437.76 9.38 480647.3 725437.76 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480645.49 725441.41 1.98 480642.8 725445.47 1.98 480642.8 725445.47 9.38 480645.49 725441.41 9.38 480645.49 725441.41 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480642.8 725445.47 1.98 480639.77 725448.95 1.98 480639.77 725448.95 9.38 480642.8 725445.47 9.38 480642.8 725445.47 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480639.77 725448.95 1.98 480636.75 725451.67 1.98 480636.75 725451.67 9.38 480639.77 725448.95 9.38 480639.77 725448.95 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480636.75 725451.67 1.98 480633.44 725454.04 1.98 480633.44 725454.04 9.38 480636.75 725451.67 9.38 480636.75 725451.67 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480633.44 725454.04 1.98 480629.77 725456.07 1.98 480629.77 725456.07 9.38 480633.44 725454.04 9.38 480633.44 725454.04 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480629.77 725456.07 1.98 480623.93 725458.29 1.98 480623.93 725458.29 9.38 480629.77 725456.07 9.38 480629.77 725456.07 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480623.93 725458.29 1.98 480617.83 725459.45 1.98 480617.83 725459.45 9.38 480623.93 725458.29 9.38 480623.93 725458.29 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480617.83 725459.45 1.98 480613.23 725459.62 1.98 480613.23 725459.62 9.38 480617.83 725459.45 9.38 480617.83 725459.45 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480613.23 725459.62 1.98 480607.57 725459.03 1.98 480607.57 725459.03 9.38 480613.23 725459.62 9.38 480613.23 725459.62 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480607.57 725459.03 1.98 480603.48 725458.03 1.98 480603.48 725458.03 9.38 480607.57 725459.03 9.38 480607.57 725459.03 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480603.48 725458.03 1.98 480599.87 725456.7 1.98 480599.87 725456.7 9.38 480603.48 725458.03 9.38 480603.48 725458.03 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480599.87 725456.7 1.98 480596.13 725454.83 1.98 480596.13 725454.83 9.38 480599.87 725456.7 9.38 480599.87 725456.7 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480596.13 725454.83 1.98 480592.98 725452.79 1.98 480592.98 725452.79 9.38 480596.13 725454.83 9.38 480596.13 725454.83 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480592.98 725452.79 1.98 480590.22 725450.56 1.98 480590.22 725450.56 9.38 480592.98 725452.79 9.38 480592.98 725452.79 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480590.22 725450.56 1.98 480587.58 725447.99 1.98 480587.58 725447.99 9.38 480590.22 725450.56 9.38 480590.22 725450.56 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480587.58 725447.99 1.98 480584.5 725444.14 1.98 480584.5 725444.14 9.38 480587.58 725447.99 9.38 480587.58 725447.99 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480584.5 725444.14 1.98 480581.4 725438.75 1.98 480581.4 725438.75 9.38 480584.5 725444.14 9.38 480584.5 725444.14 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480581.4 725438.75 1.98 480579.61 725434.02 1.98 480579.61 725434.02 9.38 480581.4 725438.75 9.38 480581.4 725438.75 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480579.61 725434.02 1.98 480578.33 725428.02 1.98 480578.33 725428.02 9.38 480579.61 725434.02 9.38 480579.61 725434.02 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480578.33 725428.02 1.98 480578.08 725422.58 1.98 480578.08 725422.58 9.38 480578.33 725428.02 9.38 480578.33 725428.02 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a12455d4-cbb1-418b-a41c-2aed357c8358_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480578.08 725422.58 9.38 480578.4 725418.58 9.38 480579.09 725415 9.38 480580.25 725411.18 9.38 480581.65 725407.86 9.38 480583.74 725404.12 9.38 480586.17 725400.77 9.38 480589.47 725397.23 9.38 480592.99 725394.33 9.38 480596.82 725391.9 9.38 480601 725389.95 9.38 480605.57 725388.51 9.38 480610.99 725387.62 9.38 480616.17 725387.54 9.38 480621.14 725388.18 9.38 480626.43 725389.64 9.38 480630.32 725391.33 9.38 480633.99 725393.44 9.38 480637.21 725395.84 9.38 480640.36 725398.78 9.38 480642.04 725400.71 9.38 480643.43 725402.52 9.38 480645.4 725405.57 9.38 480646.62 725407.88 9.38 480648.18 725411.67 9.38 480649.21 725415.15 9.38 480649.84 725418.36 9.38 480650.14 725421.27 9.38 480650.17 725425.32 9.38 480649.95 725427.84 9.38 480649.38 725431.26 9.38 480648.61 725434.2 9.38 480647.3 725437.76 9.38 480645.49 725441.41 9.38 480642.8 725445.47 9.38 480639.77 725448.95 9.38 480636.75 725451.67 9.38 480633.44 725454.04 9.38 480629.77 725456.07 9.38 480623.93 725458.29 9.38 480617.83 725459.45 9.38 480613.23 725459.62 9.38 480607.57 725459.03 9.38 480603.48 725458.03 9.38 480599.87 725456.7 9.38 480596.13 725454.83 9.38 480592.98 725452.79 9.38 480590.22 725450.56 9.38 480587.58 725447.99 9.38 480584.5 725444.14 9.38 480581.4 725438.75 9.38 480579.61 725434.02 9.38 480578.33 725428.02 9.38 480578.08 725422.58 9.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-483D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-483D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479952.72 725394.93 2.2 479965.6 725394.69 2.2 479965.59 725394.09 2.2 479965.21 725394.09 2.2 479964.98 725376.94 2.2 479964.88 725370.37 2.2 479952.28 725370.6 2.2 479952.72 725394.93 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479952.72 725394.93 2.2 479952.28 725370.6 2.2 479952.28 725370.6 9.75 479952.72 725394.93 9.75 479952.72 725394.93 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479952.28 725370.6 2.2 479964.88 725370.37 2.2 479964.88 725370.37 9.75 479952.28 725370.6 9.75 479952.28 725370.6 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479964.88 725370.37 2.2 479964.98 725376.94 2.2 479964.98 725376.94 9.75 479964.88 725370.37 9.75 479964.88 725370.37 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479964.98 725376.94 2.2 479965.21 725394.09 2.2 479965.21 725394.09 9.75 479964.98 725376.94 9.75 479964.98 725376.94 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479965.21 725394.09 2.2 479965.59 725394.09 2.2 479965.59 725394.09 9.75 479965.21 725394.09 9.75 479965.21 725394.09 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479965.59 725394.09 2.2 479965.6 725394.69 2.2 479965.6 725394.69 9.75 479965.59 725394.09 9.75 479965.59 725394.09 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479965.6 725394.69 2.2 479952.72 725394.93 2.2 479952.72 725394.93 9.75 479965.6 725394.69 9.75 479965.6 725394.69 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479952.72 725394.93 9.75 479952.28 725370.6 9.75 479964.88 725370.37 9.75 479964.98 725376.94 9.75 479965.21 725394.09 9.75 479965.59 725394.09 9.75 479965.6 725394.69 9.75 479952.72 725394.93 9.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-483F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-483F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.25</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479977.07 725392.11 2.32 479995.67 725391.96 2.32 479995.36 725355.25 2.32 479976.75 725355.64 2.32 479976.88 725370.21 2.32 479976.93 725376.77 2.32 479977.07 725392.11 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479977.07 725392.11 2.32 479976.93 725376.77 2.32 479976.93 725376.77 7.57 479977.07 725392.11 7.57 479977.07 725392.11 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479976.93 725376.77 2.32 479976.88 725370.21 2.32 479976.88 725370.21 7.57 479976.93 725376.77 7.57 479976.93 725376.77 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479976.88 725370.21 2.32 479976.75 725355.64 2.32 479976.75 725355.64 7.57 479976.88 725370.21 7.57 479976.88 725370.21 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479976.75 725355.64 2.32 479995.36 725355.25 2.32 479995.36 725355.25 7.57 479976.75 725355.64 7.57 479976.75 725355.64 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479995.36 725355.25 2.32 479995.67 725391.96 2.32 479995.67 725391.96 7.57 479995.36 725355.25 7.57 479995.36 725355.25 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479995.67 725391.96 2.32 479977.07 725392.11 2.32 479977.07 725392.11 7.57 479995.67 725391.96 7.57 479995.67 725391.96 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479977.07 725392.11 7.57 479976.93 725376.77 7.57 479976.88 725370.21 7.57 479976.75 725355.64 7.57 479995.36 725355.25 7.57 479995.67 725391.96 7.57 479977.07 725392.11 7.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-1ff4b1e8-9d37-40c2-9790-3f0b455fd70f">
			<gen:stringAttribute name="buildingId">
				<gen:value>1ff4b1e8-9d37-40c2-9790-3f0b455fd70f</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1ff4b1e8-9d37-40c2-9790-3f0b455fd70f_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480305.14 723981.92 4.12 480300.45 723985.66 4.12 480307.42 723994.48 4.12 480312.12 723990.75 4.12 480305.14 723981.92 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1ff4b1e8-9d37-40c2-9790-3f0b455fd70f_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480305.14 723981.92 4.12 480312.12 723990.75 4.12 480312.12 723990.75 7.41 480305.14 723981.92 7.41 480305.14 723981.92 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1ff4b1e8-9d37-40c2-9790-3f0b455fd70f_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480312.12 723990.75 4.12 480307.42 723994.48 4.12 480307.42 723994.48 7.41 480312.12 723990.75 7.41 480312.12 723990.75 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1ff4b1e8-9d37-40c2-9790-3f0b455fd70f_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480307.42 723994.48 4.12 480300.45 723985.66 4.12 480300.45 723985.66 7.41 480307.42 723994.48 7.41 480307.42 723994.48 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1ff4b1e8-9d37-40c2-9790-3f0b455fd70f_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480300.45 723985.66 4.12 480305.14 723981.92 4.12 480305.14 723981.92 7.41 480300.45 723985.66 7.41 480300.45 723985.66 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1ff4b1e8-9d37-40c2-9790-3f0b455fd70f_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480305.14 723981.92 7.41 480312.12 723990.75 7.41 480307.42 723994.48 7.41 480300.45 723985.66 7.41 480305.14 723981.92 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-483E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-483E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.98</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480015.14 725391.78 2.41 480033.38 725391.63 2.41 480033.37 725390.93 2.41 480033.05 725390.93 2.41 480032.54 725355.08 2.41 480032.93 725355.08 2.41 480032.93 725354.46 2.41 480014.82 725354.84 2.41 480015.14 725391.78 2.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480015.14 725391.78 2.41 480014.82 725354.84 2.41 480014.82 725354.84 11.39 480015.14 725391.78 11.39 480015.14 725391.78 2.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480014.82 725354.84 2.41 480032.93 725354.46 2.41 480032.93 725354.46 11.39 480014.82 725354.84 11.39 480014.82 725354.84 2.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480032.93 725354.46 2.41 480032.93 725355.08 2.41 480032.93 725355.08 11.39 480032.93 725354.46 11.39 480032.93 725354.46 2.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480032.93 725355.08 2.41 480032.54 725355.08 2.41 480032.54 725355.08 11.39 480032.93 725355.08 11.39 480032.93 725355.08 2.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480032.54 725355.08 2.41 480033.05 725390.93 2.41 480033.05 725390.93 11.39 480032.54 725355.08 11.39 480032.54 725355.08 2.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480033.05 725390.93 2.41 480033.37 725390.93 2.41 480033.37 725390.93 11.39 480033.05 725390.93 11.39 480033.05 725390.93 2.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480033.37 725390.93 2.41 480033.38 725391.63 2.41 480033.38 725391.63 11.39 480033.37 725390.93 11.39 480033.37 725390.93 2.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480033.38 725391.63 2.41 480015.14 725391.78 2.41 480015.14 725391.78 11.39 480033.38 725391.63 11.39 480033.38 725391.63 2.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480015.14 725391.78 11.39 480014.82 725354.84 11.39 480032.93 725354.46 11.39 480032.93 725355.08 11.39 480032.54 725355.08 11.39 480033.05 725390.93 11.39 480033.37 725390.93 11.39 480033.38 725391.63 11.39 480015.14 725391.78 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-483A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-483A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479964.98 725376.94 2.46 479976.93 725376.77 2.46 479976.88 725370.21 2.46 479964.88 725370.37 2.46 479964.98 725376.94 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479964.98 725376.94 2.46 479964.88 725370.37 2.46 479964.88 725370.37 5.93 479964.98 725376.94 5.93 479964.98 725376.94 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479964.88 725370.37 2.46 479976.88 725370.21 2.46 479976.88 725370.21 5.93 479964.88 725370.37 5.93 479964.88 725370.37 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479976.88 725370.21 2.46 479976.93 725376.77 2.46 479976.93 725376.77 5.93 479976.88 725370.21 5.93 479976.88 725370.21 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479976.93 725376.77 2.46 479964.98 725376.94 2.46 479964.98 725376.94 5.93 479976.93 725376.77 5.93 479976.93 725376.77 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-483A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479964.98 725376.94 5.93 479964.88 725370.37 5.93 479976.88 725370.21 5.93 479976.93 725376.77 5.93 479964.98 725376.94 5.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa">
			<gen:stringAttribute name="buildingId">
				<gen:value>4a2fca52-1399-402f-8c16-8874b4979caa</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">18.6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480538.26 725274.5 1.98 480538.49 725277.77 1.98 480538.96 725280.65 1.98 480539.8 725283.84 1.98 480540.79 725286.58 1.98 480542.2 725289.56 1.98 480543.67 725292.06 1.98 480545.62 725294.75 1.98 480547.51 725296.92 1.98 480549.93 725299.22 1.98 480552.18 725301 1.98 480554.99 725302.81 1.98 480557.52 725304.14 1.98 480560.61 725305.41 1.98 480563.34 725306.24 1.98 480566.62 725306.93 1.98 480569.45 725307.26 1.98 480572.81 725307.32 1.98 480575.65 725307.12 1.98 480578.96 725306.57 1.98 480581.71 725305.84 1.98 480584.86 725304.7 1.98 480587.44 725303.48 1.98 480590.32 725301.78 1.98 480592.63 725300.1 1.98 480595.14 725297.92 1.98 480597.12 725295.83 1.98 480599.17 725293.23 1.98 480600.74 725290.81 1.98 480602.28 725287.88 1.98 480603.38 725285.21 1.98 480604.35 725282.06 1.98 480604.95 725279.21 1.98 480605.32 725275.95 1.98 480605.38 725273.03 1.98 480605.15 725269.78 1.98 480604.67 725266.88 1.98 480603.86 725263.73 1.98 480602.85 725260.96 1.98 480601.48 725258.03 1.98 480599.97 725255.47 1.98 480598.09 725252.86 1.98 480596.13 725250.61 1.98 480593.81 725248.39 1.98 480591.46 725246.54 1.98 480588.78 725244.8 1.98 480586.12 725243.4 1.98 480583.17 725242.17 1.98 480580.3 725241.28 1.98 480577.18 725240.62 1.98 480574.18 725240.28 1.98 480570.99 725240.2 1.98 480567.99 725240.41 1.98 480564.84 725240.93 1.98 480561.93 725241.68 1.98 480558.92 725242.77 1.98 480556.2 725244.05 1.98 480553.44 725245.67 1.98 480551 725247.42 1.98 480548.59 725249.53 1.98 480546.52 725251.69 1.98 480544.52 725254.23 1.98 480542.9 725256.72 1.98 480541.39 725259.58 1.98 480540.25 725262.33 1.98 480539.3 725265.43 1.98 480538.69 725268.33 1.98 480538.32 725271.57 1.98 480538.26 725274.5 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480538.26 725274.5 1.98 480538.32 725271.57 1.98 480538.32 725271.57 20.580000000000002 480538.26 725274.5 20.580000000000002 480538.26 725274.5 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480538.32 725271.57 1.98 480538.69 725268.33 1.98 480538.69 725268.33 20.580000000000002 480538.32 725271.57 20.580000000000002 480538.32 725271.57 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480538.69 725268.33 1.98 480539.3 725265.43 1.98 480539.3 725265.43 20.580000000000002 480538.69 725268.33 20.580000000000002 480538.69 725268.33 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480539.3 725265.43 1.98 480540.25 725262.33 1.98 480540.25 725262.33 20.580000000000002 480539.3 725265.43 20.580000000000002 480539.3 725265.43 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480540.25 725262.33 1.98 480541.39 725259.58 1.98 480541.39 725259.58 20.580000000000002 480540.25 725262.33 20.580000000000002 480540.25 725262.33 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480541.39 725259.58 1.98 480542.9 725256.72 1.98 480542.9 725256.72 20.580000000000002 480541.39 725259.58 20.580000000000002 480541.39 725259.58 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480542.9 725256.72 1.98 480544.52 725254.23 1.98 480544.52 725254.23 20.580000000000002 480542.9 725256.72 20.580000000000002 480542.9 725256.72 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480544.52 725254.23 1.98 480546.52 725251.69 1.98 480546.52 725251.69 20.580000000000002 480544.52 725254.23 20.580000000000002 480544.52 725254.23 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480546.52 725251.69 1.98 480548.59 725249.53 1.98 480548.59 725249.53 20.580000000000002 480546.52 725251.69 20.580000000000002 480546.52 725251.69 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480548.59 725249.53 1.98 480551 725247.42 1.98 480551 725247.42 20.580000000000002 480548.59 725249.53 20.580000000000002 480548.59 725249.53 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480551 725247.42 1.98 480553.44 725245.67 1.98 480553.44 725245.67 20.580000000000002 480551 725247.42 20.580000000000002 480551 725247.42 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480553.44 725245.67 1.98 480556.2 725244.05 1.98 480556.2 725244.05 20.580000000000002 480553.44 725245.67 20.580000000000002 480553.44 725245.67 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480556.2 725244.05 1.98 480558.92 725242.77 1.98 480558.92 725242.77 20.580000000000002 480556.2 725244.05 20.580000000000002 480556.2 725244.05 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480558.92 725242.77 1.98 480561.93 725241.68 1.98 480561.93 725241.68 20.580000000000002 480558.92 725242.77 20.580000000000002 480558.92 725242.77 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480561.93 725241.68 1.98 480564.84 725240.93 1.98 480564.84 725240.93 20.580000000000002 480561.93 725241.68 20.580000000000002 480561.93 725241.68 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480564.84 725240.93 1.98 480567.99 725240.41 1.98 480567.99 725240.41 20.580000000000002 480564.84 725240.93 20.580000000000002 480564.84 725240.93 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480567.99 725240.41 1.98 480570.99 725240.2 1.98 480570.99 725240.2 20.580000000000002 480567.99 725240.41 20.580000000000002 480567.99 725240.41 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480570.99 725240.2 1.98 480574.18 725240.28 1.98 480574.18 725240.28 20.580000000000002 480570.99 725240.2 20.580000000000002 480570.99 725240.2 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480574.18 725240.28 1.98 480577.18 725240.62 1.98 480577.18 725240.62 20.580000000000002 480574.18 725240.28 20.580000000000002 480574.18 725240.28 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480577.18 725240.62 1.98 480580.3 725241.28 1.98 480580.3 725241.28 20.580000000000002 480577.18 725240.62 20.580000000000002 480577.18 725240.62 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480580.3 725241.28 1.98 480583.17 725242.17 1.98 480583.17 725242.17 20.580000000000002 480580.3 725241.28 20.580000000000002 480580.3 725241.28 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480583.17 725242.17 1.98 480586.12 725243.4 1.98 480586.12 725243.4 20.580000000000002 480583.17 725242.17 20.580000000000002 480583.17 725242.17 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480586.12 725243.4 1.98 480588.78 725244.8 1.98 480588.78 725244.8 20.580000000000002 480586.12 725243.4 20.580000000000002 480586.12 725243.4 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480588.78 725244.8 1.98 480591.46 725246.54 1.98 480591.46 725246.54 20.580000000000002 480588.78 725244.8 20.580000000000002 480588.78 725244.8 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480591.46 725246.54 1.98 480593.81 725248.39 1.98 480593.81 725248.39 20.580000000000002 480591.46 725246.54 20.580000000000002 480591.46 725246.54 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480593.81 725248.39 1.98 480596.13 725250.61 1.98 480596.13 725250.61 20.580000000000002 480593.81 725248.39 20.580000000000002 480593.81 725248.39 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480596.13 725250.61 1.98 480598.09 725252.86 1.98 480598.09 725252.86 20.580000000000002 480596.13 725250.61 20.580000000000002 480596.13 725250.61 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480598.09 725252.86 1.98 480599.97 725255.47 1.98 480599.97 725255.47 20.580000000000002 480598.09 725252.86 20.580000000000002 480598.09 725252.86 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480599.97 725255.47 1.98 480601.48 725258.03 1.98 480601.48 725258.03 20.580000000000002 480599.97 725255.47 20.580000000000002 480599.97 725255.47 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480601.48 725258.03 1.98 480602.85 725260.96 1.98 480602.85 725260.96 20.580000000000002 480601.48 725258.03 20.580000000000002 480601.48 725258.03 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480602.85 725260.96 1.98 480603.86 725263.73 1.98 480603.86 725263.73 20.580000000000002 480602.85 725260.96 20.580000000000002 480602.85 725260.96 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480603.86 725263.73 1.98 480604.67 725266.88 1.98 480604.67 725266.88 20.580000000000002 480603.86 725263.73 20.580000000000002 480603.86 725263.73 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480604.67 725266.88 1.98 480605.15 725269.78 1.98 480605.15 725269.78 20.580000000000002 480604.67 725266.88 20.580000000000002 480604.67 725266.88 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480605.15 725269.78 1.98 480605.38 725273.03 1.98 480605.38 725273.03 20.580000000000002 480605.15 725269.78 20.580000000000002 480605.15 725269.78 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480605.38 725273.03 1.98 480605.32 725275.95 1.98 480605.32 725275.95 20.580000000000002 480605.38 725273.03 20.580000000000002 480605.38 725273.03 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480605.32 725275.95 1.98 480604.95 725279.21 1.98 480604.95 725279.21 20.580000000000002 480605.32 725275.95 20.580000000000002 480605.32 725275.95 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480604.95 725279.21 1.98 480604.35 725282.06 1.98 480604.35 725282.06 20.580000000000002 480604.95 725279.21 20.580000000000002 480604.95 725279.21 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480604.35 725282.06 1.98 480603.38 725285.21 1.98 480603.38 725285.21 20.580000000000002 480604.35 725282.06 20.580000000000002 480604.35 725282.06 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480603.38 725285.21 1.98 480602.28 725287.88 1.98 480602.28 725287.88 20.580000000000002 480603.38 725285.21 20.580000000000002 480603.38 725285.21 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480602.28 725287.88 1.98 480600.74 725290.81 1.98 480600.74 725290.81 20.580000000000002 480602.28 725287.88 20.580000000000002 480602.28 725287.88 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480600.74 725290.81 1.98 480599.17 725293.23 1.98 480599.17 725293.23 20.580000000000002 480600.74 725290.81 20.580000000000002 480600.74 725290.81 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480599.17 725293.23 1.98 480597.12 725295.83 1.98 480597.12 725295.83 20.580000000000002 480599.17 725293.23 20.580000000000002 480599.17 725293.23 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480597.12 725295.83 1.98 480595.14 725297.92 1.98 480595.14 725297.92 20.580000000000002 480597.12 725295.83 20.580000000000002 480597.12 725295.83 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480595.14 725297.92 1.98 480592.63 725300.1 1.98 480592.63 725300.1 20.580000000000002 480595.14 725297.92 20.580000000000002 480595.14 725297.92 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480592.63 725300.1 1.98 480590.32 725301.78 1.98 480590.32 725301.78 20.580000000000002 480592.63 725300.1 20.580000000000002 480592.63 725300.1 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480590.32 725301.78 1.98 480587.44 725303.48 1.98 480587.44 725303.48 20.580000000000002 480590.32 725301.78 20.580000000000002 480590.32 725301.78 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480587.44 725303.48 1.98 480584.86 725304.7 1.98 480584.86 725304.7 20.580000000000002 480587.44 725303.48 20.580000000000002 480587.44 725303.48 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480584.86 725304.7 1.98 480581.71 725305.84 1.98 480581.71 725305.84 20.580000000000002 480584.86 725304.7 20.580000000000002 480584.86 725304.7 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480581.71 725305.84 1.98 480578.96 725306.57 1.98 480578.96 725306.57 20.580000000000002 480581.71 725305.84 20.580000000000002 480581.71 725305.84 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480578.96 725306.57 1.98 480575.65 725307.12 1.98 480575.65 725307.12 20.580000000000002 480578.96 725306.57 20.580000000000002 480578.96 725306.57 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480575.65 725307.12 1.98 480572.81 725307.32 1.98 480572.81 725307.32 20.580000000000002 480575.65 725307.12 20.580000000000002 480575.65 725307.12 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480572.81 725307.32 1.98 480569.45 725307.26 1.98 480569.45 725307.26 20.580000000000002 480572.81 725307.32 20.580000000000002 480572.81 725307.32 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480569.45 725307.26 1.98 480566.62 725306.93 1.98 480566.62 725306.93 20.580000000000002 480569.45 725307.26 20.580000000000002 480569.45 725307.26 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480566.62 725306.93 1.98 480563.34 725306.24 1.98 480563.34 725306.24 20.580000000000002 480566.62 725306.93 20.580000000000002 480566.62 725306.93 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480563.34 725306.24 1.98 480560.61 725305.41 1.98 480560.61 725305.41 20.580000000000002 480563.34 725306.24 20.580000000000002 480563.34 725306.24 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480560.61 725305.41 1.98 480557.52 725304.14 1.98 480557.52 725304.14 20.580000000000002 480560.61 725305.41 20.580000000000002 480560.61 725305.41 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480557.52 725304.14 1.98 480554.99 725302.81 1.98 480554.99 725302.81 20.580000000000002 480557.52 725304.14 20.580000000000002 480557.52 725304.14 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480554.99 725302.81 1.98 480552.18 725301 1.98 480552.18 725301 20.580000000000002 480554.99 725302.81 20.580000000000002 480554.99 725302.81 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480552.18 725301 1.98 480549.93 725299.22 1.98 480549.93 725299.22 20.580000000000002 480552.18 725301 20.580000000000002 480552.18 725301 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480549.93 725299.22 1.98 480547.51 725296.92 1.98 480547.51 725296.92 20.580000000000002 480549.93 725299.22 20.580000000000002 480549.93 725299.22 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480547.51 725296.92 1.98 480545.62 725294.75 1.98 480545.62 725294.75 20.580000000000002 480547.51 725296.92 20.580000000000002 480547.51 725296.92 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480545.62 725294.75 1.98 480543.67 725292.06 1.98 480543.67 725292.06 20.580000000000002 480545.62 725294.75 20.580000000000002 480545.62 725294.75 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480543.67 725292.06 1.98 480542.2 725289.56 1.98 480542.2 725289.56 20.580000000000002 480543.67 725292.06 20.580000000000002 480543.67 725292.06 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480542.2 725289.56 1.98 480540.79 725286.58 1.98 480540.79 725286.58 20.580000000000002 480542.2 725289.56 20.580000000000002 480542.2 725289.56 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480540.79 725286.58 1.98 480539.8 725283.84 1.98 480539.8 725283.84 20.580000000000002 480540.79 725286.58 20.580000000000002 480540.79 725286.58 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480539.8 725283.84 1.98 480538.96 725280.65 1.98 480538.96 725280.65 20.580000000000002 480539.8 725283.84 20.580000000000002 480539.8 725283.84 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480538.96 725280.65 1.98 480538.49 725277.77 1.98 480538.49 725277.77 20.580000000000002 480538.96 725280.65 20.580000000000002 480538.96 725280.65 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480538.49 725277.77 1.98 480538.26 725274.5 1.98 480538.26 725274.5 20.580000000000002 480538.49 725277.77 20.580000000000002 480538.49 725277.77 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4a2fca52-1399-402f-8c16-8874b4979caa_PG_70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480538.26 725274.5 20.580000000000002 480538.32 725271.57 20.580000000000002 480538.69 725268.33 20.580000000000002 480539.3 725265.43 20.580000000000002 480540.25 725262.33 20.580000000000002 480541.39 725259.58 20.580000000000002 480542.9 725256.72 20.580000000000002 480544.52 725254.23 20.580000000000002 480546.52 725251.69 20.580000000000002 480548.59 725249.53 20.580000000000002 480551 725247.42 20.580000000000002 480553.44 725245.67 20.580000000000002 480556.2 725244.05 20.580000000000002 480558.92 725242.77 20.580000000000002 480561.93 725241.68 20.580000000000002 480564.84 725240.93 20.580000000000002 480567.99 725240.41 20.580000000000002 480570.99 725240.2 20.580000000000002 480574.18 725240.28 20.580000000000002 480577.18 725240.62 20.580000000000002 480580.3 725241.28 20.580000000000002 480583.17 725242.17 20.580000000000002 480586.12 725243.4 20.580000000000002 480588.78 725244.8 20.580000000000002 480591.46 725246.54 20.580000000000002 480593.81 725248.39 20.580000000000002 480596.13 725250.61 20.580000000000002 480598.09 725252.86 20.580000000000002 480599.97 725255.47 20.580000000000002 480601.48 725258.03 20.580000000000002 480602.85 725260.96 20.580000000000002 480603.86 725263.73 20.580000000000002 480604.67 725266.88 20.580000000000002 480605.15 725269.78 20.580000000000002 480605.38 725273.03 20.580000000000002 480605.32 725275.95 20.580000000000002 480604.95 725279.21 20.580000000000002 480604.35 725282.06 20.580000000000002 480603.38 725285.21 20.580000000000002 480602.28 725287.88 20.580000000000002 480600.74 725290.81 20.580000000000002 480599.17 725293.23 20.580000000000002 480597.12 725295.83 20.580000000000002 480595.14 725297.92 20.580000000000002 480592.63 725300.1 20.580000000000002 480590.32 725301.78 20.580000000000002 480587.44 725303.48 20.580000000000002 480584.86 725304.7 20.580000000000002 480581.71 725305.84 20.580000000000002 480578.96 725306.57 20.580000000000002 480575.65 725307.12 20.580000000000002 480572.81 725307.32 20.580000000000002 480569.45 725307.26 20.580000000000002 480566.62 725306.93 20.580000000000002 480563.34 725306.24 20.580000000000002 480560.61 725305.41 20.580000000000002 480557.52 725304.14 20.580000000000002 480554.99 725302.81 20.580000000000002 480552.18 725301 20.580000000000002 480549.93 725299.22 20.580000000000002 480547.51 725296.92 20.580000000000002 480545.62 725294.75 20.580000000000002 480543.67 725292.06 20.580000000000002 480542.2 725289.56 20.580000000000002 480540.79 725286.58 20.580000000000002 480539.8 725283.84 20.580000000000002 480538.96 725280.65 20.580000000000002 480538.49 725277.77 20.580000000000002 480538.26 725274.5 20.580000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46">
			<gen:stringAttribute name="buildingId">
				<gen:value>4cb58f43-bf50-4142-ad72-b99d9de6fa46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">18.65</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480442.36 725221.2 2.01 480442.59 725224.13 2.01 480443.14 725227.34 2.01 480443.9 725230.19 2.01 480445.02 725233.25 2.01 480446.3 725235.9 2.01 480447.97 725238.71 2.01 480449.7 725241.08 2.01 480451.86 725243.53 2.01 480454 725245.55 2.01 480456.58 725247.55 2.01 480459.05 725249.14 2.01 480461.95 725250.64 2.01 480464.67 725251.75 2.01 480467.79 725252.69 2.01 480470.68 725253.28 2.01 480473.91 725253.63 2.01 480476.86 725253.68 2.01 480480.11 725253.43 2.01 480483.02 725252.93 2.01 480486.17 725252.09 2.01 480488.93 725251.07 2.01 480491.86 725249.67 2.01 480494.4 725248.16 2.01 480497.03 725246.24 2.01 480499.24 725244.29 2.01 480501.47 725241.91 2.01 480503.28 725239.59 2.01 480505.04 725236.85 2.01 480506.39 725234.23 2.01 480507.62 725231.22 2.01 480508.47 725228.4 2.01 480509.12 725225.2 2.01 480509.44 725222.28 2.01 480509.49 725219.02 2.01 480509.27 725216.08 2.01 480508.72 725212.87 2.01 480507.96 725210.02 2.01 480506.83 725206.96 2.01 480505.57 725204.31 2.01 480503.89 725201.51 2.01 480502.16 725199.13 2.01 480500 725196.68 2.01 480497.85 725194.66 2.01 480495.29 725192.66 2.01 480492.81 725191.08 2.01 480489.92 725189.57 2.01 480487.18 725188.47 2.01 480484.06 725187.52 2.01 480481.17 725186.94 2.01 480477.94 725186.58 2.01 480474.99 725186.53 2.01 480471.75 725186.79 2.01 480468.85 725187.28 2.01 480465.69 725188.13 2.01 480462.93 725189.14 2.01 480459.99 725190.54 2.01 480457.46 725192.06 2.01 480454.83 725193.98 2.01 480452.63 725195.93 2.01 480450.39 725198.31 2.01 480448.58 725200.62 2.01 480446.82 725203.36 2.01 480445.46 725205.98 2.01 480444.24 725209 2.01 480443.39 725211.82 2.01 480442.73 725215.02 2.01 480442.41 725217.94 2.01 480442.36 725221.2 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480442.36 725221.2 2.01 480442.41 725217.94 2.01 480442.41 725217.94 20.659999999999997 480442.36 725221.2 20.659999999999997 480442.36 725221.2 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480442.41 725217.94 2.01 480442.73 725215.02 2.01 480442.73 725215.02 20.659999999999997 480442.41 725217.94 20.659999999999997 480442.41 725217.94 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480442.73 725215.02 2.01 480443.39 725211.82 2.01 480443.39 725211.82 20.659999999999997 480442.73 725215.02 20.659999999999997 480442.73 725215.02 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480443.39 725211.82 2.01 480444.24 725209 2.01 480444.24 725209 20.659999999999997 480443.39 725211.82 20.659999999999997 480443.39 725211.82 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480444.24 725209 2.01 480445.46 725205.98 2.01 480445.46 725205.98 20.659999999999997 480444.24 725209 20.659999999999997 480444.24 725209 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480445.46 725205.98 2.01 480446.82 725203.36 2.01 480446.82 725203.36 20.659999999999997 480445.46 725205.98 20.659999999999997 480445.46 725205.98 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480446.82 725203.36 2.01 480448.58 725200.62 2.01 480448.58 725200.62 20.659999999999997 480446.82 725203.36 20.659999999999997 480446.82 725203.36 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480448.58 725200.62 2.01 480450.39 725198.31 2.01 480450.39 725198.31 20.659999999999997 480448.58 725200.62 20.659999999999997 480448.58 725200.62 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480450.39 725198.31 2.01 480452.63 725195.93 2.01 480452.63 725195.93 20.659999999999997 480450.39 725198.31 20.659999999999997 480450.39 725198.31 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480452.63 725195.93 2.01 480454.83 725193.98 2.01 480454.83 725193.98 20.659999999999997 480452.63 725195.93 20.659999999999997 480452.63 725195.93 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480454.83 725193.98 2.01 480457.46 725192.06 2.01 480457.46 725192.06 20.659999999999997 480454.83 725193.98 20.659999999999997 480454.83 725193.98 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480457.46 725192.06 2.01 480459.99 725190.54 2.01 480459.99 725190.54 20.659999999999997 480457.46 725192.06 20.659999999999997 480457.46 725192.06 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480459.99 725190.54 2.01 480462.93 725189.14 2.01 480462.93 725189.14 20.659999999999997 480459.99 725190.54 20.659999999999997 480459.99 725190.54 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480462.93 725189.14 2.01 480465.69 725188.13 2.01 480465.69 725188.13 20.659999999999997 480462.93 725189.14 20.659999999999997 480462.93 725189.14 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480465.69 725188.13 2.01 480468.85 725187.28 2.01 480468.85 725187.28 20.659999999999997 480465.69 725188.13 20.659999999999997 480465.69 725188.13 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480468.85 725187.28 2.01 480471.75 725186.79 2.01 480471.75 725186.79 20.659999999999997 480468.85 725187.28 20.659999999999997 480468.85 725187.28 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480471.75 725186.79 2.01 480474.99 725186.53 2.01 480474.99 725186.53 20.659999999999997 480471.75 725186.79 20.659999999999997 480471.75 725186.79 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480474.99 725186.53 2.01 480477.94 725186.58 2.01 480477.94 725186.58 20.659999999999997 480474.99 725186.53 20.659999999999997 480474.99 725186.53 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480477.94 725186.58 2.01 480481.17 725186.94 2.01 480481.17 725186.94 20.659999999999997 480477.94 725186.58 20.659999999999997 480477.94 725186.58 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480481.17 725186.94 2.01 480484.06 725187.52 2.01 480484.06 725187.52 20.659999999999997 480481.17 725186.94 20.659999999999997 480481.17 725186.94 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480484.06 725187.52 2.01 480487.18 725188.47 2.01 480487.18 725188.47 20.659999999999997 480484.06 725187.52 20.659999999999997 480484.06 725187.52 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480487.18 725188.47 2.01 480489.92 725189.57 2.01 480489.92 725189.57 20.659999999999997 480487.18 725188.47 20.659999999999997 480487.18 725188.47 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480489.92 725189.57 2.01 480492.81 725191.08 2.01 480492.81 725191.08 20.659999999999997 480489.92 725189.57 20.659999999999997 480489.92 725189.57 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480492.81 725191.08 2.01 480495.29 725192.66 2.01 480495.29 725192.66 20.659999999999997 480492.81 725191.08 20.659999999999997 480492.81 725191.08 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480495.29 725192.66 2.01 480497.85 725194.66 2.01 480497.85 725194.66 20.659999999999997 480495.29 725192.66 20.659999999999997 480495.29 725192.66 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480497.85 725194.66 2.01 480500 725196.68 2.01 480500 725196.68 20.659999999999997 480497.85 725194.66 20.659999999999997 480497.85 725194.66 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480500 725196.68 2.01 480502.16 725199.13 2.01 480502.16 725199.13 20.659999999999997 480500 725196.68 20.659999999999997 480500 725196.68 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480502.16 725199.13 2.01 480503.89 725201.51 2.01 480503.89 725201.51 20.659999999999997 480502.16 725199.13 20.659999999999997 480502.16 725199.13 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480503.89 725201.51 2.01 480505.57 725204.31 2.01 480505.57 725204.31 20.659999999999997 480503.89 725201.51 20.659999999999997 480503.89 725201.51 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480505.57 725204.31 2.01 480506.83 725206.96 2.01 480506.83 725206.96 20.659999999999997 480505.57 725204.31 20.659999999999997 480505.57 725204.31 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480506.83 725206.96 2.01 480507.96 725210.02 2.01 480507.96 725210.02 20.659999999999997 480506.83 725206.96 20.659999999999997 480506.83 725206.96 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480507.96 725210.02 2.01 480508.72 725212.87 2.01 480508.72 725212.87 20.659999999999997 480507.96 725210.02 20.659999999999997 480507.96 725210.02 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480508.72 725212.87 2.01 480509.27 725216.08 2.01 480509.27 725216.08 20.659999999999997 480508.72 725212.87 20.659999999999997 480508.72 725212.87 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480509.27 725216.08 2.01 480509.49 725219.02 2.01 480509.49 725219.02 20.659999999999997 480509.27 725216.08 20.659999999999997 480509.27 725216.08 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480509.49 725219.02 2.01 480509.44 725222.28 2.01 480509.44 725222.28 20.659999999999997 480509.49 725219.02 20.659999999999997 480509.49 725219.02 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480509.44 725222.28 2.01 480509.12 725225.2 2.01 480509.12 725225.2 20.659999999999997 480509.44 725222.28 20.659999999999997 480509.44 725222.28 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480509.12 725225.2 2.01 480508.47 725228.4 2.01 480508.47 725228.4 20.659999999999997 480509.12 725225.2 20.659999999999997 480509.12 725225.2 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480508.47 725228.4 2.01 480507.62 725231.22 2.01 480507.62 725231.22 20.659999999999997 480508.47 725228.4 20.659999999999997 480508.47 725228.4 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480507.62 725231.22 2.01 480506.39 725234.23 2.01 480506.39 725234.23 20.659999999999997 480507.62 725231.22 20.659999999999997 480507.62 725231.22 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480506.39 725234.23 2.01 480505.04 725236.85 2.01 480505.04 725236.85 20.659999999999997 480506.39 725234.23 20.659999999999997 480506.39 725234.23 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480505.04 725236.85 2.01 480503.28 725239.59 2.01 480503.28 725239.59 20.659999999999997 480505.04 725236.85 20.659999999999997 480505.04 725236.85 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480503.28 725239.59 2.01 480501.47 725241.91 2.01 480501.47 725241.91 20.659999999999997 480503.28 725239.59 20.659999999999997 480503.28 725239.59 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480501.47 725241.91 2.01 480499.24 725244.29 2.01 480499.24 725244.29 20.659999999999997 480501.47 725241.91 20.659999999999997 480501.47 725241.91 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480499.24 725244.29 2.01 480497.03 725246.24 2.01 480497.03 725246.24 20.659999999999997 480499.24 725244.29 20.659999999999997 480499.24 725244.29 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480497.03 725246.24 2.01 480494.4 725248.16 2.01 480494.4 725248.16 20.659999999999997 480497.03 725246.24 20.659999999999997 480497.03 725246.24 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480494.4 725248.16 2.01 480491.86 725249.67 2.01 480491.86 725249.67 20.659999999999997 480494.4 725248.16 20.659999999999997 480494.4 725248.16 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480491.86 725249.67 2.01 480488.93 725251.07 2.01 480488.93 725251.07 20.659999999999997 480491.86 725249.67 20.659999999999997 480491.86 725249.67 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480488.93 725251.07 2.01 480486.17 725252.09 2.01 480486.17 725252.09 20.659999999999997 480488.93 725251.07 20.659999999999997 480488.93 725251.07 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480486.17 725252.09 2.01 480483.02 725252.93 2.01 480483.02 725252.93 20.659999999999997 480486.17 725252.09 20.659999999999997 480486.17 725252.09 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480483.02 725252.93 2.01 480480.11 725253.43 2.01 480480.11 725253.43 20.659999999999997 480483.02 725252.93 20.659999999999997 480483.02 725252.93 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480480.11 725253.43 2.01 480476.86 725253.68 2.01 480476.86 725253.68 20.659999999999997 480480.11 725253.43 20.659999999999997 480480.11 725253.43 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480476.86 725253.68 2.01 480473.91 725253.63 2.01 480473.91 725253.63 20.659999999999997 480476.86 725253.68 20.659999999999997 480476.86 725253.68 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480473.91 725253.63 2.01 480470.68 725253.28 2.01 480470.68 725253.28 20.659999999999997 480473.91 725253.63 20.659999999999997 480473.91 725253.63 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480470.68 725253.28 2.01 480467.79 725252.69 2.01 480467.79 725252.69 20.659999999999997 480470.68 725253.28 20.659999999999997 480470.68 725253.28 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480467.79 725252.69 2.01 480464.67 725251.75 2.01 480464.67 725251.75 20.659999999999997 480467.79 725252.69 20.659999999999997 480467.79 725252.69 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480464.67 725251.75 2.01 480461.95 725250.64 2.01 480461.95 725250.64 20.659999999999997 480464.67 725251.75 20.659999999999997 480464.67 725251.75 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480461.95 725250.64 2.01 480459.05 725249.14 2.01 480459.05 725249.14 20.659999999999997 480461.95 725250.64 20.659999999999997 480461.95 725250.64 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480459.05 725249.14 2.01 480456.58 725247.55 2.01 480456.58 725247.55 20.659999999999997 480459.05 725249.14 20.659999999999997 480459.05 725249.14 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480456.58 725247.55 2.01 480454 725245.55 2.01 480454 725245.55 20.659999999999997 480456.58 725247.55 20.659999999999997 480456.58 725247.55 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480454 725245.55 2.01 480451.86 725243.53 2.01 480451.86 725243.53 20.659999999999997 480454 725245.55 20.659999999999997 480454 725245.55 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480451.86 725243.53 2.01 480449.7 725241.08 2.01 480449.7 725241.08 20.659999999999997 480451.86 725243.53 20.659999999999997 480451.86 725243.53 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480449.7 725241.08 2.01 480447.97 725238.71 2.01 480447.97 725238.71 20.659999999999997 480449.7 725241.08 20.659999999999997 480449.7 725241.08 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480447.97 725238.71 2.01 480446.3 725235.9 2.01 480446.3 725235.9 20.659999999999997 480447.97 725238.71 20.659999999999997 480447.97 725238.71 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480446.3 725235.9 2.01 480445.02 725233.25 2.01 480445.02 725233.25 20.659999999999997 480446.3 725235.9 20.659999999999997 480446.3 725235.9 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480445.02 725233.25 2.01 480443.9 725230.19 2.01 480443.9 725230.19 20.659999999999997 480445.02 725233.25 20.659999999999997 480445.02 725233.25 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480443.9 725230.19 2.01 480443.14 725227.34 2.01 480443.14 725227.34 20.659999999999997 480443.9 725230.19 20.659999999999997 480443.9 725230.19 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480443.14 725227.34 2.01 480442.59 725224.13 2.01 480442.59 725224.13 20.659999999999997 480443.14 725227.34 20.659999999999997 480443.14 725227.34 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480442.59 725224.13 2.01 480442.36 725221.2 2.01 480442.36 725221.2 20.659999999999997 480442.59 725224.13 20.659999999999997 480442.59 725224.13 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4cb58f43-bf50-4142-ad72-b99d9de6fa46_PG_70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480442.36 725221.2 20.659999999999997 480442.41 725217.94 20.659999999999997 480442.73 725215.02 20.659999999999997 480443.39 725211.82 20.659999999999997 480444.24 725209 20.659999999999997 480445.46 725205.98 20.659999999999997 480446.82 725203.36 20.659999999999997 480448.58 725200.62 20.659999999999997 480450.39 725198.31 20.659999999999997 480452.63 725195.93 20.659999999999997 480454.83 725193.98 20.659999999999997 480457.46 725192.06 20.659999999999997 480459.99 725190.54 20.659999999999997 480462.93 725189.14 20.659999999999997 480465.69 725188.13 20.659999999999997 480468.85 725187.28 20.659999999999997 480471.75 725186.79 20.659999999999997 480474.99 725186.53 20.659999999999997 480477.94 725186.58 20.659999999999997 480481.17 725186.94 20.659999999999997 480484.06 725187.52 20.659999999999997 480487.18 725188.47 20.659999999999997 480489.92 725189.57 20.659999999999997 480492.81 725191.08 20.659999999999997 480495.29 725192.66 20.659999999999997 480497.85 725194.66 20.659999999999997 480500 725196.68 20.659999999999997 480502.16 725199.13 20.659999999999997 480503.89 725201.51 20.659999999999997 480505.57 725204.31 20.659999999999997 480506.83 725206.96 20.659999999999997 480507.96 725210.02 20.659999999999997 480508.72 725212.87 20.659999999999997 480509.27 725216.08 20.659999999999997 480509.49 725219.02 20.659999999999997 480509.44 725222.28 20.659999999999997 480509.12 725225.2 20.659999999999997 480508.47 725228.4 20.659999999999997 480507.62 725231.22 20.659999999999997 480506.39 725234.23 20.659999999999997 480505.04 725236.85 20.659999999999997 480503.28 725239.59 20.659999999999997 480501.47 725241.91 20.659999999999997 480499.24 725244.29 20.659999999999997 480497.03 725246.24 20.659999999999997 480494.4 725248.16 20.659999999999997 480491.86 725249.67 20.659999999999997 480488.93 725251.07 20.659999999999997 480486.17 725252.09 20.659999999999997 480483.02 725252.93 20.659999999999997 480480.11 725253.43 20.659999999999997 480476.86 725253.68 20.659999999999997 480473.91 725253.63 20.659999999999997 480470.68 725253.28 20.659999999999997 480467.79 725252.69 20.659999999999997 480464.67 725251.75 20.659999999999997 480461.95 725250.64 20.659999999999997 480459.05 725249.14 20.659999999999997 480456.58 725247.55 20.659999999999997 480454 725245.55 20.659999999999997 480451.86 725243.53 20.659999999999997 480449.7 725241.08 20.659999999999997 480447.97 725238.71 20.659999999999997 480446.3 725235.9 20.659999999999997 480445.02 725233.25 20.659999999999997 480443.9 725230.19 20.659999999999997 480443.14 725227.34 20.659999999999997 480442.59 725224.13 20.659999999999997 480442.36 725221.2 20.659999999999997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-3EB6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-3EB6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">13.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EB6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.52 725475.32 2.21 479976.74 725474.98 2.21 479975.74 725407.97 2.21 479950.45 725408.09 2.21 479951.52 725475.32 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EB6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.52 725475.32 2.21 479950.45 725408.09 2.21 479950.45 725408.09 16.02 479951.52 725475.32 16.02 479951.52 725475.32 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EB6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479950.45 725408.09 2.21 479975.74 725407.97 2.21 479975.74 725407.97 16.02 479950.45 725408.09 16.02 479950.45 725408.09 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EB6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479975.74 725407.97 2.21 479976.74 725474.98 2.21 479976.74 725474.98 16.02 479975.74 725407.97 16.02 479975.74 725407.97 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EB6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479976.74 725474.98 2.21 479951.52 725475.32 2.21 479951.52 725475.32 16.02 479976.74 725474.98 16.02 479976.74 725474.98 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EB6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479951.52 725475.32 16.02 479950.45 725408.09 16.02 479975.74 725407.97 16.02 479976.74 725474.98 16.02 479951.52 725475.32 16.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821">
			<gen:stringAttribute name="buildingId">
				<gen:value>ee32dd42-de75-4430-a0a9-467eab2a5821</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">26.2</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480730.95 725390.08 2.03 480731.7 725393.13 2.03 480732.71 725396.09 2.03 480733.98 725398.95 2.03 480735.5 725401.7 2.03 480737.27 725404.28 2.03 480739.25 725406.71 2.03 480741.45 725408.94 2.03 480743.84 725410.97 2.03 480746.41 725412.78 2.03 480749.12 725414.35 2.03 480751.96 725415.67 2.03 480754.92 725416.72 2.03 480757.95 725417.52 2.03 480761.04 725418.04 2.03 480764.16 725418.27 2.03 480767.3 725418.23 2.03 480770.42 725417.9 2.03 480773.5 725417.3 2.03 480776.5 725416.42 2.03 480779.42 725415.28 2.03 480782.23 725413.88 2.03 480784.9 725412.23 2.03 480787.41 725410.36 2.03 480789.74 725408.25 2.03 480791.87 725405.97 2.03 480793.79 725403.48 2.03 480795.48 725400.85 2.03 480796.93 725398.06 2.03 480798.12 725395.16 2.03 480799.04 725392.17 2.03 480799.7 725389.1 2.03 480800.08 725385.99 2.03 480800.17 725382.85 2.03 480799.99 725379.72 2.03 480799.52 725376.62 2.03 480798.78 725373.57 2.03 480797.77 725370.61 2.03 480796.5 725367.75 2.03 480794.97 725365 2.03 480793.21 725362.42 2.03 480791.22 725359.99 2.03 480789.02 725357.76 2.03 480786.63 725355.73 2.03 480784.07 725353.92 2.03 480781.36 725352.35 2.03 480778.51 725351.04 2.03 480775.56 725349.98 2.03 480772.53 725349.18 2.03 480769.43 725348.67 2.03 480766.31 725348.43 2.03 480763.17 725348.47 2.03 480760.06 725348.8 2.03 480756.98 725349.4 2.03 480753.97 725350.28 2.03 480751.05 725351.42 2.03 480748.24 725352.82 2.03 480745.58 725354.47 2.03 480743.07 725356.35 2.03 480740.74 725358.45 2.03 480738.6 725360.74 2.03 480736.69 725363.22 2.03 480735 725365.85 2.03 480733.55 725368.64 2.03 480732.36 725371.54 2.03 480731.43 725374.53 2.03 480730.78 725377.6 2.03 480730.4 725380.71 2.03 480730.3 725383.84 2.03 480730.49 725386.98 2.03 480730.95 725390.08 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480730.95 725390.08 2.03 480730.49 725386.98 2.03 480730.49 725386.98 28.23 480730.95 725390.08 28.23 480730.95 725390.08 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480730.49 725386.98 2.03 480730.3 725383.84 2.03 480730.3 725383.84 28.23 480730.49 725386.98 28.23 480730.49 725386.98 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480730.3 725383.84 2.03 480730.4 725380.71 2.03 480730.4 725380.71 28.23 480730.3 725383.84 28.23 480730.3 725383.84 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480730.4 725380.71 2.03 480730.78 725377.6 2.03 480730.78 725377.6 28.23 480730.4 725380.71 28.23 480730.4 725380.71 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480730.78 725377.6 2.03 480731.43 725374.53 2.03 480731.43 725374.53 28.23 480730.78 725377.6 28.23 480730.78 725377.6 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480731.43 725374.53 2.03 480732.36 725371.54 2.03 480732.36 725371.54 28.23 480731.43 725374.53 28.23 480731.43 725374.53 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480732.36 725371.54 2.03 480733.55 725368.64 2.03 480733.55 725368.64 28.23 480732.36 725371.54 28.23 480732.36 725371.54 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480733.55 725368.64 2.03 480735 725365.85 2.03 480735 725365.85 28.23 480733.55 725368.64 28.23 480733.55 725368.64 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480735 725365.85 2.03 480736.69 725363.22 2.03 480736.69 725363.22 28.23 480735 725365.85 28.23 480735 725365.85 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480736.69 725363.22 2.03 480738.6 725360.74 2.03 480738.6 725360.74 28.23 480736.69 725363.22 28.23 480736.69 725363.22 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480738.6 725360.74 2.03 480740.74 725358.45 2.03 480740.74 725358.45 28.23 480738.6 725360.74 28.23 480738.6 725360.74 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480740.74 725358.45 2.03 480743.07 725356.35 2.03 480743.07 725356.35 28.23 480740.74 725358.45 28.23 480740.74 725358.45 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480743.07 725356.35 2.03 480745.58 725354.47 2.03 480745.58 725354.47 28.23 480743.07 725356.35 28.23 480743.07 725356.35 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480745.58 725354.47 2.03 480748.24 725352.82 2.03 480748.24 725352.82 28.23 480745.58 725354.47 28.23 480745.58 725354.47 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480748.24 725352.82 2.03 480751.05 725351.42 2.03 480751.05 725351.42 28.23 480748.24 725352.82 28.23 480748.24 725352.82 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480751.05 725351.42 2.03 480753.97 725350.28 2.03 480753.97 725350.28 28.23 480751.05 725351.42 28.23 480751.05 725351.42 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480753.97 725350.28 2.03 480756.98 725349.4 2.03 480756.98 725349.4 28.23 480753.97 725350.28 28.23 480753.97 725350.28 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480756.98 725349.4 2.03 480760.06 725348.8 2.03 480760.06 725348.8 28.23 480756.98 725349.4 28.23 480756.98 725349.4 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480760.06 725348.8 2.03 480763.17 725348.47 2.03 480763.17 725348.47 28.23 480760.06 725348.8 28.23 480760.06 725348.8 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480763.17 725348.47 2.03 480766.31 725348.43 2.03 480766.31 725348.43 28.23 480763.17 725348.47 28.23 480763.17 725348.47 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480766.31 725348.43 2.03 480769.43 725348.67 2.03 480769.43 725348.67 28.23 480766.31 725348.43 28.23 480766.31 725348.43 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480769.43 725348.67 2.03 480772.53 725349.18 2.03 480772.53 725349.18 28.23 480769.43 725348.67 28.23 480769.43 725348.67 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480772.53 725349.18 2.03 480775.56 725349.98 2.03 480775.56 725349.98 28.23 480772.53 725349.18 28.23 480772.53 725349.18 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480775.56 725349.98 2.03 480778.51 725351.04 2.03 480778.51 725351.04 28.23 480775.56 725349.98 28.23 480775.56 725349.98 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480778.51 725351.04 2.03 480781.36 725352.35 2.03 480781.36 725352.35 28.23 480778.51 725351.04 28.23 480778.51 725351.04 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480781.36 725352.35 2.03 480784.07 725353.92 2.03 480784.07 725353.92 28.23 480781.36 725352.35 28.23 480781.36 725352.35 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480784.07 725353.92 2.03 480786.63 725355.73 2.03 480786.63 725355.73 28.23 480784.07 725353.92 28.23 480784.07 725353.92 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480786.63 725355.73 2.03 480789.02 725357.76 2.03 480789.02 725357.76 28.23 480786.63 725355.73 28.23 480786.63 725355.73 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480789.02 725357.76 2.03 480791.22 725359.99 2.03 480791.22 725359.99 28.23 480789.02 725357.76 28.23 480789.02 725357.76 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480791.22 725359.99 2.03 480793.21 725362.42 2.03 480793.21 725362.42 28.23 480791.22 725359.99 28.23 480791.22 725359.99 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480793.21 725362.42 2.03 480794.97 725365 2.03 480794.97 725365 28.23 480793.21 725362.42 28.23 480793.21 725362.42 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480794.97 725365 2.03 480796.5 725367.75 2.03 480796.5 725367.75 28.23 480794.97 725365 28.23 480794.97 725365 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480796.5 725367.75 2.03 480797.77 725370.61 2.03 480797.77 725370.61 28.23 480796.5 725367.75 28.23 480796.5 725367.75 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480797.77 725370.61 2.03 480798.78 725373.57 2.03 480798.78 725373.57 28.23 480797.77 725370.61 28.23 480797.77 725370.61 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480798.78 725373.57 2.03 480799.52 725376.62 2.03 480799.52 725376.62 28.23 480798.78 725373.57 28.23 480798.78 725373.57 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480799.52 725376.62 2.03 480799.99 725379.72 2.03 480799.99 725379.72 28.23 480799.52 725376.62 28.23 480799.52 725376.62 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480799.99 725379.72 2.03 480800.17 725382.85 2.03 480800.17 725382.85 28.23 480799.99 725379.72 28.23 480799.99 725379.72 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480800.17 725382.85 2.03 480800.08 725385.99 2.03 480800.08 725385.99 28.23 480800.17 725382.85 28.23 480800.17 725382.85 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480800.08 725385.99 2.03 480799.7 725389.1 2.03 480799.7 725389.1 28.23 480800.08 725385.99 28.23 480800.08 725385.99 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480799.7 725389.1 2.03 480799.04 725392.17 2.03 480799.04 725392.17 28.23 480799.7 725389.1 28.23 480799.7 725389.1 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480799.04 725392.17 2.03 480798.12 725395.16 2.03 480798.12 725395.16 28.23 480799.04 725392.17 28.23 480799.04 725392.17 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480798.12 725395.16 2.03 480796.93 725398.06 2.03 480796.93 725398.06 28.23 480798.12 725395.16 28.23 480798.12 725395.16 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480796.93 725398.06 2.03 480795.48 725400.85 2.03 480795.48 725400.85 28.23 480796.93 725398.06 28.23 480796.93 725398.06 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480795.48 725400.85 2.03 480793.79 725403.48 2.03 480793.79 725403.48 28.23 480795.48 725400.85 28.23 480795.48 725400.85 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480793.79 725403.48 2.03 480791.87 725405.97 2.03 480791.87 725405.97 28.23 480793.79 725403.48 28.23 480793.79 725403.48 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480791.87 725405.97 2.03 480789.74 725408.25 2.03 480789.74 725408.25 28.23 480791.87 725405.97 28.23 480791.87 725405.97 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480789.74 725408.25 2.03 480787.41 725410.36 2.03 480787.41 725410.36 28.23 480789.74 725408.25 28.23 480789.74 725408.25 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480787.41 725410.36 2.03 480784.9 725412.23 2.03 480784.9 725412.23 28.23 480787.41 725410.36 28.23 480787.41 725410.36 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480784.9 725412.23 2.03 480782.23 725413.88 2.03 480782.23 725413.88 28.23 480784.9 725412.23 28.23 480784.9 725412.23 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480782.23 725413.88 2.03 480779.42 725415.28 2.03 480779.42 725415.28 28.23 480782.23 725413.88 28.23 480782.23 725413.88 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480779.42 725415.28 2.03 480776.5 725416.42 2.03 480776.5 725416.42 28.23 480779.42 725415.28 28.23 480779.42 725415.28 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480776.5 725416.42 2.03 480773.5 725417.3 2.03 480773.5 725417.3 28.23 480776.5 725416.42 28.23 480776.5 725416.42 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480773.5 725417.3 2.03 480770.42 725417.9 2.03 480770.42 725417.9 28.23 480773.5 725417.3 28.23 480773.5 725417.3 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480770.42 725417.9 2.03 480767.3 725418.23 2.03 480767.3 725418.23 28.23 480770.42 725417.9 28.23 480770.42 725417.9 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480767.3 725418.23 2.03 480764.16 725418.27 2.03 480764.16 725418.27 28.23 480767.3 725418.23 28.23 480767.3 725418.23 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480764.16 725418.27 2.03 480761.04 725418.04 2.03 480761.04 725418.04 28.23 480764.16 725418.27 28.23 480764.16 725418.27 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480761.04 725418.04 2.03 480757.95 725417.52 2.03 480757.95 725417.52 28.23 480761.04 725418.04 28.23 480761.04 725418.04 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480757.95 725417.52 2.03 480754.92 725416.72 2.03 480754.92 725416.72 28.23 480757.95 725417.52 28.23 480757.95 725417.52 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480754.92 725416.72 2.03 480751.96 725415.67 2.03 480751.96 725415.67 28.23 480754.92 725416.72 28.23 480754.92 725416.72 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480751.96 725415.67 2.03 480749.12 725414.35 2.03 480749.12 725414.35 28.23 480751.96 725415.67 28.23 480751.96 725415.67 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480749.12 725414.35 2.03 480746.41 725412.78 2.03 480746.41 725412.78 28.23 480749.12 725414.35 28.23 480749.12 725414.35 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480746.41 725412.78 2.03 480743.84 725410.97 2.03 480743.84 725410.97 28.23 480746.41 725412.78 28.23 480746.41 725412.78 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480743.84 725410.97 2.03 480741.45 725408.94 2.03 480741.45 725408.94 28.23 480743.84 725410.97 28.23 480743.84 725410.97 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480741.45 725408.94 2.03 480739.25 725406.71 2.03 480739.25 725406.71 28.23 480741.45 725408.94 28.23 480741.45 725408.94 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480739.25 725406.71 2.03 480737.27 725404.28 2.03 480737.27 725404.28 28.23 480739.25 725406.71 28.23 480739.25 725406.71 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480737.27 725404.28 2.03 480735.5 725401.7 2.03 480735.5 725401.7 28.23 480737.27 725404.28 28.23 480737.27 725404.28 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480735.5 725401.7 2.03 480733.98 725398.95 2.03 480733.98 725398.95 28.23 480735.5 725401.7 28.23 480735.5 725401.7 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480733.98 725398.95 2.03 480732.71 725396.09 2.03 480732.71 725396.09 28.23 480733.98 725398.95 28.23 480733.98 725398.95 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480732.71 725396.09 2.03 480731.7 725393.13 2.03 480731.7 725393.13 28.23 480732.71 725396.09 28.23 480732.71 725396.09 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480731.7 725393.13 2.03 480730.95 725390.08 2.03 480730.95 725390.08 28.23 480731.7 725393.13 28.23 480731.7 725393.13 2.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ee32dd42-de75-4430-a0a9-467eab2a5821_PG_72">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480730.95 725390.08 28.23 480730.49 725386.98 28.23 480730.3 725383.84 28.23 480730.4 725380.71 28.23 480730.78 725377.6 28.23 480731.43 725374.53 28.23 480732.36 725371.54 28.23 480733.55 725368.64 28.23 480735 725365.85 28.23 480736.69 725363.22 28.23 480738.6 725360.74 28.23 480740.74 725358.45 28.23 480743.07 725356.35 28.23 480745.58 725354.47 28.23 480748.24 725352.82 28.23 480751.05 725351.42 28.23 480753.97 725350.28 28.23 480756.98 725349.4 28.23 480760.06 725348.8 28.23 480763.17 725348.47 28.23 480766.31 725348.43 28.23 480769.43 725348.67 28.23 480772.53 725349.18 28.23 480775.56 725349.98 28.23 480778.51 725351.04 28.23 480781.36 725352.35 28.23 480784.07 725353.92 28.23 480786.63 725355.73 28.23 480789.02 725357.76 28.23 480791.22 725359.99 28.23 480793.21 725362.42 28.23 480794.97 725365 28.23 480796.5 725367.75 28.23 480797.77 725370.61 28.23 480798.78 725373.57 28.23 480799.52 725376.62 28.23 480799.99 725379.72 28.23 480800.17 725382.85 28.23 480800.08 725385.99 28.23 480799.7 725389.1 28.23 480799.04 725392.17 28.23 480798.12 725395.16 28.23 480796.93 725398.06 28.23 480795.48 725400.85 28.23 480793.79 725403.48 28.23 480791.87 725405.97 28.23 480789.74 725408.25 28.23 480787.41 725410.36 28.23 480784.9 725412.23 28.23 480782.23 725413.88 28.23 480779.42 725415.28 28.23 480776.5 725416.42 28.23 480773.5 725417.3 28.23 480770.42 725417.9 28.23 480767.3 725418.23 28.23 480764.16 725418.27 28.23 480761.04 725418.04 28.23 480757.95 725417.52 28.23 480754.92 725416.72 28.23 480751.96 725415.67 28.23 480749.12 725414.35 28.23 480746.41 725412.78 28.23 480743.84 725410.97 28.23 480741.45 725408.94 28.23 480739.25 725406.71 28.23 480737.27 725404.28 28.23 480735.5 725401.7 28.23 480733.98 725398.95 28.23 480732.71 725396.09 28.23 480731.7 725393.13 28.23 480730.95 725390.08 28.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30">
			<gen:stringAttribute name="buildingId">
				<gen:value>ce64e102-f5b3-4bb7-96e2-868be5b85c30</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">23.45</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480478.18 725482.82 1.98 480479.33 725486.29 1.98 480480.81 725489.31 1.98 480482.85 725492.3 1.98 480485.13 725494.88 1.98 480487.81 725497.05 1.98 480490.79 725498.88 1.98 480494.04 725500.3 1.98 480497.42 725501.24 1.98 480501.03 725501.69 1.98 480504.4 725501.65 1.98 480508.01 725501.09 1.98 480510.33 725500.44 1.98 480513.6 725499.08 1.98 480516.53 725497.34 1.98 480519.32 725495.13 1.98 480521.74 725492.58 1.98 480523.77 725489.71 1.98 480525.37 725486.6 1.98 480526.5 725483.38 1.98 480527.24 725479.5 1.98 480527.39 725476.13 1.98 480527.11 725472.88 1.98 480526.26 725469.31 1.98 480525.12 725466.32 1.98 480523.5 725463.32 1.98 480521.18 725460.25 1.98 480518.65 725457.74 1.98 480515.69 725455.59 1.98 480514.58 725454.89 1.98 480512.43 725453.81 1.98 480509.6 725452.8 1.98 480505.94 725452.01 1.98 480502.52 725451.74 1.98 480498.75 725452 1.98 480495.37 725452.73 1.98 480491.87 725454.08 1.98 480489.23 725455.52 1.98 480486.1 725457.72 1.98 480483.78 725460.09 1.98 480481.75 725462.7 1.98 480480.03 725465.65 1.98 480478.68 725468.92 1.98 480477.79 725472.52 1.98 480477.44 725475.92 1.98 480477.58 725479.48 1.98 480478.18 725482.82 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480478.18 725482.82 1.98 480477.58 725479.48 1.98 480477.58 725479.48 25.43 480478.18 725482.82 25.43 480478.18 725482.82 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480477.58 725479.48 1.98 480477.44 725475.92 1.98 480477.44 725475.92 25.43 480477.58 725479.48 25.43 480477.58 725479.48 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480477.44 725475.92 1.98 480477.79 725472.52 1.98 480477.79 725472.52 25.43 480477.44 725475.92 25.43 480477.44 725475.92 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480477.79 725472.52 1.98 480478.68 725468.92 1.98 480478.68 725468.92 25.43 480477.79 725472.52 25.43 480477.79 725472.52 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480478.68 725468.92 1.98 480480.03 725465.65 1.98 480480.03 725465.65 25.43 480478.68 725468.92 25.43 480478.68 725468.92 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480480.03 725465.65 1.98 480481.75 725462.7 1.98 480481.75 725462.7 25.43 480480.03 725465.65 25.43 480480.03 725465.65 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480481.75 725462.7 1.98 480483.78 725460.09 1.98 480483.78 725460.09 25.43 480481.75 725462.7 25.43 480481.75 725462.7 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480483.78 725460.09 1.98 480486.1 725457.72 1.98 480486.1 725457.72 25.43 480483.78 725460.09 25.43 480483.78 725460.09 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480486.1 725457.72 1.98 480489.23 725455.52 1.98 480489.23 725455.52 25.43 480486.1 725457.72 25.43 480486.1 725457.72 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480489.23 725455.52 1.98 480491.87 725454.08 1.98 480491.87 725454.08 25.43 480489.23 725455.52 25.43 480489.23 725455.52 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480491.87 725454.08 1.98 480495.37 725452.73 1.98 480495.37 725452.73 25.43 480491.87 725454.08 25.43 480491.87 725454.08 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480495.37 725452.73 1.98 480498.75 725452 1.98 480498.75 725452 25.43 480495.37 725452.73 25.43 480495.37 725452.73 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480498.75 725452 1.98 480502.52 725451.74 1.98 480502.52 725451.74 25.43 480498.75 725452 25.43 480498.75 725452 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480502.52 725451.74 1.98 480505.94 725452.01 1.98 480505.94 725452.01 25.43 480502.52 725451.74 25.43 480502.52 725451.74 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480505.94 725452.01 1.98 480509.6 725452.8 1.98 480509.6 725452.8 25.43 480505.94 725452.01 25.43 480505.94 725452.01 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480509.6 725452.8 1.98 480512.43 725453.81 1.98 480512.43 725453.81 25.43 480509.6 725452.8 25.43 480509.6 725452.8 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480512.43 725453.81 1.98 480514.58 725454.89 1.98 480514.58 725454.89 25.43 480512.43 725453.81 25.43 480512.43 725453.81 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480514.58 725454.89 1.98 480515.69 725455.59 1.98 480515.69 725455.59 25.43 480514.58 725454.89 25.43 480514.58 725454.89 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480515.69 725455.59 1.98 480518.65 725457.74 1.98 480518.65 725457.74 25.43 480515.69 725455.59 25.43 480515.69 725455.59 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480518.65 725457.74 1.98 480521.18 725460.25 1.98 480521.18 725460.25 25.43 480518.65 725457.74 25.43 480518.65 725457.74 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480521.18 725460.25 1.98 480523.5 725463.32 1.98 480523.5 725463.32 25.43 480521.18 725460.25 25.43 480521.18 725460.25 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480523.5 725463.32 1.98 480525.12 725466.32 1.98 480525.12 725466.32 25.43 480523.5 725463.32 25.43 480523.5 725463.32 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480525.12 725466.32 1.98 480526.26 725469.31 1.98 480526.26 725469.31 25.43 480525.12 725466.32 25.43 480525.12 725466.32 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480526.26 725469.31 1.98 480527.11 725472.88 1.98 480527.11 725472.88 25.43 480526.26 725469.31 25.43 480526.26 725469.31 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480527.11 725472.88 1.98 480527.39 725476.13 1.98 480527.39 725476.13 25.43 480527.11 725472.88 25.43 480527.11 725472.88 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480527.39 725476.13 1.98 480527.24 725479.5 1.98 480527.24 725479.5 25.43 480527.39 725476.13 25.43 480527.39 725476.13 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480527.24 725479.5 1.98 480526.5 725483.38 1.98 480526.5 725483.38 25.43 480527.24 725479.5 25.43 480527.24 725479.5 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480526.5 725483.38 1.98 480525.37 725486.6 1.98 480525.37 725486.6 25.43 480526.5 725483.38 25.43 480526.5 725483.38 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480525.37 725486.6 1.98 480523.77 725489.71 1.98 480523.77 725489.71 25.43 480525.37 725486.6 25.43 480525.37 725486.6 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480523.77 725489.71 1.98 480521.74 725492.58 1.98 480521.74 725492.58 25.43 480523.77 725489.71 25.43 480523.77 725489.71 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480521.74 725492.58 1.98 480519.32 725495.13 1.98 480519.32 725495.13 25.43 480521.74 725492.58 25.43 480521.74 725492.58 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480519.32 725495.13 1.98 480516.53 725497.34 1.98 480516.53 725497.34 25.43 480519.32 725495.13 25.43 480519.32 725495.13 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480516.53 725497.34 1.98 480513.6 725499.08 1.98 480513.6 725499.08 25.43 480516.53 725497.34 25.43 480516.53 725497.34 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480513.6 725499.08 1.98 480510.33 725500.44 1.98 480510.33 725500.44 25.43 480513.6 725499.08 25.43 480513.6 725499.08 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480510.33 725500.44 1.98 480508.01 725501.09 1.98 480508.01 725501.09 25.43 480510.33 725500.44 25.43 480510.33 725500.44 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480508.01 725501.09 1.98 480504.4 725501.65 1.98 480504.4 725501.65 25.43 480508.01 725501.09 25.43 480508.01 725501.09 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480504.4 725501.65 1.98 480501.03 725501.69 1.98 480501.03 725501.69 25.43 480504.4 725501.65 25.43 480504.4 725501.65 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480501.03 725501.69 1.98 480497.42 725501.24 1.98 480497.42 725501.24 25.43 480501.03 725501.69 25.43 480501.03 725501.69 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480497.42 725501.24 1.98 480494.04 725500.3 1.98 480494.04 725500.3 25.43 480497.42 725501.24 25.43 480497.42 725501.24 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480494.04 725500.3 1.98 480490.79 725498.88 1.98 480490.79 725498.88 25.43 480494.04 725500.3 25.43 480494.04 725500.3 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480490.79 725498.88 1.98 480487.81 725497.05 1.98 480487.81 725497.05 25.43 480490.79 725498.88 25.43 480490.79 725498.88 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480487.81 725497.05 1.98 480485.13 725494.88 1.98 480485.13 725494.88 25.43 480487.81 725497.05 25.43 480487.81 725497.05 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480485.13 725494.88 1.98 480482.85 725492.3 1.98 480482.85 725492.3 25.43 480485.13 725494.88 25.43 480485.13 725494.88 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480482.85 725492.3 1.98 480480.81 725489.31 1.98 480480.81 725489.31 25.43 480482.85 725492.3 25.43 480482.85 725492.3 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480480.81 725489.31 1.98 480479.33 725486.29 1.98 480479.33 725486.29 25.43 480480.81 725489.31 25.43 480480.81 725489.31 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480479.33 725486.29 1.98 480478.18 725482.82 1.98 480478.18 725482.82 25.43 480479.33 725486.29 25.43 480479.33 725486.29 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-ce64e102-f5b3-4bb7-96e2-868be5b85c30_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480478.18 725482.82 25.43 480477.58 725479.48 25.43 480477.44 725475.92 25.43 480477.79 725472.52 25.43 480478.68 725468.92 25.43 480480.03 725465.65 25.43 480481.75 725462.7 25.43 480483.78 725460.09 25.43 480486.1 725457.72 25.43 480489.23 725455.52 25.43 480491.87 725454.08 25.43 480495.37 725452.73 25.43 480498.75 725452 25.43 480502.52 725451.74 25.43 480505.94 725452.01 25.43 480509.6 725452.8 25.43 480512.43 725453.81 25.43 480514.58 725454.89 25.43 480515.69 725455.59 25.43 480518.65 725457.74 25.43 480521.18 725460.25 25.43 480523.5 725463.32 25.43 480525.12 725466.32 25.43 480526.26 725469.31 25.43 480527.11 725472.88 25.43 480527.39 725476.13 25.43 480527.24 725479.5 25.43 480526.5 725483.38 25.43 480525.37 725486.6 25.43 480523.77 725489.71 25.43 480521.74 725492.58 25.43 480519.32 725495.13 25.43 480516.53 725497.34 25.43 480513.6 725499.08 25.43 480510.33 725500.44 25.43 480508.01 725501.09 25.43 480504.4 725501.65 25.43 480501.03 725501.69 25.43 480497.42 725501.24 25.43 480494.04 725500.3 25.43 480490.79 725498.88 25.43 480487.81 725497.05 25.43 480485.13 725494.88 25.43 480482.85 725492.3 25.43 480480.81 725489.31 25.43 480479.33 725486.29 25.43 480478.18 725482.82 25.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004">
			<gen:stringAttribute name="buildingId">
				<gen:value>12af6fc5-ffab-4c86-9e92-61ba35466004</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">23.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480550.32 725522.71 1.96 480551.47 725526.18 1.96 480552.95 725529.2 1.96 480555 725532.19 1.96 480557.27 725534.77 1.96 480559.95 725536.94 1.96 480562.93 725538.77 1.96 480566.18 725540.19 1.96 480569.56 725541.13 1.96 480573.18 725541.58 1.96 480576.55 725541.54 1.96 480580.16 725540.98 1.96 480582.48 725540.33 1.96 480585.75 725538.97 1.96 480588.68 725537.23 1.96 480591.47 725535.02 1.96 480593.89 725532.47 1.96 480595.92 725529.6 1.96 480597.51 725526.49 1.96 480598.65 725523.27 1.96 480599.39 725519.39 1.96 480599.53 725516.02 1.96 480599.26 725512.77 1.96 480598.41 725509.2 1.96 480597.26 725506.2 1.96 480595.64 725503.21 1.96 480593.33 725500.14 1.96 480590.8 725497.63 1.96 480587.84 725495.48 1.96 480586.73 725494.78 1.96 480584.57 725493.7 1.96 480581.74 725492.69 1.96 480578.08 725491.89 1.96 480574.67 725491.63 1.96 480570.89 725491.89 1.96 480567.52 725492.62 1.96 480564.02 725493.97 1.96 480561.37 725495.41 1.96 480558.24 725497.61 1.96 480555.93 725499.97 1.96 480553.9 725502.59 1.96 480552.18 725505.53 1.96 480550.83 725508.81 1.96 480549.94 725512.41 1.96 480549.59 725515.81 1.96 480549.73 725519.37 1.96 480550.32 725522.71 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480550.32 725522.71 1.96 480549.73 725519.37 1.96 480549.73 725519.37 25.43 480550.32 725522.71 25.43 480550.32 725522.71 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480549.73 725519.37 1.96 480549.59 725515.81 1.96 480549.59 725515.81 25.43 480549.73 725519.37 25.43 480549.73 725519.37 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480549.59 725515.81 1.96 480549.94 725512.41 1.96 480549.94 725512.41 25.43 480549.59 725515.81 25.43 480549.59 725515.81 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480549.94 725512.41 1.96 480550.83 725508.81 1.96 480550.83 725508.81 25.43 480549.94 725512.41 25.43 480549.94 725512.41 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480550.83 725508.81 1.96 480552.18 725505.53 1.96 480552.18 725505.53 25.43 480550.83 725508.81 25.43 480550.83 725508.81 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480552.18 725505.53 1.96 480553.9 725502.59 1.96 480553.9 725502.59 25.43 480552.18 725505.53 25.43 480552.18 725505.53 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480553.9 725502.59 1.96 480555.93 725499.97 1.96 480555.93 725499.97 25.43 480553.9 725502.59 25.43 480553.9 725502.59 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480555.93 725499.97 1.96 480558.24 725497.61 1.96 480558.24 725497.61 25.43 480555.93 725499.97 25.43 480555.93 725499.97 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480558.24 725497.61 1.96 480561.37 725495.41 1.96 480561.37 725495.41 25.43 480558.24 725497.61 25.43 480558.24 725497.61 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480561.37 725495.41 1.96 480564.02 725493.97 1.96 480564.02 725493.97 25.43 480561.37 725495.41 25.43 480561.37 725495.41 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480564.02 725493.97 1.96 480567.52 725492.62 1.96 480567.52 725492.62 25.43 480564.02 725493.97 25.43 480564.02 725493.97 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480567.52 725492.62 1.96 480570.89 725491.89 1.96 480570.89 725491.89 25.43 480567.52 725492.62 25.43 480567.52 725492.62 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480570.89 725491.89 1.96 480574.67 725491.63 1.96 480574.67 725491.63 25.43 480570.89 725491.89 25.43 480570.89 725491.89 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480574.67 725491.63 1.96 480578.08 725491.89 1.96 480578.08 725491.89 25.43 480574.67 725491.63 25.43 480574.67 725491.63 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480578.08 725491.89 1.96 480581.74 725492.69 1.96 480581.74 725492.69 25.43 480578.08 725491.89 25.43 480578.08 725491.89 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480581.74 725492.69 1.96 480584.57 725493.7 1.96 480584.57 725493.7 25.43 480581.74 725492.69 25.43 480581.74 725492.69 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480584.57 725493.7 1.96 480586.73 725494.78 1.96 480586.73 725494.78 25.43 480584.57 725493.7 25.43 480584.57 725493.7 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480586.73 725494.78 1.96 480587.84 725495.48 1.96 480587.84 725495.48 25.43 480586.73 725494.78 25.43 480586.73 725494.78 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480587.84 725495.48 1.96 480590.8 725497.63 1.96 480590.8 725497.63 25.43 480587.84 725495.48 25.43 480587.84 725495.48 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480590.8 725497.63 1.96 480593.33 725500.14 1.96 480593.33 725500.14 25.43 480590.8 725497.63 25.43 480590.8 725497.63 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480593.33 725500.14 1.96 480595.64 725503.21 1.96 480595.64 725503.21 25.43 480593.33 725500.14 25.43 480593.33 725500.14 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480595.64 725503.21 1.96 480597.26 725506.2 1.96 480597.26 725506.2 25.43 480595.64 725503.21 25.43 480595.64 725503.21 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480597.26 725506.2 1.96 480598.41 725509.2 1.96 480598.41 725509.2 25.43 480597.26 725506.2 25.43 480597.26 725506.2 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480598.41 725509.2 1.96 480599.26 725512.77 1.96 480599.26 725512.77 25.43 480598.41 725509.2 25.43 480598.41 725509.2 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480599.26 725512.77 1.96 480599.53 725516.02 1.96 480599.53 725516.02 25.43 480599.26 725512.77 25.43 480599.26 725512.77 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480599.53 725516.02 1.96 480599.39 725519.39 1.96 480599.39 725519.39 25.43 480599.53 725516.02 25.43 480599.53 725516.02 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480599.39 725519.39 1.96 480598.65 725523.27 1.96 480598.65 725523.27 25.43 480599.39 725519.39 25.43 480599.39 725519.39 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480598.65 725523.27 1.96 480597.51 725526.49 1.96 480597.51 725526.49 25.43 480598.65 725523.27 25.43 480598.65 725523.27 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480597.51 725526.49 1.96 480595.92 725529.6 1.96 480595.92 725529.6 25.43 480597.51 725526.49 25.43 480597.51 725526.49 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480595.92 725529.6 1.96 480593.89 725532.47 1.96 480593.89 725532.47 25.43 480595.92 725529.6 25.43 480595.92 725529.6 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480593.89 725532.47 1.96 480591.47 725535.02 1.96 480591.47 725535.02 25.43 480593.89 725532.47 25.43 480593.89 725532.47 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480591.47 725535.02 1.96 480588.68 725537.23 1.96 480588.68 725537.23 25.43 480591.47 725535.02 25.43 480591.47 725535.02 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480588.68 725537.23 1.96 480585.75 725538.97 1.96 480585.75 725538.97 25.43 480588.68 725537.23 25.43 480588.68 725537.23 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480585.75 725538.97 1.96 480582.48 725540.33 1.96 480582.48 725540.33 25.43 480585.75 725538.97 25.43 480585.75 725538.97 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480582.48 725540.33 1.96 480580.16 725540.98 1.96 480580.16 725540.98 25.43 480582.48 725540.33 25.43 480582.48 725540.33 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480580.16 725540.98 1.96 480576.55 725541.54 1.96 480576.55 725541.54 25.43 480580.16 725540.98 25.43 480580.16 725540.98 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480576.55 725541.54 1.96 480573.18 725541.58 1.96 480573.18 725541.58 25.43 480576.55 725541.54 25.43 480576.55 725541.54 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480573.18 725541.58 1.96 480569.56 725541.13 1.96 480569.56 725541.13 25.43 480573.18 725541.58 25.43 480573.18 725541.58 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480569.56 725541.13 1.96 480566.18 725540.19 1.96 480566.18 725540.19 25.43 480569.56 725541.13 25.43 480569.56 725541.13 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480566.18 725540.19 1.96 480562.93 725538.77 1.96 480562.93 725538.77 25.43 480566.18 725540.19 25.43 480566.18 725540.19 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480562.93 725538.77 1.96 480559.95 725536.94 1.96 480559.95 725536.94 25.43 480562.93 725538.77 25.43 480562.93 725538.77 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480559.95 725536.94 1.96 480557.27 725534.77 1.96 480557.27 725534.77 25.43 480559.95 725536.94 25.43 480559.95 725536.94 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480557.27 725534.77 1.96 480555 725532.19 1.96 480555 725532.19 25.43 480557.27 725534.77 25.43 480557.27 725534.77 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480555 725532.19 1.96 480552.95 725529.2 1.96 480552.95 725529.2 25.43 480555 725532.19 25.43 480555 725532.19 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480552.95 725529.2 1.96 480551.47 725526.18 1.96 480551.47 725526.18 25.43 480552.95 725529.2 25.43 480552.95 725529.2 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480551.47 725526.18 1.96 480550.32 725522.71 1.96 480550.32 725522.71 25.43 480551.47 725526.18 25.43 480551.47 725526.18 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-12af6fc5-ffab-4c86-9e92-61ba35466004_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480550.32 725522.71 25.43 480549.73 725519.37 25.43 480549.59 725515.81 25.43 480549.94 725512.41 25.43 480550.83 725508.81 25.43 480552.18 725505.53 25.43 480553.9 725502.59 25.43 480555.93 725499.97 25.43 480558.24 725497.61 25.43 480561.37 725495.41 25.43 480564.02 725493.97 25.43 480567.52 725492.62 25.43 480570.89 725491.89 25.43 480574.67 725491.63 25.43 480578.08 725491.89 25.43 480581.74 725492.69 25.43 480584.57 725493.7 25.43 480586.73 725494.78 25.43 480587.84 725495.48 25.43 480590.8 725497.63 25.43 480593.33 725500.14 25.43 480595.64 725503.21 25.43 480597.26 725506.2 25.43 480598.41 725509.2 25.43 480599.26 725512.77 25.43 480599.53 725516.02 25.43 480599.39 725519.39 25.43 480598.65 725523.27 25.43 480597.51 725526.49 25.43 480595.92 725529.6 25.43 480593.89 725532.47 25.43 480591.47 725535.02 25.43 480588.68 725537.23 25.43 480585.75 725538.97 25.43 480582.48 725540.33 25.43 480580.16 725540.98 25.43 480576.55 725541.54 25.43 480573.18 725541.58 25.43 480569.56 725541.13 25.43 480566.18 725540.19 25.43 480562.93 725538.77 25.43 480559.95 725536.94 25.43 480557.27 725534.77 25.43 480555 725532.19 25.43 480552.95 725529.2 25.43 480551.47 725526.18 25.43 480550.32 725522.71 25.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-74a64fdf-010b-4d70-af4e-cbc367dffeb1">
			<gen:stringAttribute name="buildingId">
				<gen:value>74a64fdf-010b-4d70-af4e-cbc367dffeb1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-74a64fdf-010b-4d70-af4e-cbc367dffeb1_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479980.04 725716.17 2.24 479979.66 725716.04 2.24 479975.25 725716.17 2.24 479971.77 725716.26 2.24 479971.05 725716.27 2.24 479971.31 725735.09 2.24 479980.31 725734.95 2.24 479980.04 725716.17 2.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-74a64fdf-010b-4d70-af4e-cbc367dffeb1_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479980.04 725716.17 2.24 479980.31 725734.95 2.24 479980.31 725734.95 6.7700000000000005 479980.04 725716.17 6.7700000000000005 479980.04 725716.17 2.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-74a64fdf-010b-4d70-af4e-cbc367dffeb1_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479980.31 725734.95 2.24 479971.31 725735.09 2.24 479971.31 725735.09 6.7700000000000005 479980.31 725734.95 6.7700000000000005 479980.31 725734.95 2.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-74a64fdf-010b-4d70-af4e-cbc367dffeb1_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.31 725735.09 2.24 479971.05 725716.27 2.24 479971.05 725716.27 6.7700000000000005 479971.31 725735.09 6.7700000000000005 479971.31 725735.09 2.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-74a64fdf-010b-4d70-af4e-cbc367dffeb1_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.05 725716.27 2.24 479971.77 725716.26 2.24 479971.77 725716.26 6.7700000000000005 479971.05 725716.27 6.7700000000000005 479971.05 725716.27 2.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-74a64fdf-010b-4d70-af4e-cbc367dffeb1_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.77 725716.26 2.24 479975.25 725716.17 2.24 479975.25 725716.17 6.7700000000000005 479971.77 725716.26 6.7700000000000005 479971.77 725716.26 2.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-74a64fdf-010b-4d70-af4e-cbc367dffeb1_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479975.25 725716.17 2.24 479979.66 725716.04 2.24 479979.66 725716.04 6.7700000000000005 479975.25 725716.17 6.7700000000000005 479975.25 725716.17 2.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-74a64fdf-010b-4d70-af4e-cbc367dffeb1_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479979.66 725716.04 2.24 479980.04 725716.17 2.24 479980.04 725716.17 6.7700000000000005 479979.66 725716.04 6.7700000000000005 479979.66 725716.04 2.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-74a64fdf-010b-4d70-af4e-cbc367dffeb1_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479980.04 725716.17 6.7700000000000005 479980.31 725734.95 6.7700000000000005 479971.31 725735.09 6.7700000000000005 479971.05 725716.27 6.7700000000000005 479971.77 725716.26 6.7700000000000005 479975.25 725716.17 6.7700000000000005 479979.66 725716.04 6.7700000000000005 479980.04 725716.17 6.7700000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-f542c772-0a5c-4584-8e45-4229290c31f0">
			<gen:stringAttribute name="buildingId">
				<gen:value>f542c772-0a5c-4584-8e45-4229290c31f0</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.71</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f542c772-0a5c-4584-8e45-4229290c31f0_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.44 725692.13 2.2 479957.9 725692.31 2.2 479958.24 725716.45 2.2 479971.05 725716.27 2.2 479971.77 725716.26 2.2 479971.44 725692.13 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f542c772-0a5c-4584-8e45-4229290c31f0_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.44 725692.13 2.2 479971.77 725716.26 2.2 479971.77 725716.26 10.91 479971.44 725692.13 10.91 479971.44 725692.13 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f542c772-0a5c-4584-8e45-4229290c31f0_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.77 725716.26 2.2 479971.05 725716.27 2.2 479971.05 725716.27 10.91 479971.77 725716.26 10.91 479971.77 725716.26 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f542c772-0a5c-4584-8e45-4229290c31f0_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.05 725716.27 2.2 479958.24 725716.45 2.2 479958.24 725716.45 10.91 479971.05 725716.27 10.91 479971.05 725716.27 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f542c772-0a5c-4584-8e45-4229290c31f0_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479958.24 725716.45 2.2 479957.9 725692.31 2.2 479957.9 725692.31 10.91 479958.24 725716.45 10.91 479958.24 725716.45 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f542c772-0a5c-4584-8e45-4229290c31f0_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479957.9 725692.31 2.2 479971.44 725692.13 2.2 479971.44 725692.13 10.91 479957.9 725692.31 10.91 479957.9 725692.31 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f542c772-0a5c-4584-8e45-4229290c31f0_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.44 725692.13 10.91 479971.77 725716.26 10.91 479971.05 725716.27 10.91 479958.24 725716.45 10.91 479957.9 725692.31 10.91 479971.44 725692.13 10.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-accba098-f8d9-407d-8ed5-7c9e74477737">
			<gen:stringAttribute name="buildingId">
				<gen:value>accba098-f8d9-407d-8ed5-7c9e74477737</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.34</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-accba098-f8d9-407d-8ed5-7c9e74477737_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479979.57 725706.86 2.23 479975.07 725706.91 2.23 479975.25 725716.17 2.23 479979.66 725716.04 2.23 479979.57 725706.86 2.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-accba098-f8d9-407d-8ed5-7c9e74477737_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479979.57 725706.86 2.23 479979.66 725716.04 2.23 479979.66 725716.04 6.57 479979.57 725706.86 6.57 479979.57 725706.86 2.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-accba098-f8d9-407d-8ed5-7c9e74477737_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479979.66 725716.04 2.23 479975.25 725716.17 2.23 479975.25 725716.17 6.57 479979.66 725716.04 6.57 479979.66 725716.04 2.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-accba098-f8d9-407d-8ed5-7c9e74477737_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479975.25 725716.17 2.23 479975.07 725706.91 2.23 479975.07 725706.91 6.57 479975.25 725716.17 6.57 479975.25 725716.17 2.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-accba098-f8d9-407d-8ed5-7c9e74477737_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479975.07 725706.91 2.23 479979.57 725706.86 2.23 479979.57 725706.86 6.57 479975.07 725706.91 6.57 479975.07 725706.91 2.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-accba098-f8d9-407d-8ed5-7c9e74477737_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479979.57 725706.86 6.57 479979.66 725716.04 6.57 479975.25 725716.17 6.57 479975.07 725706.91 6.57 479979.57 725706.86 6.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-b57a4be9-d8e3-4d85-b97e-e80c7e4e3351">
			<gen:stringAttribute name="buildingId">
				<gen:value>b57a4be9-d8e3-4d85-b97e-e80c7e4e3351</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.07</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b57a4be9-d8e3-4d85-b97e-e80c7e4e3351_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481617.48 724000.32 2.97 481650.82 724038.34 2.97 481666.18 724024.86 2.97 481632.86 723986.86 2.97 481617.48 724000.32 2.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b57a4be9-d8e3-4d85-b97e-e80c7e4e3351_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481617.48 724000.32 2.97 481632.86 723986.86 2.97 481632.86 723986.86 10.040000000000001 481617.48 724000.32 10.040000000000001 481617.48 724000.32 2.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b57a4be9-d8e3-4d85-b97e-e80c7e4e3351_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481632.86 723986.86 2.97 481666.18 724024.86 2.97 481666.18 724024.86 10.040000000000001 481632.86 723986.86 10.040000000000001 481632.86 723986.86 2.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b57a4be9-d8e3-4d85-b97e-e80c7e4e3351_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481666.18 724024.86 2.97 481650.82 724038.34 2.97 481650.82 724038.34 10.040000000000001 481666.18 724024.86 10.040000000000001 481666.18 724024.86 2.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b57a4be9-d8e3-4d85-b97e-e80c7e4e3351_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481650.82 724038.34 2.97 481617.48 724000.32 2.97 481617.48 724000.32 10.040000000000001 481650.82 724038.34 10.040000000000001 481650.82 724038.34 2.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b57a4be9-d8e3-4d85-b97e-e80c7e4e3351_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>481617.48 724000.32 10.040000000000001 481632.86 723986.86 10.040000000000001 481666.18 724024.86 10.040000000000001 481650.82 724038.34 10.040000000000001 481617.48 724000.32 10.040000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-b712ba1c-f941-456a-958a-98508eb6f00d">
			<gen:stringAttribute name="buildingId">
				<gen:value>b712ba1c-f941-456a-958a-98508eb6f00d</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">13.35</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b712ba1c-f941-456a-958a-98508eb6f00d_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480358.67 723705.39 3.21 480448.79 723819.02 3.21 480647 723661.83 3.21 480556.86 723548.19 3.21 480358.67 723705.39 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b712ba1c-f941-456a-958a-98508eb6f00d_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480358.67 723705.39 3.21 480556.86 723548.19 3.21 480556.86 723548.19 16.56 480358.67 723705.39 16.56 480358.67 723705.39 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b712ba1c-f941-456a-958a-98508eb6f00d_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480556.86 723548.19 3.21 480647 723661.83 3.21 480647 723661.83 16.56 480556.86 723548.19 16.56 480556.86 723548.19 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b712ba1c-f941-456a-958a-98508eb6f00d_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480647 723661.83 3.21 480448.79 723819.02 3.21 480448.79 723819.02 16.56 480647 723661.83 16.56 480647 723661.83 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b712ba1c-f941-456a-958a-98508eb6f00d_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480448.79 723819.02 3.21 480358.67 723705.39 3.21 480358.67 723705.39 16.56 480448.79 723819.02 16.56 480448.79 723819.02 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b712ba1c-f941-456a-958a-98508eb6f00d_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480358.67 723705.39 16.56 480556.86 723548.19 16.56 480647 723661.83 16.56 480448.79 723819.02 16.56 480358.67 723705.39 16.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80">
			<gen:stringAttribute name="buildingId">
				<gen:value>09744152-c8e9-4a72-bfdb-9f18aed49a80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">26.64</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480633.65 725562.13 1.94 480634.25 725565.2 1.94 480635.13 725568.21 1.94 480636.27 725571.12 1.94 480637.67 725573.93 1.94 480639.32 725576.6 1.94 480641.2 725579.11 1.94 480643.3 725581.44 1.94 480645.59 725583.58 1.94 480648.07 725585.5 1.94 480650.7 725587.18 1.94 480653.49 725588.63 1.94 480656.39 725589.82 1.94 480659.38 725590.75 1.94 480662.45 725591.4 1.94 480665.56 725591.78 1.94 480668.7 725591.87 1.94 480671.83 725591.69 1.94 480674.93 725591.23 1.94 480677.98 725590.48 1.94 480680.94 725589.47 1.94 480683.8 725588.2 1.94 480686.55 725586.67 1.94 480689.13 725584.92 1.94 480691.56 725582.92 1.94 480693.79 725580.72 1.94 480695.82 725578.34 1.94 480697.63 725575.77 1.94 480699.2 725573.06 1.94 480700.52 725570.21 1.94 480701.57 725567.27 1.94 480702.37 725564.23 1.94 480702.89 725561.14 1.94 480703.12 725558.01 1.94 480703.08 725554.89 1.94 480702.75 725551.76 1.94 480702.15 725548.69 1.94 480701.27 725545.68 1.94 480700.13 725542.75 1.94 480698.73 725539.96 1.94 480697.08 725537.29 1.94 480695.21 725534.78 1.94 480693.1 725532.44 1.94 480690.82 725530.31 1.94 480688.33 725528.39 1.94 480685.7 725526.7 1.94 480682.91 725525.26 1.94 480680.01 725524.06 1.94 480677.02 725523.13 1.94 480673.95 725522.49 1.94 480670.84 725522.11 1.94 480667.71 725522.01 1.94 480664.57 725522.2 1.94 480661.47 725522.66 1.94 480658.42 725523.4 1.94 480655.46 725524.41 1.94 480652.6 725525.69 1.94 480649.85 725527.21 1.94 480647.27 725528.97 1.94 480644.84 725530.97 1.94 480642.61 725533.16 1.94 480640.58 725535.55 1.94 480638.77 725538.12 1.94 480637.2 725540.83 1.94 480635.88 725543.67 1.94 480634.83 725546.62 1.94 480634.03 725549.66 1.94 480633.51 725552.74 1.94 480633.28 725555.88 1.94 480633.32 725559 1.94 480633.65 725562.13 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480633.65 725562.13 1.94 480633.32 725559 1.94 480633.32 725559 28.580000000000002 480633.65 725562.13 28.580000000000002 480633.65 725562.13 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480633.32 725559 1.94 480633.28 725555.88 1.94 480633.28 725555.88 28.580000000000002 480633.32 725559 28.580000000000002 480633.32 725559 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480633.28 725555.88 1.94 480633.51 725552.74 1.94 480633.51 725552.74 28.580000000000002 480633.28 725555.88 28.580000000000002 480633.28 725555.88 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480633.51 725552.74 1.94 480634.03 725549.66 1.94 480634.03 725549.66 28.580000000000002 480633.51 725552.74 28.580000000000002 480633.51 725552.74 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480634.03 725549.66 1.94 480634.83 725546.62 1.94 480634.83 725546.62 28.580000000000002 480634.03 725549.66 28.580000000000002 480634.03 725549.66 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480634.83 725546.62 1.94 480635.88 725543.67 1.94 480635.88 725543.67 28.580000000000002 480634.83 725546.62 28.580000000000002 480634.83 725546.62 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480635.88 725543.67 1.94 480637.2 725540.83 1.94 480637.2 725540.83 28.580000000000002 480635.88 725543.67 28.580000000000002 480635.88 725543.67 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480637.2 725540.83 1.94 480638.77 725538.12 1.94 480638.77 725538.12 28.580000000000002 480637.2 725540.83 28.580000000000002 480637.2 725540.83 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480638.77 725538.12 1.94 480640.58 725535.55 1.94 480640.58 725535.55 28.580000000000002 480638.77 725538.12 28.580000000000002 480638.77 725538.12 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480640.58 725535.55 1.94 480642.61 725533.16 1.94 480642.61 725533.16 28.580000000000002 480640.58 725535.55 28.580000000000002 480640.58 725535.55 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480642.61 725533.16 1.94 480644.84 725530.97 1.94 480644.84 725530.97 28.580000000000002 480642.61 725533.16 28.580000000000002 480642.61 725533.16 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480644.84 725530.97 1.94 480647.27 725528.97 1.94 480647.27 725528.97 28.580000000000002 480644.84 725530.97 28.580000000000002 480644.84 725530.97 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480647.27 725528.97 1.94 480649.85 725527.21 1.94 480649.85 725527.21 28.580000000000002 480647.27 725528.97 28.580000000000002 480647.27 725528.97 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480649.85 725527.21 1.94 480652.6 725525.69 1.94 480652.6 725525.69 28.580000000000002 480649.85 725527.21 28.580000000000002 480649.85 725527.21 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480652.6 725525.69 1.94 480655.46 725524.41 1.94 480655.46 725524.41 28.580000000000002 480652.6 725525.69 28.580000000000002 480652.6 725525.69 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480655.46 725524.41 1.94 480658.42 725523.4 1.94 480658.42 725523.4 28.580000000000002 480655.46 725524.41 28.580000000000002 480655.46 725524.41 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480658.42 725523.4 1.94 480661.47 725522.66 1.94 480661.47 725522.66 28.580000000000002 480658.42 725523.4 28.580000000000002 480658.42 725523.4 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480661.47 725522.66 1.94 480664.57 725522.2 1.94 480664.57 725522.2 28.580000000000002 480661.47 725522.66 28.580000000000002 480661.47 725522.66 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480664.57 725522.2 1.94 480667.71 725522.01 1.94 480667.71 725522.01 28.580000000000002 480664.57 725522.2 28.580000000000002 480664.57 725522.2 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480667.71 725522.01 1.94 480670.84 725522.11 1.94 480670.84 725522.11 28.580000000000002 480667.71 725522.01 28.580000000000002 480667.71 725522.01 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480670.84 725522.11 1.94 480673.95 725522.49 1.94 480673.95 725522.49 28.580000000000002 480670.84 725522.11 28.580000000000002 480670.84 725522.11 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480673.95 725522.49 1.94 480677.02 725523.13 1.94 480677.02 725523.13 28.580000000000002 480673.95 725522.49 28.580000000000002 480673.95 725522.49 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480677.02 725523.13 1.94 480680.01 725524.06 1.94 480680.01 725524.06 28.580000000000002 480677.02 725523.13 28.580000000000002 480677.02 725523.13 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480680.01 725524.06 1.94 480682.91 725525.26 1.94 480682.91 725525.26 28.580000000000002 480680.01 725524.06 28.580000000000002 480680.01 725524.06 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480682.91 725525.26 1.94 480685.7 725526.7 1.94 480685.7 725526.7 28.580000000000002 480682.91 725525.26 28.580000000000002 480682.91 725525.26 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480685.7 725526.7 1.94 480688.33 725528.39 1.94 480688.33 725528.39 28.580000000000002 480685.7 725526.7 28.580000000000002 480685.7 725526.7 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480688.33 725528.39 1.94 480690.82 725530.31 1.94 480690.82 725530.31 28.580000000000002 480688.33 725528.39 28.580000000000002 480688.33 725528.39 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480690.82 725530.31 1.94 480693.1 725532.44 1.94 480693.1 725532.44 28.580000000000002 480690.82 725530.31 28.580000000000002 480690.82 725530.31 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480693.1 725532.44 1.94 480695.21 725534.78 1.94 480695.21 725534.78 28.580000000000002 480693.1 725532.44 28.580000000000002 480693.1 725532.44 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480695.21 725534.78 1.94 480697.08 725537.29 1.94 480697.08 725537.29 28.580000000000002 480695.21 725534.78 28.580000000000002 480695.21 725534.78 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480697.08 725537.29 1.94 480698.73 725539.96 1.94 480698.73 725539.96 28.580000000000002 480697.08 725537.29 28.580000000000002 480697.08 725537.29 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480698.73 725539.96 1.94 480700.13 725542.75 1.94 480700.13 725542.75 28.580000000000002 480698.73 725539.96 28.580000000000002 480698.73 725539.96 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480700.13 725542.75 1.94 480701.27 725545.68 1.94 480701.27 725545.68 28.580000000000002 480700.13 725542.75 28.580000000000002 480700.13 725542.75 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480701.27 725545.68 1.94 480702.15 725548.69 1.94 480702.15 725548.69 28.580000000000002 480701.27 725545.68 28.580000000000002 480701.27 725545.68 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480702.15 725548.69 1.94 480702.75 725551.76 1.94 480702.75 725551.76 28.580000000000002 480702.15 725548.69 28.580000000000002 480702.15 725548.69 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480702.75 725551.76 1.94 480703.08 725554.89 1.94 480703.08 725554.89 28.580000000000002 480702.75 725551.76 28.580000000000002 480702.75 725551.76 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480703.08 725554.89 1.94 480703.12 725558.01 1.94 480703.12 725558.01 28.580000000000002 480703.08 725554.89 28.580000000000002 480703.08 725554.89 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480703.12 725558.01 1.94 480702.89 725561.14 1.94 480702.89 725561.14 28.580000000000002 480703.12 725558.01 28.580000000000002 480703.12 725558.01 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480702.89 725561.14 1.94 480702.37 725564.23 1.94 480702.37 725564.23 28.580000000000002 480702.89 725561.14 28.580000000000002 480702.89 725561.14 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480702.37 725564.23 1.94 480701.57 725567.27 1.94 480701.57 725567.27 28.580000000000002 480702.37 725564.23 28.580000000000002 480702.37 725564.23 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480701.57 725567.27 1.94 480700.52 725570.21 1.94 480700.52 725570.21 28.580000000000002 480701.57 725567.27 28.580000000000002 480701.57 725567.27 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480700.52 725570.21 1.94 480699.2 725573.06 1.94 480699.2 725573.06 28.580000000000002 480700.52 725570.21 28.580000000000002 480700.52 725570.21 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480699.2 725573.06 1.94 480697.63 725575.77 1.94 480697.63 725575.77 28.580000000000002 480699.2 725573.06 28.580000000000002 480699.2 725573.06 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480697.63 725575.77 1.94 480695.82 725578.34 1.94 480695.82 725578.34 28.580000000000002 480697.63 725575.77 28.580000000000002 480697.63 725575.77 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480695.82 725578.34 1.94 480693.79 725580.72 1.94 480693.79 725580.72 28.580000000000002 480695.82 725578.34 28.580000000000002 480695.82 725578.34 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480693.79 725580.72 1.94 480691.56 725582.92 1.94 480691.56 725582.92 28.580000000000002 480693.79 725580.72 28.580000000000002 480693.79 725580.72 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480691.56 725582.92 1.94 480689.13 725584.92 1.94 480689.13 725584.92 28.580000000000002 480691.56 725582.92 28.580000000000002 480691.56 725582.92 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480689.13 725584.92 1.94 480686.55 725586.67 1.94 480686.55 725586.67 28.580000000000002 480689.13 725584.92 28.580000000000002 480689.13 725584.92 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480686.55 725586.67 1.94 480683.8 725588.2 1.94 480683.8 725588.2 28.580000000000002 480686.55 725586.67 28.580000000000002 480686.55 725586.67 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480683.8 725588.2 1.94 480680.94 725589.47 1.94 480680.94 725589.47 28.580000000000002 480683.8 725588.2 28.580000000000002 480683.8 725588.2 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480680.94 725589.47 1.94 480677.98 725590.48 1.94 480677.98 725590.48 28.580000000000002 480680.94 725589.47 28.580000000000002 480680.94 725589.47 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480677.98 725590.48 1.94 480674.93 725591.23 1.94 480674.93 725591.23 28.580000000000002 480677.98 725590.48 28.580000000000002 480677.98 725590.48 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480674.93 725591.23 1.94 480671.83 725591.69 1.94 480671.83 725591.69 28.580000000000002 480674.93 725591.23 28.580000000000002 480674.93 725591.23 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480671.83 725591.69 1.94 480668.7 725591.87 1.94 480668.7 725591.87 28.580000000000002 480671.83 725591.69 28.580000000000002 480671.83 725591.69 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480668.7 725591.87 1.94 480665.56 725591.78 1.94 480665.56 725591.78 28.580000000000002 480668.7 725591.87 28.580000000000002 480668.7 725591.87 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480665.56 725591.78 1.94 480662.45 725591.4 1.94 480662.45 725591.4 28.580000000000002 480665.56 725591.78 28.580000000000002 480665.56 725591.78 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480662.45 725591.4 1.94 480659.38 725590.75 1.94 480659.38 725590.75 28.580000000000002 480662.45 725591.4 28.580000000000002 480662.45 725591.4 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480659.38 725590.75 1.94 480656.39 725589.82 1.94 480656.39 725589.82 28.580000000000002 480659.38 725590.75 28.580000000000002 480659.38 725590.75 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480656.39 725589.82 1.94 480653.49 725588.63 1.94 480653.49 725588.63 28.580000000000002 480656.39 725589.82 28.580000000000002 480656.39 725589.82 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480653.49 725588.63 1.94 480650.7 725587.18 1.94 480650.7 725587.18 28.580000000000002 480653.49 725588.63 28.580000000000002 480653.49 725588.63 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480650.7 725587.18 1.94 480648.07 725585.5 1.94 480648.07 725585.5 28.580000000000002 480650.7 725587.18 28.580000000000002 480650.7 725587.18 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480648.07 725585.5 1.94 480645.59 725583.58 1.94 480645.59 725583.58 28.580000000000002 480648.07 725585.5 28.580000000000002 480648.07 725585.5 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480645.59 725583.58 1.94 480643.3 725581.44 1.94 480643.3 725581.44 28.580000000000002 480645.59 725583.58 28.580000000000002 480645.59 725583.58 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480643.3 725581.44 1.94 480641.2 725579.11 1.94 480641.2 725579.11 28.580000000000002 480643.3 725581.44 28.580000000000002 480643.3 725581.44 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480641.2 725579.11 1.94 480639.32 725576.6 1.94 480639.32 725576.6 28.580000000000002 480641.2 725579.11 28.580000000000002 480641.2 725579.11 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480639.32 725576.6 1.94 480637.67 725573.93 1.94 480637.67 725573.93 28.580000000000002 480639.32 725576.6 28.580000000000002 480639.32 725576.6 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480637.67 725573.93 1.94 480636.27 725571.12 1.94 480636.27 725571.12 28.580000000000002 480637.67 725573.93 28.580000000000002 480637.67 725573.93 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480636.27 725571.12 1.94 480635.13 725568.21 1.94 480635.13 725568.21 28.580000000000002 480636.27 725571.12 28.580000000000002 480636.27 725571.12 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480635.13 725568.21 1.94 480634.25 725565.2 1.94 480634.25 725565.2 28.580000000000002 480635.13 725568.21 28.580000000000002 480635.13 725568.21 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480634.25 725565.2 1.94 480633.65 725562.13 1.94 480633.65 725562.13 28.580000000000002 480634.25 725565.2 28.580000000000002 480634.25 725565.2 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-09744152-c8e9-4a72-bfdb-9f18aed49a80_PG_72">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480633.65 725562.13 28.580000000000002 480633.32 725559 28.580000000000002 480633.28 725555.88 28.580000000000002 480633.51 725552.74 28.580000000000002 480634.03 725549.66 28.580000000000002 480634.83 725546.62 28.580000000000002 480635.88 725543.67 28.580000000000002 480637.2 725540.83 28.580000000000002 480638.77 725538.12 28.580000000000002 480640.58 725535.55 28.580000000000002 480642.61 725533.16 28.580000000000002 480644.84 725530.97 28.580000000000002 480647.27 725528.97 28.580000000000002 480649.85 725527.21 28.580000000000002 480652.6 725525.69 28.580000000000002 480655.46 725524.41 28.580000000000002 480658.42 725523.4 28.580000000000002 480661.47 725522.66 28.580000000000002 480664.57 725522.2 28.580000000000002 480667.71 725522.01 28.580000000000002 480670.84 725522.11 28.580000000000002 480673.95 725522.49 28.580000000000002 480677.02 725523.13 28.580000000000002 480680.01 725524.06 28.580000000000002 480682.91 725525.26 28.580000000000002 480685.7 725526.7 28.580000000000002 480688.33 725528.39 28.580000000000002 480690.82 725530.31 28.580000000000002 480693.1 725532.44 28.580000000000002 480695.21 725534.78 28.580000000000002 480697.08 725537.29 28.580000000000002 480698.73 725539.96 28.580000000000002 480700.13 725542.75 28.580000000000002 480701.27 725545.68 28.580000000000002 480702.15 725548.69 28.580000000000002 480702.75 725551.76 28.580000000000002 480703.08 725554.89 28.580000000000002 480703.12 725558.01 28.580000000000002 480702.89 725561.14 28.580000000000002 480702.37 725564.23 28.580000000000002 480701.57 725567.27 28.580000000000002 480700.52 725570.21 28.580000000000002 480699.2 725573.06 28.580000000000002 480697.63 725575.77 28.580000000000002 480695.82 725578.34 28.580000000000002 480693.79 725580.72 28.580000000000002 480691.56 725582.92 28.580000000000002 480689.13 725584.92 28.580000000000002 480686.55 725586.67 28.580000000000002 480683.8 725588.2 28.580000000000002 480680.94 725589.47 28.580000000000002 480677.98 725590.48 28.580000000000002 480674.93 725591.23 28.580000000000002 480671.83 725591.69 28.580000000000002 480668.7 725591.87 28.580000000000002 480665.56 725591.78 28.580000000000002 480662.45 725591.4 28.580000000000002 480659.38 725590.75 28.580000000000002 480656.39 725589.82 28.580000000000002 480653.49 725588.63 28.580000000000002 480650.7 725587.18 28.580000000000002 480648.07 725585.5 28.580000000000002 480645.59 725583.58 28.580000000000002 480643.3 725581.44 28.580000000000002 480641.2 725579.11 28.580000000000002 480639.32 725576.6 28.580000000000002 480637.67 725573.93 28.580000000000002 480636.27 725571.12 28.580000000000002 480635.13 725568.21 28.580000000000002 480634.25 725565.2 28.580000000000002 480633.65 725562.13 28.580000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7896-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7896-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.42</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7896-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480359.16 725539.07 1.78 480373.04 725542.92 1.78 480375.25 725534.96 1.78 480361.37 725531.11 1.78 480359.16 725539.07 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7896-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480359.16 725539.07 1.78 480361.37 725531.11 1.78 480361.37 725531.11 8.2 480359.16 725539.07 8.2 480359.16 725539.07 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7896-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480361.37 725531.11 1.78 480375.25 725534.96 1.78 480375.25 725534.96 8.2 480361.37 725531.11 8.2 480361.37 725531.11 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7896-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480375.25 725534.96 1.78 480373.04 725542.92 1.78 480373.04 725542.92 8.2 480375.25 725534.96 8.2 480375.25 725534.96 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7896-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480373.04 725542.92 1.78 480359.16 725539.07 1.78 480359.16 725539.07 8.2 480373.04 725542.92 8.2 480373.04 725542.92 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7896-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480359.16 725539.07 8.2 480361.37 725531.11 8.2 480375.25 725534.96 8.2 480373.04 725542.92 8.2 480359.16 725539.07 8.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-794F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-794F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">23.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480717.78 724960.42 2.21 480765.72 724987.15 2.21 480844.99 724844.97 2.21 480797.05 724818.24 2.21 480717.78 724960.42 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480717.78 724960.42 2.21 480797.05 724818.24 2.21 480797.05 724818.24 26.05 480717.78 724960.42 26.05 480717.78 724960.42 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480797.05 724818.24 2.21 480844.99 724844.97 2.21 480844.99 724844.97 26.05 480797.05 724818.24 26.05 480797.05 724818.24 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480844.99 724844.97 2.21 480765.72 724987.15 2.21 480765.72 724987.15 26.05 480844.99 724844.97 26.05 480844.99 724844.97 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480765.72 724987.15 2.21 480717.78 724960.42 2.21 480717.78 724960.42 26.05 480765.72 724987.15 26.05 480765.72 724987.15 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-794F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480717.78 724960.42 26.05 480797.05 724818.24 26.05 480844.99 724844.97 26.05 480765.72 724987.15 26.05 480717.78 724960.42 26.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7722-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7722-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7722-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.05 725716.27 2.45 479958.24 725716.45 2.45 479958.75 725753.55 2.45 479966.45 725753.45 2.45 479971.56 725753.38 2.45 479971.31 725735.09 2.45 479971.05 725716.27 2.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7722-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.05 725716.27 2.45 479971.31 725735.09 2.45 479971.31 725735.09 10.879999999999999 479971.05 725716.27 10.879999999999999 479971.05 725716.27 2.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7722-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.31 725735.09 2.45 479971.56 725753.38 2.45 479971.56 725753.38 10.879999999999999 479971.31 725735.09 10.879999999999999 479971.31 725735.09 2.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7722-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.56 725753.38 2.45 479966.45 725753.45 2.45 479966.45 725753.45 10.879999999999999 479971.56 725753.38 10.879999999999999 479971.56 725753.38 2.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7722-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479966.45 725753.45 2.45 479958.75 725753.55 2.45 479958.75 725753.55 10.879999999999999 479966.45 725753.45 10.879999999999999 479966.45 725753.45 2.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7722-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479958.75 725753.55 2.45 479958.24 725716.45 2.45 479958.24 725716.45 10.879999999999999 479958.75 725753.55 10.879999999999999 479958.75 725753.55 2.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7722-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479958.24 725716.45 2.45 479971.05 725716.27 2.45 479971.05 725716.27 10.879999999999999 479958.24 725716.45 10.879999999999999 479958.24 725716.45 2.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7722-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479971.05 725716.27 10.879999999999999 479971.31 725735.09 10.879999999999999 479971.56 725753.38 10.879999999999999 479966.45 725753.45 10.879999999999999 479958.75 725753.55 10.879999999999999 479958.24 725716.45 10.879999999999999 479971.05 725716.27 10.879999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.3</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479944.74 725068.55 2.44 479944.76 725068.82 2.44 479945 725068.8 2.44 479945.61 725110.84 2.44 479945.37 725110.84 2.44 479945.39 725111.11 2.44 479958.5 725110.92 2.44 479958.48 725110.64 2.44 479958.24 725110.64 2.44 479957.82 725083.55 2.44 479994.02 725082.94 2.44 479994.04 725083.19 2.44 479994.31 725083.2 2.44 479993.96 725071.46 2.44 479990.7 725071.48 2.44 479990.68 725073.08 2.44 479969.97 725073.41 2.44 479969.95 725071.81 2.44 479966.68 725071.91 2.44 479966.7 725073.41 2.44 479957.69 725073.59 2.44 479957.62 725068.59 2.44 479957.87 725068.59 2.44 479957.86 725068.33 2.44 479944.74 725068.55 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479944.74 725068.55 2.44 479957.86 725068.33 2.44 479957.86 725068.33 10.74 479944.74 725068.55 10.74 479944.74 725068.55 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479957.86 725068.33 2.44 479957.87 725068.59 2.44 479957.87 725068.59 10.74 479957.86 725068.33 10.74 479957.86 725068.33 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479957.87 725068.59 2.44 479957.62 725068.59 2.44 479957.62 725068.59 10.74 479957.87 725068.59 10.74 479957.87 725068.59 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479957.62 725068.59 2.44 479957.69 725073.59 2.44 479957.69 725073.59 10.74 479957.62 725068.59 10.74 479957.62 725068.59 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479957.69 725073.59 2.44 479966.7 725073.41 2.44 479966.7 725073.41 10.74 479957.69 725073.59 10.74 479957.69 725073.59 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479966.7 725073.41 2.44 479966.68 725071.91 2.44 479966.68 725071.91 10.74 479966.7 725073.41 10.74 479966.7 725073.41 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479966.68 725071.91 2.44 479969.95 725071.81 2.44 479969.95 725071.81 10.74 479966.68 725071.91 10.74 479966.68 725071.91 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479969.95 725071.81 2.44 479969.97 725073.41 2.44 479969.97 725073.41 10.74 479969.95 725071.81 10.74 479969.95 725071.81 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479969.97 725073.41 2.44 479990.68 725073.08 2.44 479990.68 725073.08 10.74 479969.97 725073.41 10.74 479969.97 725073.41 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479990.68 725073.08 2.44 479990.7 725071.48 2.44 479990.7 725071.48 10.74 479990.68 725073.08 10.74 479990.68 725073.08 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479990.7 725071.48 2.44 479993.96 725071.46 2.44 479993.96 725071.46 10.74 479990.7 725071.48 10.74 479990.7 725071.48 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479993.96 725071.46 2.44 479994.31 725083.2 2.44 479994.31 725083.2 10.74 479993.96 725071.46 10.74 479993.96 725071.46 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479994.31 725083.2 2.44 479994.04 725083.19 2.44 479994.04 725083.19 10.74 479994.31 725083.2 10.74 479994.31 725083.2 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479994.04 725083.19 2.44 479994.02 725082.94 2.44 479994.02 725082.94 10.74 479994.04 725083.19 10.74 479994.04 725083.19 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479994.02 725082.94 2.44 479957.82 725083.55 2.44 479957.82 725083.55 10.74 479994.02 725082.94 10.74 479994.02 725082.94 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479957.82 725083.55 2.44 479958.24 725110.64 2.44 479958.24 725110.64 10.74 479957.82 725083.55 10.74 479957.82 725083.55 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479958.24 725110.64 2.44 479958.48 725110.64 2.44 479958.48 725110.64 10.74 479958.24 725110.64 10.74 479958.24 725110.64 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479958.48 725110.64 2.44 479958.5 725110.92 2.44 479958.5 725110.92 10.74 479958.48 725110.64 10.74 479958.48 725110.64 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479958.5 725110.92 2.44 479945.39 725111.11 2.44 479945.39 725111.11 10.74 479958.5 725110.92 10.74 479958.5 725110.92 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479945.39 725111.11 2.44 479945.37 725110.84 2.44 479945.37 725110.84 10.74 479945.39 725111.11 10.74 479945.39 725111.11 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479945.37 725110.84 2.44 479945.61 725110.84 2.44 479945.61 725110.84 10.74 479945.37 725110.84 10.74 479945.37 725110.84 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479945.61 725110.84 2.44 479945 725068.8 2.44 479945 725068.8 10.74 479945.61 725110.84 10.74 479945.61 725110.84 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479945 725068.8 2.44 479944.76 725068.82 2.44 479944.76 725068.82 10.74 479945 725068.8 10.74 479945 725068.8 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479944.76 725068.82 2.44 479944.74 725068.55 2.44 479944.74 725068.55 10.74 479944.76 725068.82 10.74 479944.76 725068.82 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C3F7-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479944.74 725068.55 10.74 479957.86 725068.33 10.74 479957.87 725068.59 10.74 479957.62 725068.59 10.74 479957.69 725073.59 10.74 479966.7 725073.41 10.74 479966.68 725071.91 10.74 479969.95 725071.81 10.74 479969.97 725073.41 10.74 479990.68 725073.08 10.74 479990.7 725071.48 10.74 479993.96 725071.46 10.74 479994.31 725083.2 10.74 479994.04 725083.19 10.74 479994.02 725082.94 10.74 479957.82 725083.55 10.74 479958.24 725110.64 10.74 479958.48 725110.64 10.74 479958.5 725110.92 10.74 479945.39 725111.11 10.74 479945.37 725110.84 10.74 479945.61 725110.84 10.74 479945 725068.8 10.74 479944.76 725068.82 10.74 479944.74 725068.55 10.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3">
			<gen:stringAttribute name="buildingId">
				<gen:value>6531f32e-4482-4f22-b348-e29fbd61ffe3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">26.57</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480682.14 725475.37 1.99 480682.74 725478.45 1.99 480683.63 725481.45 1.99 480684.77 725484.36 1.99 480686.18 725487.17 1.99 480687.82 725489.84 1.99 480689.71 725492.35 1.99 480691.8 725494.68 1.99 480694.1 725496.8 1.99 480696.58 725498.72 1.99 480699.23 725500.41 1.99 480702 725501.85 1.99 480704.9 725503.04 1.99 480707.9 725503.96 1.99 480710.97 725504.61 1.99 480714.08 725504.99 1.99 480717.21 725505.08 1.99 480720.34 725504.9 1.99 480723.44 725504.42 1.99 480726.49 725503.68 1.99 480729.45 725502.67 1.99 480732.32 725501.39 1.99 480735.06 725499.86 1.99 480737.64 725498.1 1.99 480740.06 725496.1 1.99 480742.3 725493.9 1.99 480744.33 725491.51 1.99 480746.13 725488.95 1.99 480747.7 725486.24 1.99 480749.02 725483.39 1.99 480750.07 725480.44 1.99 480750.86 725477.4 1.99 480751.37 725474.31 1.99 480751.6 725471.18 1.99 480751.56 725468.05 1.99 480751.22 725464.93 1.99 480750.62 725461.86 1.99 480749.74 725458.84 1.99 480748.6 725455.93 1.99 480747.19 725453.12 1.99 480745.54 725450.46 1.99 480743.67 725447.96 1.99 480741.57 725445.63 1.99 480739.27 725443.49 1.99 480736.79 725441.58 1.99 480734.15 725439.89 1.99 480731.36 725438.45 1.99 480728.46 725437.26 1.99 480725.46 725436.33 1.99 480722.39 725435.69 1.99 480719.28 725435.31 1.99 480716.15 725435.21 1.99 480713.03 725435.4 1.99 480709.92 725435.87 1.99 480706.88 725436.62 1.99 480703.91 725437.63 1.99 480701.05 725438.91 1.99 480698.3 725440.44 1.99 480695.72 725442.2 1.99 480693.3 725444.19 1.99 480691.06 725446.39 1.99 480689.04 725448.78 1.99 480687.24 725451.35 1.99 480685.67 725454.06 1.99 480684.36 725456.9 1.99 480683.3 725459.86 1.99 480682.5 725462.9 1.99 480682 725465.98 1.99 480681.76 725469.11 1.99 480681.81 725472.25 1.99 480682.14 725475.37 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480682.14 725475.37 1.99 480681.81 725472.25 1.99 480681.81 725472.25 28.560000000000002 480682.14 725475.37 28.560000000000002 480682.14 725475.37 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480681.81 725472.25 1.99 480681.76 725469.11 1.99 480681.76 725469.11 28.560000000000002 480681.81 725472.25 28.560000000000002 480681.81 725472.25 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480681.76 725469.11 1.99 480682 725465.98 1.99 480682 725465.98 28.560000000000002 480681.76 725469.11 28.560000000000002 480681.76 725469.11 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480682 725465.98 1.99 480682.5 725462.9 1.99 480682.5 725462.9 28.560000000000002 480682 725465.98 28.560000000000002 480682 725465.98 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480682.5 725462.9 1.99 480683.3 725459.86 1.99 480683.3 725459.86 28.560000000000002 480682.5 725462.9 28.560000000000002 480682.5 725462.9 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480683.3 725459.86 1.99 480684.36 725456.9 1.99 480684.36 725456.9 28.560000000000002 480683.3 725459.86 28.560000000000002 480683.3 725459.86 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480684.36 725456.9 1.99 480685.67 725454.06 1.99 480685.67 725454.06 28.560000000000002 480684.36 725456.9 28.560000000000002 480684.36 725456.9 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480685.67 725454.06 1.99 480687.24 725451.35 1.99 480687.24 725451.35 28.560000000000002 480685.67 725454.06 28.560000000000002 480685.67 725454.06 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480687.24 725451.35 1.99 480689.04 725448.78 1.99 480689.04 725448.78 28.560000000000002 480687.24 725451.35 28.560000000000002 480687.24 725451.35 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480689.04 725448.78 1.99 480691.06 725446.39 1.99 480691.06 725446.39 28.560000000000002 480689.04 725448.78 28.560000000000002 480689.04 725448.78 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480691.06 725446.39 1.99 480693.3 725444.19 1.99 480693.3 725444.19 28.560000000000002 480691.06 725446.39 28.560000000000002 480691.06 725446.39 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480693.3 725444.19 1.99 480695.72 725442.2 1.99 480695.72 725442.2 28.560000000000002 480693.3 725444.19 28.560000000000002 480693.3 725444.19 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480695.72 725442.2 1.99 480698.3 725440.44 1.99 480698.3 725440.44 28.560000000000002 480695.72 725442.2 28.560000000000002 480695.72 725442.2 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480698.3 725440.44 1.99 480701.05 725438.91 1.99 480701.05 725438.91 28.560000000000002 480698.3 725440.44 28.560000000000002 480698.3 725440.44 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480701.05 725438.91 1.99 480703.91 725437.63 1.99 480703.91 725437.63 28.560000000000002 480701.05 725438.91 28.560000000000002 480701.05 725438.91 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480703.91 725437.63 1.99 480706.88 725436.62 1.99 480706.88 725436.62 28.560000000000002 480703.91 725437.63 28.560000000000002 480703.91 725437.63 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480706.88 725436.62 1.99 480709.92 725435.87 1.99 480709.92 725435.87 28.560000000000002 480706.88 725436.62 28.560000000000002 480706.88 725436.62 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480709.92 725435.87 1.99 480713.03 725435.4 1.99 480713.03 725435.4 28.560000000000002 480709.92 725435.87 28.560000000000002 480709.92 725435.87 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480713.03 725435.4 1.99 480716.15 725435.21 1.99 480716.15 725435.21 28.560000000000002 480713.03 725435.4 28.560000000000002 480713.03 725435.4 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480716.15 725435.21 1.99 480719.28 725435.31 1.99 480719.28 725435.31 28.560000000000002 480716.15 725435.21 28.560000000000002 480716.15 725435.21 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480719.28 725435.31 1.99 480722.39 725435.69 1.99 480722.39 725435.69 28.560000000000002 480719.28 725435.31 28.560000000000002 480719.28 725435.31 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480722.39 725435.69 1.99 480725.46 725436.33 1.99 480725.46 725436.33 28.560000000000002 480722.39 725435.69 28.560000000000002 480722.39 725435.69 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480725.46 725436.33 1.99 480728.46 725437.26 1.99 480728.46 725437.26 28.560000000000002 480725.46 725436.33 28.560000000000002 480725.46 725436.33 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480728.46 725437.26 1.99 480731.36 725438.45 1.99 480731.36 725438.45 28.560000000000002 480728.46 725437.26 28.560000000000002 480728.46 725437.26 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480731.36 725438.45 1.99 480734.15 725439.89 1.99 480734.15 725439.89 28.560000000000002 480731.36 725438.45 28.560000000000002 480731.36 725438.45 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480734.15 725439.89 1.99 480736.79 725441.58 1.99 480736.79 725441.58 28.560000000000002 480734.15 725439.89 28.560000000000002 480734.15 725439.89 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480736.79 725441.58 1.99 480739.27 725443.49 1.99 480739.27 725443.49 28.560000000000002 480736.79 725441.58 28.560000000000002 480736.79 725441.58 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480739.27 725443.49 1.99 480741.57 725445.63 1.99 480741.57 725445.63 28.560000000000002 480739.27 725443.49 28.560000000000002 480739.27 725443.49 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480741.57 725445.63 1.99 480743.67 725447.96 1.99 480743.67 725447.96 28.560000000000002 480741.57 725445.63 28.560000000000002 480741.57 725445.63 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480743.67 725447.96 1.99 480745.54 725450.46 1.99 480745.54 725450.46 28.560000000000002 480743.67 725447.96 28.560000000000002 480743.67 725447.96 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480745.54 725450.46 1.99 480747.19 725453.12 1.99 480747.19 725453.12 28.560000000000002 480745.54 725450.46 28.560000000000002 480745.54 725450.46 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480747.19 725453.12 1.99 480748.6 725455.93 1.99 480748.6 725455.93 28.560000000000002 480747.19 725453.12 28.560000000000002 480747.19 725453.12 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480748.6 725455.93 1.99 480749.74 725458.84 1.99 480749.74 725458.84 28.560000000000002 480748.6 725455.93 28.560000000000002 480748.6 725455.93 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480749.74 725458.84 1.99 480750.62 725461.86 1.99 480750.62 725461.86 28.560000000000002 480749.74 725458.84 28.560000000000002 480749.74 725458.84 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480750.62 725461.86 1.99 480751.22 725464.93 1.99 480751.22 725464.93 28.560000000000002 480750.62 725461.86 28.560000000000002 480750.62 725461.86 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480751.22 725464.93 1.99 480751.56 725468.05 1.99 480751.56 725468.05 28.560000000000002 480751.22 725464.93 28.560000000000002 480751.22 725464.93 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480751.56 725468.05 1.99 480751.6 725471.18 1.99 480751.6 725471.18 28.560000000000002 480751.56 725468.05 28.560000000000002 480751.56 725468.05 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480751.6 725471.18 1.99 480751.37 725474.31 1.99 480751.37 725474.31 28.560000000000002 480751.6 725471.18 28.560000000000002 480751.6 725471.18 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480751.37 725474.31 1.99 480750.86 725477.4 1.99 480750.86 725477.4 28.560000000000002 480751.37 725474.31 28.560000000000002 480751.37 725474.31 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480750.86 725477.4 1.99 480750.07 725480.44 1.99 480750.07 725480.44 28.560000000000002 480750.86 725477.4 28.560000000000002 480750.86 725477.4 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480750.07 725480.44 1.99 480749.02 725483.39 1.99 480749.02 725483.39 28.560000000000002 480750.07 725480.44 28.560000000000002 480750.07 725480.44 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480749.02 725483.39 1.99 480747.7 725486.24 1.99 480747.7 725486.24 28.560000000000002 480749.02 725483.39 28.560000000000002 480749.02 725483.39 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480747.7 725486.24 1.99 480746.13 725488.95 1.99 480746.13 725488.95 28.560000000000002 480747.7 725486.24 28.560000000000002 480747.7 725486.24 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480746.13 725488.95 1.99 480744.33 725491.51 1.99 480744.33 725491.51 28.560000000000002 480746.13 725488.95 28.560000000000002 480746.13 725488.95 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480744.33 725491.51 1.99 480742.3 725493.9 1.99 480742.3 725493.9 28.560000000000002 480744.33 725491.51 28.560000000000002 480744.33 725491.51 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480742.3 725493.9 1.99 480740.06 725496.1 1.99 480740.06 725496.1 28.560000000000002 480742.3 725493.9 28.560000000000002 480742.3 725493.9 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480740.06 725496.1 1.99 480737.64 725498.1 1.99 480737.64 725498.1 28.560000000000002 480740.06 725496.1 28.560000000000002 480740.06 725496.1 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480737.64 725498.1 1.99 480735.06 725499.86 1.99 480735.06 725499.86 28.560000000000002 480737.64 725498.1 28.560000000000002 480737.64 725498.1 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480735.06 725499.86 1.99 480732.32 725501.39 1.99 480732.32 725501.39 28.560000000000002 480735.06 725499.86 28.560000000000002 480735.06 725499.86 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480732.32 725501.39 1.99 480729.45 725502.67 1.99 480729.45 725502.67 28.560000000000002 480732.32 725501.39 28.560000000000002 480732.32 725501.39 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480729.45 725502.67 1.99 480726.49 725503.68 1.99 480726.49 725503.68 28.560000000000002 480729.45 725502.67 28.560000000000002 480729.45 725502.67 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480726.49 725503.68 1.99 480723.44 725504.42 1.99 480723.44 725504.42 28.560000000000002 480726.49 725503.68 28.560000000000002 480726.49 725503.68 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480723.44 725504.42 1.99 480720.34 725504.9 1.99 480720.34 725504.9 28.560000000000002 480723.44 725504.42 28.560000000000002 480723.44 725504.42 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480720.34 725504.9 1.99 480717.21 725505.08 1.99 480717.21 725505.08 28.560000000000002 480720.34 725504.9 28.560000000000002 480720.34 725504.9 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480717.21 725505.08 1.99 480714.08 725504.99 1.99 480714.08 725504.99 28.560000000000002 480717.21 725505.08 28.560000000000002 480717.21 725505.08 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480714.08 725504.99 1.99 480710.97 725504.61 1.99 480710.97 725504.61 28.560000000000002 480714.08 725504.99 28.560000000000002 480714.08 725504.99 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480710.97 725504.61 1.99 480707.9 725503.96 1.99 480707.9 725503.96 28.560000000000002 480710.97 725504.61 28.560000000000002 480710.97 725504.61 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480707.9 725503.96 1.99 480704.9 725503.04 1.99 480704.9 725503.04 28.560000000000002 480707.9 725503.96 28.560000000000002 480707.9 725503.96 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480704.9 725503.04 1.99 480702 725501.85 1.99 480702 725501.85 28.560000000000002 480704.9 725503.04 28.560000000000002 480704.9 725503.04 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480702 725501.85 1.99 480699.23 725500.41 1.99 480699.23 725500.41 28.560000000000002 480702 725501.85 28.560000000000002 480702 725501.85 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480699.23 725500.41 1.99 480696.58 725498.72 1.99 480696.58 725498.72 28.560000000000002 480699.23 725500.41 28.560000000000002 480699.23 725500.41 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480696.58 725498.72 1.99 480694.1 725496.8 1.99 480694.1 725496.8 28.560000000000002 480696.58 725498.72 28.560000000000002 480696.58 725498.72 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480694.1 725496.8 1.99 480691.8 725494.68 1.99 480691.8 725494.68 28.560000000000002 480694.1 725496.8 28.560000000000002 480694.1 725496.8 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480691.8 725494.68 1.99 480689.71 725492.35 1.99 480689.71 725492.35 28.560000000000002 480691.8 725494.68 28.560000000000002 480691.8 725494.68 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480689.71 725492.35 1.99 480687.82 725489.84 1.99 480687.82 725489.84 28.560000000000002 480689.71 725492.35 28.560000000000002 480689.71 725492.35 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480687.82 725489.84 1.99 480686.18 725487.17 1.99 480686.18 725487.17 28.560000000000002 480687.82 725489.84 28.560000000000002 480687.82 725489.84 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480686.18 725487.17 1.99 480684.77 725484.36 1.99 480684.77 725484.36 28.560000000000002 480686.18 725487.17 28.560000000000002 480686.18 725487.17 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480684.77 725484.36 1.99 480683.63 725481.45 1.99 480683.63 725481.45 28.560000000000002 480684.77 725484.36 28.560000000000002 480684.77 725484.36 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480683.63 725481.45 1.99 480682.74 725478.45 1.99 480682.74 725478.45 28.560000000000002 480683.63 725481.45 28.560000000000002 480683.63 725481.45 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480682.74 725478.45 1.99 480682.14 725475.37 1.99 480682.14 725475.37 28.560000000000002 480682.74 725478.45 28.560000000000002 480682.74 725478.45 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6531f32e-4482-4f22-b348-e29fbd61ffe3_PG_72">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480682.14 725475.37 28.560000000000002 480681.81 725472.25 28.560000000000002 480681.76 725469.11 28.560000000000002 480682 725465.98 28.560000000000002 480682.5 725462.9 28.560000000000002 480683.3 725459.86 28.560000000000002 480684.36 725456.9 28.560000000000002 480685.67 725454.06 28.560000000000002 480687.24 725451.35 28.560000000000002 480689.04 725448.78 28.560000000000002 480691.06 725446.39 28.560000000000002 480693.3 725444.19 28.560000000000002 480695.72 725442.2 28.560000000000002 480698.3 725440.44 28.560000000000002 480701.05 725438.91 28.560000000000002 480703.91 725437.63 28.560000000000002 480706.88 725436.62 28.560000000000002 480709.92 725435.87 28.560000000000002 480713.03 725435.4 28.560000000000002 480716.15 725435.21 28.560000000000002 480719.28 725435.31 28.560000000000002 480722.39 725435.69 28.560000000000002 480725.46 725436.33 28.560000000000002 480728.46 725437.26 28.560000000000002 480731.36 725438.45 28.560000000000002 480734.15 725439.89 28.560000000000002 480736.79 725441.58 28.560000000000002 480739.27 725443.49 28.560000000000002 480741.57 725445.63 28.560000000000002 480743.67 725447.96 28.560000000000002 480745.54 725450.46 28.560000000000002 480747.19 725453.12 28.560000000000002 480748.6 725455.93 28.560000000000002 480749.74 725458.84 28.560000000000002 480750.62 725461.86 28.560000000000002 480751.22 725464.93 28.560000000000002 480751.56 725468.05 28.560000000000002 480751.6 725471.18 28.560000000000002 480751.37 725474.31 28.560000000000002 480750.86 725477.4 28.560000000000002 480750.07 725480.44 28.560000000000002 480749.02 725483.39 28.560000000000002 480747.7 725486.24 28.560000000000002 480746.13 725488.95 28.560000000000002 480744.33 725491.51 28.560000000000002 480742.3 725493.9 28.560000000000002 480740.06 725496.1 28.560000000000002 480737.64 725498.1 28.560000000000002 480735.06 725499.86 28.560000000000002 480732.32 725501.39 28.560000000000002 480729.45 725502.67 28.560000000000002 480726.49 725503.68 28.560000000000002 480723.44 725504.42 28.560000000000002 480720.34 725504.9 28.560000000000002 480717.21 725505.08 28.560000000000002 480714.08 725504.99 28.560000000000002 480710.97 725504.61 28.560000000000002 480707.9 725503.96 28.560000000000002 480704.9 725503.04 28.560000000000002 480702 725501.85 28.560000000000002 480699.23 725500.41 28.560000000000002 480696.58 725498.72 28.560000000000002 480694.1 725496.8 28.560000000000002 480691.8 725494.68 28.560000000000002 480689.71 725492.35 28.560000000000002 480687.82 725489.84 28.560000000000002 480686.18 725487.17 28.560000000000002 480684.77 725484.36 28.560000000000002 480683.63 725481.45 28.560000000000002 480682.74 725478.45 28.560000000000002 480682.14 725475.37 28.560000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4841-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4841-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">14.57</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4841-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479995.67 725391.96 2.44 480015.14 725391.78 2.44 480014.82 725354.84 2.44 479995.36 725355.25 2.44 479995.67 725391.96 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4841-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479995.67 725391.96 2.44 479995.36 725355.25 2.44 479995.36 725355.25 17.01 479995.67 725391.96 17.01 479995.67 725391.96 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4841-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479995.36 725355.25 2.44 480014.82 725354.84 2.44 480014.82 725354.84 17.01 479995.36 725355.25 17.01 479995.36 725355.25 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4841-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480014.82 725354.84 2.44 480015.14 725391.78 2.44 480015.14 725391.78 17.01 480014.82 725354.84 17.01 480014.82 725354.84 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4841-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>480015.14 725391.78 2.44 479995.67 725391.96 2.44 479995.67 725391.96 17.01 480015.14 725391.78 17.01 480015.14 725391.78 2.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4841-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479995.67 725391.96 17.01 479995.36 725355.25 17.01 480014.82 725354.84 17.01 480015.14 725391.78 17.01 479995.67 725391.96 17.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D47B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D47B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D47B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479810.08 725526.42 3.02 479810.98 725511.11 3.02 479802.89 725510.63 3.02 479801.98 725525.94 3.02 479810.08 725526.42 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D47B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479810.08 725526.42 3.02 479801.98 725525.94 3.02 479801.98 725525.94 6.34 479810.08 725526.42 6.34 479810.08 725526.42 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D47B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479801.98 725525.94 3.02 479802.89 725510.63 3.02 479802.89 725510.63 6.34 479801.98 725525.94 6.34 479801.98 725525.94 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D47B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479802.89 725510.63 3.02 479810.98 725511.11 3.02 479810.98 725511.11 6.34 479802.89 725510.63 6.34 479802.89 725510.63 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D47B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479810.98 725511.11 3.02 479810.08 725526.42 3.02 479810.08 725526.42 6.34 479810.98 725511.11 6.34 479810.98 725511.11 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D47B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>479810.08 725526.42 6.34 479801.98 725525.94 6.34 479802.89 725510.63 6.34 479810.98 725511.11 6.34 479810.08 725526.42 6.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
</CityModel>
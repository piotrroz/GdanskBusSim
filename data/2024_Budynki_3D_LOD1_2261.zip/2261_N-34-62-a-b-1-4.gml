<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0" xmlns="http://www.opengis.net/citygml/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
			<gml:lowerCorner>477676.81 715558.16 -1.13</gml:lowerCorner>
			<gml:upperCorner>478838.62 716479.41 8.91</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0823-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0823-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.23</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0823-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478367.18 715585.75 0.38 478360.74 715586.65 0.38 478360.94 715588.11 0.38 478354.99 715589.02 0.38 478356.24 715598.55 0.38 478374.57 715596.02 0.38 478373.31 715586.45 0.38 478367.38 715587.24 0.38 478367.18 715585.75 0.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0823-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478367.18 715585.75 0.38 478367.38 715587.24 0.38 478367.38 715587.24 5.61 478367.18 715585.75 5.61 478367.18 715585.75 0.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0823-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478367.38 715587.24 0.38 478373.31 715586.45 0.38 478373.31 715586.45 5.61 478367.38 715587.24 5.61 478367.38 715587.24 0.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0823-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478373.31 715586.45 0.38 478374.57 715596.02 0.38 478374.57 715596.02 5.61 478373.31 715586.45 5.61 478373.31 715586.45 0.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0823-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478374.57 715596.02 0.38 478356.24 715598.55 0.38 478356.24 715598.55 5.61 478374.57 715596.02 5.61 478374.57 715596.02 0.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0823-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478356.24 715598.55 0.38 478354.99 715589.02 0.38 478354.99 715589.02 5.61 478356.24 715598.55 5.61 478356.24 715598.55 0.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0823-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478354.99 715589.02 0.38 478360.94 715588.11 0.38 478360.94 715588.11 5.61 478354.99 715589.02 5.61 478354.99 715589.02 0.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0823-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478360.94 715588.11 0.38 478360.74 715586.65 0.38 478360.74 715586.65 5.61 478360.94 715588.11 5.61 478360.94 715588.11 0.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0823-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478360.74 715586.65 0.38 478367.18 715585.75 0.38 478367.18 715585.75 5.61 478360.74 715586.65 5.61 478360.74 715586.65 0.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0823-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478367.18 715585.75 5.61 478367.38 715587.24 5.61 478373.31 715586.45 5.61 478374.57 715596.02 5.61 478356.24 715598.55 5.61 478354.99 715589.02 5.61 478360.94 715588.11 5.61 478360.74 715586.65 5.61 478367.18 715585.75 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C4A2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C4A2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.14</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4A2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478502.59 715984.42 -0.95 478505.26 715978.65 -0.95 478499.47 715975.96 -0.95 478496.79 715981.72 -0.95 478502.59 715984.42 -0.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4A2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478502.59 715984.42 -0.95 478496.79 715981.72 -0.95 478496.79 715981.72 2.1899999999999995 478502.59 715984.42 2.1899999999999995 478502.59 715984.42 -0.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4A2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478496.79 715981.72 -0.95 478499.47 715975.96 -0.95 478499.47 715975.96 2.1899999999999995 478496.79 715981.72 2.1899999999999995 478496.79 715981.72 -0.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4A2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478499.47 715975.96 -0.95 478505.26 715978.65 -0.95 478505.26 715978.65 2.1899999999999995 478499.47 715975.96 2.1899999999999995 478499.47 715975.96 -0.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4A2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478505.26 715978.65 -0.95 478502.59 715984.42 -0.95 478502.59 715984.42 2.1899999999999995 478505.26 715978.65 2.1899999999999995 478505.26 715978.65 -0.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4A2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478502.59 715984.42 2.1899999999999995 478496.79 715981.72 2.1899999999999995 478499.47 715975.96 2.1899999999999995 478505.26 715978.65 2.1899999999999995 478502.59 715984.42 2.1899999999999995</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-081B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-081B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.37</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-081B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477962.1 715739.5 0.13 477964.15 715743.94 0.13 477963.04 715744.42 0.13 477964.01 715746.48 0.13 477966.08 715750.98 0.13 477976.23 715746.29 0.13 477971.17 715735.3 0.13 477962.1 715739.5 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-081B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477962.1 715739.5 0.13 477971.17 715735.3 0.13 477971.17 715735.3 8.5 477962.1 715739.5 8.5 477962.1 715739.5 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-081B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477971.17 715735.3 0.13 477976.23 715746.29 0.13 477976.23 715746.29 8.5 477971.17 715735.3 8.5 477971.17 715735.3 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-081B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477976.23 715746.29 0.13 477966.08 715750.98 0.13 477966.08 715750.98 8.5 477976.23 715746.29 8.5 477976.23 715746.29 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-081B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477966.08 715750.98 0.13 477964.01 715746.48 0.13 477964.01 715746.48 8.5 477966.08 715750.98 8.5 477966.08 715750.98 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-081B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477964.01 715746.48 0.13 477963.04 715744.42 0.13 477963.04 715744.42 8.5 477964.01 715746.48 8.5 477964.01 715746.48 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-081B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477963.04 715744.42 0.13 477964.15 715743.94 0.13 477964.15 715743.94 8.5 477963.04 715744.42 8.5 477963.04 715744.42 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-081B-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477964.15 715743.94 0.13 477962.1 715739.5 0.13 477962.1 715739.5 8.5 477964.15 715743.94 8.5 477964.15 715743.94 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-081B-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477962.1 715739.5 8.5 477971.17 715735.3 8.5 477976.23 715746.29 8.5 477966.08 715750.98 8.5 477964.01 715746.48 8.5 477963.04 715744.42 8.5 477964.15 715743.94 8.5 477962.1 715739.5 8.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-645D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-645D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.08</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477920.7 715757.83 -0.98 477919.28 715758.57 -0.98 477923.85 715768.12 -0.98 477931.46 715764.23 -0.98 477926.64 715754.8 -0.98 477925.32 715752.21 -0.98 477919.38 715755.25 -0.98 477920.7 715757.83 -0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477920.7 715757.83 -0.98 477919.38 715755.25 -0.98 477919.38 715755.25 4.1 477920.7 715757.83 4.1 477920.7 715757.83 -0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477919.38 715755.25 -0.98 477925.32 715752.21 -0.98 477925.32 715752.21 4.1 477919.38 715755.25 4.1 477919.38 715755.25 -0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477925.32 715752.21 -0.98 477926.64 715754.8 -0.98 477926.64 715754.8 4.1 477925.32 715752.21 4.1 477925.32 715752.21 -0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477926.64 715754.8 -0.98 477931.46 715764.23 -0.98 477931.46 715764.23 4.1 477926.64 715754.8 4.1 477926.64 715754.8 -0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477931.46 715764.23 -0.98 477923.85 715768.12 -0.98 477923.85 715768.12 4.1 477931.46 715764.23 4.1 477931.46 715764.23 -0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477923.85 715768.12 -0.98 477919.28 715758.57 -0.98 477919.28 715758.57 4.1 477923.85 715768.12 4.1 477923.85 715768.12 -0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477919.28 715758.57 -0.98 477920.7 715757.83 -0.98 477920.7 715757.83 4.1 477919.28 715758.57 4.1 477919.28 715758.57 -0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-645D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477920.7 715757.83 4.1 477919.38 715755.25 4.1 477925.32 715752.21 4.1 477926.64 715754.8 4.1 477931.46 715764.23 4.1 477923.85 715768.12 4.1 477919.28 715758.57 4.1 477920.7 715757.83 4.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5F44-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5F44-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.44</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F44-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477926.65 715773.76 -0.12 477934.41 715770 -0.12 477931.46 715764.23 -0.12 477923.85 715768.12 -0.12 477926.65 715773.76 -0.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F44-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477926.65 715773.76 -0.12 477923.85 715768.12 -0.12 477923.85 715768.12 4.315 477926.65 715773.76 4.315 477926.65 715773.76 -0.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F44-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477923.85 715768.12 -0.12 477931.46 715764.23 -0.12 477931.46 715764.23 4.315 477923.85 715768.12 4.315 477923.85 715768.12 -0.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F44-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477931.46 715764.23 -0.12 477934.41 715770 -0.12 477934.41 715770 4.315 477931.46 715764.23 4.315 477931.46 715764.23 -0.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F44-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477934.41 715770 -0.12 477926.65 715773.76 -0.12 477926.65 715773.76 4.315 477934.41 715770 4.315 477934.41 715770 -0.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F44-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477926.65 715773.76 4.315 477923.85 715768.12 4.315 477931.46 715764.23 4.315 477934.41 715770 4.315 477926.65 715773.76 4.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-79EE-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-79EE-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.22</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EE-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478153.5 715827.79 -0.01 478156.08 715820.84 -0.01 478143.88 715816.34 -0.01 478141.88 715821.61 -0.01 478141.22 715823.23 -0.01 478147.86 715825.7 -0.01 478145.96 715830.82 -0.01 478151.59 715832.91 -0.01 478153.5 715827.79 -0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EE-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478153.5 715827.79 -0.01 478151.59 715832.91 -0.01 478151.59 715832.91 3.21 478153.5 715827.79 3.21 478153.5 715827.79 -0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EE-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478151.59 715832.91 -0.01 478145.96 715830.82 -0.01 478145.96 715830.82 3.21 478151.59 715832.91 3.21 478151.59 715832.91 -0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EE-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478145.96 715830.82 -0.01 478147.86 715825.7 -0.01 478147.86 715825.7 3.21 478145.96 715830.82 3.21 478145.96 715830.82 -0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EE-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478147.86 715825.7 -0.01 478141.22 715823.23 -0.01 478141.22 715823.23 3.21 478147.86 715825.7 3.21 478147.86 715825.7 -0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EE-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478141.22 715823.23 -0.01 478141.88 715821.61 -0.01 478141.88 715821.61 3.21 478141.22 715823.23 3.21 478141.22 715823.23 -0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EE-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478141.88 715821.61 -0.01 478143.88 715816.34 -0.01 478143.88 715816.34 3.21 478141.88 715821.61 3.21 478141.88 715821.61 -0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EE-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478143.88 715816.34 -0.01 478156.08 715820.84 -0.01 478156.08 715820.84 3.21 478143.88 715816.34 3.21 478143.88 715816.34 -0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EE-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478156.08 715820.84 -0.01 478153.5 715827.79 -0.01 478153.5 715827.79 3.21 478156.08 715820.84 3.21 478156.08 715820.84 -0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EE-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478153.5 715827.79 3.21 478151.59 715832.91 3.21 478145.96 715830.82 3.21 478147.86 715825.7 3.21 478141.22 715823.23 3.21 478141.88 715821.61 3.21 478143.88 715816.34 3.21 478156.08 715820.84 3.21 478153.5 715827.79 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7B21-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7B21-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B21-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478794.88 715594.67 -0.19 478795.96 715620.29 -0.19 478805.16 715619.71 -0.19 478804.04 715594.07 -0.19 478794.88 715594.67 -0.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B21-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478794.88 715594.67 -0.19 478804.04 715594.07 -0.19 478804.04 715594.07 5.6000000000000005 478794.88 715594.67 5.6000000000000005 478794.88 715594.67 -0.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B21-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478804.04 715594.07 -0.19 478805.16 715619.71 -0.19 478805.16 715619.71 5.6000000000000005 478804.04 715594.07 5.6000000000000005 478804.04 715594.07 -0.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B21-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478805.16 715619.71 -0.19 478795.96 715620.29 -0.19 478795.96 715620.29 5.6000000000000005 478805.16 715619.71 5.6000000000000005 478805.16 715619.71 -0.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B21-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478795.96 715620.29 -0.19 478794.88 715594.67 -0.19 478794.88 715594.67 5.6000000000000005 478795.96 715620.29 5.6000000000000005 478795.96 715620.29 -0.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B21-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478794.88 715594.67 5.6000000000000005 478804.04 715594.07 5.6000000000000005 478805.16 715619.71 5.6000000000000005 478795.96 715620.29 5.6000000000000005 478794.88 715594.67 5.6000000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.96</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478649.06 715621.78 -0.31 478661.77 715621.87 -0.31 478661.76 715621.63 -0.31 478664.23 715621.62 -0.31 478664.21 715613.96 -0.31 478663.11 715613.96 -0.31 478663.1 715612.67 -0.31 478661.8 715612.67 -0.31 478661.65 715602.77 -0.31 478661.46 715590.56 -0.31 478661.46 715590.01 -0.31 478658.34 715590.06 -0.31 478658.28 715586.43 -0.31 478648.79 715586.44 -0.31 478649.06 715621.78 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478649.06 715621.78 -0.31 478648.79 715586.44 -0.31 478648.79 715586.44 4.65 478649.06 715621.78 4.65 478649.06 715621.78 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478648.79 715586.44 -0.31 478658.28 715586.43 -0.31 478658.28 715586.43 4.65 478648.79 715586.44 4.65 478648.79 715586.44 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478658.28 715586.43 -0.31 478658.34 715590.06 -0.31 478658.34 715590.06 4.65 478658.28 715586.43 4.65 478658.28 715586.43 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478658.34 715590.06 -0.31 478661.46 715590.01 -0.31 478661.46 715590.01 4.65 478658.34 715590.06 4.65 478658.34 715590.06 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478661.46 715590.01 -0.31 478661.46 715590.56 -0.31 478661.46 715590.56 4.65 478661.46 715590.01 4.65 478661.46 715590.01 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478661.46 715590.56 -0.31 478661.65 715602.77 -0.31 478661.65 715602.77 4.65 478661.46 715590.56 4.65 478661.46 715590.56 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478661.65 715602.77 -0.31 478661.8 715612.67 -0.31 478661.8 715612.67 4.65 478661.65 715602.77 4.65 478661.65 715602.77 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478661.8 715612.67 -0.31 478663.1 715612.67 -0.31 478663.1 715612.67 4.65 478661.8 715612.67 4.65 478661.8 715612.67 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478663.1 715612.67 -0.31 478663.11 715613.96 -0.31 478663.11 715613.96 4.65 478663.1 715612.67 4.65 478663.1 715612.67 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478663.11 715613.96 -0.31 478664.21 715613.96 -0.31 478664.21 715613.96 4.65 478663.11 715613.96 4.65 478663.11 715613.96 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478664.21 715613.96 -0.31 478664.23 715621.62 -0.31 478664.23 715621.62 4.65 478664.21 715613.96 4.65 478664.21 715613.96 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478664.23 715621.62 -0.31 478661.76 715621.63 -0.31 478661.76 715621.63 4.65 478664.23 715621.62 4.65 478664.23 715621.62 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478661.76 715621.63 -0.31 478661.77 715621.87 -0.31 478661.77 715621.87 4.65 478661.76 715621.63 4.65 478661.76 715621.63 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478661.77 715621.87 -0.31 478649.06 715621.78 -0.31 478649.06 715621.78 4.65 478661.77 715621.87 4.65 478661.77 715621.87 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B20-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478649.06 715621.78 4.65 478648.79 715586.44 4.65 478658.28 715586.43 4.65 478658.34 715590.06 4.65 478661.46 715590.01 4.65 478661.46 715590.56 4.65 478661.65 715602.77 4.65 478661.8 715612.67 4.65 478663.1 715612.67 4.65 478663.11 715613.96 4.65 478664.21 715613.96 4.65 478664.23 715621.62 4.65 478661.76 715621.63 4.65 478661.77 715621.87 4.65 478649.06 715621.78 4.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7B1F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7B1F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.95</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B1F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478661.65 715602.77 -0.11 478691.84 715602.71 -0.11 478691.82 715593.1 -0.11 478691.81 715590.46 -0.11 478661.46 715590.56 -0.11 478661.65 715602.77 -0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B1F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478661.65 715602.77 -0.11 478661.46 715590.56 -0.11 478661.46 715590.56 5.84 478661.65 715602.77 5.84 478661.65 715602.77 -0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B1F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478661.46 715590.56 -0.11 478691.81 715590.46 -0.11 478691.81 715590.46 5.84 478661.46 715590.56 5.84 478661.46 715590.56 -0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B1F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478691.81 715590.46 -0.11 478691.82 715593.1 -0.11 478691.82 715593.1 5.84 478691.81 715590.46 5.84 478691.81 715590.46 -0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B1F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478691.82 715593.1 -0.11 478691.84 715602.71 -0.11 478691.84 715602.71 5.84 478691.82 715593.1 5.84 478691.82 715593.1 -0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B1F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478691.84 715602.71 -0.11 478661.65 715602.77 -0.11 478661.65 715602.77 5.84 478691.84 715602.71 5.84 478691.84 715602.71 -0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B1F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478661.65 715602.77 5.84 478661.46 715590.56 5.84 478691.81 715590.46 5.84 478691.82 715593.1 5.84 478691.84 715602.71 5.84 478661.65 715602.77 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7B22-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7B22-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.68</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B22-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478810.52 715596.24 -0.51 478810.96 715604.19 -0.51 478825.99 715603.35 -0.51 478825.16 715588.43 -0.51 478815.27 715588.99 -0.51 478815.66 715595.88 -0.51 478810.52 715596.24 -0.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B22-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478810.52 715596.24 -0.51 478815.66 715595.88 -0.51 478815.66 715595.88 6.17 478810.52 715596.24 6.17 478810.52 715596.24 -0.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B22-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478815.66 715595.88 -0.51 478815.27 715588.99 -0.51 478815.27 715588.99 6.17 478815.66 715595.88 6.17 478815.66 715595.88 -0.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B22-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478815.27 715588.99 -0.51 478825.16 715588.43 -0.51 478825.16 715588.43 6.17 478815.27 715588.99 6.17 478815.27 715588.99 -0.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B22-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478825.16 715588.43 -0.51 478825.99 715603.35 -0.51 478825.99 715603.35 6.17 478825.16 715588.43 6.17 478825.16 715588.43 -0.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B22-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478825.99 715603.35 -0.51 478810.96 715604.19 -0.51 478810.96 715604.19 6.17 478825.99 715603.35 6.17 478825.99 715603.35 -0.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B22-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478810.96 715604.19 -0.51 478810.52 715596.24 -0.51 478810.52 715596.24 6.17 478810.96 715604.19 6.17 478810.96 715604.19 -0.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B22-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478810.52 715596.24 6.17 478815.66 715595.88 6.17 478815.27 715588.99 6.17 478825.16 715588.43 6.17 478825.99 715603.35 6.17 478810.96 715604.19 6.17 478810.52 715596.24 6.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.83</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478513.19 716009.14 -1.13 478521.49 716013.66 -1.13 478521.08 716014.59 -1.13 478530.39 716019.72 -1.13 478533.17 716014.65 -1.13 478524.06 716009.64 -1.13 478526.25 716005.72 -1.13 478520.9 716002.8 -1.13 478517.59 716000.99 -1.13 478516.77 716002.51 -1.13 478513.19 716009.14 -1.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478513.19 716009.14 -1.13 478516.77 716002.51 -1.13 478516.77 716002.51 3.7 478513.19 716009.14 3.7 478513.19 716009.14 -1.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478516.77 716002.51 -1.13 478517.59 716000.99 -1.13 478517.59 716000.99 3.7 478516.77 716002.51 3.7 478516.77 716002.51 -1.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478517.59 716000.99 -1.13 478520.9 716002.8 -1.13 478520.9 716002.8 3.7 478517.59 716000.99 3.7 478517.59 716000.99 -1.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478520.9 716002.8 -1.13 478526.25 716005.72 -1.13 478526.25 716005.72 3.7 478520.9 716002.8 3.7 478520.9 716002.8 -1.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478526.25 716005.72 -1.13 478524.06 716009.64 -1.13 478524.06 716009.64 3.7 478526.25 716005.72 3.7 478526.25 716005.72 -1.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478524.06 716009.64 -1.13 478533.17 716014.65 -1.13 478533.17 716014.65 3.7 478524.06 716009.64 3.7 478524.06 716009.64 -1.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478533.17 716014.65 -1.13 478530.39 716019.72 -1.13 478530.39 716019.72 3.7 478533.17 716014.65 3.7 478533.17 716014.65 -1.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478530.39 716019.72 -1.13 478521.08 716014.59 -1.13 478521.08 716014.59 3.7 478530.39 716019.72 3.7 478530.39 716019.72 -1.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478521.08 716014.59 -1.13 478521.49 716013.66 -1.13 478521.49 716013.66 3.7 478521.08 716014.59 3.7 478521.08 716014.59 -1.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478521.49 716013.66 -1.13 478513.19 716009.14 -1.13 478513.19 716009.14 3.7 478521.49 716013.66 3.7 478521.49 716013.66 -1.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AEC-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478513.19 716009.14 3.7 478516.77 716002.51 3.7 478517.59 716000.99 3.7 478520.9 716002.8 3.7 478526.25 716005.72 3.7 478524.06 716009.64 3.7 478533.17 716014.65 3.7 478530.39 716019.72 3.7 478521.08 716014.59 3.7 478521.49 716013.66 3.7 478513.19 716009.14 3.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7B25-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7B25-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B25-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478722.18 715791.45 0.05 478728.13 715794.25 0.05 478731.26 715787.58 0.05 478725.55 715784.74 0.05 478722.18 715791.45 0.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B25-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478722.18 715791.45 0.05 478725.55 715784.74 0.05 478725.55 715784.74 3.6 478722.18 715791.45 3.6 478722.18 715791.45 0.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B25-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478725.55 715784.74 0.05 478731.26 715787.58 0.05 478731.26 715787.58 3.6 478725.55 715784.74 3.6 478725.55 715784.74 0.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B25-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478731.26 715787.58 0.05 478728.13 715794.25 0.05 478728.13 715794.25 3.6 478731.26 715787.58 3.6 478731.26 715787.58 0.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B25-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478728.13 715794.25 0.05 478722.18 715791.45 0.05 478722.18 715791.45 3.6 478728.13 715794.25 3.6 478728.13 715794.25 0.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B25-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478722.18 715791.45 3.6 478725.55 715784.74 3.6 478731.26 715787.58 3.6 478728.13 715794.25 3.6 478722.18 715791.45 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-79ED-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-79ED-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.04</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79ED-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478134.47 715815.8 0.12 478137.74 715817.04 0.12 478136.72 715819.69 0.12 478141.88 715821.61 0.12 478143.88 715816.34 0.12 478135.46 715813.16 0.12 478134.47 715815.8 0.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79ED-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478134.47 715815.8 0.12 478135.46 715813.16 0.12 478135.46 715813.16 3.16 478134.47 715815.8 3.16 478134.47 715815.8 0.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79ED-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478135.46 715813.16 0.12 478143.88 715816.34 0.12 478143.88 715816.34 3.16 478135.46 715813.16 3.16 478135.46 715813.16 0.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79ED-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478143.88 715816.34 0.12 478141.88 715821.61 0.12 478141.88 715821.61 3.16 478143.88 715816.34 3.16 478143.88 715816.34 0.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79ED-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478141.88 715821.61 0.12 478136.72 715819.69 0.12 478136.72 715819.69 3.16 478141.88 715821.61 3.16 478141.88 715821.61 0.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79ED-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478136.72 715819.69 0.12 478137.74 715817.04 0.12 478137.74 715817.04 3.16 478136.72 715819.69 3.16 478136.72 715819.69 0.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79ED-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478137.74 715817.04 0.12 478134.47 715815.8 0.12 478134.47 715815.8 3.16 478137.74 715817.04 3.16 478137.74 715817.04 0.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79ED-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478134.47 715815.8 3.16 478135.46 715813.16 3.16 478143.88 715816.34 3.16 478141.88 715821.61 3.16 478136.72 715819.69 3.16 478137.74 715817.04 3.16 478134.47 715815.8 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-79E9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-79E9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.46</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478075.45 715676.61 1.15 478085.69 715672.49 1.15 478082.05 715663.41 1.15 478072.12 715667.51 1.15 478075.18 715675.85 1.15 478075.45 715676.61 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478075.45 715676.61 1.15 478075.18 715675.85 1.15 478075.18 715675.85 3.61 478075.45 715676.61 3.61 478075.45 715676.61 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478075.18 715675.85 1.15 478072.12 715667.51 1.15 478072.12 715667.51 3.61 478075.18 715675.85 3.61 478075.18 715675.85 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478072.12 715667.51 1.15 478082.05 715663.41 1.15 478082.05 715663.41 3.61 478072.12 715667.51 3.61 478072.12 715667.51 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478082.05 715663.41 1.15 478085.69 715672.49 1.15 478085.69 715672.49 3.61 478082.05 715663.41 3.61 478082.05 715663.41 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478085.69 715672.49 1.15 478075.45 715676.61 1.15 478075.45 715676.61 3.61 478085.69 715672.49 3.61 478085.69 715672.49 1.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E9-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478075.45 715676.61 3.61 478075.18 715675.85 3.61 478072.12 715667.51 3.61 478082.05 715663.41 3.61 478085.69 715672.49 3.61 478075.45 715676.61 3.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7B86-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7B86-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B86-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477935.87 715759.03 0.22 477941.28 715770.3 0.22 477950 715765.98 0.22 477946 715758.02 0.22 477941.67 715760.23 0.22 477940.16 715756.96 0.22 477935.87 715759.03 0.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B86-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477935.87 715759.03 0.22 477940.16 715756.96 0.22 477940.16 715756.96 4.75 477935.87 715759.03 4.75 477935.87 715759.03 0.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B86-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477940.16 715756.96 0.22 477941.67 715760.23 0.22 477941.67 715760.23 4.75 477940.16 715756.96 4.75 477940.16 715756.96 0.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B86-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477941.67 715760.23 0.22 477946 715758.02 0.22 477946 715758.02 4.75 477941.67 715760.23 4.75 477941.67 715760.23 0.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B86-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477946 715758.02 0.22 477950 715765.98 0.22 477950 715765.98 4.75 477946 715758.02 4.75 477946 715758.02 0.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B86-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477950 715765.98 0.22 477941.28 715770.3 0.22 477941.28 715770.3 4.75 477950 715765.98 4.75 477950 715765.98 0.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B86-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477941.28 715770.3 0.22 477935.87 715759.03 0.22 477935.87 715759.03 4.75 477941.28 715770.3 4.75 477941.28 715770.3 0.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B86-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477935.87 715759.03 4.75 477940.16 715756.96 4.75 477941.67 715760.23 4.75 477946 715758.02 4.75 477950 715765.98 4.75 477941.28 715770.3 4.75 477935.87 715759.03 4.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.74</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478735.09 715812.92 -0.17 478745.84 715817.53 -0.17 478746.64 715815.7 -0.17 478744.49 715814.76 -0.17 478748.12 715805.67 -0.17 478749.31 715806.18 -0.17 478751.57 715800.93 -0.17 478743.84 715797.62 -0.17 478741.76 715802.48 -0.17 478739.92 715801.69 -0.17 478735.09 715812.92 -0.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478735.09 715812.92 -0.17 478739.92 715801.69 -0.17 478739.92 715801.69 3.5700000000000003 478735.09 715812.92 3.5700000000000003 478735.09 715812.92 -0.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478739.92 715801.69 -0.17 478741.76 715802.48 -0.17 478741.76 715802.48 3.5700000000000003 478739.92 715801.69 3.5700000000000003 478739.92 715801.69 -0.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478741.76 715802.48 -0.17 478743.84 715797.62 -0.17 478743.84 715797.62 3.5700000000000003 478741.76 715802.48 3.5700000000000003 478741.76 715802.48 -0.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478743.84 715797.62 -0.17 478751.57 715800.93 -0.17 478751.57 715800.93 3.5700000000000003 478743.84 715797.62 3.5700000000000003 478743.84 715797.62 -0.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478751.57 715800.93 -0.17 478749.31 715806.18 -0.17 478749.31 715806.18 3.5700000000000003 478751.57 715800.93 3.5700000000000003 478751.57 715800.93 -0.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478749.31 715806.18 -0.17 478748.12 715805.67 -0.17 478748.12 715805.67 3.5700000000000003 478749.31 715806.18 3.5700000000000003 478749.31 715806.18 -0.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478748.12 715805.67 -0.17 478744.49 715814.76 -0.17 478744.49 715814.76 3.5700000000000003 478748.12 715805.67 3.5700000000000003 478748.12 715805.67 -0.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478744.49 715814.76 -0.17 478746.64 715815.7 -0.17 478746.64 715815.7 3.5700000000000003 478744.49 715814.76 3.5700000000000003 478744.49 715814.76 -0.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478746.64 715815.7 -0.17 478745.84 715817.53 -0.17 478745.84 715817.53 3.5700000000000003 478746.64 715815.7 3.5700000000000003 478746.64 715815.7 -0.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478745.84 715817.53 -0.17 478735.09 715812.92 -0.17 478735.09 715812.92 3.5700000000000003 478745.84 715817.53 3.5700000000000003 478745.84 715817.53 -0.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B24-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478735.09 715812.92 3.5700000000000003 478739.92 715801.69 3.5700000000000003 478741.76 715802.48 3.5700000000000003 478743.84 715797.62 3.5700000000000003 478751.57 715800.93 3.5700000000000003 478749.31 715806.18 3.5700000000000003 478748.12 715805.67 3.5700000000000003 478744.49 715814.76 3.5700000000000003 478746.64 715815.7 3.5700000000000003 478745.84 715817.53 3.5700000000000003 478735.09 715812.92 3.5700000000000003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7B23-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7B23-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.81</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B23-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478826.68 715607.92 -0.29 478826.84 715611.76 -0.29 478826.96 715614.71 -0.29 478828.83 715614.67 -0.29 478828.97 715618.22 -0.29 478838.62 715617.92 -0.29 478838.3 715607.56 -0.29 478828.68 715607.85 -0.29 478826.68 715607.92 -0.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B23-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478826.68 715607.92 -0.29 478828.68 715607.85 -0.29 478828.68 715607.85 4.5200000000000005 478826.68 715607.92 4.5200000000000005 478826.68 715607.92 -0.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B23-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478828.68 715607.85 -0.29 478838.3 715607.56 -0.29 478838.3 715607.56 4.5200000000000005 478828.68 715607.85 4.5200000000000005 478828.68 715607.85 -0.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B23-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478838.3 715607.56 -0.29 478838.62 715617.92 -0.29 478838.62 715617.92 4.5200000000000005 478838.3 715607.56 4.5200000000000005 478838.3 715607.56 -0.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B23-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478838.62 715617.92 -0.29 478828.97 715618.22 -0.29 478828.97 715618.22 4.5200000000000005 478838.62 715617.92 4.5200000000000005 478838.62 715617.92 -0.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B23-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478828.97 715618.22 -0.29 478828.83 715614.67 -0.29 478828.83 715614.67 4.5200000000000005 478828.97 715618.22 4.5200000000000005 478828.97 715618.22 -0.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B23-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478828.83 715614.67 -0.29 478826.96 715614.71 -0.29 478826.96 715614.71 4.5200000000000005 478828.83 715614.67 4.5200000000000005 478828.83 715614.67 -0.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B23-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478826.96 715614.71 -0.29 478826.84 715611.76 -0.29 478826.84 715611.76 4.5200000000000005 478826.96 715614.71 4.5200000000000005 478826.96 715614.71 -0.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B23-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478826.84 715611.76 -0.29 478826.68 715607.92 -0.29 478826.68 715607.92 4.5200000000000005 478826.84 715611.76 4.5200000000000005 478826.84 715611.76 -0.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7B23-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478826.68 715607.92 4.5200000000000005 478828.68 715607.85 4.5200000000000005 478838.3 715607.56 4.5200000000000005 478838.62 715617.92 4.5200000000000005 478828.97 715618.22 4.5200000000000005 478828.83 715614.67 4.5200000000000005 478826.96 715614.71 4.5200000000000005 478826.84 715611.76 4.5200000000000005 478826.68 715607.92 4.5200000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7D85-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7D85-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D85-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477729.41 716112.01 -0.61 477734.26 716114.13 -0.61 477739.23 716102.78 -0.61 477734.39 716100.66 -0.61 477729.41 716112.01 -0.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D85-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477729.41 716112.01 -0.61 477734.39 716100.66 -0.61 477734.39 716100.66 2.71 477729.41 716112.01 2.71 477729.41 716112.01 -0.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D85-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477734.39 716100.66 -0.61 477739.23 716102.78 -0.61 477739.23 716102.78 2.71 477734.39 716100.66 2.71 477734.39 716100.66 -0.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D85-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477739.23 716102.78 -0.61 477734.26 716114.13 -0.61 477734.26 716114.13 2.71 477739.23 716102.78 2.71 477739.23 716102.78 -0.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D85-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477734.26 716114.13 -0.61 477729.41 716112.01 -0.61 477729.41 716112.01 2.71 477734.26 716114.13 2.71 477734.26 716114.13 -0.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D85-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477729.41 716112.01 2.71 477734.39 716100.66 2.71 477739.23 716102.78 2.71 477734.26 716114.13 2.71 477729.41 716112.01 2.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c">
			<gen:stringAttribute name="buildingId">
				<gen:value>899e1837-4f5c-42e7-9cbb-574b51bd359c</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.1</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478280.95 715558.16 0.01 478274.27 715559.64 0.01 478275.19 715563.74 0.01 478270.56 715564.78 0.01 478269.63 715560.68 0.01 478262.94 715562.19 0.01 478265.98 715575.72 0.01 478272.67 715574.21 0.01 478272.37 715572.87 0.01 478277.01 715571.82 0.01 478277.61 715574.43 0.01 478284.27 715572.94 0.01 478280.95 715558.16 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478280.95 715558.16 0.01 478284.27 715572.94 0.01 478284.27 715572.94 6.11 478280.95 715558.16 6.11 478280.95 715558.16 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478284.27 715572.94 0.01 478277.61 715574.43 0.01 478277.61 715574.43 6.11 478284.27 715572.94 6.11 478284.27 715572.94 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478277.61 715574.43 0.01 478277.01 715571.82 0.01 478277.01 715571.82 6.11 478277.61 715574.43 6.11 478277.61 715574.43 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478277.01 715571.82 0.01 478272.37 715572.87 0.01 478272.37 715572.87 6.11 478277.01 715571.82 6.11 478277.01 715571.82 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478272.37 715572.87 0.01 478272.67 715574.21 0.01 478272.67 715574.21 6.11 478272.37 715572.87 6.11 478272.37 715572.87 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478272.67 715574.21 0.01 478265.98 715575.72 0.01 478265.98 715575.72 6.11 478272.67 715574.21 6.11 478272.67 715574.21 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478265.98 715575.72 0.01 478262.94 715562.19 0.01 478262.94 715562.19 6.11 478265.98 715575.72 6.11 478265.98 715575.72 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478262.94 715562.19 0.01 478269.63 715560.68 0.01 478269.63 715560.68 6.11 478262.94 715562.19 6.11 478262.94 715562.19 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478269.63 715560.68 0.01 478270.56 715564.78 0.01 478270.56 715564.78 6.11 478269.63 715560.68 6.11 478269.63 715560.68 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478270.56 715564.78 0.01 478275.19 715563.74 0.01 478275.19 715563.74 6.11 478270.56 715564.78 6.11 478270.56 715564.78 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478275.19 715563.74 0.01 478274.27 715559.64 0.01 478274.27 715559.64 6.11 478275.19 715563.74 6.11 478275.19 715563.74 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478274.27 715559.64 0.01 478280.95 715558.16 0.01 478280.95 715558.16 6.11 478274.27 715559.64 6.11 478274.27 715559.64 0.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-899e1837-4f5c-42e7-9cbb-574b51bd359c_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478280.95 715558.16 6.11 478284.27 715572.94 6.11 478277.61 715574.43 6.11 478277.01 715571.82 6.11 478272.37 715572.87 6.11 478272.67 715574.21 6.11 478265.98 715575.72 6.11 478262.94 715562.19 6.11 478269.63 715560.68 6.11 478270.56 715564.78 6.11 478275.19 715563.74 6.11 478274.27 715559.64 6.11 478280.95 715558.16 6.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A24-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A24-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.38</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A24-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478477.56 715764.86 -0.14 478487.42 715768.84 -0.14 478489 715764.66 -0.14 478479.15 715760.94 -0.14 478477.56 715764.86 -0.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A24-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478477.56 715764.86 -0.14 478479.15 715760.94 -0.14 478479.15 715760.94 3.24 478477.56 715764.86 3.24 478477.56 715764.86 -0.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A24-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478479.15 715760.94 -0.14 478489 715764.66 -0.14 478489 715764.66 3.24 478479.15 715760.94 3.24 478479.15 715760.94 -0.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A24-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478489 715764.66 -0.14 478487.42 715768.84 -0.14 478487.42 715768.84 3.24 478489 715764.66 3.24 478489 715764.66 -0.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A24-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478487.42 715768.84 -0.14 478477.56 715764.86 -0.14 478477.56 715764.86 3.24 478487.42 715768.84 3.24 478487.42 715768.84 -0.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A24-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478477.56 715764.86 3.24 478479.15 715760.94 3.24 478489 715764.66 3.24 478487.42 715768.84 3.24 478477.56 715764.86 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-79EA-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-79EA-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EA-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478061.94 715671.23 0.8 478064.81 715679 0.8 478065.03 715679.56 0.8 478075.18 715675.85 0.8 478072.12 715667.51 0.8 478061.94 715671.23 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EA-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478061.94 715671.23 0.8 478072.12 715667.51 0.8 478072.12 715667.51 4.74 478061.94 715671.23 4.74 478061.94 715671.23 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EA-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478072.12 715667.51 0.8 478075.18 715675.85 0.8 478075.18 715675.85 4.74 478072.12 715667.51 4.74 478072.12 715667.51 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EA-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478075.18 715675.85 0.8 478065.03 715679.56 0.8 478065.03 715679.56 4.74 478075.18 715675.85 4.74 478075.18 715675.85 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EA-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478065.03 715679.56 0.8 478064.81 715679 0.8 478064.81 715679 4.74 478065.03 715679.56 4.74 478065.03 715679.56 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EA-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478064.81 715679 0.8 478061.94 715671.23 0.8 478061.94 715671.23 4.74 478064.81 715679 4.74 478064.81 715679 0.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EA-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478061.94 715671.23 4.74 478072.12 715667.51 4.74 478075.18 715675.85 4.74 478065.03 715679.56 4.74 478064.81 715679 4.74 478061.94 715671.23 4.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7D91-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7D91-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.82</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D91-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477830.96 715824.57 0.41 477837.92 715832.31 0.41 477845.84 715825.41 0.41 477838.75 715817.79 0.41 477830.96 715824.57 0.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D91-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477830.96 715824.57 0.41 477838.75 715817.79 0.41 477838.75 715817.79 6.23 477830.96 715824.57 6.23 477830.96 715824.57 0.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D91-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477838.75 715817.79 0.41 477845.84 715825.41 0.41 477845.84 715825.41 6.23 477838.75 715817.79 6.23 477838.75 715817.79 0.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D91-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477845.84 715825.41 0.41 477837.92 715832.31 0.41 477837.92 715832.31 6.23 477845.84 715825.41 6.23 477845.84 715825.41 0.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D91-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477837.92 715832.31 0.41 477830.96 715824.57 0.41 477830.96 715824.57 6.23 477837.92 715832.31 6.23 477837.92 715832.31 0.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D91-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477830.96 715824.57 6.23 477838.75 715817.79 6.23 477845.84 715825.41 6.23 477837.92 715832.31 6.23 477830.96 715824.57 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7D90-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7D90-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.96</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D90-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477824.05 715850.73 0.72 477830.05 715857.16 0.72 477839.13 715848.53 0.72 477833.11 715842.21 0.72 477829.62 715845.5 0.72 477828.41 715844.21 0.72 477826.41 715846.19 0.72 477827.56 715847.42 0.72 477824.05 715850.73 0.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D90-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477824.05 715850.73 0.72 477827.56 715847.42 0.72 477827.56 715847.42 6.68 477824.05 715850.73 6.68 477824.05 715850.73 0.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D90-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477827.56 715847.42 0.72 477826.41 715846.19 0.72 477826.41 715846.19 6.68 477827.56 715847.42 6.68 477827.56 715847.42 0.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D90-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477826.41 715846.19 0.72 477828.41 715844.21 0.72 477828.41 715844.21 6.68 477826.41 715846.19 6.68 477826.41 715846.19 0.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D90-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477828.41 715844.21 0.72 477829.62 715845.5 0.72 477829.62 715845.5 6.68 477828.41 715844.21 6.68 477828.41 715844.21 0.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D90-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477829.62 715845.5 0.72 477833.11 715842.21 0.72 477833.11 715842.21 6.68 477829.62 715845.5 6.68 477829.62 715845.5 0.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D90-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477833.11 715842.21 0.72 477839.13 715848.53 0.72 477839.13 715848.53 6.68 477833.11 715842.21 6.68 477833.11 715842.21 0.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D90-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477839.13 715848.53 0.72 477830.05 715857.16 0.72 477830.05 715857.16 6.68 477839.13 715848.53 6.68 477839.13 715848.53 0.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D90-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477830.05 715857.16 0.72 477824.05 715850.73 0.72 477824.05 715850.73 6.68 477830.05 715857.16 6.68 477830.05 715857.16 0.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D90-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477824.05 715850.73 6.68 477827.56 715847.42 6.68 477826.41 715846.19 6.68 477828.41 715844.21 6.68 477829.62 715845.5 6.68 477833.11 715842.21 6.68 477839.13 715848.53 6.68 477830.05 715857.16 6.68 477824.05 715850.73 6.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-79E8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-79E8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477929.45 715741.53 -0.1 477932.29 715747.61 -0.1 477940.97 715743.62 -0.1 477938.13 715737.5 -0.1 477929.45 715741.53 -0.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477929.45 715741.53 -0.1 477938.13 715737.5 -0.1 477938.13 715737.5 5.19 477929.45 715741.53 5.19 477929.45 715741.53 -0.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477938.13 715737.5 -0.1 477940.97 715743.62 -0.1 477940.97 715743.62 5.19 477938.13 715737.5 5.19 477938.13 715737.5 -0.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477940.97 715743.62 -0.1 477932.29 715747.61 -0.1 477932.29 715747.61 5.19 477940.97 715743.62 5.19 477940.97 715743.62 -0.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477932.29 715747.61 -0.1 477929.45 715741.53 -0.1 477929.45 715741.53 5.19 477932.29 715747.61 5.19 477932.29 715747.61 -0.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477929.45 715741.53 5.19 477938.13 715737.5 5.19 477940.97 715743.62 5.19 477932.29 715747.61 5.19 477929.45 715741.53 5.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A2B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A2B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.37</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478392.24 715877.58 -0.93 478397.77 715879.73 -0.93 478403.91 715863.29 -0.93 478398.54 715861.15 -0.93 478392.24 715877.58 -0.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478392.24 715877.58 -0.93 478398.54 715861.15 -0.93 478398.54 715861.15 1.44 478392.24 715877.58 1.44 478392.24 715877.58 -0.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478398.54 715861.15 -0.93 478403.91 715863.29 -0.93 478403.91 715863.29 1.44 478398.54 715861.15 1.44 478398.54 715861.15 -0.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478403.91 715863.29 -0.93 478397.77 715879.73 -0.93 478397.77 715879.73 1.44 478403.91 715863.29 1.44 478403.91 715863.29 -0.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478397.77 715879.73 -0.93 478392.24 715877.58 -0.93 478392.24 715877.58 1.44 478397.77 715879.73 1.44 478397.77 715879.73 -0.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478392.24 715877.58 1.44 478398.54 715861.15 1.44 478403.91 715863.29 1.44 478397.77 715879.73 1.44 478392.24 715877.58 1.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A25-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A25-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.1</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A25-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478435.8 715748.97 0.13 478440.83 715751 0.13 478441.81 715748.56 0.13 478443.31 715749.17 0.13 478444.2 715747.02 0.13 478442.69 715746.41 0.13 478444.51 715741.92 0.13 478439.23 715739.91 0.13 478435.8 715748.97 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A25-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478435.8 715748.97 0.13 478439.23 715739.91 0.13 478439.23 715739.91 3.23 478435.8 715748.97 3.23 478435.8 715748.97 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A25-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478439.23 715739.91 0.13 478444.51 715741.92 0.13 478444.51 715741.92 3.23 478439.23 715739.91 3.23 478439.23 715739.91 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A25-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478444.51 715741.92 0.13 478442.69 715746.41 0.13 478442.69 715746.41 3.23 478444.51 715741.92 3.23 478444.51 715741.92 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A25-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478442.69 715746.41 0.13 478444.2 715747.02 0.13 478444.2 715747.02 3.23 478442.69 715746.41 3.23 478442.69 715746.41 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A25-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478444.2 715747.02 0.13 478443.31 715749.17 0.13 478443.31 715749.17 3.23 478444.2 715747.02 3.23 478444.2 715747.02 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A25-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478443.31 715749.17 0.13 478441.81 715748.56 0.13 478441.81 715748.56 3.23 478443.31 715749.17 3.23 478443.31 715749.17 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A25-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478441.81 715748.56 0.13 478440.83 715751 0.13 478440.83 715751 3.23 478441.81 715748.56 3.23 478441.81 715748.56 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A25-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478440.83 715751 0.13 478435.8 715748.97 0.13 478435.8 715748.97 3.23 478440.83 715751 3.23 478440.83 715751 0.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A25-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478435.8 715748.97 3.23 478439.23 715739.91 3.23 478444.51 715741.92 3.23 478442.69 715746.41 3.23 478444.2 715747.02 3.23 478443.31 715749.17 3.23 478441.81 715748.56 3.23 478440.83 715751 3.23 478435.8 715748.97 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-79E7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-79E7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477942.29 715747.34 0.26 477944.39 715751.87 0.26 477946.4 715750.96 0.26 477947.5 715753.36 0.26 477952.19 715751.2 0.26 477948.44 715743.15 0.26 477943.81 715745.32 0.26 477944.31 715746.41 0.26 477942.29 715747.34 0.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477942.29 715747.34 0.26 477944.31 715746.41 0.26 477944.31 715746.41 3.6899999999999995 477942.29 715747.34 3.6899999999999995 477942.29 715747.34 0.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477944.31 715746.41 0.26 477943.81 715745.32 0.26 477943.81 715745.32 3.6899999999999995 477944.31 715746.41 3.6899999999999995 477944.31 715746.41 0.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477943.81 715745.32 0.26 477948.44 715743.15 0.26 477948.44 715743.15 3.6899999999999995 477943.81 715745.32 3.6899999999999995 477943.81 715745.32 0.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477948.44 715743.15 0.26 477952.19 715751.2 0.26 477952.19 715751.2 3.6899999999999995 477948.44 715743.15 3.6899999999999995 477948.44 715743.15 0.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477952.19 715751.2 0.26 477947.5 715753.36 0.26 477947.5 715753.36 3.6899999999999995 477952.19 715751.2 3.6899999999999995 477952.19 715751.2 0.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477947.5 715753.36 0.26 477946.4 715750.96 0.26 477946.4 715750.96 3.6899999999999995 477947.5 715753.36 3.6899999999999995 477947.5 715753.36 0.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477946.4 715750.96 0.26 477944.39 715751.87 0.26 477944.39 715751.87 3.6899999999999995 477946.4 715750.96 3.6899999999999995 477946.4 715750.96 0.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477944.39 715751.87 0.26 477942.29 715747.34 0.26 477942.29 715747.34 3.6899999999999995 477944.39 715751.87 3.6899999999999995 477944.39 715751.87 0.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79E7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477942.29 715747.34 3.6899999999999995 477944.31 715746.41 3.6899999999999995 477943.81 715745.32 3.6899999999999995 477948.44 715743.15 3.6899999999999995 477952.19 715751.2 3.6899999999999995 477947.5 715753.36 3.6899999999999995 477946.4 715750.96 3.6899999999999995 477944.39 715751.87 3.6899999999999995 477942.29 715747.34 3.6899999999999995</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7BBF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7BBF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.3</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7BBF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478437.68 715760.27 0.11 478446.96 715763.62 0.11 478451.07 715751.86 0.11 478446.85 715750.39 0.11 478445.68 715753.73 0.11 478440.98 715752.08 0.11 478437.68 715760.27 0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7BBF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478437.68 715760.27 0.11 478440.98 715752.08 0.11 478440.98 715752.08 3.41 478437.68 715760.27 3.41 478437.68 715760.27 0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7BBF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478440.98 715752.08 0.11 478445.68 715753.73 0.11 478445.68 715753.73 3.41 478440.98 715752.08 3.41 478440.98 715752.08 0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7BBF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478445.68 715753.73 0.11 478446.85 715750.39 0.11 478446.85 715750.39 3.41 478445.68 715753.73 3.41 478445.68 715753.73 0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7BBF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478446.85 715750.39 0.11 478451.07 715751.86 0.11 478451.07 715751.86 3.41 478446.85 715750.39 3.41 478446.85 715750.39 0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7BBF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478451.07 715751.86 0.11 478446.96 715763.62 0.11 478446.96 715763.62 3.41 478451.07 715751.86 3.41 478451.07 715751.86 0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7BBF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478446.96 715763.62 0.11 478437.68 715760.27 0.11 478437.68 715760.27 3.41 478446.96 715763.62 3.41 478446.96 715763.62 0.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7BBF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478437.68 715760.27 3.41 478440.98 715752.08 3.41 478445.68 715753.73 3.41 478446.85 715750.39 3.41 478451.07 715751.86 3.41 478446.96 715763.62 3.41 478437.68 715760.27 3.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7AE9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7AE9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.77</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478535.27 716455.24 -0.7 478542.75 716458.88 -0.7 478549.97 716444.07 -0.7 478542.5 716440.46 -0.7 478538.78 716447.9 -0.7 478536.43 716446.83 -0.7 478535.47 716448.96 -0.7 478537.71 716449.96 -0.7 478535.27 716455.24 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478535.27 716455.24 -0.7 478537.71 716449.96 -0.7 478537.71 716449.96 6.07 478535.27 716455.24 6.07 478535.27 716455.24 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478537.71 716449.96 -0.7 478535.47 716448.96 -0.7 478535.47 716448.96 6.07 478537.71 716449.96 6.07 478537.71 716449.96 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478535.47 716448.96 -0.7 478536.43 716446.83 -0.7 478536.43 716446.83 6.07 478535.47 716448.96 6.07 478535.47 716448.96 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478536.43 716446.83 -0.7 478538.78 716447.9 -0.7 478538.78 716447.9 6.07 478536.43 716446.83 6.07 478536.43 716446.83 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478538.78 716447.9 -0.7 478542.5 716440.46 -0.7 478542.5 716440.46 6.07 478538.78 716447.9 6.07 478538.78 716447.9 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE9-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478542.5 716440.46 -0.7 478549.97 716444.07 -0.7 478549.97 716444.07 6.07 478542.5 716440.46 6.07 478542.5 716440.46 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE9-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478549.97 716444.07 -0.7 478542.75 716458.88 -0.7 478542.75 716458.88 6.07 478549.97 716444.07 6.07 478549.97 716444.07 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE9-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478542.75 716458.88 -0.7 478535.27 716455.24 -0.7 478535.27 716455.24 6.07 478542.75 716458.88 6.07 478542.75 716458.88 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE9-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478535.27 716455.24 6.07 478537.71 716449.96 6.07 478535.47 716448.96 6.07 478536.43 716446.83 6.07 478538.78 716447.9 6.07 478542.5 716440.46 6.07 478549.97 716444.07 6.07 478542.75 716458.88 6.07 478535.27 716455.24 6.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-79EC-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-79EC-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.83</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EC-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478101.49 715827.37 0.08 478108.55 715829.89 0.08 478110.06 715830.43 0.08 478111.28 715827.1 0.08 478113.17 715821.4 0.08 478109.11 715819.93 0.08 478109.51 715818.82 0.08 478105.12 715817.24 0.08 478101.49 715827.37 0.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EC-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478101.49 715827.37 0.08 478105.12 715817.24 0.08 478105.12 715817.24 8.91 478101.49 715827.37 8.91 478101.49 715827.37 0.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EC-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478105.12 715817.24 0.08 478109.51 715818.82 0.08 478109.51 715818.82 8.91 478105.12 715817.24 8.91 478105.12 715817.24 0.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EC-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478109.51 715818.82 0.08 478109.11 715819.93 0.08 478109.11 715819.93 8.91 478109.51 715818.82 8.91 478109.51 715818.82 0.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EC-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478109.11 715819.93 0.08 478113.17 715821.4 0.08 478113.17 715821.4 8.91 478109.11 715819.93 8.91 478109.11 715819.93 0.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EC-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478113.17 715821.4 0.08 478111.28 715827.1 0.08 478111.28 715827.1 8.91 478113.17 715821.4 8.91 478113.17 715821.4 0.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EC-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478111.28 715827.1 0.08 478110.06 715830.43 0.08 478110.06 715830.43 8.91 478111.28 715827.1 8.91 478111.28 715827.1 0.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EC-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478110.06 715830.43 0.08 478108.55 715829.89 0.08 478108.55 715829.89 8.91 478110.06 715830.43 8.91 478110.06 715830.43 0.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EC-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478108.55 715829.89 0.08 478101.49 715827.37 0.08 478101.49 715827.37 8.91 478108.55 715829.89 8.91 478108.55 715829.89 0.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EC-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478101.49 715827.37 8.91 478105.12 715817.24 8.91 478109.51 715818.82 8.91 478109.11 715819.93 8.91 478113.17 715821.4 8.91 478111.28 715827.1 8.91 478110.06 715830.43 8.91 478108.55 715829.89 8.91 478101.49 715827.37 8.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-79EB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-79EB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.33</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478058.21 715670.48 0.52 478058.4 715671.02 0.52 478058.99 715670.8 0.52 478062.22 715680.01 0.52 478064.81 715679 0.52 478061.94 715671.23 0.52 478061.42 715669.37 0.52 478058.21 715670.48 0.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478058.21 715670.48 0.52 478061.42 715669.37 0.52 478061.42 715669.37 3.85 478058.21 715670.48 3.85 478058.21 715670.48 0.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478061.42 715669.37 0.52 478061.94 715671.23 0.52 478061.94 715671.23 3.85 478061.42 715669.37 3.85 478061.42 715669.37 0.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478061.94 715671.23 0.52 478064.81 715679 0.52 478064.81 715679 3.85 478061.94 715671.23 3.85 478061.94 715671.23 0.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478064.81 715679 0.52 478062.22 715680.01 0.52 478062.22 715680.01 3.85 478064.81 715679 3.85 478064.81 715679 0.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478062.22 715680.01 0.52 478058.99 715670.8 0.52 478058.99 715670.8 3.85 478062.22 715680.01 3.85 478062.22 715680.01 0.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EB-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478058.99 715670.8 0.52 478058.4 715671.02 0.52 478058.4 715671.02 3.85 478058.99 715670.8 3.85 478058.99 715670.8 0.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EB-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478058.4 715671.02 0.52 478058.21 715670.48 0.52 478058.21 715670.48 3.85 478058.4 715671.02 3.85 478058.4 715671.02 0.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79EB-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478058.21 715670.48 3.85 478061.42 715669.37 3.85 478061.94 715671.23 3.85 478064.81 715679 3.85 478062.22 715680.01 3.85 478058.99 715670.8 3.85 478058.4 715671.02 3.85 478058.21 715670.48 3.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7D51-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7D51-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.1</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D51-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477707.84 716095.61 -0.9 477713.52 716098.18 -0.9 477713.9 716097.36 -0.9 477716.17 716098.38 -0.9 477718.89 716092.25 -0.9 477716.6 716091.23 -0.9 477717.41 716089.41 -0.9 477711.7 716086.88 -0.9 477707.84 716095.61 -0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D51-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477707.84 716095.61 -0.9 477711.7 716086.88 -0.9 477711.7 716086.88 6.2 477707.84 716095.61 6.2 477707.84 716095.61 -0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D51-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477711.7 716086.88 -0.9 477717.41 716089.41 -0.9 477717.41 716089.41 6.2 477711.7 716086.88 6.2 477711.7 716086.88 -0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D51-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477717.41 716089.41 -0.9 477716.6 716091.23 -0.9 477716.6 716091.23 6.2 477717.41 716089.41 6.2 477717.41 716089.41 -0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D51-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477716.6 716091.23 -0.9 477718.89 716092.25 -0.9 477718.89 716092.25 6.2 477716.6 716091.23 6.2 477716.6 716091.23 -0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D51-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477718.89 716092.25 -0.9 477716.17 716098.38 -0.9 477716.17 716098.38 6.2 477718.89 716092.25 6.2 477718.89 716092.25 -0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D51-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477716.17 716098.38 -0.9 477713.9 716097.36 -0.9 477713.9 716097.36 6.2 477716.17 716098.38 6.2 477716.17 716098.38 -0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D51-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477713.9 716097.36 -0.9 477713.52 716098.18 -0.9 477713.52 716098.18 6.2 477713.9 716097.36 6.2 477713.9 716097.36 -0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D51-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477713.52 716098.18 -0.9 477707.84 716095.61 -0.9 477707.84 716095.61 6.2 477713.52 716098.18 6.2 477713.52 716098.18 -0.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D51-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477707.84 716095.61 6.2 477711.7 716086.88 6.2 477717.41 716089.41 6.2 477716.6 716091.23 6.2 477718.89 716092.25 6.2 477716.17 716098.38 6.2 477713.9 716097.36 6.2 477713.52 716098.18 6.2 477707.84 716095.61 6.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477797.64 716046.59 0.03 477807.06 716052.63 0.03 477810.19 716047.91 0.03 477807.82 716046.34 0.03 477811.53 716040.72 0.03 477809.74 716039.56 0.03 477812.63 716035.16 0.03 477803.59 716029.19 0.03 477801.95 716031.64 0.03 477803 716032.31 0.03 477799.75 716037.35 0.03 477802.54 716039.26 0.03 477797.64 716046.59 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477797.64 716046.59 0.03 477802.54 716039.26 0.03 477802.54 716039.26 4.655 477797.64 716046.59 4.655 477797.64 716046.59 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477802.54 716039.26 0.03 477799.75 716037.35 0.03 477799.75 716037.35 4.655 477802.54 716039.26 4.655 477802.54 716039.26 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477799.75 716037.35 0.03 477803 716032.31 0.03 477803 716032.31 4.655 477799.75 716037.35 4.655 477799.75 716037.35 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477803 716032.31 0.03 477801.95 716031.64 0.03 477801.95 716031.64 4.655 477803 716032.31 4.655 477803 716032.31 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477801.95 716031.64 0.03 477803.59 716029.19 0.03 477803.59 716029.19 4.655 477801.95 716031.64 4.655 477801.95 716031.64 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477803.59 716029.19 0.03 477812.63 716035.16 0.03 477812.63 716035.16 4.655 477803.59 716029.19 4.655 477803.59 716029.19 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477812.63 716035.16 0.03 477809.74 716039.56 0.03 477809.74 716039.56 4.655 477812.63 716035.16 4.655 477812.63 716035.16 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477809.74 716039.56 0.03 477811.53 716040.72 0.03 477811.53 716040.72 4.655 477809.74 716039.56 4.655 477809.74 716039.56 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477811.53 716040.72 0.03 477807.82 716046.34 0.03 477807.82 716046.34 4.655 477811.53 716040.72 4.655 477811.53 716040.72 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477807.82 716046.34 0.03 477810.19 716047.91 0.03 477810.19 716047.91 4.655 477807.82 716046.34 4.655 477807.82 716046.34 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477810.19 716047.91 0.03 477807.06 716052.63 0.03 477807.06 716052.63 4.655 477810.19 716047.91 4.655 477810.19 716047.91 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477807.06 716052.63 0.03 477797.64 716046.59 0.03 477797.64 716046.59 4.655 477807.06 716052.63 4.655 477807.06 716052.63 0.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4F-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477797.64 716046.59 4.655 477802.54 716039.26 4.655 477799.75 716037.35 4.655 477803 716032.31 4.655 477801.95 716031.64 4.655 477803.59 716029.19 4.655 477812.63 716035.16 4.655 477809.74 716039.56 4.655 477811.53 716040.72 4.655 477807.82 716046.34 4.655 477810.19 716047.91 4.655 477807.06 716052.63 4.655 477797.64 716046.59 4.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7D50-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7D50-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.67</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D50-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477744.27 716073.76 -0.09 477749.73 716076.62 -0.09 477754.3 716067.57 -0.09 477748.93 716064.86 -0.09 477744.27 716073.76 -0.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D50-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477744.27 716073.76 -0.09 477748.93 716064.86 -0.09 477748.93 716064.86 3.58 477744.27 716073.76 3.58 477744.27 716073.76 -0.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D50-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477748.93 716064.86 -0.09 477754.3 716067.57 -0.09 477754.3 716067.57 3.58 477748.93 716064.86 3.58 477748.93 716064.86 -0.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D50-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477754.3 716067.57 -0.09 477749.73 716076.62 -0.09 477749.73 716076.62 3.58 477754.3 716067.57 3.58 477754.3 716067.57 -0.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D50-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477749.73 716076.62 -0.09 477744.27 716073.76 -0.09 477744.27 716073.76 3.58 477749.73 716076.62 3.58 477749.73 716076.62 -0.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D50-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477744.27 716073.76 3.58 477748.93 716064.86 3.58 477754.3 716067.57 3.58 477749.73 716076.62 3.58 477744.27 716073.76 3.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7D4B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7D4B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.61</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477701.02 715843.46 -0.7 477708.47 715846.49 -0.7 477708.96 715845.25 -0.7 477714.69 715847.66 -0.7 477722.28 715829.69 -0.7 477715.87 715827.1 -0.7 477711.03 715838.55 -0.7 477704.29 715835.68 -0.7 477701.02 715843.46 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477701.02 715843.46 -0.7 477704.29 715835.68 -0.7 477704.29 715835.68 5.91 477701.02 715843.46 5.91 477701.02 715843.46 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477704.29 715835.68 -0.7 477711.03 715838.55 -0.7 477711.03 715838.55 5.91 477704.29 715835.68 5.91 477704.29 715835.68 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477711.03 715838.55 -0.7 477715.87 715827.1 -0.7 477715.87 715827.1 5.91 477711.03 715838.55 5.91 477711.03 715838.55 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477715.87 715827.1 -0.7 477722.28 715829.69 -0.7 477722.28 715829.69 5.91 477715.87 715827.1 5.91 477715.87 715827.1 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477722.28 715829.69 -0.7 477714.69 715847.66 -0.7 477714.69 715847.66 5.91 477722.28 715829.69 5.91 477722.28 715829.69 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477714.69 715847.66 -0.7 477708.96 715845.25 -0.7 477708.96 715845.25 5.91 477714.69 715847.66 5.91 477714.69 715847.66 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4B-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477708.96 715845.25 -0.7 477708.47 715846.49 -0.7 477708.47 715846.49 5.91 477708.96 715845.25 5.91 477708.96 715845.25 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4B-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477708.47 715846.49 -0.7 477701.02 715843.46 -0.7 477701.02 715843.46 5.91 477708.47 715846.49 5.91 477708.47 715846.49 -0.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4B-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477701.02 715843.46 5.91 477704.29 715835.68 5.91 477711.03 715838.55 5.91 477715.87 715827.1 5.91 477722.28 715829.69 5.91 477714.69 715847.66 5.91 477708.96 715845.25 5.91 477708.47 715846.49 5.91 477701.02 715843.46 5.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.97</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477676.81 715841.89 -0.31 477691.15 715847.37 -0.31 477693.11 715842.37 -0.31 477688.91 715840.64 -0.31 477690.01 715837.85 -0.31 477688.37 715837.28 -0.31 477689.63 715833.85 -0.31 477680.65 715830.41 -0.31 477679.12 715834.32 -0.31 477679.67 715834.59 -0.31 477676.81 715841.89 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477676.81 715841.89 -0.31 477679.67 715834.59 -0.31 477679.67 715834.59 7.66 477676.81 715841.89 7.66 477676.81 715841.89 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477679.67 715834.59 -0.31 477679.12 715834.32 -0.31 477679.12 715834.32 7.66 477679.67 715834.59 7.66 477679.67 715834.59 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477679.12 715834.32 -0.31 477680.65 715830.41 -0.31 477680.65 715830.41 7.66 477679.12 715834.32 7.66 477679.12 715834.32 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477680.65 715830.41 -0.31 477689.63 715833.85 -0.31 477689.63 715833.85 7.66 477680.65 715830.41 7.66 477680.65 715830.41 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477689.63 715833.85 -0.31 477688.37 715837.28 -0.31 477688.37 715837.28 7.66 477689.63 715833.85 7.66 477689.63 715833.85 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477688.37 715837.28 -0.31 477690.01 715837.85 -0.31 477690.01 715837.85 7.66 477688.37 715837.28 7.66 477688.37 715837.28 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477690.01 715837.85 -0.31 477688.91 715840.64 -0.31 477688.91 715840.64 7.66 477690.01 715837.85 7.66 477690.01 715837.85 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477688.91 715840.64 -0.31 477693.11 715842.37 -0.31 477693.11 715842.37 7.66 477688.91 715840.64 7.66 477688.91 715840.64 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477693.11 715842.37 -0.31 477691.15 715847.37 -0.31 477691.15 715847.37 7.66 477693.11 715842.37 7.66 477693.11 715842.37 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477691.15 715847.37 -0.31 477676.81 715841.89 -0.31 477676.81 715841.89 7.66 477691.15 715847.37 7.66 477691.15 715847.37 -0.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4A-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477676.81 715841.89 7.66 477679.67 715834.59 7.66 477679.12 715834.32 7.66 477680.65 715830.41 7.66 477689.63 715833.85 7.66 477688.37 715837.28 7.66 477690.01 715837.85 7.66 477688.91 715840.64 7.66 477693.11 715842.37 7.66 477691.15 715847.37 7.66 477676.81 715841.89 7.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7AE8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7AE8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.33</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478518.34 716466.47 -0.71 478521.95 716468.4 -0.71 478523.67 716465.16 -0.71 478526.67 716466.8 -0.71 478529.52 716461.64 -0.71 478522.9 716457.94 -0.71 478518.34 716466.47 -0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478518.34 716466.47 -0.71 478522.9 716457.94 -0.71 478522.9 716457.94 2.62 478518.34 716466.47 2.62 478518.34 716466.47 -0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478522.9 716457.94 -0.71 478529.52 716461.64 -0.71 478529.52 716461.64 2.62 478522.9 716457.94 2.62 478522.9 716457.94 -0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478529.52 716461.64 -0.71 478526.67 716466.8 -0.71 478526.67 716466.8 2.62 478529.52 716461.64 2.62 478529.52 716461.64 -0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478526.67 716466.8 -0.71 478523.67 716465.16 -0.71 478523.67 716465.16 2.62 478526.67 716466.8 2.62 478526.67 716466.8 -0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478523.67 716465.16 -0.71 478521.95 716468.4 -0.71 478521.95 716468.4 2.62 478523.67 716465.16 2.62 478523.67 716465.16 -0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE8-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478521.95 716468.4 -0.71 478518.34 716466.47 -0.71 478518.34 716466.47 2.62 478521.95 716468.4 2.62 478521.95 716468.4 -0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7AE8-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478518.34 716466.47 2.62 478522.9 716457.94 2.62 478529.52 716461.64 2.62 478526.67 716466.8 2.62 478523.67 716465.16 2.62 478521.95 716468.4 2.62 478518.34 716466.47 2.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A2A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A2A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.21</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478381.97 715878.76 -1.08 478396.09 715884.27 -1.08 478397.77 715879.73 -1.08 478392.24 715877.58 -1.08 478383.65 715874.46 -1.08 478381.97 715878.76 -1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478381.97 715878.76 -1.08 478383.65 715874.46 -1.08 478383.65 715874.46 2.13 478381.97 715878.76 2.13 478381.97 715878.76 -1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478383.65 715874.46 -1.08 478392.24 715877.58 -1.08 478392.24 715877.58 2.13 478383.65 715874.46 2.13 478383.65 715874.46 -1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478392.24 715877.58 -1.08 478397.77 715879.73 -1.08 478397.77 715879.73 2.13 478392.24 715877.58 2.13 478392.24 715877.58 -1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478397.77 715879.73 -1.08 478396.09 715884.27 -1.08 478396.09 715884.27 2.13 478397.77 715879.73 2.13 478397.77 715879.73 -1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478396.09 715884.27 -1.08 478381.97 715878.76 -1.08 478381.97 715878.76 2.13 478396.09 715884.27 2.13 478396.09 715884.27 -1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A2A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478381.97 715878.76 2.13 478383.65 715874.46 2.13 478392.24 715877.58 2.13 478397.77 715879.73 2.13 478396.09 715884.27 2.13 478381.97 715878.76 2.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-79F3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-79F3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.34</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79F3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478469.85 715617.56 0.71 478473.25 715618.01 0.71 478473.79 715614.71 0.71 478481.55 715615.88 0.71 478482.74 715607.72 0.71 478474.36 715606.47 0.71 478474.66 715604.59 0.71 478471.91 715604.14 0.71 478469.85 715617.56 0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79F3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478469.85 715617.56 0.71 478471.91 715604.14 0.71 478471.91 715604.14 6.05 478469.85 715617.56 6.05 478469.85 715617.56 0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79F3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478471.91 715604.14 0.71 478474.66 715604.59 0.71 478474.66 715604.59 6.05 478471.91 715604.14 6.05 478471.91 715604.14 0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79F3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478474.66 715604.59 0.71 478474.36 715606.47 0.71 478474.36 715606.47 6.05 478474.66 715604.59 6.05 478474.66 715604.59 0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79F3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478474.36 715606.47 0.71 478482.74 715607.72 0.71 478482.74 715607.72 6.05 478474.36 715606.47 6.05 478474.36 715606.47 0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79F3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478482.74 715607.72 0.71 478481.55 715615.88 0.71 478481.55 715615.88 6.05 478482.74 715607.72 6.05 478482.74 715607.72 0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79F3-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478481.55 715615.88 0.71 478473.79 715614.71 0.71 478473.79 715614.71 6.05 478481.55 715615.88 6.05 478481.55 715615.88 0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79F3-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478473.79 715614.71 0.71 478473.25 715618.01 0.71 478473.25 715618.01 6.05 478473.79 715614.71 6.05 478473.79 715614.71 0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79F3-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478473.25 715618.01 0.71 478469.85 715617.56 0.71 478469.85 715617.56 6.05 478473.25 715618.01 6.05 478473.25 715618.01 0.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-79F3-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478469.85 715617.56 6.05 478471.91 715604.14 6.05 478474.66 715604.59 6.05 478474.36 715606.47 6.05 478482.74 715607.72 6.05 478481.55 715615.88 6.05 478473.79 715614.71 6.05 478473.25 715618.01 6.05 478469.85 715617.56 6.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7D4E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7D4E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.95</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477824.61 716051.31 0.07 477831.38 716055.66 0.07 477838.5 716044.8 0.07 477831.75 716040.47 0.07 477824.61 716051.31 0.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477824.61 716051.31 0.07 477831.75 716040.47 0.07 477831.75 716040.47 3.02 477824.61 716051.31 3.02 477824.61 716051.31 0.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477831.75 716040.47 0.07 477838.5 716044.8 0.07 477838.5 716044.8 3.02 477831.75 716040.47 3.02 477831.75 716040.47 0.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477838.5 716044.8 0.07 477831.38 716055.66 0.07 477831.38 716055.66 3.02 477838.5 716044.8 3.02 477838.5 716044.8 0.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477831.38 716055.66 0.07 477824.61 716051.31 0.07 477824.61 716051.31 3.02 477831.38 716055.66 3.02 477831.38 716055.66 0.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477824.61 716051.31 3.02 477831.75 716040.47 3.02 477838.5 716044.8 3.02 477831.38 716055.66 3.02 477824.61 716051.31 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7D4D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7D4D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477806.31 716053.8 0.09 477818.12 716061.61 0.09 477821.93 716055.67 0.09 477810.19 716047.91 0.09 477807.06 716052.63 0.09 477806.31 716053.8 0.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477806.31 716053.8 0.09 477807.06 716052.63 0.09 477807.06 716052.63 3.0300000000000002 477806.31 716053.8 3.0300000000000002 477806.31 716053.8 0.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477807.06 716052.63 0.09 477810.19 716047.91 0.09 477810.19 716047.91 3.0300000000000002 477807.06 716052.63 3.0300000000000002 477807.06 716052.63 0.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477810.19 716047.91 0.09 477821.93 716055.67 0.09 477821.93 716055.67 3.0300000000000002 477810.19 716047.91 3.0300000000000002 477810.19 716047.91 0.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477821.93 716055.67 0.09 477818.12 716061.61 0.09 477818.12 716061.61 3.0300000000000002 477821.93 716055.67 3.0300000000000002 477821.93 716055.67 0.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477818.12 716061.61 0.09 477806.31 716053.8 0.09 477806.31 716053.8 3.0300000000000002 477818.12 716061.61 3.0300000000000002 477818.12 716061.61 0.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7D4D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477806.31 716053.8 3.0300000000000002 477807.06 716052.63 3.0300000000000002 477810.19 716047.91 3.0300000000000002 477821.93 716055.67 3.0300000000000002 477818.12 716061.61 3.0300000000000002 477806.31 716053.8 3.0300000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-7229aba9-0cff-4c2c-af56-d235129babf1">
			<gen:stringAttribute name="buildingId">
				<gen:value>7229aba9-0cff-4c2c-af56-d235129babf1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.64</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7229aba9-0cff-4c2c-af56-d235129babf1_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478691.82 715593.1 -0.27 478691.84 715602.71 -0.27 478729.07 715602.64 -0.27 478729.05 715593.28 -0.27 478691.82 715593.1 -0.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7229aba9-0cff-4c2c-af56-d235129babf1_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478691.82 715593.1 -0.27 478729.05 715593.28 -0.27 478729.05 715593.28 5.370000000000001 478691.82 715593.1 5.370000000000001 478691.82 715593.1 -0.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7229aba9-0cff-4c2c-af56-d235129babf1_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478729.05 715593.28 -0.27 478729.07 715602.64 -0.27 478729.07 715602.64 5.370000000000001 478729.05 715593.28 5.370000000000001 478729.05 715593.28 -0.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7229aba9-0cff-4c2c-af56-d235129babf1_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478729.07 715602.64 -0.27 478691.84 715602.71 -0.27 478691.84 715602.71 5.370000000000001 478729.07 715602.64 5.370000000000001 478729.07 715602.64 -0.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7229aba9-0cff-4c2c-af56-d235129babf1_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478691.84 715602.71 -0.27 478691.82 715593.1 -0.27 478691.82 715593.1 5.370000000000001 478691.84 715602.71 5.370000000000001 478691.84 715602.71 -0.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7229aba9-0cff-4c2c-af56-d235129babf1_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478691.82 715593.1 5.370000000000001 478729.05 715593.28 5.370000000000001 478729.07 715602.64 5.370000000000001 478691.84 715602.71 5.370000000000001 478691.82 715593.1 5.370000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-b980691a-3622-474b-8feb-938ae91dc1f2">
			<gen:stringAttribute name="buildingId">
				<gen:value>b980691a-3622-474b-8feb-938ae91dc1f2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.64</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b980691a-3622-474b-8feb-938ae91dc1f2_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478512.13 715817.1 -0.67 478522.87 715821.82 -0.67 478526.83 715812.8 -0.67 478516.1 715808.08 -0.67 478512.13 715817.1 -0.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b980691a-3622-474b-8feb-938ae91dc1f2_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478512.13 715817.1 -0.67 478516.1 715808.08 -0.67 478516.1 715808.08 5.97 478512.13 715817.1 5.97 478512.13 715817.1 -0.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b980691a-3622-474b-8feb-938ae91dc1f2_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478516.1 715808.08 -0.67 478526.83 715812.8 -0.67 478526.83 715812.8 5.97 478516.1 715808.08 5.97 478516.1 715808.08 -0.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b980691a-3622-474b-8feb-938ae91dc1f2_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478526.83 715812.8 -0.67 478522.87 715821.82 -0.67 478522.87 715821.82 5.97 478526.83 715812.8 5.97 478526.83 715812.8 -0.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b980691a-3622-474b-8feb-938ae91dc1f2_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478522.87 715821.82 -0.67 478512.13 715817.1 -0.67 478512.13 715817.1 5.97 478522.87 715821.82 5.97 478522.87 715821.82 -0.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b980691a-3622-474b-8feb-938ae91dc1f2_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478512.13 715817.1 5.97 478516.1 715808.08 5.97 478526.83 715812.8 5.97 478522.87 715821.82 5.97 478512.13 715817.1 5.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C4A3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C4A3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.73</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4A3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478587.61 716474.96 -0.64 478596.79 716479.41 -0.64 478600.24 716472.28 -0.64 478591.06 716467.84 -0.64 478587.61 716474.96 -0.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4A3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478587.61 716474.96 -0.64 478591.06 716467.84 -0.64 478591.06 716467.84 3.09 478587.61 716474.96 3.09 478587.61 716474.96 -0.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4A3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478591.06 716467.84 -0.64 478600.24 716472.28 -0.64 478600.24 716472.28 3.09 478591.06 716467.84 3.09 478591.06 716467.84 -0.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4A3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478600.24 716472.28 -0.64 478596.79 716479.41 -0.64 478596.79 716479.41 3.09 478600.24 716472.28 3.09 478600.24 716472.28 -0.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4A3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478596.79 716479.41 -0.64 478587.61 716474.96 -0.64 478587.61 716474.96 3.09 478596.79 716479.41 3.09 478596.79 716479.41 -0.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C4A3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>478587.61 716474.96 3.09 478591.06 716467.84 3.09 478600.24 716472.28 3.09 478596.79 716479.41 3.09 478587.61 716474.96 3.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C195-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C195-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C195-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477723.42 716082.16 -0.39 477730.84 716087.19 -0.39 477733.5 716083.25 -0.39 477726.09 716078.22 -0.39 477723.42 716082.16 -0.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C195-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477723.42 716082.16 -0.39 477726.09 716078.22 -0.39 477726.09 716078.22 2.9 477723.42 716082.16 2.9 477723.42 716082.16 -0.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C195-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477726.09 716078.22 -0.39 477733.5 716083.25 -0.39 477733.5 716083.25 2.9 477726.09 716078.22 2.9 477726.09 716078.22 -0.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C195-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477733.5 716083.25 -0.39 477730.84 716087.19 -0.39 477730.84 716087.19 2.9 477733.5 716083.25 2.9 477733.5 716083.25 -0.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C195-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477730.84 716087.19 -0.39 477723.42 716082.16 -0.39 477723.42 716082.16 2.9 477730.84 716087.19 2.9 477730.84 716087.19 -0.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C195-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>477723.42 716082.16 2.9 477726.09 716078.22 2.9 477733.5 716083.25 2.9 477730.84 716087.19 2.9 477723.42 716082.16 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
</CityModel>
<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0" xmlns="http://www.opengis.net/citygml/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
			<gml:lowerCorner>468731.69 725855.2 68.65</gml:lowerCorner>
			<gml:upperCorner>469570.67 727934.31 93.19</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4E88-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4E88-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.56</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4E88-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469113.51 725866.71 80.01 469115.93 725863.3 80.01 469113.44 725861.56 80.01 469115.15 725859.13 80.01 469109.56 725855.2 80.01 469107.82 725857.67 80.01 469106.1 725856.47 80.01 469103.72 725859.89 80.01 469113.51 725866.71 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4E88-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469113.51 725866.71 80.01 469103.72 725859.89 80.01 469103.72 725859.89 83.57000000000001 469113.51 725866.71 83.57000000000001 469113.51 725866.71 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4E88-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469103.72 725859.89 80.01 469106.1 725856.47 80.01 469106.1 725856.47 83.57000000000001 469103.72 725859.89 83.57000000000001 469103.72 725859.89 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4E88-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469106.1 725856.47 80.01 469107.82 725857.67 80.01 469107.82 725857.67 83.57000000000001 469106.1 725856.47 83.57000000000001 469106.1 725856.47 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4E88-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469107.82 725857.67 80.01 469109.56 725855.2 80.01 469109.56 725855.2 83.57000000000001 469107.82 725857.67 83.57000000000001 469107.82 725857.67 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4E88-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469109.56 725855.2 80.01 469115.15 725859.13 80.01 469115.15 725859.13 83.57000000000001 469109.56 725855.2 83.57000000000001 469109.56 725855.2 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4E88-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469115.15 725859.13 80.01 469113.44 725861.56 80.01 469113.44 725861.56 83.57000000000001 469115.15 725859.13 83.57000000000001 469115.15 725859.13 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4E88-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469113.44 725861.56 80.01 469115.93 725863.3 80.01 469115.93 725863.3 83.57000000000001 469113.44 725861.56 83.57000000000001 469113.44 725861.56 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4E88-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469115.93 725863.3 80.01 469113.51 725866.71 80.01 469113.51 725866.71 83.57000000000001 469115.93 725863.3 83.57000000000001 469115.93 725863.3 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4E88-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469113.51 725866.71 83.57000000000001 469103.72 725859.89 83.57000000000001 469106.1 725856.47 83.57000000000001 469107.82 725857.67 83.57000000000001 469109.56 725855.2 83.57000000000001 469115.15 725859.13 83.57000000000001 469113.44 725861.56 83.57000000000001 469115.93 725863.3 83.57000000000001 469113.51 725866.71 83.57000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468742.37 725961.5 85.07 468743.44 725960.62 85.07 468751.09 725954.35 85.07 468748.37 725951.03 85.07 468748.67 725950.78 85.07 468746.89 725948.62 85.07 468746.59 725948.87 85.07 468743.89 725945.59 85.07 468735.17 725952.76 85.07 468737.9 725956.09 85.07 468737.59 725956.33 85.07 468739.35 725958.46 85.07 468739.64 725958.21 85.07 468742.37 725961.5 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468742.37 725961.5 85.07 468739.64 725958.21 85.07 468739.64 725958.21 92.7 468742.37 725961.5 92.7 468742.37 725961.5 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468739.64 725958.21 85.07 468739.35 725958.46 85.07 468739.35 725958.46 92.7 468739.64 725958.21 92.7 468739.64 725958.21 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468739.35 725958.46 85.07 468737.59 725956.33 85.07 468737.59 725956.33 92.7 468739.35 725958.46 92.7 468739.35 725958.46 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468737.59 725956.33 85.07 468737.9 725956.09 85.07 468737.9 725956.09 92.7 468737.59 725956.33 92.7 468737.59 725956.33 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468737.9 725956.09 85.07 468735.17 725952.76 85.07 468735.17 725952.76 92.7 468737.9 725956.09 92.7 468737.9 725956.09 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468735.17 725952.76 85.07 468743.89 725945.59 85.07 468743.89 725945.59 92.7 468735.17 725952.76 92.7 468735.17 725952.76 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468743.89 725945.59 85.07 468746.59 725948.87 85.07 468746.59 725948.87 92.7 468743.89 725945.59 92.7 468743.89 725945.59 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468746.59 725948.87 85.07 468746.89 725948.62 85.07 468746.89 725948.62 92.7 468746.59 725948.87 92.7 468746.59 725948.87 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468746.89 725948.62 85.07 468748.67 725950.78 85.07 468748.67 725950.78 92.7 468746.89 725948.62 92.7 468746.89 725948.62 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468748.67 725950.78 85.07 468748.37 725951.03 85.07 468748.37 725951.03 92.7 468748.67 725950.78 92.7 468748.67 725950.78 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468748.37 725951.03 85.07 468751.09 725954.35 85.07 468751.09 725954.35 92.7 468748.37 725951.03 92.7 468748.37 725951.03 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468751.09 725954.35 85.07 468743.44 725960.62 85.07 468743.44 725960.62 92.7 468751.09 725954.35 92.7 468751.09 725954.35 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468743.44 725960.62 85.07 468742.37 725961.5 85.07 468742.37 725961.5 92.7 468743.44 725960.62 92.7 468743.44 725960.62 85.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F5-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468742.37 725961.5 92.7 468739.64 725958.21 92.7 468739.35 725958.46 92.7 468737.59 725956.33 92.7 468737.9 725956.09 92.7 468735.17 725952.76 92.7 468743.89 725945.59 92.7 468746.59 725948.87 92.7 468746.89 725948.62 92.7 468748.67 725950.78 92.7 468748.37 725951.03 92.7 468751.09 725954.35 92.7 468743.44 725960.62 92.7 468742.37 725961.5 92.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F2F8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F2F8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468761.94 725985.51 85.14 468768.78 725979.91 85.14 468758.36 725967.16 85.14 468751.52 725972.75 85.14 468761.94 725985.51 85.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468761.94 725985.51 85.14 468751.52 725972.75 85.14 468751.52 725972.75 92.69 468761.94 725985.51 92.69 468761.94 725985.51 85.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468751.52 725972.75 85.14 468758.36 725967.16 85.14 468758.36 725967.16 92.69 468751.52 725972.75 92.69 468751.52 725972.75 85.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468758.36 725967.16 85.14 468768.78 725979.91 85.14 468768.78 725979.91 92.69 468758.36 725967.16 92.69 468758.36 725967.16 85.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468768.78 725979.91 85.14 468761.94 725985.51 85.14 468761.94 725985.51 92.69 468768.78 725979.91 92.69 468768.78 725979.91 85.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F2F8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468761.94 725985.51 92.69 468751.52 725972.75 92.69 468758.36 725967.16 92.69 468768.78 725979.91 92.69 468761.94 725985.51 92.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C78F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C78F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.52</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C78F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468744.47 725996.09 88.34 468748.67 725992.68 88.34 468742.12 725984.64 88.34 468737.93 725988.05 88.34 468744.47 725996.09 88.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C78F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468744.47 725996.09 88.34 468737.93 725988.05 88.34 468737.93 725988.05 92.86 468744.47 725996.09 92.86 468744.47 725996.09 88.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C78F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468737.93 725988.05 88.34 468742.12 725984.64 88.34 468742.12 725984.64 92.86 468737.93 725988.05 92.86 468737.93 725988.05 88.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C78F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468742.12 725984.64 88.34 468748.67 725992.68 88.34 468748.67 725992.68 92.86 468742.12 725984.64 92.86 468742.12 725984.64 88.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C78F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468748.67 725992.68 88.34 468744.47 725996.09 88.34 468744.47 725996.09 92.86 468748.67 725992.68 92.86 468748.67 725992.68 88.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C78F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468744.47 725996.09 92.86 468737.93 725988.05 92.86 468742.12 725984.64 92.86 468748.67 725992.68 92.86 468744.47 725996.09 92.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-F488-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-F488-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.19</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F488-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468962.6 725966.26 75.17 468970 725968.94 75.17 468970.11 725968.71 75.17 468975.03 725955.06 75.17 468967.76 725951.88 75.17 468962.6 725966.26 75.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F488-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468962.6 725966.26 75.17 468967.76 725951.88 75.17 468967.76 725951.88 84.36 468962.6 725966.26 84.36 468962.6 725966.26 75.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F488-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468967.76 725951.88 75.17 468975.03 725955.06 75.17 468975.03 725955.06 84.36 468967.76 725951.88 84.36 468967.76 725951.88 75.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F488-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468975.03 725955.06 75.17 468970.11 725968.71 75.17 468970.11 725968.71 84.36 468975.03 725955.06 84.36 468975.03 725955.06 75.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F488-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468970.11 725968.71 75.17 468970 725968.94 75.17 468970 725968.94 84.36 468970.11 725968.71 84.36 468970.11 725968.71 75.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F488-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468970 725968.94 75.17 468962.6 725966.26 75.17 468962.6 725966.26 84.36 468970 725968.94 84.36 468970 725968.94 75.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-F488-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468962.6 725966.26 84.36 468967.76 725951.88 84.36 468975.03 725955.06 84.36 468970.11 725968.71 84.36 468970 725968.94 84.36 468962.6 725966.26 84.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C791-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C791-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.4</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C791-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468791.02 725969.02 84.12 468798.6 725962.68 84.12 468788.28 725950.33 84.12 468780.69 725956.67 84.12 468791.02 725969.02 84.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C791-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468791.02 725969.02 84.12 468780.69 725956.67 84.12 468780.69 725956.67 90.52 468791.02 725969.02 90.52 468791.02 725969.02 84.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C791-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468780.69 725956.67 84.12 468788.28 725950.33 84.12 468788.28 725950.33 90.52 468780.69 725956.67 90.52 468780.69 725956.67 84.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C791-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468788.28 725950.33 84.12 468798.6 725962.68 84.12 468798.6 725962.68 90.52 468788.28 725950.33 90.52 468788.28 725950.33 84.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C791-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468798.6 725962.68 84.12 468791.02 725969.02 84.12 468791.02 725969.02 90.52 468798.6 725962.68 90.52 468798.6 725962.68 84.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C791-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468791.02 725969.02 90.52 468780.69 725956.67 90.52 468788.28 725950.33 90.52 468798.6 725962.68 90.52 468791.02 725969.02 90.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C790-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C790-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.45</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C790-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468731.83 725982.04 86.74 468735.45 725982 86.74 468738.69 725981.97 86.74 468738.54 725967.85 86.74 468731.69 725967.91 86.74 468731.83 725982.04 86.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C790-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468731.83 725982.04 86.74 468731.69 725967.91 86.74 468731.69 725967.91 93.19 468731.83 725982.04 93.19 468731.83 725982.04 86.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C790-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468731.69 725967.91 86.74 468738.54 725967.85 86.74 468738.54 725967.85 93.19 468731.69 725967.91 93.19 468731.69 725967.91 86.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C790-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468738.54 725967.85 86.74 468738.69 725981.97 86.74 468738.69 725981.97 93.19 468738.54 725967.85 93.19 468738.54 725967.85 86.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C790-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468738.69 725981.97 86.74 468735.45 725982 86.74 468735.45 725982 93.19 468738.69 725981.97 93.19 468738.69 725981.97 86.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C790-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468735.45 725982 86.74 468731.83 725982.04 86.74 468731.83 725982.04 93.19 468735.45 725982 93.19 468735.45 725982 86.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C790-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468731.83 725982.04 93.19 468731.69 725967.91 93.19 468738.54 725967.85 93.19 468738.69 725981.97 93.19 468735.45 725982 93.19 468731.83 725982.04 93.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C85B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C85B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.12</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C85B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469532.69 727934.31 71.58 469544.78 727928.81 71.58 469543.48 727925.96 71.58 469538.49 727914.97 71.58 469537.47 727912.72 71.58 469525.37 727918.22 71.58 469526.3 727920.28 71.58 469531.67 727932.06 71.58 469532.69 727934.31 71.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C85B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469532.69 727934.31 71.58 469531.67 727932.06 71.58 469531.67 727932.06 81.7 469532.69 727934.31 81.7 469532.69 727934.31 71.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C85B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469531.67 727932.06 71.58 469526.3 727920.28 71.58 469526.3 727920.28 81.7 469531.67 727932.06 81.7 469531.67 727932.06 71.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C85B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469526.3 727920.28 71.58 469525.37 727918.22 71.58 469525.37 727918.22 81.7 469526.3 727920.28 81.7 469526.3 727920.28 71.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C85B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469525.37 727918.22 71.58 469537.47 727912.72 71.58 469537.47 727912.72 81.7 469525.37 727918.22 81.7 469525.37 727918.22 71.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C85B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469537.47 727912.72 71.58 469538.49 727914.97 71.58 469538.49 727914.97 81.7 469537.47 727912.72 81.7 469537.47 727912.72 71.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C85B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469538.49 727914.97 71.58 469543.48 727925.96 71.58 469543.48 727925.96 81.7 469538.49 727914.97 81.7 469538.49 727914.97 71.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C85B-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469543.48 727925.96 71.58 469544.78 727928.81 71.58 469544.78 727928.81 81.7 469543.48 727925.96 81.7 469543.48 727925.96 71.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C85B-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469544.78 727928.81 71.58 469532.69 727934.31 71.58 469532.69 727934.31 81.7 469544.78 727928.81 81.7 469544.78 727928.81 71.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C85B-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469532.69 727934.31 81.7 469531.67 727932.06 81.7 469526.3 727920.28 81.7 469525.37 727918.22 81.7 469537.47 727912.72 81.7 469538.49 727914.97 81.7 469543.48 727925.96 81.7 469544.78 727928.81 81.7 469532.69 727934.31 81.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D82E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D82E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.59</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D82E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469086.08 725898.44 80.01 469089.41 725893.71 80.01 469083.77 725889.76 80.01 469080.46 725894.48 80.01 469086.08 725898.44 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D82E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469086.08 725898.44 80.01 469080.46 725894.48 80.01 469080.46 725894.48 84.605 469086.08 725898.44 84.605 469086.08 725898.44 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D82E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469080.46 725894.48 80.01 469083.77 725889.76 80.01 469083.77 725889.76 84.605 469080.46 725894.48 84.605 469080.46 725894.48 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D82E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469083.77 725889.76 80.01 469089.41 725893.71 80.01 469089.41 725893.71 84.605 469083.77 725889.76 84.605 469083.77 725889.76 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D82E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469089.41 725893.71 80.01 469086.08 725898.44 80.01 469086.08 725898.44 84.605 469089.41 725893.71 84.605 469089.41 725893.71 80.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D82E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469086.08 725898.44 84.605 469080.46 725894.48 84.605 469083.77 725889.76 84.605 469089.41 725893.71 84.605 469086.08 725898.44 84.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D8EC-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D8EC-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8EC-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469093.73 725892.29 80.11 469110.45 725868.31 80.11 469102.6 725862.77 80.11 469085.97 725886.81 80.11 469093.73 725892.29 80.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8EC-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469093.73 725892.29 80.11 469085.97 725886.81 80.11 469085.97 725886.81 83.43 469093.73 725892.29 83.43 469093.73 725892.29 80.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8EC-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469085.97 725886.81 80.11 469102.6 725862.77 80.11 469102.6 725862.77 83.43 469085.97 725886.81 83.43 469085.97 725886.81 80.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8EC-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469102.6 725862.77 80.11 469110.45 725868.31 80.11 469110.45 725868.31 83.43 469102.6 725862.77 83.43 469102.6 725862.77 80.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8EC-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469110.45 725868.31 80.11 469093.73 725892.29 80.11 469093.73 725892.29 83.43 469110.45 725868.31 83.43 469110.45 725868.31 80.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D8EC-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469093.73 725892.29 83.43 469085.97 725886.81 83.43 469102.6 725862.77 83.43 469110.45 725868.31 83.43 469093.73 725892.29 83.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D831-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D831-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.74</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D831-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469099.4 725896.41 80.09 469116.17 725872.32 80.09 469110.45 725868.31 80.09 469093.73 725892.29 80.09 469093.65 725892.39 80.09 469099.4 725896.41 80.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D831-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469099.4 725896.41 80.09 469093.65 725892.39 80.09 469093.65 725892.39 85.83 469099.4 725896.41 85.83 469099.4 725896.41 80.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D831-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469093.65 725892.39 80.09 469093.73 725892.29 80.09 469093.73 725892.29 85.83 469093.65 725892.39 85.83 469093.65 725892.39 80.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D831-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469093.73 725892.29 80.09 469110.45 725868.31 80.09 469110.45 725868.31 85.83 469093.73 725892.29 85.83 469093.73 725892.29 80.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D831-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469110.45 725868.31 80.09 469116.17 725872.32 80.09 469116.17 725872.32 85.83 469110.45 725868.31 85.83 469110.45 725868.31 80.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D831-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469116.17 725872.32 80.09 469099.4 725896.41 80.09 469099.4 725896.41 85.83 469116.17 725872.32 85.83 469116.17 725872.32 80.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D831-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469099.4 725896.41 85.83 469093.65 725892.39 85.83 469093.73 725892.29 85.83 469110.45 725868.31 85.83 469116.17 725872.32 85.83 469099.4 725896.41 85.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-4DB9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-4DB9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.59</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DB9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468934.45 726029.86 81.06 468937.23 726020.17 81.06 468932.88 726018.92 81.06 468930.09 726028.62 81.06 468934.45 726029.86 81.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DB9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468934.45 726029.86 81.06 468930.09 726028.62 81.06 468930.09 726028.62 84.65 468934.45 726029.86 84.65 468934.45 726029.86 81.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DB9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468930.09 726028.62 81.06 468932.88 726018.92 81.06 468932.88 726018.92 84.65 468930.09 726028.62 84.65 468930.09 726028.62 81.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DB9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468932.88 726018.92 81.06 468937.23 726020.17 81.06 468937.23 726020.17 84.65 468932.88 726018.92 84.65 468932.88 726018.92 81.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DB9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468937.23 726020.17 81.06 468934.45 726029.86 81.06 468934.45 726029.86 84.65 468937.23 726020.17 84.65 468937.23 726020.17 81.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-4DB9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468934.45 726029.86 84.65 468930.09 726028.62 84.65 468932.88 726018.92 84.65 468937.23 726020.17 84.65 468934.45 726029.86 84.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697">
			<gen:stringAttribute name="buildingId">
				<gen:value>eb5e4eaa-8a2f-4224-80eb-79f1f7854697</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468972.47 725936.13 75.02 468968.18 725947.85 75.02 468967.08 725947.6 75.02 468965.84 725951.27 75.02 468967.76 725951.88 75.02 468975.03 725955.06 75.02 468975.58 725955.24 75.02 468978.29 725948.14 75.02 468973.93 725946.49 75.02 468974.68 725944.58 75.02 468974.97 725944.64 75.02 468977.48 725937.73 75.02 468972.47 725936.13 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468972.47 725936.13 75.02 468977.48 725937.73 75.02 468977.48 725937.73 78.65 468972.47 725936.13 78.65 468972.47 725936.13 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468977.48 725937.73 75.02 468974.97 725944.64 75.02 468974.97 725944.64 78.65 468977.48 725937.73 78.65 468977.48 725937.73 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468974.97 725944.64 75.02 468974.68 725944.58 75.02 468974.68 725944.58 78.65 468974.97 725944.64 78.65 468974.97 725944.64 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468974.68 725944.58 75.02 468973.93 725946.49 75.02 468973.93 725946.49 78.65 468974.68 725944.58 78.65 468974.68 725944.58 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468973.93 725946.49 75.02 468978.29 725948.14 75.02 468978.29 725948.14 78.65 468973.93 725946.49 78.65 468973.93 725946.49 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468978.29 725948.14 75.02 468975.58 725955.24 75.02 468975.58 725955.24 78.65 468978.29 725948.14 78.65 468978.29 725948.14 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468975.58 725955.24 75.02 468975.03 725955.06 75.02 468975.03 725955.06 78.65 468975.58 725955.24 78.65 468975.58 725955.24 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468975.03 725955.06 75.02 468967.76 725951.88 75.02 468967.76 725951.88 78.65 468975.03 725955.06 78.65 468975.03 725955.06 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468967.76 725951.88 75.02 468965.84 725951.27 75.02 468965.84 725951.27 78.65 468967.76 725951.88 78.65 468967.76 725951.88 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468965.84 725951.27 75.02 468967.08 725947.6 75.02 468967.08 725947.6 78.65 468965.84 725951.27 78.65 468965.84 725951.27 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468967.08 725947.6 75.02 468968.18 725947.85 75.02 468968.18 725947.85 78.65 468967.08 725947.6 78.65 468967.08 725947.6 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468968.18 725947.85 75.02 468972.47 725936.13 75.02 468972.47 725936.13 78.65 468968.18 725947.85 78.65 468968.18 725947.85 75.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-eb5e4eaa-8a2f-4224-80eb-79f1f7854697_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468972.47 725936.13 78.65 468977.48 725937.73 78.65 468974.97 725944.64 78.65 468974.68 725944.58 78.65 468973.93 725946.49 78.65 468978.29 725948.14 78.65 468975.58 725955.24 78.65 468975.03 725955.06 78.65 468967.76 725951.88 78.65 468965.84 725951.27 78.65 468967.08 725947.6 78.65 468968.18 725947.85 78.65 468972.47 725936.13 78.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.54</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468943.27 726016.67 78.84 468945.22 726011.52 78.84 468946.21 726011.9 78.84 468949.67 726002.79 78.84 468946.15 726001.44 78.84 468944.95 726000.99 78.84 468944.76 726000.94 78.84 468944.81 726000.81 78.84 468938.24 725998.31 78.84 468938.1 725998.66 78.84 468937.71 725998.52 78.84 468932.4 725996.44 78.84 468927.91 726008.33 78.84 468927.13 726010.41 78.84 468928.86 726011.06 78.84 468928.23 726012.71 78.84 468932.17 726014.22 78.84 468932.71 726012.81 78.84 468943.27 726016.67 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468943.27 726016.67 78.84 468932.71 726012.81 78.84 468932.71 726012.81 89.38 468943.27 726016.67 89.38 468943.27 726016.67 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468932.71 726012.81 78.84 468932.17 726014.22 78.84 468932.17 726014.22 89.38 468932.71 726012.81 89.38 468932.71 726012.81 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468932.17 726014.22 78.84 468928.23 726012.71 78.84 468928.23 726012.71 89.38 468932.17 726014.22 89.38 468932.17 726014.22 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468928.23 726012.71 78.84 468928.86 726011.06 78.84 468928.86 726011.06 89.38 468928.23 726012.71 89.38 468928.23 726012.71 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468928.86 726011.06 78.84 468927.13 726010.41 78.84 468927.13 726010.41 89.38 468928.86 726011.06 89.38 468928.86 726011.06 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468927.13 726010.41 78.84 468927.91 726008.33 78.84 468927.91 726008.33 89.38 468927.13 726010.41 89.38 468927.13 726010.41 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468927.91 726008.33 78.84 468932.4 725996.44 78.84 468932.4 725996.44 89.38 468927.91 726008.33 89.38 468927.91 726008.33 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468932.4 725996.44 78.84 468937.71 725998.52 78.84 468937.71 725998.52 89.38 468932.4 725996.44 89.38 468932.4 725996.44 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468937.71 725998.52 78.84 468938.1 725998.66 78.84 468938.1 725998.66 89.38 468937.71 725998.52 89.38 468937.71 725998.52 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468938.1 725998.66 78.84 468938.24 725998.31 78.84 468938.24 725998.31 89.38 468938.1 725998.66 89.38 468938.1 725998.66 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468938.24 725998.31 78.84 468944.81 726000.81 78.84 468944.81 726000.81 89.38 468938.24 725998.31 89.38 468938.24 725998.31 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468944.81 726000.81 78.84 468944.76 726000.94 78.84 468944.76 726000.94 89.38 468944.81 726000.81 89.38 468944.81 726000.81 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468944.76 726000.94 78.84 468944.95 726000.99 78.84 468944.95 726000.99 89.38 468944.76 726000.94 89.38 468944.76 726000.94 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468944.95 726000.99 78.84 468946.15 726001.44 78.84 468946.15 726001.44 89.38 468944.95 726000.99 89.38 468944.95 726000.99 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468946.15 726001.44 78.84 468949.67 726002.79 78.84 468949.67 726002.79 89.38 468946.15 726001.44 89.38 468946.15 726001.44 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468949.67 726002.79 78.84 468946.21 726011.9 78.84 468946.21 726011.9 89.38 468949.67 726002.79 89.38 468949.67 726002.79 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468946.21 726011.9 78.84 468945.22 726011.52 78.84 468945.22 726011.52 89.38 468946.21 726011.9 89.38 468946.21 726011.9 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468945.22 726011.52 78.84 468943.27 726016.67 78.84 468943.27 726016.67 89.38 468945.22 726011.52 89.38 468945.22 726011.52 78.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2A12-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468943.27 726016.67 89.38 468932.71 726012.81 89.38 468932.17 726014.22 89.38 468928.23 726012.71 89.38 468928.86 726011.06 89.38 468927.13 726010.41 89.38 468927.91 726008.33 89.38 468932.4 725996.44 89.38 468937.71 725998.52 89.38 468938.1 725998.66 89.38 468938.24 725998.31 89.38 468944.81 726000.81 89.38 468944.76 726000.94 89.38 468944.95 726000.99 89.38 468946.15 726001.44 89.38 468949.67 726002.79 89.38 468946.21 726011.9 89.38 468945.22 726011.52 89.38 468943.27 726016.67 89.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C794-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C794-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.91</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C794-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468981.22 726026.07 78.62 468984.26 726017.13 78.62 468956.96 726008.64 78.62 468954.18 726017.66 78.62 468981.22 726026.07 78.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C794-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468981.22 726026.07 78.62 468954.18 726017.66 78.62 468954.18 726017.66 83.53 468981.22 726026.07 83.53 468981.22 726026.07 78.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C794-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468954.18 726017.66 78.62 468956.96 726008.64 78.62 468956.96 726008.64 83.53 468954.18 726017.66 83.53 468954.18 726017.66 78.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C794-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468956.96 726008.64 78.62 468984.26 726017.13 78.62 468984.26 726017.13 83.53 468956.96 726008.64 83.53 468956.96 726008.64 78.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C794-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468984.26 726017.13 78.62 468981.22 726026.07 78.62 468981.22 726026.07 83.53 468984.26 726017.13 83.53 468984.26 726017.13 78.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C794-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468981.22 726026.07 83.53 468954.18 726017.66 83.53 468956.96 726008.64 83.53 468984.26 726017.13 83.53 468981.22 726026.07 83.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C795-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C795-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.19</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C795-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468995.77 725967.47 74.71 468990.93 725980.54 74.71 468997.61 725983.01 74.71 469002.45 725969.94 74.71 468995.77 725967.47 74.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C795-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468995.77 725967.47 74.71 469002.45 725969.94 74.71 469002.45 725969.94 77.9 468995.77 725967.47 77.9 468995.77 725967.47 74.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C795-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469002.45 725969.94 74.71 468997.61 725983.01 74.71 468997.61 725983.01 77.9 469002.45 725969.94 77.9 469002.45 725969.94 74.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C795-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468997.61 725983.01 74.71 468990.93 725980.54 74.71 468990.93 725980.54 77.9 468997.61 725983.01 77.9 468997.61 725983.01 74.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C795-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468990.93 725980.54 74.71 468995.77 725967.47 74.71 468995.77 725967.47 77.9 468990.93 725980.54 77.9 468990.93 725980.54 74.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C795-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>468995.77 725967.47 77.9 469002.45 725969.94 77.9 468997.61 725983.01 77.9 468990.93 725980.54 77.9 468995.77 725967.47 77.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-e84be8f6-82bb-40ec-9ad6-ad7949774c4c">
			<gen:stringAttribute name="buildingId">
				<gen:value>e84be8f6-82bb-40ec-9ad6-ad7949774c4c</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.23</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e84be8f6-82bb-40ec-9ad6-ad7949774c4c_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469565.73 727875.3 68.65 469559.7 727878.14 68.65 469560.14 727880.2 68.65 469552.02 727881.59 68.65 469553.82 727891.27 68.65 469562.16 727889.84 68.65 469570.67 727885.86 68.65 469565.73 727875.3 68.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e84be8f6-82bb-40ec-9ad6-ad7949774c4c_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469565.73 727875.3 68.65 469570.67 727885.86 68.65 469570.67 727885.86 74.88 469565.73 727875.3 74.88 469565.73 727875.3 68.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e84be8f6-82bb-40ec-9ad6-ad7949774c4c_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469570.67 727885.86 68.65 469562.16 727889.84 68.65 469562.16 727889.84 74.88 469570.67 727885.86 74.88 469570.67 727885.86 68.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e84be8f6-82bb-40ec-9ad6-ad7949774c4c_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469562.16 727889.84 68.65 469553.82 727891.27 68.65 469553.82 727891.27 74.88 469562.16 727889.84 74.88 469562.16 727889.84 68.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e84be8f6-82bb-40ec-9ad6-ad7949774c4c_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469553.82 727891.27 68.65 469552.02 727881.59 68.65 469552.02 727881.59 74.88 469553.82 727891.27 74.88 469553.82 727891.27 68.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e84be8f6-82bb-40ec-9ad6-ad7949774c4c_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469552.02 727881.59 68.65 469560.14 727880.2 68.65 469560.14 727880.2 74.88 469552.02 727881.59 74.88 469552.02 727881.59 68.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e84be8f6-82bb-40ec-9ad6-ad7949774c4c_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469560.14 727880.2 68.65 469559.7 727878.14 68.65 469559.7 727878.14 74.88 469560.14 727880.2 74.88 469560.14 727880.2 68.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e84be8f6-82bb-40ec-9ad6-ad7949774c4c_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469559.7 727878.14 68.65 469565.73 727875.3 68.65 469565.73 727875.3 74.88 469559.7 727878.14 74.88 469559.7 727878.14 68.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e84be8f6-82bb-40ec-9ad6-ad7949774c4c_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>469565.73 727875.3 74.88 469570.67 727885.86 74.88 469562.16 727889.84 74.88 469553.82 727891.27 74.88 469552.02 727881.59 74.88 469560.14 727880.2 74.88 469559.7 727878.14 74.88 469565.73 727875.3 74.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
</CityModel>
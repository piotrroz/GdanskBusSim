<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0" xmlns="http://www.opengis.net/citygml/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
			<gml:lowerCorner>493016.59 716876.36 1.08</gml:lowerCorner>
			<gml:upperCorner>493882.11 718811.46 11.75</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-50BB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-50BB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50BB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493035.95 718797.52 2.68 493036.22 718811.46 2.68 493047.27 718811.2 2.68 493048.79 718811.16 2.68 493048.46 718797.22 2.68 493035.95 718797.52 2.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50BB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493035.95 718797.52 2.68 493048.46 718797.22 2.68 493048.46 718797.22 6.47 493035.95 718797.52 6.47 493035.95 718797.52 2.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50BB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493048.46 718797.22 2.68 493048.79 718811.16 2.68 493048.79 718811.16 6.47 493048.46 718797.22 6.47 493048.46 718797.22 2.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50BB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493048.79 718811.16 2.68 493047.27 718811.2 2.68 493047.27 718811.2 6.47 493048.79 718811.16 6.47 493048.79 718811.16 2.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50BB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493047.27 718811.2 2.68 493036.22 718811.46 2.68 493036.22 718811.46 6.47 493047.27 718811.2 6.47 493047.27 718811.2 2.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50BB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493036.22 718811.46 2.68 493035.95 718797.52 2.68 493035.95 718797.52 6.47 493036.22 718811.46 6.47 493036.22 718811.46 2.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50BB-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493035.95 718797.52 6.47 493048.46 718797.22 6.47 493048.79 718811.16 6.47 493047.27 718811.2 6.47 493036.22 718811.46 6.47 493035.95 718797.52 6.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D158-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D158-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.06</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D158-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493593.31 717032.36 3.35 493602.91 717031.66 3.35 493602.43 717025.32 3.35 493592.83 717026.05 3.35 493593.31 717032.36 3.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D158-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493593.31 717032.36 3.35 493592.83 717026.05 3.35 493592.83 717026.05 7.41 493593.31 717032.36 7.41 493593.31 717032.36 3.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D158-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493592.83 717026.05 3.35 493602.43 717025.32 3.35 493602.43 717025.32 7.41 493592.83 717026.05 7.41 493592.83 717026.05 3.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D158-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493602.43 717025.32 3.35 493602.91 717031.66 3.35 493602.91 717031.66 7.41 493602.43 717025.32 7.41 493602.43 717025.32 3.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D158-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493602.91 717031.66 3.35 493593.31 717032.36 3.35 493593.31 717032.36 7.41 493602.91 717031.66 7.41 493602.91 717031.66 3.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D158-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493593.31 717032.36 7.41 493592.83 717026.05 7.41 493602.43 717025.32 7.41 493602.91 717031.66 7.41 493593.31 717032.36 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D14C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D14C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.86</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493558.04 717139.79 3.23 493550.99 717139.92 3.23 493551.32 717154.46 3.23 493558.37 717154.34 3.23 493558.04 717139.79 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493558.04 717139.79 3.23 493558.37 717154.34 3.23 493558.37 717154.34 8.09 493558.04 717139.79 8.09 493558.04 717139.79 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493558.37 717154.34 3.23 493551.32 717154.46 3.23 493551.32 717154.46 8.09 493558.37 717154.34 8.09 493558.37 717154.34 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493551.32 717154.46 3.23 493550.99 717139.92 3.23 493550.99 717139.92 8.09 493551.32 717154.46 8.09 493551.32 717154.46 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493550.99 717139.92 3.23 493558.04 717139.79 3.23 493558.04 717139.79 8.09 493550.99 717139.92 8.09 493550.99 717139.92 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493558.04 717139.79 8.09 493558.37 717154.34 8.09 493551.32 717154.46 8.09 493550.99 717139.92 8.09 493558.04 717139.79 8.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D14F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D14F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.09</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493467.63 717137.23 3.53 493484.15 717137.21 3.53 493484.19 717125.92 3.53 493467.68 717125.97 3.53 493467.63 717137.23 3.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493467.63 717137.23 3.53 493467.68 717125.97 3.53 493467.68 717125.97 10.620000000000001 493467.63 717137.23 10.620000000000001 493467.63 717137.23 3.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493467.68 717125.97 3.53 493484.19 717125.92 3.53 493484.19 717125.92 10.620000000000001 493467.68 717125.97 10.620000000000001 493467.68 717125.97 3.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493484.19 717125.92 3.53 493484.15 717137.21 3.53 493484.15 717137.21 10.620000000000001 493484.19 717125.92 10.620000000000001 493484.19 717125.92 3.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493484.15 717137.21 3.53 493467.63 717137.23 3.53 493467.63 717137.23 10.620000000000001 493484.15 717137.21 10.620000000000001 493484.15 717137.21 3.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493467.63 717137.23 10.620000000000001 493467.68 717125.97 10.620000000000001 493484.19 717125.92 10.620000000000001 493484.15 717137.21 10.620000000000001 493467.63 717137.23 10.620000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5B54-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5B54-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.03</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5B54-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493593.5 716919.04 3.97 493592.48 716910.37 3.97 493588.46 716910.81 3.97 493589.45 716919.5 3.97 493593.5 716919.04 3.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5B54-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493593.5 716919.04 3.97 493589.45 716919.5 3.97 493589.45 716919.5 7 493593.5 716919.04 7 493593.5 716919.04 3.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5B54-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493589.45 716919.5 3.97 493588.46 716910.81 3.97 493588.46 716910.81 7 493589.45 716919.5 7 493589.45 716919.5 3.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5B54-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493588.46 716910.81 3.97 493592.48 716910.37 3.97 493592.48 716910.37 7 493588.46 716910.81 7 493588.46 716910.81 3.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5B54-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493592.48 716910.37 3.97 493593.5 716919.04 3.97 493593.5 716919.04 7 493592.48 716910.37 7 493592.48 716910.37 3.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5B54-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493593.5 716919.04 7 493589.45 716919.5 7 493588.46 716910.81 7 493592.48 716910.37 7 493593.5 716919.04 7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7030-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7030-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.12</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7030-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493551.08 717015.47 3.6 493560.03 717015.53 3.6 493560.1 717011.13 3.6 493551.16 717011.08 3.6 493551.08 717015.47 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7030-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493551.08 717015.47 3.6 493551.16 717011.08 3.6 493551.16 717011.08 7.719999999999999 493551.08 717015.47 7.719999999999999 493551.08 717015.47 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7030-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493551.16 717011.08 3.6 493560.1 717011.13 3.6 493560.1 717011.13 7.719999999999999 493551.16 717011.08 7.719999999999999 493551.16 717011.08 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7030-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493560.1 717011.13 3.6 493560.03 717015.53 3.6 493560.03 717015.53 7.719999999999999 493560.1 717011.13 7.719999999999999 493560.1 717011.13 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7030-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493560.03 717015.53 3.6 493551.08 717015.47 3.6 493551.08 717015.47 7.719999999999999 493560.03 717015.53 7.719999999999999 493560.03 717015.53 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7030-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493551.08 717015.47 7.719999999999999 493551.16 717011.08 7.719999999999999 493560.1 717011.13 7.719999999999999 493560.03 717015.53 7.719999999999999 493551.08 717015.47 7.719999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-702F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-702F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.23</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493549.81 717046.39 3.44 493555.84 717046.51 3.44 493556.02 717034.39 3.44 493549.98 717034.3 3.44 493549.81 717046.39 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493549.81 717046.39 3.44 493549.98 717034.3 3.44 493549.98 717034.3 8.67 493549.81 717046.39 8.67 493549.81 717046.39 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493549.98 717034.3 3.44 493556.02 717034.39 3.44 493556.02 717034.39 8.67 493549.98 717034.3 8.67 493549.98 717034.3 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493556.02 717034.39 3.44 493555.84 717046.51 3.44 493555.84 717046.51 8.67 493556.02 717034.39 8.67 493556.02 717034.39 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493555.84 717046.51 3.44 493549.81 717046.39 3.44 493549.81 717046.39 8.67 493555.84 717046.51 8.67 493555.84 717046.51 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493549.81 717046.39 8.67 493549.98 717034.3 8.67 493556.02 717034.39 8.67 493555.84 717046.51 8.67 493549.81 717046.39 8.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-702E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-702E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493318.96 717013.51 2.64 493319.13 717022.62 2.64 493321.23 717022.57 2.64 493321.31 717024.95 2.64 493324.47 717024.89 2.64 493324.48 717022.52 2.64 493326.59 717022.49 2.64 493326.4 717013.35 2.64 493318.96 717013.51 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493318.96 717013.51 2.64 493326.4 717013.35 2.64 493326.4 717013.35 8.11 493318.96 717013.51 8.11 493318.96 717013.51 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493326.4 717013.35 2.64 493326.59 717022.49 2.64 493326.59 717022.49 8.11 493326.4 717013.35 8.11 493326.4 717013.35 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493326.59 717022.49 2.64 493324.48 717022.52 2.64 493324.48 717022.52 8.11 493326.59 717022.49 8.11 493326.59 717022.49 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493324.48 717022.52 2.64 493324.47 717024.89 2.64 493324.47 717024.89 8.11 493324.48 717022.52 8.11 493324.48 717022.52 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493324.47 717024.89 2.64 493321.31 717024.95 2.64 493321.31 717024.95 8.11 493324.47 717024.89 8.11 493324.47 717024.89 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493321.31 717024.95 2.64 493321.23 717022.57 2.64 493321.23 717022.57 8.11 493321.31 717024.95 8.11 493321.31 717024.95 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493321.23 717022.57 2.64 493319.13 717022.62 2.64 493319.13 717022.62 8.11 493321.23 717022.57 8.11 493321.23 717022.57 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493319.13 717022.62 2.64 493318.96 717013.51 2.64 493318.96 717013.51 8.11 493319.13 717022.62 8.11 493319.13 717022.62 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-702E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493318.96 717013.51 8.11 493326.4 717013.35 8.11 493326.59 717022.49 8.11 493324.48 717022.52 8.11 493324.47 717024.89 8.11 493321.31 717024.95 8.11 493321.23 717022.57 8.11 493319.13 717022.62 8.11 493318.96 717013.51 8.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6FFB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6FFB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.56</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FFB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493479.05 717103.45 4.05 493488.64 717103.45 4.05 493488.62 717101.33 4.05 493490.06 717101.29 4.05 493490.05 717096.34 4.05 493488.61 717096.35 4.05 493488.58 717090.53 4.05 493478.99 717090.55 4.05 493479.05 717103.45 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FFB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493479.05 717103.45 4.05 493478.99 717090.55 4.05 493478.99 717090.55 9.61 493479.05 717103.45 9.61 493479.05 717103.45 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FFB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493478.99 717090.55 4.05 493488.58 717090.53 4.05 493488.58 717090.53 9.61 493478.99 717090.55 9.61 493478.99 717090.55 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FFB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493488.58 717090.53 4.05 493488.61 717096.35 4.05 493488.61 717096.35 9.61 493488.58 717090.53 9.61 493488.58 717090.53 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FFB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493488.61 717096.35 4.05 493490.05 717096.34 4.05 493490.05 717096.34 9.61 493488.61 717096.35 9.61 493488.61 717096.35 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FFB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493490.05 717096.34 4.05 493490.06 717101.29 4.05 493490.06 717101.29 9.61 493490.05 717096.34 9.61 493490.05 717096.34 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FFB-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493490.06 717101.29 4.05 493488.62 717101.33 4.05 493488.62 717101.33 9.61 493490.06 717101.29 9.61 493490.06 717101.29 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FFB-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493488.62 717101.33 4.05 493488.64 717103.45 4.05 493488.64 717103.45 9.61 493488.62 717101.33 9.61 493488.62 717101.33 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FFB-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493488.64 717103.45 4.05 493479.05 717103.45 4.05 493479.05 717103.45 9.61 493488.64 717103.45 9.61 493488.64 717103.45 4.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FFB-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493479.05 717103.45 9.61 493478.99 717090.55 9.61 493488.58 717090.53 9.61 493488.61 717096.35 9.61 493490.05 717096.34 9.61 493490.06 717101.29 9.61 493488.62 717101.33 9.61 493488.64 717103.45 9.61 493479.05 717103.45 9.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CFB2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CFB2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.78</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493314.04 717118.29 4.47 493319.58 717119 4.47 493320.74 717109.88 4.47 493321.24 717109.94 4.47 493322.84 717098.63 4.47 493316.66 717097.9 4.47 493314.04 717118.29 4.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493314.04 717118.29 4.47 493316.66 717097.9 4.47 493316.66 717097.9 11.25 493314.04 717118.29 11.25 493314.04 717118.29 4.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493316.66 717097.9 4.47 493322.84 717098.63 4.47 493322.84 717098.63 11.25 493316.66 717097.9 11.25 493316.66 717097.9 4.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493322.84 717098.63 4.47 493321.24 717109.94 4.47 493321.24 717109.94 11.25 493322.84 717098.63 11.25 493322.84 717098.63 4.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493321.24 717109.94 4.47 493320.74 717109.88 4.47 493320.74 717109.88 11.25 493321.24 717109.94 11.25 493321.24 717109.94 4.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493320.74 717109.88 4.47 493319.58 717119 4.47 493319.58 717119 11.25 493320.74 717109.88 11.25 493320.74 717109.88 4.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB2-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493319.58 717119 4.47 493314.04 717118.29 4.47 493314.04 717118.29 11.25 493319.58 717119 11.25 493319.58 717119 4.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB2-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493314.04 717118.29 11.25 493316.66 717097.9 11.25 493322.84 717098.63 11.25 493321.24 717109.94 11.25 493320.74 717109.88 11.25 493319.58 717119 11.25 493314.04 717118.29 11.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CFB6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CFB6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.62</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493017.2 718758.16 1.08 493032.87 718758.01 1.08 493032.23 718721.5 1.08 493016.59 718721.65 1.08 493017.2 718758.16 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493017.2 718758.16 1.08 493016.59 718721.65 1.08 493016.59 718721.65 7.7 493017.2 718758.16 7.7 493017.2 718758.16 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493016.59 718721.65 1.08 493032.23 718721.5 1.08 493032.23 718721.5 7.7 493016.59 718721.65 7.7 493016.59 718721.65 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493032.23 718721.5 1.08 493032.87 718758.01 1.08 493032.87 718758.01 7.7 493032.23 718721.5 7.7 493032.23 718721.5 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493032.87 718758.01 1.08 493017.2 718758.16 1.08 493017.2 718758.16 7.7 493032.87 718758.01 7.7 493032.87 718758.01 1.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFB6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493017.2 718758.16 7.7 493016.59 718721.65 7.7 493032.23 718721.5 7.7 493032.87 718758.01 7.7 493017.2 718758.16 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.12</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493661.46 717057.69 3.81 493662.61 717058.95 3.81 493668.22 717065.22 3.81 493668.41 717065.05 3.81 493668.25 717064.87 3.81 493676.14 717057.76 3.81 493670.83 717051.86 3.81 493664.78 717057.17 3.81 493663.53 717055.78 3.81 493661.46 717057.69 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493661.46 717057.69 3.81 493663.53 717055.78 3.81 493663.53 717055.78 8.93 493661.46 717057.69 8.93 493661.46 717057.69 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493663.53 717055.78 3.81 493664.78 717057.17 3.81 493664.78 717057.17 8.93 493663.53 717055.78 8.93 493663.53 717055.78 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493664.78 717057.17 3.81 493670.83 717051.86 3.81 493670.83 717051.86 8.93 493664.78 717057.17 8.93 493664.78 717057.17 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493670.83 717051.86 3.81 493676.14 717057.76 3.81 493676.14 717057.76 8.93 493670.83 717051.86 8.93 493670.83 717051.86 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493676.14 717057.76 3.81 493668.25 717064.87 3.81 493668.25 717064.87 8.93 493676.14 717057.76 8.93 493676.14 717057.76 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493668.25 717064.87 3.81 493668.41 717065.05 3.81 493668.41 717065.05 8.93 493668.25 717064.87 8.93 493668.25 717064.87 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493668.41 717065.05 3.81 493668.22 717065.22 3.81 493668.22 717065.22 8.93 493668.41 717065.05 8.93 493668.41 717065.05 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493668.22 717065.22 3.81 493662.61 717058.95 3.81 493662.61 717058.95 8.93 493668.22 717065.22 8.93 493668.22 717065.22 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493662.61 717058.95 3.81 493661.46 717057.69 3.81 493661.46 717057.69 8.93 493662.61 717058.95 8.93 493662.61 717058.95 3.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD3D-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493661.46 717057.69 8.93 493663.53 717055.78 8.93 493664.78 717057.17 8.93 493670.83 717051.86 8.93 493676.14 717057.76 8.93 493668.25 717064.87 8.93 493668.41 717065.05 8.93 493668.22 717065.22 8.93 493662.61 717058.95 8.93 493661.46 717057.69 8.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC79-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC79-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.5</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC79-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493650.06 717033.8 3.55 493652.81 717036.94 3.55 493654.63 717039.01 3.55 493657.39 717042.16 3.55 493659.19 717040.55 3.55 493662.05 717043.84 3.55 493667.65 717038.92 3.55 493657.42 717027.31 3.55 493650.06 717033.8 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC79-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493650.06 717033.8 3.55 493657.42 717027.31 3.55 493657.42 717027.31 10.045 493650.06 717033.8 10.045 493650.06 717033.8 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC79-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493657.42 717027.31 3.55 493667.65 717038.92 3.55 493667.65 717038.92 10.045 493657.42 717027.31 10.045 493657.42 717027.31 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC79-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493667.65 717038.92 3.55 493662.05 717043.84 3.55 493662.05 717043.84 10.045 493667.65 717038.92 10.045 493667.65 717038.92 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC79-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493662.05 717043.84 3.55 493659.19 717040.55 3.55 493659.19 717040.55 10.045 493662.05 717043.84 10.045 493662.05 717043.84 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC79-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493659.19 717040.55 3.55 493657.39 717042.16 3.55 493657.39 717042.16 10.045 493659.19 717040.55 10.045 493659.19 717040.55 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC79-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493657.39 717042.16 3.55 493654.63 717039.01 3.55 493654.63 717039.01 10.045 493657.39 717042.16 10.045 493657.39 717042.16 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC79-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493654.63 717039.01 3.55 493652.81 717036.94 3.55 493652.81 717036.94 10.045 493654.63 717039.01 10.045 493654.63 717039.01 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC79-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493652.81 717036.94 3.55 493650.06 717033.8 3.55 493650.06 717033.8 10.045 493652.81 717036.94 10.045 493652.81 717036.94 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC79-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493650.06 717033.8 10.045 493657.42 717027.31 10.045 493667.65 717038.92 10.045 493662.05 717043.84 10.045 493659.19 717040.55 10.045 493657.39 717042.16 10.045 493654.63 717039.01 10.045 493652.81 717036.94 10.045 493650.06 717033.8 10.045</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.54</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493604.88 716884.54 3.78 493603.99 716880.47 3.78 493601.8 716880.87 3.78 493589.5 716883.43 3.78 493591.22 716891.57 3.78 493595.69 716890.61 3.78 493596.13 716892.67 3.78 493599.47 716891.97 3.78 493599.07 716889.89 3.78 493603.53 716888.93 3.78 493602.69 716885.04 3.78 493604.88 716884.54 3.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493604.88 716884.54 3.78 493602.69 716885.04 3.78 493602.69 716885.04 10.32 493604.88 716884.54 10.32 493604.88 716884.54 3.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493602.69 716885.04 3.78 493603.53 716888.93 3.78 493603.53 716888.93 10.32 493602.69 716885.04 10.32 493602.69 716885.04 3.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493603.53 716888.93 3.78 493599.07 716889.89 3.78 493599.07 716889.89 10.32 493603.53 716888.93 10.32 493603.53 716888.93 3.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493599.07 716889.89 3.78 493599.47 716891.97 3.78 493599.47 716891.97 10.32 493599.07 716889.89 10.32 493599.07 716889.89 3.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493599.47 716891.97 3.78 493596.13 716892.67 3.78 493596.13 716892.67 10.32 493599.47 716891.97 10.32 493599.47 716891.97 3.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493596.13 716892.67 3.78 493595.69 716890.61 3.78 493595.69 716890.61 10.32 493596.13 716892.67 10.32 493596.13 716892.67 3.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493595.69 716890.61 3.78 493591.22 716891.57 3.78 493591.22 716891.57 10.32 493595.69 716890.61 10.32 493595.69 716890.61 3.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493591.22 716891.57 3.78 493589.5 716883.43 3.78 493589.5 716883.43 10.32 493591.22 716891.57 10.32 493591.22 716891.57 3.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493589.5 716883.43 3.78 493601.8 716880.87 3.78 493601.8 716880.87 10.32 493589.5 716883.43 10.32 493589.5 716883.43 3.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493601.8 716880.87 3.78 493603.99 716880.47 3.78 493603.99 716880.47 10.32 493601.8 716880.87 10.32 493601.8 716880.87 3.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493603.99 716880.47 3.78 493604.88 716884.54 3.78 493604.88 716884.54 10.32 493603.99 716880.47 10.32 493603.99 716880.47 3.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC77-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493604.88 716884.54 10.32 493602.69 716885.04 10.32 493603.53 716888.93 10.32 493599.07 716889.89 10.32 493599.47 716891.97 10.32 493596.13 716892.67 10.32 493595.69 716890.61 10.32 493591.22 716891.57 10.32 493589.5 716883.43 10.32 493601.8 716880.87 10.32 493603.99 716880.47 10.32 493604.88 716884.54 10.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.01</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493636.48 716888.53 4.12 493637.5 716892.16 4.12 493640.35 716891.45 4.12 493641.26 716894.52 4.12 493643.68 716893.79 4.12 493644.22 716895.54 4.12 493646.9 716894.73 4.12 493646.38 716892.98 4.12 493652.1 716891.26 4.12 493649.34 716881.89 4.12 493638.45 716884.88 4.12 493639.32 716887.89 4.12 493636.48 716888.53 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493636.48 716888.53 4.12 493639.32 716887.89 4.12 493639.32 716887.89 10.13 493636.48 716888.53 10.13 493636.48 716888.53 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493639.32 716887.89 4.12 493638.45 716884.88 4.12 493638.45 716884.88 10.13 493639.32 716887.89 10.13 493639.32 716887.89 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493638.45 716884.88 4.12 493649.34 716881.89 4.12 493649.34 716881.89 10.13 493638.45 716884.88 10.13 493638.45 716884.88 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493649.34 716881.89 4.12 493652.1 716891.26 4.12 493652.1 716891.26 10.13 493649.34 716881.89 10.13 493649.34 716881.89 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493652.1 716891.26 4.12 493646.38 716892.98 4.12 493646.38 716892.98 10.13 493652.1 716891.26 10.13 493652.1 716891.26 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493646.38 716892.98 4.12 493646.9 716894.73 4.12 493646.9 716894.73 10.13 493646.38 716892.98 10.13 493646.38 716892.98 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493646.9 716894.73 4.12 493644.22 716895.54 4.12 493644.22 716895.54 10.13 493646.9 716894.73 10.13 493646.9 716894.73 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493644.22 716895.54 4.12 493643.68 716893.79 4.12 493643.68 716893.79 10.13 493644.22 716895.54 10.13 493644.22 716895.54 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493643.68 716893.79 4.12 493641.26 716894.52 4.12 493641.26 716894.52 10.13 493643.68 716893.79 10.13 493643.68 716893.79 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493641.26 716894.52 4.12 493640.35 716891.45 4.12 493640.35 716891.45 10.13 493641.26 716894.52 10.13 493641.26 716894.52 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493640.35 716891.45 4.12 493637.5 716892.16 4.12 493637.5 716892.16 10.13 493640.35 716891.45 10.13 493640.35 716891.45 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493637.5 716892.16 4.12 493636.48 716888.53 4.12 493636.48 716888.53 10.13 493637.5 716892.16 10.13 493637.5 716892.16 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DC-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493636.48 716888.53 10.13 493639.32 716887.89 10.13 493638.45 716884.88 10.13 493649.34 716881.89 10.13 493652.1 716891.26 10.13 493646.38 716892.98 10.13 493646.9 716894.73 10.13 493644.22 716895.54 10.13 493643.68 716893.79 10.13 493641.26 716894.52 10.13 493640.35 716891.45 10.13 493637.5 716892.16 10.13 493636.48 716888.53 10.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493649.44 717068.38 3.48 493657.26 717077.41 3.48 493659.91 717075.15 3.48 493659.32 717074.42 3.48 493668.7 717065.72 3.48 493668.22 717065.22 3.48 493662.61 717058.95 3.48 493655.7 717065.28 3.48 493655.85 717065.45 3.48 493653.33 717067.66 3.48 493652.14 717066.26 3.48 493649.44 717068.38 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493649.44 717068.38 3.48 493652.14 717066.26 3.48 493652.14 717066.26 8.47 493649.44 717068.38 8.47 493649.44 717068.38 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493652.14 717066.26 3.48 493653.33 717067.66 3.48 493653.33 717067.66 8.47 493652.14 717066.26 8.47 493652.14 717066.26 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493653.33 717067.66 3.48 493655.85 717065.45 3.48 493655.85 717065.45 8.47 493653.33 717067.66 8.47 493653.33 717067.66 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493655.85 717065.45 3.48 493655.7 717065.28 3.48 493655.7 717065.28 8.47 493655.85 717065.45 8.47 493655.85 717065.45 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493655.7 717065.28 3.48 493662.61 717058.95 3.48 493662.61 717058.95 8.47 493655.7 717065.28 8.47 493655.7 717065.28 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493662.61 717058.95 3.48 493668.22 717065.22 3.48 493668.22 717065.22 8.47 493662.61 717058.95 8.47 493662.61 717058.95 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493668.22 717065.22 3.48 493668.7 717065.72 3.48 493668.7 717065.72 8.47 493668.22 717065.22 8.47 493668.22 717065.22 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493668.7 717065.72 3.48 493659.32 717074.42 3.48 493659.32 717074.42 8.47 493668.7 717065.72 8.47 493668.7 717065.72 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493659.32 717074.42 3.48 493659.91 717075.15 3.48 493659.91 717075.15 8.47 493659.32 717074.42 8.47 493659.32 717074.42 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493659.91 717075.15 3.48 493657.26 717077.41 3.48 493657.26 717077.41 8.47 493659.91 717075.15 8.47 493659.91 717075.15 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493657.26 717077.41 3.48 493649.44 717068.38 3.48 493649.44 717068.38 8.47 493657.26 717077.41 8.47 493657.26 717077.41 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DB-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493649.44 717068.38 8.47 493652.14 717066.26 8.47 493653.33 717067.66 8.47 493655.85 717065.45 8.47 493655.7 717065.28 8.47 493662.61 717058.95 8.47 493668.22 717065.22 8.47 493668.7 717065.72 8.47 493659.32 717074.42 8.47 493659.91 717075.15 8.47 493657.26 717077.41 8.47 493649.44 717068.38 8.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-71DA-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-71DA-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.25</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DA-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493507.76 717106.85 4.27 493512.76 717106.96 4.27 493512.77 717103.02 4.27 493520.99 717103.04 4.27 493521.01 717113.06 4.27 493529.69 717113.07 4.27 493529.59 717090.91 4.27 493507.92 717090.72 4.27 493507.76 717106.85 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DA-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493507.76 717106.85 4.27 493507.92 717090.72 4.27 493507.92 717090.72 10.52 493507.76 717106.85 10.52 493507.76 717106.85 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DA-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493507.92 717090.72 4.27 493529.59 717090.91 4.27 493529.59 717090.91 10.52 493507.92 717090.72 10.52 493507.92 717090.72 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DA-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493529.59 717090.91 4.27 493529.69 717113.07 4.27 493529.69 717113.07 10.52 493529.59 717090.91 10.52 493529.59 717090.91 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DA-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493529.69 717113.07 4.27 493521.01 717113.06 4.27 493521.01 717113.06 10.52 493529.69 717113.07 10.52 493529.69 717113.07 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DA-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493521.01 717113.06 4.27 493520.99 717103.04 4.27 493520.99 717103.04 10.52 493521.01 717113.06 10.52 493521.01 717113.06 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DA-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493520.99 717103.04 4.27 493512.77 717103.02 4.27 493512.77 717103.02 10.52 493520.99 717103.04 10.52 493520.99 717103.04 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DA-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493512.77 717103.02 4.27 493512.76 717106.96 4.27 493512.76 717106.96 10.52 493512.77 717103.02 10.52 493512.77 717103.02 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DA-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493512.76 717106.96 4.27 493507.76 717106.85 4.27 493507.76 717106.85 10.52 493512.76 717106.96 10.52 493512.76 717106.96 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DA-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493507.76 717106.85 10.52 493507.92 717090.72 10.52 493529.59 717090.91 10.52 493529.69 717113.07 10.52 493521.01 717113.06 10.52 493520.99 717103.04 10.52 493512.77 717103.02 10.52 493512.76 717106.96 10.52 493507.76 717106.85 10.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0797-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0797-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0797-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493307.81 717038.46 3.24 493308.53 717047.68 3.24 493312.87 717047.35 3.24 493313.13 717050.48 3.24 493316.76 717050.18 3.24 493316.62 717046.95 3.24 493318.7 717046.87 3.24 493317.93 717037.67 3.24 493307.81 717038.46 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0797-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493307.81 717038.46 3.24 493317.93 717037.67 3.24 493317.93 717037.67 9.56 493307.81 717038.46 9.56 493307.81 717038.46 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0797-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493317.93 717037.67 3.24 493318.7 717046.87 3.24 493318.7 717046.87 9.56 493317.93 717037.67 9.56 493317.93 717037.67 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0797-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493318.7 717046.87 3.24 493316.62 717046.95 3.24 493316.62 717046.95 9.56 493318.7 717046.87 9.56 493318.7 717046.87 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0797-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493316.62 717046.95 3.24 493316.76 717050.18 3.24 493316.76 717050.18 9.56 493316.62 717046.95 9.56 493316.62 717046.95 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0797-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493316.76 717050.18 3.24 493313.13 717050.48 3.24 493313.13 717050.48 9.56 493316.76 717050.18 9.56 493316.76 717050.18 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0797-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493313.13 717050.48 3.24 493312.87 717047.35 3.24 493312.87 717047.35 9.56 493313.13 717050.48 9.56 493313.13 717050.48 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0797-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493312.87 717047.35 3.24 493308.53 717047.68 3.24 493308.53 717047.68 9.56 493312.87 717047.35 9.56 493312.87 717047.35 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0797-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493308.53 717047.68 3.24 493307.81 717038.46 3.24 493307.81 717038.46 9.56 493308.53 717047.68 9.56 493308.53 717047.68 3.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0797-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493307.81 717038.46 9.56 493317.93 717037.67 9.56 493318.7 717046.87 9.56 493316.62 717046.95 9.56 493316.76 717050.18 9.56 493313.13 717050.48 9.56 493312.87 717047.35 9.56 493308.53 717047.68 9.56 493307.81 717038.46 9.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D156-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D156-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.14</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D156-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493551.82 716880.01 3.6 493551.64 716883.54 3.6 493554.71 716883.64 3.6 493554.23 716901.76 3.6 493550.99 716901.7 3.6 493550.9 716906.73 3.6 493562.27 716907.12 3.6 493563.13 716880.39 3.6 493551.82 716880.01 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D156-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493551.82 716880.01 3.6 493563.13 716880.39 3.6 493563.13 716880.39 7.74 493551.82 716880.01 7.74 493551.82 716880.01 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D156-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493563.13 716880.39 3.6 493562.27 716907.12 3.6 493562.27 716907.12 7.74 493563.13 716880.39 7.74 493563.13 716880.39 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D156-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493562.27 716907.12 3.6 493550.9 716906.73 3.6 493550.9 716906.73 7.74 493562.27 716907.12 7.74 493562.27 716907.12 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D156-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493550.9 716906.73 3.6 493550.99 716901.7 3.6 493550.99 716901.7 7.74 493550.9 716906.73 7.74 493550.9 716906.73 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D156-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493550.99 716901.7 3.6 493554.23 716901.76 3.6 493554.23 716901.76 7.74 493550.99 716901.7 7.74 493550.99 716901.7 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D156-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493554.23 716901.76 3.6 493554.71 716883.64 3.6 493554.71 716883.64 7.74 493554.23 716901.76 7.74 493554.23 716901.76 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D156-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493554.71 716883.64 3.6 493551.64 716883.54 3.6 493551.64 716883.54 7.74 493554.71 716883.64 7.74 493554.71 716883.64 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D156-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493551.64 716883.54 3.6 493551.82 716880.01 3.6 493551.82 716880.01 7.74 493551.64 716883.54 7.74 493551.64 716883.54 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D156-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493551.82 716880.01 7.74 493563.13 716880.39 7.74 493562.27 716907.12 7.74 493550.9 716906.73 7.74 493550.99 716901.7 7.74 493554.23 716901.76 7.74 493554.71 716883.64 7.74 493551.64 716883.54 7.74 493551.82 716880.01 7.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D157-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D157-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.51</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D157-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493669.92 717090.68 3.1 493674.62 717096.31 3.1 493687.86 717085.35 3.1 493683.2 717079.79 3.1 493669.92 717090.68 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D157-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493669.92 717090.68 3.1 493683.2 717079.79 3.1 493683.2 717079.79 8.61 493669.92 717090.68 8.61 493669.92 717090.68 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D157-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493683.2 717079.79 3.1 493687.86 717085.35 3.1 493687.86 717085.35 8.61 493683.2 717079.79 8.61 493683.2 717079.79 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D157-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493687.86 717085.35 3.1 493674.62 717096.31 3.1 493674.62 717096.31 8.61 493687.86 717085.35 8.61 493687.86 717085.35 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D157-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493674.62 717096.31 3.1 493669.92 717090.68 3.1 493669.92 717090.68 8.61 493674.62 717096.31 8.61 493674.62 717096.31 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D157-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493669.92 717090.68 8.61 493683.2 717079.79 8.61 493687.86 717085.35 8.61 493674.62 717096.31 8.61 493669.92 717090.68 8.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D153-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D153-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.88</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D153-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493514.66 717034.13 3.48 493520.75 717034.08 3.48 493520.59 717021.41 3.48 493514.51 717021.5 3.48 493514.66 717034.13 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D153-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493514.66 717034.13 3.48 493514.51 717021.5 3.48 493514.51 717021.5 7.36 493514.66 717034.13 7.36 493514.66 717034.13 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D153-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493514.51 717021.5 3.48 493520.59 717021.41 3.48 493520.59 717021.41 7.36 493514.51 717021.5 7.36 493514.51 717021.5 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D153-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493520.59 717021.41 3.48 493520.75 717034.08 3.48 493520.75 717034.08 7.36 493520.59 717021.41 7.36 493520.59 717021.41 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D153-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493520.75 717034.08 3.48 493514.66 717034.13 3.48 493514.66 717034.13 7.36 493520.75 717034.08 7.36 493520.75 717034.08 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D153-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493514.66 717034.13 7.36 493514.51 717021.5 7.36 493520.59 717021.41 7.36 493520.75 717034.08 7.36 493514.66 717034.13 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D152-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D152-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.92</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D152-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493538.2 716987.76 3.57 493538.31 716982.92 3.57 493526.22 716982.72 3.57 493526.15 716987.61 3.57 493538.2 716987.76 3.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D152-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493538.2 716987.76 3.57 493526.15 716987.61 3.57 493526.15 716987.61 7.49 493538.2 716987.76 7.49 493538.2 716987.76 3.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D152-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493526.15 716987.61 3.57 493526.22 716982.72 3.57 493526.22 716982.72 7.49 493526.15 716987.61 7.49 493526.15 716987.61 3.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D152-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493526.22 716982.72 3.57 493538.31 716982.92 3.57 493538.31 716982.92 7.49 493526.22 716982.72 7.49 493526.22 716982.72 3.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D152-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493538.31 716982.92 3.57 493538.2 716987.76 3.57 493538.2 716987.76 7.49 493538.31 716982.92 7.49 493538.31 716982.92 3.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D152-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493538.2 716987.76 7.49 493526.15 716987.61 7.49 493526.22 716982.72 7.49 493538.31 716982.92 7.49 493538.2 716987.76 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-4224be47-2a96-4b4a-ab1d-a1fbf8b23611">
			<gen:stringAttribute name="buildingId">
				<gen:value>4224be47-2a96-4b4a-ab1d-a1fbf8b23611</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4224be47-2a96-4b4a-ab1d-a1fbf8b23611_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493467.64 717143.11 3.65 493484.16 717143.11 3.65 493484.15 717137.21 3.65 493467.63 717137.23 3.65 493467.64 717143.11 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4224be47-2a96-4b4a-ab1d-a1fbf8b23611_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493467.64 717143.11 3.65 493467.63 717137.23 3.65 493467.63 717137.23 10.65 493467.64 717143.11 10.65 493467.64 717143.11 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4224be47-2a96-4b4a-ab1d-a1fbf8b23611_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493467.63 717137.23 3.65 493484.15 717137.21 3.65 493484.15 717137.21 10.65 493467.63 717137.23 10.65 493467.63 717137.23 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4224be47-2a96-4b4a-ab1d-a1fbf8b23611_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493484.15 717137.21 3.65 493484.16 717143.11 3.65 493484.16 717143.11 10.65 493484.15 717137.21 10.65 493484.15 717137.21 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4224be47-2a96-4b4a-ab1d-a1fbf8b23611_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493484.16 717143.11 3.65 493467.64 717143.11 3.65 493467.64 717143.11 10.65 493484.16 717143.11 10.65 493484.16 717143.11 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-4224be47-2a96-4b4a-ab1d-a1fbf8b23611_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493467.64 717143.11 10.65 493467.63 717137.23 10.65 493484.15 717137.21 10.65 493484.16 717143.11 10.65 493467.64 717143.11 10.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71">
			<gen:stringAttribute name="buildingId">
				<gen:value>9f371ac1-33fb-4f3d-b00a-f7560eef6a71</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.51</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493607.03 717084.78 3.48 493608 717088.68 3.48 493607.16 717088.87 3.48 493608.43 717094.06 3.48 493609.27 717093.87 3.48 493610.21 717097.67 3.48 493610.5 717097.59 3.48 493611.5 717101.57 3.48 493621.29 717099.16 3.48 493620.35 717095.14 3.48 493620.62 717095.06 3.48 493619.62 717091.12 3.48 493621.41 717090.67 3.48 493619.23 717081.8 3.48 493614.11 717083.06 3.48 493613.89 717082.13 3.48 493612.65 717081.33 3.48 493611.09 717081.71 3.48 493610.41 717083.03 3.48 493610.61 717083.91 3.48 493607.03 717084.78 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493607.03 717084.78 3.48 493610.61 717083.91 3.48 493610.61 717083.91 9.99 493607.03 717084.78 9.99 493607.03 717084.78 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493610.61 717083.91 3.48 493610.41 717083.03 3.48 493610.41 717083.03 9.99 493610.61 717083.91 9.99 493610.61 717083.91 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493610.41 717083.03 3.48 493611.09 717081.71 3.48 493611.09 717081.71 9.99 493610.41 717083.03 9.99 493610.41 717083.03 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493611.09 717081.71 3.48 493612.65 717081.33 3.48 493612.65 717081.33 9.99 493611.09 717081.71 9.99 493611.09 717081.71 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493612.65 717081.33 3.48 493613.89 717082.13 3.48 493613.89 717082.13 9.99 493612.65 717081.33 9.99 493612.65 717081.33 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493613.89 717082.13 3.48 493614.11 717083.06 3.48 493614.11 717083.06 9.99 493613.89 717082.13 9.99 493613.89 717082.13 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493614.11 717083.06 3.48 493619.23 717081.8 3.48 493619.23 717081.8 9.99 493614.11 717083.06 9.99 493614.11 717083.06 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493619.23 717081.8 3.48 493621.41 717090.67 3.48 493621.41 717090.67 9.99 493619.23 717081.8 9.99 493619.23 717081.8 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493621.41 717090.67 3.48 493619.62 717091.12 3.48 493619.62 717091.12 9.99 493621.41 717090.67 9.99 493621.41 717090.67 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493619.62 717091.12 3.48 493620.62 717095.06 3.48 493620.62 717095.06 9.99 493619.62 717091.12 9.99 493619.62 717091.12 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493620.62 717095.06 3.48 493620.35 717095.14 3.48 493620.35 717095.14 9.99 493620.62 717095.06 9.99 493620.62 717095.06 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493620.35 717095.14 3.48 493621.29 717099.16 3.48 493621.29 717099.16 9.99 493620.35 717095.14 9.99 493620.35 717095.14 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493621.29 717099.16 3.48 493611.5 717101.57 3.48 493611.5 717101.57 9.99 493621.29 717099.16 9.99 493621.29 717099.16 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493611.5 717101.57 3.48 493610.5 717097.59 3.48 493610.5 717097.59 9.99 493611.5 717101.57 9.99 493611.5 717101.57 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493610.5 717097.59 3.48 493610.21 717097.67 3.48 493610.21 717097.67 9.99 493610.5 717097.59 9.99 493610.5 717097.59 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493610.21 717097.67 3.48 493609.27 717093.87 3.48 493609.27 717093.87 9.99 493610.21 717097.67 9.99 493610.21 717097.67 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493609.27 717093.87 3.48 493608.43 717094.06 3.48 493608.43 717094.06 9.99 493609.27 717093.87 9.99 493609.27 717093.87 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493608.43 717094.06 3.48 493607.16 717088.87 3.48 493607.16 717088.87 9.99 493608.43 717094.06 9.99 493608.43 717094.06 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493607.16 717088.87 3.48 493608 717088.68 3.48 493608 717088.68 9.99 493607.16 717088.87 9.99 493607.16 717088.87 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493608 717088.68 3.48 493607.03 717084.78 3.48 493607.03 717084.78 9.99 493608 717088.68 9.99 493608 717088.68 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-9f371ac1-33fb-4f3d-b00a-f7560eef6a71_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493607.03 717084.78 9.99 493610.61 717083.91 9.99 493610.41 717083.03 9.99 493611.09 717081.71 9.99 493612.65 717081.33 9.99 493613.89 717082.13 9.99 493614.11 717083.06 9.99 493619.23 717081.8 9.99 493621.41 717090.67 9.99 493619.62 717091.12 9.99 493620.62 717095.06 9.99 493620.35 717095.14 9.99 493621.29 717099.16 9.99 493611.5 717101.57 9.99 493610.5 717097.59 9.99 493610.21 717097.67 9.99 493609.27 717093.87 9.99 493608.43 717094.06 9.99 493607.16 717088.87 9.99 493608 717088.68 9.99 493607.03 717084.78 9.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81">
			<gen:stringAttribute name="buildingId">
				<gen:value>3d52959a-e268-43fe-811a-bda4febfaf81</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.37</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493314.44 717079.36 3.77 493317.07 717079.77 3.77 493316.73 717081.92 3.77 493319.59 717082.42 3.77 493320.03 717080.22 3.77 493323.97 717080.85 3.77 493324.72 717076.11 3.77 493325.66 717076.27 3.77 493326.08 717073.62 3.77 493326.46 717073.68 3.77 493327.18 717068.39 3.77 493324.18 717067.94 3.77 493323.85 717070.08 3.77 493316.03 717068.9 3.77 493314.44 717079.36 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493314.44 717079.36 3.77 493316.03 717068.9 3.77 493316.03 717068.9 10.14 493314.44 717079.36 10.14 493314.44 717079.36 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493316.03 717068.9 3.77 493323.85 717070.08 3.77 493323.85 717070.08 10.14 493316.03 717068.9 10.14 493316.03 717068.9 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493323.85 717070.08 3.77 493324.18 717067.94 3.77 493324.18 717067.94 10.14 493323.85 717070.08 10.14 493323.85 717070.08 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493324.18 717067.94 3.77 493327.18 717068.39 3.77 493327.18 717068.39 10.14 493324.18 717067.94 10.14 493324.18 717067.94 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493327.18 717068.39 3.77 493326.46 717073.68 3.77 493326.46 717073.68 10.14 493327.18 717068.39 10.14 493327.18 717068.39 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493326.46 717073.68 3.77 493326.08 717073.62 3.77 493326.08 717073.62 10.14 493326.46 717073.68 10.14 493326.46 717073.68 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493326.08 717073.62 3.77 493325.66 717076.27 3.77 493325.66 717076.27 10.14 493326.08 717073.62 10.14 493326.08 717073.62 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493325.66 717076.27 3.77 493324.72 717076.11 3.77 493324.72 717076.11 10.14 493325.66 717076.27 10.14 493325.66 717076.27 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493324.72 717076.11 3.77 493323.97 717080.85 3.77 493323.97 717080.85 10.14 493324.72 717076.11 10.14 493324.72 717076.11 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493323.97 717080.85 3.77 493320.03 717080.22 3.77 493320.03 717080.22 10.14 493323.97 717080.85 10.14 493323.97 717080.85 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493320.03 717080.22 3.77 493319.59 717082.42 3.77 493319.59 717082.42 10.14 493320.03 717080.22 10.14 493320.03 717080.22 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493319.59 717082.42 3.77 493316.73 717081.92 3.77 493316.73 717081.92 10.14 493319.59 717082.42 10.14 493319.59 717082.42 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493316.73 717081.92 3.77 493317.07 717079.77 3.77 493317.07 717079.77 10.14 493316.73 717081.92 10.14 493316.73 717081.92 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493317.07 717079.77 3.77 493314.44 717079.36 3.77 493314.44 717079.36 10.14 493317.07 717079.77 10.14 493317.07 717079.77 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3d52959a-e268-43fe-811a-bda4febfaf81_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493314.44 717079.36 10.14 493316.03 717068.9 10.14 493323.85 717070.08 10.14 493324.18 717067.94 10.14 493327.18 717068.39 10.14 493326.46 717073.68 10.14 493326.08 717073.62 10.14 493325.66 717076.27 10.14 493324.72 717076.11 10.14 493323.97 717080.85 10.14 493320.03 717080.22 10.14 493319.59 717082.42 10.14 493316.73 717081.92 10.14 493317.07 717079.77 10.14 493314.44 717079.36 10.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-f7ab7d1a-c30e-44ac-9e89-4bbccd9ba95e">
			<gen:stringAttribute name="buildingId">
				<gen:value>f7ab7d1a-c30e-44ac-9e89-4bbccd9ba95e</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.52</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7ab7d1a-c30e-44ac-9e89-4bbccd9ba95e_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493692.12 717050.63 3.21 493684.5 717057.17 3.21 493704.11 717080.08 3.21 493711.74 717073.56 3.21 493692.12 717050.63 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7ab7d1a-c30e-44ac-9e89-4bbccd9ba95e_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493692.12 717050.63 3.21 493711.74 717073.56 3.21 493711.74 717073.56 8.73 493692.12 717050.63 8.73 493692.12 717050.63 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7ab7d1a-c30e-44ac-9e89-4bbccd9ba95e_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493711.74 717073.56 3.21 493704.11 717080.08 3.21 493704.11 717080.08 8.73 493711.74 717073.56 8.73 493711.74 717073.56 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7ab7d1a-c30e-44ac-9e89-4bbccd9ba95e_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493704.11 717080.08 3.21 493684.5 717057.17 3.21 493684.5 717057.17 8.73 493704.11 717080.08 8.73 493704.11 717080.08 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7ab7d1a-c30e-44ac-9e89-4bbccd9ba95e_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493684.5 717057.17 3.21 493692.12 717050.63 3.21 493692.12 717050.63 8.73 493684.5 717057.17 8.73 493684.5 717057.17 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f7ab7d1a-c30e-44ac-9e89-4bbccd9ba95e_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493692.12 717050.63 8.73 493711.74 717073.56 8.73 493704.11 717080.08 8.73 493684.5 717057.17 8.73 493692.12 717050.63 8.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-fde21889-a52b-4abe-b99d-3413b6e88049">
			<gen:stringAttribute name="buildingId">
				<gen:value>fde21889-a52b-4abe-b99d-3413b6e88049</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.35</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fde21889-a52b-4abe-b99d-3413b6e88049_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493546.58 717091.78 3.77 493546.43 717101.6 3.77 493552.56 717101.57 3.77 493552.68 717091.82 3.77 493546.58 717091.78 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fde21889-a52b-4abe-b99d-3413b6e88049_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493546.58 717091.78 3.77 493552.68 717091.82 3.77 493552.68 717091.82 9.120000000000001 493546.58 717091.78 9.120000000000001 493546.58 717091.78 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fde21889-a52b-4abe-b99d-3413b6e88049_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493552.68 717091.82 3.77 493552.56 717101.57 3.77 493552.56 717101.57 9.120000000000001 493552.68 717091.82 9.120000000000001 493552.68 717091.82 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fde21889-a52b-4abe-b99d-3413b6e88049_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493552.56 717101.57 3.77 493546.43 717101.6 3.77 493546.43 717101.6 9.120000000000001 493552.56 717101.57 9.120000000000001 493552.56 717101.57 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fde21889-a52b-4abe-b99d-3413b6e88049_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493546.43 717101.6 3.77 493546.58 717091.78 3.77 493546.58 717091.78 9.120000000000001 493546.43 717101.6 9.120000000000001 493546.43 717101.6 3.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-fde21889-a52b-4abe-b99d-3413b6e88049_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493546.58 717091.78 9.120000000000001 493552.68 717091.82 9.120000000000001 493552.56 717101.57 9.120000000000001 493546.43 717101.6 9.120000000000001 493546.58 717091.78 9.120000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-2eaf3641-ea83-4d51-8f89-b74e7a1f6f30">
			<gen:stringAttribute name="buildingId">
				<gen:value>2eaf3641-ea83-4d51-8f89-b74e7a1f6f30</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2eaf3641-ea83-4d51-8f89-b74e7a1f6f30_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493615.34 716886.37 3.4 493613.23 716876.36 3.4 493608.03 716877.55 3.4 493608.45 716879.52 3.4 493610.27 716887.43 3.4 493615.34 716886.37 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2eaf3641-ea83-4d51-8f89-b74e7a1f6f30_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493615.34 716886.37 3.4 493610.27 716887.43 3.4 493610.27 716887.43 6.03 493615.34 716886.37 6.03 493615.34 716886.37 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2eaf3641-ea83-4d51-8f89-b74e7a1f6f30_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493610.27 716887.43 3.4 493608.45 716879.52 3.4 493608.45 716879.52 6.03 493610.27 716887.43 6.03 493610.27 716887.43 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2eaf3641-ea83-4d51-8f89-b74e7a1f6f30_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493608.45 716879.52 3.4 493608.03 716877.55 3.4 493608.03 716877.55 6.03 493608.45 716879.52 6.03 493608.45 716879.52 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2eaf3641-ea83-4d51-8f89-b74e7a1f6f30_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493608.03 716877.55 3.4 493613.23 716876.36 3.4 493613.23 716876.36 6.03 493608.03 716877.55 6.03 493608.03 716877.55 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2eaf3641-ea83-4d51-8f89-b74e7a1f6f30_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493613.23 716876.36 3.4 493615.34 716886.37 3.4 493615.34 716886.37 6.03 493613.23 716876.36 6.03 493613.23 716876.36 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2eaf3641-ea83-4d51-8f89-b74e7a1f6f30_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493615.34 716886.37 6.03 493610.27 716887.43 6.03 493608.45 716879.52 6.03 493608.03 716877.55 6.03 493613.23 716876.36 6.03 493615.34 716886.37 6.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-59BF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-59BF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.75</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59BF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493319.58 717119 4.36 493330.83 717120.43 4.36 493332.25 717107.18 4.36 493326.58 717106.45 4.36 493327.62 717099.29 4.36 493322.84 717098.63 4.36 493321.24 717109.94 4.36 493320.74 717109.88 4.36 493319.58 717119 4.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59BF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493319.58 717119 4.36 493320.74 717109.88 4.36 493320.74 717109.88 11.11 493319.58 717119 11.11 493319.58 717119 4.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59BF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493320.74 717109.88 4.36 493321.24 717109.94 4.36 493321.24 717109.94 11.11 493320.74 717109.88 11.11 493320.74 717109.88 4.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59BF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493321.24 717109.94 4.36 493322.84 717098.63 4.36 493322.84 717098.63 11.11 493321.24 717109.94 11.11 493321.24 717109.94 4.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59BF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493322.84 717098.63 4.36 493327.62 717099.29 4.36 493327.62 717099.29 11.11 493322.84 717098.63 11.11 493322.84 717098.63 4.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59BF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493327.62 717099.29 4.36 493326.58 717106.45 4.36 493326.58 717106.45 11.11 493327.62 717099.29 11.11 493327.62 717099.29 4.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59BF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493326.58 717106.45 4.36 493332.25 717107.18 4.36 493332.25 717107.18 11.11 493326.58 717106.45 11.11 493326.58 717106.45 4.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59BF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493332.25 717107.18 4.36 493330.83 717120.43 4.36 493330.83 717120.43 11.11 493332.25 717107.18 11.11 493332.25 717107.18 4.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59BF-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493330.83 717120.43 4.36 493319.58 717119 4.36 493319.58 717119 11.11 493330.83 717120.43 11.11 493330.83 717120.43 4.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-59BF-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493319.58 717119 11.11 493320.74 717109.88 11.11 493321.24 717109.94 11.11 493322.84 717098.63 11.11 493327.62 717099.29 11.11 493326.58 717106.45 11.11 493332.25 717107.18 11.11 493330.83 717120.43 11.11 493319.58 717119 11.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC76-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC76-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.08</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC76-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493605.29 717022.3 3.49 493613.02 717021.82 3.49 493612.21 717008.82 3.49 493604.49 717009.3 3.49 493604.72 717013.15 3.49 493602.52 717013.28 3.49 493602.7 717016.14 3.49 493604.9 717016 3.49 493605.29 717022.3 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC76-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493605.29 717022.3 3.49 493604.9 717016 3.49 493604.9 717016 9.57 493605.29 717022.3 9.57 493605.29 717022.3 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC76-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493604.9 717016 3.49 493602.7 717016.14 3.49 493602.7 717016.14 9.57 493604.9 717016 9.57 493604.9 717016 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC76-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493602.7 717016.14 3.49 493602.52 717013.28 3.49 493602.52 717013.28 9.57 493602.7 717016.14 9.57 493602.7 717016.14 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC76-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493602.52 717013.28 3.49 493604.72 717013.15 3.49 493604.72 717013.15 9.57 493602.52 717013.28 9.57 493602.52 717013.28 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC76-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493604.72 717013.15 3.49 493604.49 717009.3 3.49 493604.49 717009.3 9.57 493604.72 717013.15 9.57 493604.72 717013.15 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC76-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493604.49 717009.3 3.49 493612.21 717008.82 3.49 493612.21 717008.82 9.57 493604.49 717009.3 9.57 493604.49 717009.3 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC76-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493612.21 717008.82 3.49 493613.02 717021.82 3.49 493613.02 717021.82 9.57 493612.21 717008.82 9.57 493612.21 717008.82 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC76-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493613.02 717021.82 3.49 493605.29 717022.3 3.49 493605.29 717022.3 9.57 493613.02 717021.82 9.57 493613.02 717021.82 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC76-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493605.29 717022.3 9.57 493604.9 717016 9.57 493602.7 717016.14 9.57 493602.52 717013.28 9.57 493604.72 717013.15 9.57 493604.49 717009.3 9.57 493612.21 717008.82 9.57 493613.02 717021.82 9.57 493605.29 717022.3 9.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC74-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC74-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.73</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC74-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493595.84 716918.78 3.63 493596.02 716920.45 3.63 493598.75 716920.14 3.63 493598.57 716918.47 3.63 493605.02 716917.75 3.63 493603.97 716909.1 3.63 493592.48 716910.37 3.63 493593.5 716919.04 3.63 493595.84 716918.78 3.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC74-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493595.84 716918.78 3.63 493593.5 716919.04 3.63 493593.5 716919.04 8.36 493595.84 716918.78 8.36 493595.84 716918.78 3.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC74-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493593.5 716919.04 3.63 493592.48 716910.37 3.63 493592.48 716910.37 8.36 493593.5 716919.04 8.36 493593.5 716919.04 3.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC74-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493592.48 716910.37 3.63 493603.97 716909.1 3.63 493603.97 716909.1 8.36 493592.48 716910.37 8.36 493592.48 716910.37 3.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC74-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493603.97 716909.1 3.63 493605.02 716917.75 3.63 493605.02 716917.75 8.36 493603.97 716909.1 8.36 493603.97 716909.1 3.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC74-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493605.02 716917.75 3.63 493598.57 716918.47 3.63 493598.57 716918.47 8.36 493605.02 716917.75 8.36 493605.02 716917.75 3.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC74-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493598.57 716918.47 3.63 493598.75 716920.14 3.63 493598.75 716920.14 8.36 493598.57 716918.47 8.36 493598.57 716918.47 3.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC74-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493598.75 716920.14 3.63 493596.02 716920.45 3.63 493596.02 716920.45 8.36 493598.75 716920.14 8.36 493598.75 716920.14 3.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC74-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493596.02 716920.45 3.63 493595.84 716918.78 3.63 493595.84 716918.78 8.36 493596.02 716920.45 8.36 493596.02 716920.45 3.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC74-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493595.84 716918.78 8.36 493593.5 716919.04 8.36 493592.48 716910.37 8.36 493603.97 716909.1 8.36 493605.02 716917.75 8.36 493598.57 716918.47 8.36 493598.75 716920.14 8.36 493596.02 716920.45 8.36 493595.84 716918.78 8.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC73-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC73-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.07</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC73-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493553.24 716984.47 3.6 493563.89 716984.14 3.6 493563.5 716973.45 3.6 493554.19 716973.77 3.6 493554.46 716979.74 3.6 493553.12 716979.75 3.6 493553.24 716984.47 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC73-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493553.24 716984.47 3.6 493553.12 716979.75 3.6 493553.12 716979.75 8.665000000000001 493553.24 716984.47 8.665000000000001 493553.24 716984.47 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC73-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493553.12 716979.75 3.6 493554.46 716979.74 3.6 493554.46 716979.74 8.665000000000001 493553.12 716979.75 8.665000000000001 493553.12 716979.75 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC73-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493554.46 716979.74 3.6 493554.19 716973.77 3.6 493554.19 716973.77 8.665000000000001 493554.46 716979.74 8.665000000000001 493554.46 716979.74 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC73-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493554.19 716973.77 3.6 493563.5 716973.45 3.6 493563.5 716973.45 8.665000000000001 493554.19 716973.77 8.665000000000001 493554.19 716973.77 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC73-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493563.5 716973.45 3.6 493563.89 716984.14 3.6 493563.89 716984.14 8.665000000000001 493563.5 716973.45 8.665000000000001 493563.5 716973.45 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC73-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493563.89 716984.14 3.6 493553.24 716984.47 3.6 493553.24 716984.47 8.665000000000001 493563.89 716984.14 8.665000000000001 493563.89 716984.14 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC73-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493553.24 716984.47 8.665000000000001 493553.12 716979.75 8.665000000000001 493554.46 716979.74 8.665000000000001 493554.19 716973.77 8.665000000000001 493563.5 716973.45 8.665000000000001 493563.89 716984.14 8.665000000000001 493553.24 716984.47 8.665000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC72-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC72-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.19</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC72-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493560.86 716918.93 3.79 493561.19 716929.93 3.79 493570.75 716929.67 3.79 493570.65 716926.01 3.79 493573.02 716925.91 3.79 493572.85 716922.42 3.79 493570.55 716922.5 3.79 493570.44 716918.59 3.79 493560.86 716918.93 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC72-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493560.86 716918.93 3.79 493570.44 716918.59 3.79 493570.44 716918.59 10.975 493560.86 716918.93 10.975 493560.86 716918.93 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC72-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493570.44 716918.59 3.79 493570.55 716922.5 3.79 493570.55 716922.5 10.975 493570.44 716918.59 10.975 493570.44 716918.59 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC72-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493570.55 716922.5 3.79 493572.85 716922.42 3.79 493572.85 716922.42 10.975 493570.55 716922.5 10.975 493570.55 716922.5 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC72-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493572.85 716922.42 3.79 493573.02 716925.91 3.79 493573.02 716925.91 10.975 493572.85 716922.42 10.975 493572.85 716922.42 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC72-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493573.02 716925.91 3.79 493570.65 716926.01 3.79 493570.65 716926.01 10.975 493573.02 716925.91 10.975 493573.02 716925.91 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC72-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493570.65 716926.01 3.79 493570.75 716929.67 3.79 493570.75 716929.67 10.975 493570.65 716926.01 10.975 493570.65 716926.01 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC72-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493570.75 716929.67 3.79 493561.19 716929.93 3.79 493561.19 716929.93 10.975 493570.75 716929.67 10.975 493570.75 716929.67 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC72-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493561.19 716929.93 3.79 493560.86 716918.93 3.79 493560.86 716918.93 10.975 493561.19 716929.93 10.975 493561.19 716929.93 3.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC72-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493560.86 716918.93 10.975 493570.44 716918.59 10.975 493570.55 716922.5 10.975 493572.85 716922.42 10.975 493573.02 716925.91 10.975 493570.65 716926.01 10.975 493570.75 716929.67 10.975 493561.19 716929.93 10.975 493560.86 716918.93 10.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC71-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC71-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.16</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC71-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493512.19 717053.34 3.72 493512.05 717036.9 3.72 493497.06 717037.03 3.72 493497.13 717046.66 3.72 493506.05 717046.68 3.72 493506.13 717053.29 3.72 493512.19 717053.34 3.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC71-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493512.19 717053.34 3.72 493506.13 717053.29 3.72 493506.13 717053.29 7.880000000000001 493512.19 717053.34 7.880000000000001 493512.19 717053.34 3.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC71-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493506.13 717053.29 3.72 493506.05 717046.68 3.72 493506.05 717046.68 7.880000000000001 493506.13 717053.29 7.880000000000001 493506.13 717053.29 3.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC71-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493506.05 717046.68 3.72 493497.13 717046.66 3.72 493497.13 717046.66 7.880000000000001 493506.05 717046.68 7.880000000000001 493506.05 717046.68 3.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC71-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493497.13 717046.66 3.72 493497.06 717037.03 3.72 493497.06 717037.03 7.880000000000001 493497.13 717046.66 7.880000000000001 493497.13 717046.66 3.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC71-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493497.06 717037.03 3.72 493512.05 717036.9 3.72 493512.05 717036.9 7.880000000000001 493497.06 717037.03 7.880000000000001 493497.06 717037.03 3.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC71-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493512.05 717036.9 3.72 493512.19 717053.34 3.72 493512.19 717053.34 7.880000000000001 493512.05 717036.9 7.880000000000001 493512.05 717036.9 3.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC71-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493512.19 717053.34 7.880000000000001 493506.13 717053.29 7.880000000000001 493506.05 717046.68 7.880000000000001 493497.13 717046.66 7.880000000000001 493497.06 717037.03 7.880000000000001 493512.05 717036.9 7.880000000000001 493512.19 717053.34 7.880000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.68</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493552.56 717101.57 3.03 493557.13 717101.61 3.03 493557.16 717102.94 3.03 493559.97 717102.89 3.03 493559.91 717101.61 3.03 493561.96 717101.62 3.03 493562.02 717096.72 3.03 493564.17 717096.79 3.03 493564.23 717093.54 3.03 493562.03 717093.5 3.03 493562.06 717091.25 3.03 493552.69 717091.14 3.03 493552.68 717091.82 3.03 493552.56 717101.57 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493552.56 717101.57 3.03 493552.68 717091.82 3.03 493552.68 717091.82 10.71 493552.56 717101.57 10.71 493552.56 717101.57 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493552.68 717091.82 3.03 493552.69 717091.14 3.03 493552.69 717091.14 10.71 493552.68 717091.82 10.71 493552.68 717091.82 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493552.69 717091.14 3.03 493562.06 717091.25 3.03 493562.06 717091.25 10.71 493552.69 717091.14 10.71 493552.69 717091.14 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493562.06 717091.25 3.03 493562.03 717093.5 3.03 493562.03 717093.5 10.71 493562.06 717091.25 10.71 493562.06 717091.25 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493562.03 717093.5 3.03 493564.23 717093.54 3.03 493564.23 717093.54 10.71 493562.03 717093.5 10.71 493562.03 717093.5 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493564.23 717093.54 3.03 493564.17 717096.79 3.03 493564.17 717096.79 10.71 493564.23 717093.54 10.71 493564.23 717093.54 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493564.17 717096.79 3.03 493562.02 717096.72 3.03 493562.02 717096.72 10.71 493564.17 717096.79 10.71 493564.17 717096.79 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493562.02 717096.72 3.03 493561.96 717101.62 3.03 493561.96 717101.62 10.71 493562.02 717096.72 10.71 493562.02 717096.72 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493561.96 717101.62 3.03 493559.91 717101.61 3.03 493559.91 717101.61 10.71 493561.96 717101.62 10.71 493561.96 717101.62 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493559.91 717101.61 3.03 493559.97 717102.89 3.03 493559.97 717102.89 10.71 493559.91 717101.61 10.71 493559.91 717101.61 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493559.97 717102.89 3.03 493557.16 717102.94 3.03 493557.16 717102.94 10.71 493559.97 717102.89 10.71 493559.97 717102.89 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493557.16 717102.94 3.03 493557.13 717101.61 3.03 493557.13 717101.61 10.71 493557.16 717102.94 10.71 493557.16 717102.94 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493557.13 717101.61 3.03 493552.56 717101.57 3.03 493552.56 717101.57 10.71 493557.13 717101.61 10.71 493557.13 717101.61 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC70-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493552.56 717101.57 10.71 493552.68 717091.82 10.71 493552.69 717091.14 10.71 493562.06 717091.25 10.71 493562.03 717093.5 10.71 493564.23 717093.54 10.71 493564.17 717096.79 10.71 493562.02 717096.72 10.71 493561.96 717101.62 10.71 493559.91 717101.61 10.71 493559.97 717102.89 10.71 493557.16 717102.94 10.71 493557.13 717101.61 10.71 493552.56 717101.57 10.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0794-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.92</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493323.97 717080.85 4.19 493334.5 717082.52 4.19 493335.06 717078.9 4.19 493338.3 717079.36 4.19 493338.8 717075.93 4.19 493335.57 717075.46 4.19 493336.11 717071.77 4.19 493330.01 717070.86 4.19 493330.33 717068.87 4.19 493327.18 717068.39 4.19 493326.46 717073.68 4.19 493326.08 717073.62 4.19 493325.66 717076.27 4.19 493324.72 717076.11 4.19 493323.97 717080.85 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493323.97 717080.85 4.19 493324.72 717076.11 4.19 493324.72 717076.11 10.11 493323.97 717080.85 10.11 493323.97 717080.85 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493324.72 717076.11 4.19 493325.66 717076.27 4.19 493325.66 717076.27 10.11 493324.72 717076.11 10.11 493324.72 717076.11 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493325.66 717076.27 4.19 493326.08 717073.62 4.19 493326.08 717073.62 10.11 493325.66 717076.27 10.11 493325.66 717076.27 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493326.08 717073.62 4.19 493326.46 717073.68 4.19 493326.46 717073.68 10.11 493326.08 717073.62 10.11 493326.08 717073.62 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493326.46 717073.68 4.19 493327.18 717068.39 4.19 493327.18 717068.39 10.11 493326.46 717073.68 10.11 493326.46 717073.68 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493327.18 717068.39 4.19 493330.33 717068.87 4.19 493330.33 717068.87 10.11 493327.18 717068.39 10.11 493327.18 717068.39 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493330.33 717068.87 4.19 493330.01 717070.86 4.19 493330.01 717070.86 10.11 493330.33 717068.87 10.11 493330.33 717068.87 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493330.01 717070.86 4.19 493336.11 717071.77 4.19 493336.11 717071.77 10.11 493330.01 717070.86 10.11 493330.01 717070.86 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493336.11 717071.77 4.19 493335.57 717075.46 4.19 493335.57 717075.46 10.11 493336.11 717071.77 10.11 493336.11 717071.77 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493335.57 717075.46 4.19 493338.8 717075.93 4.19 493338.8 717075.93 10.11 493335.57 717075.46 10.11 493335.57 717075.46 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493338.8 717075.93 4.19 493338.3 717079.36 4.19 493338.3 717079.36 10.11 493338.8 717075.93 10.11 493338.8 717075.93 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493338.3 717079.36 4.19 493335.06 717078.9 4.19 493335.06 717078.9 10.11 493338.3 717079.36 10.11 493338.3 717079.36 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493335.06 717078.9 4.19 493334.5 717082.52 4.19 493334.5 717082.52 10.11 493335.06 717078.9 10.11 493335.06 717078.9 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493334.5 717082.52 4.19 493323.97 717080.85 4.19 493323.97 717080.85 10.11 493334.5 717082.52 10.11 493334.5 717082.52 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0794-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493323.97 717080.85 10.11 493324.72 717076.11 10.11 493325.66 717076.27 10.11 493326.08 717073.62 10.11 493326.46 717073.68 10.11 493327.18 717068.39 10.11 493330.33 717068.87 10.11 493330.01 717070.86 10.11 493336.11 717071.77 10.11 493335.57 717075.46 10.11 493338.8 717075.93 10.11 493338.3 717079.36 10.11 493335.06 717078.9 10.11 493334.5 717082.52 10.11 493323.97 717080.85 10.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D221-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D221-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.89</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D221-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493870.18 716879.55 3.49 493871.06 716887.27 3.49 493882.11 716886.11 3.49 493881.19 716878.38 3.49 493870.18 716879.55 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D221-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493870.18 716879.55 3.49 493881.19 716878.38 3.49 493881.19 716878.38 8.375 493870.18 716879.55 8.375 493870.18 716879.55 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D221-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493881.19 716878.38 3.49 493882.11 716886.11 3.49 493882.11 716886.11 8.375 493881.19 716878.38 8.375 493881.19 716878.38 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D221-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493882.11 716886.11 3.49 493871.06 716887.27 3.49 493871.06 716887.27 8.375 493882.11 716886.11 8.375 493882.11 716886.11 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D221-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493871.06 716887.27 3.49 493870.18 716879.55 3.49 493870.18 716879.55 8.375 493871.06 716887.27 8.375 493871.06 716887.27 3.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D221-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493870.18 716879.55 8.375 493881.19 716878.38 8.375 493882.11 716886.11 8.375 493871.06 716887.27 8.375 493870.18 716879.55 8.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-078F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.52</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493280.31 717027.07 3.02 493285.88 717026.26 3.02 493285.82 717025.83 3.02 493288.05 717025.51 3.02 493286.77 717016.67 3.02 493276.73 717018.17 3.02 493276.81 717018.73 3.02 493272.67 717019.35 3.02 493273.77 717026.94 3.02 493277.95 717026.31 3.02 493278.01 717026.94 3.02 493280.27 717026.57 3.02 493280.31 717027.07 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493280.31 717027.07 3.02 493280.27 717026.57 3.02 493280.27 717026.57 9.540000000000001 493280.31 717027.07 9.540000000000001 493280.31 717027.07 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493280.27 717026.57 3.02 493278.01 717026.94 3.02 493278.01 717026.94 9.540000000000001 493280.27 717026.57 9.540000000000001 493280.27 717026.57 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493278.01 717026.94 3.02 493277.95 717026.31 3.02 493277.95 717026.31 9.540000000000001 493278.01 717026.94 9.540000000000001 493278.01 717026.94 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493277.95 717026.31 3.02 493273.77 717026.94 3.02 493273.77 717026.94 9.540000000000001 493277.95 717026.31 9.540000000000001 493277.95 717026.31 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493273.77 717026.94 3.02 493272.67 717019.35 3.02 493272.67 717019.35 9.540000000000001 493273.77 717026.94 9.540000000000001 493273.77 717026.94 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493272.67 717019.35 3.02 493276.81 717018.73 3.02 493276.81 717018.73 9.540000000000001 493272.67 717019.35 9.540000000000001 493272.67 717019.35 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493276.81 717018.73 3.02 493276.73 717018.17 3.02 493276.73 717018.17 9.540000000000001 493276.81 717018.73 9.540000000000001 493276.81 717018.73 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493276.73 717018.17 3.02 493286.77 717016.67 3.02 493286.77 717016.67 9.540000000000001 493276.73 717018.17 9.540000000000001 493276.73 717018.17 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493286.77 717016.67 3.02 493288.05 717025.51 3.02 493288.05 717025.51 9.540000000000001 493286.77 717016.67 9.540000000000001 493286.77 717016.67 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493288.05 717025.51 3.02 493285.82 717025.83 3.02 493285.82 717025.83 9.540000000000001 493288.05 717025.51 9.540000000000001 493288.05 717025.51 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493285.82 717025.83 3.02 493285.88 717026.26 3.02 493285.88 717026.26 9.540000000000001 493285.82 717025.83 9.540000000000001 493285.82 717025.83 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493285.88 717026.26 3.02 493280.31 717027.07 3.02 493280.31 717027.07 9.540000000000001 493285.88 717026.26 9.540000000000001 493285.88 717026.26 3.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-078F-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493280.31 717027.07 9.540000000000001 493280.27 717026.57 9.540000000000001 493278.01 717026.94 9.540000000000001 493277.95 717026.31 9.540000000000001 493273.77 717026.94 9.540000000000001 493272.67 717019.35 9.540000000000001 493276.81 717018.73 9.540000000000001 493276.73 717018.17 9.540000000000001 493286.77 717016.67 9.540000000000001 493288.05 717025.51 9.540000000000001 493285.82 717025.83 9.540000000000001 493285.88 717026.26 9.540000000000001 493280.31 717027.07 9.540000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-5e3fd6fb-cd4f-465e-8520-6838e8ddf930">
			<gen:stringAttribute name="buildingId">
				<gen:value>5e3fd6fb-cd4f-465e-8520-6838e8ddf930</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.59</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5e3fd6fb-cd4f-465e-8520-6838e8ddf930_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493662.59 717096.68 3.03 493667.54 717102.18 3.03 493674.62 717096.31 3.03 493669.92 717090.68 3.03 493662.59 717096.68 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5e3fd6fb-cd4f-465e-8520-6838e8ddf930_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493662.59 717096.68 3.03 493669.92 717090.68 3.03 493669.92 717090.68 8.620000000000001 493662.59 717096.68 8.620000000000001 493662.59 717096.68 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5e3fd6fb-cd4f-465e-8520-6838e8ddf930_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493669.92 717090.68 3.03 493674.62 717096.31 3.03 493674.62 717096.31 8.620000000000001 493669.92 717090.68 8.620000000000001 493669.92 717090.68 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5e3fd6fb-cd4f-465e-8520-6838e8ddf930_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493674.62 717096.31 3.03 493667.54 717102.18 3.03 493667.54 717102.18 8.620000000000001 493674.62 717096.31 8.620000000000001 493674.62 717096.31 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5e3fd6fb-cd4f-465e-8520-6838e8ddf930_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493667.54 717102.18 3.03 493662.59 717096.68 3.03 493662.59 717096.68 8.620000000000001 493667.54 717102.18 8.620000000000001 493667.54 717102.18 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5e3fd6fb-cd4f-465e-8520-6838e8ddf930_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493662.59 717096.68 8.620000000000001 493669.92 717090.68 8.620000000000001 493674.62 717096.31 8.620000000000001 493667.54 717102.18 8.620000000000001 493662.59 717096.68 8.620000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-40c4b061-a59f-4a93-bf41-8e371d195cbb">
			<gen:stringAttribute name="buildingId">
				<gen:value>40c4b061-a59f-4a93-bf41-8e371d195cbb</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.36</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40c4b061-a59f-4a93-bf41-8e371d195cbb_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493610.27 716887.43 3.7 493608.45 716879.52 3.7 493603.99 716880.47 3.7 493604.88 716884.54 3.7 493605.73 716888.45 3.7 493610.27 716887.43 3.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40c4b061-a59f-4a93-bf41-8e371d195cbb_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493610.27 716887.43 3.7 493605.73 716888.45 3.7 493605.73 716888.45 8.06 493610.27 716887.43 8.06 493610.27 716887.43 3.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40c4b061-a59f-4a93-bf41-8e371d195cbb_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493605.73 716888.45 3.7 493604.88 716884.54 3.7 493604.88 716884.54 8.06 493605.73 716888.45 8.06 493605.73 716888.45 3.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40c4b061-a59f-4a93-bf41-8e371d195cbb_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493604.88 716884.54 3.7 493603.99 716880.47 3.7 493603.99 716880.47 8.06 493604.88 716884.54 8.06 493604.88 716884.54 3.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40c4b061-a59f-4a93-bf41-8e371d195cbb_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493603.99 716880.47 3.7 493608.45 716879.52 3.7 493608.45 716879.52 8.06 493603.99 716880.47 8.06 493603.99 716880.47 3.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40c4b061-a59f-4a93-bf41-8e371d195cbb_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493608.45 716879.52 3.7 493610.27 716887.43 3.7 493610.27 716887.43 8.06 493608.45 716879.52 8.06 493608.45 716879.52 3.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-40c4b061-a59f-4a93-bf41-8e371d195cbb_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493610.27 716887.43 8.06 493605.73 716888.45 8.06 493604.88 716884.54 8.06 493603.99 716880.47 8.06 493608.45 716879.52 8.06 493610.27 716887.43 8.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-0987c72e-bc7a-4653-8aad-81bfa552829e">
			<gen:stringAttribute name="buildingId">
				<gen:value>0987c72e-bc7a-4653-8aad-81bfa552829e</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.86</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0987c72e-bc7a-4653-8aad-81bfa552829e_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493605.15 716917.73 3.39 493605.13 716917.66 3.39 493616.42 716916.43 3.39 493615.47 716907.95 3.39 493604.09 716909.17 3.39 493604.07 716909.08 3.39 493603.97 716909.1 3.39 493605.02 716917.75 3.39 493605.15 716917.73 3.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0987c72e-bc7a-4653-8aad-81bfa552829e_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493605.15 716917.73 3.39 493605.02 716917.75 3.39 493605.02 716917.75 8.25 493605.15 716917.73 8.25 493605.15 716917.73 3.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0987c72e-bc7a-4653-8aad-81bfa552829e_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493605.02 716917.75 3.39 493603.97 716909.1 3.39 493603.97 716909.1 8.25 493605.02 716917.75 8.25 493605.02 716917.75 3.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0987c72e-bc7a-4653-8aad-81bfa552829e_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493603.97 716909.1 3.39 493604.07 716909.08 3.39 493604.07 716909.08 8.25 493603.97 716909.1 8.25 493603.97 716909.1 3.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0987c72e-bc7a-4653-8aad-81bfa552829e_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493604.07 716909.08 3.39 493604.09 716909.17 3.39 493604.09 716909.17 8.25 493604.07 716909.08 8.25 493604.07 716909.08 3.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0987c72e-bc7a-4653-8aad-81bfa552829e_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493604.09 716909.17 3.39 493615.47 716907.95 3.39 493615.47 716907.95 8.25 493604.09 716909.17 8.25 493604.09 716909.17 3.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0987c72e-bc7a-4653-8aad-81bfa552829e_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493615.47 716907.95 3.39 493616.42 716916.43 3.39 493616.42 716916.43 8.25 493615.47 716907.95 8.25 493615.47 716907.95 3.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0987c72e-bc7a-4653-8aad-81bfa552829e_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493616.42 716916.43 3.39 493605.13 716917.66 3.39 493605.13 716917.66 8.25 493616.42 716916.43 8.25 493616.42 716916.43 3.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0987c72e-bc7a-4653-8aad-81bfa552829e_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493605.13 716917.66 3.39 493605.15 716917.73 3.39 493605.15 716917.73 8.25 493605.13 716917.66 8.25 493605.13 716917.66 3.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0987c72e-bc7a-4653-8aad-81bfa552829e_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493605.15 716917.73 8.25 493605.02 716917.75 8.25 493603.97 716909.1 8.25 493604.07 716909.08 8.25 493604.09 716909.17 8.25 493615.47 716907.95 8.25 493616.42 716916.43 8.25 493605.13 716917.66 8.25 493605.15 716917.73 8.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-c8286ca3-0b92-451f-b39d-2642b0e564f7">
			<gen:stringAttribute name="buildingId">
				<gen:value>c8286ca3-0b92-451f-b39d-2642b0e564f7</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.21</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8286ca3-0b92-451f-b39d-2642b0e564f7_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493620.31 716916.03 3.4 493619.38 716907.52 3.4 493615.47 716907.95 3.4 493616.42 716916.43 3.4 493620.31 716916.03 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8286ca3-0b92-451f-b39d-2642b0e564f7_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493620.31 716916.03 3.4 493616.42 716916.43 3.4 493616.42 716916.43 6.605 493620.31 716916.03 6.605 493620.31 716916.03 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8286ca3-0b92-451f-b39d-2642b0e564f7_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493616.42 716916.43 3.4 493615.47 716907.95 3.4 493615.47 716907.95 6.605 493616.42 716916.43 6.605 493616.42 716916.43 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8286ca3-0b92-451f-b39d-2642b0e564f7_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493615.47 716907.95 3.4 493619.38 716907.52 3.4 493619.38 716907.52 6.605 493615.47 716907.95 6.605 493615.47 716907.95 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8286ca3-0b92-451f-b39d-2642b0e564f7_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493619.38 716907.52 3.4 493620.31 716916.03 3.4 493620.31 716916.03 6.605 493619.38 716907.52 6.605 493619.38 716907.52 3.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c8286ca3-0b92-451f-b39d-2642b0e564f7_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493620.31 716916.03 6.605 493616.42 716916.43 6.605 493615.47 716907.95 6.605 493619.38 716907.52 6.605 493620.31 716916.03 6.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-71DF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-71DF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493143.67 716895.9 2.1 493125.89 716899.11 2.1 493121.9 716899.86 2.1 493122.63 716903.75 2.1 493126.62 716903.06 2.1 493144.33 716899.94 2.1 493143.67 716895.9 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493143.67 716895.9 2.1 493144.33 716899.94 2.1 493144.33 716899.94 4.89 493143.67 716895.9 4.89 493143.67 716895.9 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493144.33 716899.94 2.1 493126.62 716903.06 2.1 493126.62 716903.06 4.89 493144.33 716899.94 4.89 493144.33 716899.94 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493126.62 716903.06 2.1 493122.63 716903.75 2.1 493122.63 716903.75 4.89 493126.62 716903.06 4.89 493126.62 716903.06 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493122.63 716903.75 2.1 493121.9 716899.86 2.1 493121.9 716899.86 4.89 493122.63 716903.75 4.89 493122.63 716903.75 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493121.9 716899.86 2.1 493125.89 716899.11 2.1 493125.89 716899.11 4.89 493121.9 716899.86 4.89 493121.9 716899.86 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493125.89 716899.11 2.1 493143.67 716895.9 2.1 493143.67 716895.9 4.89 493125.89 716899.11 4.89 493125.89 716899.11 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493143.67 716895.9 4.89 493144.33 716899.94 4.89 493126.62 716903.06 4.89 493122.63 716903.75 4.89 493121.9 716899.86 4.89 493125.89 716899.11 4.89 493143.67 716895.9 4.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-71DE-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-71DE-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DE-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493342.02 717096.54 3.33 493342.09 717101.05 3.33 493350.05 717101.03 3.33 493349.6 717086.38 3.33 493345.11 717086.38 3.33 493345.3 717096.46 3.33 493342.02 717096.54 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DE-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493342.02 717096.54 3.33 493345.3 717096.46 3.33 493345.3 717096.46 7.12 493342.02 717096.54 7.12 493342.02 717096.54 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DE-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493345.3 717096.46 3.33 493345.11 717086.38 3.33 493345.11 717086.38 7.12 493345.3 717096.46 7.12 493345.3 717096.46 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DE-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493345.11 717086.38 3.33 493349.6 717086.38 3.33 493349.6 717086.38 7.12 493345.11 717086.38 7.12 493345.11 717086.38 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DE-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493349.6 717086.38 3.33 493350.05 717101.03 3.33 493350.05 717101.03 7.12 493349.6 717086.38 7.12 493349.6 717086.38 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DE-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493350.05 717101.03 3.33 493342.09 717101.05 3.33 493342.09 717101.05 7.12 493350.05 717101.03 7.12 493350.05 717101.03 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DE-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493342.09 717101.05 3.33 493342.02 717096.54 3.33 493342.02 717096.54 7.12 493342.09 717101.05 7.12 493342.09 717101.05 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71DE-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493342.02 717096.54 7.12 493345.3 717096.46 7.12 493345.11 717086.38 7.12 493349.6 717086.38 7.12 493350.05 717101.03 7.12 493342.09 717101.05 7.12 493342.02 717096.54 7.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.01</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493116.61 716883.06 2.22 493118.5 716893.17 2.22 493121.19 716892.66 2.22 493121.56 716894.72 2.22 493125.63 716893.96 2.22 493125.22 716891.91 2.22 493129.43 716891.13 2.22 493129.84 716893.37 2.22 493135.15 716892.41 2.22 493134.74 716890.08 2.22 493136.43 716889.75 2.22 493134.5 716879.89 2.22 493116.61 716883.06 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493116.61 716883.06 2.22 493134.5 716879.89 2.22 493134.5 716879.89 8.23 493116.61 716883.06 8.23 493116.61 716883.06 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493134.5 716879.89 2.22 493136.43 716889.75 2.22 493136.43 716889.75 8.23 493134.5 716879.89 8.23 493134.5 716879.89 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493136.43 716889.75 2.22 493134.74 716890.08 2.22 493134.74 716890.08 8.23 493136.43 716889.75 8.23 493136.43 716889.75 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493134.74 716890.08 2.22 493135.15 716892.41 2.22 493135.15 716892.41 8.23 493134.74 716890.08 8.23 493134.74 716890.08 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493135.15 716892.41 2.22 493129.84 716893.37 2.22 493129.84 716893.37 8.23 493135.15 716892.41 8.23 493135.15 716892.41 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493129.84 716893.37 2.22 493129.43 716891.13 2.22 493129.43 716891.13 8.23 493129.84 716893.37 8.23 493129.84 716893.37 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493129.43 716891.13 2.22 493125.22 716891.91 2.22 493125.22 716891.91 8.23 493129.43 716891.13 8.23 493129.43 716891.13 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493125.22 716891.91 2.22 493125.63 716893.96 2.22 493125.63 716893.96 8.23 493125.22 716891.91 8.23 493125.22 716891.91 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493125.63 716893.96 2.22 493121.56 716894.72 2.22 493121.56 716894.72 8.23 493125.63 716893.96 8.23 493125.63 716893.96 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493121.56 716894.72 2.22 493121.19 716892.66 2.22 493121.19 716892.66 8.23 493121.56 716894.72 8.23 493121.56 716894.72 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493121.19 716892.66 2.22 493118.5 716893.17 2.22 493118.5 716893.17 8.23 493121.19 716892.66 8.23 493121.19 716892.66 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493118.5 716893.17 2.22 493116.61 716883.06 2.22 493116.61 716883.06 8.23 493118.5 716893.17 8.23 493118.5 716893.17 2.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-71E0-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493116.61 716883.06 8.23 493134.5 716879.89 8.23 493136.43 716889.75 8.23 493134.74 716890.08 8.23 493135.15 716892.41 8.23 493129.84 716893.37 8.23 493129.43 716891.13 8.23 493125.22 716891.91 8.23 493125.63 716893.96 8.23 493121.56 716894.72 8.23 493121.19 716892.66 8.23 493118.5 716893.17 8.23 493116.61 716883.06 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D087-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D087-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.23</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D087-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493299.85 717107.3 3.65 493305.95 717108.01 3.65 493307.07 717098.6 3.65 493300.97 717097.9 3.65 493299.85 717107.3 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D087-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493299.85 717107.3 3.65 493300.97 717097.9 3.65 493300.97 717097.9 6.88 493299.85 717107.3 6.88 493299.85 717107.3 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D087-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493300.97 717097.9 3.65 493307.07 717098.6 3.65 493307.07 717098.6 6.88 493300.97 717097.9 6.88 493300.97 717097.9 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D087-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493307.07 717098.6 3.65 493305.95 717108.01 3.65 493305.95 717108.01 6.88 493307.07 717098.6 6.88 493307.07 717098.6 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D087-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493305.95 717108.01 3.65 493299.85 717107.3 3.65 493299.85 717107.3 6.88 493305.95 717108.01 6.88 493305.95 717108.01 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D087-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493299.85 717107.3 6.88 493300.97 717097.9 6.88 493307.07 717098.6 6.88 493305.95 717108.01 6.88 493299.85 717107.3 6.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D086-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D086-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.17</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D086-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493295.35 717092.55 3.28 493297.13 717092.77 3.28 493303.02 717093.52 3.28 493305.61 717073.94 3.28 493307.62 717074.11 3.28 493307.97 717070.89 3.28 493305.99 717070.62 3.28 493306.28 717068.59 3.28 493298.63 717067.58 3.28 493295.35 717092.55 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D086-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493295.35 717092.55 3.28 493298.63 717067.58 3.28 493298.63 717067.58 8.45 493295.35 717092.55 8.45 493295.35 717092.55 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D086-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493298.63 717067.58 3.28 493306.28 717068.59 3.28 493306.28 717068.59 8.45 493298.63 717067.58 8.45 493298.63 717067.58 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D086-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493306.28 717068.59 3.28 493305.99 717070.62 3.28 493305.99 717070.62 8.45 493306.28 717068.59 8.45 493306.28 717068.59 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D086-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493305.99 717070.62 3.28 493307.97 717070.89 3.28 493307.97 717070.89 8.45 493305.99 717070.62 8.45 493305.99 717070.62 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D086-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493307.97 717070.89 3.28 493307.62 717074.11 3.28 493307.62 717074.11 8.45 493307.97 717070.89 8.45 493307.97 717070.89 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D086-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493307.62 717074.11 3.28 493305.61 717073.94 3.28 493305.61 717073.94 8.45 493307.62 717074.11 8.45 493307.62 717074.11 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D086-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493305.61 717073.94 3.28 493303.02 717093.52 3.28 493303.02 717093.52 8.45 493305.61 717073.94 8.45 493305.61 717073.94 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D086-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493303.02 717093.52 3.28 493297.13 717092.77 3.28 493297.13 717092.77 8.45 493303.02 717093.52 8.45 493303.02 717093.52 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D086-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493297.13 717092.77 3.28 493295.35 717092.55 3.28 493295.35 717092.55 8.45 493297.13 717092.77 8.45 493297.13 717092.77 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D086-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493295.35 717092.55 8.45 493298.63 717067.58 8.45 493306.28 717068.59 8.45 493305.99 717070.62 8.45 493307.97 717070.89 8.45 493307.62 717074.11 8.45 493305.61 717073.94 8.45 493303.02 717093.52 8.45 493297.13 717092.77 8.45 493295.35 717092.55 8.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7127-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7127-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.11</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7127-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493550.34 717113.88 3.64 493550.87 717131.26 3.64 493561.87 717130.92 3.64 493561.51 717117.79 3.64 493561.39 717113.63 3.64 493550.34 717113.88 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7127-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493550.34 717113.88 3.64 493561.39 717113.63 3.64 493561.39 717113.63 11.75 493550.34 717113.88 11.75 493550.34 717113.88 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7127-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493561.39 717113.63 3.64 493561.51 717117.79 3.64 493561.51 717117.79 11.75 493561.39 717113.63 11.75 493561.39 717113.63 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7127-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493561.51 717117.79 3.64 493561.87 717130.92 3.64 493561.87 717130.92 11.75 493561.51 717117.79 11.75 493561.51 717117.79 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7127-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493561.87 717130.92 3.64 493550.87 717131.26 3.64 493550.87 717131.26 11.75 493561.87 717130.92 11.75 493561.87 717130.92 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7127-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493550.87 717131.26 3.64 493550.34 717113.88 3.64 493550.34 717113.88 11.75 493550.87 717131.26 11.75 493550.87 717131.26 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7127-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493550.34 717113.88 11.75 493561.39 717113.63 11.75 493561.51 717117.79 11.75 493561.87 717130.92 11.75 493550.87 717131.26 11.75 493550.34 717113.88 11.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D14E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D14E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.08</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493326.03 717049.81 3.33 493334.78 717050.76 3.33 493335.61 717043.06 3.33 493326.86 717042.11 3.33 493326.03 717049.81 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493326.03 717049.81 3.33 493326.86 717042.11 3.33 493326.86 717042.11 6.41 493326.03 717049.81 6.41 493326.03 717049.81 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493326.86 717042.11 3.33 493335.61 717043.06 3.33 493335.61 717043.06 6.41 493326.86 717042.11 6.41 493326.86 717042.11 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493335.61 717043.06 3.33 493334.78 717050.76 3.33 493334.78 717050.76 6.41 493335.61 717043.06 6.41 493335.61 717043.06 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493334.78 717050.76 3.33 493326.03 717049.81 3.33 493326.03 717049.81 6.41 493334.78 717050.76 6.41 493334.78 717050.76 3.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D14E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>493326.03 717049.81 6.41 493326.86 717042.11 6.41 493335.61 717043.06 6.41 493334.78 717050.76 6.41 493326.03 717049.81 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
</CityModel>
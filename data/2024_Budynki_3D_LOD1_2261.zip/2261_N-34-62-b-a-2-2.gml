<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0" xmlns="http://www.opengis.net/citygml/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
			<gml:lowerCorner>489870.1 716522.76 1.69</gml:lowerCorner>
			<gml:upperCorner>491801.51 718345.16 12.23</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.77</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490838.8 717750.97 3.21 490840.15 717754.11 3.21 490842.19 717753.17 3.21 490843.24 717755.59 3.21 490844.69 717754.96 3.21 490845.19 717756.02 3.21 490846.47 717755.44 3.21 490846.01 717754.39 3.21 490856.55 717749.77 3.21 490852.5 717740.5 3.21 490839.18 717746.38 3.21 490840.81 717750.13 3.21 490838.8 717750.97 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490838.8 717750.97 3.21 490840.81 717750.13 3.21 490840.81 717750.13 9.98 490838.8 717750.97 9.98 490838.8 717750.97 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490840.81 717750.13 3.21 490839.18 717746.38 3.21 490839.18 717746.38 9.98 490840.81 717750.13 9.98 490840.81 717750.13 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490839.18 717746.38 3.21 490852.5 717740.5 3.21 490852.5 717740.5 9.98 490839.18 717746.38 9.98 490839.18 717746.38 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490852.5 717740.5 3.21 490856.55 717749.77 3.21 490856.55 717749.77 9.98 490852.5 717740.5 9.98 490852.5 717740.5 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490856.55 717749.77 3.21 490846.01 717754.39 3.21 490846.01 717754.39 9.98 490856.55 717749.77 9.98 490856.55 717749.77 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490846.01 717754.39 3.21 490846.47 717755.44 3.21 490846.47 717755.44 9.98 490846.01 717754.39 9.98 490846.01 717754.39 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490846.47 717755.44 3.21 490845.19 717756.02 3.21 490845.19 717756.02 9.98 490846.47 717755.44 9.98 490846.47 717755.44 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490845.19 717756.02 3.21 490844.69 717754.96 3.21 490844.69 717754.96 9.98 490845.19 717756.02 9.98 490845.19 717756.02 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490844.69 717754.96 3.21 490843.24 717755.59 3.21 490843.24 717755.59 9.98 490844.69 717754.96 9.98 490844.69 717754.96 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490843.24 717755.59 3.21 490842.19 717753.17 3.21 490842.19 717753.17 9.98 490843.24 717755.59 9.98 490843.24 717755.59 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490842.19 717753.17 3.21 490840.15 717754.11 3.21 490840.15 717754.11 9.98 490842.19 717753.17 9.98 490842.19 717753.17 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490840.15 717754.11 3.21 490838.8 717750.97 3.21 490838.8 717750.97 9.98 490840.15 717754.11 9.98 490840.15 717754.11 3.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F9-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490838.8 717750.97 9.98 490840.81 717750.13 9.98 490839.18 717746.38 9.98 490852.5 717740.5 9.98 490856.55 717749.77 9.98 490846.01 717754.39 9.98 490846.47 717755.44 9.98 490845.19 717756.02 9.98 490844.69 717754.96 9.98 490843.24 717755.59 9.98 490842.19 717753.17 9.98 490840.15 717754.11 9.98 490838.8 717750.97 9.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01FC-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01FC-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.04</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FC-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490895.96 717576.62 3.44 490896.89 717578.75 3.44 490901.23 717587.84 3.44 490903.14 717586.97 3.44 490910.49 717583.57 3.44 490906.29 717574.47 3.44 490901 717576.91 3.44 490900.05 717574.8 3.44 490895.96 717576.62 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FC-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490895.96 717576.62 3.44 490900.05 717574.8 3.44 490900.05 717574.8 9.48 490895.96 717576.62 9.48 490895.96 717576.62 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FC-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490900.05 717574.8 3.44 490901 717576.91 3.44 490901 717576.91 9.48 490900.05 717574.8 9.48 490900.05 717574.8 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FC-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490901 717576.91 3.44 490906.29 717574.47 3.44 490906.29 717574.47 9.48 490901 717576.91 9.48 490901 717576.91 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FC-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490906.29 717574.47 3.44 490910.49 717583.57 3.44 490910.49 717583.57 9.48 490906.29 717574.47 9.48 490906.29 717574.47 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FC-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490910.49 717583.57 3.44 490903.14 717586.97 3.44 490903.14 717586.97 9.48 490910.49 717583.57 9.48 490910.49 717583.57 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FC-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490903.14 717586.97 3.44 490901.23 717587.84 3.44 490901.23 717587.84 9.48 490903.14 717586.97 9.48 490903.14 717586.97 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FC-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490901.23 717587.84 3.44 490896.89 717578.75 3.44 490896.89 717578.75 9.48 490901.23 717587.84 9.48 490901.23 717587.84 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FC-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490896.89 717578.75 3.44 490895.96 717576.62 3.44 490895.96 717576.62 9.48 490896.89 717578.75 9.48 490896.89 717578.75 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FC-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490895.96 717576.62 9.48 490900.05 717574.8 9.48 490901 717576.91 9.48 490906.29 717574.47 9.48 490910.49 717583.57 9.48 490903.14 717586.97 9.48 490901.23 717587.84 9.48 490896.89 717578.75 9.48 490895.96 717576.62 9.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01FA-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01FA-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FA-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491429.06 717084.24 3.16 491434.32 717091.75 3.16 491445.54 717083.95 3.16 491440.28 717076.43 3.16 491429.06 717084.24 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FA-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491429.06 717084.24 3.16 491440.28 717076.43 3.16 491440.28 717076.43 9.1 491429.06 717084.24 9.1 491429.06 717084.24 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FA-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491440.28 717076.43 3.16 491445.54 717083.95 3.16 491445.54 717083.95 9.1 491440.28 717076.43 9.1 491440.28 717076.43 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FA-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491445.54 717083.95 3.16 491434.32 717091.75 3.16 491434.32 717091.75 9.1 491445.54 717083.95 9.1 491445.54 717083.95 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FA-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491434.32 717091.75 3.16 491429.06 717084.24 3.16 491429.06 717084.24 9.1 491434.32 717091.75 9.1 491434.32 717091.75 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FA-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491429.06 717084.24 9.1 491440.28 717076.43 9.1 491445.54 717083.95 9.1 491434.32 717091.75 9.1 491429.06 717084.24 9.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490920.94 717565.67 2.94 490923.23 717570.69 2.94 490922.06 717571.19 2.94 490922.98 717573.2 2.94 490924.12 717572.7 2.94 490925.85 717576.51 2.94 490933.96 717572.85 2.94 490935 717572.38 2.94 490935.5 717573.47 2.94 490939.48 717571.69 2.94 490934.11 717559.76 2.94 490920.94 717565.67 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490920.94 717565.67 2.94 490934.11 717559.76 2.94 490934.11 717559.76 11.47 490920.94 717565.67 11.47 490920.94 717565.67 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490934.11 717559.76 2.94 490939.48 717571.69 2.94 490939.48 717571.69 11.47 490934.11 717559.76 11.47 490934.11 717559.76 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490939.48 717571.69 2.94 490935.5 717573.47 2.94 490935.5 717573.47 11.47 490939.48 717571.69 11.47 490939.48 717571.69 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490935.5 717573.47 2.94 490935 717572.38 2.94 490935 717572.38 11.47 490935.5 717573.47 11.47 490935.5 717573.47 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490935 717572.38 2.94 490933.96 717572.85 2.94 490933.96 717572.85 11.47 490935 717572.38 11.47 490935 717572.38 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490933.96 717572.85 2.94 490925.85 717576.51 2.94 490925.85 717576.51 11.47 490933.96 717572.85 11.47 490933.96 717572.85 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490925.85 717576.51 2.94 490924.12 717572.7 2.94 490924.12 717572.7 11.47 490925.85 717576.51 11.47 490925.85 717576.51 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490924.12 717572.7 2.94 490922.98 717573.2 2.94 490922.98 717573.2 11.47 490924.12 717572.7 11.47 490924.12 717572.7 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490922.98 717573.2 2.94 490922.06 717571.19 2.94 490922.06 717571.19 11.47 490922.98 717573.2 11.47 490922.98 717573.2 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490922.06 717571.19 2.94 490923.23 717570.69 2.94 490923.23 717570.69 11.47 490922.06 717571.19 11.47 490922.06 717571.19 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490923.23 717570.69 2.94 490920.94 717565.67 2.94 490920.94 717565.67 11.47 490923.23 717570.69 11.47 490923.23 717570.69 2.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FB-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490920.94 717565.67 11.47 490934.11 717559.76 11.47 490939.48 717571.69 11.47 490935.5 717573.47 11.47 490935 717572.38 11.47 490933.96 717572.85 11.47 490925.85 717576.51 11.47 490924.12 717572.7 11.47 490922.98 717573.2 11.47 490922.06 717571.19 11.47 490923.23 717570.69 11.47 490920.94 717565.67 11.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CC64-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CC64-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.42</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC64-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490585.8 717918.25 2.28 490602.19 717950.59 2.28 490605.03 717949.07 2.28 490588.73 717916.75 2.28 490585.8 717918.25 2.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC64-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490585.8 717918.25 2.28 490588.73 717916.75 2.28 490588.73 717916.75 4.7 490585.8 717918.25 4.7 490585.8 717918.25 2.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC64-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490588.73 717916.75 2.28 490605.03 717949.07 2.28 490605.03 717949.07 4.7 490588.73 717916.75 4.7 490588.73 717916.75 2.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC64-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490605.03 717949.07 2.28 490602.19 717950.59 2.28 490602.19 717950.59 4.7 490605.03 717949.07 4.7 490605.03 717949.07 2.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC64-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490602.19 717950.59 2.28 490585.8 717918.25 2.28 490585.8 717918.25 4.7 490602.19 717950.59 4.7 490602.19 717950.59 2.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC64-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490585.8 717918.25 4.7 490588.73 717916.75 4.7 490605.03 717949.07 4.7 490602.19 717950.59 4.7 490585.8 717918.25 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CC62-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CC62-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.36</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC62-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490577.7 717895.05 2.29 490574.87 717896.43 2.29 490585.71 717917.87 2.29 490588.63 717916.39 2.29 490577.7 717895.05 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC62-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490577.7 717895.05 2.29 490588.63 717916.39 2.29 490588.63 717916.39 4.65 490577.7 717895.05 4.65 490577.7 717895.05 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC62-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490588.63 717916.39 2.29 490585.71 717917.87 2.29 490585.71 717917.87 4.65 490588.63 717916.39 4.65 490588.63 717916.39 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC62-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490585.71 717917.87 2.29 490574.87 717896.43 2.29 490574.87 717896.43 4.65 490585.71 717917.87 4.65 490585.71 717917.87 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC62-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490574.87 717896.43 2.29 490577.7 717895.05 2.29 490577.7 717895.05 4.65 490574.87 717896.43 4.65 490574.87 717896.43 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC62-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490577.7 717895.05 4.65 490588.63 717916.39 4.65 490585.71 717917.87 4.65 490574.87 717896.43 4.65 490577.7 717895.05 4.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.05</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490027.48 718249.68 2.21 490035.66 718251.63 2.21 490036.38 718248.77 2.21 490041.55 718249.99 2.21 490042.55 718245.9 2.21 490043.38 718242.5 2.21 490038.27 718241.22 2.21 490034.37 718240.26 2.21 490034.78 718238.6 2.21 490034.69 718238.56 2.21 490036.71 718230.53 2.21 490030.83 718229.11 2.21 490028.99 718236.36 2.21 490028.88 718236.35 2.21 490028.15 718239.27 2.21 490029.94 718239.7 2.21 490027.48 718249.68 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490027.48 718249.68 2.21 490029.94 718239.7 2.21 490029.94 718239.7 5.26 490027.48 718249.68 5.26 490027.48 718249.68 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490029.94 718239.7 2.21 490028.15 718239.27 2.21 490028.15 718239.27 5.26 490029.94 718239.7 5.26 490029.94 718239.7 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490028.15 718239.27 2.21 490028.88 718236.35 2.21 490028.88 718236.35 5.26 490028.15 718239.27 5.26 490028.15 718239.27 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490028.88 718236.35 2.21 490028.99 718236.36 2.21 490028.99 718236.36 5.26 490028.88 718236.35 5.26 490028.88 718236.35 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490028.99 718236.36 2.21 490030.83 718229.11 2.21 490030.83 718229.11 5.26 490028.99 718236.36 5.26 490028.99 718236.36 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490030.83 718229.11 2.21 490036.71 718230.53 2.21 490036.71 718230.53 5.26 490030.83 718229.11 5.26 490030.83 718229.11 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490036.71 718230.53 2.21 490034.69 718238.56 2.21 490034.69 718238.56 5.26 490036.71 718230.53 5.26 490036.71 718230.53 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490034.69 718238.56 2.21 490034.78 718238.6 2.21 490034.78 718238.6 5.26 490034.69 718238.56 5.26 490034.69 718238.56 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490034.78 718238.6 2.21 490034.37 718240.26 2.21 490034.37 718240.26 5.26 490034.78 718238.6 5.26 490034.78 718238.6 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490034.37 718240.26 2.21 490038.27 718241.22 2.21 490038.27 718241.22 5.26 490034.37 718240.26 5.26 490034.37 718240.26 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490038.27 718241.22 2.21 490043.38 718242.5 2.21 490043.38 718242.5 5.26 490038.27 718241.22 5.26 490038.27 718241.22 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490043.38 718242.5 2.21 490042.55 718245.9 2.21 490042.55 718245.9 5.26 490043.38 718242.5 5.26 490043.38 718242.5 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490042.55 718245.9 2.21 490041.55 718249.99 2.21 490041.55 718249.99 5.26 490042.55 718245.9 5.26 490042.55 718245.9 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490041.55 718249.99 2.21 490036.38 718248.77 2.21 490036.38 718248.77 5.26 490041.55 718249.99 5.26 490041.55 718249.99 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490036.38 718248.77 2.21 490035.66 718251.63 2.21 490035.66 718251.63 5.26 490036.38 718248.77 5.26 490036.38 718248.77 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490035.66 718251.63 2.21 490027.48 718249.68 2.21 490027.48 718249.68 5.26 490035.66 718251.63 5.26 490035.66 718251.63 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A5-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490027.48 718249.68 5.26 490029.94 718239.7 5.26 490028.15 718239.27 5.26 490028.88 718236.35 5.26 490028.99 718236.36 5.26 490030.83 718229.11 5.26 490036.71 718230.53 5.26 490034.69 718238.56 5.26 490034.78 718238.6 5.26 490034.37 718240.26 5.26 490038.27 718241.22 5.26 490043.38 718242.5 5.26 490042.55 718245.9 5.26 490041.55 718249.99 5.26 490036.38 718248.77 5.26 490035.66 718251.63 5.26 490027.48 718249.68 5.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490631.47 718064.48 1.85 490633.39 718066.63 1.85 490633.29 718068.04 1.85 490634.92 718069.84 1.85 490636.43 718069.95 1.85 490637.52 718068.93 1.85 490640.02 718071.83 1.85 490641.56 718070.55 1.85 490641.67 718070.66 1.85 490651.51 718061.86 1.85 490653.35 718063.62 1.85 490655.48 718061.64 1.85 490653.74 718059.88 1.85 490668.83 718046.47 1.85 490667.72 718045.27 1.85 490670.76 718042.34 1.85 490667.08 718038.47 1.85 490664.13 718041.23 1.85 490658.54 718035.03 1.85 490652.68 718040.31 1.85 490655.25 718043.24 1.85 490648.82 718048.95 1.85 490648.89 718049.04 1.85 490631.47 718064.48 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490631.47 718064.48 1.85 490648.89 718049.04 1.85 490648.89 718049.04 5.4 490631.47 718064.48 5.4 490631.47 718064.48 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490648.89 718049.04 1.85 490648.82 718048.95 1.85 490648.82 718048.95 5.4 490648.89 718049.04 5.4 490648.89 718049.04 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490648.82 718048.95 1.85 490655.25 718043.24 1.85 490655.25 718043.24 5.4 490648.82 718048.95 5.4 490648.82 718048.95 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490655.25 718043.24 1.85 490652.68 718040.31 1.85 490652.68 718040.31 5.4 490655.25 718043.24 5.4 490655.25 718043.24 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490652.68 718040.31 1.85 490658.54 718035.03 1.85 490658.54 718035.03 5.4 490652.68 718040.31 5.4 490652.68 718040.31 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490658.54 718035.03 1.85 490664.13 718041.23 1.85 490664.13 718041.23 5.4 490658.54 718035.03 5.4 490658.54 718035.03 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490664.13 718041.23 1.85 490667.08 718038.47 1.85 490667.08 718038.47 5.4 490664.13 718041.23 5.4 490664.13 718041.23 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490667.08 718038.47 1.85 490670.76 718042.34 1.85 490670.76 718042.34 5.4 490667.08 718038.47 5.4 490667.08 718038.47 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490670.76 718042.34 1.85 490667.72 718045.27 1.85 490667.72 718045.27 5.4 490670.76 718042.34 5.4 490670.76 718042.34 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490667.72 718045.27 1.85 490668.83 718046.47 1.85 490668.83 718046.47 5.4 490667.72 718045.27 5.4 490667.72 718045.27 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490668.83 718046.47 1.85 490653.74 718059.88 1.85 490653.74 718059.88 5.4 490668.83 718046.47 5.4 490668.83 718046.47 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490653.74 718059.88 1.85 490655.48 718061.64 1.85 490655.48 718061.64 5.4 490653.74 718059.88 5.4 490653.74 718059.88 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490655.48 718061.64 1.85 490653.35 718063.62 1.85 490653.35 718063.62 5.4 490655.48 718061.64 5.4 490655.48 718061.64 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490653.35 718063.62 1.85 490651.51 718061.86 1.85 490651.51 718061.86 5.4 490653.35 718063.62 5.4 490653.35 718063.62 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490651.51 718061.86 1.85 490641.67 718070.66 1.85 490641.67 718070.66 5.4 490651.51 718061.86 5.4 490651.51 718061.86 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490641.67 718070.66 1.85 490641.56 718070.55 1.85 490641.56 718070.55 5.4 490641.67 718070.66 5.4 490641.67 718070.66 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490641.56 718070.55 1.85 490640.02 718071.83 1.85 490640.02 718071.83 5.4 490641.56 718070.55 5.4 490641.56 718070.55 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490640.02 718071.83 1.85 490637.52 718068.93 1.85 490637.52 718068.93 5.4 490640.02 718071.83 5.4 490640.02 718071.83 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490637.52 718068.93 1.85 490636.43 718069.95 1.85 490636.43 718069.95 5.4 490637.52 718068.93 5.4 490637.52 718068.93 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490636.43 718069.95 1.85 490634.92 718069.84 1.85 490634.92 718069.84 5.4 490636.43 718069.95 5.4 490636.43 718069.95 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490634.92 718069.84 1.85 490633.29 718068.04 1.85 490633.29 718068.04 5.4 490634.92 718069.84 5.4 490634.92 718069.84 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490633.29 718068.04 1.85 490633.39 718066.63 1.85 490633.39 718066.63 5.4 490633.29 718068.04 5.4 490633.29 718068.04 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490633.39 718066.63 1.85 490631.47 718064.48 1.85 490631.47 718064.48 5.4 490633.39 718066.63 5.4 490633.39 718066.63 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A2-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490631.47 718064.48 5.4 490648.89 718049.04 5.4 490648.82 718048.95 5.4 490655.25 718043.24 5.4 490652.68 718040.31 5.4 490658.54 718035.03 5.4 490664.13 718041.23 5.4 490667.08 718038.47 5.4 490670.76 718042.34 5.4 490667.72 718045.27 5.4 490668.83 718046.47 5.4 490653.74 718059.88 5.4 490655.48 718061.64 5.4 490653.35 718063.62 5.4 490651.51 718061.86 5.4 490641.67 718070.66 5.4 490641.56 718070.55 5.4 490640.02 718071.83 5.4 490637.52 718068.93 5.4 490636.43 718069.95 5.4 490634.92 718069.84 5.4 490633.29 718068.04 5.4 490633.39 718066.63 5.4 490631.47 718064.48 5.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD3A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD3A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD3A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491564.48 716791.81 4.32 491573.25 716780.53 4.32 491550.64 716762.92 4.32 491541.86 716774.13 4.32 491564.48 716791.81 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD3A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491564.48 716791.81 4.32 491541.86 716774.13 4.32 491541.86 716774.13 11.870000000000001 491564.48 716791.81 11.870000000000001 491564.48 716791.81 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD3A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491541.86 716774.13 4.32 491550.64 716762.92 4.32 491550.64 716762.92 11.870000000000001 491541.86 716774.13 11.870000000000001 491541.86 716774.13 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD3A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491550.64 716762.92 4.32 491573.25 716780.53 4.32 491573.25 716780.53 11.870000000000001 491550.64 716762.92 11.870000000000001 491550.64 716762.92 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD3A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491573.25 716780.53 4.32 491564.48 716791.81 4.32 491564.48 716791.81 11.870000000000001 491573.25 716780.53 11.870000000000001 491573.25 716780.53 4.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD3A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491564.48 716791.81 11.870000000000001 491541.86 716774.13 11.870000000000001 491550.64 716762.92 11.870000000000001 491573.25 716780.53 11.870000000000001 491564.48 716791.81 11.870000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-68A7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-68A7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.68</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490014.98 718283.03 2.15 490012.99 718282.7 2.15 490010.9 718282.37 2.15 490010.59 718283.96 2.15 490011.58 718284.14 2.15 490010.73 718288.61 2.15 490013.91 718289.11 2.15 490014.98 718283.03 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490014.98 718283.03 2.15 490013.91 718289.11 2.15 490013.91 718289.11 4.83 490014.98 718283.03 4.83 490014.98 718283.03 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490013.91 718289.11 2.15 490010.73 718288.61 2.15 490010.73 718288.61 4.83 490013.91 718289.11 4.83 490013.91 718289.11 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490010.73 718288.61 2.15 490011.58 718284.14 2.15 490011.58 718284.14 4.83 490010.73 718288.61 4.83 490010.73 718288.61 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490011.58 718284.14 2.15 490010.59 718283.96 2.15 490010.59 718283.96 4.83 490011.58 718284.14 4.83 490011.58 718284.14 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490010.59 718283.96 2.15 490010.9 718282.37 2.15 490010.9 718282.37 4.83 490010.59 718283.96 4.83 490010.59 718283.96 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490010.9 718282.37 2.15 490012.99 718282.7 2.15 490012.99 718282.7 4.83 490010.9 718282.37 4.83 490010.9 718282.37 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490012.99 718282.7 2.15 490014.98 718283.03 2.15 490014.98 718283.03 4.83 490012.99 718282.7 4.83 490012.99 718282.7 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-68A7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490014.98 718283.03 4.83 490013.91 718289.11 4.83 490010.73 718288.61 4.83 490011.58 718284.14 4.83 490010.59 718283.96 4.83 490010.9 718282.37 4.83 490012.99 718282.7 4.83 490014.98 718283.03 4.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5F3F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5F3F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.87</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F3F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490708.12 718174.79 2.69 490718.38 718188.67 2.69 490724.94 718183.51 2.69 490714.41 718170.11 2.69 490708.12 718174.79 2.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F3F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490708.12 718174.79 2.69 490714.41 718170.11 2.69 490714.41 718170.11 7.5600000000000005 490708.12 718174.79 7.5600000000000005 490708.12 718174.79 2.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F3F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490714.41 718170.11 2.69 490724.94 718183.51 2.69 490724.94 718183.51 7.5600000000000005 490714.41 718170.11 7.5600000000000005 490714.41 718170.11 2.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F3F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490724.94 718183.51 2.69 490718.38 718188.67 2.69 490718.38 718188.67 7.5600000000000005 490724.94 718183.51 7.5600000000000005 490724.94 718183.51 2.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F3F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490718.38 718188.67 2.69 490708.12 718174.79 2.69 490708.12 718174.79 7.5600000000000005 490718.38 718188.67 7.5600000000000005 490718.38 718188.67 2.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5F3F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490708.12 718174.79 7.5600000000000005 490714.41 718170.11 7.5600000000000005 490724.94 718183.51 7.5600000000000005 490718.38 718188.67 7.5600000000000005 490708.12 718174.79 7.5600000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.92</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490926.55 717613.58 3.07 490933.88 717628.69 3.07 490933.94 717628.8 3.07 490939.24 717626.24 3.07 490938.01 717623.68 3.07 490947.85 717619.02 3.07 490946.03 717615.55 3.07 490945.72 717615.73 3.07 490940.19 717605.65 3.07 490926.62 717613.08 3.07 490926.8 717613.45 3.07 490926.55 717613.58 3.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490926.55 717613.58 3.07 490926.8 717613.45 3.07 490926.8 717613.45 6.99 490926.55 717613.58 6.99 490926.55 717613.58 3.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490926.8 717613.45 3.07 490926.62 717613.08 3.07 490926.62 717613.08 6.99 490926.8 717613.45 6.99 490926.8 717613.45 3.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490926.62 717613.08 3.07 490940.19 717605.65 3.07 490940.19 717605.65 6.99 490926.62 717613.08 6.99 490926.62 717613.08 3.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490940.19 717605.65 3.07 490945.72 717615.73 3.07 490945.72 717615.73 6.99 490940.19 717605.65 6.99 490940.19 717605.65 3.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490945.72 717615.73 3.07 490946.03 717615.55 3.07 490946.03 717615.55 6.99 490945.72 717615.73 6.99 490945.72 717615.73 3.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490946.03 717615.55 3.07 490947.85 717619.02 3.07 490947.85 717619.02 6.99 490946.03 717615.55 6.99 490946.03 717615.55 3.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490947.85 717619.02 3.07 490938.01 717623.68 3.07 490938.01 717623.68 6.99 490947.85 717619.02 6.99 490947.85 717619.02 3.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490938.01 717623.68 3.07 490939.24 717626.24 3.07 490939.24 717626.24 6.99 490938.01 717623.68 6.99 490938.01 717623.68 3.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490939.24 717626.24 3.07 490933.94 717628.8 3.07 490933.94 717628.8 6.99 490939.24 717626.24 6.99 490939.24 717626.24 3.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490933.94 717628.8 3.07 490933.88 717628.69 3.07 490933.88 717628.69 6.99 490933.94 717628.8 6.99 490933.94 717628.8 3.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490933.88 717628.69 3.07 490926.55 717613.58 3.07 490926.55 717613.58 6.99 490933.88 717628.69 6.99 490933.88 717628.69 3.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A9-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490926.55 717613.58 6.99 490926.8 717613.45 6.99 490926.62 717613.08 6.99 490940.19 717605.65 6.99 490945.72 717615.73 6.99 490946.03 717615.55 6.99 490947.85 717619.02 6.99 490938.01 717623.68 6.99 490939.24 717626.24 6.99 490933.94 717628.8 6.99 490933.88 717628.69 6.99 490926.55 717613.58 6.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-012D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.18</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490043.9 718313.14 2.29 490045.79 718313.83 2.29 490045.65 718314.21 2.29 490053.27 718316.9 2.29 490056.09 718317.9 2.29 490057.35 718314.41 2.29 490058.17 718312.15 2.29 490055.33 718311.16 2.29 490056.35 718308.4 2.29 490048.73 718305.67 2.29 490046.9 718310.76 2.29 490045.01 718310.04 2.29 490043.9 718313.14 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490043.9 718313.14 2.29 490045.01 718310.04 2.29 490045.01 718310.04 7.47 490043.9 718313.14 7.47 490043.9 718313.14 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490045.01 718310.04 2.29 490046.9 718310.76 2.29 490046.9 718310.76 7.47 490045.01 718310.04 7.47 490045.01 718310.04 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490046.9 718310.76 2.29 490048.73 718305.67 2.29 490048.73 718305.67 7.47 490046.9 718310.76 7.47 490046.9 718310.76 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490048.73 718305.67 2.29 490056.35 718308.4 2.29 490056.35 718308.4 7.47 490048.73 718305.67 7.47 490048.73 718305.67 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490056.35 718308.4 2.29 490055.33 718311.16 2.29 490055.33 718311.16 7.47 490056.35 718308.4 7.47 490056.35 718308.4 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490055.33 718311.16 2.29 490058.17 718312.15 2.29 490058.17 718312.15 7.47 490055.33 718311.16 7.47 490055.33 718311.16 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490058.17 718312.15 2.29 490057.35 718314.41 2.29 490057.35 718314.41 7.47 490058.17 718312.15 7.47 490058.17 718312.15 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490057.35 718314.41 2.29 490056.09 718317.9 2.29 490056.09 718317.9 7.47 490057.35 718314.41 7.47 490057.35 718314.41 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490056.09 718317.9 2.29 490053.27 718316.9 2.29 490053.27 718316.9 7.47 490056.09 718317.9 7.47 490056.09 718317.9 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490053.27 718316.9 2.29 490045.65 718314.21 2.29 490045.65 718314.21 7.47 490053.27 718316.9 7.47 490053.27 718316.9 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490045.65 718314.21 2.29 490045.79 718313.83 2.29 490045.79 718313.83 7.47 490045.65 718314.21 7.47 490045.65 718314.21 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490045.79 718313.83 2.29 490043.9 718313.14 2.29 490043.9 718313.14 7.47 490045.79 718313.83 7.47 490045.79 718313.83 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012D-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490043.9 718313.14 7.47 490045.01 718310.04 7.47 490046.9 718310.76 7.47 490048.73 718305.67 7.47 490056.35 718308.4 7.47 490055.33 718311.16 7.47 490058.17 718312.15 7.47 490057.35 718314.41 7.47 490056.09 718317.9 7.47 490053.27 718316.9 7.47 490045.65 718314.21 7.47 490045.79 718313.83 7.47 490043.9 718313.14 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-012B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489870.1 718289.38 1.95 489879.52 718290.48 1.95 489879.66 718289.54 1.95 489886.6 718290.45 1.95 489886.73 718289.5 1.95 489886.61 718289.48 1.95 489887.2 718284.65 1.95 489883.86 718284.26 1.95 489880.42 718283.85 1.95 489880.19 718285.48 1.95 489870.77 718284.37 1.95 489870.1 718289.38 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489870.1 718289.38 1.95 489870.77 718284.37 1.95 489870.77 718284.37 5.5 489870.1 718289.38 5.5 489870.1 718289.38 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489870.77 718284.37 1.95 489880.19 718285.48 1.95 489880.19 718285.48 5.5 489870.77 718284.37 5.5 489870.77 718284.37 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489880.19 718285.48 1.95 489880.42 718283.85 1.95 489880.42 718283.85 5.5 489880.19 718285.48 5.5 489880.19 718285.48 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489880.42 718283.85 1.95 489883.86 718284.26 1.95 489883.86 718284.26 5.5 489880.42 718283.85 5.5 489880.42 718283.85 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489883.86 718284.26 1.95 489887.2 718284.65 1.95 489887.2 718284.65 5.5 489883.86 718284.26 5.5 489883.86 718284.26 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489887.2 718284.65 1.95 489886.61 718289.48 1.95 489886.61 718289.48 5.5 489887.2 718284.65 5.5 489887.2 718284.65 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489886.61 718289.48 1.95 489886.73 718289.5 1.95 489886.73 718289.5 5.5 489886.61 718289.48 5.5 489886.61 718289.48 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489886.73 718289.5 1.95 489886.6 718290.45 1.95 489886.6 718290.45 5.5 489886.73 718289.5 5.5 489886.73 718289.5 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489886.6 718290.45 1.95 489879.66 718289.54 1.95 489879.66 718289.54 5.5 489886.6 718290.45 5.5 489886.6 718290.45 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489879.66 718289.54 1.95 489879.52 718290.48 1.95 489879.52 718290.48 5.5 489879.66 718289.54 5.5 489879.66 718289.54 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489879.52 718290.48 1.95 489870.1 718289.38 1.95 489870.1 718289.38 5.5 489879.52 718290.48 5.5 489879.52 718290.48 1.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012B-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489870.1 718289.38 5.5 489870.77 718284.37 5.5 489880.19 718285.48 5.5 489880.42 718283.85 5.5 489883.86 718284.26 5.5 489887.2 718284.65 5.5 489886.61 718289.48 5.5 489886.73 718289.5 5.5 489886.6 718290.45 5.5 489879.66 718289.54 5.5 489879.52 718290.48 5.5 489870.1 718289.38 5.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CC5F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CC5F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.28</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC5F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490560.11 717866.68 2.54 490566.19 717879.26 2.54 490572.32 717876.31 2.54 490566.22 717863.75 2.54 490560.11 717866.68 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC5F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490560.11 717866.68 2.54 490566.22 717863.75 2.54 490566.22 717863.75 4.82 490560.11 717866.68 4.82 490560.11 717866.68 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC5F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490566.22 717863.75 2.54 490572.32 717876.31 2.54 490572.32 717876.31 4.82 490566.22 717863.75 4.82 490566.22 717863.75 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC5F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490572.32 717876.31 2.54 490566.19 717879.26 2.54 490566.19 717879.26 4.82 490572.32 717876.31 4.82 490572.32 717876.31 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC5F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490566.19 717879.26 2.54 490560.11 717866.68 2.54 490560.11 717866.68 4.82 490566.19 717879.26 4.82 490566.19 717879.26 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC5F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490560.11 717866.68 4.82 490566.22 717863.75 4.82 490572.32 717876.31 4.82 490566.19 717879.26 4.82 490560.11 717866.68 4.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6F77-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6F77-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.15</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F77-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491664.65 717080.57 2.62 491667.08 717085.22 2.62 491673.5 717081.85 2.62 491671.04 717077.22 2.62 491664.65 717080.57 2.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F77-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491664.65 717080.57 2.62 491671.04 717077.22 2.62 491671.04 717077.22 7.7700000000000005 491664.65 717080.57 7.7700000000000005 491664.65 717080.57 2.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F77-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491671.04 717077.22 2.62 491673.5 717081.85 2.62 491673.5 717081.85 7.7700000000000005 491671.04 717077.22 7.7700000000000005 491671.04 717077.22 2.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F77-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491673.5 717081.85 2.62 491667.08 717085.22 2.62 491667.08 717085.22 7.7700000000000005 491673.5 717081.85 7.7700000000000005 491673.5 717081.85 2.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F77-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491667.08 717085.22 2.62 491664.65 717080.57 2.62 491664.65 717080.57 7.7700000000000005 491667.08 717085.22 7.7700000000000005 491667.08 717085.22 2.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F77-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491664.65 717080.57 7.7700000000000005 491671.04 717077.22 7.7700000000000005 491673.5 717081.85 7.7700000000000005 491667.08 717085.22 7.7700000000000005 491664.65 717080.57 7.7700000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0132-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0132-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.62</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0132-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490601.23 718003.89 1.79 490604.34 718009.97 1.79 490611.62 718006.19 1.79 490609.95 718002.76 1.79 490612.17 718001.57 1.79 490610.8 717998.73 1.79 490608.63 717999.87 1.79 490608.69 718000 1.79 490601.23 718003.89 1.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0132-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490601.23 718003.89 1.79 490608.69 718000 1.79 490608.69 718000 7.41 490601.23 718003.89 7.41 490601.23 718003.89 1.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0132-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490608.69 718000 1.79 490608.63 717999.87 1.79 490608.63 717999.87 7.41 490608.69 718000 7.41 490608.69 718000 1.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0132-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490608.63 717999.87 1.79 490610.8 717998.73 1.79 490610.8 717998.73 7.41 490608.63 717999.87 7.41 490608.63 717999.87 1.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0132-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490610.8 717998.73 1.79 490612.17 718001.57 1.79 490612.17 718001.57 7.41 490610.8 717998.73 7.41 490610.8 717998.73 1.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0132-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490612.17 718001.57 1.79 490609.95 718002.76 1.79 490609.95 718002.76 7.41 490612.17 718001.57 7.41 490612.17 718001.57 1.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0132-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490609.95 718002.76 1.79 490611.62 718006.19 1.79 490611.62 718006.19 7.41 490609.95 718002.76 7.41 490609.95 718002.76 1.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0132-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490611.62 718006.19 1.79 490604.34 718009.97 1.79 490604.34 718009.97 7.41 490611.62 718006.19 7.41 490611.62 718006.19 1.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0132-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490604.34 718009.97 1.79 490601.23 718003.89 1.79 490601.23 718003.89 7.41 490604.34 718009.97 7.41 490604.34 718009.97 1.79</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0132-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490601.23 718003.89 7.41 490608.69 718000 7.41 490608.63 717999.87 7.41 490610.8 717998.73 7.41 490612.17 718001.57 7.41 490609.95 718002.76 7.41 490611.62 718006.19 7.41 490604.34 718009.97 7.41 490601.23 718003.89 7.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0130-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.44</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490880.57 717609.99 3.64 490885.17 717619.16 3.64 490885.7 717618.88 3.64 490886.67 717620.81 3.64 490886.11 717621.09 3.64 490890.41 717629.71 3.64 490893.69 717636.11 3.64 490899.23 717633.35 3.64 490896.75 717628.49 3.64 490898.04 717627.83 3.64 490897.28 717626.27 3.64 490899.79 717625.01 3.64 490894.53 717614.49 3.64 490896.13 717613.71 3.64 490891.6 717604.55 3.64 490880.57 717609.99 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490880.57 717609.99 3.64 490891.6 717604.55 3.64 490891.6 717604.55 11.08 490880.57 717609.99 11.08 490880.57 717609.99 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490891.6 717604.55 3.64 490896.13 717613.71 3.64 490896.13 717613.71 11.08 490891.6 717604.55 11.08 490891.6 717604.55 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490896.13 717613.71 3.64 490894.53 717614.49 3.64 490894.53 717614.49 11.08 490896.13 717613.71 11.08 490896.13 717613.71 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490894.53 717614.49 3.64 490899.79 717625.01 3.64 490899.79 717625.01 11.08 490894.53 717614.49 11.08 490894.53 717614.49 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490899.79 717625.01 3.64 490897.28 717626.27 3.64 490897.28 717626.27 11.08 490899.79 717625.01 11.08 490899.79 717625.01 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490897.28 717626.27 3.64 490898.04 717627.83 3.64 490898.04 717627.83 11.08 490897.28 717626.27 11.08 490897.28 717626.27 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490898.04 717627.83 3.64 490896.75 717628.49 3.64 490896.75 717628.49 11.08 490898.04 717627.83 11.08 490898.04 717627.83 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490896.75 717628.49 3.64 490899.23 717633.35 3.64 490899.23 717633.35 11.08 490896.75 717628.49 11.08 490896.75 717628.49 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490899.23 717633.35 3.64 490893.69 717636.11 3.64 490893.69 717636.11 11.08 490899.23 717633.35 11.08 490899.23 717633.35 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490893.69 717636.11 3.64 490890.41 717629.71 3.64 490890.41 717629.71 11.08 490893.69 717636.11 11.08 490893.69 717636.11 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490890.41 717629.71 3.64 490886.11 717621.09 3.64 490886.11 717621.09 11.08 490890.41 717629.71 11.08 490890.41 717629.71 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490886.11 717621.09 3.64 490886.67 717620.81 3.64 490886.67 717620.81 11.08 490886.11 717621.09 11.08 490886.11 717621.09 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490886.67 717620.81 3.64 490885.7 717618.88 3.64 490885.7 717618.88 11.08 490886.67 717620.81 11.08 490886.67 717620.81 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490885.7 717618.88 3.64 490885.17 717619.16 3.64 490885.17 717619.16 11.08 490885.7 717618.88 11.08 490885.7 717618.88 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490885.17 717619.16 3.64 490880.57 717609.99 3.64 490880.57 717609.99 11.08 490885.17 717619.16 11.08 490885.17 717619.16 3.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0130-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490880.57 717609.99 11.08 490891.6 717604.55 11.08 490896.13 717613.71 11.08 490894.53 717614.49 11.08 490899.79 717625.01 11.08 490897.28 717626.27 11.08 490898.04 717627.83 11.08 490896.75 717628.49 11.08 490899.23 717633.35 11.08 490893.69 717636.11 11.08 490890.41 717629.71 11.08 490886.11 717621.09 11.08 490886.67 717620.81 11.08 490885.7 717618.88 11.08 490885.17 717619.16 11.08 490880.57 717609.99 11.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.42</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491611.05 716965.84 3.05 491615.62 716972.42 3.05 491618.24 716970.63 3.05 491620.39 716973.75 3.05 491626.24 716969.66 3.05 491624.08 716966.56 3.05 491625.02 716965.88 3.05 491619.41 716957.86 3.05 491616.17 716960.12 3.05 491615.17 716959.95 3.05 491613.61 716961.07 3.05 491613.43 716962.03 3.05 491612.98 716964.49 3.05 491611.91 716965.24 3.05 491611.05 716965.84 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491611.05 716965.84 3.05 491611.91 716965.24 3.05 491611.91 716965.24 9.47 491611.05 716965.84 9.47 491611.05 716965.84 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491611.91 716965.24 3.05 491612.98 716964.49 3.05 491612.98 716964.49 9.47 491611.91 716965.24 9.47 491611.91 716965.24 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491612.98 716964.49 3.05 491613.43 716962.03 3.05 491613.43 716962.03 9.47 491612.98 716964.49 9.47 491612.98 716964.49 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491613.43 716962.03 3.05 491613.61 716961.07 3.05 491613.61 716961.07 9.47 491613.43 716962.03 9.47 491613.43 716962.03 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491613.61 716961.07 3.05 491615.17 716959.95 3.05 491615.17 716959.95 9.47 491613.61 716961.07 9.47 491613.61 716961.07 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491615.17 716959.95 3.05 491616.17 716960.12 3.05 491616.17 716960.12 9.47 491615.17 716959.95 9.47 491615.17 716959.95 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491616.17 716960.12 3.05 491619.41 716957.86 3.05 491619.41 716957.86 9.47 491616.17 716960.12 9.47 491616.17 716960.12 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491619.41 716957.86 3.05 491625.02 716965.88 3.05 491625.02 716965.88 9.47 491619.41 716957.86 9.47 491619.41 716957.86 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491625.02 716965.88 3.05 491624.08 716966.56 3.05 491624.08 716966.56 9.47 491625.02 716965.88 9.47 491625.02 716965.88 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491624.08 716966.56 3.05 491626.24 716969.66 3.05 491626.24 716969.66 9.47 491624.08 716966.56 9.47 491624.08 716966.56 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491626.24 716969.66 3.05 491620.39 716973.75 3.05 491620.39 716973.75 9.47 491626.24 716969.66 9.47 491626.24 716969.66 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491620.39 716973.75 3.05 491618.24 716970.63 3.05 491618.24 716970.63 9.47 491620.39 716973.75 9.47 491620.39 716973.75 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491618.24 716970.63 3.05 491615.62 716972.42 3.05 491615.62 716972.42 9.47 491618.24 716970.63 9.47 491618.24 716970.63 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491615.62 716972.42 3.05 491611.05 716965.84 3.05 491611.05 716965.84 9.47 491615.62 716972.42 9.47 491615.62 716972.42 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FFA0-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491611.05 716965.84 9.47 491611.91 716965.24 9.47 491612.98 716964.49 9.47 491613.43 716962.03 9.47 491613.61 716961.07 9.47 491615.17 716959.95 9.47 491616.17 716960.12 9.47 491619.41 716957.86 9.47 491625.02 716965.88 9.47 491624.08 716966.56 9.47 491626.24 716969.66 9.47 491620.39 716973.75 9.47 491618.24 716970.63 9.47 491615.62 716972.42 9.47 491611.05 716965.84 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-61A4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-61A4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.64</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490917.42 717636.52 3.22 490920.08 717642.02 3.22 490927.81 717658.01 3.22 490927.95 717658.28 3.22 490941.47 717651.77 3.22 490931.02 717630.09 3.22 490917.42 717636.52 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490917.42 717636.52 3.22 490931.02 717630.09 3.22 490931.02 717630.09 7.860000000000001 490917.42 717636.52 7.860000000000001 490917.42 717636.52 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490931.02 717630.09 3.22 490941.47 717651.77 3.22 490941.47 717651.77 7.860000000000001 490931.02 717630.09 7.860000000000001 490931.02 717630.09 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490941.47 717651.77 3.22 490927.95 717658.28 3.22 490927.95 717658.28 7.860000000000001 490941.47 717651.77 7.860000000000001 490941.47 717651.77 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490927.95 717658.28 3.22 490927.81 717658.01 3.22 490927.81 717658.01 7.860000000000001 490927.95 717658.28 7.860000000000001 490927.95 717658.28 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490927.81 717658.01 3.22 490920.08 717642.02 3.22 490920.08 717642.02 7.860000000000001 490927.81 717658.01 7.860000000000001 490927.81 717658.01 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490920.08 717642.02 3.22 490917.42 717636.52 3.22 490917.42 717636.52 7.860000000000001 490920.08 717642.02 7.860000000000001 490920.08 717642.02 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-61A4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490917.42 717636.52 7.860000000000001 490931.02 717630.09 7.860000000000001 490941.47 717651.77 7.860000000000001 490927.95 717658.28 7.860000000000001 490927.81 717658.01 7.860000000000001 490920.08 717642.02 7.860000000000001 490917.42 717636.52 7.860000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CE05-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CE05-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.18</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE05-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491581.19 716941.81 3.23 491584.86 716947.04 3.23 491591.45 716942.44 3.23 491587.78 716937.21 3.23 491581.19 716941.81 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE05-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491581.19 716941.81 3.23 491587.78 716937.21 3.23 491587.78 716937.21 8.41 491581.19 716941.81 8.41 491581.19 716941.81 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE05-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491587.78 716937.21 3.23 491591.45 716942.44 3.23 491591.45 716942.44 8.41 491587.78 716937.21 8.41 491587.78 716937.21 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE05-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491591.45 716942.44 3.23 491584.86 716947.04 3.23 491584.86 716947.04 8.41 491591.45 716942.44 8.41 491591.45 716942.44 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE05-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491584.86 716947.04 3.23 491581.19 716941.81 3.23 491581.19 716941.81 8.41 491584.86 716947.04 8.41 491584.86 716947.04 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE05-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491581.19 716941.81 8.41 491587.78 716937.21 8.41 491591.45 716942.44 8.41 491584.86 716947.04 8.41 491581.19 716941.81 8.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CE04-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CE04-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.18</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE04-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491757.15 716557.48 4.54 491765.94 716579.01 4.54 491773.93 716575.75 4.54 491765.13 716554.37 4.54 491757.15 716557.48 4.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE04-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491757.15 716557.48 4.54 491765.13 716554.37 4.54 491765.13 716554.37 9.72 491757.15 716557.48 9.72 491757.15 716557.48 4.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE04-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491765.13 716554.37 4.54 491773.93 716575.75 4.54 491773.93 716575.75 9.72 491765.13 716554.37 9.72 491765.13 716554.37 4.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE04-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491773.93 716575.75 4.54 491765.94 716579.01 4.54 491765.94 716579.01 9.72 491773.93 716575.75 9.72 491773.93 716575.75 4.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE04-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491765.94 716579.01 4.54 491757.15 716557.48 4.54 491757.15 716557.48 9.72 491765.94 716579.01 9.72 491765.94 716579.01 4.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE04-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491757.15 716557.48 9.72 491765.13 716554.37 9.72 491773.93 716575.75 9.72 491765.94 716579.01 9.72 491757.15 716557.48 9.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CE03-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CE03-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.06</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE03-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491487.8 717177.25 3.38 491467.67 717190.36 3.38 491472.91 717198.57 3.38 491493.04 717185.44 3.38 491487.8 717177.25 3.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE03-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491487.8 717177.25 3.38 491493.04 717185.44 3.38 491493.04 717185.44 9.44 491487.8 717177.25 9.44 491487.8 717177.25 3.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE03-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491493.04 717185.44 3.38 491472.91 717198.57 3.38 491472.91 717198.57 9.44 491493.04 717185.44 9.44 491493.04 717185.44 3.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE03-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491472.91 717198.57 3.38 491467.67 717190.36 3.38 491467.67 717190.36 9.44 491472.91 717198.57 9.44 491472.91 717198.57 3.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE03-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491467.67 717190.36 3.38 491487.8 717177.25 3.38 491487.8 717177.25 9.44 491467.67 717190.36 9.44 491467.67 717190.36 3.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE03-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491487.8 717177.25 9.44 491493.04 717185.44 9.44 491472.91 717198.57 9.44 491467.67 717190.36 9.44 491487.8 717177.25 9.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-012F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-012F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.35</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.85 718277.42 2.11 490074.35 718283.92 2.11 490091.89 718282.61 2.11 490091.18 718272.84 2.11 490087.58 718273.11 2.11 490087.34 718269.51 2.11 490077.56 718270.23 2.11 490078.04 718277.12 2.11 490073.85 718277.42 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.85 718277.42 2.11 490078.04 718277.12 2.11 490078.04 718277.12 6.459999999999999 490073.85 718277.42 6.459999999999999 490073.85 718277.42 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490078.04 718277.12 2.11 490077.56 718270.23 2.11 490077.56 718270.23 6.459999999999999 490078.04 718277.12 6.459999999999999 490078.04 718277.12 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490077.56 718270.23 2.11 490087.34 718269.51 2.11 490087.34 718269.51 6.459999999999999 490077.56 718270.23 6.459999999999999 490077.56 718270.23 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490087.34 718269.51 2.11 490087.58 718273.11 2.11 490087.58 718273.11 6.459999999999999 490087.34 718269.51 6.459999999999999 490087.34 718269.51 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490087.58 718273.11 2.11 490091.18 718272.84 2.11 490091.18 718272.84 6.459999999999999 490087.58 718273.11 6.459999999999999 490087.58 718273.11 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490091.18 718272.84 2.11 490091.89 718282.61 2.11 490091.89 718282.61 6.459999999999999 490091.18 718272.84 6.459999999999999 490091.18 718272.84 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490091.89 718282.61 2.11 490074.35 718283.92 2.11 490074.35 718283.92 6.459999999999999 490091.89 718282.61 6.459999999999999 490091.89 718282.61 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490074.35 718283.92 2.11 490073.85 718277.42 2.11 490073.85 718277.42 6.459999999999999 490074.35 718283.92 6.459999999999999 490074.35 718283.92 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.85 718277.42 6.459999999999999 490078.04 718277.12 6.459999999999999 490077.56 718270.23 6.459999999999999 490087.34 718269.51 6.459999999999999 490087.58 718273.11 6.459999999999999 490091.18 718272.84 6.459999999999999 490091.89 718282.61 6.459999999999999 490074.35 718283.92 6.459999999999999 490073.85 718277.42 6.459999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-012E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-012E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.42</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490036.01 718343.19 2.02 490042.28 718345.16 2.02 490043.32 718342.1 2.02 490045.83 718342.87 2.02 490046.45 718341.09 2.02 490047.09 718339.22 2.02 490044.54 718338.35 2.02 490045.44 718335.63 2.02 490039.15 718333.67 2.02 490036.01 718343.19 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490036.01 718343.19 2.02 490039.15 718333.67 2.02 490039.15 718333.67 5.4350000000000005 490036.01 718343.19 5.4350000000000005 490036.01 718343.19 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490039.15 718333.67 2.02 490045.44 718335.63 2.02 490045.44 718335.63 5.4350000000000005 490039.15 718333.67 5.4350000000000005 490039.15 718333.67 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490045.44 718335.63 2.02 490044.54 718338.35 2.02 490044.54 718338.35 5.4350000000000005 490045.44 718335.63 5.4350000000000005 490045.44 718335.63 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490044.54 718338.35 2.02 490047.09 718339.22 2.02 490047.09 718339.22 5.4350000000000005 490044.54 718338.35 5.4350000000000005 490044.54 718338.35 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490047.09 718339.22 2.02 490046.45 718341.09 2.02 490046.45 718341.09 5.4350000000000005 490047.09 718339.22 5.4350000000000005 490047.09 718339.22 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490046.45 718341.09 2.02 490045.83 718342.87 2.02 490045.83 718342.87 5.4350000000000005 490046.45 718341.09 5.4350000000000005 490046.45 718341.09 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490045.83 718342.87 2.02 490043.32 718342.1 2.02 490043.32 718342.1 5.4350000000000005 490045.83 718342.87 5.4350000000000005 490045.83 718342.87 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490043.32 718342.1 2.02 490042.28 718345.16 2.02 490042.28 718345.16 5.4350000000000005 490043.32 718342.1 5.4350000000000005 490043.32 718342.1 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490042.28 718345.16 2.02 490036.01 718343.19 2.02 490036.01 718343.19 5.4350000000000005 490042.28 718345.16 5.4350000000000005 490042.28 718345.16 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-012E-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490036.01 718343.19 5.4350000000000005 490039.15 718333.67 5.4350000000000005 490045.44 718335.63 5.4350000000000005 490044.54 718338.35 5.4350000000000005 490047.09 718339.22 5.4350000000000005 490046.45 718341.09 5.4350000000000005 490045.83 718342.87 5.4350000000000005 490043.32 718342.1 5.4350000000000005 490042.28 718345.16 5.4350000000000005 490036.01 718343.19 5.4350000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.59</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490685.83 718154.91 2.32 490687.42 718155.1 2.32 490689.05 718157.18 2.32 490688.84 718159.13 2.32 490693.42 718164.78 2.32 490695.39 718165.02 2.32 490698.52 718168.9 2.32 490702.18 718165.97 2.32 490703.59 718166.12 2.32 490705.08 718164.94 2.32 490705.21 718163.55 2.32 490708.78 718160.66 2.32 490696.12 718144.97 2.32 490687.76 718151.67 2.32 490686.16 718151.51 2.32 490685.83 718154.91 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490685.83 718154.91 2.32 490686.16 718151.51 2.32 490686.16 718151.51 11.91 490685.83 718154.91 11.91 490685.83 718154.91 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490686.16 718151.51 2.32 490687.76 718151.67 2.32 490687.76 718151.67 11.91 490686.16 718151.51 11.91 490686.16 718151.51 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490687.76 718151.67 2.32 490696.12 718144.97 2.32 490696.12 718144.97 11.91 490687.76 718151.67 11.91 490687.76 718151.67 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490696.12 718144.97 2.32 490708.78 718160.66 2.32 490708.78 718160.66 11.91 490696.12 718144.97 11.91 490696.12 718144.97 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490708.78 718160.66 2.32 490705.21 718163.55 2.32 490705.21 718163.55 11.91 490708.78 718160.66 11.91 490708.78 718160.66 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490705.21 718163.55 2.32 490705.08 718164.94 2.32 490705.08 718164.94 11.91 490705.21 718163.55 11.91 490705.21 718163.55 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490705.08 718164.94 2.32 490703.59 718166.12 2.32 490703.59 718166.12 11.91 490705.08 718164.94 11.91 490705.08 718164.94 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490703.59 718166.12 2.32 490702.18 718165.97 2.32 490702.18 718165.97 11.91 490703.59 718166.12 11.91 490703.59 718166.12 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490702.18 718165.97 2.32 490698.52 718168.9 2.32 490698.52 718168.9 11.91 490702.18 718165.97 11.91 490702.18 718165.97 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490698.52 718168.9 2.32 490695.39 718165.02 2.32 490695.39 718165.02 11.91 490698.52 718168.9 11.91 490698.52 718168.9 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490695.39 718165.02 2.32 490693.42 718164.78 2.32 490693.42 718164.78 11.91 490695.39 718165.02 11.91 490695.39 718165.02 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490693.42 718164.78 2.32 490688.84 718159.13 2.32 490688.84 718159.13 11.91 490693.42 718164.78 11.91 490693.42 718164.78 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490688.84 718159.13 2.32 490689.05 718157.18 2.32 490689.05 718157.18 11.91 490688.84 718159.13 11.91 490688.84 718159.13 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490689.05 718157.18 2.32 490687.42 718155.1 2.32 490687.42 718155.1 11.91 490689.05 718157.18 11.91 490689.05 718157.18 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490687.42 718155.1 2.32 490685.83 718154.91 2.32 490685.83 718154.91 11.91 490687.42 718155.1 11.91 490687.42 718155.1 2.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01F4-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490685.83 718154.91 11.91 490686.16 718151.51 11.91 490687.76 718151.67 11.91 490696.12 718144.97 11.91 490708.78 718160.66 11.91 490705.21 718163.55 11.91 490705.08 718164.94 11.91 490703.59 718166.12 11.91 490702.18 718165.97 11.91 490698.52 718168.9 11.91 490695.39 718165.02 11.91 490693.42 718164.78 11.91 490688.84 718159.13 11.91 490689.05 718157.18 11.91 490687.42 718155.1 11.91 490685.83 718154.91 11.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD2E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD2E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490621.88 717993.01 2.1 490622.5 717994.22 2.1 490623.35 717993.76 2.1 490624.23 717995.46 2.1 490623.34 717995.9 2.1 490624.6 717998.28 2.1 490629.08 717996.05 2.1 490626.39 717990.66 2.1 490621.88 717993.01 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490621.88 717993.01 2.1 490626.39 717990.66 2.1 490626.39 717990.66 4.53 490621.88 717993.01 4.53 490621.88 717993.01 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490626.39 717990.66 2.1 490629.08 717996.05 2.1 490629.08 717996.05 4.53 490626.39 717990.66 4.53 490626.39 717990.66 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490629.08 717996.05 2.1 490624.6 717998.28 2.1 490624.6 717998.28 4.53 490629.08 717996.05 4.53 490629.08 717996.05 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490624.6 717998.28 2.1 490623.34 717995.9 2.1 490623.34 717995.9 4.53 490624.6 717998.28 4.53 490624.6 717998.28 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490623.34 717995.9 2.1 490624.23 717995.46 2.1 490624.23 717995.46 4.53 490623.34 717995.9 4.53 490623.34 717995.9 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490624.23 717995.46 2.1 490623.35 717993.76 2.1 490623.35 717993.76 4.53 490624.23 717995.46 4.53 490624.23 717995.46 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490623.35 717993.76 2.1 490622.5 717994.22 2.1 490622.5 717994.22 4.53 490623.35 717993.76 4.53 490623.35 717993.76 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490622.5 717994.22 2.1 490621.88 717993.01 2.1 490621.88 717993.01 4.53 490622.5 717994.22 4.53 490622.5 717994.22 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490621.88 717993.01 4.53 490626.39 717990.66 4.53 490629.08 717996.05 4.53 490624.6 717998.28 4.53 490623.34 717995.9 4.53 490624.23 717995.46 4.53 490623.35 717993.76 4.53 490622.5 717994.22 4.53 490621.88 717993.01 4.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD2F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD2F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490653.08 717989.09 1.99 490655.96 717995.12 1.99 490673.99 717986.52 1.99 490671.07 717980.47 1.99 490653.08 717989.09 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490653.08 717989.09 1.99 490671.07 717980.47 1.99 490671.07 717980.47 4.59 490653.08 717989.09 4.59 490653.08 717989.09 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490671.07 717980.47 1.99 490673.99 717986.52 1.99 490673.99 717986.52 4.59 490671.07 717980.47 4.59 490671.07 717980.47 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490673.99 717986.52 1.99 490655.96 717995.12 1.99 490655.96 717995.12 4.59 490673.99 717986.52 4.59 490673.99 717986.52 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490655.96 717995.12 1.99 490653.08 717989.09 1.99 490653.08 717989.09 4.59 490655.96 717995.12 4.59 490655.96 717995.12 1.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD2F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490653.08 717989.09 4.59 490671.07 717980.47 4.59 490673.99 717986.52 4.59 490655.96 717995.12 4.59 490653.08 717989.09 4.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02BF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02BF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.57</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02BF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491556.01 716940.09 3.23 491563.13 716950.24 3.23 491569.17 716946.01 3.23 491566.87 716942.73 3.23 491568.51 716941.58 3.23 491566.01 716937.99 3.23 491564.36 716939.15 3.23 491562.05 716935.89 3.23 491556.01 716940.09 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02BF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491556.01 716940.09 3.23 491562.05 716935.89 3.23 491562.05 716935.89 8.8 491556.01 716940.09 8.8 491556.01 716940.09 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02BF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491562.05 716935.89 3.23 491564.36 716939.15 3.23 491564.36 716939.15 8.8 491562.05 716935.89 8.8 491562.05 716935.89 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02BF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491564.36 716939.15 3.23 491566.01 716937.99 3.23 491566.01 716937.99 8.8 491564.36 716939.15 8.8 491564.36 716939.15 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02BF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491566.01 716937.99 3.23 491568.51 716941.58 3.23 491568.51 716941.58 8.8 491566.01 716937.99 8.8 491566.01 716937.99 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02BF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491568.51 716941.58 3.23 491566.87 716942.73 3.23 491566.87 716942.73 8.8 491568.51 716941.58 8.8 491568.51 716941.58 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02BF-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491566.87 716942.73 3.23 491569.17 716946.01 3.23 491569.17 716946.01 8.8 491566.87 716942.73 8.8 491566.87 716942.73 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02BF-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491569.17 716946.01 3.23 491563.13 716950.24 3.23 491563.13 716950.24 8.8 491569.17 716946.01 8.8 491569.17 716946.01 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02BF-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491563.13 716950.24 3.23 491556.01 716940.09 3.23 491556.01 716940.09 8.8 491563.13 716950.24 8.8 491563.13 716950.24 3.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02BF-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491556.01 716940.09 8.8 491562.05 716935.89 8.8 491564.36 716939.15 8.8 491566.01 716937.99 8.8 491568.51 716941.58 8.8 491566.87 716942.73 8.8 491569.17 716946.01 8.8 491563.13 716950.24 8.8 491556.01 716940.09 8.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.58</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491560.84 716741.31 4.41 491565.09 716744.63 4.41 491563.06 716747.21 4.41 491571.63 716753.96 4.41 491571.8 716753.7 4.41 491573.94 716755.35 4.41 491579.17 716748.66 4.41 491577.08 716747 4.41 491582.5 716740 4.41 491573.89 716733.33 4.41 491570.16 716738.07 4.41 491565.88 716734.68 4.41 491560.84 716741.31 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491560.84 716741.31 4.41 491565.88 716734.68 4.41 491565.88 716734.68 10.99 491560.84 716741.31 10.99 491560.84 716741.31 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491565.88 716734.68 4.41 491570.16 716738.07 4.41 491570.16 716738.07 10.99 491565.88 716734.68 10.99 491565.88 716734.68 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491570.16 716738.07 4.41 491573.89 716733.33 4.41 491573.89 716733.33 10.99 491570.16 716738.07 10.99 491570.16 716738.07 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491573.89 716733.33 4.41 491582.5 716740 4.41 491582.5 716740 10.99 491573.89 716733.33 10.99 491573.89 716733.33 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491582.5 716740 4.41 491577.08 716747 4.41 491577.08 716747 10.99 491582.5 716740 10.99 491582.5 716740 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491577.08 716747 4.41 491579.17 716748.66 4.41 491579.17 716748.66 10.99 491577.08 716747 10.99 491577.08 716747 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491579.17 716748.66 4.41 491573.94 716755.35 4.41 491573.94 716755.35 10.99 491579.17 716748.66 10.99 491579.17 716748.66 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491573.94 716755.35 4.41 491571.8 716753.7 4.41 491571.8 716753.7 10.99 491573.94 716755.35 10.99 491573.94 716755.35 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491571.8 716753.7 4.41 491571.63 716753.96 4.41 491571.63 716753.96 10.99 491571.8 716753.7 10.99 491571.8 716753.7 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491571.63 716753.96 4.41 491563.06 716747.21 4.41 491563.06 716747.21 10.99 491571.63 716753.96 10.99 491571.63 716753.96 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491563.06 716747.21 4.41 491565.09 716744.63 4.41 491565.09 716744.63 10.99 491563.06 716747.21 10.99 491563.06 716747.21 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491565.09 716744.63 4.41 491560.84 716741.31 4.41 491560.84 716741.31 10.99 491565.09 716744.63 10.99 491565.09 716744.63 4.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C4-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491560.84 716741.31 10.99 491565.88 716734.68 10.99 491570.16 716738.07 10.99 491573.89 716733.33 10.99 491582.5 716740 10.99 491577.08 716747 10.99 491579.17 716748.66 10.99 491573.94 716755.35 10.99 491571.8 716753.7 10.99 491571.63 716753.96 10.99 491563.06 716747.21 10.99 491565.09 716744.63 10.99 491560.84 716741.31 10.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.82</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491588.67 716920.56 3.22 491588.88 716920.85 3.22 491590.9 716923.72 3.22 491591.37 716923.37 3.22 491592.63 716925.16 3.22 491590.92 716926.37 3.22 491590.98 716926.46 3.22 491593.78 716930.48 3.22 491605.02 716922.62 3.22 491603.16 716919.89 3.22 491602.7 716919.23 3.22 491601.69 716919.93 3.22 491599.75 716917.13 3.22 491597.75 716914.24 3.22 491588.67 716920.56 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491588.67 716920.56 3.22 491597.75 716914.24 3.22 491597.75 716914.24 10.040000000000001 491588.67 716920.56 10.040000000000001 491588.67 716920.56 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491597.75 716914.24 3.22 491599.75 716917.13 3.22 491599.75 716917.13 10.040000000000001 491597.75 716914.24 10.040000000000001 491597.75 716914.24 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491599.75 716917.13 3.22 491601.69 716919.93 3.22 491601.69 716919.93 10.040000000000001 491599.75 716917.13 10.040000000000001 491599.75 716917.13 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491601.69 716919.93 3.22 491602.7 716919.23 3.22 491602.7 716919.23 10.040000000000001 491601.69 716919.93 10.040000000000001 491601.69 716919.93 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491602.7 716919.23 3.22 491603.16 716919.89 3.22 491603.16 716919.89 10.040000000000001 491602.7 716919.23 10.040000000000001 491602.7 716919.23 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491603.16 716919.89 3.22 491605.02 716922.62 3.22 491605.02 716922.62 10.040000000000001 491603.16 716919.89 10.040000000000001 491603.16 716919.89 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491605.02 716922.62 3.22 491593.78 716930.48 3.22 491593.78 716930.48 10.040000000000001 491605.02 716922.62 10.040000000000001 491605.02 716922.62 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491593.78 716930.48 3.22 491590.98 716926.46 3.22 491590.98 716926.46 10.040000000000001 491593.78 716930.48 10.040000000000001 491593.78 716930.48 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491590.98 716926.46 3.22 491590.92 716926.37 3.22 491590.92 716926.37 10.040000000000001 491590.98 716926.46 10.040000000000001 491590.98 716926.46 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491590.92 716926.37 3.22 491592.63 716925.16 3.22 491592.63 716925.16 10.040000000000001 491590.92 716926.37 10.040000000000001 491590.92 716926.37 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491592.63 716925.16 3.22 491591.37 716923.37 3.22 491591.37 716923.37 10.040000000000001 491592.63 716925.16 10.040000000000001 491592.63 716925.16 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491591.37 716923.37 3.22 491590.9 716923.72 3.22 491590.9 716923.72 10.040000000000001 491591.37 716923.37 10.040000000000001 491591.37 716923.37 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491590.9 716923.72 3.22 491588.88 716920.85 3.22 491588.88 716920.85 10.040000000000001 491590.9 716923.72 10.040000000000001 491590.9 716923.72 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491588.88 716920.85 3.22 491588.67 716920.56 3.22 491588.67 716920.56 10.040000000000001 491588.88 716920.85 10.040000000000001 491588.88 716920.85 3.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C3-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491588.67 716920.56 10.040000000000001 491597.75 716914.24 10.040000000000001 491599.75 716917.13 10.040000000000001 491601.69 716919.93 10.040000000000001 491602.7 716919.23 10.040000000000001 491603.16 716919.89 10.040000000000001 491605.02 716922.62 10.040000000000001 491593.78 716930.48 10.040000000000001 491590.98 716926.46 10.040000000000001 491590.92 716926.37 10.040000000000001 491592.63 716925.16 10.040000000000001 491591.37 716923.37 10.040000000000001 491590.9 716923.72 10.040000000000001 491588.88 716920.85 10.040000000000001 491588.67 716920.56 10.040000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.88</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491492.25 716986.3 3.05 491500.09 716997.56 3.05 491503.49 716995.21 3.05 491502.76 716994.22 3.05 491508.47 716990.28 3.05 491502.18 716981.24 3.05 491499 716983.42 3.05 491497.22 716984.66 3.05 491496.38 716983.43 3.05 491492.25 716986.3 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491492.25 716986.3 3.05 491496.38 716983.43 3.05 491496.38 716983.43 8.925 491492.25 716986.3 8.925 491492.25 716986.3 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491496.38 716983.43 3.05 491497.22 716984.66 3.05 491497.22 716984.66 8.925 491496.38 716983.43 8.925 491496.38 716983.43 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491497.22 716984.66 3.05 491499 716983.42 3.05 491499 716983.42 8.925 491497.22 716984.66 8.925 491497.22 716984.66 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491499 716983.42 3.05 491502.18 716981.24 3.05 491502.18 716981.24 8.925 491499 716983.42 8.925 491499 716983.42 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491502.18 716981.24 3.05 491508.47 716990.28 3.05 491508.47 716990.28 8.925 491502.18 716981.24 8.925 491502.18 716981.24 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491508.47 716990.28 3.05 491502.76 716994.22 3.05 491502.76 716994.22 8.925 491508.47 716990.28 8.925 491508.47 716990.28 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491502.76 716994.22 3.05 491503.49 716995.21 3.05 491503.49 716995.21 8.925 491502.76 716994.22 8.925 491502.76 716994.22 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491503.49 716995.21 3.05 491500.09 716997.56 3.05 491500.09 716997.56 8.925 491503.49 716995.21 8.925 491503.49 716995.21 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491500.09 716997.56 3.05 491492.25 716986.3 3.05 491492.25 716986.3 8.925 491500.09 716997.56 8.925 491500.09 716997.56 3.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C2-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491492.25 716986.3 8.925 491496.38 716983.43 8.925 491497.22 716984.66 8.925 491499 716983.42 8.925 491502.18 716981.24 8.925 491508.47 716990.28 8.925 491502.76 716994.22 8.925 491503.49 716995.21 8.925 491500.09 716997.56 8.925 491492.25 716986.3 8.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.34</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491465.5 717154.95 3.44 491457.08 717160.57 3.44 491460.24 717165.16 3.44 491460.02 717165.32 3.44 491460.3 717165.74 3.44 491460.54 717165.59 3.44 491464.94 717171.94 3.44 491473.17 717166.39 3.44 491471.91 717164.51 3.44 491474.19 717163.07 3.44 491471.33 717158.83 3.44 491469.07 717160.3 3.44 491465.5 717154.95 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491465.5 717154.95 3.44 491469.07 717160.3 3.44 491469.07 717160.3 8.78 491465.5 717154.95 8.78 491465.5 717154.95 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491469.07 717160.3 3.44 491471.33 717158.83 3.44 491471.33 717158.83 8.78 491469.07 717160.3 8.78 491469.07 717160.3 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491471.33 717158.83 3.44 491474.19 717163.07 3.44 491474.19 717163.07 8.78 491471.33 717158.83 8.78 491471.33 717158.83 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491474.19 717163.07 3.44 491471.91 717164.51 3.44 491471.91 717164.51 8.78 491474.19 717163.07 8.78 491474.19 717163.07 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491471.91 717164.51 3.44 491473.17 717166.39 3.44 491473.17 717166.39 8.78 491471.91 717164.51 8.78 491471.91 717164.51 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491473.17 717166.39 3.44 491464.94 717171.94 3.44 491464.94 717171.94 8.78 491473.17 717166.39 8.78 491473.17 717166.39 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491464.94 717171.94 3.44 491460.54 717165.59 3.44 491460.54 717165.59 8.78 491464.94 717171.94 8.78 491464.94 717171.94 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491460.54 717165.59 3.44 491460.3 717165.74 3.44 491460.3 717165.74 8.78 491460.54 717165.59 8.78 491460.54 717165.59 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491460.3 717165.74 3.44 491460.02 717165.32 3.44 491460.02 717165.32 8.78 491460.3 717165.74 8.78 491460.3 717165.74 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491460.02 717165.32 3.44 491460.24 717165.16 3.44 491460.24 717165.16 8.78 491460.02 717165.32 8.78 491460.02 717165.32 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491460.24 717165.16 3.44 491457.08 717160.57 3.44 491457.08 717160.57 8.78 491460.24 717165.16 8.78 491460.24 717165.16 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491457.08 717160.57 3.44 491465.5 717154.95 3.44 491465.5 717154.95 8.78 491457.08 717160.57 8.78 491457.08 717160.57 3.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-02C1-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491465.5 717154.95 8.78 491469.07 717160.3 8.78 491471.33 717158.83 8.78 491474.19 717163.07 8.78 491471.91 717164.51 8.78 491473.17 717166.39 8.78 491464.94 717171.94 8.78 491460.54 717165.59 8.78 491460.3 717165.74 8.78 491460.02 717165.32 8.78 491460.24 717165.16 8.78 491457.08 717160.57 8.78 491465.5 717154.95 8.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489871.94 718297.5 2.08 489880.82 718298.49 2.08 489880.6 718300.55 2.08 489890.1 718301.56 2.08 489891.47 718290.98 2.08 489886.6 718290.45 2.08 489879.66 718289.54 2.08 489879.52 718290.48 2.08 489879.27 718292.24 2.08 489872.72 718291.49 2.08 489871.94 718297.5 2.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489871.94 718297.5 2.08 489872.72 718291.49 2.08 489872.72 718291.49 6.07 489871.94 718297.5 6.07 489871.94 718297.5 2.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489872.72 718291.49 2.08 489879.27 718292.24 2.08 489879.27 718292.24 6.07 489872.72 718291.49 6.07 489872.72 718291.49 2.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489879.27 718292.24 2.08 489879.52 718290.48 2.08 489879.52 718290.48 6.07 489879.27 718292.24 6.07 489879.27 718292.24 2.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489879.52 718290.48 2.08 489879.66 718289.54 2.08 489879.66 718289.54 6.07 489879.52 718290.48 6.07 489879.52 718290.48 2.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489879.66 718289.54 2.08 489886.6 718290.45 2.08 489886.6 718290.45 6.07 489879.66 718289.54 6.07 489879.66 718289.54 2.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489886.6 718290.45 2.08 489891.47 718290.98 2.08 489891.47 718290.98 6.07 489886.6 718290.45 6.07 489886.6 718290.45 2.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489891.47 718290.98 2.08 489890.1 718301.56 2.08 489890.1 718301.56 6.07 489891.47 718290.98 6.07 489891.47 718290.98 2.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489890.1 718301.56 2.08 489880.6 718300.55 2.08 489880.6 718300.55 6.07 489890.1 718301.56 6.07 489890.1 718301.56 2.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489880.6 718300.55 2.08 489880.82 718298.49 2.08 489880.82 718298.49 6.07 489880.6 718300.55 6.07 489880.6 718300.55 2.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489880.82 718298.49 2.08 489871.94 718297.5 2.08 489871.94 718297.5 6.07 489880.82 718298.49 6.07 489880.82 718298.49 2.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5E6F-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>489871.94 718297.5 6.07 489872.72 718291.49 6.07 489879.27 718292.24 6.07 489879.52 718290.48 6.07 489879.66 718289.54 6.07 489886.6 718290.45 6.07 489891.47 718290.98 6.07 489890.1 718301.56 6.07 489880.6 718300.55 6.07 489880.82 718298.49 6.07 489871.94 718297.5 6.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0134-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0134-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.76</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0134-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490614.3 718029.51 1.69 490617.45 718035.68 1.69 490624.79 718031.86 1.69 490623.02 718028.34 1.69 490625 718027.3 1.69 490623.64 718024.63 1.69 490621.77 718025.6 1.69 490614.3 718029.51 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0134-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490614.3 718029.51 1.69 490621.77 718025.6 1.69 490621.77 718025.6 7.449999999999999 490614.3 718029.51 7.449999999999999 490614.3 718029.51 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0134-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490621.77 718025.6 1.69 490623.64 718024.63 1.69 490623.64 718024.63 7.449999999999999 490621.77 718025.6 7.449999999999999 490621.77 718025.6 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0134-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490623.64 718024.63 1.69 490625 718027.3 1.69 490625 718027.3 7.449999999999999 490623.64 718024.63 7.449999999999999 490623.64 718024.63 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0134-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490625 718027.3 1.69 490623.02 718028.34 1.69 490623.02 718028.34 7.449999999999999 490625 718027.3 7.449999999999999 490625 718027.3 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0134-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490623.02 718028.34 1.69 490624.79 718031.86 1.69 490624.79 718031.86 7.449999999999999 490623.02 718028.34 7.449999999999999 490623.02 718028.34 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0134-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490624.79 718031.86 1.69 490617.45 718035.68 1.69 490617.45 718035.68 7.449999999999999 490624.79 718031.86 7.449999999999999 490624.79 718031.86 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0134-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490617.45 718035.68 1.69 490614.3 718029.51 1.69 490614.3 718029.51 7.449999999999999 490617.45 718035.68 7.449999999999999 490617.45 718035.68 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0134-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490614.3 718029.51 7.449999999999999 490621.77 718025.6 7.449999999999999 490623.64 718024.63 7.449999999999999 490625 718027.3 7.449999999999999 490623.02 718028.34 7.449999999999999 490624.79 718031.86 7.449999999999999 490617.45 718035.68 7.449999999999999 490614.3 718029.51 7.449999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0133-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0133-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0133-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490589.05 717979.9 1.96 490592.18 717986.13 1.96 490599.62 717982.29 1.96 490597.72 717978.56 1.96 490596.43 717976.05 1.96 490589.05 717979.9 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0133-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490589.05 717979.9 1.96 490596.43 717976.05 1.96 490596.43 717976.05 7.59 490589.05 717979.9 7.59 490589.05 717979.9 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0133-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490596.43 717976.05 1.96 490597.72 717978.56 1.96 490597.72 717978.56 7.59 490596.43 717976.05 7.59 490596.43 717976.05 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0133-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490597.72 717978.56 1.96 490599.62 717982.29 1.96 490599.62 717982.29 7.59 490597.72 717978.56 7.59 490597.72 717978.56 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0133-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490599.62 717982.29 1.96 490592.18 717986.13 1.96 490592.18 717986.13 7.59 490599.62 717982.29 7.59 490599.62 717982.29 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0133-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490592.18 717986.13 1.96 490589.05 717979.9 1.96 490589.05 717979.9 7.59 490592.18 717986.13 7.59 490592.18 717986.13 1.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0133-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490589.05 717979.9 7.59 490596.43 717976.05 7.59 490597.72 717978.56 7.59 490599.62 717982.29 7.59 490592.18 717986.13 7.59 490589.05 717979.9 7.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D210-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D210-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.78</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D210-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491007.08 717473.9 3.88 491024.25 717492.82 3.88 491031.35 717487.22 3.88 491013.24 717467.42 3.88 491007.08 717473.9 3.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D210-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491007.08 717473.9 3.88 491013.24 717467.42 3.88 491013.24 717467.42 10.66 491007.08 717473.9 10.66 491007.08 717473.9 3.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D210-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491013.24 717467.42 3.88 491031.35 717487.22 3.88 491031.35 717487.22 10.66 491013.24 717467.42 10.66 491013.24 717467.42 3.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D210-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491031.35 717487.22 3.88 491024.25 717492.82 3.88 491024.25 717492.82 10.66 491031.35 717487.22 10.66 491031.35 717487.22 3.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D210-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491024.25 717492.82 3.88 491007.08 717473.9 3.88 491007.08 717473.9 10.66 491024.25 717492.82 10.66 491024.25 717492.82 3.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D210-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491007.08 717473.9 10.66 491013.24 717467.42 10.66 491031.35 717487.22 10.66 491024.25 717492.82 10.66 491007.08 717473.9 10.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.33</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490635.04 718018.76 2.01 490635.64 718019.92 2.01 490636.5 718019.52 2.01 490637.3 718021.08 2.01 490636.48 718021.51 2.01 490637.25 718022.98 2.01 490641.61 718020.76 2.01 490641.03 718019.62 2.01 490641.14 718019.6 2.01 490639.44 718016.42 2.01 490635.04 718018.76 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490635.04 718018.76 2.01 490639.44 718016.42 2.01 490639.44 718016.42 4.34 490635.04 718018.76 4.34 490635.04 718018.76 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490639.44 718016.42 2.01 490641.14 718019.6 2.01 490641.14 718019.6 4.34 490639.44 718016.42 4.34 490639.44 718016.42 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490641.14 718019.6 2.01 490641.03 718019.62 2.01 490641.03 718019.62 4.34 490641.14 718019.6 4.34 490641.14 718019.6 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490641.03 718019.62 2.01 490641.61 718020.76 2.01 490641.61 718020.76 4.34 490641.03 718019.62 4.34 490641.03 718019.62 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490641.61 718020.76 2.01 490637.25 718022.98 2.01 490637.25 718022.98 4.34 490641.61 718020.76 4.34 490641.61 718020.76 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490637.25 718022.98 2.01 490636.48 718021.51 2.01 490636.48 718021.51 4.34 490637.25 718022.98 4.34 490637.25 718022.98 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490636.48 718021.51 2.01 490637.3 718021.08 2.01 490637.3 718021.08 4.34 490636.48 718021.51 4.34 490636.48 718021.51 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490637.3 718021.08 2.01 490636.5 718019.52 2.01 490636.5 718019.52 4.34 490637.3 718021.08 4.34 490637.3 718021.08 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490636.5 718019.52 2.01 490635.64 718019.92 2.01 490635.64 718019.92 4.34 490636.5 718019.52 4.34 490636.5 718019.52 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490635.64 718019.92 2.01 490635.04 718018.76 2.01 490635.04 718018.76 4.34 490635.64 718019.92 4.34 490635.64 718019.92 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CC66-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490635.04 718018.76 4.34 490639.44 718016.42 4.34 490641.14 718019.6 4.34 490641.03 718019.62 4.34 490641.61 718020.76 4.34 490637.25 718022.98 4.34 490636.48 718021.51 4.34 490637.3 718021.08 4.34 490636.5 718019.52 4.34 490635.64 718019.92 4.34 490635.04 718018.76 4.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491242.78 717258.43 4.7 491248.17 717261.57 4.7 491247.26 717263.11 4.7 491252.93 717266.4 4.7 491253.77 717264.95 4.7 491259.36 717267.96 4.7 491260.11 717266.52 4.7 491262.32 717267.74 4.7 491263.02 717266.43 4.7 491260.87 717265.26 4.7 491262.15 717263.02 4.7 491246.41 717252.19 4.7 491242.78 717258.43 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491242.78 717258.43 4.7 491246.41 717252.19 4.7 491246.41 717252.19 12.23 491242.78 717258.43 12.23 491242.78 717258.43 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491246.41 717252.19 4.7 491262.15 717263.02 4.7 491262.15 717263.02 12.23 491246.41 717252.19 12.23 491246.41 717252.19 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491262.15 717263.02 4.7 491260.87 717265.26 4.7 491260.87 717265.26 12.23 491262.15 717263.02 12.23 491262.15 717263.02 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491260.87 717265.26 4.7 491263.02 717266.43 4.7 491263.02 717266.43 12.23 491260.87 717265.26 12.23 491260.87 717265.26 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491263.02 717266.43 4.7 491262.32 717267.74 4.7 491262.32 717267.74 12.23 491263.02 717266.43 12.23 491263.02 717266.43 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491262.32 717267.74 4.7 491260.11 717266.52 4.7 491260.11 717266.52 12.23 491262.32 717267.74 12.23 491262.32 717267.74 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491260.11 717266.52 4.7 491259.36 717267.96 4.7 491259.36 717267.96 12.23 491260.11 717266.52 12.23 491260.11 717266.52 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491259.36 717267.96 4.7 491253.77 717264.95 4.7 491253.77 717264.95 12.23 491259.36 717267.96 12.23 491259.36 717267.96 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491253.77 717264.95 4.7 491252.93 717266.4 4.7 491252.93 717266.4 12.23 491253.77 717264.95 12.23 491253.77 717264.95 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491252.93 717266.4 4.7 491247.26 717263.11 4.7 491247.26 717263.11 12.23 491252.93 717266.4 12.23 491252.93 717266.4 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491247.26 717263.11 4.7 491248.17 717261.57 4.7 491248.17 717261.57 12.23 491247.26 717263.11 12.23 491247.26 717263.11 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491248.17 717261.57 4.7 491242.78 717258.43 4.7 491242.78 717258.43 12.23 491248.17 717261.57 12.23 491248.17 717261.57 4.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FE-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491242.78 717258.43 12.23 491246.41 717252.19 12.23 491262.15 717263.02 12.23 491260.87 717265.26 12.23 491263.02 717266.43 12.23 491262.32 717267.74 12.23 491260.11 717266.52 12.23 491259.36 717267.96 12.23 491253.77 717264.95 12.23 491252.93 717266.4 12.23 491247.26 717263.11 12.23 491248.17 717261.57 12.23 491242.78 717258.43 12.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-01FD-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-01FD-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.86</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FD-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490977.79 717506.45 3.58 490984.96 717512.38 3.58 490988.68 717515.45 3.58 490994.87 717508.05 3.58 490991.41 717505.14 3.58 490993.44 717502.68 3.58 490986.17 717496.54 3.58 490977.79 717506.45 3.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FD-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490977.79 717506.45 3.58 490986.17 717496.54 3.58 490986.17 717496.54 11.44 490977.79 717506.45 11.44 490977.79 717506.45 3.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FD-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490986.17 717496.54 3.58 490993.44 717502.68 3.58 490993.44 717502.68 11.44 490986.17 717496.54 11.44 490986.17 717496.54 3.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FD-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490993.44 717502.68 3.58 490991.41 717505.14 3.58 490991.41 717505.14 11.44 490993.44 717502.68 11.44 490993.44 717502.68 3.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FD-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490991.41 717505.14 3.58 490994.87 717508.05 3.58 490994.87 717508.05 11.44 490991.41 717505.14 11.44 490991.41 717505.14 3.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FD-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490994.87 717508.05 3.58 490988.68 717515.45 3.58 490988.68 717515.45 11.44 490994.87 717508.05 11.44 490994.87 717508.05 3.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FD-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490988.68 717515.45 3.58 490984.96 717512.38 3.58 490984.96 717512.38 11.44 490988.68 717515.45 11.44 490988.68 717515.45 3.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FD-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490984.96 717512.38 3.58 490977.79 717506.45 3.58 490977.79 717506.45 11.44 490984.96 717512.38 11.44 490984.96 717512.38 3.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-01FD-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490977.79 717506.45 11.44 490986.17 717496.54 11.44 490993.44 717502.68 11.44 490991.41 717505.14 11.44 490994.87 717508.05 11.44 490988.68 717515.45 11.44 490984.96 717512.38 11.44 490977.79 717506.45 11.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CE01-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CE01-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.23</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE01-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491209.21 717303.23 4.46 491220.94 717310.67 4.46 491226.87 717301.22 4.46 491237.47 717284.28 4.46 491225.94 717276.98 4.46 491209.21 717303.23 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE01-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491209.21 717303.23 4.46 491225.94 717276.98 4.46 491225.94 717276.98 9.69 491209.21 717303.23 9.69 491209.21 717303.23 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE01-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491225.94 717276.98 4.46 491237.47 717284.28 4.46 491237.47 717284.28 9.69 491225.94 717276.98 9.69 491225.94 717276.98 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE01-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491237.47 717284.28 4.46 491226.87 717301.22 4.46 491226.87 717301.22 9.69 491237.47 717284.28 9.69 491237.47 717284.28 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE01-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491226.87 717301.22 4.46 491220.94 717310.67 4.46 491220.94 717310.67 9.69 491226.87 717301.22 9.69 491226.87 717301.22 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE01-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491220.94 717310.67 4.46 491209.21 717303.23 4.46 491209.21 717303.23 9.69 491220.94 717310.67 9.69 491220.94 717310.67 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE01-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491209.21 717303.23 9.69 491225.94 717276.98 9.69 491237.47 717284.28 9.69 491226.87 717301.22 9.69 491220.94 717310.67 9.69 491209.21 717303.23 9.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-569E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-569E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.85</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-569E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491036.73 717488.91 3.38 491042.9 717495.29 3.38 491052.26 717486.34 3.38 491046.05 717479.91 3.38 491036.73 717488.91 3.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-569E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491036.73 717488.91 3.38 491046.05 717479.91 3.38 491046.05 717479.91 8.23 491036.73 717488.91 8.23 491036.73 717488.91 3.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-569E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491046.05 717479.91 3.38 491052.26 717486.34 3.38 491052.26 717486.34 8.23 491046.05 717479.91 8.23 491046.05 717479.91 3.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-569E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491052.26 717486.34 3.38 491042.9 717495.29 3.38 491042.9 717495.29 8.23 491052.26 717486.34 8.23 491052.26 717486.34 3.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-569E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491042.9 717495.29 3.38 491036.73 717488.91 3.38 491036.73 717488.91 8.23 491042.9 717495.29 8.23 491042.9 717495.29 3.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-569E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491036.73 717488.91 8.23 491046.05 717479.91 8.23 491052.26 717486.34 8.23 491042.9 717495.29 8.23 491036.73 717488.91 8.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD32-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD32-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.75</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD32-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490940.19 717605.65 2.93 490945.72 717615.73 2.93 490946.03 717615.55 2.93 490962.01 717606.81 2.93 490971.76 717601.45 2.93 490966.29 717591.39 2.93 490940.19 717605.65 2.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD32-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490940.19 717605.65 2.93 490966.29 717591.39 2.93 490966.29 717591.39 8.68 490940.19 717605.65 8.68 490940.19 717605.65 2.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD32-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490966.29 717591.39 2.93 490971.76 717601.45 2.93 490971.76 717601.45 8.68 490966.29 717591.39 8.68 490966.29 717591.39 2.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD32-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490971.76 717601.45 2.93 490962.01 717606.81 2.93 490962.01 717606.81 8.68 490971.76 717601.45 8.68 490971.76 717601.45 2.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD32-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490962.01 717606.81 2.93 490946.03 717615.55 2.93 490946.03 717615.55 8.68 490962.01 717606.81 8.68 490962.01 717606.81 2.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD32-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490946.03 717615.55 2.93 490945.72 717615.73 2.93 490945.72 717615.73 8.68 490946.03 717615.55 8.68 490946.03 717615.55 2.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD32-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490945.72 717615.73 2.93 490940.19 717605.65 2.93 490940.19 717605.65 8.68 490945.72 717615.73 8.68 490945.72 717615.73 2.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD32-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490940.19 717605.65 8.68 490966.29 717591.39 8.68 490971.76 717601.45 8.68 490962.01 717606.81 8.68 490946.03 717615.55 8.68 490945.72 717615.73 8.68 490940.19 717605.65 8.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD31-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD31-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.26</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD31-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490691.04 718210.03 2.11 490698.81 718220.05 2.11 490732.82 718193.43 2.11 490724.94 718183.51 2.11 490718.38 718188.67 2.11 490691.04 718210.03 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD31-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490691.04 718210.03 2.11 490718.38 718188.67 2.11 490718.38 718188.67 9.370000000000001 490691.04 718210.03 9.370000000000001 490691.04 718210.03 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD31-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490718.38 718188.67 2.11 490724.94 718183.51 2.11 490724.94 718183.51 9.370000000000001 490718.38 718188.67 9.370000000000001 490718.38 718188.67 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD31-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490724.94 718183.51 2.11 490732.82 718193.43 2.11 490732.82 718193.43 9.370000000000001 490724.94 718183.51 9.370000000000001 490724.94 718183.51 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD31-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490732.82 718193.43 2.11 490698.81 718220.05 2.11 490698.81 718220.05 9.370000000000001 490732.82 718193.43 9.370000000000001 490732.82 718193.43 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD31-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490698.81 718220.05 2.11 490691.04 718210.03 2.11 490691.04 718210.03 9.370000000000001 490698.81 718220.05 9.370000000000001 490698.81 718220.05 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD31-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490691.04 718210.03 9.370000000000001 490718.38 718188.67 9.370000000000001 490724.94 718183.51 9.370000000000001 490732.82 718193.43 9.370000000000001 490698.81 718220.05 9.370000000000001 490691.04 718210.03 9.370000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-afd9d3be-f1e3-42b5-9b6d-7d28c23f7c54">
			<gen:stringAttribute name="buildingId">
				<gen:value>afd9d3be-f1e3-42b5-9b6d-7d28c23f7c54</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.82</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd9d3be-f1e3-42b5-9b6d-7d28c23f7c54_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491027.33 717490.67 3.41 491033.43 717499.09 3.41 491036.74 717496.71 3.41 491030.6 717488.3 3.41 491027.33 717490.67 3.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd9d3be-f1e3-42b5-9b6d-7d28c23f7c54_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491027.33 717490.67 3.41 491030.6 717488.3 3.41 491030.6 717488.3 6.23 491027.33 717490.67 6.23 491027.33 717490.67 3.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd9d3be-f1e3-42b5-9b6d-7d28c23f7c54_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491030.6 717488.3 3.41 491036.74 717496.71 3.41 491036.74 717496.71 6.23 491030.6 717488.3 6.23 491030.6 717488.3 3.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd9d3be-f1e3-42b5-9b6d-7d28c23f7c54_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491036.74 717496.71 3.41 491033.43 717499.09 3.41 491033.43 717499.09 6.23 491036.74 717496.71 6.23 491036.74 717496.71 3.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd9d3be-f1e3-42b5-9b6d-7d28c23f7c54_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491033.43 717499.09 3.41 491027.33 717490.67 3.41 491027.33 717490.67 6.23 491033.43 717499.09 6.23 491033.43 717499.09 3.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd9d3be-f1e3-42b5-9b6d-7d28c23f7c54_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491027.33 717490.67 6.23 491030.6 717488.3 6.23 491036.74 717496.71 6.23 491033.43 717499.09 6.23 491027.33 717490.67 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787">
			<gen:stringAttribute name="buildingId">
				<gen:value>afd80b48-66a2-402e-b293-b6235f423787</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.51</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490619.67 717988.67 2.14 490620.43 717990.19 2.14 490621.27 717989.72 2.14 490622.2 717991.46 2.14 490621.34 717991.91 2.14 490621.88 717993.01 2.14 490626.39 717990.66 2.14 490624.78 717987.7 2.14 490624.64 717987.74 2.14 490624 717986.51 2.14 490619.67 717988.67 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490619.67 717988.67 2.14 490624 717986.51 2.14 490624 717986.51 5.6450000000000005 490619.67 717988.67 5.6450000000000005 490619.67 717988.67 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490624 717986.51 2.14 490624.64 717987.74 2.14 490624.64 717987.74 5.6450000000000005 490624 717986.51 5.6450000000000005 490624 717986.51 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490624.64 717987.74 2.14 490624.78 717987.7 2.14 490624.78 717987.7 5.6450000000000005 490624.64 717987.74 5.6450000000000005 490624.64 717987.74 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490624.78 717987.7 2.14 490626.39 717990.66 2.14 490626.39 717990.66 5.6450000000000005 490624.78 717987.7 5.6450000000000005 490624.78 717987.7 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490626.39 717990.66 2.14 490621.88 717993.01 2.14 490621.88 717993.01 5.6450000000000005 490626.39 717990.66 5.6450000000000005 490626.39 717990.66 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490621.88 717993.01 2.14 490621.34 717991.91 2.14 490621.34 717991.91 5.6450000000000005 490621.88 717993.01 5.6450000000000005 490621.88 717993.01 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490621.34 717991.91 2.14 490622.2 717991.46 2.14 490622.2 717991.46 5.6450000000000005 490621.34 717991.91 5.6450000000000005 490621.34 717991.91 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490622.2 717991.46 2.14 490621.27 717989.72 2.14 490621.27 717989.72 5.6450000000000005 490622.2 717991.46 5.6450000000000005 490622.2 717991.46 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490621.27 717989.72 2.14 490620.43 717990.19 2.14 490620.43 717990.19 5.6450000000000005 490621.27 717989.72 5.6450000000000005 490621.27 717989.72 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490620.43 717990.19 2.14 490619.67 717988.67 2.14 490619.67 717988.67 5.6450000000000005 490620.43 717990.19 5.6450000000000005 490620.43 717990.19 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-afd80b48-66a2-402e-b293-b6235f423787_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490619.67 717988.67 5.6450000000000005 490624 717986.51 5.6450000000000005 490624.64 717987.74 5.6450000000000005 490624.78 717987.7 5.6450000000000005 490626.39 717990.66 5.6450000000000005 490621.88 717993.01 5.6450000000000005 490621.34 717991.91 5.6450000000000005 490622.2 717991.46 5.6450000000000005 490621.27 717989.72 5.6450000000000005 490620.43 717990.19 5.6450000000000005 490619.67 717988.67 5.6450000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-2a1ae686-51e0-4b11-a586-9357b22ca304">
			<gen:stringAttribute name="buildingId">
				<gen:value>2a1ae686-51e0-4b11-a586-9357b22ca304</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.15</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2a1ae686-51e0-4b11-a586-9357b22ca304_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490588.92 717893.34 2.34 490585.37 717894.93 2.34 490589.28 717903.16 2.34 490589.38 717903.12 2.34 490590.32 717905.07 2.34 490593.61 717903.64 2.34 490592.77 717901.57 2.34 490592.9 717901.52 2.34 490588.92 717893.34 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2a1ae686-51e0-4b11-a586-9357b22ca304_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490588.92 717893.34 2.34 490592.9 717901.52 2.34 490592.9 717901.52 4.49 490588.92 717893.34 4.49 490588.92 717893.34 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2a1ae686-51e0-4b11-a586-9357b22ca304_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490592.9 717901.52 2.34 490592.77 717901.57 2.34 490592.77 717901.57 4.49 490592.9 717901.52 4.49 490592.9 717901.52 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2a1ae686-51e0-4b11-a586-9357b22ca304_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490592.77 717901.57 2.34 490593.61 717903.64 2.34 490593.61 717903.64 4.49 490592.77 717901.57 4.49 490592.77 717901.57 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2a1ae686-51e0-4b11-a586-9357b22ca304_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490593.61 717903.64 2.34 490590.32 717905.07 2.34 490590.32 717905.07 4.49 490593.61 717903.64 4.49 490593.61 717903.64 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2a1ae686-51e0-4b11-a586-9357b22ca304_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490590.32 717905.07 2.34 490589.38 717903.12 2.34 490589.38 717903.12 4.49 490590.32 717905.07 4.49 490590.32 717905.07 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2a1ae686-51e0-4b11-a586-9357b22ca304_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490589.38 717903.12 2.34 490589.28 717903.16 2.34 490589.28 717903.16 4.49 490589.38 717903.12 4.49 490589.38 717903.12 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2a1ae686-51e0-4b11-a586-9357b22ca304_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490589.28 717903.16 2.34 490585.37 717894.93 2.34 490585.37 717894.93 4.49 490589.28 717903.16 4.49 490589.28 717903.16 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2a1ae686-51e0-4b11-a586-9357b22ca304_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490585.37 717894.93 2.34 490588.92 717893.34 2.34 490588.92 717893.34 4.49 490585.37 717894.93 4.49 490585.37 717894.93 2.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2a1ae686-51e0-4b11-a586-9357b22ca304_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490588.92 717893.34 4.49 490592.9 717901.52 4.49 490592.77 717901.57 4.49 490593.61 717903.64 4.49 490590.32 717905.07 4.49 490589.38 717903.12 4.49 490589.28 717903.16 4.49 490585.37 717894.93 4.49 490588.92 717893.34 4.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572">
			<gen:stringAttribute name="buildingId">
				<gen:value>77feecb1-e43e-48fb-aad4-4d43a0cce572</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490611.04 718023.28 1.85 490614.3 718029.51 1.85 490621.77 718025.6 1.85 490623.64 718024.63 1.85 490622.99 718023.36 1.85 490627.96 718020.75 1.85 490625.53 718015.99 1.85 490622.75 718015.09 1.85 490621.12 718020.04 1.85 490619.59 718020.85 1.85 490618.79 718019.29 1.85 490617.08 718020.17 1.85 490611.04 718023.28 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490611.04 718023.28 1.85 490617.08 718020.17 1.85 490617.08 718020.17 6.48 490611.04 718023.28 6.48 490611.04 718023.28 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490617.08 718020.17 1.85 490618.79 718019.29 1.85 490618.79 718019.29 6.48 490617.08 718020.17 6.48 490617.08 718020.17 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490618.79 718019.29 1.85 490619.59 718020.85 1.85 490619.59 718020.85 6.48 490618.79 718019.29 6.48 490618.79 718019.29 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490619.59 718020.85 1.85 490621.12 718020.04 1.85 490621.12 718020.04 6.48 490619.59 718020.85 6.48 490619.59 718020.85 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490621.12 718020.04 1.85 490622.75 718015.09 1.85 490622.75 718015.09 6.48 490621.12 718020.04 6.48 490621.12 718020.04 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490622.75 718015.09 1.85 490625.53 718015.99 1.85 490625.53 718015.99 6.48 490622.75 718015.09 6.48 490622.75 718015.09 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490625.53 718015.99 1.85 490627.96 718020.75 1.85 490627.96 718020.75 6.48 490625.53 718015.99 6.48 490625.53 718015.99 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490627.96 718020.75 1.85 490622.99 718023.36 1.85 490622.99 718023.36 6.48 490627.96 718020.75 6.48 490627.96 718020.75 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490622.99 718023.36 1.85 490623.64 718024.63 1.85 490623.64 718024.63 6.48 490622.99 718023.36 6.48 490622.99 718023.36 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490623.64 718024.63 1.85 490621.77 718025.6 1.85 490621.77 718025.6 6.48 490623.64 718024.63 6.48 490623.64 718024.63 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490621.77 718025.6 1.85 490614.3 718029.51 1.85 490614.3 718029.51 6.48 490621.77 718025.6 6.48 490621.77 718025.6 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490614.3 718029.51 1.85 490611.04 718023.28 1.85 490611.04 718023.28 6.48 490614.3 718029.51 6.48 490614.3 718029.51 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-77feecb1-e43e-48fb-aad4-4d43a0cce572_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490611.04 718023.28 6.48 490617.08 718020.17 6.48 490618.79 718019.29 6.48 490619.59 718020.85 6.48 490621.12 718020.04 6.48 490622.75 718015.09 6.48 490625.53 718015.99 6.48 490627.96 718020.75 6.48 490622.99 718023.36 6.48 490623.64 718024.63 6.48 490621.77 718025.6 6.48 490614.3 718029.51 6.48 490611.04 718023.28 6.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6">
			<gen:stringAttribute name="buildingId">
				<gen:value>2bb62b49-fdd4-433c-a207-778b8046b3d6</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.8</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490024.99 718259.93 2.15 490029.47 718260.91 2.15 490029.8 718259.44 2.15 490035.35 718260.72 2.15 490036.1 718257.96 2.15 490036.84 718255.25 2.15 490034.88 718254.75 2.15 490035.66 718251.63 2.15 490027.48 718249.68 2.15 490026.19 718255.06 2.15 490024.99 718259.93 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490024.99 718259.93 2.15 490026.19 718255.06 2.15 490026.19 718255.06 7.950000000000001 490024.99 718259.93 7.950000000000001 490024.99 718259.93 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490026.19 718255.06 2.15 490027.48 718249.68 2.15 490027.48 718249.68 7.950000000000001 490026.19 718255.06 7.950000000000001 490026.19 718255.06 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490027.48 718249.68 2.15 490035.66 718251.63 2.15 490035.66 718251.63 7.950000000000001 490027.48 718249.68 7.950000000000001 490027.48 718249.68 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490035.66 718251.63 2.15 490034.88 718254.75 2.15 490034.88 718254.75 7.950000000000001 490035.66 718251.63 7.950000000000001 490035.66 718251.63 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490034.88 718254.75 2.15 490036.84 718255.25 2.15 490036.84 718255.25 7.950000000000001 490034.88 718254.75 7.950000000000001 490034.88 718254.75 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490036.84 718255.25 2.15 490036.1 718257.96 2.15 490036.1 718257.96 7.950000000000001 490036.84 718255.25 7.950000000000001 490036.84 718255.25 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490036.1 718257.96 2.15 490035.35 718260.72 2.15 490035.35 718260.72 7.950000000000001 490036.1 718257.96 7.950000000000001 490036.1 718257.96 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490035.35 718260.72 2.15 490029.8 718259.44 2.15 490029.8 718259.44 7.950000000000001 490035.35 718260.72 7.950000000000001 490035.35 718260.72 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490029.8 718259.44 2.15 490029.47 718260.91 2.15 490029.47 718260.91 7.950000000000001 490029.8 718259.44 7.950000000000001 490029.8 718259.44 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490029.47 718260.91 2.15 490024.99 718259.93 2.15 490024.99 718259.93 7.950000000000001 490029.47 718260.91 7.950000000000001 490029.47 718260.91 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2bb62b49-fdd4-433c-a207-778b8046b3d6_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490024.99 718259.93 7.950000000000001 490026.19 718255.06 7.950000000000001 490027.48 718249.68 7.950000000000001 490035.66 718251.63 7.950000000000001 490034.88 718254.75 7.950000000000001 490036.84 718255.25 7.950000000000001 490036.1 718257.96 7.950000000000001 490035.35 718260.72 7.950000000000001 490029.8 718259.44 7.950000000000001 490029.47 718260.91 7.950000000000001 490024.99 718259.93 7.950000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-50062342-d190-4d63-8073-ae192dcfa343">
			<gen:stringAttribute name="buildingId">
				<gen:value>50062342-d190-4d63-8073-ae192dcfa343</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50062342-d190-4d63-8073-ae192dcfa343_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490597.94 717997.58 1.88 490601.13 718003.92 1.88 490601.23 718003.89 1.88 490608.69 718000 1.88 490608.63 717999.87 1.88 490607.43 717997.48 1.88 490605.48 717993.62 1.88 490597.94 717997.58 1.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50062342-d190-4d63-8073-ae192dcfa343_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490597.94 717997.58 1.88 490605.48 717993.62 1.88 490605.48 717993.62 8.35 490597.94 717997.58 8.35 490597.94 717997.58 1.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50062342-d190-4d63-8073-ae192dcfa343_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490605.48 717993.62 1.88 490607.43 717997.48 1.88 490607.43 717997.48 8.35 490605.48 717993.62 8.35 490605.48 717993.62 1.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50062342-d190-4d63-8073-ae192dcfa343_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490607.43 717997.48 1.88 490608.63 717999.87 1.88 490608.63 717999.87 8.35 490607.43 717997.48 8.35 490607.43 717997.48 1.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50062342-d190-4d63-8073-ae192dcfa343_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490608.63 717999.87 1.88 490608.69 718000 1.88 490608.69 718000 8.35 490608.63 717999.87 8.35 490608.63 717999.87 1.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50062342-d190-4d63-8073-ae192dcfa343_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490608.69 718000 1.88 490601.23 718003.89 1.88 490601.23 718003.89 8.35 490608.69 718000 8.35 490608.69 718000 1.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50062342-d190-4d63-8073-ae192dcfa343_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490601.23 718003.89 1.88 490601.13 718003.92 1.88 490601.13 718003.92 8.35 490601.23 718003.89 8.35 490601.23 718003.89 1.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50062342-d190-4d63-8073-ae192dcfa343_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490601.13 718003.92 1.88 490597.94 717997.58 1.88 490597.94 717997.58 8.35 490601.13 718003.92 8.35 490601.13 718003.92 1.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-50062342-d190-4d63-8073-ae192dcfa343_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490597.94 717997.58 8.35 490605.48 717993.62 8.35 490607.43 717997.48 8.35 490608.63 717999.87 8.35 490608.69 718000 8.35 490601.23 718003.89 8.35 490601.13 718003.92 8.35 490597.94 717997.58 8.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-52f3fb02-54e8-4d7c-8000-36d50a698667">
			<gen:stringAttribute name="buildingId">
				<gen:value>52f3fb02-54e8-4d7c-8000-36d50a698667</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.18</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-52f3fb02-54e8-4d7c-8000-36d50a698667_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490048.1 718214.28 2.1 490056.22 718217.63 2.1 490058.04 718213.13 2.1 490049.73 718209.84 2.1 490048.1 718214.28 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-52f3fb02-54e8-4d7c-8000-36d50a698667_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490048.1 718214.28 2.1 490049.73 718209.84 2.1 490049.73 718209.84 5.28 490048.1 718214.28 5.28 490048.1 718214.28 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-52f3fb02-54e8-4d7c-8000-36d50a698667_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490049.73 718209.84 2.1 490058.04 718213.13 2.1 490058.04 718213.13 5.28 490049.73 718209.84 5.28 490049.73 718209.84 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-52f3fb02-54e8-4d7c-8000-36d50a698667_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490058.04 718213.13 2.1 490056.22 718217.63 2.1 490056.22 718217.63 5.28 490058.04 718213.13 5.28 490058.04 718213.13 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-52f3fb02-54e8-4d7c-8000-36d50a698667_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490056.22 718217.63 2.1 490048.1 718214.28 2.1 490048.1 718214.28 5.28 490056.22 718217.63 5.28 490056.22 718217.63 2.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-52f3fb02-54e8-4d7c-8000-36d50a698667_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490048.1 718214.28 5.28 490049.73 718209.84 5.28 490058.04 718213.13 5.28 490056.22 718217.63 5.28 490048.1 718214.28 5.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca">
			<gen:stringAttribute name="buildingId">
				<gen:value>25d8def4-6767-45a7-812e-18c229a5e3ca</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.62</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491268.29 717274.33 4.13 491268.72 717274.62 4.13 491268.78 717274.53 4.13 491281.92 717282.17 4.13 491281.81 717282.37 4.13 491282.32 717282.62 4.13 491282.61 717282.14 4.13 491282.51 717282.07 4.13 491284.31 717278.99 4.13 491284.42 717279.05 4.13 491284.63 717278.71 4.13 491284.51 717278.64 4.13 491285.64 717276.76 4.13 491271.74 717268.63 4.13 491270.44 717270.82 4.13 491270.56 717270.9 4.13 491268.71 717273.91 4.13 491268.59 717273.84 4.13 491268.29 717274.33 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491268.29 717274.33 4.13 491268.59 717273.84 4.13 491268.59 717273.84 11.75 491268.29 717274.33 11.75 491268.29 717274.33 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491268.59 717273.84 4.13 491268.71 717273.91 4.13 491268.71 717273.91 11.75 491268.59 717273.84 11.75 491268.59 717273.84 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491268.71 717273.91 4.13 491270.56 717270.9 4.13 491270.56 717270.9 11.75 491268.71 717273.91 11.75 491268.71 717273.91 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491270.56 717270.9 4.13 491270.44 717270.82 4.13 491270.44 717270.82 11.75 491270.56 717270.9 11.75 491270.56 717270.9 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491270.44 717270.82 4.13 491271.74 717268.63 4.13 491271.74 717268.63 11.75 491270.44 717270.82 11.75 491270.44 717270.82 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491271.74 717268.63 4.13 491285.64 717276.76 4.13 491285.64 717276.76 11.75 491271.74 717268.63 11.75 491271.74 717268.63 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491285.64 717276.76 4.13 491284.51 717278.64 4.13 491284.51 717278.64 11.75 491285.64 717276.76 11.75 491285.64 717276.76 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491284.51 717278.64 4.13 491284.63 717278.71 4.13 491284.63 717278.71 11.75 491284.51 717278.64 11.75 491284.51 717278.64 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491284.63 717278.71 4.13 491284.42 717279.05 4.13 491284.42 717279.05 11.75 491284.63 717278.71 11.75 491284.63 717278.71 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491284.42 717279.05 4.13 491284.31 717278.99 4.13 491284.31 717278.99 11.75 491284.42 717279.05 11.75 491284.42 717279.05 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491284.31 717278.99 4.13 491282.51 717282.07 4.13 491282.51 717282.07 11.75 491284.31 717278.99 11.75 491284.31 717278.99 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491282.51 717282.07 4.13 491282.61 717282.14 4.13 491282.61 717282.14 11.75 491282.51 717282.07 11.75 491282.51 717282.07 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491282.61 717282.14 4.13 491282.32 717282.62 4.13 491282.32 717282.62 11.75 491282.61 717282.14 11.75 491282.61 717282.14 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491282.32 717282.62 4.13 491281.81 717282.37 4.13 491281.81 717282.37 11.75 491282.32 717282.62 11.75 491282.32 717282.62 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491281.81 717282.37 4.13 491281.92 717282.17 4.13 491281.92 717282.17 11.75 491281.81 717282.37 11.75 491281.81 717282.37 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491281.92 717282.17 4.13 491268.78 717274.53 4.13 491268.78 717274.53 11.75 491281.92 717282.17 11.75 491281.92 717282.17 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491268.78 717274.53 4.13 491268.72 717274.62 4.13 491268.72 717274.62 11.75 491268.78 717274.53 11.75 491268.78 717274.53 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491268.72 717274.62 4.13 491268.29 717274.33 4.13 491268.29 717274.33 11.75 491268.72 717274.62 11.75 491268.72 717274.62 4.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-25d8def4-6767-45a7-812e-18c229a5e3ca_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491268.29 717274.33 11.75 491268.59 717273.84 11.75 491268.71 717273.91 11.75 491270.56 717270.9 11.75 491270.44 717270.82 11.75 491271.74 717268.63 11.75 491285.64 717276.76 11.75 491284.51 717278.64 11.75 491284.63 717278.71 11.75 491284.42 717279.05 11.75 491284.31 717278.99 11.75 491282.51 717282.07 11.75 491282.61 717282.14 11.75 491282.32 717282.62 11.75 491281.81 717282.37 11.75 491281.92 717282.17 11.75 491268.78 717274.53 11.75 491268.72 717274.62 11.75 491268.29 717274.33 11.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-466e2af1-9560-4f93-a2b1-ed3c143e3f33">
			<gen:stringAttribute name="buildingId">
				<gen:value>466e2af1-9560-4f93-a2b1-ed3c143e3f33</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.66</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-466e2af1-9560-4f93-a2b1-ed3c143e3f33_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490585.95 717973.71 1.9 490589.05 717979.9 1.9 490596.43 717976.05 1.9 490593.32 717969.95 1.9 490585.95 717973.71 1.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-466e2af1-9560-4f93-a2b1-ed3c143e3f33_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490585.95 717973.71 1.9 490593.32 717969.95 1.9 490593.32 717969.95 7.5600000000000005 490585.95 717973.71 7.5600000000000005 490585.95 717973.71 1.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-466e2af1-9560-4f93-a2b1-ed3c143e3f33_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490593.32 717969.95 1.9 490596.43 717976.05 1.9 490596.43 717976.05 7.5600000000000005 490593.32 717969.95 7.5600000000000005 490593.32 717969.95 1.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-466e2af1-9560-4f93-a2b1-ed3c143e3f33_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490596.43 717976.05 1.9 490589.05 717979.9 1.9 490589.05 717979.9 7.5600000000000005 490596.43 717976.05 7.5600000000000005 490596.43 717976.05 1.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-466e2af1-9560-4f93-a2b1-ed3c143e3f33_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490589.05 717979.9 1.9 490585.95 717973.71 1.9 490585.95 717973.71 7.5600000000000005 490589.05 717979.9 7.5600000000000005 490589.05 717979.9 1.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-466e2af1-9560-4f93-a2b1-ed3c143e3f33_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490585.95 717973.71 7.5600000000000005 490593.32 717969.95 7.5600000000000005 490596.43 717976.05 7.5600000000000005 490589.05 717979.9 7.5600000000000005 490585.95 717973.71 7.5600000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502">
			<gen:stringAttribute name="buildingId">
				<gen:value>5cc59a81-3817-4159-9714-6e4719edb502</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.88</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491285.64 717276.76 3.37 491286.25 717275.75 3.37 491286.36 717275.82 3.37 491286.57 717275.47 3.37 491286.46 717275.41 3.37 491288.31 717272.31 3.37 491288.45 717272.4 3.37 491288.76 717271.88 3.37 491274.65 717263.66 3.37 491274.37 717264.15 3.37 491274.5 717264.23 3.37 491272.7 717267.3 3.37 491272.58 717267.22 3.37 491271.74 717268.63 3.37 491285.64 717276.76 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491285.64 717276.76 3.37 491271.74 717268.63 3.37 491271.74 717268.63 11.25 491285.64 717276.76 11.25 491285.64 717276.76 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491271.74 717268.63 3.37 491272.58 717267.22 3.37 491272.58 717267.22 11.25 491271.74 717268.63 11.25 491271.74 717268.63 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491272.58 717267.22 3.37 491272.7 717267.3 3.37 491272.7 717267.3 11.25 491272.58 717267.22 11.25 491272.58 717267.22 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491272.7 717267.3 3.37 491274.5 717264.23 3.37 491274.5 717264.23 11.25 491272.7 717267.3 11.25 491272.7 717267.3 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491274.5 717264.23 3.37 491274.37 717264.15 3.37 491274.37 717264.15 11.25 491274.5 717264.23 11.25 491274.5 717264.23 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491274.37 717264.15 3.37 491274.65 717263.66 3.37 491274.65 717263.66 11.25 491274.37 717264.15 11.25 491274.37 717264.15 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491274.65 717263.66 3.37 491288.76 717271.88 3.37 491288.76 717271.88 11.25 491274.65 717263.66 11.25 491274.65 717263.66 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491288.76 717271.88 3.37 491288.45 717272.4 3.37 491288.45 717272.4 11.25 491288.76 717271.88 11.25 491288.76 717271.88 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491288.45 717272.4 3.37 491288.31 717272.31 3.37 491288.31 717272.31 11.25 491288.45 717272.4 11.25 491288.45 717272.4 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491288.31 717272.31 3.37 491286.46 717275.41 3.37 491286.46 717275.41 11.25 491288.31 717272.31 11.25 491288.31 717272.31 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491286.46 717275.41 3.37 491286.57 717275.47 3.37 491286.57 717275.47 11.25 491286.46 717275.41 11.25 491286.46 717275.41 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491286.57 717275.47 3.37 491286.36 717275.82 3.37 491286.36 717275.82 11.25 491286.57 717275.47 11.25 491286.57 717275.47 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491286.36 717275.82 3.37 491286.25 717275.75 3.37 491286.25 717275.75 11.25 491286.36 717275.82 11.25 491286.36 717275.82 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491286.25 717275.75 3.37 491285.64 717276.76 3.37 491285.64 717276.76 11.25 491286.25 717275.75 11.25 491286.25 717275.75 3.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5cc59a81-3817-4159-9714-6e4719edb502_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491285.64 717276.76 11.25 491271.74 717268.63 11.25 491272.58 717267.22 11.25 491272.7 717267.3 11.25 491274.5 717264.23 11.25 491274.37 717264.15 11.25 491274.65 717263.66 11.25 491288.76 717271.88 11.25 491288.45 717272.4 11.25 491288.31 717272.31 11.25 491286.46 717275.41 11.25 491286.57 717275.47 11.25 491286.36 717275.82 11.25 491286.25 717275.75 11.25 491285.64 717276.76 11.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-01b8a580-e63e-46dd-8a2b-6e7eb33e4aaf">
			<gen:stringAttribute name="buildingId">
				<gen:value>01b8a580-e63e-46dd-8a2b-6e7eb33e4aaf</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.91</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01b8a580-e63e-46dd-8a2b-6e7eb33e4aaf_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491773.24 716583.76 4.31 491776.06 716589.48 4.31 491778.86 716588.13 4.31 491778.47 716587.26 4.31 491791.06 716581.42 4.31 491788.43 716576.31 4.31 491775.95 716582.21 4.31 491776.06 716582.44 4.31 491773.24 716583.76 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01b8a580-e63e-46dd-8a2b-6e7eb33e4aaf_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491773.24 716583.76 4.31 491776.06 716582.44 4.31 491776.06 716582.44 8.22 491773.24 716583.76 8.22 491773.24 716583.76 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01b8a580-e63e-46dd-8a2b-6e7eb33e4aaf_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491776.06 716582.44 4.31 491775.95 716582.21 4.31 491775.95 716582.21 8.22 491776.06 716582.44 8.22 491776.06 716582.44 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01b8a580-e63e-46dd-8a2b-6e7eb33e4aaf_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491775.95 716582.21 4.31 491788.43 716576.31 4.31 491788.43 716576.31 8.22 491775.95 716582.21 8.22 491775.95 716582.21 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01b8a580-e63e-46dd-8a2b-6e7eb33e4aaf_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491788.43 716576.31 4.31 491791.06 716581.42 4.31 491791.06 716581.42 8.22 491788.43 716576.31 8.22 491788.43 716576.31 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01b8a580-e63e-46dd-8a2b-6e7eb33e4aaf_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491791.06 716581.42 4.31 491778.47 716587.26 4.31 491778.47 716587.26 8.22 491791.06 716581.42 8.22 491791.06 716581.42 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01b8a580-e63e-46dd-8a2b-6e7eb33e4aaf_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491778.47 716587.26 4.31 491778.86 716588.13 4.31 491778.86 716588.13 8.22 491778.47 716587.26 8.22 491778.47 716587.26 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01b8a580-e63e-46dd-8a2b-6e7eb33e4aaf_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491778.86 716588.13 4.31 491776.06 716589.48 4.31 491776.06 716589.48 8.22 491778.86 716588.13 8.22 491778.86 716588.13 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01b8a580-e63e-46dd-8a2b-6e7eb33e4aaf_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491776.06 716589.48 4.31 491773.24 716583.76 4.31 491773.24 716583.76 8.22 491776.06 716589.48 8.22 491776.06 716589.48 4.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-01b8a580-e63e-46dd-8a2b-6e7eb33e4aaf_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491773.24 716583.76 8.22 491776.06 716582.44 8.22 491775.95 716582.21 8.22 491788.43 716576.31 8.22 491791.06 716581.42 8.22 491778.47 716587.26 8.22 491778.86 716588.13 8.22 491776.06 716589.48 8.22 491773.24 716583.76 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-3285a4a0-aaa9-460b-ae32-995fcd01a28f">
			<gen:stringAttribute name="buildingId">
				<gen:value>3285a4a0-aaa9-460b-ae32-995fcd01a28f</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.48</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3285a4a0-aaa9-460b-ae32-995fcd01a28f_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491226.87 717301.22 4.74 491231.13 717304.12 4.74 491241.88 717287.07 4.74 491237.47 717284.28 4.74 491226.87 717301.22 4.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3285a4a0-aaa9-460b-ae32-995fcd01a28f_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491226.87 717301.22 4.74 491237.47 717284.28 4.74 491237.47 717284.28 8.22 491226.87 717301.22 8.22 491226.87 717301.22 4.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3285a4a0-aaa9-460b-ae32-995fcd01a28f_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491237.47 717284.28 4.74 491241.88 717287.07 4.74 491241.88 717287.07 8.22 491237.47 717284.28 8.22 491237.47 717284.28 4.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3285a4a0-aaa9-460b-ae32-995fcd01a28f_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491241.88 717287.07 4.74 491231.13 717304.12 4.74 491231.13 717304.12 8.22 491241.88 717287.07 8.22 491241.88 717287.07 4.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3285a4a0-aaa9-460b-ae32-995fcd01a28f_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491231.13 717304.12 4.74 491226.87 717301.22 4.74 491226.87 717301.22 8.22 491231.13 717304.12 8.22 491231.13 717304.12 4.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-3285a4a0-aaa9-460b-ae32-995fcd01a28f_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491226.87 717301.22 8.22 491237.47 717284.28 8.22 491241.88 717287.07 8.22 491231.13 717304.12 8.22 491226.87 717301.22 8.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-d78e554c-e471-40e8-b2ff-f283acc67432">
			<gen:stringAttribute name="buildingId">
				<gen:value>d78e554c-e471-40e8-b2ff-f283acc67432</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.12</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d78e554c-e471-40e8-b2ff-f283acc67432_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491580.42 716941.1 3.2 491578.39 716942.52 3.2 491584.14 716950.75 3.2 491594.01 716943.91 3.2 491592.52 716941.73 3.2 491591.45 716942.44 3.2 491584.86 716947.04 3.2 491581.19 716941.81 3.2 491580.42 716941.1 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d78e554c-e471-40e8-b2ff-f283acc67432_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491580.42 716941.1 3.2 491581.19 716941.81 3.2 491581.19 716941.81 7.32 491580.42 716941.1 7.32 491580.42 716941.1 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d78e554c-e471-40e8-b2ff-f283acc67432_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491581.19 716941.81 3.2 491584.86 716947.04 3.2 491584.86 716947.04 7.32 491581.19 716941.81 7.32 491581.19 716941.81 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d78e554c-e471-40e8-b2ff-f283acc67432_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491584.86 716947.04 3.2 491591.45 716942.44 3.2 491591.45 716942.44 7.32 491584.86 716947.04 7.32 491584.86 716947.04 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d78e554c-e471-40e8-b2ff-f283acc67432_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491591.45 716942.44 3.2 491592.52 716941.73 3.2 491592.52 716941.73 7.32 491591.45 716942.44 7.32 491591.45 716942.44 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d78e554c-e471-40e8-b2ff-f283acc67432_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491592.52 716941.73 3.2 491594.01 716943.91 3.2 491594.01 716943.91 7.32 491592.52 716941.73 7.32 491592.52 716941.73 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d78e554c-e471-40e8-b2ff-f283acc67432_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491594.01 716943.91 3.2 491584.14 716950.75 3.2 491584.14 716950.75 7.32 491594.01 716943.91 7.32 491594.01 716943.91 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d78e554c-e471-40e8-b2ff-f283acc67432_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491584.14 716950.75 3.2 491578.39 716942.52 3.2 491578.39 716942.52 7.32 491584.14 716950.75 7.32 491584.14 716950.75 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d78e554c-e471-40e8-b2ff-f283acc67432_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491578.39 716942.52 3.2 491580.42 716941.1 3.2 491580.42 716941.1 7.32 491578.39 716942.52 7.32 491578.39 716942.52 3.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-d78e554c-e471-40e8-b2ff-f283acc67432_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491580.42 716941.1 7.32 491581.19 716941.81 7.32 491584.86 716947.04 7.32 491591.45 716942.44 7.32 491592.52 716941.73 7.32 491594.01 716943.91 7.32 491584.14 716950.75 7.32 491578.39 716942.52 7.32 491580.42 716941.1 7.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54">
			<gen:stringAttribute name="buildingId">
				<gen:value>c7b54679-6637-4481-ac36-16ec49e4be54</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.3</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491246.41 717252.19 4.19 491262.15 717263.02 4.19 491263.12 717261.34 4.19 491263.55 717261.51 4.19 491263.8 717261.05 4.19 491263.4 717260.85 4.19 491264.98 717258.09 4.19 491260.04 717255.22 4.19 491261.31 717253.01 4.19 491257.92 717251.05 4.19 491256.67 717253.23 4.19 491248.56 717248.53 4.19 491246.41 717252.19 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491246.41 717252.19 4.19 491248.56 717248.53 4.19 491248.56 717248.53 10.49 491246.41 717252.19 10.49 491246.41 717252.19 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491248.56 717248.53 4.19 491256.67 717253.23 4.19 491256.67 717253.23 10.49 491248.56 717248.53 10.49 491248.56 717248.53 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491256.67 717253.23 4.19 491257.92 717251.05 4.19 491257.92 717251.05 10.49 491256.67 717253.23 10.49 491256.67 717253.23 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491257.92 717251.05 4.19 491261.31 717253.01 4.19 491261.31 717253.01 10.49 491257.92 717251.05 10.49 491257.92 717251.05 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491261.31 717253.01 4.19 491260.04 717255.22 4.19 491260.04 717255.22 10.49 491261.31 717253.01 10.49 491261.31 717253.01 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491260.04 717255.22 4.19 491264.98 717258.09 4.19 491264.98 717258.09 10.49 491260.04 717255.22 10.49 491260.04 717255.22 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491264.98 717258.09 4.19 491263.4 717260.85 4.19 491263.4 717260.85 10.49 491264.98 717258.09 10.49 491264.98 717258.09 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491263.4 717260.85 4.19 491263.8 717261.05 4.19 491263.8 717261.05 10.49 491263.4 717260.85 10.49 491263.4 717260.85 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491263.8 717261.05 4.19 491263.55 717261.51 4.19 491263.55 717261.51 10.49 491263.8 717261.05 10.49 491263.8 717261.05 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491263.55 717261.51 4.19 491263.12 717261.34 4.19 491263.12 717261.34 10.49 491263.55 717261.51 10.49 491263.55 717261.51 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491263.12 717261.34 4.19 491262.15 717263.02 4.19 491262.15 717263.02 10.49 491263.12 717261.34 10.49 491263.12 717261.34 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491262.15 717263.02 4.19 491246.41 717252.19 4.19 491246.41 717252.19 10.49 491262.15 717263.02 10.49 491262.15 717263.02 4.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-c7b54679-6637-4481-ac36-16ec49e4be54_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491246.41 717252.19 10.49 491248.56 717248.53 10.49 491256.67 717253.23 10.49 491257.92 717251.05 10.49 491261.31 717253.01 10.49 491260.04 717255.22 10.49 491264.98 717258.09 10.49 491263.4 717260.85 10.49 491263.8 717261.05 10.49 491263.55 717261.51 10.49 491263.12 717261.34 10.49 491262.15 717263.02 10.49 491246.41 717252.19 10.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-bfacfcb7-9f78-4454-9f0b-fd7b0a05c613">
			<gen:stringAttribute name="buildingId">
				<gen:value>bfacfcb7-9f78-4454-9f0b-fd7b0a05c613</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.18</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bfacfcb7-9f78-4454-9f0b-fd7b0a05c613_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490992.39 717606.12 2.33 490995.41 717611.4 2.33 491000.56 717608.55 2.33 491001.44 717610.16 2.33 491045.12 717585.53 2.33 491040.64 717577.21 2.33 490996.56 717601.51 2.33 490997.73 717603.38 2.33 490992.39 717606.12 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bfacfcb7-9f78-4454-9f0b-fd7b0a05c613_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490992.39 717606.12 2.33 490997.73 717603.38 2.33 490997.73 717603.38 5.51 490992.39 717606.12 5.51 490992.39 717606.12 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bfacfcb7-9f78-4454-9f0b-fd7b0a05c613_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490997.73 717603.38 2.33 490996.56 717601.51 2.33 490996.56 717601.51 5.51 490997.73 717603.38 5.51 490997.73 717603.38 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bfacfcb7-9f78-4454-9f0b-fd7b0a05c613_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490996.56 717601.51 2.33 491040.64 717577.21 2.33 491040.64 717577.21 5.51 490996.56 717601.51 5.51 490996.56 717601.51 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bfacfcb7-9f78-4454-9f0b-fd7b0a05c613_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491040.64 717577.21 2.33 491045.12 717585.53 2.33 491045.12 717585.53 5.51 491040.64 717577.21 5.51 491040.64 717577.21 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bfacfcb7-9f78-4454-9f0b-fd7b0a05c613_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491045.12 717585.53 2.33 491001.44 717610.16 2.33 491001.44 717610.16 5.51 491045.12 717585.53 5.51 491045.12 717585.53 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bfacfcb7-9f78-4454-9f0b-fd7b0a05c613_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491001.44 717610.16 2.33 491000.56 717608.55 2.33 491000.56 717608.55 5.51 491001.44 717610.16 5.51 491001.44 717610.16 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bfacfcb7-9f78-4454-9f0b-fd7b0a05c613_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491000.56 717608.55 2.33 490995.41 717611.4 2.33 490995.41 717611.4 5.51 491000.56 717608.55 5.51 491000.56 717608.55 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bfacfcb7-9f78-4454-9f0b-fd7b0a05c613_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490995.41 717611.4 2.33 490992.39 717606.12 2.33 490992.39 717606.12 5.51 490995.41 717611.4 5.51 490995.41 717611.4 2.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-bfacfcb7-9f78-4454-9f0b-fd7b0a05c613_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490992.39 717606.12 5.51 490997.73 717603.38 5.51 490996.56 717601.51 5.51 491040.64 717577.21 5.51 491045.12 717585.53 5.51 491001.44 717610.16 5.51 491000.56 717608.55 5.51 490995.41 717611.4 5.51 490992.39 717606.12 5.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-7e0eeb51-0807-4720-821e-5f5ec6db6c08">
			<gen:stringAttribute name="buildingId">
				<gen:value>7e0eeb51-0807-4720-821e-5f5ec6db6c08</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.15</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7e0eeb51-0807-4720-821e-5f5ec6db6c08_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490868.74 717755.72 3.01 490863.21 717758.66 3.01 490866.52 717764.74 3.01 490872.07 717761.83 3.01 490868.74 717755.72 3.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7e0eeb51-0807-4720-821e-5f5ec6db6c08_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490868.74 717755.72 3.01 490872.07 717761.83 3.01 490872.07 717761.83 6.16 490868.74 717755.72 6.16 490868.74 717755.72 3.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7e0eeb51-0807-4720-821e-5f5ec6db6c08_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490872.07 717761.83 3.01 490866.52 717764.74 3.01 490866.52 717764.74 6.16 490872.07 717761.83 6.16 490872.07 717761.83 3.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7e0eeb51-0807-4720-821e-5f5ec6db6c08_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490866.52 717764.74 3.01 490863.21 717758.66 3.01 490863.21 717758.66 6.16 490866.52 717764.74 6.16 490866.52 717764.74 3.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7e0eeb51-0807-4720-821e-5f5ec6db6c08_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490863.21 717758.66 3.01 490868.74 717755.72 3.01 490868.74 717755.72 6.16 490863.21 717758.66 6.16 490863.21 717758.66 3.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-7e0eeb51-0807-4720-821e-5f5ec6db6c08_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490868.74 717755.72 6.16 490872.07 717761.83 6.16 490866.52 717764.74 6.16 490863.21 717758.66 6.16 490868.74 717755.72 6.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-1594750c-afbc-4949-8986-3f2627f4787a">
			<gen:stringAttribute name="buildingId">
				<gen:value>1594750c-afbc-4949-8986-3f2627f4787a</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1594750c-afbc-4949-8986-3f2627f4787a_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491786.55 716572.44 3.76 491788.43 716576.31 3.76 491791.06 716581.42 3.76 491796.76 716578.74 3.76 491792.7 716570.44 3.76 491786.55 716572.44 3.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1594750c-afbc-4949-8986-3f2627f4787a_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491786.55 716572.44 3.76 491792.7 716570.44 3.76 491792.7 716570.44 8.290000000000001 491786.55 716572.44 8.290000000000001 491786.55 716572.44 3.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1594750c-afbc-4949-8986-3f2627f4787a_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491792.7 716570.44 3.76 491796.76 716578.74 3.76 491796.76 716578.74 8.290000000000001 491792.7 716570.44 8.290000000000001 491792.7 716570.44 3.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1594750c-afbc-4949-8986-3f2627f4787a_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491796.76 716578.74 3.76 491791.06 716581.42 3.76 491791.06 716581.42 8.290000000000001 491796.76 716578.74 8.290000000000001 491796.76 716578.74 3.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1594750c-afbc-4949-8986-3f2627f4787a_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491791.06 716581.42 3.76 491788.43 716576.31 3.76 491788.43 716576.31 8.290000000000001 491791.06 716581.42 8.290000000000001 491791.06 716581.42 3.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1594750c-afbc-4949-8986-3f2627f4787a_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491788.43 716576.31 3.76 491786.55 716572.44 3.76 491786.55 716572.44 8.290000000000001 491788.43 716576.31 8.290000000000001 491788.43 716576.31 3.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-1594750c-afbc-4949-8986-3f2627f4787a_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491786.55 716572.44 8.290000000000001 491792.7 716570.44 8.290000000000001 491796.76 716578.74 8.290000000000001 491791.06 716581.42 8.290000000000001 491788.43 716576.31 8.290000000000001 491786.55 716572.44 8.290000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-f25f2a4a-2c07-4936-a65c-247bffa39a18">
			<gen:stringAttribute name="buildingId">
				<gen:value>f25f2a4a-2c07-4936-a65c-247bffa39a18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.17</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f25f2a4a-2c07-4936-a65c-247bffa39a18_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490914.58 717644.72 3.03 490922.29 717660.7 3.03 490927.81 717658.01 3.03 490920.08 717642.02 3.03 490914.58 717644.72 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f25f2a4a-2c07-4936-a65c-247bffa39a18_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490914.58 717644.72 3.03 490920.08 717642.02 3.03 490920.08 717642.02 7.199999999999999 490914.58 717644.72 7.199999999999999 490914.58 717644.72 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f25f2a4a-2c07-4936-a65c-247bffa39a18_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490920.08 717642.02 3.03 490927.81 717658.01 3.03 490927.81 717658.01 7.199999999999999 490920.08 717642.02 7.199999999999999 490920.08 717642.02 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f25f2a4a-2c07-4936-a65c-247bffa39a18_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490927.81 717658.01 3.03 490922.29 717660.7 3.03 490922.29 717660.7 7.199999999999999 490927.81 717658.01 7.199999999999999 490927.81 717658.01 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f25f2a4a-2c07-4936-a65c-247bffa39a18_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490922.29 717660.7 3.03 490914.58 717644.72 3.03 490914.58 717644.72 7.199999999999999 490922.29 717660.7 7.199999999999999 490922.29 717660.7 3.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-f25f2a4a-2c07-4936-a65c-247bffa39a18_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490914.58 717644.72 7.199999999999999 490920.08 717642.02 7.199999999999999 490927.81 717658.01 7.199999999999999 490922.29 717660.7 7.199999999999999 490914.58 717644.72 7.199999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9">
			<gen:stringAttribute name="buildingId">
				<gen:value>2cb33f2a-585d-4c61-ae56-e2c4004f2cb9</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.98</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491495.24 717126.17 3.16 491501.21 717134.75 3.16 491509.35 717129.11 3.16 491508.84 717128.37 3.16 491513.75 717124.96 3.16 491508.76 717117.85 3.16 491503.84 717121.29 3.16 491503.33 717120.55 3.16 491500.16 717122.76 3.16 491500.51 717123.25 3.16 491498.76 717124.46 3.16 491498.42 717123.97 3.16 491495.24 717126.17 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491495.24 717126.17 3.16 491498.42 717123.97 3.16 491498.42 717123.97 10.14 491495.24 717126.17 10.14 491495.24 717126.17 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491498.42 717123.97 3.16 491498.76 717124.46 3.16 491498.76 717124.46 10.14 491498.42 717123.97 10.14 491498.42 717123.97 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491498.76 717124.46 3.16 491500.51 717123.25 3.16 491500.51 717123.25 10.14 491498.76 717124.46 10.14 491498.76 717124.46 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491500.51 717123.25 3.16 491500.16 717122.76 3.16 491500.16 717122.76 10.14 491500.51 717123.25 10.14 491500.51 717123.25 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491500.16 717122.76 3.16 491503.33 717120.55 3.16 491503.33 717120.55 10.14 491500.16 717122.76 10.14 491500.16 717122.76 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491503.33 717120.55 3.16 491503.84 717121.29 3.16 491503.84 717121.29 10.14 491503.33 717120.55 10.14 491503.33 717120.55 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491503.84 717121.29 3.16 491508.76 717117.85 3.16 491508.76 717117.85 10.14 491503.84 717121.29 10.14 491503.84 717121.29 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491508.76 717117.85 3.16 491513.75 717124.96 3.16 491513.75 717124.96 10.14 491508.76 717117.85 10.14 491508.76 717117.85 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491513.75 717124.96 3.16 491508.84 717128.37 3.16 491508.84 717128.37 10.14 491513.75 717124.96 10.14 491513.75 717124.96 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491508.84 717128.37 3.16 491509.35 717129.11 3.16 491509.35 717129.11 10.14 491508.84 717128.37 10.14 491508.84 717128.37 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491509.35 717129.11 3.16 491501.21 717134.75 3.16 491501.21 717134.75 10.14 491509.35 717129.11 10.14 491509.35 717129.11 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491501.21 717134.75 3.16 491495.24 717126.17 3.16 491495.24 717126.17 10.14 491501.21 717134.75 10.14 491501.21 717134.75 3.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-2cb33f2a-585d-4c61-ae56-e2c4004f2cb9_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491495.24 717126.17 10.14 491498.42 717123.97 10.14 491498.76 717124.46 10.14 491500.51 717123.25 10.14 491500.16 717122.76 10.14 491503.33 717120.55 10.14 491503.84 717121.29 10.14 491508.76 717117.85 10.14 491513.75 717124.96 10.14 491508.84 717128.37 10.14 491509.35 717129.11 10.14 491501.21 717134.75 10.14 491495.24 717126.17 10.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CE00-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CE00-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.3</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE00-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491043.71 717521.48 2.53 491051.89 717534.67 2.53 491058.8 717530.46 2.53 491050.57 717517.22 2.53 491043.71 717521.48 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE00-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491043.71 717521.48 2.53 491050.57 717517.22 2.53 491050.57 717517.22 6.83 491043.71 717521.48 6.83 491043.71 717521.48 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE00-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491050.57 717517.22 2.53 491058.8 717530.46 2.53 491058.8 717530.46 6.83 491050.57 717517.22 6.83 491050.57 717517.22 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE00-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491058.8 717530.46 2.53 491051.89 717534.67 2.53 491051.89 717534.67 6.83 491058.8 717530.46 6.83 491058.8 717530.46 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE00-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491051.89 717534.67 2.53 491043.71 717521.48 2.53 491043.71 717521.48 6.83 491051.89 717534.67 6.83 491051.89 717534.67 2.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CE00-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491043.71 717521.48 6.83 491050.57 717517.22 6.83 491058.8 717530.46 6.83 491051.89 717534.67 6.83 491043.71 717521.48 6.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2D52-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2D52-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.76</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D52-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491774.61 716531.48 4.45 491779.2 716543.35 4.45 491791.01 716538.73 4.45 491792.05 716541.47 4.45 491794.09 716540.73 4.45 491793.05 716537.98 4.45 491801.51 716534.66 4.45 491796.97 716522.76 4.45 491774.61 716531.48 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D52-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491774.61 716531.48 4.45 491796.97 716522.76 4.45 491796.97 716522.76 12.21 491774.61 716531.48 12.21 491774.61 716531.48 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D52-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491796.97 716522.76 4.45 491801.51 716534.66 4.45 491801.51 716534.66 12.21 491796.97 716522.76 12.21 491796.97 716522.76 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D52-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491801.51 716534.66 4.45 491793.05 716537.98 4.45 491793.05 716537.98 12.21 491801.51 716534.66 12.21 491801.51 716534.66 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D52-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491793.05 716537.98 4.45 491794.09 716540.73 4.45 491794.09 716540.73 12.21 491793.05 716537.98 12.21 491793.05 716537.98 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D52-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491794.09 716540.73 4.45 491792.05 716541.47 4.45 491792.05 716541.47 12.21 491794.09 716540.73 12.21 491794.09 716540.73 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D52-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491792.05 716541.47 4.45 491791.01 716538.73 4.45 491791.01 716538.73 12.21 491792.05 716541.47 12.21 491792.05 716541.47 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D52-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491791.01 716538.73 4.45 491779.2 716543.35 4.45 491779.2 716543.35 12.21 491791.01 716538.73 12.21 491791.01 716538.73 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D52-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491779.2 716543.35 4.45 491774.61 716531.48 4.45 491774.61 716531.48 12.21 491779.2 716543.35 12.21 491779.2 716543.35 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D52-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491774.61 716531.48 12.21 491796.97 716522.76 12.21 491801.51 716534.66 12.21 491793.05 716537.98 12.21 491794.09 716540.73 12.21 491792.05 716541.47 12.21 491791.01 716538.73 12.21 491779.2 716543.35 12.21 491774.61 716531.48 12.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2D51-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2D51-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.45</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D51-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490558.9 717921.07 2.12 490566.11 717935.15 2.12 490574.69 717930.74 2.12 490570.71 717922.9 2.12 490570.8 717922.85 2.12 490567.6 717916.61 2.12 490558.9 717921.07 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D51-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490558.9 717921.07 2.12 490567.6 717916.61 2.12 490567.6 717916.61 8.57 490558.9 717921.07 8.57 490558.9 717921.07 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D51-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490567.6 717916.61 2.12 490570.8 717922.85 2.12 490570.8 717922.85 8.57 490567.6 717916.61 8.57 490567.6 717916.61 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D51-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490570.8 717922.85 2.12 490570.71 717922.9 2.12 490570.71 717922.9 8.57 490570.8 717922.85 8.57 490570.8 717922.85 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D51-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490570.71 717922.9 2.12 490574.69 717930.74 2.12 490574.69 717930.74 8.57 490570.71 717922.9 8.57 490570.71 717922.9 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D51-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490574.69 717930.74 2.12 490566.11 717935.15 2.12 490566.11 717935.15 8.57 490574.69 717930.74 8.57 490574.69 717930.74 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D51-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490566.11 717935.15 2.12 490558.9 717921.07 2.12 490558.9 717921.07 8.57 490566.11 717935.15 8.57 490566.11 717935.15 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D51-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490558.9 717921.07 8.57 490567.6 717916.61 8.57 490570.8 717922.85 8.57 490570.71 717922.9 8.57 490574.69 717930.74 8.57 490566.11 717935.15 8.57 490558.9 717921.07 8.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2D50-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2D50-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.37</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D50-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490572.82 717948.25 2.05 490579.98 717962.24 2.05 490588.66 717957.75 2.05 490581.44 717943.82 2.05 490572.82 717948.25 2.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D50-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490572.82 717948.25 2.05 490581.44 717943.82 2.05 490581.44 717943.82 8.42 490572.82 717948.25 8.42 490572.82 717948.25 2.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D50-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490581.44 717943.82 2.05 490588.66 717957.75 2.05 490588.66 717957.75 8.42 490581.44 717943.82 8.42 490581.44 717943.82 2.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D50-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490588.66 717957.75 2.05 490579.98 717962.24 2.05 490579.98 717962.24 8.42 490588.66 717957.75 8.42 490588.66 717957.75 2.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D50-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490579.98 717962.24 2.05 490572.82 717948.25 2.05 490572.82 717948.25 8.42 490579.98 717962.24 8.42 490579.98 717962.24 2.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2D50-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490572.82 717948.25 8.42 490581.44 717943.82 8.42 490588.66 717957.75 8.42 490579.98 717962.24 8.42 490572.82 717948.25 8.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-251147fa-57b8-4b05-8913-9eba0c92f481">
			<gen:stringAttribute name="buildingId">
				<gen:value>251147fa-57b8-4b05-8913-9eba0c92f481</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.02</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-251147fa-57b8-4b05-8913-9eba0c92f481_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490910.47 717608.02 3.48 490915.75 717618.75 3.48 490924.11 717614.77 3.48 490916.09 717605.34 3.48 490910.47 717608.02 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-251147fa-57b8-4b05-8913-9eba0c92f481_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490910.47 717608.02 3.48 490916.09 717605.34 3.48 490916.09 717605.34 7.5 490910.47 717608.02 7.5 490910.47 717608.02 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-251147fa-57b8-4b05-8913-9eba0c92f481_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490916.09 717605.34 3.48 490924.11 717614.77 3.48 490924.11 717614.77 7.5 490916.09 717605.34 7.5 490916.09 717605.34 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-251147fa-57b8-4b05-8913-9eba0c92f481_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490924.11 717614.77 3.48 490915.75 717618.75 3.48 490915.75 717618.75 7.5 490924.11 717614.77 7.5 490924.11 717614.77 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-251147fa-57b8-4b05-8913-9eba0c92f481_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490915.75 717618.75 3.48 490910.47 717608.02 3.48 490910.47 717608.02 7.5 490915.75 717618.75 7.5 490915.75 717618.75 3.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-251147fa-57b8-4b05-8913-9eba0c92f481_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490910.47 717608.02 7.5 490916.09 717605.34 7.5 490924.11 717614.77 7.5 490915.75 717618.75 7.5 490910.47 717608.02 7.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157">
			<gen:stringAttribute name="buildingId">
				<gen:value>0661046a-52cc-48ea-bfe6-8c4a8d33e157</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490058.58 718325.46 2.18 490073.42 718328.53 2.18 490073.91 718325.92 2.18 490074.61 718322.08 2.18 490070.81 718321.27 2.18 490070.42 718323.4 2.18 490067.51 718322.79 2.18 490068.07 718320.08 2.18 490063.72 718319.17 2.18 490063.15 718321.92 2.18 490059.4 718321.22 2.18 490058.58 718325.46 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490058.58 718325.46 2.18 490059.4 718321.22 2.18 490059.4 718321.22 5.61 490058.58 718325.46 5.61 490058.58 718325.46 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490059.4 718321.22 2.18 490063.15 718321.92 2.18 490063.15 718321.92 5.61 490059.4 718321.22 5.61 490059.4 718321.22 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490063.15 718321.92 2.18 490063.72 718319.17 2.18 490063.72 718319.17 5.61 490063.15 718321.92 5.61 490063.15 718321.92 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490063.72 718319.17 2.18 490068.07 718320.08 2.18 490068.07 718320.08 5.61 490063.72 718319.17 5.61 490063.72 718319.17 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490068.07 718320.08 2.18 490067.51 718322.79 2.18 490067.51 718322.79 5.61 490068.07 718320.08 5.61 490068.07 718320.08 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490067.51 718322.79 2.18 490070.42 718323.4 2.18 490070.42 718323.4 5.61 490067.51 718322.79 5.61 490067.51 718322.79 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490070.42 718323.4 2.18 490070.81 718321.27 2.18 490070.81 718321.27 5.61 490070.42 718323.4 5.61 490070.42 718323.4 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490070.81 718321.27 2.18 490074.61 718322.08 2.18 490074.61 718322.08 5.61 490070.81 718321.27 5.61 490070.81 718321.27 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490074.61 718322.08 2.18 490073.91 718325.92 2.18 490073.91 718325.92 5.61 490074.61 718322.08 5.61 490074.61 718322.08 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.91 718325.92 2.18 490073.42 718328.53 2.18 490073.42 718328.53 5.61 490073.91 718325.92 5.61 490073.91 718325.92 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490073.42 718328.53 2.18 490058.58 718325.46 2.18 490058.58 718325.46 5.61 490073.42 718328.53 5.61 490073.42 718328.53 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-0661046a-52cc-48ea-bfe6-8c4a8d33e157_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490058.58 718325.46 5.61 490059.4 718321.22 5.61 490063.15 718321.92 5.61 490063.72 718319.17 5.61 490068.07 718320.08 5.61 490067.51 718322.79 5.61 490070.42 718323.4 5.61 490070.81 718321.27 5.61 490074.61 718322.08 5.61 490073.91 718325.92 5.61 490073.42 718328.53 5.61 490058.58 718325.46 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557">
			<gen:stringAttribute name="buildingId">
				<gen:value>6b0d74e0-cde9-40c7-86aa-5cf8c312a557</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.68</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490611.67 717961.94 2.18 490607.15 717964.17 2.18 490609.65 717969.07 2.18 490610.2 717970.07 2.18 490611.05 717969.65 2.18 490611.93 717971.45 2.18 490611.02 717971.89 2.18 490612.13 717973.98 2.18 490616.68 717971.82 2.18 490614.18 717966.86 2.18 490611.67 717961.94 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490611.67 717961.94 2.18 490614.18 717966.86 2.18 490614.18 717966.86 4.86 490611.67 717961.94 4.86 490611.67 717961.94 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490614.18 717966.86 2.18 490616.68 717971.82 2.18 490616.68 717971.82 4.86 490614.18 717966.86 4.86 490614.18 717966.86 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490616.68 717971.82 2.18 490612.13 717973.98 2.18 490612.13 717973.98 4.86 490616.68 717971.82 4.86 490616.68 717971.82 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490612.13 717973.98 2.18 490611.02 717971.89 2.18 490611.02 717971.89 4.86 490612.13 717973.98 4.86 490612.13 717973.98 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490611.02 717971.89 2.18 490611.93 717971.45 2.18 490611.93 717971.45 4.86 490611.02 717971.89 4.86 490611.02 717971.89 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490611.93 717971.45 2.18 490611.05 717969.65 2.18 490611.05 717969.65 4.86 490611.93 717971.45 4.86 490611.93 717971.45 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490611.05 717969.65 2.18 490610.2 717970.07 2.18 490610.2 717970.07 4.86 490611.05 717969.65 4.86 490611.05 717969.65 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490610.2 717970.07 2.18 490609.65 717969.07 2.18 490609.65 717969.07 4.86 490610.2 717970.07 4.86 490610.2 717970.07 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490609.65 717969.07 2.18 490607.15 717964.17 2.18 490607.15 717964.17 4.86 490609.65 717969.07 4.86 490609.65 717969.07 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490607.15 717964.17 2.18 490611.67 717961.94 2.18 490611.67 717961.94 4.86 490607.15 717964.17 4.86 490607.15 717964.17 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-6b0d74e0-cde9-40c7-86aa-5cf8c312a557_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490611.67 717961.94 4.86 490614.18 717966.86 4.86 490616.68 717971.82 4.86 490612.13 717973.98 4.86 490611.02 717971.89 4.86 490611.93 717971.45 4.86 490611.05 717969.65 4.86 490610.2 717970.07 4.86 490609.65 717969.07 4.86 490607.15 717964.17 4.86 490611.67 717961.94 4.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-523d643d-ecbf-4b61-bea7-c20f0e7c4810">
			<gen:stringAttribute name="buildingId">
				<gen:value>523d643d-ecbf-4b61-bea7-c20f0e7c4810</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.12</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-523d643d-ecbf-4b61-bea7-c20f0e7c4810_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491603.41 716748.83 3.56 491608.39 716752.63 3.56 491612.05 716747.87 3.56 491607.03 716744.07 3.56 491605.03 716742.67 3.56 491601.5 716747.37 3.56 491603.41 716748.83 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-523d643d-ecbf-4b61-bea7-c20f0e7c4810_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491603.41 716748.83 3.56 491601.5 716747.37 3.56 491601.5 716747.37 7.68 491603.41 716748.83 7.68 491603.41 716748.83 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-523d643d-ecbf-4b61-bea7-c20f0e7c4810_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491601.5 716747.37 3.56 491605.03 716742.67 3.56 491605.03 716742.67 7.68 491601.5 716747.37 7.68 491601.5 716747.37 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-523d643d-ecbf-4b61-bea7-c20f0e7c4810_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491605.03 716742.67 3.56 491607.03 716744.07 3.56 491607.03 716744.07 7.68 491605.03 716742.67 7.68 491605.03 716742.67 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-523d643d-ecbf-4b61-bea7-c20f0e7c4810_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491607.03 716744.07 3.56 491612.05 716747.87 3.56 491612.05 716747.87 7.68 491607.03 716744.07 7.68 491607.03 716744.07 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-523d643d-ecbf-4b61-bea7-c20f0e7c4810_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491612.05 716747.87 3.56 491608.39 716752.63 3.56 491608.39 716752.63 7.68 491612.05 716747.87 7.68 491612.05 716747.87 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-523d643d-ecbf-4b61-bea7-c20f0e7c4810_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491608.39 716752.63 3.56 491603.41 716748.83 3.56 491603.41 716748.83 7.68 491608.39 716752.63 7.68 491608.39 716752.63 3.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-523d643d-ecbf-4b61-bea7-c20f0e7c4810_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491603.41 716748.83 7.68 491601.5 716747.37 7.68 491605.03 716742.67 7.68 491607.03 716744.07 7.68 491612.05 716747.87 7.68 491608.39 716752.63 7.68 491603.41 716748.83 7.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-5f8e973b-d11c-49cb-81b0-767a81912470">
			<gen:stringAttribute name="buildingId">
				<gen:value>5f8e973b-d11c-49cb-81b0-767a81912470</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.78</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5f8e973b-d11c-49cb-81b0-767a81912470_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491605.96 716771.04 3.55 491599.75 716766.7 3.55 491596.09 716772.18 3.55 491599.74 716774.58 3.55 491599.81 716774.5 3.55 491602.43 716776.34 3.55 491605.96 716771.04 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5f8e973b-d11c-49cb-81b0-767a81912470_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491605.96 716771.04 3.55 491602.43 716776.34 3.55 491602.43 716776.34 6.33 491605.96 716771.04 6.33 491605.96 716771.04 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5f8e973b-d11c-49cb-81b0-767a81912470_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491602.43 716776.34 3.55 491599.81 716774.5 3.55 491599.81 716774.5 6.33 491602.43 716776.34 6.33 491602.43 716776.34 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5f8e973b-d11c-49cb-81b0-767a81912470_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491599.81 716774.5 3.55 491599.74 716774.58 3.55 491599.74 716774.58 6.33 491599.81 716774.5 6.33 491599.81 716774.5 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5f8e973b-d11c-49cb-81b0-767a81912470_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491599.74 716774.58 3.55 491596.09 716772.18 3.55 491596.09 716772.18 6.33 491599.74 716774.58 6.33 491599.74 716774.58 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5f8e973b-d11c-49cb-81b0-767a81912470_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491596.09 716772.18 3.55 491599.75 716766.7 3.55 491599.75 716766.7 6.33 491596.09 716772.18 6.33 491596.09 716772.18 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5f8e973b-d11c-49cb-81b0-767a81912470_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491599.75 716766.7 3.55 491605.96 716771.04 3.55 491605.96 716771.04 6.33 491599.75 716766.7 6.33 491599.75 716766.7 3.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-5f8e973b-d11c-49cb-81b0-767a81912470_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491605.96 716771.04 6.33 491602.43 716776.34 6.33 491599.81 716774.5 6.33 491599.74 716774.58 6.33 491596.09 716772.18 6.33 491599.75 716766.7 6.33 491605.96 716771.04 6.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD38-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD38-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD38-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490993.24 717490.18 3.96 491009.82 717504.88 3.96 491015.15 717498.8 3.96 490998.57 717484.23 3.96 490993.24 717490.18 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD38-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490993.24 717490.18 3.96 490998.57 717484.23 3.96 490998.57 717484.23 9.8 490993.24 717490.18 9.8 490993.24 717490.18 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD38-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490998.57 717484.23 3.96 491015.15 717498.8 3.96 491015.15 717498.8 9.8 490998.57 717484.23 9.8 490998.57 717484.23 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD38-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491015.15 717498.8 3.96 491009.82 717504.88 3.96 491009.82 717504.88 9.8 491015.15 717498.8 9.8 491015.15 717498.8 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD38-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491009.82 717504.88 3.96 490993.24 717490.18 3.96 490993.24 717490.18 9.8 491009.82 717504.88 9.8 491009.82 717504.88 3.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD38-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490993.24 717490.18 9.8 490998.57 717484.23 9.8 491015.15 717498.8 9.8 491009.82 717504.88 9.8 490993.24 717490.18 9.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD37-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD37-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.61</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD37-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490962.01 717606.81 2.88 490965.03 717612.27 2.88 490974.72 717606.94 2.88 490971.76 717601.45 2.88 490962.01 717606.81 2.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD37-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490962.01 717606.81 2.88 490971.76 717601.45 2.88 490971.76 717601.45 7.49 490962.01 717606.81 7.49 490962.01 717606.81 2.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD37-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490971.76 717601.45 2.88 490974.72 717606.94 2.88 490974.72 717606.94 7.49 490971.76 717601.45 7.49 490971.76 717601.45 2.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD37-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490974.72 717606.94 2.88 490965.03 717612.27 2.88 490965.03 717612.27 7.49 490974.72 717606.94 7.49 490974.72 717606.94 2.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD37-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490965.03 717612.27 2.88 490962.01 717606.81 2.88 490962.01 717606.81 7.49 490965.03 717612.27 7.49 490965.03 717612.27 2.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD37-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490962.01 717606.81 7.49 490971.76 717601.45 7.49 490974.72 717606.94 7.49 490965.03 717612.27 7.49 490962.01 717606.81 7.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD35-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD35-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.59</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD35-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490910.14 717621.43 3.28 490917.42 717636.52 3.28 490931.02 717630.09 3.28 490933.88 717628.69 3.28 490926.55 717613.58 3.28 490924.11 717614.77 3.28 490915.75 717618.75 3.28 490910.14 717621.43 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD35-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490910.14 717621.43 3.28 490915.75 717618.75 3.28 490915.75 717618.75 7.869999999999999 490910.14 717621.43 7.869999999999999 490910.14 717621.43 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD35-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490915.75 717618.75 3.28 490924.11 717614.77 3.28 490924.11 717614.77 7.869999999999999 490915.75 717618.75 7.869999999999999 490915.75 717618.75 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD35-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490924.11 717614.77 3.28 490926.55 717613.58 3.28 490926.55 717613.58 7.869999999999999 490924.11 717614.77 7.869999999999999 490924.11 717614.77 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD35-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490926.55 717613.58 3.28 490933.88 717628.69 3.28 490933.88 717628.69 7.869999999999999 490926.55 717613.58 7.869999999999999 490926.55 717613.58 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD35-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490933.88 717628.69 3.28 490931.02 717630.09 3.28 490931.02 717630.09 7.869999999999999 490933.88 717628.69 7.869999999999999 490933.88 717628.69 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD35-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490931.02 717630.09 3.28 490917.42 717636.52 3.28 490917.42 717636.52 7.869999999999999 490931.02 717630.09 7.869999999999999 490931.02 717630.09 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD35-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490917.42 717636.52 3.28 490910.14 717621.43 3.28 490910.14 717621.43 7.869999999999999 490917.42 717636.52 7.869999999999999 490917.42 717636.52 3.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD35-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490910.14 717621.43 7.869999999999999 490915.75 717618.75 7.869999999999999 490924.11 717614.77 7.869999999999999 490926.55 717613.58 7.869999999999999 490933.88 717628.69 7.869999999999999 490931.02 717630.09 7.869999999999999 490917.42 717636.52 7.869999999999999 490910.14 717621.43 7.869999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.16</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490867.43 717769.35 3.25 490858.57 717773.34 3.25 490860.17 717776.66 3.25 490862.57 717781.79 3.25 490862.66 717781.97 3.25 490871.4 717777.98 3.25 490869.64 717774.11 3.25 490872.21 717772.79 3.25 490871.19 717770.69 3.25 490868.57 717771.85 3.25 490867.43 717769.35 3.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490867.43 717769.35 3.25 490868.57 717771.85 3.25 490868.57 717771.85 6.41 490867.43 717769.35 6.41 490867.43 717769.35 3.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490868.57 717771.85 3.25 490871.19 717770.69 3.25 490871.19 717770.69 6.41 490868.57 717771.85 6.41 490868.57 717771.85 3.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490871.19 717770.69 3.25 490872.21 717772.79 3.25 490872.21 717772.79 6.41 490871.19 717770.69 6.41 490871.19 717770.69 3.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490872.21 717772.79 3.25 490869.64 717774.11 3.25 490869.64 717774.11 6.41 490872.21 717772.79 6.41 490872.21 717772.79 3.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490869.64 717774.11 3.25 490871.4 717777.98 3.25 490871.4 717777.98 6.41 490869.64 717774.11 6.41 490869.64 717774.11 3.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490871.4 717777.98 3.25 490862.66 717781.97 3.25 490862.66 717781.97 6.41 490871.4 717777.98 6.41 490871.4 717777.98 3.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490862.66 717781.97 3.25 490862.57 717781.79 3.25 490862.57 717781.79 6.41 490862.66 717781.97 6.41 490862.66 717781.97 3.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490862.57 717781.79 3.25 490860.17 717776.66 3.25 490860.17 717776.66 6.41 490862.57 717781.79 6.41 490862.57 717781.79 3.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490860.17 717776.66 3.25 490858.57 717773.34 3.25 490858.57 717773.34 6.41 490860.17 717776.66 6.41 490860.17 717776.66 3.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490858.57 717773.34 3.25 490867.43 717769.35 3.25 490867.43 717769.35 6.41 490858.57 717773.34 6.41 490858.57 717773.34 3.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CD33-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490867.43 717769.35 6.41 490868.57 717771.85 6.41 490871.19 717770.69 6.41 490872.21 717772.79 6.41 490869.64 717774.11 6.41 490871.4 717777.98 6.41 490862.66 717781.97 6.41 490862.57 717781.79 6.41 490860.17 717776.66 6.41 490858.57 717773.34 6.41 490867.43 717769.35 6.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-626E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-626E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.69</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-626E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490892.64 717580.68 3.65 490896.75 717589.67 3.65 490899.17 717594.97 3.65 490905.45 717592.06 3.65 490903.14 717586.97 3.65 490901.23 717587.84 3.65 490896.89 717578.75 3.65 490892.64 717580.68 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-626E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490892.64 717580.68 3.65 490896.89 717578.75 3.65 490896.89 717578.75 10.34 490892.64 717580.68 10.34 490892.64 717580.68 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-626E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490896.89 717578.75 3.65 490901.23 717587.84 3.65 490901.23 717587.84 10.34 490896.89 717578.75 10.34 490896.89 717578.75 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-626E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490901.23 717587.84 3.65 490903.14 717586.97 3.65 490903.14 717586.97 10.34 490901.23 717587.84 10.34 490901.23 717587.84 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-626E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490903.14 717586.97 3.65 490905.45 717592.06 3.65 490905.45 717592.06 10.34 490903.14 717586.97 10.34 490903.14 717586.97 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-626E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490905.45 717592.06 3.65 490899.17 717594.97 3.65 490899.17 717594.97 10.34 490905.45 717592.06 10.34 490905.45 717592.06 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-626E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490899.17 717594.97 3.65 490896.75 717589.67 3.65 490896.75 717589.67 10.34 490899.17 717594.97 10.34 490899.17 717594.97 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-626E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490896.75 717589.67 3.65 490892.64 717580.68 3.65 490892.64 717580.68 10.34 490896.75 717589.67 10.34 490896.75 717589.67 3.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-626E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>490892.64 717580.68 10.34 490896.89 717578.75 10.34 490901.23 717587.84 10.34 490903.14 717586.97 10.34 490905.45 717592.06 10.34 490899.17 717594.97 10.34 490896.75 717589.67 10.34 490892.64 717580.68 10.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6F78-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6F78-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F78-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491653.95 717062.69 2.57 491651.07 717056.57 2.57 491646.44 717058.75 2.57 491649.33 717064.87 2.57 491653.95 717062.69 2.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F78-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491653.95 717062.69 2.57 491649.33 717064.87 2.57 491649.33 717064.87 4.855 491653.95 717062.69 4.855 491653.95 717062.69 2.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F78-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491649.33 717064.87 2.57 491646.44 717058.75 2.57 491646.44 717058.75 4.855 491649.33 717064.87 4.855 491649.33 717064.87 2.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F78-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491646.44 717058.75 2.57 491651.07 717056.57 2.57 491651.07 717056.57 4.855 491646.44 717058.75 4.855 491646.44 717058.75 2.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F78-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491651.07 717056.57 2.57 491653.95 717062.69 2.57 491653.95 717062.69 4.855 491651.07 717056.57 4.855 491651.07 717056.57 2.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6F78-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>491653.95 717062.69 4.855 491649.33 717064.87 4.855 491646.44 717058.75 4.855 491651.07 717056.57 4.855 491653.95 717062.69 4.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
</CityModel>
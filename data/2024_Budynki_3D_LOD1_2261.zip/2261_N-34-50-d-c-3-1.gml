<?xml version="1.0" encoding="UTF-8"?>
<CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0" xmlns="http://www.opengis.net/citygml/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xsi:schemaLocation="http://www.opengis.net/citygml/building/2.0 http://schemas.opengis.net/citygml/building/2.0/building.xsd http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/generics/2.0 http://schemas.opengis.net/citygml/generics/2.0/generics.xsd http://www.opengis.net/citygml/appearance/2.0 http://schemas.opengis.net/citygml/appearance/2.0/appearance.xsd http://www.opengis.net/citygml/relief/2.0 http://schemas.opengis.net/citygml/relief/2.0/relief.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
			<gml:lowerCorner>483785.86 721142.66 0.98</gml:lowerCorner>
			<gml:upperCorner>485786.29 722819.75 19.64</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-736E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-736E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.87</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-736E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484563.85 721145.22 1.77 484558.76 721145.94 1.77 484558.8 721146.19 1.77 484551.8 721147.33 1.77 484552.65 721152.46 1.77 484559.68 721151.3 1.77 484564.63 721150.45 1.77 484563.91 721145.98 1.77 484563.85 721145.22 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-736E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484563.85 721145.22 1.77 484563.91 721145.98 1.77 484563.91 721145.98 6.640000000000001 484563.85 721145.22 6.640000000000001 484563.85 721145.22 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-736E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484563.91 721145.98 1.77 484564.63 721150.45 1.77 484564.63 721150.45 6.640000000000001 484563.91 721145.98 6.640000000000001 484563.91 721145.98 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-736E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484564.63 721150.45 1.77 484559.68 721151.3 1.77 484559.68 721151.3 6.640000000000001 484564.63 721150.45 6.640000000000001 484564.63 721150.45 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-736E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484559.68 721151.3 1.77 484552.65 721152.46 1.77 484552.65 721152.46 6.640000000000001 484559.68 721151.3 6.640000000000001 484559.68 721151.3 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-736E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484552.65 721152.46 1.77 484551.8 721147.33 1.77 484551.8 721147.33 6.640000000000001 484552.65 721152.46 6.640000000000001 484552.65 721152.46 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-736E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484551.8 721147.33 1.77 484558.8 721146.19 1.77 484558.8 721146.19 6.640000000000001 484551.8 721147.33 6.640000000000001 484551.8 721147.33 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-736E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484558.8 721146.19 1.77 484558.76 721145.94 1.77 484558.76 721145.94 6.640000000000001 484558.8 721146.19 6.640000000000001 484558.8 721146.19 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-736E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484558.76 721145.94 1.77 484563.85 721145.22 1.77 484563.85 721145.22 6.640000000000001 484558.76 721145.94 6.640000000000001 484558.76 721145.94 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-736E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484563.85 721145.22 6.640000000000001 484563.91 721145.98 6.640000000000001 484564.63 721150.45 6.640000000000001 484559.68 721151.3 6.640000000000001 484552.65 721152.46 6.640000000000001 484551.8 721147.33 6.640000000000001 484558.8 721146.19 6.640000000000001 484558.76 721145.94 6.640000000000001 484563.85 721145.22 6.640000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0775-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0775-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.49</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0775-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484614.96 721159.58 1.68 484623.82 721157.67 1.68 484621.56 721144.41 1.68 484612.66 721146.13 1.68 484614.96 721159.58 1.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0775-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484614.96 721159.58 1.68 484612.66 721146.13 1.68 484612.66 721146.13 7.17 484614.96 721159.58 7.17 484614.96 721159.58 1.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0775-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484612.66 721146.13 1.68 484621.56 721144.41 1.68 484621.56 721144.41 7.17 484612.66 721146.13 7.17 484612.66 721146.13 1.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0775-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484621.56 721144.41 1.68 484623.82 721157.67 1.68 484623.82 721157.67 7.17 484621.56 721144.41 7.17 484621.56 721144.41 1.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0775-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484623.82 721157.67 1.68 484614.96 721159.58 1.68 484614.96 721159.58 7.17 484623.82 721157.67 7.17 484623.82 721157.67 1.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0775-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484614.96 721159.58 7.17 484612.66 721146.13 7.17 484621.56 721144.41 7.17 484623.82 721157.67 7.17 484614.96 721159.58 7.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484456.68 721282.68 2.04 484461.8 721280.79 2.04 484462.02 721281.43 2.04 484464.44 721280.5 2.04 484463.42 721277.75 2.04 484470.86 721274.79 2.04 484471.36 721276.03 2.04 484480.06 721272.53 2.04 484475.19 721259.39 2.04 484469.22 721261.89 2.04 484469.94 721263.59 2.04 484459.01 721268.2 2.04 484461 721272.6 2.04 484453.85 721275.6 2.04 484456.68 721282.68 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484456.68 721282.68 2.04 484453.85 721275.6 2.04 484453.85 721275.6 6.03 484456.68 721282.68 6.03 484456.68 721282.68 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484453.85 721275.6 2.04 484461 721272.6 2.04 484461 721272.6 6.03 484453.85 721275.6 6.03 484453.85 721275.6 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484461 721272.6 2.04 484459.01 721268.2 2.04 484459.01 721268.2 6.03 484461 721272.6 6.03 484461 721272.6 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484459.01 721268.2 2.04 484469.94 721263.59 2.04 484469.94 721263.59 6.03 484459.01 721268.2 6.03 484459.01 721268.2 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484469.94 721263.59 2.04 484469.22 721261.89 2.04 484469.22 721261.89 6.03 484469.94 721263.59 6.03 484469.94 721263.59 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484469.22 721261.89 2.04 484475.19 721259.39 2.04 484475.19 721259.39 6.03 484469.22 721261.89 6.03 484469.22 721261.89 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484475.19 721259.39 2.04 484480.06 721272.53 2.04 484480.06 721272.53 6.03 484475.19 721259.39 6.03 484475.19 721259.39 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484480.06 721272.53 2.04 484471.36 721276.03 2.04 484471.36 721276.03 6.03 484480.06 721272.53 6.03 484480.06 721272.53 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484471.36 721276.03 2.04 484470.86 721274.79 2.04 484470.86 721274.79 6.03 484471.36 721276.03 6.03 484471.36 721276.03 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484470.86 721274.79 2.04 484463.42 721277.75 2.04 484463.42 721277.75 6.03 484470.86 721274.79 6.03 484470.86 721274.79 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484463.42 721277.75 2.04 484464.44 721280.5 2.04 484464.44 721280.5 6.03 484463.42 721277.75 6.03 484463.42 721277.75 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484464.44 721280.5 2.04 484462.02 721281.43 2.04 484462.02 721281.43 6.03 484464.44 721280.5 6.03 484464.44 721280.5 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484462.02 721281.43 2.04 484461.8 721280.79 2.04 484461.8 721280.79 6.03 484462.02 721281.43 6.03 484462.02 721281.43 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484461.8 721280.79 2.04 484456.68 721282.68 2.04 484456.68 721282.68 6.03 484461.8 721280.79 6.03 484461.8 721280.79 2.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE9D-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484456.68 721282.68 6.03 484453.85 721275.6 6.03 484461 721272.6 6.03 484459.01 721268.2 6.03 484469.94 721263.59 6.03 484469.22 721261.89 6.03 484475.19 721259.39 6.03 484480.06 721272.53 6.03 484471.36 721276.03 6.03 484470.86 721274.79 6.03 484463.42 721277.75 6.03 484464.44 721280.5 6.03 484462.02 721281.43 6.03 484461.8 721280.79 6.03 484456.68 721282.68 6.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E093-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E093-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.13</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E093-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484840.55 722583.28 1.71 484848.67 722585.85 1.71 484855.82 722562.85 1.71 484847.72 722560.28 1.71 484840.55 722583.28 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E093-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484840.55 722583.28 1.71 484847.72 722560.28 1.71 484847.72 722560.28 5.84 484840.55 722583.28 5.84 484840.55 722583.28 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E093-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484847.72 722560.28 1.71 484855.82 722562.85 1.71 484855.82 722562.85 5.84 484847.72 722560.28 5.84 484847.72 722560.28 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E093-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484855.82 722562.85 1.71 484848.67 722585.85 1.71 484848.67 722585.85 5.84 484855.82 722562.85 5.84 484855.82 722562.85 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E093-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484848.67 722585.85 1.71 484840.55 722583.28 1.71 484840.55 722583.28 5.84 484848.67 722585.85 5.84 484848.67 722585.85 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E093-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484840.55 722583.28 5.84 484847.72 722560.28 5.84 484855.82 722562.85 5.84 484848.67 722585.85 5.84 484840.55 722583.28 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD60-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD60-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.9</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD60-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485255.4 722690.99 1.42 485256.74 722698.9 1.42 485263.13 722697.87 1.42 485261.85 722689.96 1.42 485255.4 722690.99 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD60-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485255.4 722690.99 1.42 485261.85 722689.96 1.42 485261.85 722689.96 5.315 485255.4 722690.99 5.315 485255.4 722690.99 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD60-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485261.85 722689.96 1.42 485263.13 722697.87 1.42 485263.13 722697.87 5.315 485261.85 722689.96 5.315 485261.85 722689.96 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD60-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485263.13 722697.87 1.42 485256.74 722698.9 1.42 485256.74 722698.9 5.315 485263.13 722697.87 5.315 485263.13 722697.87 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD60-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485256.74 722698.9 1.42 485255.4 722690.99 1.42 485255.4 722690.99 5.315 485256.74 722698.9 5.315 485256.74 722698.9 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD60-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485255.4 722690.99 5.315 485261.85 722689.96 5.315 485263.13 722697.87 5.315 485256.74 722698.9 5.315 485255.4 722690.99 5.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD5F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD5F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.8</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485214.39 722702.02 1.34 485220.94 722702.49 1.34 485221.49 722694.27 1.34 485214.93 722693.85 1.34 485214.39 722702.02 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485214.39 722702.02 1.34 485214.93 722693.85 1.34 485214.93 722693.85 5.14 485214.39 722702.02 5.14 485214.39 722702.02 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485214.93 722693.85 1.34 485221.49 722694.27 1.34 485221.49 722694.27 5.14 485214.93 722693.85 5.14 485214.93 722693.85 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485221.49 722694.27 1.34 485220.94 722702.49 1.34 485220.94 722702.49 5.14 485221.49 722694.27 5.14 485221.49 722694.27 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485220.94 722702.49 1.34 485214.39 722702.02 1.34 485214.39 722702.02 5.14 485220.94 722702.49 5.14 485220.94 722702.49 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485214.39 722702.02 5.14 485214.93 722693.85 5.14 485221.49 722694.27 5.14 485220.94 722702.49 5.14 485214.39 722702.02 5.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E092-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E092-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.39</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E092-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484798.14 722544.15 1.85 484804.51 722556.29 1.85 484812.55 722551.98 1.85 484813.74 722554.63 1.85 484828.1 722546.87 1.85 484824.89 722540.38 1.85 484830.33 722537.47 1.85 484826.11 722529.39 1.85 484798.14 722544.15 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E092-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484798.14 722544.15 1.85 484826.11 722529.39 1.85 484826.11 722529.39 5.24 484798.14 722544.15 5.24 484798.14 722544.15 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E092-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484826.11 722529.39 1.85 484830.33 722537.47 1.85 484830.33 722537.47 5.24 484826.11 722529.39 5.24 484826.11 722529.39 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E092-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484830.33 722537.47 1.85 484824.89 722540.38 1.85 484824.89 722540.38 5.24 484830.33 722537.47 5.24 484830.33 722537.47 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E092-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484824.89 722540.38 1.85 484828.1 722546.87 1.85 484828.1 722546.87 5.24 484824.89 722540.38 5.24 484824.89 722540.38 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E092-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484828.1 722546.87 1.85 484813.74 722554.63 1.85 484813.74 722554.63 5.24 484828.1 722546.87 5.24 484828.1 722546.87 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E092-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484813.74 722554.63 1.85 484812.55 722551.98 1.85 484812.55 722551.98 5.24 484813.74 722554.63 5.24 484813.74 722554.63 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E092-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484812.55 722551.98 1.85 484804.51 722556.29 1.85 484804.51 722556.29 5.24 484812.55 722551.98 5.24 484812.55 722551.98 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E092-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484804.51 722556.29 1.85 484798.14 722544.15 1.85 484798.14 722544.15 5.24 484804.51 722556.29 5.24 484804.51 722556.29 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E092-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484798.14 722544.15 5.24 484826.11 722529.39 5.24 484830.33 722537.47 5.24 484824.89 722540.38 5.24 484828.1 722546.87 5.24 484813.74 722554.63 5.24 484812.55 722551.98 5.24 484804.51 722556.29 5.24 484798.14 722544.15 5.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD5E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD5E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.89</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485242.39 722707.42 1.46 485248.86 722707.43 1.46 485248.87 722699.22 1.46 485242.37 722699.22 1.46 485242.39 722707.42 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485242.39 722707.42 1.46 485242.37 722699.22 1.46 485242.37 722699.22 5.3500000000000005 485242.39 722707.42 5.3500000000000005 485242.39 722707.42 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485242.37 722699.22 1.46 485248.87 722699.22 1.46 485248.87 722699.22 5.3500000000000005 485242.37 722699.22 5.3500000000000005 485242.37 722699.22 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485248.87 722699.22 1.46 485248.86 722707.43 1.46 485248.86 722707.43 5.3500000000000005 485248.87 722699.22 5.3500000000000005 485248.87 722699.22 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485248.86 722707.43 1.46 485242.39 722707.42 1.46 485242.39 722707.42 5.3500000000000005 485248.86 722707.43 5.3500000000000005 485248.86 722707.43 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485242.39 722707.42 5.3500000000000005 485242.37 722699.22 5.3500000000000005 485248.87 722699.22 5.3500000000000005 485248.86 722707.43 5.3500000000000005 485242.39 722707.42 5.3500000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD5D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD5D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.27</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484978.85 721327.68 3.12 484982.77 721327.29 3.12 484981.75 721319.5 3.12 484977.91 721319.96 3.12 484978.85 721327.68 3.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484978.85 721327.68 3.12 484977.91 721319.96 3.12 484977.91 721319.96 6.390000000000001 484978.85 721327.68 6.390000000000001 484978.85 721327.68 3.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484977.91 721319.96 3.12 484981.75 721319.5 3.12 484981.75 721319.5 6.390000000000001 484977.91 721319.96 6.390000000000001 484977.91 721319.96 3.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484981.75 721319.5 3.12 484982.77 721327.29 3.12 484982.77 721327.29 6.390000000000001 484981.75 721319.5 6.390000000000001 484981.75 721319.5 3.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484982.77 721327.29 3.12 484978.85 721327.68 3.12 484978.85 721327.68 6.390000000000001 484982.77 721327.29 6.390000000000001 484982.77 721327.29 3.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484978.85 721327.68 6.390000000000001 484977.91 721319.96 6.390000000000001 484981.75 721319.5 6.390000000000001 484982.77 721327.29 6.390000000000001 484978.85 721327.68 6.390000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DE19-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DE19-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE19-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485568.19 722817.07 1.45 485578.52 722819.75 1.45 485581.32 722808.98 1.45 485571.01 722806.29 1.45 485568.19 722817.07 1.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE19-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485568.19 722817.07 1.45 485571.01 722806.29 1.45 485571.01 722806.29 6.92 485568.19 722817.07 6.92 485568.19 722817.07 1.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE19-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485571.01 722806.29 1.45 485581.32 722808.98 1.45 485581.32 722808.98 6.92 485571.01 722806.29 6.92 485571.01 722806.29 1.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE19-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485581.32 722808.98 1.45 485578.52 722819.75 1.45 485578.52 722819.75 6.92 485581.32 722808.98 6.92 485581.32 722808.98 1.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE19-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485578.52 722819.75 1.45 485568.19 722817.07 1.45 485568.19 722817.07 6.92 485578.52 722819.75 6.92 485578.52 722819.75 1.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE19-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485568.19 722817.07 6.92 485571.01 722806.29 6.92 485581.32 722808.98 6.92 485578.52 722819.75 6.92 485568.19 722817.07 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-3EC3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-3EC3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.05</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485769.02 721150.89 1.73 485769.4 721158.3 1.73 485786.29 721157.61 1.73 485785.91 721150.2 1.73 485769.02 721150.89 1.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485769.02 721150.89 1.73 485785.91 721150.2 1.73 485785.91 721150.2 4.78 485769.02 721150.89 4.78 485769.02 721150.89 1.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485785.91 721150.2 1.73 485786.29 721157.61 1.73 485786.29 721157.61 4.78 485785.91 721150.2 4.78 485785.91 721150.2 1.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485786.29 721157.61 1.73 485769.4 721158.3 1.73 485769.4 721158.3 4.78 485786.29 721157.61 4.78 485786.29 721157.61 1.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485769.4 721158.3 1.73 485769.02 721150.89 1.73 485769.02 721150.89 4.78 485769.4 721158.3 4.78 485769.4 721158.3 1.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485769.02 721150.89 4.78 485785.91 721150.2 4.78 485786.29 721157.61 4.78 485769.4 721158.3 4.78 485769.02 721150.89 4.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D9B6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D9B6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.27</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D9B6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483785.86 721569.52 4.35 483792.59 721586.95 4.35 483804.64 721582.26 4.35 483797.85 721564.84 4.35 483785.86 721569.52 4.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D9B6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483785.86 721569.52 4.35 483797.85 721564.84 4.35 483797.85 721564.84 10.620000000000001 483785.86 721569.52 10.620000000000001 483785.86 721569.52 4.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D9B6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483797.85 721564.84 4.35 483804.64 721582.26 4.35 483804.64 721582.26 10.620000000000001 483797.85 721564.84 10.620000000000001 483797.85 721564.84 4.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D9B6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483804.64 721582.26 4.35 483792.59 721586.95 4.35 483792.59 721586.95 10.620000000000001 483804.64 721582.26 10.620000000000001 483804.64 721582.26 4.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D9B6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483792.59 721586.95 4.35 483785.86 721569.52 4.35 483785.86 721569.52 10.620000000000001 483792.59 721586.95 10.620000000000001 483792.59 721586.95 4.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D9B6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483785.86 721569.52 10.620000000000001 483797.85 721564.84 10.620000000000001 483804.64 721582.26 10.620000000000001 483792.59 721586.95 10.620000000000001 483785.86 721569.52 10.620000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-741C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-741C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.24</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484797 721290.96 2.25 484793.01 721291.42 2.25 484794.37 721302.31 2.25 484798.32 721301.75 2.25 484797 721290.96 2.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484797 721290.96 2.25 484798.32 721301.75 2.25 484798.32 721301.75 5.485 484797 721290.96 5.485 484797 721290.96 2.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484798.32 721301.75 2.25 484794.37 721302.31 2.25 484794.37 721302.31 5.485 484798.32 721301.75 5.485 484798.32 721301.75 2.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484794.37 721302.31 2.25 484793.01 721291.42 2.25 484793.01 721291.42 5.485 484794.37 721302.31 5.485 484794.37 721302.31 2.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484793.01 721291.42 2.25 484797 721290.96 2.25 484797 721290.96 5.485 484793.01 721291.42 5.485 484793.01 721291.42 2.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484797 721290.96 5.485 484798.32 721301.75 5.485 484794.37 721302.31 5.485 484793.01 721291.42 5.485 484797 721290.96 5.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D9B8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D9B8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.92</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D9B8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483945.8 721561.84 3.86 483950.46 721573.75 3.86 483980.56 721561.91 3.86 483976.13 721550.22 3.86 483945.8 721561.84 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D9B8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483945.8 721561.84 3.86 483976.13 721550.22 3.86 483976.13 721550.22 8.78 483945.8 721561.84 8.78 483945.8 721561.84 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D9B8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483976.13 721550.22 3.86 483980.56 721561.91 3.86 483980.56 721561.91 8.78 483976.13 721550.22 8.78 483976.13 721550.22 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D9B8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483980.56 721561.91 3.86 483950.46 721573.75 3.86 483950.46 721573.75 8.78 483980.56 721561.91 8.78 483980.56 721561.91 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D9B8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483950.46 721573.75 3.86 483945.8 721561.84 3.86 483945.8 721561.84 8.78 483950.46 721573.75 8.78 483950.46 721573.75 3.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D9B8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483945.8 721561.84 8.78 483976.13 721550.22 8.78 483980.56 721561.91 8.78 483950.46 721573.75 8.78 483945.8 721561.84 8.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DE59-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DE59-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.51</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE59-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485313.47 721158.96 1.02 485315.81 721172.22 1.02 485324.32 721170.72 1.02 485321.98 721157.45 1.02 485313.47 721158.96 1.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE59-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485313.47 721158.96 1.02 485321.98 721157.45 1.02 485321.98 721157.45 4.53 485313.47 721158.96 4.53 485313.47 721158.96 1.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE59-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485321.98 721157.45 1.02 485324.32 721170.72 1.02 485324.32 721170.72 4.53 485321.98 721157.45 4.53 485321.98 721157.45 1.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE59-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485324.32 721170.72 1.02 485315.81 721172.22 1.02 485315.81 721172.22 4.53 485324.32 721170.72 4.53 485324.32 721170.72 1.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE59-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485315.81 721172.22 1.02 485313.47 721158.96 1.02 485313.47 721158.96 4.53 485315.81 721172.22 4.53 485315.81 721172.22 1.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE59-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485313.47 721158.96 4.53 485321.98 721157.45 4.53 485324.32 721170.72 4.53 485315.81 721172.22 4.53 485313.47 721158.96 4.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DA74-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DA74-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.3</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DA74-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483976.13 721550.22 3.87 483980.56 721561.91 3.87 483990.05 721558.31 3.87 483985.52 721546.57 3.87 483976.13 721550.22 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DA74-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483976.13 721550.22 3.87 483985.52 721546.57 3.87 483985.52 721546.57 12.170000000000002 483976.13 721550.22 12.170000000000002 483976.13 721550.22 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DA74-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483985.52 721546.57 3.87 483990.05 721558.31 3.87 483990.05 721558.31 12.170000000000002 483985.52 721546.57 12.170000000000002 483985.52 721546.57 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DA74-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483990.05 721558.31 3.87 483980.56 721561.91 3.87 483980.56 721561.91 12.170000000000002 483990.05 721558.31 12.170000000000002 483990.05 721558.31 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DA74-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483980.56 721561.91 3.87 483976.13 721550.22 3.87 483976.13 721550.22 12.170000000000002 483980.56 721561.91 12.170000000000002 483980.56 721561.91 3.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DA74-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483976.13 721550.22 12.170000000000002 483985.52 721546.57 12.170000000000002 483990.05 721558.31 12.170000000000002 483980.56 721561.91 12.170000000000002 483976.13 721550.22 12.170000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C689-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.56</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483818.1 721619.67 5.61 483831.62 721654.6 5.61 483844.7 721649.48 5.61 483839.63 721636.35 5.61 483844.65 721634.36 5.61 483847.65 721642.16 5.61 483856.9 721638.56 5.61 483849.66 721620.87 5.61 483839 721625.03 5.61 483839.85 721627.22 5.61 483836.6 721628.5 5.61 483831.15 721614.54 5.61 483818.1 721619.67 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483818.1 721619.67 5.61 483831.15 721614.54 5.61 483831.15 721614.54 10.17 483818.1 721619.67 10.17 483818.1 721619.67 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483831.15 721614.54 5.61 483836.6 721628.5 5.61 483836.6 721628.5 10.17 483831.15 721614.54 10.17 483831.15 721614.54 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483836.6 721628.5 5.61 483839.85 721627.22 5.61 483839.85 721627.22 10.17 483836.6 721628.5 10.17 483836.6 721628.5 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483839.85 721627.22 5.61 483839 721625.03 5.61 483839 721625.03 10.17 483839.85 721627.22 10.17 483839.85 721627.22 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483839 721625.03 5.61 483849.66 721620.87 5.61 483849.66 721620.87 10.17 483839 721625.03 10.17 483839 721625.03 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483849.66 721620.87 5.61 483856.9 721638.56 5.61 483856.9 721638.56 10.17 483849.66 721620.87 10.17 483849.66 721620.87 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483856.9 721638.56 5.61 483847.65 721642.16 5.61 483847.65 721642.16 10.17 483856.9 721638.56 10.17 483856.9 721638.56 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483847.65 721642.16 5.61 483844.65 721634.36 5.61 483844.65 721634.36 10.17 483847.65 721642.16 10.17 483847.65 721642.16 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483844.65 721634.36 5.61 483839.63 721636.35 5.61 483839.63 721636.35 10.17 483844.65 721634.36 10.17 483844.65 721634.36 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483839.63 721636.35 5.61 483844.7 721649.48 5.61 483844.7 721649.48 10.17 483839.63 721636.35 10.17 483839.63 721636.35 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483844.7 721649.48 5.61 483831.62 721654.6 5.61 483831.62 721654.6 10.17 483844.7 721649.48 10.17 483844.7 721649.48 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483831.62 721654.6 5.61 483818.1 721619.67 5.61 483818.1 721619.67 10.17 483831.62 721654.6 10.17 483831.62 721654.6 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C689-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483818.1 721619.67 10.17 483831.15 721614.54 10.17 483836.6 721628.5 10.17 483839.85 721627.22 10.17 483839 721625.03 10.17 483849.66 721620.87 10.17 483856.9 721638.56 10.17 483847.65 721642.16 10.17 483844.65 721634.36 10.17 483839.63 721636.35 10.17 483844.7 721649.48 10.17 483831.62 721654.6 10.17 483818.1 721619.67 10.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC54-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC54-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.98</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC54-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484891.83 721320.1 3.1 484896.42 721319.2 3.1 484896.26 721318.41 3.1 484899.52 721317.76 3.1 484897.9 721309.6 3.1 484886.82 721311.79 3.1 484888.43 721319.95 3.1 484891.68 721319.32 3.1 484891.83 721320.1 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC54-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484891.83 721320.1 3.1 484891.68 721319.32 3.1 484891.68 721319.32 10.08 484891.83 721320.1 10.08 484891.83 721320.1 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC54-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484891.68 721319.32 3.1 484888.43 721319.95 3.1 484888.43 721319.95 10.08 484891.68 721319.32 10.08 484891.68 721319.32 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC54-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484888.43 721319.95 3.1 484886.82 721311.79 3.1 484886.82 721311.79 10.08 484888.43 721319.95 10.08 484888.43 721319.95 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC54-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484886.82 721311.79 3.1 484897.9 721309.6 3.1 484897.9 721309.6 10.08 484886.82 721311.79 10.08 484886.82 721311.79 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC54-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484897.9 721309.6 3.1 484899.52 721317.76 3.1 484899.52 721317.76 10.08 484897.9 721309.6 10.08 484897.9 721309.6 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC54-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484899.52 721317.76 3.1 484896.26 721318.41 3.1 484896.26 721318.41 10.08 484899.52 721317.76 10.08 484899.52 721317.76 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC54-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484896.26 721318.41 3.1 484896.42 721319.2 3.1 484896.42 721319.2 10.08 484896.26 721318.41 10.08 484896.26 721318.41 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC54-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484896.42 721319.2 3.1 484891.83 721320.1 3.1 484891.83 721320.1 10.08 484896.42 721319.2 10.08 484896.42 721319.2 3.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC54-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484891.83 721320.1 10.08 484891.68 721319.32 10.08 484888.43 721319.95 10.08 484886.82 721311.79 10.08 484897.9 721309.6 10.08 484899.52 721317.76 10.08 484896.26 721318.41 10.08 484896.42 721319.2 10.08 484891.83 721320.1 10.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-05E5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-05E5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.8</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484515.12 721176.49 1.83 484525.2 721174.71 1.83 484523.71 721166.29 1.83 484521.58 721166.67 1.83 484520.99 721163.26 1.83 484513.04 721164.67 1.83 484515.12 721176.49 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484515.12 721176.49 1.83 484513.04 721164.67 1.83 484513.04 721164.67 6.63 484515.12 721176.49 6.63 484515.12 721176.49 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484513.04 721164.67 1.83 484520.99 721163.26 1.83 484520.99 721163.26 6.63 484513.04 721164.67 6.63 484513.04 721164.67 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484520.99 721163.26 1.83 484521.58 721166.67 1.83 484521.58 721166.67 6.63 484520.99 721163.26 6.63 484520.99 721163.26 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484521.58 721166.67 1.83 484523.71 721166.29 1.83 484523.71 721166.29 6.63 484521.58 721166.67 6.63 484521.58 721166.67 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484523.71 721166.29 1.83 484525.2 721174.71 1.83 484525.2 721174.71 6.63 484523.71 721166.29 6.63 484523.71 721166.29 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484525.2 721174.71 1.83 484515.12 721176.49 1.83 484515.12 721176.49 6.63 484525.2 721174.71 6.63 484525.2 721174.71 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484515.12 721176.49 6.63 484513.04 721164.67 6.63 484520.99 721163.26 6.63 484521.58 721166.67 6.63 484523.71 721166.29 6.63 484525.2 721174.71 6.63 484515.12 721176.49 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-05E3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-05E3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484476.84 721179.24 1.75 484483.77 721177.97 1.75 484482.19 721169.36 1.75 484475.25 721170.65 1.75 484476.84 721179.24 1.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484476.84 721179.24 1.75 484475.25 721170.65 1.75 484475.25 721170.65 7.6850000000000005 484476.84 721179.24 7.6850000000000005 484476.84 721179.24 1.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484475.25 721170.65 1.75 484482.19 721169.36 1.75 484482.19 721169.36 7.6850000000000005 484475.25 721170.65 7.6850000000000005 484475.25 721170.65 1.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484482.19 721169.36 1.75 484483.77 721177.97 1.75 484483.77 721177.97 7.6850000000000005 484482.19 721169.36 7.6850000000000005 484482.19 721169.36 1.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484483.77 721177.97 1.75 484476.84 721179.24 1.75 484476.84 721179.24 7.6850000000000005 484483.77 721177.97 7.6850000000000005 484483.77 721177.97 1.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-05E3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484476.84 721179.24 7.6850000000000005 484475.25 721170.65 7.6850000000000005 484482.19 721169.36 7.6850000000000005 484483.77 721177.97 7.6850000000000005 484476.84 721179.24 7.6850000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0773-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0773-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.69</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0773-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484608.02 721333.69 4.9 484613.81 721332.5 4.9 484617.57 721331.69 4.9 484617.47 721331.31 4.9 484615.93 721323.83 4.9 484606.4 721325.79 4.9 484608.02 721333.69 4.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0773-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484608.02 721333.69 4.9 484606.4 721325.79 4.9 484606.4 721325.79 9.59 484608.02 721333.69 9.59 484608.02 721333.69 4.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0773-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484606.4 721325.79 4.9 484615.93 721323.83 4.9 484615.93 721323.83 9.59 484606.4 721325.79 9.59 484606.4 721325.79 4.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0773-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484615.93 721323.83 4.9 484617.47 721331.31 4.9 484617.47 721331.31 9.59 484615.93 721323.83 9.59 484615.93 721323.83 4.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0773-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484617.47 721331.31 4.9 484617.57 721331.69 4.9 484617.57 721331.69 9.59 484617.47 721331.31 9.59 484617.47 721331.31 4.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0773-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484617.57 721331.69 4.9 484613.81 721332.5 4.9 484613.81 721332.5 9.59 484617.57 721331.69 9.59 484617.57 721331.69 4.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0773-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484613.81 721332.5 4.9 484608.02 721333.69 4.9 484608.02 721333.69 9.59 484613.81 721332.5 9.59 484613.81 721332.5 4.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0773-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484608.02 721333.69 9.59 484606.4 721325.79 9.59 484615.93 721323.83 9.59 484617.47 721331.31 9.59 484617.57 721331.69 9.59 484613.81 721332.5 9.59 484608.02 721333.69 9.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FD27-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FD27-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.71</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD27-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485227.61 721203.75 1.51 485233.53 721202.52 1.51 485232.14 721195.8 1.51 485226.21 721197.03 1.51 485227.61 721203.75 1.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD27-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485227.61 721203.75 1.51 485226.21 721197.03 1.51 485226.21 721197.03 5.22 485227.61 721203.75 5.22 485227.61 721203.75 1.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD27-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485226.21 721197.03 1.51 485232.14 721195.8 1.51 485232.14 721195.8 5.22 485226.21 721197.03 5.22 485226.21 721197.03 1.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD27-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485232.14 721195.8 1.51 485233.53 721202.52 1.51 485233.53 721202.52 5.22 485232.14 721195.8 5.22 485232.14 721195.8 1.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD27-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485233.53 721202.52 1.51 485227.61 721203.75 1.51 485227.61 721203.75 5.22 485233.53 721202.52 5.22 485233.53 721202.52 1.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD27-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485227.61 721203.75 5.22 485226.21 721197.03 5.22 485232.14 721195.8 5.22 485233.53 721202.52 5.22 485227.61 721203.75 5.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-741E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-741E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.28</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484483.66 721300.86 2.11 484485.61 721306.14 2.11 484492.12 721303.73 2.11 484489.97 721298.59 2.11 484488.82 721295.77 2.11 484482.57 721298.3 2.11 484483.66 721300.86 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484483.66 721300.86 2.11 484482.57 721298.3 2.11 484482.57 721298.3 6.390000000000001 484483.66 721300.86 6.390000000000001 484483.66 721300.86 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484482.57 721298.3 2.11 484488.82 721295.77 2.11 484488.82 721295.77 6.390000000000001 484482.57 721298.3 6.390000000000001 484482.57 721298.3 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484488.82 721295.77 2.11 484489.97 721298.59 2.11 484489.97 721298.59 6.390000000000001 484488.82 721295.77 6.390000000000001 484488.82 721295.77 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484489.97 721298.59 2.11 484492.12 721303.73 2.11 484492.12 721303.73 6.390000000000001 484489.97 721298.59 6.390000000000001 484489.97 721298.59 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484492.12 721303.73 2.11 484485.61 721306.14 2.11 484485.61 721306.14 6.390000000000001 484492.12 721303.73 6.390000000000001 484492.12 721303.73 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484485.61 721306.14 2.11 484483.66 721300.86 2.11 484483.66 721300.86 6.390000000000001 484485.61 721306.14 6.390000000000001 484485.61 721306.14 2.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484483.66 721300.86 6.390000000000001 484482.57 721298.3 6.390000000000001 484488.82 721295.77 6.390000000000001 484489.97 721298.59 6.390000000000001 484492.12 721303.73 6.390000000000001 484485.61 721306.14 6.390000000000001 484483.66 721300.86 6.390000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D144-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D144-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.13</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D144-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484592.61 721156.82 2 484599.86 721155.08 2 484598.42 721149.06 2 484591.17 721150.8 2 484592.61 721156.82 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D144-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484592.61 721156.82 2 484591.17 721150.8 2 484591.17 721150.8 5.13 484592.61 721156.82 5.13 484592.61 721156.82 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D144-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484591.17 721150.8 2 484598.42 721149.06 2 484598.42 721149.06 5.13 484591.17 721150.8 5.13 484591.17 721150.8 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D144-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484598.42 721149.06 2 484599.86 721155.08 2 484599.86 721155.08 5.13 484598.42 721149.06 5.13 484598.42 721149.06 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D144-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484599.86 721155.08 2 484592.61 721156.82 2 484592.61 721156.82 5.13 484599.86 721155.08 5.13 484599.86 721155.08 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D144-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484592.61 721156.82 5.13 484591.17 721150.8 5.13 484598.42 721149.06 5.13 484599.86 721155.08 5.13 484592.61 721156.82 5.13</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CFA6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CFA6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.26</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484482.13 721298.44 2.12 484482.57 721298.3 2.12 484488.82 721295.77 2.12 484485.5 721287.96 2.12 484478.98 721290.52 2.12 484480.8 721295.09 2.12 484482.13 721298.44 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484482.13 721298.44 2.12 484480.8 721295.09 2.12 484480.8 721295.09 5.385 484482.13 721298.44 5.385 484482.13 721298.44 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484480.8 721295.09 2.12 484478.98 721290.52 2.12 484478.98 721290.52 5.385 484480.8 721295.09 5.385 484480.8 721295.09 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484478.98 721290.52 2.12 484485.5 721287.96 2.12 484485.5 721287.96 5.385 484478.98 721290.52 5.385 484478.98 721290.52 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484485.5 721287.96 2.12 484488.82 721295.77 2.12 484488.82 721295.77 5.385 484485.5 721287.96 5.385 484485.5 721287.96 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484488.82 721295.77 2.12 484482.57 721298.3 2.12 484482.57 721298.3 5.385 484488.82 721295.77 5.385 484488.82 721295.77 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA6-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484482.57 721298.3 2.12 484482.13 721298.44 2.12 484482.13 721298.44 5.385 484482.57 721298.3 5.385 484482.57 721298.3 2.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA6-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484482.13 721298.44 5.385 484480.8 721295.09 5.385 484478.98 721290.52 5.385 484485.5 721287.96 5.385 484488.82 721295.77 5.385 484482.57 721298.3 5.385 484482.13 721298.44 5.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD20-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD20-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.82</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD20-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484689.45 721362.46 4.09 484701.45 721360.02 4.09 484701.1 721358.32 4.09 484699.9 721352.42 4.09 484699.01 721348.09 4.09 484687.02 721350.53 4.09 484689.45 721362.46 4.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD20-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484689.45 721362.46 4.09 484687.02 721350.53 4.09 484687.02 721350.53 7.91 484689.45 721362.46 7.91 484689.45 721362.46 4.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD20-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484687.02 721350.53 4.09 484699.01 721348.09 4.09 484699.01 721348.09 7.91 484687.02 721350.53 7.91 484687.02 721350.53 4.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD20-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484699.01 721348.09 4.09 484699.9 721352.42 4.09 484699.9 721352.42 7.91 484699.01 721348.09 7.91 484699.01 721348.09 4.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD20-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484699.9 721352.42 4.09 484701.1 721358.32 4.09 484701.1 721358.32 7.91 484699.9 721352.42 7.91 484699.9 721352.42 4.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD20-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484701.1 721358.32 4.09 484701.45 721360.02 4.09 484701.45 721360.02 7.91 484701.1 721358.32 7.91 484701.1 721358.32 4.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD20-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484701.45 721360.02 4.09 484689.45 721362.46 4.09 484689.45 721362.46 7.91 484701.45 721360.02 7.91 484701.45 721360.02 4.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD20-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484689.45 721362.46 7.91 484687.02 721350.53 7.91 484699.01 721348.09 7.91 484699.9 721352.42 7.91 484701.1 721358.32 7.91 484701.45 721360.02 7.91 484689.45 721362.46 7.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-084C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-084C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.53</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-084C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484850.99 721331.33 3.93 484864.55 721328.76 3.93 484863.11 721319.34 3.93 484849.51 721321.76 3.93 484850.99 721331.33 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-084C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484850.99 721331.33 3.93 484849.51 721321.76 3.93 484849.51 721321.76 11.46 484850.99 721331.33 11.46 484850.99 721331.33 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-084C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484849.51 721321.76 3.93 484863.11 721319.34 3.93 484863.11 721319.34 11.46 484849.51 721321.76 11.46 484849.51 721321.76 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-084C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484863.11 721319.34 3.93 484864.55 721328.76 3.93 484864.55 721328.76 11.46 484863.11 721319.34 11.46 484863.11 721319.34 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-084C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484864.55 721328.76 3.93 484850.99 721331.33 3.93 484850.99 721331.33 11.46 484864.55 721328.76 11.46 484864.55 721328.76 3.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-084C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484850.99 721331.33 11.46 484849.51 721321.76 11.46 484863.11 721319.34 11.46 484864.55 721328.76 11.46 484850.99 721331.33 11.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-06B3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-06B3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.41</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484598.29 721197.64 2.29 484609.87 721195.74 2.29 484611.91 721195.41 2.29 484610.51 721186.9 2.29 484596.9 721189.13 2.29 484598.29 721197.64 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484598.29 721197.64 2.29 484596.9 721189.13 2.29 484596.9 721189.13 7.7 484598.29 721197.64 7.7 484598.29 721197.64 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484596.9 721189.13 2.29 484610.51 721186.9 2.29 484610.51 721186.9 7.7 484596.9 721189.13 7.7 484596.9 721189.13 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484610.51 721186.9 2.29 484611.91 721195.41 2.29 484611.91 721195.41 7.7 484610.51 721186.9 7.7 484610.51 721186.9 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484611.91 721195.41 2.29 484609.87 721195.74 2.29 484609.87 721195.74 7.7 484611.91 721195.41 7.7 484611.91 721195.41 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484609.87 721195.74 2.29 484598.29 721197.64 2.29 484598.29 721197.64 7.7 484609.87 721195.74 7.7 484609.87 721195.74 2.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B3-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484598.29 721197.64 7.7 484596.9 721189.13 7.7 484610.51 721186.9 7.7 484611.91 721195.41 7.7 484609.87 721195.74 7.7 484598.29 721197.64 7.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D3DC-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D3DC-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3DC-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485636.49 722760.77 2.16 485642.3 722768.67 2.16 485649.12 722763.53 2.16 485643.46 722755.72 2.16 485636.49 722760.77 2.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3DC-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485636.49 722760.77 2.16 485643.46 722755.72 2.16 485643.46 722755.72 7.63 485636.49 722760.77 7.63 485636.49 722760.77 2.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3DC-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485643.46 722755.72 2.16 485649.12 722763.53 2.16 485649.12 722763.53 7.63 485643.46 722755.72 7.63 485643.46 722755.72 2.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3DC-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485649.12 722763.53 2.16 485642.3 722768.67 2.16 485642.3 722768.67 7.63 485649.12 722763.53 7.63 485649.12 722763.53 2.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3DC-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485642.3 722768.67 2.16 485636.49 722760.77 2.16 485636.49 722760.77 7.63 485642.3 722768.67 7.63 485642.3 722768.67 2.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3DC-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485636.49 722760.77 7.63 485643.46 722755.72 7.63 485649.12 722763.53 7.63 485642.3 722768.67 7.63 485636.49 722760.77 7.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0777-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0777-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.98</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0777-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484625.93 721228.54 1.48 484634.35 721225.69 1.48 484632.79 721220.42 1.48 484624.15 721223.15 1.48 484624.32 721223.61 1.48 484625.93 721228.54 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0777-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484625.93 721228.54 1.48 484624.32 721223.61 1.48 484624.32 721223.61 5.46 484625.93 721228.54 5.46 484625.93 721228.54 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0777-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484624.32 721223.61 1.48 484624.15 721223.15 1.48 484624.15 721223.15 5.46 484624.32 721223.61 5.46 484624.32 721223.61 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0777-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484624.15 721223.15 1.48 484632.79 721220.42 1.48 484632.79 721220.42 5.46 484624.15 721223.15 5.46 484624.15 721223.15 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0777-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484632.79 721220.42 1.48 484634.35 721225.69 1.48 484634.35 721225.69 5.46 484632.79 721220.42 5.46 484632.79 721220.42 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0777-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484634.35 721225.69 1.48 484625.93 721228.54 1.48 484625.93 721228.54 5.46 484634.35 721225.69 5.46 484634.35 721225.69 1.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0777-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484625.93 721228.54 5.46 484624.32 721223.61 5.46 484624.15 721223.15 5.46 484632.79 721220.42 5.46 484634.35 721225.69 5.46 484625.93 721228.54 5.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0778-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0778-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.54</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0778-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484611.62 721239.64 1.39 484618.91 721237.34 1.39 484618.73 721236.75 1.39 484616.94 721231.1 1.39 484615.59 721226.82 1.39 484611.62 721228.08 1.39 484613.98 721235.54 1.39 484610.65 721236.59 1.39 484611.62 721239.64 1.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0778-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484611.62 721239.64 1.39 484610.65 721236.59 1.39 484610.65 721236.59 7.930000000000001 484611.62 721239.64 7.930000000000001 484611.62 721239.64 1.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0778-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484610.65 721236.59 1.39 484613.98 721235.54 1.39 484613.98 721235.54 7.930000000000001 484610.65 721236.59 7.930000000000001 484610.65 721236.59 1.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0778-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484613.98 721235.54 1.39 484611.62 721228.08 1.39 484611.62 721228.08 7.930000000000001 484613.98 721235.54 7.930000000000001 484613.98 721235.54 1.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0778-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484611.62 721228.08 1.39 484615.59 721226.82 1.39 484615.59 721226.82 7.930000000000001 484611.62 721228.08 7.930000000000001 484611.62 721228.08 1.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0778-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484615.59 721226.82 1.39 484616.94 721231.1 1.39 484616.94 721231.1 7.930000000000001 484615.59 721226.82 7.930000000000001 484615.59 721226.82 1.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0778-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484616.94 721231.1 1.39 484618.73 721236.75 1.39 484618.73 721236.75 7.930000000000001 484616.94 721231.1 7.930000000000001 484616.94 721231.1 1.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0778-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484618.73 721236.75 1.39 484618.91 721237.34 1.39 484618.91 721237.34 7.930000000000001 484618.73 721236.75 7.930000000000001 484618.73 721236.75 1.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0778-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484618.91 721237.34 1.39 484611.62 721239.64 1.39 484611.62 721239.64 7.930000000000001 484618.91 721237.34 7.930000000000001 484618.91 721237.34 1.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0778-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484611.62 721239.64 7.930000000000001 484610.65 721236.59 7.930000000000001 484613.98 721235.54 7.930000000000001 484611.62 721228.08 7.930000000000001 484615.59 721226.82 7.930000000000001 484616.94 721231.1 7.930000000000001 484618.73 721236.75 7.930000000000001 484618.91 721237.34 7.930000000000001 484611.62 721239.64 7.930000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6095-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6095-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.69</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6095-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484701.1 721358.32 4.3 484706.96 721357.21 4.3 484705.84 721351.29 4.3 484699.9 721352.42 4.3 484701.1 721358.32 4.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6095-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484701.1 721358.32 4.3 484699.9 721352.42 4.3 484699.9 721352.42 6.99 484701.1 721358.32 6.99 484701.1 721358.32 4.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6095-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484699.9 721352.42 4.3 484705.84 721351.29 4.3 484705.84 721351.29 6.99 484699.9 721352.42 6.99 484699.9 721352.42 4.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6095-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484705.84 721351.29 4.3 484706.96 721357.21 4.3 484706.96 721357.21 6.99 484705.84 721351.29 6.99 484705.84 721351.29 4.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6095-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484706.96 721357.21 4.3 484701.1 721358.32 4.3 484701.1 721358.32 6.99 484706.96 721357.21 6.99 484706.96 721357.21 4.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6095-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484701.1 721358.32 6.99 484699.9 721352.42 6.99 484705.84 721351.29 6.99 484706.96 721357.21 6.99 484701.1 721358.32 6.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D3C5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D3C5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.03</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3C5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485299.88 722660.46 2.21 485305.4 722664.88 2.21 485310.4 722658.61 2.21 485304.85 722654.13 2.21 485299.88 722660.46 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3C5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485299.88 722660.46 2.21 485304.85 722654.13 2.21 485304.85 722654.13 6.24 485299.88 722660.46 6.24 485299.88 722660.46 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3C5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485304.85 722654.13 2.21 485310.4 722658.61 2.21 485310.4 722658.61 6.24 485304.85 722654.13 6.24 485304.85 722654.13 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3C5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485310.4 722658.61 2.21 485305.4 722664.88 2.21 485305.4 722664.88 6.24 485310.4 722658.61 6.24 485310.4 722658.61 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3C5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485305.4 722664.88 2.21 485299.88 722660.46 2.21 485299.88 722660.46 6.24 485305.4 722664.88 6.24 485305.4 722664.88 2.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3C5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485299.88 722660.46 6.24 485304.85 722654.13 6.24 485310.4 722658.61 6.24 485305.4 722664.88 6.24 485299.88 722660.46 6.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-06B0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-06B0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.68</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484616.14 721164.11 2.02 484617.05 721173.41 2.02 484620.69 721173.06 2.02 484621.06 721176.05 2.02 484625.08 721175.56 2.02 484623.85 721165.52 2.02 484620.24 721165.81 2.02 484620.03 721163.72 2.02 484616.14 721164.11 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484616.14 721164.11 2.02 484620.03 721163.72 2.02 484620.03 721163.72 8.700000000000001 484616.14 721164.11 8.700000000000001 484616.14 721164.11 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484620.03 721163.72 2.02 484620.24 721165.81 2.02 484620.24 721165.81 8.700000000000001 484620.03 721163.72 8.700000000000001 484620.03 721163.72 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484620.24 721165.81 2.02 484623.85 721165.52 2.02 484623.85 721165.52 8.700000000000001 484620.24 721165.81 8.700000000000001 484620.24 721165.81 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484623.85 721165.52 2.02 484625.08 721175.56 2.02 484625.08 721175.56 8.700000000000001 484623.85 721165.52 8.700000000000001 484623.85 721165.52 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484625.08 721175.56 2.02 484621.06 721176.05 2.02 484621.06 721176.05 8.700000000000001 484625.08 721175.56 8.700000000000001 484625.08 721175.56 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B0-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484621.06 721176.05 2.02 484620.69 721173.06 2.02 484620.69 721173.06 8.700000000000001 484621.06 721176.05 8.700000000000001 484621.06 721176.05 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B0-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484620.69 721173.06 2.02 484617.05 721173.41 2.02 484617.05 721173.41 8.700000000000001 484620.69 721173.06 8.700000000000001 484620.69 721173.06 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B0-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484617.05 721173.41 2.02 484616.14 721164.11 2.02 484616.14 721164.11 8.700000000000001 484617.05 721173.41 8.700000000000001 484617.05 721173.41 2.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06B0-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484616.14 721164.11 8.700000000000001 484620.03 721163.72 8.700000000000001 484620.24 721165.81 8.700000000000001 484623.85 721165.52 8.700000000000001 484625.08 721175.56 8.700000000000001 484621.06 721176.05 8.700000000000001 484620.69 721173.06 8.700000000000001 484617.05 721173.41 8.700000000000001 484616.14 721164.11 8.700000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-50B8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-50B8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.34</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50B8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485705.62 721497.7 1.42 485698.16 721511.22 1.42 485728.3 721527.91 1.42 485735.78 721514.34 1.42 485705.62 721497.7 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50B8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485705.62 721497.7 1.42 485735.78 721514.34 1.42 485735.78 721514.34 7.76 485705.62 721497.7 7.76 485705.62 721497.7 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50B8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485735.78 721514.34 1.42 485728.3 721527.91 1.42 485728.3 721527.91 7.76 485735.78 721514.34 7.76 485735.78 721514.34 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50B8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485728.3 721527.91 1.42 485698.16 721511.22 1.42 485698.16 721511.22 7.76 485728.3 721527.91 7.76 485728.3 721527.91 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50B8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485698.16 721511.22 1.42 485705.62 721497.7 1.42 485705.62 721497.7 7.76 485698.16 721511.22 7.76 485698.16 721511.22 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50B8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485705.62 721497.7 7.76 485735.78 721514.34 7.76 485728.3 721527.91 7.76 485698.16 721511.22 7.76 485705.62 721497.7 7.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC59-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC59-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.98</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC59-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484923.22 721318.87 2.84 484923.76 721318.8 2.84 484923.99 721320.59 2.84 484929.15 721319.94 2.84 484928.92 721318.15 2.84 484931 721317.9 2.84 484929.89 721308.92 2.84 484922.08 721309.88 2.84 484923.22 721318.87 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC59-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484923.22 721318.87 2.84 484922.08 721309.88 2.84 484922.08 721309.88 8.82 484923.22 721318.87 8.82 484923.22 721318.87 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC59-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.08 721309.88 2.84 484929.89 721308.92 2.84 484929.89 721308.92 8.82 484922.08 721309.88 8.82 484922.08 721309.88 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC59-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484929.89 721308.92 2.84 484931 721317.9 2.84 484931 721317.9 8.82 484929.89 721308.92 8.82 484929.89 721308.92 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC59-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484931 721317.9 2.84 484928.92 721318.15 2.84 484928.92 721318.15 8.82 484931 721317.9 8.82 484931 721317.9 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC59-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484928.92 721318.15 2.84 484929.15 721319.94 2.84 484929.15 721319.94 8.82 484928.92 721318.15 8.82 484928.92 721318.15 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC59-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484929.15 721319.94 2.84 484923.99 721320.59 2.84 484923.99 721320.59 8.82 484929.15 721319.94 8.82 484929.15 721319.94 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC59-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484923.99 721320.59 2.84 484923.76 721318.8 2.84 484923.76 721318.8 8.82 484923.99 721320.59 8.82 484923.99 721320.59 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC59-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484923.76 721318.8 2.84 484923.22 721318.87 2.84 484923.22 721318.87 8.82 484923.76 721318.8 8.82 484923.76 721318.8 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC59-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484923.22 721318.87 8.82 484922.08 721309.88 8.82 484929.89 721308.92 8.82 484931 721317.9 8.82 484928.92 721318.15 8.82 484929.15 721319.94 8.82 484923.99 721320.59 8.82 484923.76 721318.8 8.82 484923.22 721318.87 8.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-06AF-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-06AF-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">8.23</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AF-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484657.73 721229.45 1.72 484665.65 721226.19 1.72 484662 721217.29 1.72 484654.08 721220.53 1.72 484657.73 721229.45 1.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AF-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484657.73 721229.45 1.72 484654.08 721220.53 1.72 484654.08 721220.53 9.950000000000001 484657.73 721229.45 9.950000000000001 484657.73 721229.45 1.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AF-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484654.08 721220.53 1.72 484662 721217.29 1.72 484662 721217.29 9.950000000000001 484654.08 721220.53 9.950000000000001 484654.08 721220.53 1.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AF-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484662 721217.29 1.72 484665.65 721226.19 1.72 484665.65 721226.19 9.950000000000001 484662 721217.29 9.950000000000001 484662 721217.29 1.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AF-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484665.65 721226.19 1.72 484657.73 721229.45 1.72 484657.73 721229.45 9.950000000000001 484665.65 721226.19 9.950000000000001 484665.65 721226.19 1.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AF-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484657.73 721229.45 9.950000000000001 484654.08 721220.53 9.950000000000001 484662 721217.29 9.950000000000001 484665.65 721226.19 9.950000000000001 484657.73 721229.45 9.950000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-077D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.61</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484708.38 721300.33 3 484713.71 721299.47 3 484713.53 721298.34 3 484714.77 721298.22 3 484713.42 721290.76 3 484709.23 721291.35 3 484709.76 721294.21 3 484706.18 721294.99 3 484705.91 721294.06 3 484702.57 721294.51 3 484703.05 721297.79 3 484704.62 721297.63 3 484704.94 721299.64 3 484708.22 721299.23 3 484708.38 721300.33 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484708.38 721300.33 3 484708.22 721299.23 3 484708.22 721299.23 5.61 484708.38 721300.33 5.61 484708.38 721300.33 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484708.22 721299.23 3 484704.94 721299.64 3 484704.94 721299.64 5.61 484708.22 721299.23 5.61 484708.22 721299.23 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484704.94 721299.64 3 484704.62 721297.63 3 484704.62 721297.63 5.61 484704.94 721299.64 5.61 484704.94 721299.64 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484704.62 721297.63 3 484703.05 721297.79 3 484703.05 721297.79 5.61 484704.62 721297.63 5.61 484704.62 721297.63 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484703.05 721297.79 3 484702.57 721294.51 3 484702.57 721294.51 5.61 484703.05 721297.79 5.61 484703.05 721297.79 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484702.57 721294.51 3 484705.91 721294.06 3 484705.91 721294.06 5.61 484702.57 721294.51 5.61 484702.57 721294.51 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484705.91 721294.06 3 484706.18 721294.99 3 484706.18 721294.99 5.61 484705.91 721294.06 5.61 484705.91 721294.06 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484706.18 721294.99 3 484709.76 721294.21 3 484709.76 721294.21 5.61 484706.18 721294.99 5.61 484706.18 721294.99 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484709.76 721294.21 3 484709.23 721291.35 3 484709.23 721291.35 5.61 484709.76 721294.21 5.61 484709.76 721294.21 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484709.23 721291.35 3 484713.42 721290.76 3 484713.42 721290.76 5.61 484709.23 721291.35 5.61 484709.23 721291.35 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484713.42 721290.76 3 484714.77 721298.22 3 484714.77 721298.22 5.61 484713.42 721290.76 5.61 484713.42 721290.76 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484714.77 721298.22 3 484713.53 721298.34 3 484713.53 721298.34 5.61 484714.77 721298.22 5.61 484714.77 721298.22 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484713.53 721298.34 3 484713.71 721299.47 3 484713.71 721299.47 5.61 484713.53 721298.34 5.61 484713.53 721298.34 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484713.71 721299.47 3 484708.38 721300.33 3 484708.38 721300.33 5.61 484713.71 721299.47 5.61 484713.71 721299.47 3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077D-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484708.38 721300.33 5.61 484708.22 721299.23 5.61 484704.94 721299.64 5.61 484704.62 721297.63 5.61 484703.05 721297.79 5.61 484702.57 721294.51 5.61 484705.91 721294.06 5.61 484706.18 721294.99 5.61 484709.76 721294.21 5.61 484709.23 721291.35 5.61 484713.42 721290.76 5.61 484714.77 721298.22 5.61 484713.53 721298.34 5.61 484713.71 721299.47 5.61 484708.38 721300.33 5.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-077A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-077A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.24</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484640.38 721175.27 1.52 484649.57 721173.77 1.52 484646.81 721156.85 1.52 484637.61 721158.35 1.52 484640.38 721175.27 1.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484640.38 721175.27 1.52 484637.61 721158.35 1.52 484637.61 721158.35 6.76 484640.38 721175.27 6.76 484640.38 721175.27 1.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484637.61 721158.35 1.52 484646.81 721156.85 1.52 484646.81 721156.85 6.76 484637.61 721158.35 6.76 484637.61 721158.35 1.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484646.81 721156.85 1.52 484649.57 721173.77 1.52 484649.57 721173.77 6.76 484646.81 721156.85 6.76 484646.81 721156.85 1.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484649.57 721173.77 1.52 484640.38 721175.27 1.52 484640.38 721175.27 6.76 484649.57 721173.77 6.76 484649.57 721173.77 1.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484640.38 721175.27 6.76 484637.61 721158.35 6.76 484646.81 721156.85 6.76 484649.57 721173.77 6.76 484640.38 721175.27 6.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D074-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D074-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D074-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484424.35 721192.84 1.77 484445.02 721189.51 1.77 484444.17 721184.26 1.77 484432.56 721186.13 1.77 484431.92 721182.16 1.77 484429.75 721182.52 1.77 484430.47 721186.99 1.77 484423.59 721188.1 1.77 484424.35 721192.84 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D074-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484424.35 721192.84 1.77 484423.59 721188.1 1.77 484423.59 721188.1 5.76 484424.35 721192.84 5.76 484424.35 721192.84 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D074-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484423.59 721188.1 1.77 484430.47 721186.99 1.77 484430.47 721186.99 5.76 484423.59 721188.1 5.76 484423.59 721188.1 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D074-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484430.47 721186.99 1.77 484429.75 721182.52 1.77 484429.75 721182.52 5.76 484430.47 721186.99 5.76 484430.47 721186.99 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D074-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484429.75 721182.52 1.77 484431.92 721182.16 1.77 484431.92 721182.16 5.76 484429.75 721182.52 5.76 484429.75 721182.52 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D074-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484431.92 721182.16 1.77 484432.56 721186.13 1.77 484432.56 721186.13 5.76 484431.92 721182.16 5.76 484431.92 721182.16 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D074-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484432.56 721186.13 1.77 484444.17 721184.26 1.77 484444.17 721184.26 5.76 484432.56 721186.13 5.76 484432.56 721186.13 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D074-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484444.17 721184.26 1.77 484445.02 721189.51 1.77 484445.02 721189.51 5.76 484444.17 721184.26 5.76 484444.17 721184.26 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D074-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484445.02 721189.51 1.77 484424.35 721192.84 1.77 484424.35 721192.84 5.76 484445.02 721189.51 5.76 484445.02 721189.51 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D074-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484424.35 721192.84 5.76 484423.59 721188.1 5.76 484430.47 721186.99 5.76 484429.75 721182.52 5.76 484431.92 721182.16 5.76 484432.56 721186.13 5.76 484444.17 721184.26 5.76 484445.02 721189.51 5.76 484424.35 721192.84 5.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-50B5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-50B5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.7</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50B5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485491.33 722695.45 1.22 485520.86 722717.29 1.22 485556.8 722668.52 1.22 485527.47 722646.76 1.22 485491.33 722695.45 1.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50B5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485491.33 722695.45 1.22 485527.47 722646.76 1.22 485527.47 722646.76 6.92 485491.33 722695.45 6.92 485491.33 722695.45 1.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50B5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485527.47 722646.76 1.22 485556.8 722668.52 1.22 485556.8 722668.52 6.92 485527.47 722646.76 6.92 485527.47 722646.76 1.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50B5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485556.8 722668.52 1.22 485520.86 722717.29 1.22 485520.86 722717.29 6.92 485556.8 722668.52 6.92 485556.8 722668.52 1.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50B5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485520.86 722717.29 1.22 485491.33 722695.45 1.22 485491.33 722695.45 6.92 485520.86 722717.29 6.92 485520.86 722717.29 1.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-50B5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485491.33 722695.45 6.92 485527.47 722646.76 6.92 485556.8 722668.52 6.92 485520.86 722717.29 6.92 485491.33 722695.45 6.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0841-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0841-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.24</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0841-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484716.73 721356.36 3.71 484726.69 721354.21 3.71 484724.44 721342.45 3.71 484714.2 721344.58 3.71 484716.73 721356.36 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0841-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484716.73 721356.36 3.71 484714.2 721344.58 3.71 484714.2 721344.58 9.950000000000001 484716.73 721356.36 9.950000000000001 484716.73 721356.36 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0841-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484714.2 721344.58 3.71 484724.44 721342.45 3.71 484724.44 721342.45 9.950000000000001 484714.2 721344.58 9.950000000000001 484714.2 721344.58 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0841-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484724.44 721342.45 3.71 484726.69 721354.21 3.71 484726.69 721354.21 9.950000000000001 484724.44 721342.45 9.950000000000001 484724.44 721342.45 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0841-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484726.69 721354.21 3.71 484716.73 721356.36 3.71 484716.73 721356.36 9.950000000000001 484726.69 721354.21 9.950000000000001 484726.69 721354.21 3.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0841-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484716.73 721356.36 9.950000000000001 484714.2 721344.58 9.950000000000001 484724.44 721342.45 9.950000000000001 484726.69 721354.21 9.950000000000001 484716.73 721356.36 9.950000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0840-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0840-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.67</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0840-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484716.28 721289.68 3.08 484734.3 721289.04 3.08 484733.97 721279.9 3.08 484715.95 721280.53 3.08 484716.28 721289.68 3.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0840-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484716.28 721289.68 3.08 484715.95 721280.53 3.08 484715.95 721280.53 8.75 484716.28 721289.68 8.75 484716.28 721289.68 3.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0840-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484715.95 721280.53 3.08 484733.97 721279.9 3.08 484733.97 721279.9 8.75 484715.95 721280.53 8.75 484715.95 721280.53 3.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0840-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484733.97 721279.9 3.08 484734.3 721289.04 3.08 484734.3 721289.04 8.75 484733.97 721279.9 8.75 484733.97 721279.9 3.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0840-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484734.3 721289.04 3.08 484716.28 721289.68 3.08 484716.28 721289.68 8.75 484734.3 721289.04 8.75 484734.3 721289.04 3.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0840-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484716.28 721289.68 8.75 484715.95 721280.53 8.75 484733.97 721279.9 8.75 484734.3 721289.04 8.75 484716.28 721289.68 8.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC5F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC5F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.79</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484979.25 721318.08 2.64 484981.54 721317.82 2.64 484981.51 721317.62 2.64 484980.71 721311.52 2.64 484979.53 721302.56 2.64 484971.8 721303.53 2.64 484972.94 721312.48 2.64 484978.51 721311.78 2.64 484979.25 721318.08 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484979.25 721318.08 2.64 484978.51 721311.78 2.64 484978.51 721311.78 8.43 484979.25 721318.08 8.43 484979.25 721318.08 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484978.51 721311.78 2.64 484972.94 721312.48 2.64 484972.94 721312.48 8.43 484978.51 721311.78 8.43 484978.51 721311.78 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484972.94 721312.48 2.64 484971.8 721303.53 2.64 484971.8 721303.53 8.43 484972.94 721312.48 8.43 484972.94 721312.48 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484971.8 721303.53 2.64 484979.53 721302.56 2.64 484979.53 721302.56 8.43 484971.8 721303.53 8.43 484971.8 721303.53 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484979.53 721302.56 2.64 484980.71 721311.52 2.64 484980.71 721311.52 8.43 484979.53 721302.56 8.43 484979.53 721302.56 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484980.71 721311.52 2.64 484981.51 721317.62 2.64 484981.51 721317.62 8.43 484980.71 721311.52 8.43 484980.71 721311.52 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484981.51 721317.62 2.64 484981.54 721317.82 2.64 484981.54 721317.82 8.43 484981.51 721317.62 8.43 484981.51 721317.62 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484981.54 721317.82 2.64 484979.25 721318.08 2.64 484979.25 721318.08 8.43 484981.54 721317.82 8.43 484981.54 721317.82 2.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484979.25 721318.08 8.43 484978.51 721311.78 8.43 484972.94 721312.48 8.43 484971.8 721303.53 8.43 484979.53 721302.56 8.43 484980.71 721311.52 8.43 484981.51 721317.62 8.43 484981.54 721317.82 8.43 484979.25 721318.08 8.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC5C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC5C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484947.8 721311.78 2.66 484954.98 721310.54 2.66 484953.57 721302.31 2.66 484944.06 721304.01 2.66 484944.98 721309.31 2.66 484947.3 721308.89 2.66 484947.8 721311.78 2.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484947.8 721311.78 2.66 484947.3 721308.89 2.66 484947.3 721308.89 6.5 484947.8 721311.78 6.5 484947.8 721311.78 2.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484947.3 721308.89 2.66 484944.98 721309.31 2.66 484944.98 721309.31 6.5 484947.3 721308.89 6.5 484947.3 721308.89 2.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484944.98 721309.31 2.66 484944.06 721304.01 2.66 484944.06 721304.01 6.5 484944.98 721309.31 6.5 484944.98 721309.31 2.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484944.06 721304.01 2.66 484953.57 721302.31 2.66 484953.57 721302.31 6.5 484944.06 721304.01 6.5 484944.06 721304.01 2.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484953.57 721302.31 2.66 484954.98 721310.54 2.66 484954.98 721310.54 6.5 484953.57 721302.31 6.5 484953.57 721302.31 2.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484954.98 721310.54 2.66 484947.8 721311.78 2.66 484947.8 721311.78 6.5 484954.98 721310.54 6.5 484954.98 721310.54 2.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484947.8 721311.78 6.5 484947.3 721308.89 6.5 484944.98 721309.31 6.5 484944.06 721304.01 6.5 484953.57 721302.31 6.5 484954.98 721310.54 6.5 484947.8 721311.78 6.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0847-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0847-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.31</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0847-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484803.23 721301.08 2.15 484815.68 721299.24 2.15 484814.56 721290.83 2.15 484811.83 721291.3 2.15 484811.41 721288.86 2.15 484805.07 721289.8 2.15 484805.27 721292.23 2.15 484802.04 721292.68 2.15 484803.23 721301.08 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0847-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484803.23 721301.08 2.15 484802.04 721292.68 2.15 484802.04 721292.68 7.460000000000001 484803.23 721301.08 7.460000000000001 484803.23 721301.08 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0847-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484802.04 721292.68 2.15 484805.27 721292.23 2.15 484805.27 721292.23 7.460000000000001 484802.04 721292.68 7.460000000000001 484802.04 721292.68 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0847-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484805.27 721292.23 2.15 484805.07 721289.8 2.15 484805.07 721289.8 7.460000000000001 484805.27 721292.23 7.460000000000001 484805.27 721292.23 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0847-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484805.07 721289.8 2.15 484811.41 721288.86 2.15 484811.41 721288.86 7.460000000000001 484805.07 721289.8 7.460000000000001 484805.07 721289.8 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0847-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484811.41 721288.86 2.15 484811.83 721291.3 2.15 484811.83 721291.3 7.460000000000001 484811.41 721288.86 7.460000000000001 484811.41 721288.86 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0847-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484811.83 721291.3 2.15 484814.56 721290.83 2.15 484814.56 721290.83 7.460000000000001 484811.83 721291.3 7.460000000000001 484811.83 721291.3 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0847-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484814.56 721290.83 2.15 484815.68 721299.24 2.15 484815.68 721299.24 7.460000000000001 484814.56 721290.83 7.460000000000001 484814.56 721290.83 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0847-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484815.68 721299.24 2.15 484803.23 721301.08 2.15 484803.23 721301.08 7.460000000000001 484815.68 721299.24 7.460000000000001 484815.68 721299.24 2.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0847-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484803.23 721301.08 7.460000000000001 484802.04 721292.68 7.460000000000001 484805.27 721292.23 7.460000000000001 484805.07 721289.8 7.460000000000001 484811.41 721288.86 7.460000000000001 484811.83 721291.3 7.460000000000001 484814.56 721290.83 7.460000000000001 484815.68 721299.24 7.460000000000001 484803.23 721301.08 7.460000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC5B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC5B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.24</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484931 721317.9 2.9 484938.73 721316.93 2.9 484937.58 721307.98 2.9 484929.89 721308.92 2.9 484931 721317.9 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484931 721317.9 2.9 484929.89 721308.92 2.9 484929.89 721308.92 9.14 484931 721317.9 9.14 484931 721317.9 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484929.89 721308.92 2.9 484937.58 721307.98 2.9 484937.58 721307.98 9.14 484929.89 721308.92 9.14 484929.89 721308.92 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484937.58 721307.98 2.9 484938.73 721316.93 2.9 484938.73 721316.93 9.14 484937.58 721307.98 9.14 484937.58 721307.98 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484938.73 721316.93 2.9 484931 721317.9 2.9 484931 721317.9 9.14 484938.73 721316.93 9.14 484938.73 721316.93 2.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC5B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484931 721317.9 9.14 484929.89 721308.92 9.14 484937.58 721307.98 9.14 484938.73 721316.93 9.14 484931 721317.9 9.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D164-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484814.78 721325.92 2.73 484815.61 721330.62 2.73 484814.15 721330.89 2.73 484814.82 721334.66 2.73 484825.4 721332.79 2.73 484825.18 721331.61 2.73 484833.16 721330.23 2.73 484831.75 721322.29 2.73 484825.29 721323.43 2.73 484825.4 721324.02 2.73 484814.78 721325.92 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484814.78 721325.92 2.73 484825.4 721324.02 2.73 484825.4 721324.02 10.72 484814.78 721325.92 10.72 484814.78 721325.92 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484825.4 721324.02 2.73 484825.29 721323.43 2.73 484825.29 721323.43 10.72 484825.4 721324.02 10.72 484825.4 721324.02 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484825.29 721323.43 2.73 484831.75 721322.29 2.73 484831.75 721322.29 10.72 484825.29 721323.43 10.72 484825.29 721323.43 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484831.75 721322.29 2.73 484833.16 721330.23 2.73 484833.16 721330.23 10.72 484831.75 721322.29 10.72 484831.75 721322.29 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484833.16 721330.23 2.73 484825.18 721331.61 2.73 484825.18 721331.61 10.72 484833.16 721330.23 10.72 484833.16 721330.23 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484825.18 721331.61 2.73 484825.4 721332.79 2.73 484825.4 721332.79 10.72 484825.18 721331.61 10.72 484825.18 721331.61 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484825.4 721332.79 2.73 484814.82 721334.66 2.73 484814.82 721334.66 10.72 484825.4 721332.79 10.72 484825.4 721332.79 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484814.82 721334.66 2.73 484814.15 721330.89 2.73 484814.15 721330.89 10.72 484814.82 721334.66 10.72 484814.82 721334.66 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484814.15 721330.89 2.73 484815.61 721330.62 2.73 484815.61 721330.62 10.72 484814.15 721330.89 10.72 484814.15 721330.89 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484815.61 721330.62 2.73 484814.78 721325.92 2.73 484814.78 721325.92 10.72 484815.61 721330.62 10.72 484815.61 721330.62 2.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D164-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484814.78 721325.92 10.72 484825.4 721324.02 10.72 484825.29 721323.43 10.72 484831.75 721322.29 10.72 484833.16 721330.23 10.72 484825.18 721331.61 10.72 484825.4 721332.79 10.72 484814.82 721334.66 10.72 484814.15 721330.89 10.72 484815.61 721330.62 10.72 484814.78 721325.92 10.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D3BB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D3BB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.49</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3BB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485077.73 721323.19 2.88 485083.53 721321.67 2.88 485079.64 721306.81 2.88 485073.83 721308.33 2.88 485077.73 721323.19 2.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3BB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485077.73 721323.19 2.88 485073.83 721308.33 2.88 485073.83 721308.33 6.37 485077.73 721323.19 6.37 485077.73 721323.19 2.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3BB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485073.83 721308.33 2.88 485079.64 721306.81 2.88 485079.64 721306.81 6.37 485073.83 721308.33 6.37 485073.83 721308.33 2.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3BB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485079.64 721306.81 2.88 485083.53 721321.67 2.88 485083.53 721321.67 6.37 485079.64 721306.81 6.37 485079.64 721306.81 2.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3BB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485083.53 721321.67 2.88 485077.73 721323.19 2.88 485077.73 721323.19 6.37 485083.53 721321.67 6.37 485083.53 721321.67 2.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D3BB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485077.73 721323.19 6.37 485073.83 721308.33 6.37 485079.64 721306.81 6.37 485083.53 721321.67 6.37 485077.73 721323.19 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-06AB-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-06AB-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.4</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AB-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484551.59 721190.16 2.27 484558.92 721188.87 2.27 484556.45 721177.51 2.27 484549.2 721179.07 2.27 484550.57 721186.4 2.27 484551.59 721190.16 2.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AB-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484551.59 721190.16 2.27 484550.57 721186.4 2.27 484550.57 721186.4 5.67 484551.59 721190.16 5.67 484551.59 721190.16 2.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AB-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484550.57 721186.4 2.27 484549.2 721179.07 2.27 484549.2 721179.07 5.67 484550.57 721186.4 5.67 484550.57 721186.4 2.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AB-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484549.2 721179.07 2.27 484556.45 721177.51 2.27 484556.45 721177.51 5.67 484549.2 721179.07 5.67 484549.2 721179.07 2.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AB-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484556.45 721177.51 2.27 484558.92 721188.87 2.27 484558.92 721188.87 5.67 484556.45 721177.51 5.67 484556.45 721177.51 2.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AB-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484558.92 721188.87 2.27 484551.59 721190.16 2.27 484551.59 721190.16 5.67 484558.92 721188.87 5.67 484558.92 721188.87 2.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-06AB-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484551.59 721190.16 5.67 484550.57 721186.4 5.67 484549.2 721179.07 5.67 484556.45 721177.51 5.67 484558.92 721188.87 5.67 484551.59 721190.16 5.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D218-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D218-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.4</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D218-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484720.52 721366.92 3.7 484721.49 721371.28 3.7 484728.88 721369.66 3.7 484727.9 721365.26 3.7 484720.52 721366.92 3.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D218-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484720.52 721366.92 3.7 484727.9 721365.26 3.7 484727.9 721365.26 8.095 484720.52 721366.92 8.095 484720.52 721366.92 3.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D218-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484727.9 721365.26 3.7 484728.88 721369.66 3.7 484728.88 721369.66 8.095 484727.9 721365.26 8.095 484727.9 721365.26 3.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D218-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484728.88 721369.66 3.7 484721.49 721371.28 3.7 484721.49 721371.28 8.095 484728.88 721369.66 8.095 484728.88 721369.66 3.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D218-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484721.49 721371.28 3.7 484720.52 721366.92 3.7 484720.52 721366.92 8.095 484721.49 721371.28 8.095 484721.49 721371.28 3.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D218-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484720.52 721366.92 8.095 484727.9 721365.26 8.095 484728.88 721369.66 8.095 484721.49 721371.28 8.095 484720.52 721366.92 8.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-741F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-741F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.88</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484471.11 721246.15 1.58 484469.08 721240.81 1.58 484464.17 721242.64 1.58 484461.84 721237.01 1.58 484457.04 721238.96 1.58 484461.77 721250.16 1.58 484466.96 721247.94 1.58 484469.3 721246.94 1.58 484471.11 721246.15 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484471.11 721246.15 1.58 484469.3 721246.94 1.58 484469.3 721246.94 4.46 484471.11 721246.15 4.46 484471.11 721246.15 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484469.3 721246.94 1.58 484466.96 721247.94 1.58 484466.96 721247.94 4.46 484469.3 721246.94 4.46 484469.3 721246.94 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484466.96 721247.94 1.58 484461.77 721250.16 1.58 484461.77 721250.16 4.46 484466.96 721247.94 4.46 484466.96 721247.94 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484461.77 721250.16 1.58 484457.04 721238.96 1.58 484457.04 721238.96 4.46 484461.77 721250.16 4.46 484461.77 721250.16 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484457.04 721238.96 1.58 484461.84 721237.01 1.58 484461.84 721237.01 4.46 484457.04 721238.96 4.46 484457.04 721238.96 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484461.84 721237.01 1.58 484464.17 721242.64 1.58 484464.17 721242.64 4.46 484461.84 721237.01 4.46 484461.84 721237.01 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484464.17 721242.64 1.58 484469.08 721240.81 1.58 484469.08 721240.81 4.46 484464.17 721242.64 4.46 484464.17 721242.64 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484469.08 721240.81 1.58 484471.11 721246.15 1.58 484471.11 721246.15 4.46 484469.08 721240.81 4.46 484469.08 721240.81 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741F-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484471.11 721246.15 4.46 484469.3 721246.94 4.46 484466.96 721247.94 4.46 484461.77 721250.16 4.46 484457.04 721238.96 4.46 484461.84 721237.01 4.46 484464.17 721242.64 4.46 484469.08 721240.81 4.46 484471.11 721246.15 4.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-622A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-622A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.22</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-622A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484487.82 721312.11 2.27 484494.34 721309.7 2.27 484492.12 721303.73 2.27 484485.61 721306.14 2.27 484487.82 721312.11 2.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-622A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484487.82 721312.11 2.27 484485.61 721306.14 2.27 484485.61 721306.14 6.49 484487.82 721312.11 6.49 484487.82 721312.11 2.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-622A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484485.61 721306.14 2.27 484492.12 721303.73 2.27 484492.12 721303.73 6.49 484485.61 721306.14 6.49 484485.61 721306.14 2.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-622A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484492.12 721303.73 2.27 484494.34 721309.7 2.27 484494.34 721309.7 6.49 484492.12 721303.73 6.49 484492.12 721303.73 2.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-622A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484494.34 721309.7 2.27 484487.82 721312.11 2.27 484487.82 721312.11 6.49 484494.34 721309.7 6.49 484494.34 721309.7 2.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-622A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484487.82 721312.11 6.49 484485.61 721306.14 6.49 484492.12 721303.73 6.49 484494.34 721309.7 6.49 484487.82 721312.11 6.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-796a297c-4bca-4dd9-83b4-2217c8e13cca">
			<gen:stringAttribute name="buildingId">
				<gen:value>796a297c-4bca-4dd9-83b4-2217c8e13cca</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.56</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-796a297c-4bca-4dd9-83b4-2217c8e13cca_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485652.21 721628.44 1.46 485646.74 721638.23 1.46 485679.92 721656.7 1.46 485685.12 721647.18 1.46 485652.21 721628.44 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-796a297c-4bca-4dd9-83b4-2217c8e13cca_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485652.21 721628.44 1.46 485685.12 721647.18 1.46 485685.12 721647.18 7.0200000000000005 485652.21 721628.44 7.0200000000000005 485652.21 721628.44 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-796a297c-4bca-4dd9-83b4-2217c8e13cca_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485685.12 721647.18 1.46 485679.92 721656.7 1.46 485679.92 721656.7 7.0200000000000005 485685.12 721647.18 7.0200000000000005 485685.12 721647.18 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-796a297c-4bca-4dd9-83b4-2217c8e13cca_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485679.92 721656.7 1.46 485646.74 721638.23 1.46 485646.74 721638.23 7.0200000000000005 485679.92 721656.7 7.0200000000000005 485679.92 721656.7 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-796a297c-4bca-4dd9-83b4-2217c8e13cca_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485646.74 721638.23 1.46 485652.21 721628.44 1.46 485652.21 721628.44 7.0200000000000005 485646.74 721638.23 7.0200000000000005 485646.74 721638.23 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-796a297c-4bca-4dd9-83b4-2217c8e13cca_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485652.21 721628.44 7.0200000000000005 485685.12 721647.18 7.0200000000000005 485679.92 721656.7 7.0200000000000005 485646.74 721638.23 7.0200000000000005 485652.21 721628.44 7.0200000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5BD0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5BD0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.97</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5BD0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485697.77 721522.05 1.46 485701.39 721515.44 1.46 485692.17 721510.44 1.46 485688.57 721517.02 1.46 485697.77 721522.05 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5BD0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485697.77 721522.05 1.46 485688.57 721517.02 1.46 485688.57 721517.02 6.43 485697.77 721522.05 6.43 485697.77 721522.05 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5BD0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485688.57 721517.02 1.46 485692.17 721510.44 1.46 485692.17 721510.44 6.43 485688.57 721517.02 6.43 485688.57 721517.02 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5BD0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485692.17 721510.44 1.46 485701.39 721515.44 1.46 485701.39 721515.44 6.43 485692.17 721510.44 6.43 485692.17 721510.44 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5BD0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485701.39 721515.44 1.46 485697.77 721522.05 1.46 485697.77 721522.05 6.43 485701.39 721515.44 6.43 485701.39 721515.44 1.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5BD0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485697.77 721522.05 6.43 485688.57 721517.02 6.43 485692.17 721510.44 6.43 485701.39 721515.44 6.43 485697.77 721522.05 6.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5981-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5981-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.13</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5981-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484610.67 721160.5 1.85 484614.96 721159.58 1.85 484612.66 721146.13 1.85 484607.79 721147.08 1.85 484610.67 721160.5 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5981-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484610.67 721160.5 1.85 484607.79 721147.08 1.85 484607.79 721147.08 4.98 484610.67 721160.5 4.98 484610.67 721160.5 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5981-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484607.79 721147.08 1.85 484612.66 721146.13 1.85 484612.66 721146.13 4.98 484607.79 721147.08 4.98 484607.79 721147.08 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5981-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484612.66 721146.13 1.85 484614.96 721159.58 1.85 484614.96 721159.58 4.98 484612.66 721146.13 4.98 484612.66 721146.13 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5981-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484614.96 721159.58 1.85 484610.67 721160.5 1.85 484610.67 721160.5 4.98 484614.96 721159.58 4.98 484614.96 721159.58 1.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5981-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484610.67 721160.5 4.98 484607.79 721147.08 4.98 484612.66 721146.13 4.98 484614.96 721159.58 4.98 484610.67 721160.5 4.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-57F3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-57F3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.66</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-57F3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485071.74 721235.52 1.89 485076.09 721234.6 1.89 485074.66 721227.85 1.89 485070.31 721228.78 1.89 485071.74 721235.52 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-57F3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485071.74 721235.52 1.89 485070.31 721228.78 1.89 485070.31 721228.78 6.55 485071.74 721235.52 6.55 485071.74 721235.52 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-57F3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485070.31 721228.78 1.89 485074.66 721227.85 1.89 485074.66 721227.85 6.55 485070.31 721228.78 6.55 485070.31 721228.78 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-57F3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485074.66 721227.85 1.89 485076.09 721234.6 1.89 485076.09 721234.6 6.55 485074.66 721227.85 6.55 485074.66 721227.85 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-57F3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485076.09 721234.6 1.89 485071.74 721235.52 1.89 485071.74 721235.52 6.55 485076.09 721234.6 6.55 485076.09 721234.6 1.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-57F3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485071.74 721235.52 6.55 485070.31 721228.78 6.55 485074.66 721227.85 6.55 485076.09 721234.6 6.55 485071.74 721235.52 6.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7951-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7951-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.39</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7951-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.65 721329.3 3.27 484923.19 721333.38 3.27 484933.12 721332.22 3.27 484933.11 721332.14 3.27 484932.14 721325.1 3.27 484932.13 721325.01 3.27 484923.99 721326.14 3.27 484924.38 721329.06 3.27 484922.65 721329.3 3.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7951-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.65 721329.3 3.27 484924.38 721329.06 3.27 484924.38 721329.06 8.66 484922.65 721329.3 8.66 484922.65 721329.3 3.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7951-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484924.38 721329.06 3.27 484923.99 721326.14 3.27 484923.99 721326.14 8.66 484924.38 721329.06 8.66 484924.38 721329.06 3.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7951-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484923.99 721326.14 3.27 484932.13 721325.01 3.27 484932.13 721325.01 8.66 484923.99 721326.14 8.66 484923.99 721326.14 3.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7951-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484932.13 721325.01 3.27 484932.14 721325.1 3.27 484932.14 721325.1 8.66 484932.13 721325.01 8.66 484932.13 721325.01 3.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7951-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484932.14 721325.1 3.27 484933.11 721332.14 3.27 484933.11 721332.14 8.66 484932.14 721325.1 8.66 484932.14 721325.1 3.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7951-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484933.11 721332.14 3.27 484933.12 721332.22 3.27 484933.12 721332.22 8.66 484933.11 721332.14 8.66 484933.11 721332.14 3.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7951-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484933.12 721332.22 3.27 484923.19 721333.38 3.27 484923.19 721333.38 8.66 484933.12 721332.22 8.66 484933.12 721332.22 3.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7951-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484923.19 721333.38 3.27 484922.65 721329.3 3.27 484922.65 721329.3 8.66 484923.19 721333.38 8.66 484923.19 721333.38 3.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7951-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.65 721329.3 8.66 484924.38 721329.06 8.66 484923.99 721326.14 8.66 484932.13 721325.01 8.66 484932.14 721325.1 8.66 484933.11 721332.14 8.66 484933.12 721332.22 8.66 484923.19 721333.38 8.66 484922.65 721329.3 8.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-58C0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-58C0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.71</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-58C0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484423.59 721188.1 1.91 484430.47 721186.99 1.91 484429.75 721182.52 1.91 484429.13 721178.71 1.91 484422.26 721179.83 1.91 484423.59 721188.1 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-58C0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484423.59 721188.1 1.91 484422.26 721179.83 1.91 484422.26 721179.83 7.615 484423.59 721188.1 7.615 484423.59 721188.1 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-58C0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484422.26 721179.83 1.91 484429.13 721178.71 1.91 484429.13 721178.71 7.615 484422.26 721179.83 7.615 484422.26 721179.83 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-58C0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484429.13 721178.71 1.91 484429.75 721182.52 1.91 484429.75 721182.52 7.615 484429.13 721178.71 7.615 484429.13 721178.71 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-58C0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484429.75 721182.52 1.91 484430.47 721186.99 1.91 484430.47 721186.99 7.615 484429.75 721182.52 7.615 484429.75 721182.52 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-58C0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484430.47 721186.99 1.91 484423.59 721188.1 1.91 484423.59 721188.1 7.615 484430.47 721186.99 7.615 484430.47 721186.99 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-58C0-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484423.59 721188.1 7.615 484422.26 721179.83 7.615 484429.13 721178.71 7.615 484429.75 721182.52 7.615 484430.47 721186.99 7.615 484423.59 721188.1 7.615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-5354-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-5354-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5354-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485451.58 722589.34 1.31 485471.37 722585.67 1.31 485469.37 722573.46 1.31 485449.37 722577.09 1.31 485451.58 722589.34 1.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5354-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485451.58 722589.34 1.31 485449.37 722577.09 1.31 485449.37 722577.09 6.600000000000001 485451.58 722589.34 6.600000000000001 485451.58 722589.34 1.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5354-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485449.37 722577.09 1.31 485469.37 722573.46 1.31 485469.37 722573.46 6.600000000000001 485449.37 722577.09 6.600000000000001 485449.37 722577.09 1.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5354-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485469.37 722573.46 1.31 485471.37 722585.67 1.31 485471.37 722585.67 6.600000000000001 485469.37 722573.46 6.600000000000001 485469.37 722573.46 1.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5354-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485471.37 722585.67 1.31 485451.58 722589.34 1.31 485451.58 722589.34 6.600000000000001 485471.37 722585.67 6.600000000000001 485471.37 722585.67 1.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-5354-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485451.58 722589.34 6.600000000000001 485449.37 722577.09 6.600000000000001 485469.37 722573.46 6.600000000000001 485471.37 722585.67 6.600000000000001 485451.58 722589.34 6.600000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-91dcc0ca-a808-419f-b66c-5566c2b24d3f">
			<gen:stringAttribute name="buildingId">
				<gen:value>91dcc0ca-a808-419f-b66c-5566c2b24d3f</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.23</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91dcc0ca-a808-419f-b66c-5566c2b24d3f_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485397.88 722653.34 1.91 485387.6 722666.61 1.91 485405.62 722680.43 1.91 485412.59 722671.35 1.91 485401.94 722663.15 1.91 485405.16 722658.96 1.91 485397.88 722653.34 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91dcc0ca-a808-419f-b66c-5566c2b24d3f_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485397.88 722653.34 1.91 485405.16 722658.96 1.91 485405.16 722658.96 6.140000000000001 485397.88 722653.34 6.140000000000001 485397.88 722653.34 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91dcc0ca-a808-419f-b66c-5566c2b24d3f_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485405.16 722658.96 1.91 485401.94 722663.15 1.91 485401.94 722663.15 6.140000000000001 485405.16 722658.96 6.140000000000001 485405.16 722658.96 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91dcc0ca-a808-419f-b66c-5566c2b24d3f_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485401.94 722663.15 1.91 485412.59 722671.35 1.91 485412.59 722671.35 6.140000000000001 485401.94 722663.15 6.140000000000001 485401.94 722663.15 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91dcc0ca-a808-419f-b66c-5566c2b24d3f_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485412.59 722671.35 1.91 485405.62 722680.43 1.91 485405.62 722680.43 6.140000000000001 485412.59 722671.35 6.140000000000001 485412.59 722671.35 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91dcc0ca-a808-419f-b66c-5566c2b24d3f_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485405.62 722680.43 1.91 485387.6 722666.61 1.91 485387.6 722666.61 6.140000000000001 485405.62 722680.43 6.140000000000001 485405.62 722680.43 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91dcc0ca-a808-419f-b66c-5566c2b24d3f_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485387.6 722666.61 1.91 485397.88 722653.34 1.91 485397.88 722653.34 6.140000000000001 485387.6 722666.61 6.140000000000001 485387.6 722666.61 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-91dcc0ca-a808-419f-b66c-5566c2b24d3f_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485397.88 722653.34 6.140000000000001 485405.16 722658.96 6.140000000000001 485401.94 722663.15 6.140000000000001 485412.59 722671.35 6.140000000000001 485405.62 722680.43 6.140000000000001 485387.6 722666.61 6.140000000000001 485397.88 722653.34 6.140000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7950-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7950-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.62</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7950-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485065.76 721326.05 3.04 485068.65 721325.31 3.04 485065.96 721314.69 3.04 485063.08 721315.41 3.04 485064.51 721321.07 3.04 485061.53 721321.77 3.04 485062.78 721327.09 3.04 485065.76 721326.05 3.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7950-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485065.76 721326.05 3.04 485062.78 721327.09 3.04 485062.78 721327.09 6.655 485065.76 721326.05 6.655 485065.76 721326.05 3.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7950-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485062.78 721327.09 3.04 485061.53 721321.77 3.04 485061.53 721321.77 6.655 485062.78 721327.09 6.655 485062.78 721327.09 3.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7950-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485061.53 721321.77 3.04 485064.51 721321.07 3.04 485064.51 721321.07 6.655 485061.53 721321.77 6.655 485061.53 721321.77 3.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7950-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485064.51 721321.07 3.04 485063.08 721315.41 3.04 485063.08 721315.41 6.655 485064.51 721321.07 6.655 485064.51 721321.07 3.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7950-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485063.08 721315.41 3.04 485065.96 721314.69 3.04 485065.96 721314.69 6.655 485063.08 721315.41 6.655 485063.08 721315.41 3.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7950-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485065.96 721314.69 3.04 485068.65 721325.31 3.04 485068.65 721325.31 6.655 485065.96 721314.69 6.655 485065.96 721314.69 3.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7950-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485068.65 721325.31 3.04 485065.76 721326.05 3.04 485065.76 721326.05 6.655 485068.65 721325.31 6.655 485068.65 721325.31 3.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7950-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485065.76 721326.05 6.655 485062.78 721327.09 6.655 485061.53 721321.77 6.655 485064.51 721321.07 6.655 485063.08 721315.41 6.655 485065.96 721314.69 6.655 485068.65 721325.31 6.655 485065.76 721326.05 6.655</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-b5a6749d-07e5-4036-9662-345e50e895d1">
			<gen:stringAttribute name="buildingId">
				<gen:value>b5a6749d-07e5-4036-9662-345e50e895d1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b5a6749d-07e5-4036-9662-345e50e895d1_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485626.47 721629.28 1.66 485636.81 721635.09 1.66 485644.89 721620.87 1.66 485640.97 721618.73 1.66 485634.93 721615.34 1.66 485626.47 721629.28 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b5a6749d-07e5-4036-9662-345e50e895d1_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485626.47 721629.28 1.66 485634.93 721615.34 1.66 485634.93 721615.34 8.26 485626.47 721629.28 8.26 485626.47 721629.28 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b5a6749d-07e5-4036-9662-345e50e895d1_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485634.93 721615.34 1.66 485640.97 721618.73 1.66 485640.97 721618.73 8.26 485634.93 721615.34 8.26 485634.93 721615.34 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b5a6749d-07e5-4036-9662-345e50e895d1_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485640.97 721618.73 1.66 485644.89 721620.87 1.66 485644.89 721620.87 8.26 485640.97 721618.73 8.26 485640.97 721618.73 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b5a6749d-07e5-4036-9662-345e50e895d1_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485644.89 721620.87 1.66 485636.81 721635.09 1.66 485636.81 721635.09 8.26 485644.89 721620.87 8.26 485644.89 721620.87 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b5a6749d-07e5-4036-9662-345e50e895d1_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485636.81 721635.09 1.66 485626.47 721629.28 1.66 485626.47 721629.28 8.26 485636.81 721635.09 8.26 485636.81 721635.09 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-b5a6749d-07e5-4036-9662-345e50e895d1_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485626.47 721629.28 8.26 485634.93 721615.34 8.26 485640.97 721618.73 8.26 485644.89 721620.87 8.26 485636.81 721635.09 8.26 485626.47 721629.28 8.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-76D2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-76D2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.57</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484928.18 722529.87 1.49 484932.07 722535.76 1.49 484937.21 722532.4 1.49 484937.37 722532.3 1.49 484935.24 722529.05 1.49 484933.53 722526.43 1.49 484928.18 722529.87 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484928.18 722529.87 1.49 484933.53 722526.43 1.49 484933.53 722526.43 5.0600000000000005 484928.18 722529.87 5.0600000000000005 484928.18 722529.87 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484933.53 722526.43 1.49 484935.24 722529.05 1.49 484935.24 722529.05 5.0600000000000005 484933.53 722526.43 5.0600000000000005 484933.53 722526.43 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484935.24 722529.05 1.49 484937.37 722532.3 1.49 484937.37 722532.3 5.0600000000000005 484935.24 722529.05 5.0600000000000005 484935.24 722529.05 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484937.37 722532.3 1.49 484937.21 722532.4 1.49 484937.21 722532.4 5.0600000000000005 484937.37 722532.3 5.0600000000000005 484937.37 722532.3 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484937.21 722532.4 1.49 484932.07 722535.76 1.49 484932.07 722535.76 5.0600000000000005 484937.21 722532.4 5.0600000000000005 484937.21 722532.4 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D2-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484932.07 722535.76 1.49 484928.18 722529.87 1.49 484928.18 722529.87 5.0600000000000005 484932.07 722535.76 5.0600000000000005 484932.07 722535.76 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D2-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484928.18 722529.87 5.0600000000000005 484933.53 722526.43 5.0600000000000005 484935.24 722529.05 5.0600000000000005 484937.37 722532.3 5.0600000000000005 484937.21 722532.4 5.0600000000000005 484932.07 722535.76 5.0600000000000005 484928.18 722529.87 5.0600000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-3EC0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-3EC0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.57</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485737.78 721182.55 1.93 485749.48 721182.22 1.93 485749.39 721167.57 1.93 485750.79 721167.39 1.93 485750.6 721160.48 1.93 485749.25 721160.52 1.93 485749.17 721145.53 1.93 485737.05 721145.87 1.93 485737.78 721182.55 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485737.78 721182.55 1.93 485737.05 721145.87 1.93 485737.05 721145.87 9.5 485737.78 721182.55 9.5 485737.78 721182.55 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485737.05 721145.87 1.93 485749.17 721145.53 1.93 485749.17 721145.53 9.5 485737.05 721145.87 9.5 485737.05 721145.87 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485749.17 721145.53 1.93 485749.25 721160.52 1.93 485749.25 721160.52 9.5 485749.17 721145.53 9.5 485749.17 721145.53 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485749.25 721160.52 1.93 485750.6 721160.48 1.93 485750.6 721160.48 9.5 485749.25 721160.52 9.5 485749.25 721160.52 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485750.6 721160.48 1.93 485750.79 721167.39 1.93 485750.79 721167.39 9.5 485750.6 721160.48 9.5 485750.6 721160.48 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC0-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485750.79 721167.39 1.93 485749.39 721167.57 1.93 485749.39 721167.57 9.5 485750.79 721167.39 9.5 485750.79 721167.39 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC0-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485749.39 721167.57 1.93 485749.48 721182.22 1.93 485749.48 721182.22 9.5 485749.39 721167.57 9.5 485749.39 721167.57 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC0-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485749.48 721182.22 1.93 485737.78 721182.55 1.93 485737.78 721182.55 9.5 485749.48 721182.22 9.5 485749.48 721182.22 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EC0-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485737.78 721182.55 9.5 485737.05 721145.87 9.5 485749.17 721145.53 9.5 485749.25 721160.52 9.5 485750.6 721160.48 9.5 485750.79 721167.39 9.5 485749.39 721167.57 9.5 485749.48 721182.22 9.5 485737.78 721182.55 9.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6FE6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6FE6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.34</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FE6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485091.74 721303.79 2.74 485088.4 721304.72 2.74 485092.18 721319.65 2.74 485095.4 721318.74 2.74 485099.01 721317.82 2.74 485097.47 721311.8 2.74 485093.93 721312.71 2.74 485091.74 721303.79 2.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FE6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485091.74 721303.79 2.74 485093.93 721312.71 2.74 485093.93 721312.71 6.08 485091.74 721303.79 6.08 485091.74 721303.79 2.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FE6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485093.93 721312.71 2.74 485097.47 721311.8 2.74 485097.47 721311.8 6.08 485093.93 721312.71 6.08 485093.93 721312.71 2.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FE6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485097.47 721311.8 2.74 485099.01 721317.82 2.74 485099.01 721317.82 6.08 485097.47 721311.8 6.08 485097.47 721311.8 2.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FE6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485099.01 721317.82 2.74 485095.4 721318.74 2.74 485095.4 721318.74 6.08 485099.01 721317.82 6.08 485099.01 721317.82 2.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FE6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485095.4 721318.74 2.74 485092.18 721319.65 2.74 485092.18 721319.65 6.08 485095.4 721318.74 6.08 485095.4 721318.74 2.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FE6-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485092.18 721319.65 2.74 485088.4 721304.72 2.74 485088.4 721304.72 6.08 485092.18 721319.65 6.08 485092.18 721319.65 2.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FE6-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485088.4 721304.72 2.74 485091.74 721303.79 2.74 485091.74 721303.79 6.08 485088.4 721304.72 6.08 485088.4 721304.72 2.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6FE6-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485091.74 721303.79 6.08 485093.93 721312.71 6.08 485097.47 721311.8 6.08 485099.01 721317.82 6.08 485095.4 721318.74 6.08 485092.18 721319.65 6.08 485088.4 721304.72 6.08 485091.74 721303.79 6.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D2E3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D2E3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.86</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484852.9 721341.04 4.85 484867.6 721338.24 4.85 484866.9 721333.87 4.85 484852.15 721336.48 4.85 484852.9 721341.04 4.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484852.9 721341.04 4.85 484852.15 721336.48 4.85 484852.15 721336.48 7.71 484852.9 721341.04 7.71 484852.9 721341.04 4.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484852.15 721336.48 4.85 484866.9 721333.87 4.85 484866.9 721333.87 7.71 484852.15 721336.48 7.71 484852.15 721336.48 4.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484866.9 721333.87 4.85 484867.6 721338.24 4.85 484867.6 721338.24 7.71 484866.9 721333.87 7.71 484866.9 721333.87 4.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484867.6 721338.24 4.85 484852.9 721341.04 4.85 484852.9 721341.04 7.71 484867.6 721338.24 7.71 484867.6 721338.24 4.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484852.9 721341.04 7.71 484852.15 721336.48 7.71 484866.9 721333.87 7.71 484867.6 721338.24 7.71 484852.9 721341.04 7.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2C9A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2C9A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">13.2</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485031.36 721347.99 3.06 485044.54 721344.66 3.06 485037.72 721317.64 3.06 485024.54 721320.97 3.06 485031.36 721347.99 3.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485031.36 721347.99 3.06 485024.54 721320.97 3.06 485024.54 721320.97 16.26 485031.36 721347.99 16.26 485031.36 721347.99 3.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485024.54 721320.97 3.06 485037.72 721317.64 3.06 485037.72 721317.64 16.26 485024.54 721320.97 16.26 485024.54 721320.97 3.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485037.72 721317.64 3.06 485044.54 721344.66 3.06 485044.54 721344.66 16.26 485037.72 721317.64 16.26 485037.72 721317.64 3.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485044.54 721344.66 3.06 485031.36 721347.99 3.06 485031.36 721347.99 16.26 485044.54 721344.66 16.26 485044.54 721344.66 3.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485031.36 721347.99 16.26 485024.54 721320.97 16.26 485037.72 721317.64 16.26 485044.54 721344.66 16.26 485031.36 721347.99 16.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2C98-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2C98-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C98-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485043.26 721303.88 2.68 485060.4 721299.13 2.68 485057.62 721289.08 2.68 485040.48 721293.85 2.68 485043.26 721303.88 2.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C98-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485043.26 721303.88 2.68 485040.48 721293.85 2.68 485040.48 721293.85 12.23 485043.26 721303.88 12.23 485043.26 721303.88 2.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C98-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485040.48 721293.85 2.68 485057.62 721289.08 2.68 485057.62 721289.08 12.23 485040.48 721293.85 12.23 485040.48 721293.85 2.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C98-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485057.62 721289.08 2.68 485060.4 721299.13 2.68 485060.4 721299.13 12.23 485057.62 721289.08 12.23 485057.62 721289.08 2.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C98-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485060.4 721299.13 2.68 485043.26 721303.88 2.68 485043.26 721303.88 12.23 485060.4 721299.13 12.23 485060.4 721299.13 2.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C98-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485043.26 721303.88 12.23 485040.48 721293.85 12.23 485057.62 721289.08 12.23 485060.4 721299.13 12.23 485043.26 721303.88 12.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2C99-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2C99-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.98</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C99-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485022.84 721300.94 2.46 485033.24 721298.26 2.46 485028.78 721281 2.46 485018.38 721283.67 2.46 485022.84 721300.94 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C99-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485022.84 721300.94 2.46 485018.38 721283.67 2.46 485018.38 721283.67 12.440000000000001 485022.84 721300.94 12.440000000000001 485022.84 721300.94 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C99-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485018.38 721283.67 2.46 485028.78 721281 2.46 485028.78 721281 12.440000000000001 485018.38 721283.67 12.440000000000001 485018.38 721283.67 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C99-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485028.78 721281 2.46 485033.24 721298.26 2.46 485033.24 721298.26 12.440000000000001 485028.78 721281 12.440000000000001 485028.78 721281 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C99-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485033.24 721298.26 2.46 485022.84 721300.94 2.46 485022.84 721300.94 12.440000000000001 485033.24 721298.26 12.440000000000001 485033.24 721298.26 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C99-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485022.84 721300.94 12.440000000000001 485018.38 721283.67 12.440000000000001 485028.78 721281 12.440000000000001 485033.24 721298.26 12.440000000000001 485022.84 721300.94 12.440000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2CA0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2CA0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.38</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485214.56 721252.79 2.54 485224.99 721250.22 2.54 485220.75 721232.96 2.54 485210.3 721235.46 2.54 485214.56 721252.79 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485214.56 721252.79 2.54 485210.3 721235.46 2.54 485210.3 721235.46 11.919999999999998 485214.56 721252.79 11.919999999999998 485214.56 721252.79 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485210.3 721235.46 2.54 485220.75 721232.96 2.54 485220.75 721232.96 11.919999999999998 485210.3 721235.46 11.919999999999998 485210.3 721235.46 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485220.75 721232.96 2.54 485224.99 721250.22 2.54 485224.99 721250.22 11.919999999999998 485220.75 721232.96 11.919999999999998 485220.75 721232.96 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485224.99 721250.22 2.54 485214.56 721252.79 2.54 485214.56 721252.79 11.919999999999998 485224.99 721250.22 11.919999999999998 485224.99 721250.22 2.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485214.56 721252.79 11.919999999999998 485210.3 721235.46 11.919999999999998 485220.75 721232.96 11.919999999999998 485224.99 721250.22 11.919999999999998 485214.56 721252.79 11.919999999999998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2BF4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2BF4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.86</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2BF4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485170.4 721263.39 2.55 485180.91 721260.89 2.55 485176.5 721243.62 2.55 485166.05 721246.11 2.55 485170.4 721263.39 2.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2BF4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485170.4 721263.39 2.55 485166.05 721246.11 2.55 485166.05 721246.11 12.41 485170.4 721263.39 12.41 485170.4 721263.39 2.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2BF4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485166.05 721246.11 2.55 485176.5 721243.62 2.55 485176.5 721243.62 12.41 485166.05 721246.11 12.41 485166.05 721246.11 2.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2BF4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485176.5 721243.62 2.55 485180.91 721260.89 2.55 485180.91 721260.89 12.41 485176.5 721243.62 12.41 485176.5 721243.62 2.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2BF4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485180.91 721260.89 2.55 485170.4 721263.39 2.55 485170.4 721263.39 12.41 485180.91 721260.89 12.41 485180.91 721260.89 2.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2BF4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485170.4 721263.39 12.41 485166.05 721246.11 12.41 485176.5 721243.62 12.41 485180.91 721260.89 12.41 485170.4 721263.39 12.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2C9F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2C9F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.5</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485191.55 721266.73 2.52 485207.82 721262.75 2.52 485205.18 721251.93 2.52 485188.92 721255.91 2.52 485191.55 721266.73 2.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485191.55 721266.73 2.52 485188.92 721255.91 2.52 485188.92 721255.91 13.02 485191.55 721266.73 13.02 485191.55 721266.73 2.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485188.92 721255.91 2.52 485205.18 721251.93 2.52 485205.18 721251.93 13.02 485188.92 721255.91 13.02 485188.92 721255.91 2.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485205.18 721251.93 2.52 485207.82 721262.75 2.52 485207.82 721262.75 13.02 485205.18 721251.93 13.02 485205.18 721251.93 2.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485207.82 721262.75 2.52 485191.55 721266.73 2.52 485191.55 721266.73 13.02 485207.82 721262.75 13.02 485207.82 721262.75 2.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485191.55 721266.73 13.02 485188.92 721255.91 13.02 485205.18 721251.93 13.02 485207.82 721262.75 13.02 485191.55 721266.73 13.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2C9E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2C9E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.03</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485131.52 721281.5 2.07 485164.28 721273.11 2.07 485161.61 721262.66 2.07 485149.19 721265.79 2.07 485148.55 721263.27 2.07 485141.06 721265.15 2.07 485141.69 721267.68 2.07 485128.84 721270.92 2.07 485131.52 721281.5 2.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485131.52 721281.5 2.07 485128.84 721270.92 2.07 485128.84 721270.92 12.1 485131.52 721281.5 12.1 485131.52 721281.5 2.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485128.84 721270.92 2.07 485141.69 721267.68 2.07 485141.69 721267.68 12.1 485128.84 721270.92 12.1 485128.84 721270.92 2.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485141.69 721267.68 2.07 485141.06 721265.15 2.07 485141.06 721265.15 12.1 485141.69 721267.68 12.1 485141.69 721267.68 2.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485141.06 721265.15 2.07 485148.55 721263.27 2.07 485148.55 721263.27 12.1 485141.06 721265.15 12.1 485141.06 721265.15 2.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485148.55 721263.27 2.07 485149.19 721265.79 2.07 485149.19 721265.79 12.1 485148.55 721263.27 12.1 485148.55 721263.27 2.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9E-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485149.19 721265.79 2.07 485161.61 721262.66 2.07 485161.61 721262.66 12.1 485149.19 721265.79 12.1 485149.19 721265.79 2.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9E-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485161.61 721262.66 2.07 485164.28 721273.11 2.07 485164.28 721273.11 12.1 485161.61 721262.66 12.1 485161.61 721262.66 2.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9E-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485164.28 721273.11 2.07 485131.52 721281.5 2.07 485131.52 721281.5 12.1 485164.28 721273.11 12.1 485164.28 721273.11 2.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9E-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485131.52 721281.5 12.1 485128.84 721270.92 12.1 485141.69 721267.68 12.1 485141.06 721265.15 12.1 485148.55 721263.27 12.1 485149.19 721265.79 12.1 485161.61 721262.66 12.1 485164.28 721273.11 12.1 485131.52 721281.5 12.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2C9D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2C9D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.59</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485111.57 721278.25 2.61 485121.69 721275.47 2.61 485117.03 721258.53 2.61 485106.91 721261.31 2.61 485111.57 721278.25 2.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485111.57 721278.25 2.61 485106.91 721261.31 2.61 485106.91 721261.31 12.200000000000001 485111.57 721278.25 12.200000000000001 485111.57 721278.25 2.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485106.91 721261.31 2.61 485117.03 721258.53 2.61 485117.03 721258.53 12.200000000000001 485106.91 721261.31 12.200000000000001 485106.91 721261.31 2.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485117.03 721258.53 2.61 485121.69 721275.47 2.61 485121.69 721275.47 12.200000000000001 485117.03 721258.53 12.200000000000001 485117.03 721258.53 2.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485121.69 721275.47 2.61 485111.57 721278.25 2.61 485111.57 721278.25 12.200000000000001 485121.69 721275.47 12.200000000000001 485121.69 721275.47 2.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485111.57 721278.25 12.200000000000001 485106.91 721261.31 12.200000000000001 485117.03 721258.53 12.200000000000001 485121.69 721275.47 12.200000000000001 485111.57 721278.25 12.200000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2C9B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2C9B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485088.05 721292.91 2.46 485104.3 721288.84 2.46 485101.6 721278.06 2.46 485085.33 721282.12 2.46 485088.05 721292.91 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485088.05 721292.91 2.46 485085.33 721282.12 2.46 485085.33 721282.12 13.060000000000002 485088.05 721292.91 13.060000000000002 485088.05 721292.91 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485085.33 721282.12 2.46 485101.6 721278.06 2.46 485101.6 721278.06 13.060000000000002 485085.33 721282.12 13.060000000000002 485085.33 721282.12 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485101.6 721278.06 2.46 485104.3 721288.84 2.46 485104.3 721288.84 13.060000000000002 485101.6 721278.06 13.060000000000002 485101.6 721278.06 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485104.3 721288.84 2.46 485088.05 721292.91 2.46 485088.05 721292.91 13.060000000000002 485104.3 721288.84 13.060000000000002 485104.3 721288.84 2.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485088.05 721292.91 13.060000000000002 485085.33 721282.12 13.060000000000002 485101.6 721278.06 13.060000000000002 485104.3 721288.84 13.060000000000002 485088.05 721292.91 13.060000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2C9C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2C9C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.49</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485066.67 721289.7 2.55 485077.05 721287.11 2.55 485072.77 721269.9 2.55 485062.38 721272.46 2.55 485066.67 721289.7 2.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485066.67 721289.7 2.55 485062.38 721272.46 2.55 485062.38 721272.46 12.040000000000003 485066.67 721289.7 12.040000000000003 485066.67 721289.7 2.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485062.38 721272.46 2.55 485072.77 721269.9 2.55 485072.77 721269.9 12.040000000000003 485062.38 721272.46 12.040000000000003 485062.38 721272.46 2.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485072.77 721269.9 2.55 485077.05 721287.11 2.55 485077.05 721287.11 12.040000000000003 485072.77 721269.9 12.040000000000003 485072.77 721269.9 2.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485077.05 721287.11 2.55 485066.67 721289.7 2.55 485066.67 721289.7 12.040000000000003 485077.05 721287.11 12.040000000000003 485077.05 721287.11 2.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2C9C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485066.67 721289.7 12.040000000000003 485062.38 721272.46 12.040000000000003 485072.77 721269.9 12.040000000000003 485077.05 721287.11 12.040000000000003 485066.67 721289.7 12.040000000000003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2CA2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2CA2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.38</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485259.46 721244.38 2.01 485269.94 721242.07 2.01 485266.26 721224.71 2.01 485255.74 721226.95 2.01 485259.46 721244.38 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485259.46 721244.38 2.01 485255.74 721226.95 2.01 485255.74 721226.95 12.39 485259.46 721244.38 12.39 485259.46 721244.38 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485255.74 721226.95 2.01 485266.26 721224.71 2.01 485266.26 721224.71 12.39 485255.74 721226.95 12.39 485255.74 721226.95 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485266.26 721224.71 2.01 485269.94 721242.07 2.01 485269.94 721242.07 12.39 485266.26 721224.71 12.39 485266.26 721224.71 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485269.94 721242.07 2.01 485259.46 721244.38 2.01 485259.46 721244.38 12.39 485269.94 721242.07 12.39 485269.94 721242.07 2.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485259.46 721244.38 12.39 485255.74 721226.95 12.39 485266.26 721224.71 12.39 485269.94 721242.07 12.39 485259.46 721244.38 12.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-2CA1-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-2CA1-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.3</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA1-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485235.47 721258.47 2.18 485252.92 721254.8 2.18 485250.72 721244.29 2.18 485233.27 721248 2.18 485235.47 721258.47 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA1-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485235.47 721258.47 2.18 485233.27 721248 2.18 485233.27 721248 12.48 485235.47 721258.47 12.48 485235.47 721258.47 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA1-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485233.27 721248 2.18 485250.72 721244.29 2.18 485250.72 721244.29 12.48 485233.27 721248 12.48 485233.27 721248 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA1-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485250.72 721244.29 2.18 485252.92 721254.8 2.18 485252.92 721254.8 12.48 485250.72 721244.29 12.48 485250.72 721244.29 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA1-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485252.92 721254.8 2.18 485235.47 721258.47 2.18 485235.47 721258.47 12.48 485252.92 721254.8 12.48 485252.92 721254.8 2.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-2CA1-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485235.47 721258.47 12.48 485233.27 721248 12.48 485250.72 721244.29 12.48 485252.92 721254.8 12.48 485235.47 721258.47 12.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1">
			<gen:stringAttribute name="buildingId">
				<gen:value>e2596fab-f893-4d8c-8f51-3b3edbf2c4c1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">12.26</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484101.38 721439.41 3.99 484102.82 721441.58 3.99 484104.81 721443.26 3.99 484107.19 721444.31 3.99 484109.78 721444.64 3.99 484112.35 721444.23 3.99 484114.7 721443.12 3.99 484116.65 721441.38 3.99 484118.03 721439.18 3.99 484118.73 721436.67 3.99 484118.69 721434.06 3.99 484117.92 721431.57 3.99 484116.48 721429.39 3.99 484114.48 721427.71 3.99 484112.1 721426.67 3.99 484109.52 721426.33 3.99 484106.94 721426.74 3.99 484104.58 721427.85 3.99 484102.64 721429.59 3.99 484101.26 721431.81 3.99 484100.57 721434.32 3.99 484100.6 721436.93 3.99 484101.38 721439.41 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484101.38 721439.41 3.99 484100.6 721436.93 3.99 484100.6 721436.93 16.25 484101.38 721439.41 16.25 484101.38 721439.41 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484100.6 721436.93 3.99 484100.57 721434.32 3.99 484100.57 721434.32 16.25 484100.6 721436.93 16.25 484100.6 721436.93 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484100.57 721434.32 3.99 484101.26 721431.81 3.99 484101.26 721431.81 16.25 484100.57 721434.32 16.25 484100.57 721434.32 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484101.26 721431.81 3.99 484102.64 721429.59 3.99 484102.64 721429.59 16.25 484101.26 721431.81 16.25 484101.26 721431.81 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484102.64 721429.59 3.99 484104.58 721427.85 3.99 484104.58 721427.85 16.25 484102.64 721429.59 16.25 484102.64 721429.59 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484104.58 721427.85 3.99 484106.94 721426.74 3.99 484106.94 721426.74 16.25 484104.58 721427.85 16.25 484104.58 721427.85 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484106.94 721426.74 3.99 484109.52 721426.33 3.99 484109.52 721426.33 16.25 484106.94 721426.74 16.25 484106.94 721426.74 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484109.52 721426.33 3.99 484112.1 721426.67 3.99 484112.1 721426.67 16.25 484109.52 721426.33 16.25 484109.52 721426.33 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484112.1 721426.67 3.99 484114.48 721427.71 3.99 484114.48 721427.71 16.25 484112.1 721426.67 16.25 484112.1 721426.67 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484114.48 721427.71 3.99 484116.48 721429.39 3.99 484116.48 721429.39 16.25 484114.48 721427.71 16.25 484114.48 721427.71 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484116.48 721429.39 3.99 484117.92 721431.57 3.99 484117.92 721431.57 16.25 484116.48 721429.39 16.25 484116.48 721429.39 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484117.92 721431.57 3.99 484118.69 721434.06 3.99 484118.69 721434.06 16.25 484117.92 721431.57 16.25 484117.92 721431.57 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484118.69 721434.06 3.99 484118.73 721436.67 3.99 484118.73 721436.67 16.25 484118.69 721434.06 16.25 484118.69 721434.06 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484118.73 721436.67 3.99 484118.03 721439.18 3.99 484118.03 721439.18 16.25 484118.73 721436.67 16.25 484118.73 721436.67 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484118.03 721439.18 3.99 484116.65 721441.38 3.99 484116.65 721441.38 16.25 484118.03 721439.18 16.25 484118.03 721439.18 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484116.65 721441.38 3.99 484114.7 721443.12 3.99 484114.7 721443.12 16.25 484116.65 721441.38 16.25 484116.65 721441.38 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484114.7 721443.12 3.99 484112.35 721444.23 3.99 484112.35 721444.23 16.25 484114.7 721443.12 16.25 484114.7 721443.12 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484112.35 721444.23 3.99 484109.78 721444.64 3.99 484109.78 721444.64 16.25 484112.35 721444.23 16.25 484112.35 721444.23 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484109.78 721444.64 3.99 484107.19 721444.31 3.99 484107.19 721444.31 16.25 484109.78 721444.64 16.25 484109.78 721444.64 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484107.19 721444.31 3.99 484104.81 721443.26 3.99 484104.81 721443.26 16.25 484107.19 721444.31 16.25 484107.19 721444.31 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484104.81 721443.26 3.99 484102.82 721441.58 3.99 484102.82 721441.58 16.25 484104.81 721443.26 16.25 484104.81 721443.26 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484102.82 721441.58 3.99 484101.38 721439.41 3.99 484101.38 721439.41 16.25 484102.82 721441.58 16.25 484102.82 721441.58 3.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-e2596fab-f893-4d8c-8f51-3b3edbf2c4c1_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484101.38 721439.41 16.25 484100.6 721436.93 16.25 484100.57 721434.32 16.25 484101.26 721431.81 16.25 484102.64 721429.59 16.25 484104.58 721427.85 16.25 484106.94 721426.74 16.25 484109.52 721426.33 16.25 484112.1 721426.67 16.25 484114.48 721427.71 16.25 484116.48 721429.39 16.25 484117.92 721431.57 16.25 484118.69 721434.06 16.25 484118.73 721436.67 16.25 484118.03 721439.18 16.25 484116.65 721441.38 16.25 484114.7 721443.12 16.25 484112.35 721444.23 16.25 484109.78 721444.64 16.25 484107.19 721444.31 16.25 484104.81 721443.26 16.25 484102.82 721441.58 16.25 484101.38 721439.41 16.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4">
			<gen:stringAttribute name="buildingId">
				<gen:value>a1bde281-05de-47eb-b5aa-e461a8ddbbc4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.95</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484162.87 721328.77 1.28 484164.94 721334.08 1.28 484167.75 721339.05 1.28 484171.23 721343.56 1.28 484175.31 721347.54 1.28 484179.94 721350.9 1.28 484184.96 721353.55 1.28 484190.36 721355.48 1.28 484195.94 721356.61 1.28 484201.63 721356.95 1.28 484207.32 721356.44 1.28 484212.87 721355.16 1.28 484218.19 721353.07 1.28 484223.15 721350.27 1.28 484227.66 721346.79 1.28 484231.64 721342.7 1.28 484235.01 721338.1 1.28 484237.66 721333.05 1.28 484239.58 721327.68 1.28 484240.72 721322.09 1.28 484241.04 721316.4 1.28 484240.55 721310.71 1.28 484239.26 721305.16 1.28 484237.19 721299.84 1.28 484234.38 721294.87 1.28 484230.9 721290.36 1.28 484226.82 721286.39 1.28 484222.2 721283.03 1.28 484217.16 721280.37 1.28 484211.78 721278.46 1.28 484206.2 721277.31 1.28 484200.5 721276.99 1.28 484194.82 721277.48 1.28 484189.26 721278.76 1.28 484183.94 721280.83 1.28 484178.98 721283.65 1.28 484174.47 721287.12 1.28 484170.5 721291.21 1.28 484167.13 721295.83 1.28 484164.48 721300.87 1.28 484162.55 721306.24 1.28 484161.42 721311.84 1.28 484161.1 721317.53 1.28 484161.58 721323.21 1.28 484162.87 721328.77 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484162.87 721328.77 1.28 484161.58 721323.21 1.28 484161.58 721323.21 4.23 484162.87 721328.77 4.23 484162.87 721328.77 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484161.58 721323.21 1.28 484161.1 721317.53 1.28 484161.1 721317.53 4.23 484161.58 721323.21 4.23 484161.58 721323.21 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484161.1 721317.53 1.28 484161.42 721311.84 1.28 484161.42 721311.84 4.23 484161.1 721317.53 4.23 484161.1 721317.53 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484161.42 721311.84 1.28 484162.55 721306.24 1.28 484162.55 721306.24 4.23 484161.42 721311.84 4.23 484161.42 721311.84 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484162.55 721306.24 1.28 484164.48 721300.87 1.28 484164.48 721300.87 4.23 484162.55 721306.24 4.23 484162.55 721306.24 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484164.48 721300.87 1.28 484167.13 721295.83 1.28 484167.13 721295.83 4.23 484164.48 721300.87 4.23 484164.48 721300.87 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484167.13 721295.83 1.28 484170.5 721291.21 1.28 484170.5 721291.21 4.23 484167.13 721295.83 4.23 484167.13 721295.83 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484170.5 721291.21 1.28 484174.47 721287.12 1.28 484174.47 721287.12 4.23 484170.5 721291.21 4.23 484170.5 721291.21 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484174.47 721287.12 1.28 484178.98 721283.65 1.28 484178.98 721283.65 4.23 484174.47 721287.12 4.23 484174.47 721287.12 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484178.98 721283.65 1.28 484183.94 721280.83 1.28 484183.94 721280.83 4.23 484178.98 721283.65 4.23 484178.98 721283.65 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484183.94 721280.83 1.28 484189.26 721278.76 1.28 484189.26 721278.76 4.23 484183.94 721280.83 4.23 484183.94 721280.83 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484189.26 721278.76 1.28 484194.82 721277.48 1.28 484194.82 721277.48 4.23 484189.26 721278.76 4.23 484189.26 721278.76 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484194.82 721277.48 1.28 484200.5 721276.99 1.28 484200.5 721276.99 4.23 484194.82 721277.48 4.23 484194.82 721277.48 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484200.5 721276.99 1.28 484206.2 721277.31 1.28 484206.2 721277.31 4.23 484200.5 721276.99 4.23 484200.5 721276.99 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484206.2 721277.31 1.28 484211.78 721278.46 1.28 484211.78 721278.46 4.23 484206.2 721277.31 4.23 484206.2 721277.31 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484211.78 721278.46 1.28 484217.16 721280.37 1.28 484217.16 721280.37 4.23 484211.78 721278.46 4.23 484211.78 721278.46 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484217.16 721280.37 1.28 484222.2 721283.03 1.28 484222.2 721283.03 4.23 484217.16 721280.37 4.23 484217.16 721280.37 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484222.2 721283.03 1.28 484226.82 721286.39 1.28 484226.82 721286.39 4.23 484222.2 721283.03 4.23 484222.2 721283.03 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484226.82 721286.39 1.28 484230.9 721290.36 1.28 484230.9 721290.36 4.23 484226.82 721286.39 4.23 484226.82 721286.39 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484230.9 721290.36 1.28 484234.38 721294.87 1.28 484234.38 721294.87 4.23 484230.9 721290.36 4.23 484230.9 721290.36 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484234.38 721294.87 1.28 484237.19 721299.84 1.28 484237.19 721299.84 4.23 484234.38 721294.87 4.23 484234.38 721294.87 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484237.19 721299.84 1.28 484239.26 721305.16 1.28 484239.26 721305.16 4.23 484237.19 721299.84 4.23 484237.19 721299.84 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484239.26 721305.16 1.28 484240.55 721310.71 1.28 484240.55 721310.71 4.23 484239.26 721305.16 4.23 484239.26 721305.16 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484240.55 721310.71 1.28 484241.04 721316.4 1.28 484241.04 721316.4 4.23 484240.55 721310.71 4.23 484240.55 721310.71 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484241.04 721316.4 1.28 484240.72 721322.09 1.28 484240.72 721322.09 4.23 484241.04 721316.4 4.23 484241.04 721316.4 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484240.72 721322.09 1.28 484239.58 721327.68 1.28 484239.58 721327.68 4.23 484240.72 721322.09 4.23 484240.72 721322.09 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484239.58 721327.68 1.28 484237.66 721333.05 1.28 484237.66 721333.05 4.23 484239.58 721327.68 4.23 484239.58 721327.68 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484237.66 721333.05 1.28 484235.01 721338.1 1.28 484235.01 721338.1 4.23 484237.66 721333.05 4.23 484237.66 721333.05 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484235.01 721338.1 1.28 484231.64 721342.7 1.28 484231.64 721342.7 4.23 484235.01 721338.1 4.23 484235.01 721338.1 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484231.64 721342.7 1.28 484227.66 721346.79 1.28 484227.66 721346.79 4.23 484231.64 721342.7 4.23 484231.64 721342.7 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484227.66 721346.79 1.28 484223.15 721350.27 1.28 484223.15 721350.27 4.23 484227.66 721346.79 4.23 484227.66 721346.79 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484223.15 721350.27 1.28 484218.19 721353.07 1.28 484218.19 721353.07 4.23 484223.15 721350.27 4.23 484223.15 721350.27 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484218.19 721353.07 1.28 484212.87 721355.16 1.28 484212.87 721355.16 4.23 484218.19 721353.07 4.23 484218.19 721353.07 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484212.87 721355.16 1.28 484207.32 721356.44 1.28 484207.32 721356.44 4.23 484212.87 721355.16 4.23 484212.87 721355.16 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484207.32 721356.44 1.28 484201.63 721356.95 1.28 484201.63 721356.95 4.23 484207.32 721356.44 4.23 484207.32 721356.44 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484201.63 721356.95 1.28 484195.94 721356.61 1.28 484195.94 721356.61 4.23 484201.63 721356.95 4.23 484201.63 721356.95 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484195.94 721356.61 1.28 484190.36 721355.48 1.28 484190.36 721355.48 4.23 484195.94 721356.61 4.23 484195.94 721356.61 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484190.36 721355.48 1.28 484184.96 721353.55 1.28 484184.96 721353.55 4.23 484190.36 721355.48 4.23 484190.36 721355.48 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484184.96 721353.55 1.28 484179.94 721350.9 1.28 484179.94 721350.9 4.23 484184.96 721353.55 4.23 484184.96 721353.55 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484179.94 721350.9 1.28 484175.31 721347.54 1.28 484175.31 721347.54 4.23 484179.94 721350.9 4.23 484179.94 721350.9 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484175.31 721347.54 1.28 484171.23 721343.56 1.28 484171.23 721343.56 4.23 484175.31 721347.54 4.23 484175.31 721347.54 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484171.23 721343.56 1.28 484167.75 721339.05 1.28 484167.75 721339.05 4.23 484171.23 721343.56 4.23 484171.23 721343.56 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484167.75 721339.05 1.28 484164.94 721334.08 1.28 484164.94 721334.08 4.23 484167.75 721339.05 4.23 484167.75 721339.05 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484164.94 721334.08 1.28 484162.87 721328.77 1.28 484162.87 721328.77 4.23 484164.94 721334.08 4.23 484164.94 721334.08 1.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-a1bde281-05de-47eb-b5aa-e461a8ddbbc4_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484162.87 721328.77 4.23 484161.58 721323.21 4.23 484161.1 721317.53 4.23 484161.42 721311.84 4.23 484162.55 721306.24 4.23 484164.48 721300.87 4.23 484167.13 721295.83 4.23 484170.5 721291.21 4.23 484174.47 721287.12 4.23 484178.98 721283.65 4.23 484183.94 721280.83 4.23 484189.26 721278.76 4.23 484194.82 721277.48 4.23 484200.5 721276.99 4.23 484206.2 721277.31 4.23 484211.78 721278.46 4.23 484217.16 721280.37 4.23 484222.2 721283.03 4.23 484226.82 721286.39 4.23 484230.9 721290.36 4.23 484234.38 721294.87 4.23 484237.19 721299.84 4.23 484239.26 721305.16 4.23 484240.55 721310.71 4.23 484241.04 721316.4 4.23 484240.72 721322.09 4.23 484239.58 721327.68 4.23 484237.66 721333.05 4.23 484235.01 721338.1 4.23 484231.64 721342.7 4.23 484227.66 721346.79 4.23 484223.15 721350.27 4.23 484218.19 721353.07 4.23 484212.87 721355.16 4.23 484207.32 721356.44 4.23 484201.63 721356.95 4.23 484195.94 721356.61 4.23 484190.36 721355.48 4.23 484184.96 721353.55 4.23 484179.94 721350.9 4.23 484175.31 721347.54 4.23 484171.23 721343.56 4.23 484167.75 721339.05 4.23 484164.94 721334.08 4.23 484162.87 721328.77 4.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7">
			<gen:stringAttribute name="buildingId">
				<gen:value>31853585-5ee0-43bd-afb6-af3cea996ca7</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">18.5</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484114.59 721211.76 1.14 484116.65 721217.07 1.14 484119.46 721222.04 1.14 484122.95 721226.55 1.14 484127.03 721230.53 1.14 484131.64 721233.89 1.14 484136.69 721236.54 1.14 484142.06 721238.47 1.14 484147.65 721239.6 1.14 484153.35 721239.91 1.14 484159.03 721239.43 1.14 484164.59 721238.14 1.14 484169.89 721236.07 1.14 484174.86 721233.27 1.14 484179.39 721229.78 1.14 484183.36 721225.7 1.14 484186.71 721221.08 1.14 484189.37 721216.05 1.14 484191.29 721210.67 1.14 484192.42 721205.08 1.14 484192.74 721199.38 1.14 484192.26 721193.71 1.14 484190.97 721188.15 1.14 484188.91 721182.83 1.14 484186.09 721177.86 1.14 484182.62 721173.35 1.14 484178.52 721169.38 1.14 484173.91 721166.02 1.14 484168.87 721163.36 1.14 484163.5 721161.43 1.14 484157.91 721160.31 1.14 484152.21 721159.98 1.14 484146.53 721160.48 1.14 484140.98 721161.76 1.14 484135.66 721163.83 1.14 484130.69 721166.64 1.14 484126.17 721170.12 1.14 484122.2 721174.2 1.14 484118.85 721178.82 1.14 484116.18 721183.86 1.14 484114.28 721189.23 1.14 484113.14 721194.82 1.14 484112.81 721200.52 1.14 484113.29 721206.2 1.14 484114.59 721211.76 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484114.59 721211.76 1.14 484113.29 721206.2 1.14 484113.29 721206.2 19.64 484114.59 721211.76 19.64 484114.59 721211.76 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484113.29 721206.2 1.14 484112.81 721200.52 1.14 484112.81 721200.52 19.64 484113.29 721206.2 19.64 484113.29 721206.2 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484112.81 721200.52 1.14 484113.14 721194.82 1.14 484113.14 721194.82 19.64 484112.81 721200.52 19.64 484112.81 721200.52 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484113.14 721194.82 1.14 484114.28 721189.23 1.14 484114.28 721189.23 19.64 484113.14 721194.82 19.64 484113.14 721194.82 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484114.28 721189.23 1.14 484116.18 721183.86 1.14 484116.18 721183.86 19.64 484114.28 721189.23 19.64 484114.28 721189.23 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484116.18 721183.86 1.14 484118.85 721178.82 1.14 484118.85 721178.82 19.64 484116.18 721183.86 19.64 484116.18 721183.86 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484118.85 721178.82 1.14 484122.2 721174.2 1.14 484122.2 721174.2 19.64 484118.85 721178.82 19.64 484118.85 721178.82 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484122.2 721174.2 1.14 484126.17 721170.12 1.14 484126.17 721170.12 19.64 484122.2 721174.2 19.64 484122.2 721174.2 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484126.17 721170.12 1.14 484130.69 721166.64 1.14 484130.69 721166.64 19.64 484126.17 721170.12 19.64 484126.17 721170.12 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484130.69 721166.64 1.14 484135.66 721163.83 1.14 484135.66 721163.83 19.64 484130.69 721166.64 19.64 484130.69 721166.64 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484135.66 721163.83 1.14 484140.98 721161.76 1.14 484140.98 721161.76 19.64 484135.66 721163.83 19.64 484135.66 721163.83 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484140.98 721161.76 1.14 484146.53 721160.48 1.14 484146.53 721160.48 19.64 484140.98 721161.76 19.64 484140.98 721161.76 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484146.53 721160.48 1.14 484152.21 721159.98 1.14 484152.21 721159.98 19.64 484146.53 721160.48 19.64 484146.53 721160.48 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484152.21 721159.98 1.14 484157.91 721160.31 1.14 484157.91 721160.31 19.64 484152.21 721159.98 19.64 484152.21 721159.98 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484157.91 721160.31 1.14 484163.5 721161.43 1.14 484163.5 721161.43 19.64 484157.91 721160.31 19.64 484157.91 721160.31 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484163.5 721161.43 1.14 484168.87 721163.36 1.14 484168.87 721163.36 19.64 484163.5 721161.43 19.64 484163.5 721161.43 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484168.87 721163.36 1.14 484173.91 721166.02 1.14 484173.91 721166.02 19.64 484168.87 721163.36 19.64 484168.87 721163.36 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484173.91 721166.02 1.14 484178.52 721169.38 1.14 484178.52 721169.38 19.64 484173.91 721166.02 19.64 484173.91 721166.02 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484178.52 721169.38 1.14 484182.62 721173.35 1.14 484182.62 721173.35 19.64 484178.52 721169.38 19.64 484178.52 721169.38 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484182.62 721173.35 1.14 484186.09 721177.86 1.14 484186.09 721177.86 19.64 484182.62 721173.35 19.64 484182.62 721173.35 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484186.09 721177.86 1.14 484188.91 721182.83 1.14 484188.91 721182.83 19.64 484186.09 721177.86 19.64 484186.09 721177.86 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484188.91 721182.83 1.14 484190.97 721188.15 1.14 484190.97 721188.15 19.64 484188.91 721182.83 19.64 484188.91 721182.83 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484190.97 721188.15 1.14 484192.26 721193.71 1.14 484192.26 721193.71 19.64 484190.97 721188.15 19.64 484190.97 721188.15 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484192.26 721193.71 1.14 484192.74 721199.38 1.14 484192.74 721199.38 19.64 484192.26 721193.71 19.64 484192.26 721193.71 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484192.74 721199.38 1.14 484192.42 721205.08 1.14 484192.42 721205.08 19.64 484192.74 721199.38 19.64 484192.74 721199.38 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484192.42 721205.08 1.14 484191.29 721210.67 1.14 484191.29 721210.67 19.64 484192.42 721205.08 19.64 484192.42 721205.08 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484191.29 721210.67 1.14 484189.37 721216.05 1.14 484189.37 721216.05 19.64 484191.29 721210.67 19.64 484191.29 721210.67 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484189.37 721216.05 1.14 484186.71 721221.08 1.14 484186.71 721221.08 19.64 484189.37 721216.05 19.64 484189.37 721216.05 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484186.71 721221.08 1.14 484183.36 721225.7 1.14 484183.36 721225.7 19.64 484186.71 721221.08 19.64 484186.71 721221.08 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484183.36 721225.7 1.14 484179.39 721229.78 1.14 484179.39 721229.78 19.64 484183.36 721225.7 19.64 484183.36 721225.7 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484179.39 721229.78 1.14 484174.86 721233.27 1.14 484174.86 721233.27 19.64 484179.39 721229.78 19.64 484179.39 721229.78 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484174.86 721233.27 1.14 484169.89 721236.07 1.14 484169.89 721236.07 19.64 484174.86 721233.27 19.64 484174.86 721233.27 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484169.89 721236.07 1.14 484164.59 721238.14 1.14 484164.59 721238.14 19.64 484169.89 721236.07 19.64 484169.89 721236.07 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484164.59 721238.14 1.14 484159.03 721239.43 1.14 484159.03 721239.43 19.64 484164.59 721238.14 19.64 484164.59 721238.14 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484159.03 721239.43 1.14 484153.35 721239.91 1.14 484153.35 721239.91 19.64 484159.03 721239.43 19.64 484159.03 721239.43 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484153.35 721239.91 1.14 484147.65 721239.6 1.14 484147.65 721239.6 19.64 484153.35 721239.91 19.64 484153.35 721239.91 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484147.65 721239.6 1.14 484142.06 721238.47 1.14 484142.06 721238.47 19.64 484147.65 721239.6 19.64 484147.65 721239.6 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484142.06 721238.47 1.14 484136.69 721236.54 1.14 484136.69 721236.54 19.64 484142.06 721238.47 19.64 484142.06 721238.47 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484136.69 721236.54 1.14 484131.64 721233.89 1.14 484131.64 721233.89 19.64 484136.69 721236.54 19.64 484136.69 721236.54 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484131.64 721233.89 1.14 484127.03 721230.53 1.14 484127.03 721230.53 19.64 484131.64 721233.89 19.64 484131.64 721233.89 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484127.03 721230.53 1.14 484122.95 721226.55 1.14 484122.95 721226.55 19.64 484127.03 721230.53 19.64 484127.03 721230.53 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484122.95 721226.55 1.14 484119.46 721222.04 1.14 484119.46 721222.04 19.64 484122.95 721226.55 19.64 484122.95 721226.55 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484119.46 721222.04 1.14 484116.65 721217.07 1.14 484116.65 721217.07 19.64 484119.46 721222.04 19.64 484119.46 721222.04 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484116.65 721217.07 1.14 484114.59 721211.76 1.14 484114.59 721211.76 19.64 484116.65 721217.07 19.64 484116.65 721217.07 1.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-31853585-5ee0-43bd-afb6-af3cea996ca7_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484114.59 721211.76 19.64 484113.29 721206.2 19.64 484112.81 721200.52 19.64 484113.14 721194.82 19.64 484114.28 721189.23 19.64 484116.18 721183.86 19.64 484118.85 721178.82 19.64 484122.2 721174.2 19.64 484126.17 721170.12 19.64 484130.69 721166.64 19.64 484135.66 721163.83 19.64 484140.98 721161.76 19.64 484146.53 721160.48 19.64 484152.21 721159.98 19.64 484157.91 721160.31 19.64 484163.5 721161.43 19.64 484168.87 721163.36 19.64 484173.91 721166.02 19.64 484178.52 721169.38 19.64 484182.62 721173.35 19.64 484186.09 721177.86 19.64 484188.91 721182.83 19.64 484190.97 721188.15 19.64 484192.26 721193.71 19.64 484192.74 721199.38 19.64 484192.42 721205.08 19.64 484191.29 721210.67 19.64 484189.37 721216.05 19.64 484186.71 721221.08 19.64 484183.36 721225.7 19.64 484179.39 721229.78 19.64 484174.86 721233.27 19.64 484169.89 721236.07 19.64 484164.59 721238.14 19.64 484159.03 721239.43 19.64 484153.35 721239.91 19.64 484147.65 721239.6 19.64 484142.06 721238.47 19.64 484136.69 721236.54 19.64 484131.64 721233.89 19.64 484127.03 721230.53 19.64 484122.95 721226.55 19.64 484119.46 721222.04 19.64 484116.65 721217.07 19.64 484114.59 721211.76 19.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-3D56-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-3D56-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.14</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D56-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483876.46 721604 5.73 483869.5 721606.71 5.73 483871.71 721612.27 5.73 483849.66 721620.87 5.73 483856.9 721638.56 5.73 483885.62 721627.37 5.73 483876.46 721604 5.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D56-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483876.46 721604 5.73 483885.62 721627.37 5.73 483885.62 721627.37 11.870000000000001 483876.46 721604 11.870000000000001 483876.46 721604 5.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D56-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483885.62 721627.37 5.73 483856.9 721638.56 5.73 483856.9 721638.56 11.870000000000001 483885.62 721627.37 11.870000000000001 483885.62 721627.37 5.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D56-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483856.9 721638.56 5.73 483849.66 721620.87 5.73 483849.66 721620.87 11.870000000000001 483856.9 721638.56 11.870000000000001 483856.9 721638.56 5.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D56-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483849.66 721620.87 5.73 483871.71 721612.27 5.73 483871.71 721612.27 11.870000000000001 483849.66 721620.87 11.870000000000001 483849.66 721620.87 5.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D56-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483871.71 721612.27 5.73 483869.5 721606.71 5.73 483869.5 721606.71 11.870000000000001 483871.71 721612.27 11.870000000000001 483871.71 721612.27 5.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D56-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483869.5 721606.71 5.73 483876.46 721604 5.73 483876.46 721604 11.870000000000001 483869.5 721606.71 11.870000000000001 483869.5 721606.71 5.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D56-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483876.46 721604 11.870000000000001 483885.62 721627.37 11.870000000000001 483856.9 721638.56 11.870000000000001 483849.66 721620.87 11.870000000000001 483871.71 721612.27 11.870000000000001 483869.5 721606.71 11.870000000000001 483876.46 721604 11.870000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-6165-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.28</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484982.77 721327.29 2.89 484986.96 721326.74 2.89 484986.16 721319.1 2.89 484989.3 721318.7 2.89 484988.9 721315.59 2.89 484983.58 721316.28 2.89 484983.19 721316.34 2.89 484983.31 721317.33 2.89 484981.51 721317.62 2.89 484981.54 721317.82 2.89 484981.75 721319.5 2.89 484982.77 721327.29 2.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484982.77 721327.29 2.89 484981.75 721319.5 2.89 484981.75 721319.5 8.17 484982.77 721327.29 8.17 484982.77 721327.29 2.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484981.75 721319.5 2.89 484981.54 721317.82 2.89 484981.54 721317.82 8.17 484981.75 721319.5 8.17 484981.75 721319.5 2.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484981.54 721317.82 2.89 484981.51 721317.62 2.89 484981.51 721317.62 8.17 484981.54 721317.82 8.17 484981.54 721317.82 2.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484981.51 721317.62 2.89 484983.31 721317.33 2.89 484983.31 721317.33 8.17 484981.51 721317.62 8.17 484981.51 721317.62 2.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484983.31 721317.33 2.89 484983.19 721316.34 2.89 484983.19 721316.34 8.17 484983.31 721317.33 8.17 484983.31 721317.33 2.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484983.19 721316.34 2.89 484983.58 721316.28 2.89 484983.58 721316.28 8.17 484983.19 721316.34 8.17 484983.19 721316.34 2.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484983.58 721316.28 2.89 484988.9 721315.59 2.89 484988.9 721315.59 8.17 484983.58 721316.28 8.17 484983.58 721316.28 2.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484988.9 721315.59 2.89 484989.3 721318.7 2.89 484989.3 721318.7 8.17 484988.9 721315.59 8.17 484988.9 721315.59 2.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484989.3 721318.7 2.89 484986.16 721319.1 2.89 484986.16 721319.1 8.17 484989.3 721318.7 8.17 484989.3 721318.7 2.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484986.16 721319.1 2.89 484986.96 721326.74 2.89 484986.96 721326.74 8.17 484986.16 721319.1 8.17 484986.16 721319.1 2.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484986.96 721326.74 2.89 484982.77 721327.29 2.89 484982.77 721327.29 8.17 484986.96 721326.74 8.17 484986.96 721326.74 2.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-6165-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484982.77 721327.29 8.17 484981.75 721319.5 8.17 484981.54 721317.82 8.17 484981.51 721317.62 8.17 484983.31 721317.33 8.17 484983.19 721316.34 8.17 484983.58 721316.28 8.17 484988.9 721315.59 8.17 484989.3 721318.7 8.17 484986.16 721319.1 8.17 484986.96 721326.74 8.17 484982.77 721327.29 8.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-3D58-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-3D58-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.57</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D58-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485634.93 721615.34 1.4 485640.97 721618.73 1.4 485644.89 721620.87 1.4 485687.84 721645.09 1.4 485694.03 721634.16 1.4 485641.2 721604.42 1.4 485634.93 721615.34 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D58-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485634.93 721615.34 1.4 485641.2 721604.42 1.4 485641.2 721604.42 7.970000000000001 485634.93 721615.34 7.970000000000001 485634.93 721615.34 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D58-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485641.2 721604.42 1.4 485694.03 721634.16 1.4 485694.03 721634.16 7.970000000000001 485641.2 721604.42 7.970000000000001 485641.2 721604.42 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D58-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485694.03 721634.16 1.4 485687.84 721645.09 1.4 485687.84 721645.09 7.970000000000001 485694.03 721634.16 7.970000000000001 485694.03 721634.16 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D58-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485687.84 721645.09 1.4 485644.89 721620.87 1.4 485644.89 721620.87 7.970000000000001 485687.84 721645.09 7.970000000000001 485687.84 721645.09 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D58-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485644.89 721620.87 1.4 485640.97 721618.73 1.4 485640.97 721618.73 7.970000000000001 485644.89 721620.87 7.970000000000001 485644.89 721620.87 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D58-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485640.97 721618.73 1.4 485634.93 721615.34 1.4 485634.93 721615.34 7.970000000000001 485640.97 721618.73 7.970000000000001 485640.97 721618.73 1.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3D58-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485634.93 721615.34 7.970000000000001 485641.2 721604.42 7.970000000000001 485694.03 721634.16 7.970000000000001 485687.84 721645.09 7.970000000000001 485644.89 721620.87 7.970000000000001 485640.97 721618.73 7.970000000000001 485634.93 721615.34 7.970000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DE18-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DE18-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE18-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485302.33 722701.2 2 485302.46 722707.76 2 485310.31 722707.63 2 485310.17 722701.08 2 485302.33 722701.2 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE18-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485302.33 722701.2 2 485310.17 722701.08 2 485310.17 722701.08 7.84 485302.33 722701.2 7.84 485302.33 722701.2 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE18-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485310.17 722701.08 2 485310.31 722707.63 2 485310.31 722707.63 7.84 485310.17 722701.08 7.84 485310.17 722701.08 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE18-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485310.31 722707.63 2 485302.46 722707.76 2 485302.46 722707.76 7.84 485310.31 722707.63 7.84 485310.31 722707.63 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE18-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485302.46 722707.76 2 485302.33 722701.2 2 485302.33 722701.2 7.84 485302.46 722707.76 7.84 485302.46 722707.76 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE18-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485302.33 722701.2 7.84 485310.17 722701.08 7.84 485310.31 722707.63 7.84 485302.46 722707.76 7.84 485302.33 722701.2 7.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DE16-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DE16-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.25</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE16-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485287.97 722699.57 1.64 485288.12 722707.71 1.64 485294.61 722707.66 1.64 485294.47 722699.52 1.64 485287.97 722699.57 1.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE16-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485287.97 722699.57 1.64 485294.47 722699.52 1.64 485294.47 722699.52 5.89 485287.97 722699.57 5.89 485287.97 722699.57 1.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE16-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485294.47 722699.52 1.64 485294.61 722707.66 1.64 485294.61 722707.66 5.89 485294.47 722699.52 5.89 485294.47 722699.52 1.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE16-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485294.61 722707.66 1.64 485288.12 722707.71 1.64 485288.12 722707.71 5.89 485294.61 722707.66 5.89 485294.61 722707.66 1.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE16-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485288.12 722707.71 1.64 485287.97 722699.57 1.64 485287.97 722699.57 5.89 485288.12 722707.71 5.89 485288.12 722707.71 1.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE16-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485287.97 722699.57 5.89 485294.47 722699.52 5.89 485294.61 722707.66 5.89 485288.12 722707.71 5.89 485287.97 722699.57 5.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DE17-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DE17-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.54</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE17-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485273.15 722707.54 2.2 485279.66 722707.62 2.2 485279.8 722699.51 2.2 485273.3 722699.3 2.2 485273.15 722707.54 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE17-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485273.15 722707.54 2.2 485273.3 722699.3 2.2 485273.3 722699.3 5.74 485273.15 722707.54 5.74 485273.15 722707.54 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE17-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485273.3 722699.3 2.2 485279.8 722699.51 2.2 485279.8 722699.51 5.74 485273.3 722699.3 5.74 485273.3 722699.3 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE17-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485279.8 722699.51 2.2 485279.66 722707.62 2.2 485279.66 722707.62 5.74 485279.8 722699.51 5.74 485279.8 722699.51 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE17-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485279.66 722707.62 2.2 485273.15 722707.54 2.2 485273.15 722707.54 5.74 485279.66 722707.62 5.74 485279.66 722707.62 2.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DE17-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485273.15 722707.54 5.74 485273.3 722699.3 5.74 485279.8 722699.51 5.74 485279.66 722707.62 5.74 485273.15 722707.54 5.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C8A8-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C8A8-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">10.66</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A8-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485658.63 721585.16 1.49 485668.17 721590.49 1.49 485680.01 721597.14 1.49 485682.12 721593.39 1.49 485696.38 721568.06 1.49 485675.22 721556.08 1.49 485658.63 721585.16 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A8-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485658.63 721585.16 1.49 485675.22 721556.08 1.49 485675.22 721556.08 12.15 485658.63 721585.16 12.15 485658.63 721585.16 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A8-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485675.22 721556.08 1.49 485696.38 721568.06 1.49 485696.38 721568.06 12.15 485675.22 721556.08 12.15 485675.22 721556.08 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A8-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485696.38 721568.06 1.49 485682.12 721593.39 1.49 485682.12 721593.39 12.15 485696.38 721568.06 12.15 485696.38 721568.06 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A8-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485682.12 721593.39 1.49 485680.01 721597.14 1.49 485680.01 721597.14 12.15 485682.12 721593.39 12.15 485682.12 721593.39 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A8-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485680.01 721597.14 1.49 485668.17 721590.49 1.49 485668.17 721590.49 12.15 485680.01 721597.14 12.15 485680.01 721597.14 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A8-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485668.17 721590.49 1.49 485658.63 721585.16 1.49 485658.63 721585.16 12.15 485668.17 721590.49 12.15 485668.17 721590.49 1.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A8-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485658.63 721585.16 12.15 485675.22 721556.08 12.15 485696.38 721568.06 12.15 485682.12 721593.39 12.15 485680.01 721597.14 12.15 485668.17 721590.49 12.15 485658.63 721585.16 12.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CFA9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CFA9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.82</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484241.36 721596.82 6.06 484245.57 721607.62 6.06 484251.27 721605.46 6.06 484247.06 721594.67 6.06 484241.36 721596.82 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484241.36 721596.82 6.06 484247.06 721594.67 6.06 484247.06 721594.67 9.88 484241.36 721596.82 9.88 484241.36 721596.82 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484247.06 721594.67 6.06 484251.27 721605.46 6.06 484251.27 721605.46 9.88 484247.06 721594.67 9.88 484247.06 721594.67 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484251.27 721605.46 6.06 484245.57 721607.62 6.06 484245.57 721607.62 9.88 484251.27 721605.46 9.88 484251.27 721605.46 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484245.57 721607.62 6.06 484241.36 721596.82 6.06 484241.36 721596.82 9.88 484245.57 721607.62 9.88 484245.57 721607.62 6.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CFA9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484241.36 721596.82 9.88 484247.06 721594.67 9.88 484251.27 721605.46 9.88 484245.57 721607.62 9.88 484241.36 721596.82 9.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.06</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484981.51 721317.62 2.47 484983.31 721317.33 2.47 484983.19 721316.34 2.47 484983.58 721316.28 2.47 484982.93 721311.22 2.47 484988.48 721310.47 2.47 484987.3 721301.54 2.47 484979.53 721302.56 2.47 484980.71 721311.52 2.47 484981.51 721317.62 2.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484981.51 721317.62 2.47 484980.71 721311.52 2.47 484980.71 721311.52 8.525 484981.51 721317.62 8.525 484981.51 721317.62 2.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484980.71 721311.52 2.47 484979.53 721302.56 2.47 484979.53 721302.56 8.525 484980.71 721311.52 8.525 484980.71 721311.52 2.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484979.53 721302.56 2.47 484987.3 721301.54 2.47 484987.3 721301.54 8.525 484979.53 721302.56 8.525 484979.53 721302.56 2.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484987.3 721301.54 2.47 484988.48 721310.47 2.47 484988.48 721310.47 8.525 484987.3 721301.54 8.525 484987.3 721301.54 2.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484988.48 721310.47 2.47 484982.93 721311.22 2.47 484982.93 721311.22 8.525 484988.48 721310.47 8.525 484988.48 721310.47 2.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484982.93 721311.22 2.47 484983.58 721316.28 2.47 484983.58 721316.28 8.525 484982.93 721311.22 8.525 484982.93 721311.22 2.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484983.58 721316.28 2.47 484983.19 721316.34 2.47 484983.19 721316.34 8.525 484983.58 721316.28 8.525 484983.58 721316.28 2.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484983.19 721316.34 2.47 484983.31 721317.33 2.47 484983.31 721317.33 8.525 484983.19 721316.34 8.525 484983.19 721316.34 2.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484983.31 721317.33 2.47 484981.51 721317.62 2.47 484981.51 721317.62 8.525 484983.31 721317.33 8.525 484983.31 721317.33 2.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC60-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484981.51 721317.62 8.525 484980.71 721311.52 8.525 484979.53 721302.56 8.525 484987.3 721301.54 8.525 484988.48 721310.47 8.525 484982.93 721311.22 8.525 484983.58 721316.28 8.525 484983.19 721316.34 8.525 484983.31 721317.33 8.525 484981.51 721317.62 8.525</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0518-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0518-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.8</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0518-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484445.36 721253.89 1.84 484452.77 721251 1.84 484449.61 721242.92 1.84 484442.2 721245.83 1.84 484445.36 721253.89 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0518-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484445.36 721253.89 1.84 484442.2 721245.83 1.84 484442.2 721245.83 7.640000000000001 484445.36 721253.89 7.640000000000001 484445.36 721253.89 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0518-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484442.2 721245.83 1.84 484449.61 721242.92 1.84 484449.61 721242.92 7.640000000000001 484442.2 721245.83 7.640000000000001 484442.2 721245.83 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0518-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484449.61 721242.92 1.84 484452.77 721251 1.84 484452.77 721251 7.640000000000001 484449.61 721242.92 7.640000000000001 484449.61 721242.92 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0518-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484452.77 721251 1.84 484445.36 721253.89 1.84 484445.36 721253.89 7.640000000000001 484452.77 721251 7.640000000000001 484452.77 721251 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0518-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484445.36 721253.89 7.640000000000001 484442.2 721245.83 7.640000000000001 484449.61 721242.92 7.640000000000001 484452.77 721251 7.640000000000001 484445.36 721253.89 7.640000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FD2C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FD2C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.77</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD2C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485297.97 721192.85 1.21 485300.95 721192.4 1.21 485299.3 721182.75 1.21 485294.92 721183.39 1.21 485295.94 721190.98 1.21 485297.65 721190.82 1.21 485297.97 721192.85 1.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD2C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485297.97 721192.85 1.21 485297.65 721190.82 1.21 485297.65 721190.82 6.98 485297.97 721192.85 6.98 485297.97 721192.85 1.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD2C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485297.65 721190.82 1.21 485295.94 721190.98 1.21 485295.94 721190.98 6.98 485297.65 721190.82 6.98 485297.65 721190.82 1.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD2C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485295.94 721190.98 1.21 485294.92 721183.39 1.21 485294.92 721183.39 6.98 485295.94 721190.98 6.98 485295.94 721190.98 1.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD2C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485294.92 721183.39 1.21 485299.3 721182.75 1.21 485299.3 721182.75 6.98 485294.92 721183.39 6.98 485294.92 721183.39 1.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD2C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485299.3 721182.75 1.21 485300.95 721192.4 1.21 485300.95 721192.4 6.98 485299.3 721182.75 6.98 485299.3 721182.75 1.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD2C-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485300.95 721192.4 1.21 485297.97 721192.85 1.21 485297.97 721192.85 6.98 485300.95 721192.4 6.98 485300.95 721192.4 1.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FD2C-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485297.97 721192.85 6.98 485297.65 721190.82 6.98 485295.94 721190.98 6.98 485294.92 721183.39 6.98 485299.3 721182.75 6.98 485300.95 721192.4 6.98 485297.97 721192.85 6.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0844-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.24</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484759 721346.87 4.27 484766.02 721345.53 4.27 484766.08 721345.86 4.27 484768.73 721345.36 4.27 484768.66 721345.03 4.27 484774.57 721343.91 4.27 484772.83 721334.86 4.27 484766.42 721336.09 4.27 484766.55 721336.78 4.27 484764.97 721337.1 4.27 484764.84 721336.39 4.27 484761.24 721337.08 4.27 484761.16 721336.59 4.27 484757.72 721337.25 4.27 484757.81 721337.74 4.27 484757.33 721337.83 4.27 484759 721346.87 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484759 721346.87 4.27 484757.33 721337.83 4.27 484757.33 721337.83 10.51 484759 721346.87 10.51 484759 721346.87 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484757.33 721337.83 4.27 484757.81 721337.74 4.27 484757.81 721337.74 10.51 484757.33 721337.83 10.51 484757.33 721337.83 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484757.81 721337.74 4.27 484757.72 721337.25 4.27 484757.72 721337.25 10.51 484757.81 721337.74 10.51 484757.81 721337.74 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484757.72 721337.25 4.27 484761.16 721336.59 4.27 484761.16 721336.59 10.51 484757.72 721337.25 10.51 484757.72 721337.25 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484761.16 721336.59 4.27 484761.24 721337.08 4.27 484761.24 721337.08 10.51 484761.16 721336.59 10.51 484761.16 721336.59 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484761.24 721337.08 4.27 484764.84 721336.39 4.27 484764.84 721336.39 10.51 484761.24 721337.08 10.51 484761.24 721337.08 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484764.84 721336.39 4.27 484764.97 721337.1 4.27 484764.97 721337.1 10.51 484764.84 721336.39 10.51 484764.84 721336.39 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484764.97 721337.1 4.27 484766.55 721336.78 4.27 484766.55 721336.78 10.51 484764.97 721337.1 10.51 484764.97 721337.1 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484766.55 721336.78 4.27 484766.42 721336.09 4.27 484766.42 721336.09 10.51 484766.55 721336.78 10.51 484766.55 721336.78 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484766.42 721336.09 4.27 484772.83 721334.86 4.27 484772.83 721334.86 10.51 484766.42 721336.09 10.51 484766.42 721336.09 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484772.83 721334.86 4.27 484774.57 721343.91 4.27 484774.57 721343.91 10.51 484772.83 721334.86 10.51 484772.83 721334.86 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484774.57 721343.91 4.27 484768.66 721345.03 4.27 484768.66 721345.03 10.51 484774.57 721343.91 10.51 484774.57 721343.91 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484768.66 721345.03 4.27 484768.73 721345.36 4.27 484768.73 721345.36 10.51 484768.66 721345.03 10.51 484768.66 721345.03 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484768.73 721345.36 4.27 484766.08 721345.86 4.27 484766.08 721345.86 10.51 484768.73 721345.36 10.51 484768.73 721345.36 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484766.08 721345.86 4.27 484766.02 721345.53 4.27 484766.02 721345.53 10.51 484766.08 721345.86 10.51 484766.08 721345.86 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484766.02 721345.53 4.27 484759 721346.87 4.27 484759 721346.87 10.51 484766.02 721345.53 10.51 484766.02 721345.53 4.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0844-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484759 721346.87 10.51 484757.33 721337.83 10.51 484757.81 721337.74 10.51 484757.72 721337.25 10.51 484761.16 721336.59 10.51 484761.24 721337.08 10.51 484764.84 721336.39 10.51 484764.97 721337.1 10.51 484766.55 721336.78 10.51 484766.42 721336.09 10.51 484772.83 721334.86 10.51 484774.57 721343.91 10.51 484768.66 721345.03 10.51 484768.73 721345.36 10.51 484766.08 721345.86 10.51 484766.02 721345.53 10.51 484759 721346.87 10.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-0843-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-0843-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.9</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0843-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484788.02 721342.24 4.45 484801.25 721339.68 4.45 484799.81 721332.28 4.45 484786.59 721334.84 4.45 484788.02 721342.24 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0843-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484788.02 721342.24 4.45 484786.59 721334.84 4.45 484786.59 721334.84 10.35 484788.02 721342.24 10.35 484788.02 721342.24 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0843-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484786.59 721334.84 4.45 484799.81 721332.28 4.45 484799.81 721332.28 10.35 484786.59 721334.84 10.35 484786.59 721334.84 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0843-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484799.81 721332.28 4.45 484801.25 721339.68 4.45 484801.25 721339.68 10.35 484799.81 721332.28 10.35 484799.81 721332.28 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0843-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484801.25 721339.68 4.45 484788.02 721342.24 4.45 484788.02 721342.24 10.35 484801.25 721339.68 10.35 484801.25 721339.68 4.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-0843-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484788.02 721342.24 10.35 484786.59 721334.84 10.35 484799.81 721332.28 10.35 484801.25 721339.68 10.35 484788.02 721342.24 10.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-3EBE-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-3EBE-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">6.3</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EBE-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485704.9 721182.97 2.38 485716.96 721182.63 2.38 485715.84 721142.66 2.38 485703.78 721143 2.38 485704.9 721182.97 2.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EBE-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485704.9 721182.97 2.38 485703.78 721143 2.38 485703.78 721143 8.68 485704.9 721182.97 8.68 485704.9 721182.97 2.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EBE-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485703.78 721143 2.38 485715.84 721142.66 2.38 485715.84 721142.66 8.68 485703.78 721143 8.68 485703.78 721143 2.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EBE-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485715.84 721142.66 2.38 485716.96 721182.63 2.38 485716.96 721182.63 8.68 485715.84 721142.66 8.68 485715.84 721142.66 2.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EBE-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485716.96 721182.63 2.38 485704.9 721182.97 2.38 485704.9 721182.97 8.68 485716.96 721182.63 8.68 485716.96 721182.63 2.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-3EBE-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485704.9 721182.97 8.68 485703.78 721143 8.68 485715.84 721142.66 8.68 485716.96 721182.63 8.68 485704.9 721182.97 8.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E096-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">9.85</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485469.38 722594.24 1.12 485474 722619.58 1.12 485477.56 722618.86 1.12 485478.15 722622.14 1.12 485475.49 722622.69 1.12 485480.11 722647.99 1.12 485481.52 722647.73 1.12 485495.36 722657.32 1.12 485505.08 722643.07 1.12 485496.22 722636.82 1.12 485493.09 722619.49 1.12 485489.54 722620.09 1.12 485488.88 722616.83 1.12 485491.57 722616.31 1.12 485486.99 722591.05 1.12 485469.38 722594.24 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485469.38 722594.24 1.12 485486.99 722591.05 1.12 485486.99 722591.05 10.970000000000002 485469.38 722594.24 10.970000000000002 485469.38 722594.24 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485486.99 722591.05 1.12 485491.57 722616.31 1.12 485491.57 722616.31 10.970000000000002 485486.99 722591.05 10.970000000000002 485486.99 722591.05 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485491.57 722616.31 1.12 485488.88 722616.83 1.12 485488.88 722616.83 10.970000000000002 485491.57 722616.31 10.970000000000002 485491.57 722616.31 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485488.88 722616.83 1.12 485489.54 722620.09 1.12 485489.54 722620.09 10.970000000000002 485488.88 722616.83 10.970000000000002 485488.88 722616.83 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485489.54 722620.09 1.12 485493.09 722619.49 1.12 485493.09 722619.49 10.970000000000002 485489.54 722620.09 10.970000000000002 485489.54 722620.09 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485493.09 722619.49 1.12 485496.22 722636.82 1.12 485496.22 722636.82 10.970000000000002 485493.09 722619.49 10.970000000000002 485493.09 722619.49 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485496.22 722636.82 1.12 485505.08 722643.07 1.12 485505.08 722643.07 10.970000000000002 485496.22 722636.82 10.970000000000002 485496.22 722636.82 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485505.08 722643.07 1.12 485495.36 722657.32 1.12 485495.36 722657.32 10.970000000000002 485505.08 722643.07 10.970000000000002 485505.08 722643.07 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485495.36 722657.32 1.12 485481.52 722647.73 1.12 485481.52 722647.73 10.970000000000002 485495.36 722657.32 10.970000000000002 485495.36 722657.32 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485481.52 722647.73 1.12 485480.11 722647.99 1.12 485480.11 722647.99 10.970000000000002 485481.52 722647.73 10.970000000000002 485481.52 722647.73 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485480.11 722647.99 1.12 485475.49 722622.69 1.12 485475.49 722622.69 10.970000000000002 485480.11 722647.99 10.970000000000002 485480.11 722647.99 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485475.49 722622.69 1.12 485478.15 722622.14 1.12 485478.15 722622.14 10.970000000000002 485475.49 722622.69 10.970000000000002 485475.49 722622.69 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485478.15 722622.14 1.12 485477.56 722618.86 1.12 485477.56 722618.86 10.970000000000002 485478.15 722622.14 10.970000000000002 485478.15 722622.14 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485477.56 722618.86 1.12 485474 722619.58 1.12 485474 722619.58 10.970000000000002 485477.56 722618.86 10.970000000000002 485477.56 722618.86 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485474 722619.58 1.12 485469.38 722594.24 1.12 485469.38 722594.24 10.970000000000002 485474 722619.58 10.970000000000002 485474 722619.58 1.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E096-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485469.38 722594.24 10.970000000000002 485486.99 722591.05 10.970000000000002 485491.57 722616.31 10.970000000000002 485488.88 722616.83 10.970000000000002 485489.54 722620.09 10.970000000000002 485493.09 722619.49 10.970000000000002 485496.22 722636.82 10.970000000000002 485505.08 722643.07 10.970000000000002 485495.36 722657.32 10.970000000000002 485481.52 722647.73 10.970000000000002 485480.11 722647.99 10.970000000000002 485475.49 722622.69 10.970000000000002 485478.15 722622.14 10.970000000000002 485477.56 722618.86 10.970000000000002 485474 722619.58 10.970000000000002 485469.38 722594.24 10.970000000000002</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-E095-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-E095-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.97</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E095-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485398.2 722619.63 1.58 485399.17 722624.61 1.58 485413.46 722621.92 1.58 485412.49 722616.91 1.58 485409.9 722617.42 1.58 485409.58 722615.82 1.58 485400.54 722617.39 1.58 485400.86 722619.08 1.58 485398.2 722619.63 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E095-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485398.2 722619.63 1.58 485400.86 722619.08 1.58 485400.86 722619.08 4.55 485398.2 722619.63 4.55 485398.2 722619.63 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E095-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485400.86 722619.08 1.58 485400.54 722617.39 1.58 485400.54 722617.39 4.55 485400.86 722619.08 4.55 485400.86 722619.08 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E095-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485400.54 722617.39 1.58 485409.58 722615.82 1.58 485409.58 722615.82 4.55 485400.54 722617.39 4.55 485400.54 722617.39 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E095-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485409.58 722615.82 1.58 485409.9 722617.42 1.58 485409.9 722617.42 4.55 485409.58 722615.82 4.55 485409.58 722615.82 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E095-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485409.9 722617.42 1.58 485412.49 722616.91 1.58 485412.49 722616.91 4.55 485409.9 722617.42 4.55 485409.9 722617.42 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E095-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485412.49 722616.91 1.58 485413.46 722621.92 1.58 485413.46 722621.92 4.55 485412.49 722616.91 4.55 485412.49 722616.91 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E095-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485413.46 722621.92 1.58 485399.17 722624.61 1.58 485399.17 722624.61 4.55 485413.46 722621.92 4.55 485413.46 722621.92 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E095-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485399.17 722624.61 1.58 485398.2 722619.63 1.58 485398.2 722619.63 4.55 485399.17 722624.61 4.55 485399.17 722624.61 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-E095-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485398.2 722619.63 4.55 485400.86 722619.08 4.55 485400.54 722617.39 4.55 485409.58 722615.82 4.55 485409.9 722617.42 4.55 485412.49 722616.91 4.55 485413.46 722621.92 4.55 485399.17 722624.61 4.55 485398.2 722619.63 4.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CED2-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CED2-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.89</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CED2-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483846.54 721847.06 6.37 483848.68 721852.76 6.37 483859.42 721848.6 6.37 483857.26 721842.89 6.37 483846.54 721847.06 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CED2-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483846.54 721847.06 6.37 483857.26 721842.89 6.37 483857.26 721842.89 10.26 483846.54 721847.06 10.26 483846.54 721847.06 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CED2-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483857.26 721842.89 6.37 483859.42 721848.6 6.37 483859.42 721848.6 10.26 483857.26 721842.89 10.26 483857.26 721842.89 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CED2-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483859.42 721848.6 6.37 483848.68 721852.76 6.37 483848.68 721852.76 10.26 483859.42 721848.6 10.26 483859.42 721848.6 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CED2-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483848.68 721852.76 6.37 483846.54 721847.06 6.37 483846.54 721847.06 10.26 483848.68 721852.76 10.26 483848.68 721852.76 6.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CED2-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483846.54 721847.06 10.26 483857.26 721842.89 10.26 483859.42 721848.6 10.26 483848.68 721852.76 10.26 483846.54 721847.06 10.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">7.08</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485553.8 722777.39 4.03 485554.87 722782.06 4.03 485556.37 722788.5 4.03 485566.06 722786.27 4.03 485566.15 722786.66 4.03 485572.59 722785.18 4.03 485569.96 722773.68 4.03 485569.6 722772.13 4.03 485563.19 722773.62 4.03 485563.53 722775.15 4.03 485553.8 722777.39 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485553.8 722777.39 4.03 485563.53 722775.15 4.03 485563.53 722775.15 11.11 485553.8 722777.39 11.11 485553.8 722777.39 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.53 722775.15 4.03 485563.19 722773.62 4.03 485563.19 722773.62 11.11 485563.53 722775.15 11.11 485563.53 722775.15 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.19 722773.62 4.03 485569.6 722772.13 4.03 485569.6 722772.13 11.11 485563.19 722773.62 11.11 485563.19 722773.62 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485569.6 722772.13 4.03 485569.96 722773.68 4.03 485569.96 722773.68 11.11 485569.6 722772.13 11.11 485569.6 722772.13 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485569.96 722773.68 4.03 485572.59 722785.18 4.03 485572.59 722785.18 11.11 485569.96 722773.68 11.11 485569.96 722773.68 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485572.59 722785.18 4.03 485566.15 722786.66 4.03 485566.15 722786.66 11.11 485572.59 722785.18 11.11 485572.59 722785.18 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485566.15 722786.66 4.03 485566.06 722786.27 4.03 485566.06 722786.27 11.11 485566.15 722786.66 11.11 485566.15 722786.66 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485566.06 722786.27 4.03 485556.37 722788.5 4.03 485556.37 722788.5 11.11 485566.06 722786.27 11.11 485566.06 722786.27 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485556.37 722788.5 4.03 485554.87 722782.06 4.03 485554.87 722782.06 11.11 485556.37 722788.5 11.11 485556.37 722788.5 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485554.87 722782.06 4.03 485553.8 722777.39 4.03 485553.8 722777.39 11.11 485554.87 722782.06 11.11 485554.87 722782.06 4.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A7-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485553.8 722777.39 11.11 485563.53 722775.15 11.11 485563.19 722773.62 11.11 485569.6 722772.13 11.11 485569.96 722773.68 11.11 485572.59 722785.18 11.11 485566.15 722786.66 11.11 485566.06 722786.27 11.11 485556.37 722788.5 11.11 485554.87 722782.06 11.11 485553.8 722777.39 11.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C8A6-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C8A6-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.8</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A6-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485588.96 722773.08 3.51 485590.64 722780.82 3.51 485604.36 722777.76 3.51 485602.72 722770.1 3.51 485588.96 722773.08 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A6-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485588.96 722773.08 3.51 485602.72 722770.1 3.51 485602.72 722770.1 7.3100000000000005 485588.96 722773.08 7.3100000000000005 485588.96 722773.08 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A6-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485602.72 722770.1 3.51 485604.36 722777.76 3.51 485604.36 722777.76 7.3100000000000005 485602.72 722770.1 7.3100000000000005 485602.72 722770.1 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A6-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485604.36 722777.76 3.51 485590.64 722780.82 3.51 485590.64 722780.82 7.3100000000000005 485604.36 722777.76 7.3100000000000005 485604.36 722777.76 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A6-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485590.64 722780.82 3.51 485588.96 722773.08 3.51 485588.96 722773.08 7.3100000000000005 485590.64 722780.82 7.3100000000000005 485590.64 722780.82 3.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A6-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485588.96 722773.08 7.3100000000000005 485602.72 722770.1 7.3100000000000005 485604.36 722777.76 7.3100000000000005 485590.64 722780.82 7.3100000000000005 485588.96 722773.08 7.3100000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.03</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484854.37 722648.1 1.83 484857.22 722651.78 1.83 484858.2 722651.06 1.83 484862.4 722656.42 1.83 484869.18 722651.53 1.83 484864.49 722645.46 1.83 484865.56 722644.6 1.83 484863.51 722641.95 1.83 484862.44 722642.78 1.83 484862.21 722642.47 1.83 484854.37 722648.1 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484854.37 722648.1 1.83 484862.21 722642.47 1.83 484862.21 722642.47 5.86 484854.37 722648.1 5.86 484854.37 722648.1 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484862.21 722642.47 1.83 484862.44 722642.78 1.83 484862.44 722642.78 5.86 484862.21 722642.47 5.86 484862.21 722642.47 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484862.44 722642.78 1.83 484863.51 722641.95 1.83 484863.51 722641.95 5.86 484862.44 722642.78 5.86 484862.44 722642.78 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484863.51 722641.95 1.83 484865.56 722644.6 1.83 484865.56 722644.6 5.86 484863.51 722641.95 5.86 484863.51 722641.95 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484865.56 722644.6 1.83 484864.49 722645.46 1.83 484864.49 722645.46 5.86 484865.56 722644.6 5.86 484865.56 722644.6 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484864.49 722645.46 1.83 484869.18 722651.53 1.83 484869.18 722651.53 5.86 484864.49 722645.46 5.86 484864.49 722645.46 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484869.18 722651.53 1.83 484862.4 722656.42 1.83 484862.4 722656.42 5.86 484869.18 722651.53 5.86 484869.18 722651.53 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484862.4 722656.42 1.83 484858.2 722651.06 1.83 484858.2 722651.06 5.86 484862.4 722656.42 5.86 484862.4 722656.42 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484858.2 722651.06 1.83 484857.22 722651.78 1.83 484857.22 722651.78 5.86 484858.2 722651.06 5.86 484858.2 722651.06 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484857.22 722651.78 1.83 484854.37 722648.1 1.83 484854.37 722648.1 5.86 484857.22 722651.78 5.86 484857.22 722651.78 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-C8A5-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484854.37 722648.1 5.86 484862.21 722642.47 5.86 484862.44 722642.78 5.86 484863.51 722641.95 5.86 484865.56 722644.6 5.86 484864.49 722645.46 5.86 484869.18 722651.53 5.86 484862.4 722656.42 5.86 484858.2 722651.06 5.86 484857.22 722651.78 5.86 484854.37 722648.1 5.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">11.49</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.07 722733.99 1.54 485563.09 722734.52 1.54 485563.2 722735.07 1.54 485563.39 722735.53 1.54 485563.63 722735.86 1.54 485563.8 722736.03 1.54 485564 722736.26 1.54 485564.28 722736.55 1.54 485564.56 722736.77 1.54 485564.82 722736.96 1.54 485565.15 722737.17 1.54 485565.51 722737.36 1.54 485565.88 722737.5 1.54 485566.23 722737.62 1.54 485566.65 722737.71 1.54 485567.22 722737.79 1.54 485567.91 722737.82 1.54 485568.58 722737.77 1.54 485569.12 722737.7 1.54 485569.82 722737.52 1.54 485571.05 722737.05 1.54 485572.59 722736.79 1.54 485573.51 722736.92 1.54 485574.34 722737.03 1.54 485575.33 722737.35 1.54 485576.42 722737.57 1.54 485577.53 722737.56 1.54 485578.59 722737.35 1.54 485579.56 722736.93 1.54 485580.52 722736.49 1.54 485581.45 722736.29 1.54 485582.44 722736.28 1.54 485583.46 722736.34 1.54 485584.53 722736.66 1.54 485585.56 722737.03 1.54 485586.77 722737.21 1.54 485588 722737.15 1.54 485589.11 722736.94 1.54 485589.92 722736.67 1.54 485590.57 722736.47 1.54 485591.11 722736.35 1.54 485591.67 722736.34 1.54 485592.1 722736.33 1.54 485593.2 722736.18 1.54 485594.27 722735.84 1.54 485595.1 722735.68 1.54 485599.06 722735.34 1.54 485608.21 722723.01 1.54 485608.63 722722.96 1.54 485609.08 722722.87 1.54 485609.58 722722.7 1.54 485610.23 722722.46 1.54 485611.17 722722.01 1.54 485612.12 722721.4 1.54 485612.86 722720.78 1.54 485613.46 722720.21 1.54 485613.89 722719.72 1.54 485614.29 722719.18 1.54 485614.61 722718.67 1.54 485614.89 722718.15 1.54 485615.09 722717.75 1.54 485615.26 722717.35 1.54 485615.42 722716.95 1.54 485615.54 722716.53 1.54 485615.65 722716.08 1.54 485615.73 722715.67 1.54 485615.77 722715.35 1.54 485615.82 722715.02 1.54 485615.86 722714.7 1.54 485615.88 722714.3 1.54 485615.89 722713.99 1.54 485615.88 722713.68 1.54 485615.87 722713.38 1.54 485615.83 722713.04 1.54 485615.79 722712.67 1.54 485615.72 722712.32 1.54 485615.66 722712 1.54 485615.57 722711.65 1.54 485615.47 722711.29 1.54 485615.33 722710.91 1.54 485615.22 722710.6 1.54 485615.03 722710.17 1.54 485614.84 722709.77 1.54 485614.64 722709.41 1.54 485614.4 722709.01 1.54 485614.1 722708.58 1.54 485613.77 722708.16 1.54 485613.44 722707.78 1.54 485612.9 722707.27 1.54 485612.34 722706.81 1.54 485611.56 722706.29 1.54 485610.75 722705.84 1.54 485609.95 722705.49 1.54 485609.27 722705.25 1.54 485607.63 722704.96 1.54 485606.63 722704.93 1.54 485605.36 722704.91 1.54 485591.74 722694.98 1.54 485563.6 722732.93 1.54 485563.36 722732.71 1.54 485563.2 722733.16 1.54 485563.1 722733.55 1.54 485563.07 722733.99 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.07 722733.99 1.54 485563.1 722733.55 1.54 485563.1 722733.55 13.030000000000001 485563.07 722733.99 13.030000000000001 485563.07 722733.99 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.1 722733.55 1.54 485563.2 722733.16 1.54 485563.2 722733.16 13.030000000000001 485563.1 722733.55 13.030000000000001 485563.1 722733.55 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.2 722733.16 1.54 485563.36 722732.71 1.54 485563.36 722732.71 13.030000000000001 485563.2 722733.16 13.030000000000001 485563.2 722733.16 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.36 722732.71 1.54 485563.6 722732.93 1.54 485563.6 722732.93 13.030000000000001 485563.36 722732.71 13.030000000000001 485563.36 722732.71 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.6 722732.93 1.54 485591.74 722694.98 1.54 485591.74 722694.98 13.030000000000001 485563.6 722732.93 13.030000000000001 485563.6 722732.93 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485591.74 722694.98 1.54 485605.36 722704.91 1.54 485605.36 722704.91 13.030000000000001 485591.74 722694.98 13.030000000000001 485591.74 722694.98 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485605.36 722704.91 1.54 485606.63 722704.93 1.54 485606.63 722704.93 13.030000000000001 485605.36 722704.91 13.030000000000001 485605.36 722704.91 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485606.63 722704.93 1.54 485607.63 722704.96 1.54 485607.63 722704.96 13.030000000000001 485606.63 722704.93 13.030000000000001 485606.63 722704.93 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485607.63 722704.96 1.54 485609.27 722705.25 1.54 485609.27 722705.25 13.030000000000001 485607.63 722704.96 13.030000000000001 485607.63 722704.96 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485609.27 722705.25 1.54 485609.95 722705.49 1.54 485609.95 722705.49 13.030000000000001 485609.27 722705.25 13.030000000000001 485609.27 722705.25 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485609.95 722705.49 1.54 485610.75 722705.84 1.54 485610.75 722705.84 13.030000000000001 485609.95 722705.49 13.030000000000001 485609.95 722705.49 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485610.75 722705.84 1.54 485611.56 722706.29 1.54 485611.56 722706.29 13.030000000000001 485610.75 722705.84 13.030000000000001 485610.75 722705.84 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485611.56 722706.29 1.54 485612.34 722706.81 1.54 485612.34 722706.81 13.030000000000001 485611.56 722706.29 13.030000000000001 485611.56 722706.29 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485612.34 722706.81 1.54 485612.9 722707.27 1.54 485612.9 722707.27 13.030000000000001 485612.34 722706.81 13.030000000000001 485612.34 722706.81 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_16">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485612.9 722707.27 1.54 485613.44 722707.78 1.54 485613.44 722707.78 13.030000000000001 485612.9 722707.27 13.030000000000001 485612.9 722707.27 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485613.44 722707.78 1.54 485613.77 722708.16 1.54 485613.77 722708.16 13.030000000000001 485613.44 722707.78 13.030000000000001 485613.44 722707.78 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485613.77 722708.16 1.54 485614.1 722708.58 1.54 485614.1 722708.58 13.030000000000001 485613.77 722708.16 13.030000000000001 485613.77 722708.16 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485614.1 722708.58 1.54 485614.4 722709.01 1.54 485614.4 722709.01 13.030000000000001 485614.1 722708.58 13.030000000000001 485614.1 722708.58 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485614.4 722709.01 1.54 485614.64 722709.41 1.54 485614.64 722709.41 13.030000000000001 485614.4 722709.01 13.030000000000001 485614.4 722709.01 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_21">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485614.64 722709.41 1.54 485614.84 722709.77 1.54 485614.84 722709.77 13.030000000000001 485614.64 722709.41 13.030000000000001 485614.64 722709.41 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485614.84 722709.77 1.54 485615.03 722710.17 1.54 485615.03 722710.17 13.030000000000001 485614.84 722709.77 13.030000000000001 485614.84 722709.77 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.03 722710.17 1.54 485615.22 722710.6 1.54 485615.22 722710.6 13.030000000000001 485615.03 722710.17 13.030000000000001 485615.03 722710.17 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.22 722710.6 1.54 485615.33 722710.91 1.54 485615.33 722710.91 13.030000000000001 485615.22 722710.6 13.030000000000001 485615.22 722710.6 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_25">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.33 722710.91 1.54 485615.47 722711.29 1.54 485615.47 722711.29 13.030000000000001 485615.33 722710.91 13.030000000000001 485615.33 722710.91 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_26">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.47 722711.29 1.54 485615.57 722711.65 1.54 485615.57 722711.65 13.030000000000001 485615.47 722711.29 13.030000000000001 485615.47 722711.29 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_27">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.57 722711.65 1.54 485615.66 722712 1.54 485615.66 722712 13.030000000000001 485615.57 722711.65 13.030000000000001 485615.57 722711.65 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_28">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.66 722712 1.54 485615.72 722712.32 1.54 485615.72 722712.32 13.030000000000001 485615.66 722712 13.030000000000001 485615.66 722712 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.72 722712.32 1.54 485615.79 722712.67 1.54 485615.79 722712.67 13.030000000000001 485615.72 722712.32 13.030000000000001 485615.72 722712.32 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.79 722712.67 1.54 485615.83 722713.04 1.54 485615.83 722713.04 13.030000000000001 485615.79 722712.67 13.030000000000001 485615.79 722712.67 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.83 722713.04 1.54 485615.87 722713.38 1.54 485615.87 722713.38 13.030000000000001 485615.83 722713.04 13.030000000000001 485615.83 722713.04 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.87 722713.38 1.54 485615.88 722713.68 1.54 485615.88 722713.68 13.030000000000001 485615.87 722713.38 13.030000000000001 485615.87 722713.38 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.88 722713.68 1.54 485615.89 722713.99 1.54 485615.89 722713.99 13.030000000000001 485615.88 722713.68 13.030000000000001 485615.88 722713.68 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.89 722713.99 1.54 485615.88 722714.3 1.54 485615.88 722714.3 13.030000000000001 485615.89 722713.99 13.030000000000001 485615.89 722713.99 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_35">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.88 722714.3 1.54 485615.86 722714.7 1.54 485615.86 722714.7 13.030000000000001 485615.88 722714.3 13.030000000000001 485615.88 722714.3 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.86 722714.7 1.54 485615.82 722715.02 1.54 485615.82 722715.02 13.030000000000001 485615.86 722714.7 13.030000000000001 485615.86 722714.7 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_37">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.82 722715.02 1.54 485615.77 722715.35 1.54 485615.77 722715.35 13.030000000000001 485615.82 722715.02 13.030000000000001 485615.82 722715.02 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.77 722715.35 1.54 485615.73 722715.67 1.54 485615.73 722715.67 13.030000000000001 485615.77 722715.35 13.030000000000001 485615.77 722715.35 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.73 722715.67 1.54 485615.65 722716.08 1.54 485615.65 722716.08 13.030000000000001 485615.73 722715.67 13.030000000000001 485615.73 722715.67 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.65 722716.08 1.54 485615.54 722716.53 1.54 485615.54 722716.53 13.030000000000001 485615.65 722716.08 13.030000000000001 485615.65 722716.08 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.54 722716.53 1.54 485615.42 722716.95 1.54 485615.42 722716.95 13.030000000000001 485615.54 722716.53 13.030000000000001 485615.54 722716.53 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.42 722716.95 1.54 485615.26 722717.35 1.54 485615.26 722717.35 13.030000000000001 485615.42 722716.95 13.030000000000001 485615.42 722716.95 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.26 722717.35 1.54 485615.09 722717.75 1.54 485615.09 722717.75 13.030000000000001 485615.26 722717.35 13.030000000000001 485615.26 722717.35 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485615.09 722717.75 1.54 485614.89 722718.15 1.54 485614.89 722718.15 13.030000000000001 485615.09 722717.75 13.030000000000001 485615.09 722717.75 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485614.89 722718.15 1.54 485614.61 722718.67 1.54 485614.61 722718.67 13.030000000000001 485614.89 722718.15 13.030000000000001 485614.89 722718.15 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485614.61 722718.67 1.54 485614.29 722719.18 1.54 485614.29 722719.18 13.030000000000001 485614.61 722718.67 13.030000000000001 485614.61 722718.67 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485614.29 722719.18 1.54 485613.89 722719.72 1.54 485613.89 722719.72 13.030000000000001 485614.29 722719.18 13.030000000000001 485614.29 722719.18 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485613.89 722719.72 1.54 485613.46 722720.21 1.54 485613.46 722720.21 13.030000000000001 485613.89 722719.72 13.030000000000001 485613.89 722719.72 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485613.46 722720.21 1.54 485612.86 722720.78 1.54 485612.86 722720.78 13.030000000000001 485613.46 722720.21 13.030000000000001 485613.46 722720.21 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485612.86 722720.78 1.54 485612.12 722721.4 1.54 485612.12 722721.4 13.030000000000001 485612.86 722720.78 13.030000000000001 485612.86 722720.78 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485612.12 722721.4 1.54 485611.17 722722.01 1.54 485611.17 722722.01 13.030000000000001 485612.12 722721.4 13.030000000000001 485612.12 722721.4 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485611.17 722722.01 1.54 485610.23 722722.46 1.54 485610.23 722722.46 13.030000000000001 485611.17 722722.01 13.030000000000001 485611.17 722722.01 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_53">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485610.23 722722.46 1.54 485609.58 722722.7 1.54 485609.58 722722.7 13.030000000000001 485610.23 722722.46 13.030000000000001 485610.23 722722.46 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485609.58 722722.7 1.54 485609.08 722722.87 1.54 485609.08 722722.87 13.030000000000001 485609.58 722722.7 13.030000000000001 485609.58 722722.7 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485609.08 722722.87 1.54 485608.63 722722.96 1.54 485608.63 722722.96 13.030000000000001 485609.08 722722.87 13.030000000000001 485609.08 722722.87 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_56">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485608.63 722722.96 1.54 485608.21 722723.01 1.54 485608.21 722723.01 13.030000000000001 485608.63 722722.96 13.030000000000001 485608.63 722722.96 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_57">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485608.21 722723.01 1.54 485599.06 722735.34 1.54 485599.06 722735.34 13.030000000000001 485608.21 722723.01 13.030000000000001 485608.21 722723.01 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485599.06 722735.34 1.54 485595.1 722735.68 1.54 485595.1 722735.68 13.030000000000001 485599.06 722735.34 13.030000000000001 485599.06 722735.34 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_59">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485595.1 722735.68 1.54 485594.27 722735.84 1.54 485594.27 722735.84 13.030000000000001 485595.1 722735.68 13.030000000000001 485595.1 722735.68 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_60">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485594.27 722735.84 1.54 485593.2 722736.18 1.54 485593.2 722736.18 13.030000000000001 485594.27 722735.84 13.030000000000001 485594.27 722735.84 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485593.2 722736.18 1.54 485592.1 722736.33 1.54 485592.1 722736.33 13.030000000000001 485593.2 722736.18 13.030000000000001 485593.2 722736.18 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485592.1 722736.33 1.54 485591.67 722736.34 1.54 485591.67 722736.34 13.030000000000001 485592.1 722736.33 13.030000000000001 485592.1 722736.33 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_63">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485591.67 722736.34 1.54 485591.11 722736.35 1.54 485591.11 722736.35 13.030000000000001 485591.67 722736.34 13.030000000000001 485591.67 722736.34 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_64">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485591.11 722736.35 1.54 485590.57 722736.47 1.54 485590.57 722736.47 13.030000000000001 485591.11 722736.35 13.030000000000001 485591.11 722736.35 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485590.57 722736.47 1.54 485589.92 722736.67 1.54 485589.92 722736.67 13.030000000000001 485590.57 722736.47 13.030000000000001 485590.57 722736.47 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_66">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485589.92 722736.67 1.54 485589.11 722736.94 1.54 485589.11 722736.94 13.030000000000001 485589.92 722736.67 13.030000000000001 485589.92 722736.67 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485589.11 722736.94 1.54 485588 722737.15 1.54 485588 722737.15 13.030000000000001 485589.11 722736.94 13.030000000000001 485589.11 722736.94 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485588 722737.15 1.54 485586.77 722737.21 1.54 485586.77 722737.21 13.030000000000001 485588 722737.15 13.030000000000001 485588 722737.15 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_69">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485586.77 722737.21 1.54 485585.56 722737.03 1.54 485585.56 722737.03 13.030000000000001 485586.77 722737.21 13.030000000000001 485586.77 722737.21 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485585.56 722737.03 1.54 485584.53 722736.66 1.54 485584.53 722736.66 13.030000000000001 485585.56 722737.03 13.030000000000001 485585.56 722737.03 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_71">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485584.53 722736.66 1.54 485583.46 722736.34 1.54 485583.46 722736.34 13.030000000000001 485584.53 722736.66 13.030000000000001 485584.53 722736.66 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_72">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485583.46 722736.34 1.54 485582.44 722736.28 1.54 485582.44 722736.28 13.030000000000001 485583.46 722736.34 13.030000000000001 485583.46 722736.34 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_73">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485582.44 722736.28 1.54 485581.45 722736.29 1.54 485581.45 722736.29 13.030000000000001 485582.44 722736.28 13.030000000000001 485582.44 722736.28 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_74">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485581.45 722736.29 1.54 485580.52 722736.49 1.54 485580.52 722736.49 13.030000000000001 485581.45 722736.29 13.030000000000001 485581.45 722736.29 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_75">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485580.52 722736.49 1.54 485579.56 722736.93 1.54 485579.56 722736.93 13.030000000000001 485580.52 722736.49 13.030000000000001 485580.52 722736.49 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_76">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485579.56 722736.93 1.54 485578.59 722737.35 1.54 485578.59 722737.35 13.030000000000001 485579.56 722736.93 13.030000000000001 485579.56 722736.93 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_77">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485578.59 722737.35 1.54 485577.53 722737.56 1.54 485577.53 722737.56 13.030000000000001 485578.59 722737.35 13.030000000000001 485578.59 722737.35 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_78">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485577.53 722737.56 1.54 485576.42 722737.57 1.54 485576.42 722737.57 13.030000000000001 485577.53 722737.56 13.030000000000001 485577.53 722737.56 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_79">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485576.42 722737.57 1.54 485575.33 722737.35 1.54 485575.33 722737.35 13.030000000000001 485576.42 722737.57 13.030000000000001 485576.42 722737.57 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485575.33 722737.35 1.54 485574.34 722737.03 1.54 485574.34 722737.03 13.030000000000001 485575.33 722737.35 13.030000000000001 485575.33 722737.35 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_81">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485574.34 722737.03 1.54 485573.51 722736.92 1.54 485573.51 722736.92 13.030000000000001 485574.34 722737.03 13.030000000000001 485574.34 722737.03 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_82">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485573.51 722736.92 1.54 485572.59 722736.79 1.54 485572.59 722736.79 13.030000000000001 485573.51 722736.92 13.030000000000001 485573.51 722736.92 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_83">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485572.59 722736.79 1.54 485571.05 722737.05 1.54 485571.05 722737.05 13.030000000000001 485572.59 722736.79 13.030000000000001 485572.59 722736.79 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_84">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485571.05 722737.05 1.54 485569.82 722737.52 1.54 485569.82 722737.52 13.030000000000001 485571.05 722737.05 13.030000000000001 485571.05 722737.05 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_85">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485569.82 722737.52 1.54 485569.12 722737.7 1.54 485569.12 722737.7 13.030000000000001 485569.82 722737.52 13.030000000000001 485569.82 722737.52 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_86">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485569.12 722737.7 1.54 485568.58 722737.77 1.54 485568.58 722737.77 13.030000000000001 485569.12 722737.7 13.030000000000001 485569.12 722737.7 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_87">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485568.58 722737.77 1.54 485567.91 722737.82 1.54 485567.91 722737.82 13.030000000000001 485568.58 722737.77 13.030000000000001 485568.58 722737.77 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_88">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485567.91 722737.82 1.54 485567.22 722737.79 1.54 485567.22 722737.79 13.030000000000001 485567.91 722737.82 13.030000000000001 485567.91 722737.82 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_89">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485567.22 722737.79 1.54 485566.65 722737.71 1.54 485566.65 722737.71 13.030000000000001 485567.22 722737.79 13.030000000000001 485567.22 722737.79 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_90">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485566.65 722737.71 1.54 485566.23 722737.62 1.54 485566.23 722737.62 13.030000000000001 485566.65 722737.71 13.030000000000001 485566.65 722737.71 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485566.23 722737.62 1.54 485565.88 722737.5 1.54 485565.88 722737.5 13.030000000000001 485566.23 722737.62 13.030000000000001 485566.23 722737.62 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_92">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485565.88 722737.5 1.54 485565.51 722737.36 1.54 485565.51 722737.36 13.030000000000001 485565.88 722737.5 13.030000000000001 485565.88 722737.5 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_93">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485565.51 722737.36 1.54 485565.15 722737.17 1.54 485565.15 722737.17 13.030000000000001 485565.51 722737.36 13.030000000000001 485565.51 722737.36 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_94">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485565.15 722737.17 1.54 485564.82 722736.96 1.54 485564.82 722736.96 13.030000000000001 485565.15 722737.17 13.030000000000001 485565.15 722737.17 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_95">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485564.82 722736.96 1.54 485564.56 722736.77 1.54 485564.56 722736.77 13.030000000000001 485564.82 722736.96 13.030000000000001 485564.82 722736.96 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_96">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485564.56 722736.77 1.54 485564.28 722736.55 1.54 485564.28 722736.55 13.030000000000001 485564.56 722736.77 13.030000000000001 485564.56 722736.77 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_97">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485564.28 722736.55 1.54 485564 722736.26 1.54 485564 722736.26 13.030000000000001 485564.28 722736.55 13.030000000000001 485564.28 722736.55 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_98">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485564 722736.26 1.54 485563.8 722736.03 1.54 485563.8 722736.03 13.030000000000001 485564 722736.26 13.030000000000001 485564 722736.26 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_99">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.8 722736.03 1.54 485563.63 722735.86 1.54 485563.63 722735.86 13.030000000000001 485563.8 722736.03 13.030000000000001 485563.8 722736.03 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_100">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.63 722735.86 1.54 485563.39 722735.53 1.54 485563.39 722735.53 13.030000000000001 485563.63 722735.86 13.030000000000001 485563.63 722735.86 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_101">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.39 722735.53 1.54 485563.2 722735.07 1.54 485563.2 722735.07 13.030000000000001 485563.39 722735.53 13.030000000000001 485563.39 722735.53 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_102">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.2 722735.07 1.54 485563.09 722734.52 1.54 485563.09 722734.52 13.030000000000001 485563.2 722735.07 13.030000000000001 485563.2 722735.07 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_103">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.09 722734.52 1.54 485563.07 722733.99 1.54 485563.07 722733.99 13.030000000000001 485563.09 722734.52 13.030000000000001 485563.09 722734.52 1.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC36-FAF6-E053-CA2BA8C0FAE4_PG_104">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485563.07 722733.99 13.030000000000001 485563.1 722733.55 13.030000000000001 485563.2 722733.16 13.030000000000001 485563.36 722732.71 13.030000000000001 485563.6 722732.93 13.030000000000001 485591.74 722694.98 13.030000000000001 485605.36 722704.91 13.030000000000001 485606.63 722704.93 13.030000000000001 485607.63 722704.96 13.030000000000001 485609.27 722705.25 13.030000000000001 485609.95 722705.49 13.030000000000001 485610.75 722705.84 13.030000000000001 485611.56 722706.29 13.030000000000001 485612.34 722706.81 13.030000000000001 485612.9 722707.27 13.030000000000001 485613.44 722707.78 13.030000000000001 485613.77 722708.16 13.030000000000001 485614.1 722708.58 13.030000000000001 485614.4 722709.01 13.030000000000001 485614.64 722709.41 13.030000000000001 485614.84 722709.77 13.030000000000001 485615.03 722710.17 13.030000000000001 485615.22 722710.6 13.030000000000001 485615.33 722710.91 13.030000000000001 485615.47 722711.29 13.030000000000001 485615.57 722711.65 13.030000000000001 485615.66 722712 13.030000000000001 485615.72 722712.32 13.030000000000001 485615.79 722712.67 13.030000000000001 485615.83 722713.04 13.030000000000001 485615.87 722713.38 13.030000000000001 485615.88 722713.68 13.030000000000001 485615.89 722713.99 13.030000000000001 485615.88 722714.3 13.030000000000001 485615.86 722714.7 13.030000000000001 485615.82 722715.02 13.030000000000001 485615.77 722715.35 13.030000000000001 485615.73 722715.67 13.030000000000001 485615.65 722716.08 13.030000000000001 485615.54 722716.53 13.030000000000001 485615.42 722716.95 13.030000000000001 485615.26 722717.35 13.030000000000001 485615.09 722717.75 13.030000000000001 485614.89 722718.15 13.030000000000001 485614.61 722718.67 13.030000000000001 485614.29 722719.18 13.030000000000001 485613.89 722719.72 13.030000000000001 485613.46 722720.21 13.030000000000001 485612.86 722720.78 13.030000000000001 485612.12 722721.4 13.030000000000001 485611.17 722722.01 13.030000000000001 485610.23 722722.46 13.030000000000001 485609.58 722722.7 13.030000000000001 485609.08 722722.87 13.030000000000001 485608.63 722722.96 13.030000000000001 485608.21 722723.01 13.030000000000001 485599.06 722735.34 13.030000000000001 485595.1 722735.68 13.030000000000001 485594.27 722735.84 13.030000000000001 485593.2 722736.18 13.030000000000001 485592.1 722736.33 13.030000000000001 485591.67 722736.34 13.030000000000001 485591.11 722736.35 13.030000000000001 485590.57 722736.47 13.030000000000001 485589.92 722736.67 13.030000000000001 485589.11 722736.94 13.030000000000001 485588 722737.15 13.030000000000001 485586.77 722737.21 13.030000000000001 485585.56 722737.03 13.030000000000001 485584.53 722736.66 13.030000000000001 485583.46 722736.34 13.030000000000001 485582.44 722736.28 13.030000000000001 485581.45 722736.29 13.030000000000001 485580.52 722736.49 13.030000000000001 485579.56 722736.93 13.030000000000001 485578.59 722737.35 13.030000000000001 485577.53 722737.56 13.030000000000001 485576.42 722737.57 13.030000000000001 485575.33 722737.35 13.030000000000001 485574.34 722737.03 13.030000000000001 485573.51 722736.92 13.030000000000001 485572.59 722736.79 13.030000000000001 485571.05 722737.05 13.030000000000001 485569.82 722737.52 13.030000000000001 485569.12 722737.7 13.030000000000001 485568.58 722737.77 13.030000000000001 485567.91 722737.82 13.030000000000001 485567.22 722737.79 13.030000000000001 485566.65 722737.71 13.030000000000001 485566.23 722737.62 13.030000000000001 485565.88 722737.5 13.030000000000001 485565.51 722737.36 13.030000000000001 485565.15 722737.17 13.030000000000001 485564.82 722736.96 13.030000000000001 485564.56 722736.77 13.030000000000001 485564.28 722736.55 13.030000000000001 485564 722736.26 13.030000000000001 485563.8 722736.03 13.030000000000001 485563.63 722735.86 13.030000000000001 485563.39 722735.53 13.030000000000001 485563.2 722735.07 13.030000000000001 485563.09 722734.52 13.030000000000001 485563.07 722733.99 13.030000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-CEC9-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-CEC9-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.86</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CEC9-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483867.49 721322.16 3.91 483869.85 721327.84 3.91 483881.23 721323.11 3.91 483878.87 721317.43 3.91 483867.49 721322.16 3.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CEC9-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483867.49 721322.16 3.91 483878.87 721317.43 3.91 483878.87 721317.43 7.7700000000000005 483867.49 721322.16 7.7700000000000005 483867.49 721322.16 3.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CEC9-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483878.87 721317.43 3.91 483881.23 721323.11 3.91 483881.23 721323.11 7.7700000000000005 483878.87 721317.43 7.7700000000000005 483878.87 721317.43 3.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CEC9-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483881.23 721323.11 3.91 483869.85 721327.84 3.91 483869.85 721327.84 7.7700000000000005 483881.23 721323.11 7.7700000000000005 483881.23 721323.11 3.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CEC9-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483869.85 721327.84 3.91 483867.49 721322.16 3.91 483867.49 721322.16 7.7700000000000005 483869.85 721327.84 7.7700000000000005 483869.85 721327.84 3.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-CEC9-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>483867.49 721322.16 7.7700000000000005 483878.87 721317.43 7.7700000000000005 483881.23 721323.11 7.7700000000000005 483869.85 721327.84 7.7700000000000005 483867.49 721322.16 7.7700000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD5C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD5C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484936.55 722542.96 1.55 484941.82 722539.48 1.55 484937.21 722532.4 1.55 484932.07 722535.76 1.55 484936.55 722542.96 1.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484936.55 722542.96 1.55 484932.07 722535.76 1.55 484932.07 722535.76 4.865 484936.55 722542.96 4.865 484936.55 722542.96 1.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484932.07 722535.76 1.55 484937.21 722532.4 1.55 484937.21 722532.4 4.865 484932.07 722535.76 4.865 484932.07 722535.76 1.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484937.21 722532.4 1.55 484941.82 722539.48 1.55 484941.82 722539.48 4.865 484937.21 722532.4 4.865 484937.21 722532.4 1.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484941.82 722539.48 1.55 484936.55 722542.96 1.55 484936.55 722542.96 4.865 484941.82 722539.48 4.865 484941.82 722539.48 1.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484936.55 722542.96 4.865 484932.07 722535.76 4.865 484937.21 722532.4 4.865 484941.82 722539.48 4.865 484936.55 722542.96 4.865</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD59-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD59-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.84</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD59-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.92 722579.37 1.83 484926.29 722584.32 1.83 484932.18 722580.3 1.83 484928.81 722575.35 1.83 484922.92 722579.37 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD59-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.92 722579.37 1.83 484928.81 722575.35 1.83 484928.81 722575.35 4.67 484922.92 722579.37 4.67 484922.92 722579.37 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD59-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484928.81 722575.35 1.83 484932.18 722580.3 1.83 484932.18 722580.3 4.67 484928.81 722575.35 4.67 484928.81 722575.35 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD59-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484932.18 722580.3 1.83 484926.29 722584.32 1.83 484926.29 722584.32 4.67 484932.18 722580.3 4.67 484932.18 722580.3 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD59-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484926.29 722584.32 1.83 484922.92 722579.37 1.83 484922.92 722579.37 4.67 484926.29 722584.32 4.67 484926.29 722584.32 1.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD59-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.92 722579.37 4.67 484928.81 722575.35 4.67 484932.18 722580.3 4.67 484926.29 722584.32 4.67 484922.92 722579.37 4.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD58-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD58-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.91</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD58-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484913.23 722623.65 1.77 484916.6 722628.6 1.77 484922.49 722624.58 1.77 484919.12 722619.63 1.77 484913.23 722623.65 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD58-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484913.23 722623.65 1.77 484919.12 722619.63 1.77 484919.12 722619.63 4.68 484913.23 722623.65 4.68 484913.23 722623.65 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD58-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484919.12 722619.63 1.77 484922.49 722624.58 1.77 484922.49 722624.58 4.68 484919.12 722619.63 4.68 484919.12 722619.63 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD58-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.49 722624.58 1.77 484916.6 722628.6 1.77 484916.6 722628.6 4.68 484922.49 722624.58 4.68 484922.49 722624.58 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD58-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484916.6 722628.6 1.77 484913.23 722623.65 1.77 484913.23 722623.65 4.68 484916.6 722628.6 4.68 484916.6 722628.6 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD58-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484913.23 722623.65 4.68 484919.12 722619.63 4.68 484922.49 722624.58 4.68 484916.6 722628.6 4.68 484913.23 722623.65 4.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD57-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD57-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.88</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD57-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484921.24 722607.18 1.69 484924.61 722612.13 1.69 484930.5 722608.11 1.69 484927.13 722603.16 1.69 484921.24 722607.18 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD57-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484921.24 722607.18 1.69 484927.13 722603.16 1.69 484927.13 722603.16 4.57 484921.24 722607.18 4.57 484921.24 722607.18 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD57-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484927.13 722603.16 1.69 484930.5 722608.11 1.69 484930.5 722608.11 4.57 484927.13 722603.16 4.57 484927.13 722603.16 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD57-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484930.5 722608.11 1.69 484924.61 722612.13 1.69 484924.61 722612.13 4.57 484930.5 722608.11 4.57 484930.5 722608.11 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD57-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484924.61 722612.13 1.69 484921.24 722607.18 1.69 484921.24 722607.18 4.57 484924.61 722612.13 4.57 484924.61 722612.13 1.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD57-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484921.24 722607.18 4.57 484927.13 722603.16 4.57 484930.5 722608.11 4.57 484924.61 722612.13 4.57 484921.24 722607.18 4.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD5A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD5A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.95</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.04 722617.95 1.66 484925.41 722622.9 1.66 484931.3 722618.88 1.66 484927.93 722613.93 1.66 484922.04 722617.95 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.04 722617.95 1.66 484927.93 722613.93 1.66 484927.93 722613.93 4.61 484922.04 722617.95 4.61 484922.04 722617.95 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484927.93 722613.93 1.66 484931.3 722618.88 1.66 484931.3 722618.88 4.61 484927.93 722613.93 4.61 484927.93 722613.93 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484931.3 722618.88 1.66 484925.41 722622.9 1.66 484925.41 722622.9 4.61 484931.3 722618.88 4.61 484931.3 722618.88 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484925.41 722622.9 1.66 484922.04 722617.95 1.66 484922.04 722617.95 4.61 484925.41 722622.9 4.61 484925.41 722622.9 1.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.04 722617.95 4.61 484927.93 722613.93 4.61 484931.3 722618.88 4.61 484925.41 722622.9 4.61 484922.04 722617.95 4.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D146-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D146-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.23</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D146-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484618.53 721196.02 2 484619.68 721203.31 2 484628.24 721201.96 2 484627.09 721194.67 2 484618.53 721196.02 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D146-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484618.53 721196.02 2 484627.09 721194.67 2 484627.09 721194.67 5.23 484618.53 721196.02 5.23 484618.53 721196.02 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D146-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484627.09 721194.67 2 484628.24 721201.96 2 484628.24 721201.96 5.23 484627.09 721194.67 5.23 484627.09 721194.67 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D146-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484628.24 721201.96 2 484619.68 721203.31 2 484619.68 721203.31 5.23 484628.24 721201.96 5.23 484628.24 721201.96 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D146-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484619.68 721203.31 2 484618.53 721196.02 2 484618.53 721196.02 5.23 484619.68 721203.31 5.23 484619.68 721203.31 2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D146-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484618.53 721196.02 5.23 484627.09 721194.67 5.23 484628.24 721201.96 5.23 484619.68 721203.31 5.23 484618.53 721196.02 5.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DCA0-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DCA0-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.07</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DCA0-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484875.53 722545.46 1.5 484880.36 722550.28 1.5 484885.87 722544.76 1.5 484881.05 722539.94 1.5 484875.53 722545.46 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DCA0-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484875.53 722545.46 1.5 484881.05 722539.94 1.5 484881.05 722539.94 4.57 484875.53 722545.46 4.57 484875.53 722545.46 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DCA0-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484881.05 722539.94 1.5 484885.87 722544.76 1.5 484885.87 722544.76 4.57 484881.05 722539.94 4.57 484881.05 722539.94 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DCA0-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484885.87 722544.76 1.5 484880.36 722550.28 1.5 484880.36 722550.28 4.57 484885.87 722544.76 4.57 484885.87 722544.76 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DCA0-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484880.36 722550.28 1.5 484875.53 722545.46 1.5 484875.53 722545.46 4.57 484880.36 722550.28 4.57 484880.36 722550.28 1.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DCA0-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484875.53 722545.46 4.57 484881.05 722539.94 4.57 484885.87 722544.76 4.57 484880.36 722550.28 4.57 484875.53 722545.46 4.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC9F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC9F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.09</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484866.11 722568.1 1.71 484869.48 722573.05 1.71 484875.37 722569.03 1.71 484872 722564.08 1.71 484866.11 722568.1 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484866.11 722568.1 1.71 484872 722564.08 1.71 484872 722564.08 4.8 484866.11 722568.1 4.8 484866.11 722568.1 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484872 722564.08 1.71 484875.37 722569.03 1.71 484875.37 722569.03 4.8 484872 722564.08 4.8 484872 722564.08 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484875.37 722569.03 1.71 484869.48 722573.05 1.71 484869.48 722573.05 4.8 484875.37 722569.03 4.8 484875.37 722569.03 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484869.48 722573.05 1.71 484866.11 722568.1 1.71 484866.11 722568.1 4.8 484869.48 722573.05 4.8 484869.48 722573.05 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484866.11 722568.1 4.8 484872 722564.08 4.8 484875.37 722569.03 4.8 484869.48 722573.05 4.8 484866.11 722568.1 4.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC9D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC9D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.02</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484857.38 722610.75 1.78 484860.75 722615.7 1.78 484866.64 722611.68 1.78 484863.27 722606.73 1.78 484857.38 722610.75 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484857.38 722610.75 1.78 484863.27 722606.73 1.78 484863.27 722606.73 4.8 484857.38 722610.75 4.8 484857.38 722610.75 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484863.27 722606.73 1.78 484866.64 722611.68 1.78 484866.64 722611.68 4.8 484863.27 722606.73 4.8 484863.27 722606.73 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484866.64 722611.68 1.78 484860.75 722615.7 1.78 484860.75 722615.7 4.8 484866.64 722611.68 4.8 484866.64 722611.68 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484860.75 722615.7 1.78 484857.38 722610.75 1.78 484857.38 722610.75 4.8 484860.75 722615.7 4.8 484860.75 722615.7 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484857.38 722610.75 4.8 484863.27 722606.73 4.8 484866.64 722611.68 4.8 484860.75 722615.7 4.8 484857.38 722610.75 4.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC9C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC9C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.95</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484843.67 722638.87 1.94 484847.04 722643.82 1.94 484852.93 722639.8 1.94 484849.56 722634.85 1.94 484843.67 722638.87 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484843.67 722638.87 1.94 484849.56 722634.85 1.94 484849.56 722634.85 4.89 484843.67 722638.87 4.89 484843.67 722638.87 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484849.56 722634.85 1.94 484852.93 722639.8 1.94 484852.93 722639.8 4.89 484849.56 722634.85 4.89 484849.56 722634.85 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484852.93 722639.8 1.94 484847.04 722643.82 1.94 484847.04 722643.82 4.89 484852.93 722639.8 4.89 484852.93 722639.8 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484847.04 722643.82 1.94 484843.67 722638.87 1.94 484843.67 722638.87 4.89 484847.04 722643.82 4.89 484847.04 722643.82 1.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484843.67 722638.87 4.89 484849.56 722634.85 4.89 484852.93 722639.8 4.89 484847.04 722643.82 4.89 484843.67 722638.87 4.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD56-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD56-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.87</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD56-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484930.27 722601.25 1.82 484933.64 722606.2 1.82 484939.53 722602.18 1.82 484936.16 722597.23 1.82 484930.27 722601.25 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD56-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484930.27 722601.25 1.82 484936.16 722597.23 1.82 484936.16 722597.23 4.69 484930.27 722601.25 4.69 484930.27 722601.25 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD56-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484936.16 722597.23 1.82 484939.53 722602.18 1.82 484939.53 722602.18 4.69 484936.16 722597.23 4.69 484936.16 722597.23 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD56-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484939.53 722602.18 1.82 484933.64 722606.2 1.82 484933.64 722606.2 4.69 484939.53 722602.18 4.69 484939.53 722602.18 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD56-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484933.64 722606.2 1.82 484930.27 722601.25 1.82 484930.27 722601.25 4.69 484933.64 722606.2 4.69 484933.64 722606.2 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD56-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484930.27 722601.25 4.69 484936.16 722597.23 4.69 484939.53 722602.18 4.69 484933.64 722606.2 4.69 484930.27 722601.25 4.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD55-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD55-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.07</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD55-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484911.9 722612.84 1.81 484915.27 722617.79 1.81 484921.16 722613.77 1.81 484917.79 722608.82 1.81 484911.9 722612.84 1.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD55-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484911.9 722612.84 1.81 484917.79 722608.82 1.81 484917.79 722608.82 4.88 484911.9 722612.84 4.88 484911.9 722612.84 1.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD55-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484917.79 722608.82 1.81 484921.16 722613.77 1.81 484921.16 722613.77 4.88 484917.79 722608.82 4.88 484917.79 722608.82 1.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD55-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484921.16 722613.77 1.81 484915.27 722617.79 1.81 484915.27 722617.79 4.88 484921.16 722613.77 4.88 484921.16 722613.77 1.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD55-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484915.27 722617.79 1.81 484911.9 722612.84 1.81 484911.9 722612.84 4.88 484915.27 722617.79 4.88 484915.27 722617.79 1.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD55-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484911.9 722612.84 4.88 484917.79 722608.82 4.88 484921.16 722613.77 4.88 484915.27 722617.79 4.88 484911.9 722612.84 4.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD53-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD53-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.95</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD53-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484931.71 722611.67 1.71 484935.08 722616.62 1.71 484940.97 722612.6 1.71 484937.6 722607.65 1.71 484931.71 722611.67 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD53-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484931.71 722611.67 1.71 484937.6 722607.65 1.71 484937.6 722607.65 4.66 484931.71 722611.67 4.66 484931.71 722611.67 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD53-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484937.6 722607.65 1.71 484940.97 722612.6 1.71 484940.97 722612.6 4.66 484937.6 722607.65 4.66 484937.6 722607.65 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD53-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484940.97 722612.6 1.71 484935.08 722616.62 1.71 484935.08 722616.62 4.66 484940.97 722612.6 4.66 484940.97 722612.6 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD53-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484935.08 722616.62 1.71 484931.71 722611.67 1.71 484931.71 722611.67 4.66 484935.08 722616.62 4.66 484935.08 722616.62 1.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD53-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484931.71 722611.67 4.66 484937.6 722607.65 4.66 484940.97 722612.6 4.66 484935.08 722616.62 4.66 484931.71 722611.67 4.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D2E4-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D2E4-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.18</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E4-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484994.86 721320.65 2.84 484995.77 721324.55 2.84 485004.34 721322.55 2.84 485004.26 721322.2 2.84 485008.63 721321.17 2.84 485007.2 721315.03 2.84 485002.69 721316.08 2.84 485003.29 721318.68 2.84 484994.86 721320.65 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E4-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484994.86 721320.65 2.84 485003.29 721318.68 2.84 485003.29 721318.68 5.0200000000000005 484994.86 721320.65 5.0200000000000005 484994.86 721320.65 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E4-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485003.29 721318.68 2.84 485002.69 721316.08 2.84 485002.69 721316.08 5.0200000000000005 485003.29 721318.68 5.0200000000000005 485003.29 721318.68 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E4-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485002.69 721316.08 2.84 485007.2 721315.03 2.84 485007.2 721315.03 5.0200000000000005 485002.69 721316.08 5.0200000000000005 485002.69 721316.08 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E4-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485007.2 721315.03 2.84 485008.63 721321.17 2.84 485008.63 721321.17 5.0200000000000005 485007.2 721315.03 5.0200000000000005 485007.2 721315.03 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E4-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485008.63 721321.17 2.84 485004.26 721322.2 2.84 485004.26 721322.2 5.0200000000000005 485008.63 721321.17 5.0200000000000005 485008.63 721321.17 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E4-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485004.26 721322.2 2.84 485004.34 721322.55 2.84 485004.34 721322.55 5.0200000000000005 485004.26 721322.2 5.0200000000000005 485004.26 721322.2 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E4-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485004.34 721322.55 2.84 484995.77 721324.55 2.84 484995.77 721324.55 5.0200000000000005 485004.34 721322.55 5.0200000000000005 485004.34 721322.55 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E4-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484995.77 721324.55 2.84 484994.86 721320.65 2.84 484994.86 721320.65 5.0200000000000005 484995.77 721324.55 5.0200000000000005 484995.77 721324.55 2.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D2E4-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484994.86 721320.65 5.0200000000000005 485003.29 721318.68 5.0200000000000005 485002.69 721316.08 5.0200000000000005 485007.2 721315.03 5.0200000000000005 485008.63 721321.17 5.0200000000000005 485004.26 721322.2 5.0200000000000005 485004.34 721322.55 5.0200000000000005 484995.77 721324.55 5.0200000000000005 484994.86 721320.65 5.0200000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC9B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC9B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484850.1 722532.74 1.84 484853.47 722537.69 1.84 484859.36 722533.67 1.84 484855.99 722528.72 1.84 484850.1 722532.74 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484850.1 722532.74 1.84 484855.99 722528.72 1.84 484855.99 722528.72 4.84 484850.1 722532.74 4.84 484850.1 722532.74 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484855.99 722528.72 1.84 484859.36 722533.67 1.84 484859.36 722533.67 4.84 484855.99 722528.72 4.84 484855.99 722528.72 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484859.36 722533.67 1.84 484853.47 722537.69 1.84 484853.47 722537.69 4.84 484859.36 722533.67 4.84 484859.36 722533.67 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484853.47 722537.69 1.84 484850.1 722532.74 1.84 484850.1 722532.74 4.84 484853.47 722537.69 4.84 484853.47 722537.69 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484850.1 722532.74 4.84 484855.99 722528.72 4.84 484859.36 722533.67 4.84 484853.47 722537.69 4.84 484850.1 722532.74 4.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC9A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC9A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.1</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484828.65 722613.95 1.82 484832.02 722618.9 1.82 484837.91 722614.88 1.82 484834.54 722609.93 1.82 484828.65 722613.95 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484828.65 722613.95 1.82 484834.54 722609.93 1.82 484834.54 722609.93 4.92 484828.65 722613.95 4.92 484828.65 722613.95 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484834.54 722609.93 1.82 484837.91 722614.88 1.82 484837.91 722614.88 4.92 484834.54 722609.93 4.92 484834.54 722609.93 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484837.91 722614.88 1.82 484832.02 722618.9 1.82 484832.02 722618.9 4.92 484837.91 722614.88 4.92 484837.91 722614.88 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484832.02 722618.9 1.82 484828.65 722613.95 1.82 484828.65 722613.95 4.92 484832.02 722618.9 4.92 484832.02 722618.9 1.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC9A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484828.65 722613.95 4.92 484834.54 722609.93 4.92 484837.91 722614.88 4.92 484832.02 722618.9 4.92 484828.65 722613.95 4.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-084B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-084B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.6</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-084B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484904.11 721263.95 1.58 484911.54 721264.13 1.58 484911.77 721254.58 1.58 484904.34 721254.37 1.58 484904.11 721263.95 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-084B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484904.11 721263.95 1.58 484904.34 721254.37 1.58 484904.34 721254.37 7.18 484904.11 721263.95 7.18 484904.11 721263.95 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-084B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484904.34 721254.37 1.58 484911.77 721254.58 1.58 484911.77 721254.58 7.18 484904.34 721254.37 7.18 484904.34 721254.37 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-084B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484911.77 721254.58 1.58 484911.54 721264.13 1.58 484911.54 721264.13 7.18 484911.77 721254.58 7.18 484911.77 721254.58 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-084B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484911.54 721264.13 1.58 484904.11 721263.95 1.58 484904.11 721263.95 7.18 484911.54 721264.13 7.18 484911.54 721264.13 1.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-084B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484904.11 721263.95 7.18 484904.34 721254.37 7.18 484911.77 721254.58 7.18 484911.54 721264.13 7.18 484904.11 721263.95 7.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-D076-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.29</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484468.88 721312.66 2.14 484482.33 721307.42 2.14 484486.2 721318.58 2.14 484496.15 721314.63 2.14 484494.34 721309.7 2.14 484487.82 721312.11 2.14 484485.61 721306.14 2.14 484483.66 721300.86 2.14 484482.57 721298.3 2.14 484482.13 721298.44 2.14 484480.8 721295.09 2.14 484464.47 721302.03 2.14 484468.88 721312.66 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484468.88 721312.66 2.14 484464.47 721302.03 2.14 484464.47 721302.03 5.43 484468.88 721312.66 5.43 484468.88 721312.66 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484464.47 721302.03 2.14 484480.8 721295.09 2.14 484480.8 721295.09 5.43 484464.47 721302.03 5.43 484464.47 721302.03 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484480.8 721295.09 2.14 484482.13 721298.44 2.14 484482.13 721298.44 5.43 484480.8 721295.09 5.43 484480.8 721295.09 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484482.13 721298.44 2.14 484482.57 721298.3 2.14 484482.57 721298.3 5.43 484482.13 721298.44 5.43 484482.13 721298.44 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484482.57 721298.3 2.14 484483.66 721300.86 2.14 484483.66 721300.86 5.43 484482.57 721298.3 5.43 484482.57 721298.3 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484483.66 721300.86 2.14 484485.61 721306.14 2.14 484485.61 721306.14 5.43 484483.66 721300.86 5.43 484483.66 721300.86 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484485.61 721306.14 2.14 484487.82 721312.11 2.14 484487.82 721312.11 5.43 484485.61 721306.14 5.43 484485.61 721306.14 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484487.82 721312.11 2.14 484494.34 721309.7 2.14 484494.34 721309.7 5.43 484487.82 721312.11 5.43 484487.82 721312.11 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484494.34 721309.7 2.14 484496.15 721314.63 2.14 484496.15 721314.63 5.43 484494.34 721309.7 5.43 484494.34 721309.7 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_11">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484496.15 721314.63 2.14 484486.2 721318.58 2.14 484486.2 721318.58 5.43 484496.15 721314.63 5.43 484496.15 721314.63 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_12">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484486.2 721318.58 2.14 484482.33 721307.42 2.14 484482.33 721307.42 5.43 484486.2 721318.58 5.43 484486.2 721318.58 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484482.33 721307.42 2.14 484468.88 721312.66 2.14 484468.88 721312.66 5.43 484482.33 721307.42 5.43 484482.33 721307.42 2.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-D076-FAF6-E053-CA2BA8C0FAE4_PG_14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484468.88 721312.66 5.43 484464.47 721302.03 5.43 484480.8 721295.09 5.43 484482.13 721298.44 5.43 484482.57 721298.3 5.43 484483.66 721300.86 5.43 484485.61 721306.14 5.43 484487.82 721312.11 5.43 484494.34 721309.7 5.43 484496.15 721314.63 5.43 484486.2 721318.58 5.43 484482.33 721307.42 5.43 484468.88 721312.66 5.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-741A-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-741A-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">4.15</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741A-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484638.76 721188.49 1.74 484641.09 721197.81 1.74 484645.72 721196.78 1.74 484643.64 721187.41 1.74 484643.03 721184.47 1.74 484638.05 721185.59 1.74 484638.76 721188.49 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741A-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484638.76 721188.49 1.74 484638.05 721185.59 1.74 484638.05 721185.59 5.89 484638.76 721188.49 5.89 484638.76 721188.49 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741A-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484638.05 721185.59 1.74 484643.03 721184.47 1.74 484643.03 721184.47 5.89 484638.05 721185.59 5.89 484638.05 721185.59 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741A-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484643.03 721184.47 1.74 484643.64 721187.41 1.74 484643.64 721187.41 5.89 484643.03 721184.47 5.89 484643.03 721184.47 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741A-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484643.64 721187.41 1.74 484645.72 721196.78 1.74 484645.72 721196.78 5.89 484643.64 721187.41 5.89 484643.64 721187.41 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741A-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484645.72 721196.78 1.74 484641.09 721197.81 1.74 484641.09 721197.81 5.89 484645.72 721196.78 5.89 484645.72 721196.78 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741A-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484641.09 721197.81 1.74 484638.76 721188.49 1.74 484638.76 721188.49 5.89 484641.09 721197.81 5.89 484641.09 721197.81 1.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-741A-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484638.76 721188.49 5.89 484638.05 721185.59 5.89 484643.03 721184.47 5.89 484643.64 721187.41 5.89 484645.72 721196.78 5.89 484641.09 721197.81 5.89 484638.76 721188.49 5.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-FC58-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-FC58-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.63</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC58-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484914.51 721257.82 1.42 484920.83 721257.97 1.42 484921.1 721249.77 1.42 484914.71 721249.65 1.42 484914.51 721257.82 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC58-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484914.51 721257.82 1.42 484914.71 721249.65 1.42 484914.71 721249.65 7.05 484914.51 721257.82 7.05 484914.51 721257.82 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC58-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484914.71 721249.65 1.42 484921.1 721249.77 1.42 484921.1 721249.77 7.05 484914.71 721249.65 7.05 484914.71 721249.65 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC58-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484921.1 721249.77 1.42 484920.83 721257.97 1.42 484920.83 721257.97 7.05 484921.1 721249.77 7.05 484921.1 721249.77 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC58-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484920.83 721257.97 1.42 484914.51 721257.82 1.42 484914.51 721257.82 7.05 484920.83 721257.97 7.05 484920.83 721257.97 1.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-FC58-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484914.51 721257.82 7.05 484914.71 721249.65 7.05 484921.1 721249.77 7.05 484920.83 721257.97 7.05 484914.51 721257.82 7.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC93-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC93-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.01</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC93-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484830.8 722602.57 1.9 484834.17 722607.52 1.9 484840.06 722603.5 1.9 484836.69 722598.55 1.9 484830.8 722602.57 1.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC93-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484830.8 722602.57 1.9 484836.69 722598.55 1.9 484836.69 722598.55 4.91 484830.8 722602.57 4.91 484830.8 722602.57 1.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC93-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484836.69 722598.55 1.9 484840.06 722603.5 1.9 484840.06 722603.5 4.91 484836.69 722598.55 4.91 484836.69 722598.55 1.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC93-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484840.06 722603.5 1.9 484834.17 722607.52 1.9 484834.17 722607.52 4.91 484840.06 722603.5 4.91 484840.06 722603.5 1.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC93-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484834.17 722607.52 1.9 484830.8 722602.57 1.9 484830.8 722602.57 4.91 484834.17 722607.52 4.91 484834.17 722607.52 1.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC93-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484830.8 722602.57 4.91 484836.69 722598.55 4.91 484840.06 722603.5 4.91 484834.17 722607.52 4.91 484830.8 722602.57 4.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC92-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC92-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.1</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC92-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484913.24 722584.71 1.57 484916.61 722589.66 1.57 484922.5 722585.64 1.57 484919.13 722580.69 1.57 484913.24 722584.71 1.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC92-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484913.24 722584.71 1.57 484919.13 722580.69 1.57 484919.13 722580.69 4.67 484913.24 722584.71 4.67 484913.24 722584.71 1.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC92-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484919.13 722580.69 1.57 484922.5 722585.64 1.57 484922.5 722585.64 4.67 484919.13 722580.69 4.67 484919.13 722580.69 1.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC92-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.5 722585.64 1.57 484916.61 722589.66 1.57 484916.61 722589.66 4.67 484922.5 722585.64 4.67 484922.5 722585.64 1.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC92-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484916.61 722589.66 1.57 484913.24 722584.71 1.57 484913.24 722584.71 4.67 484916.61 722589.66 4.67 484916.61 722589.66 1.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC92-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484913.24 722584.71 4.67 484919.13 722580.69 4.67 484922.5 722585.64 4.67 484916.61 722589.66 4.67 484913.24 722584.71 4.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC99-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC99-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.11</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC99-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484871.07 722584.16 1.55 484877.17 722586.24 1.55 484879.28 722580.06 1.55 484873.18 722577.98 1.55 484871.07 722584.16 1.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC99-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484871.07 722584.16 1.55 484873.18 722577.98 1.55 484873.18 722577.98 4.66 484871.07 722584.16 4.66 484871.07 722584.16 1.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC99-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484873.18 722577.98 1.55 484879.28 722580.06 1.55 484879.28 722580.06 4.66 484873.18 722577.98 4.66 484873.18 722577.98 1.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC99-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484879.28 722580.06 1.55 484877.17 722586.24 1.55 484877.17 722586.24 4.66 484879.28 722580.06 4.66 484879.28 722580.06 1.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC99-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484877.17 722586.24 1.55 484871.07 722584.16 1.55 484871.07 722584.16 4.66 484877.17 722586.24 4.66 484877.17 722586.24 1.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC99-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484871.07 722584.16 4.66 484873.18 722577.98 4.66 484879.28 722580.06 4.66 484877.17 722586.24 4.66 484871.07 722584.16 4.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC96-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC96-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.32</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC96-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484577.38 721201.84 2.05 484577.53 721210.03 2.05 484586.47 721210.04 2.05 484586.33 721201.85 2.05 484577.38 721201.84 2.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC96-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484577.38 721201.84 2.05 484586.33 721201.85 2.05 484586.33 721201.85 5.37 484577.38 721201.84 5.37 484577.38 721201.84 2.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC96-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484586.33 721201.85 2.05 484586.47 721210.04 2.05 484586.47 721210.04 5.37 484586.33 721201.85 5.37 484586.33 721201.85 2.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC96-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484586.47 721210.04 2.05 484577.53 721210.03 2.05 484577.53 721210.03 5.37 484586.47 721210.04 5.37 484586.47 721210.04 2.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC96-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484577.53 721210.03 2.05 484577.38 721201.84 2.05 484577.38 721201.84 5.37 484577.53 721210.03 5.37 484577.53 721210.03 2.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC96-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484577.38 721201.84 5.37 484586.33 721201.85 5.37 484586.47 721210.04 5.37 484577.53 721210.03 5.37 484577.38 721201.84 5.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DC98-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DC98-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.43</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC98-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484821.38 722566.08 1.87 484824.75 722571.03 1.87 484830.64 722567.01 1.87 484827.27 722562.06 1.87 484821.38 722566.08 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC98-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484821.38 722566.08 1.87 484827.27 722562.06 1.87 484827.27 722562.06 4.3 484821.38 722566.08 4.3 484821.38 722566.08 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC98-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484827.27 722562.06 1.87 484830.64 722567.01 1.87 484830.64 722567.01 4.3 484827.27 722562.06 4.3 484827.27 722562.06 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC98-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484830.64 722567.01 1.87 484824.75 722571.03 1.87 484824.75 722571.03 4.3 484830.64 722567.01 4.3 484830.64 722567.01 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC98-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484824.75 722571.03 1.87 484821.38 722566.08 1.87 484821.38 722566.08 4.3 484824.75 722571.03 4.3 484824.75 722571.03 1.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DC98-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484821.38 722566.08 4.3 484827.27 722562.06 4.3 484830.64 722567.01 4.3 484824.75 722571.03 4.3 484821.38 722566.08 4.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-57F5-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-57F5-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.02</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-57F5-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484679.8 721229.74 1.78 484685.27 721227.89 1.78 484682.69 721220.23 1.78 484677.12 721222.13 1.78 484679.8 721229.74 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-57F5-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484679.8 721229.74 1.78 484677.12 721222.13 1.78 484677.12 721222.13 4.8 484679.8 721229.74 4.8 484679.8 721229.74 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-57F5-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484677.12 721222.13 1.78 484682.69 721220.23 1.78 484682.69 721220.23 4.8 484677.12 721222.13 4.8 484677.12 721222.13 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-57F5-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484682.69 721220.23 1.78 484685.27 721227.89 1.78 484685.27 721227.89 4.8 484682.69 721220.23 4.8 484682.69 721220.23 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-57F5-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484685.27 721227.89 1.78 484679.8 721229.74 1.78 484679.8 721229.74 4.8 484685.27 721227.89 4.8 484685.27 721227.89 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-57F5-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484679.8 721229.74 4.8 484677.12 721222.13 4.8 484682.69 721220.23 4.8 484685.27 721227.89 4.8 484679.8 721229.74 4.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A3E-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A3E-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.97</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3E-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484819.36 722599.39 1.91 484822.73 722604.34 1.91 484828.62 722600.32 1.91 484825.25 722595.37 1.91 484819.36 722599.39 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3E-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484819.36 722599.39 1.91 484825.25 722595.37 1.91 484825.25 722595.37 4.88 484819.36 722599.39 4.88 484819.36 722599.39 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3E-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484825.25 722595.37 1.91 484828.62 722600.32 1.91 484828.62 722600.32 4.88 484825.25 722595.37 4.88 484825.25 722595.37 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3E-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484828.62 722600.32 1.91 484822.73 722604.34 1.91 484822.73 722604.34 4.88 484828.62 722600.32 4.88 484828.62 722600.32 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3E-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484822.73 722604.34 1.91 484819.36 722599.39 1.91 484819.36 722599.39 4.88 484822.73 722604.34 4.88 484822.73 722604.34 1.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3E-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484819.36 722599.39 4.88 484825.25 722595.37 4.88 484828.62 722600.32 4.88 484822.73 722604.34 4.88 484819.36 722599.39 4.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A3D-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A3D-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.02</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3D-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484811.96 722589.3 1.98 484815.33 722594.25 1.98 484821.22 722590.23 1.98 484817.85 722585.28 1.98 484811.96 722589.3 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3D-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484811.96 722589.3 1.98 484817.85 722585.28 1.98 484817.85 722585.28 5 484811.96 722589.3 5 484811.96 722589.3 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3D-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484817.85 722585.28 1.98 484821.22 722590.23 1.98 484821.22 722590.23 5 484817.85 722585.28 5 484817.85 722585.28 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3D-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484821.22 722590.23 1.98 484815.33 722594.25 1.98 484815.33 722594.25 5 484821.22 722590.23 5 484821.22 722590.23 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3D-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484815.33 722594.25 1.98 484811.96 722589.3 1.98 484811.96 722589.3 5 484815.33 722594.25 5 484815.33 722594.25 1.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3D-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484811.96 722589.3 5 484817.85 722585.28 5 484821.22 722590.23 5 484815.33 722594.25 5 484811.96 722589.3 5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A31-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A31-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.4</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A31-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484671.48 721188.92 1.61 484677.88 721187.78 1.61 484675.94 721176.97 1.61 484669.55 721178.11 1.61 484671.48 721188.92 1.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A31-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484671.48 721188.92 1.61 484669.55 721178.11 1.61 484669.55 721178.11 5.01 484671.48 721188.92 5.01 484671.48 721188.92 1.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A31-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484669.55 721178.11 1.61 484675.94 721176.97 1.61 484675.94 721176.97 5.01 484669.55 721178.11 5.01 484669.55 721178.11 1.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A31-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484675.94 721176.97 1.61 484677.88 721187.78 1.61 484677.88 721187.78 5.01 484675.94 721176.97 5.01 484675.94 721176.97 1.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A31-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484677.88 721187.78 1.61 484671.48 721188.92 1.61 484671.48 721188.92 5.01 484677.88 721187.78 5.01 484677.88 721187.78 1.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A31-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484671.48 721188.92 5.01 484669.55 721178.11 5.01 484675.94 721176.97 5.01 484677.88 721187.78 5.01 484671.48 721188.92 5.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-76D3-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-76D3-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.47</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D3-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484927.59 722517.43 1.34 484922.36 722520.83 1.34 484928.18 722529.87 1.34 484933.53 722526.43 1.34 484935.24 722529.05 1.34 484937.28 722527.71 1.34 484932.77 722520.8 1.34 484930.68 722522.17 1.34 484927.59 722517.43 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D3-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484927.59 722517.43 1.34 484930.68 722522.17 1.34 484930.68 722522.17 4.8100000000000005 484927.59 722517.43 4.8100000000000005 484927.59 722517.43 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D3-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484930.68 722522.17 1.34 484932.77 722520.8 1.34 484932.77 722520.8 4.8100000000000005 484930.68 722522.17 4.8100000000000005 484930.68 722522.17 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D3-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484932.77 722520.8 1.34 484937.28 722527.71 1.34 484937.28 722527.71 4.8100000000000005 484932.77 722520.8 4.8100000000000005 484932.77 722520.8 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D3-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484937.28 722527.71 1.34 484935.24 722529.05 1.34 484935.24 722529.05 4.8100000000000005 484937.28 722527.71 4.8100000000000005 484937.28 722527.71 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D3-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484935.24 722529.05 1.34 484933.53 722526.43 1.34 484933.53 722526.43 4.8100000000000005 484935.24 722529.05 4.8100000000000005 484935.24 722529.05 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D3-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484933.53 722526.43 1.34 484928.18 722529.87 1.34 484928.18 722529.87 4.8100000000000005 484933.53 722526.43 4.8100000000000005 484933.53 722526.43 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D3-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484928.18 722529.87 1.34 484922.36 722520.83 1.34 484922.36 722520.83 4.8100000000000005 484928.18 722529.87 4.8100000000000005 484928.18 722529.87 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D3-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484922.36 722520.83 1.34 484927.59 722517.43 1.34 484927.59 722517.43 4.8100000000000005 484922.36 722520.83 4.8100000000000005 484922.36 722520.83 1.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-76D3-FAF6-E053-CA2BA8C0FAE4_PG_10">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484927.59 722517.43 4.8100000000000005 484930.68 722522.17 4.8100000000000005 484932.77 722520.8 4.8100000000000005 484937.28 722527.71 4.8100000000000005 484935.24 722529.05 4.8100000000000005 484933.53 722526.43 4.8100000000000005 484928.18 722529.87 4.8100000000000005 484922.36 722520.83 4.8100000000000005 484927.59 722517.43 4.8100000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A74-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A74-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.03</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A74-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484852.94 722593.95 1.77 484854.13 722599.82 1.77 484861.12 722598.39 1.77 484859.93 722592.52 1.77 484852.94 722593.95 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A74-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484852.94 722593.95 1.77 484859.93 722592.52 1.77 484859.93 722592.52 4.8 484852.94 722593.95 4.8 484852.94 722593.95 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A74-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484859.93 722592.52 1.77 484861.12 722598.39 1.77 484861.12 722598.39 4.8 484859.93 722592.52 4.8 484859.93 722592.52 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A74-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484861.12 722598.39 1.77 484854.13 722599.82 1.77 484854.13 722599.82 4.8 484861.12 722598.39 4.8 484861.12 722598.39 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A74-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484854.13 722599.82 1.77 484852.94 722593.95 1.77 484852.94 722593.95 4.8 484854.13 722599.82 4.8 484854.13 722599.82 1.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A74-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484852.94 722593.95 4.8 484859.93 722592.52 4.8 484861.12 722598.39 4.8 484854.13 722599.82 4.8 484852.94 722593.95 4.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A73-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A73-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.02</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A73-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484889.74 722550.64 1.6 484893.11 722555.59 1.6 484899 722551.57 1.6 484895.63 722546.62 1.6 484889.74 722550.64 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A73-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484889.74 722550.64 1.6 484895.63 722546.62 1.6 484895.63 722546.62 4.62 484889.74 722550.64 4.62 484889.74 722550.64 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A73-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484895.63 722546.62 1.6 484899 722551.57 1.6 484899 722551.57 4.62 484895.63 722546.62 4.62 484895.63 722546.62 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A73-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484899 722551.57 1.6 484893.11 722555.59 1.6 484893.11 722555.59 4.62 484899 722551.57 4.62 484899 722551.57 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A73-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484893.11 722555.59 1.6 484889.74 722550.64 1.6 484889.74 722550.64 4.62 484893.11 722555.59 4.62 484893.11 722555.59 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A73-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484889.74 722550.64 4.62 484895.63 722546.62 4.62 484899 722551.57 4.62 484893.11 722555.59 4.62 484889.74 722550.64 4.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A72-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A72-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.96</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A72-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484878.06 722570.01 1.78 484883.13 722573.21 1.78 484886.93 722567.17 1.78 484881.86 722563.98 1.78 484878.06 722570.01 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A72-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484878.06 722570.01 1.78 484881.86 722563.98 1.78 484881.86 722563.98 4.735 484878.06 722570.01 4.735 484878.06 722570.01 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A72-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484881.86 722563.98 1.78 484886.93 722567.17 1.78 484886.93 722567.17 4.735 484881.86 722563.98 4.735 484881.86 722563.98 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A72-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484886.93 722567.17 1.78 484883.13 722573.21 1.78 484883.13 722573.21 4.735 484886.93 722567.17 4.735 484886.93 722567.17 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A72-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484883.13 722573.21 1.78 484878.06 722570.01 1.78 484878.06 722570.01 4.735 484883.13 722573.21 4.735 484883.13 722573.21 1.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A72-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484878.06 722570.01 4.735 484881.86 722563.98 4.735 484886.93 722567.17 4.735 484883.13 722573.21 4.735 484878.06 722570.01 4.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A3C-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A3C-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.99</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3C-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484805.06 722576.09 1.93 484808.43 722581.04 1.93 484814.32 722577.02 1.93 484810.95 722572.07 1.93 484805.06 722576.09 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3C-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484805.06 722576.09 1.93 484810.95 722572.07 1.93 484810.95 722572.07 4.92 484805.06 722576.09 4.92 484805.06 722576.09 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3C-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484810.95 722572.07 1.93 484814.32 722577.02 1.93 484814.32 722577.02 4.92 484810.95 722572.07 4.92 484810.95 722572.07 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3C-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484814.32 722577.02 1.93 484808.43 722581.04 1.93 484808.43 722581.04 4.92 484814.32 722577.02 4.92 484814.32 722577.02 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3C-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484808.43 722581.04 1.93 484805.06 722576.09 1.93 484805.06 722576.09 4.92 484808.43 722581.04 4.92 484808.43 722581.04 1.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3C-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484805.06 722576.09 4.92 484810.95 722572.07 4.92 484814.32 722577.02 4.92 484808.43 722581.04 4.92 484805.06 722576.09 4.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A3B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A3B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.94</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484838.12 722596.96 1.84 484841.49 722601.91 1.84 484847.38 722597.89 1.84 484844.01 722592.94 1.84 484838.12 722596.96 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484838.12 722596.96 1.84 484844.01 722592.94 1.84 484844.01 722592.94 4.78 484838.12 722596.96 4.78 484838.12 722596.96 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484844.01 722592.94 1.84 484847.38 722597.89 1.84 484847.38 722597.89 4.78 484844.01 722592.94 4.78 484844.01 722592.94 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484847.38 722597.89 1.84 484841.49 722601.91 1.84 484841.49 722601.91 4.78 484847.38 722597.89 4.78 484847.38 722597.89 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484841.49 722601.91 1.84 484838.12 722596.96 1.84 484838.12 722596.96 4.78 484841.49 722601.91 4.78 484841.49 722601.91 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A3B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484838.12 722596.96 4.78 484844.01 722592.94 4.78 484847.38 722597.89 4.78 484841.49 722601.91 4.78 484838.12 722596.96 4.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A71-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A71-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.98</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A71-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484881.74 722558.59 1.6 484886.41 722562.34 1.6 484890.86 722556.77 1.6 484886.19 722553.03 1.6 484881.74 722558.59 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A71-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484881.74 722558.59 1.6 484886.19 722553.03 1.6 484886.19 722553.03 4.58 484881.74 722558.59 4.58 484881.74 722558.59 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A71-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484886.19 722553.03 1.6 484890.86 722556.77 1.6 484890.86 722556.77 4.58 484886.19 722553.03 4.58 484886.19 722553.03 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A71-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484890.86 722556.77 1.6 484886.41 722562.34 1.6 484886.41 722562.34 4.58 484890.86 722556.77 4.58 484890.86 722556.77 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A71-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484886.41 722562.34 1.6 484881.74 722558.59 1.6 484881.74 722558.59 4.58 484886.41 722562.34 4.58 484886.41 722562.34 1.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A71-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484881.74 722558.59 4.58 484886.19 722553.03 4.58 484890.86 722556.77 4.58 484886.41 722562.34 4.58 484881.74 722558.59 4.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7442-DD5B-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7442-DD5B-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.16</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5B-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484953.3 721324.3 3.6 484953.84 721329.72 3.6 484962.06 721328.9 3.6 484961.51 721323.48 3.6 484953.3 721324.3 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5B-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484953.3 721324.3 3.6 484961.51 721323.48 3.6 484961.51 721323.48 5.76 484953.3 721324.3 5.76 484953.3 721324.3 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5B-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484961.51 721323.48 3.6 484962.06 721328.9 3.6 484962.06 721328.9 5.76 484961.51 721323.48 5.76 484961.51 721323.48 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5B-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484962.06 721328.9 3.6 484953.84 721329.72 3.6 484953.84 721329.72 5.76 484962.06 721328.9 5.76 484962.06 721328.9 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5B-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484953.84 721329.72 3.6 484953.3 721324.3 3.6 484953.3 721324.3 5.76 484953.84 721329.72 5.76 484953.84 721329.72 3.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7442-DD5B-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484953.3 721324.3 5.76 484961.51 721323.48 5.76 484962.06 721328.9 5.76 484953.84 721329.72 5.76 484953.3 721324.3 5.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-077F-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-077F-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.77</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077F-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484681.35 721268.8 1.84 484681.8 721265.72 1.84 484683.65 721256.04 1.84 484673.33 721254.08 1.84 484671.5 721263.72 1.84 484674.15 721264.25 1.84 484673.57 721267.34 1.84 484681.35 721268.8 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077F-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484681.35 721268.8 1.84 484673.57 721267.34 1.84 484673.57 721267.34 4.61 484681.35 721268.8 4.61 484681.35 721268.8 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077F-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484673.57 721267.34 1.84 484674.15 721264.25 1.84 484674.15 721264.25 4.61 484673.57 721267.34 4.61 484673.57 721267.34 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077F-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484674.15 721264.25 1.84 484671.5 721263.72 1.84 484671.5 721263.72 4.61 484674.15 721264.25 4.61 484674.15 721264.25 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077F-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484671.5 721263.72 1.84 484673.33 721254.08 1.84 484673.33 721254.08 4.61 484671.5 721263.72 4.61 484671.5 721263.72 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077F-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484673.33 721254.08 1.84 484683.65 721256.04 1.84 484683.65 721256.04 4.61 484673.33 721254.08 4.61 484673.33 721254.08 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077F-FAF6-E053-CA2BA8C0FAE4_PG_7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484683.65 721256.04 1.84 484681.8 721265.72 1.84 484681.8 721265.72 4.61 484683.65 721256.04 4.61 484683.65 721256.04 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077F-FAF6-E053-CA2BA8C0FAE4_PG_8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484681.8 721265.72 1.84 484681.35 721268.8 1.84 484681.35 721268.8 4.61 484681.8 721265.72 4.61 484681.8 721265.72 1.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-077F-FAF6-E053-CA2BA8C0FAE4_PG_9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484681.35 721268.8 4.61 484673.57 721267.34 4.61 484674.15 721264.25 4.61 484671.5 721263.72 4.61 484673.33 721254.08 4.61 484683.65 721256.04 4.61 484681.8 721265.72 4.61 484681.35 721268.8 4.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A00-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A00-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">5.9</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A00-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484706.06 721373.31 4.21 484715.26 721371.07 4.21 484713.92 721365.57 4.21 484704.71 721367.82 4.21 484706.06 721373.31 4.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A00-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484706.06 721373.31 4.21 484704.71 721367.82 4.21 484704.71 721367.82 10.11 484706.06 721373.31 10.11 484706.06 721373.31 4.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A00-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484704.71 721367.82 4.21 484713.92 721365.57 4.21 484713.92 721365.57 10.11 484704.71 721367.82 10.11 484704.71 721367.82 4.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A00-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484713.92 721365.57 4.21 484715.26 721371.07 4.21 484715.26 721371.07 10.11 484713.92 721365.57 10.11 484713.92 721365.57 4.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A00-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484715.26 721371.07 4.21 484706.06 721373.31 4.21 484706.06 721373.31 10.11 484715.26 721371.07 10.11 484715.26 721371.07 4.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A00-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484706.06 721373.31 10.11 484704.71 721367.82 10.11 484713.92 721365.57 10.11 484715.26 721371.07 10.11 484706.06 721373.31 10.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A78-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A78-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">3.86</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A78-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485622.67 722787.44 2.56 485624.14 722793.63 2.56 485636.52 722790.68 2.56 485635.05 722784.49 2.56 485622.67 722787.44 2.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A78-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485622.67 722787.44 2.56 485635.05 722784.49 2.56 485635.05 722784.49 6.42 485622.67 722787.44 6.42 485622.67 722787.44 2.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A78-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485635.05 722784.49 2.56 485636.52 722790.68 2.56 485636.52 722790.68 6.42 485635.05 722784.49 6.42 485635.05 722784.49 2.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A78-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485636.52 722790.68 2.56 485624.14 722793.63 2.56 485624.14 722793.63 6.42 485636.52 722790.68 6.42 485636.52 722790.68 2.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A78-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485624.14 722793.63 2.56 485622.67 722787.44 2.56 485622.67 722787.44 6.42 485624.14 722793.63 6.42 485624.14 722793.63 2.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A78-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>485622.67 722787.44 6.42 485635.05 722784.49 6.42 485636.52 722790.68 6.42 485624.14 722793.63 6.42 485622.67 722787.44 6.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A34-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A34-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.85</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A34-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484670.52 721157.88 0.98 484673.81 721160.94 0.98 484678.79 721155.58 0.98 484675.51 721152.52 0.98 484670.52 721157.88 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A34-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484670.52 721157.88 0.98 484675.51 721152.52 0.98 484675.51 721152.52 3.83 484670.52 721157.88 3.83 484670.52 721157.88 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A34-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484675.51 721152.52 0.98 484678.79 721155.58 0.98 484678.79 721155.58 3.83 484675.51 721152.52 3.83 484675.51 721152.52 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A34-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484678.79 721155.58 0.98 484673.81 721160.94 0.98 484673.81 721160.94 3.83 484678.79 721155.58 3.83 484678.79 721155.58 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A34-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484673.81 721160.94 0.98 484670.52 721157.88 0.98 484670.52 721157.88 3.83 484673.81 721160.94 3.83 484673.81 721160.94 0.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A34-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484670.52 721157.88 3.83 484675.51 721152.52 3.83 484678.79 721155.58 3.83 484673.81 721160.94 3.83 484670.52 721157.88 3.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A33-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A33-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.55</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A33-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484661.84 721165.64 1.37 484663.9 721169.12 1.37 484671.28 721164.75 1.37 484669.22 721161.27 1.37 484661.84 721165.64 1.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A33-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484661.84 721165.64 1.37 484669.22 721161.27 1.37 484669.22 721161.27 3.915 484661.84 721165.64 3.915 484661.84 721165.64 1.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A33-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484669.22 721161.27 1.37 484671.28 721164.75 1.37 484671.28 721164.75 3.915 484669.22 721161.27 3.915 484669.22 721161.27 1.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A33-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484671.28 721164.75 1.37 484663.9 721169.12 1.37 484663.9 721169.12 3.915 484671.28 721164.75 3.915 484671.28 721164.75 1.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A33-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484663.9 721169.12 1.37 484661.84 721165.64 1.37 484661.84 721165.64 3.915 484663.9 721169.12 3.915 484663.9 721169.12 1.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A33-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484661.84 721165.64 3.915 484669.22 721161.27 3.915 484671.28 721164.75 3.915 484663.9 721169.12 3.915 484661.84 721165.64 3.915</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
	<cityObjectMember>
		<bldg:Building gml:id="ID-2261-26BC7443-7A32-FAF6-E053-CA2BA8C0FAE4">
			<gen:stringAttribute name="buildingId">
				<gen:value>26BC7443-7A32-FAF6-E053-CA2BA8C0FAE4</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="przestNazw">
				<gen:value>PL.PZGiK.336.BDOT10k</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="wersjaId">
				<gen:value>2023-08-01T00:00:00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="zrodloDach">
				<gen:value>ALS_II</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="aktZrodla">
				<gen:value>2024</gen:value>
			</gen:stringAttribute>
			<bldg:roofType>1000</bldg:roofType>
			<bldg:measuredHeight uom="meter">2.9</bldg:measuredHeight>
			<bldg:lod1Solid>
				<gml:Solid srsName="urn:ogc:def:crs,crs:EPSG::2180,crs:EPSG::9651" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A32-FAF6-E053-CA2BA8C0FAE4_PG_1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484658.4 721155.7 1.22 484660.84 721163.87 1.22 484667.92 721161.75 1.22 484665.48 721153.59 1.22 484658.4 721155.7 1.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A32-FAF6-E053-CA2BA8C0FAE4_PG_2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484658.4 721155.7 1.22 484665.48 721153.59 1.22 484665.48 721153.59 4.12 484658.4 721155.7 4.12 484658.4 721155.7 1.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A32-FAF6-E053-CA2BA8C0FAE4_PG_3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484665.48 721153.59 1.22 484667.92 721161.75 1.22 484667.92 721161.75 4.12 484665.48 721153.59 4.12 484665.48 721153.59 1.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A32-FAF6-E053-CA2BA8C0FAE4_PG_4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484667.92 721161.75 1.22 484660.84 721163.87 1.22 484660.84 721163.87 4.12 484667.92 721161.75 4.12 484667.92 721161.75 1.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A32-FAF6-E053-CA2BA8C0FAE4_PG_5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484660.84 721163.87 1.22 484658.4 721155.7 1.22 484658.4 721155.7 4.12 484660.84 721163.87 4.12 484660.84 721163.87 1.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="ID-2261-26BC7443-7A32-FAF6-E053-CA2BA8C0FAE4_PG_6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>484658.4 721155.7 4.12 484665.48 721153.59 4.12 484667.92 721161.75 4.12 484660.84 721163.87 4.12 484658.4 721155.7 4.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
		</bldg:Building>
	</cityObjectMember>
</CityModel>